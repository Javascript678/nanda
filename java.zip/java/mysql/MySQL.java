package mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import java.util.*;
import java.util.stream.Stream;

import org.apache.commons.pool.ObjectPool;
import org.apache.commons.pool.PoolableObjectFactory;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.commons.pool.impl.GenericObjectPoolFactory;
import org.apache.commons.pool.impl.GenericObjectPool.Config;
import org.json.JSONException;

import mysql.pool.MySqlPoolableException;
import mysql.pool.MySqlPoolableObjectFactory;

import mysql.Queries;

/**
 * @author ppinho
 * 
 *         MySQL class to make JDBC connection, Add and Retrieve/Update/Delete
 *         Data
 * 
 */

public class MySQL {

	private HashMap<String, String> mysqlData;

	public MySQL(HashMap<String, String> mysqlData) {
		this.mysqlData = mysqlData;
	}

	List<String> scenarios = new ArrayList<>();

	public HashMap<String, Object> getTestDataFromDB(Connection conn, ObjectPool connPool, PreparedStatement prepareData, String table, String featureFile) throws JSONException {
		Queries queries = new Queries(mysqlData);

		Map<String, Object> testDataValues = new HashMap<String, Object>();

		ResultSet resultSet = null;
		ResultSetMetaData metaData;

		try {
			// Create SQL Query as a String
			String getTestData = queries.selectTestDataQuery(table, featureFile);

			// Parameterized SQL statement to the database
			prepareData = conn.prepareStatement(getTestData);

			// Execute the Query, and get the java ResultSet
			resultSet = prepareData.executeQuery();

			// Get the java MetaData
			metaData = resultSet.getMetaData();
			int columns = metaData.getColumnCount();

			// Iterate through the java ResultSet
			while (resultSet.next()) {
				Map<String, String> memValues = new HashMap<String, String>();

				for (int i = 1; i <= columns; i++) {
					String columnName = toTitleCase(metaData.getColumnName(i));
					// Put individual member values in a Map replace null values
					// with empty string
					if (resultSet.getString(i) == null) {
						memValues.put(columnName, "");
					} else {
						memValues.put(columnName, resultSet.getString(i));
					}
				}
				// Put member Map values inside HashMap
				testDataValues.put(Integer.toString(resultSet.getRow() - 1), memValues);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			try {
				throw new MySqlPoolableException("Failed to borrow connection from the pool", e);
			} catch (MySqlPoolableException e1) {
				e1.printStackTrace();
			}
		} finally {
			safeClose(resultSet);
		}

		return (HashMap<String, Object>) testDataValues;
	}

	private void generateTempDataInDB(Connection conn, String table) {
		Queries queries = new Queries(mysqlData);

		PreparedStatement prepareData = null;

		try {
			String deleteTempData = queries.deleteTestDataQuery("temp_data");
			prepareData = conn.prepareStatement(deleteTempData);
			prepareData.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
		}
		
		try {
			String truncateTempData = queries.truncateTestDataQuery("temp_data");
			prepareData = conn.prepareStatement(truncateTempData);
			prepareData.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
		}
		
		try {
			String generateTempData = queries.tempDataQuery(table.replace("_evpd", ""));
			prepareData = conn.prepareStatement(generateTempData);
			prepareData.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
		}
	}

	private void deleteTestDataInDB(Connection conn, String table) {
		Queries queries = new Queries(mysqlData);
		
		PreparedStatement prepareData = null;

		try {
			String deleteTestData = queries.deleteTestDataQuery(table);
			
			prepareData = conn.prepareStatement(deleteTestData);
			prepareData.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
		}
	}

	private void truncateTestDataInDB(Connection conn, String table) {
		Queries queries = new Queries(mysqlData);
		
		PreparedStatement prepareData = null;
		
		try {
			String truncateTestData = queries.truncateTestDataQuery(table);
			
			prepareData = conn.prepareStatement(truncateTestData);
			prepareData.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
		}
	}

	private void getScenariosInDB(Connection conn, String table) {
		Queries queries = new Queries(mysqlData);

		PreparedStatement prepareData = null;
		ResultSet resultSet = null;

		try {
			String getScenario = queries.getScenarioQuery(table);
			
			prepareData = conn.prepareStatement(getScenario);
			resultSet = prepareData.executeQuery();

			while (resultSet.next()) {
				scenarios.add(resultSet.getString("scenario"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
			safeClose(resultSet);			
		}
	}

	public String getElgIdsInDB(Connection conn, String table) {
		Queries queries = new Queries(mysqlData);

		List<String> elgIdArr = new ArrayList<>();
		String elgIds = null;

		PreparedStatement prepareData = null;
		ResultSet resultSet = null;

		try {
			String getElgIds = queries.selectElgIdQuery(table);
			
			prepareData = conn.prepareStatement(getElgIds);
			resultSet = prepareData.executeQuery();

			while (resultSet.next()) {
				elgIdArr.add(resultSet.getString("elg_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
			safeClose(resultSet);
		}

		for (String elgId : elgIdArr) {
			if (elgIds == null) {
				elgIds = elgId;
			} else {
				elgIds = elgIds + ", " + elgId;
			}
		}

		return elgIds;
	}

	private int getMemCountInDB(Connection conn, String table, String scenario) {
		Queries queries = new Queries(mysqlData);

		int count = 0;

		PreparedStatement prepareData = null;
		ResultSet resultSet = null;

		try {
			String taxHHCount = queries.memCountQuery(table, scenario);
			
			prepareData = conn.prepareStatement(taxHHCount);
			resultSet = prepareData.executeQuery();

			while (resultSet.next()) {
				count = resultSet.getInt("count");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
			safeClose(resultSet);
		}

		return count;
	}

	private int getTaxHhCountInDB(Connection conn, String table, String scenario) {
		Queries queries = new Queries(mysqlData);

		int count = 0;

		PreparedStatement prepareData = null;
		ResultSet resultSet = null;

		try {
			String taxHHCount = queries.taxHHCountQuery(table, scenario);
			
			prepareData = conn.prepareStatement(taxHHCount);
			resultSet = prepareData.executeQuery();

			while (resultSet.next()) {
				count = resultSet.getInt("count");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
			safeClose(resultSet);
		}

		return count;
	}

	private String getTaxHhIncomeSumInDB(Connection conn, String table, String scenario, int taxHH) {
		Queries queries = new Queries(mysqlData);

		String taxHhIncome = null;

		PreparedStatement prepareData = null;
		ResultSet resultSet = null;

		try {
			String sumTaxHhIncome = queries.sumTaxHhIncomeQuery(table, scenario, taxHH);
			
			prepareData = conn.prepareStatement(sumTaxHhIncome);
			resultSet = prepareData.executeQuery();

			while (resultSet.next()) {
				taxHhIncome = resultSet.getString("sum");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
			safeClose(resultSet);
		}

		return taxHhIncome;
	}

	private void updateTaxHhIncomeSumInDB(Connection conn, String table, String scenario, int taxHH, String taxHhIncome) {
		Queries queries = new Queries(mysqlData);
		
		PreparedStatement prepareData = null;

		try {
			String updateTaxHhIncome = queries.updateTaxHhIncomeQuery(table, scenario, taxHH, taxHhIncome);

			prepareData = conn.prepareStatement(updateTaxHhIncome);
			prepareData.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
		}
	}

	private HashMap<Integer, String> getMagiHhMembersInDB(Connection conn, String table, String scenario) {
		Queries queries = new Queries(mysqlData);

		HashMap<Integer, String> members = new HashMap<Integer, String>();

		PreparedStatement prepareData = null;
		ResultSet resultSet = null;

		try {
			String magiHHCount = queries.magiHhMemQuery(table, scenario);
			
			prepareData = conn.prepareStatement(magiHHCount);
			resultSet = prepareData.executeQuery();

			int count = 0;

			while (resultSet.next()) {
				members.put(count++, resultSet.getString("members"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
			safeClose(resultSet);
		}

		return members;
	}

	private String getMagiHhIncomeSumInDB(HashMap<String, String> gd, Connection conn, String table, String scenario, String magiHH) {
		Queries queries = new Queries(mysqlData);

		String magiHhIncome = null;

		PreparedStatement prepareData = null;
		ResultSet resultSet = null;

		try {
			String sumMagiHhIncome = queries.sumMagiHhIncomeQuery(gd, table, scenario, magiHH);
			
			prepareData = conn.prepareStatement(sumMagiHhIncome);
			resultSet = prepareData.executeQuery();

			while (resultSet.next()) {
				magiHhIncome = resultSet.getString("sum");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
			safeClose(resultSet);
		}

		return magiHhIncome;
	}

	private void updateMagiHhIncomeSumInDB(Connection conn, String table, String scenario, String magiHhMembers, String magiHHIncome) {
		Queries queries = new Queries(mysqlData);

		PreparedStatement prepareData = null;
		
		try {
			String updateMagiHHIncome = queries.updateMagiHhIncomeQuery(table, scenario, magiHhMembers, magiHHIncome);
			
			prepareData = conn.prepareStatement(updateMagiHHIncome);
			prepareData.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
		}
	}

	public void updateEligibilityIdInDB(Connection conn, ObjectPool connPool, String table, String scenario, String eligibilityId) {
		Queries queries = new Queries(mysqlData);

		PreparedStatement prepareData = null;
		
		try {
			String updateEligibilityId = queries.updateEligibilityIdQuery(table, scenario, eligibilityId);
			
			prepareData = conn.prepareStatement(updateEligibilityId);
			prepareData.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
		}
	}

	public void updateRefIdInDB(Connection conn, ObjectPool connPool, String table, String scenario, String refId) {
		Queries queries = new Queries(mysqlData);
		
		PreparedStatement prepareData = null;

		try {
			String updateRefId = queries.updateRefIdQuery(table, scenario, refId);
			
			prepareData = conn.prepareStatement(updateRefId);
			prepareData.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			safeClose(prepareData);
		}
	}

	public void updateMemberDataInDB(Connection conn, ObjectPool connPool, String table, String scenario, String eligibilityId, String refId) throws JSONException {
		try {
			updateEligibilityIdInDB(conn, connPool, table, scenario, eligibilityId);
			updateRefIdInDB(conn, connPool, table, scenario, refId);
		} catch (Exception e) {
			try {
				throw new MySqlPoolableException("Failed to borrow connection from the pool", e);
			} catch (MySqlPoolableException e1) {
				e1.printStackTrace();
			}
		}
	}

	public List<Integer> getCriticalPdIds(Connection conn, ObjectPool connPool, String table) throws JSONException {
		Queries queries = new Queries(mysqlData);

		PreparedStatement prepareData = null;
		ResultSet resultSet = null;

		List<Integer> pdBenefitsId = new ArrayList<>();

		try {
			getScenariosInDB(conn, table);

			for (String scenario : scenarios) {
				String getPdBenefitsId = queries.selectPdBenefitsIdQuery(table, scenario);

				prepareData = conn.prepareStatement(getPdBenefitsId);
				resultSet = prepareData.executeQuery();

				while (resultSet.next()) {
					pdBenefitsId.add(Integer.parseInt(resultSet.getString("pd_benefits_id")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			try {
				throw new MySqlPoolableException("Failed to borrow connection from the pool", e);
			} catch (MySqlPoolableException e1) {
				e1.printStackTrace();
			}
		} finally {
			safeClose(prepareData);
			safeClose(resultSet);
		}

		scenarios.clear();

		return pdBenefitsId;
	}

	public void createEVPDTestDataInDB(Connection conn, ObjectPool connPool, String table, HashMap<String, String> gd) throws JSONException {
		Queries queries = new Queries(mysqlData);

		HashMap<Integer, String> magiHhMembers = new HashMap<Integer, String>();
		
		PreparedStatement prepareData = null;

		try {
			// Generate Temp Data
			if (!Stream.of("pd_benefits", "hh_comp").anyMatch(table::contains)) {
				generateTempDataInDB(conn, table);
			}

			// Refresh Test Data
			deleteTestDataInDB(conn, table);
			truncateTestDataInDB(conn, table);

			String createTestData = queries.evpdQuery(table.replace("_evpd", ""));

			// Run query to generate EVPD test data in given env
			prepareData = conn.prepareStatement(createTestData);
			prepareData.executeUpdate();

			getScenariosInDB(conn, table);

			for (String scenario : scenarios) {
				int taxHhCount = getTaxHhCountInDB(conn, table, scenario);

				// Sum up each tax hh and update DB
				for (int taxHH = 1; taxHH <= taxHhCount; taxHH++) {
					String taxHhIncomeSum = getTaxHhIncomeSumInDB(conn, table, scenario, taxHH);
					updateTaxHhIncomeSumInDB(conn, table, scenario, taxHH, taxHhIncomeSum);
				}

				magiHhMembers = getMagiHhMembersInDB(conn, table, scenario);

				// Sum up each magi hh and update DB
				for (int magiInd = 0; magiInd < magiHhMembers.size(); magiInd++) {
					String magiHhIncomeSum = getMagiHhIncomeSumInDB(gd, conn, table, scenario,
					magiHhMembers.get(magiInd).replace(":", ","));
					updateMagiHhIncomeSumInDB(conn, table, scenario, magiHhMembers.get(magiInd), magiHhIncomeSum);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			try {
				throw new MySqlPoolableException("Failed to borrow connection from the pool", e);
			} catch (MySqlPoolableException e1) {
				e1.printStackTrace();
			}
		} finally {
			safeClose(prepareData);
		}

		scenarios.clear();
	}

	public void createEnrollmentTestDataInDB(Connection conn, ObjectPool connPool, String table, HashMap<String, String> gd) throws JSONException {
		Queries queries = new Queries(mysqlData);
		
		PreparedStatement prepareData = null;

		try {
			deleteTestDataInDB(conn, table);
			truncateTestDataInDB(conn, table);

			String createTestData = queries.enrollmentQuery(table.replace("_shopping", ""));

			prepareData = conn.prepareStatement(createTestData);
			prepareData.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			try {
				throw new MySqlPoolableException("Failed to borrow connection from the pool", e);
			} catch (MySqlPoolableException e1) {
				e1.printStackTrace();
			}
		} finally {
			safeClose(prepareData);
		}

		scenarios.clear();
	}

	public void createInitialPrelimTestDataInDB(Connection conn, ObjectPool connPool, String table, HashMap<String, String> gd) throws JSONException {
		Queries queries = new Queries(mysqlData);
		
		PreparedStatement prepareData = null;

		try {
			// Refresh Test Data
			deleteTestDataInDB(conn, table);
			truncateTestDataInDB(conn, table);

			getScenariosInDB(conn, table.replace("_initial_prelim", "_evpd"));

			for (String scenario : scenarios) {
				int memCount = getMemCountInDB(conn, table.replace("_initial_prelim", "_evpd"), scenario);

				// Sum up each magi hh and update DB
				for (int memInd = 0; memInd < memCount; memInd++) {
					String createTestData = queries.initialPrelimQuery(table.replace("_initial_prelim", ""), scenario, (memInd + 1));
					prepareData = conn.prepareStatement(createTestData);
					prepareData.executeUpdate();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			try {
				throw new MySqlPoolableException("Failed to borrow connection from the pool", e);
			} catch (MySqlPoolableException e1) {
				e1.printStackTrace();
			}
		} finally {
			safeClose(prepareData);
		}

		scenarios.clear();
	}

	public ObjectPool initMySqlConnectionPool() {
		PoolableObjectFactory mySqlPoolableObjectFactory = new MySqlPoolableObjectFactory(mysqlData);

		Config config = new GenericObjectPool.Config();

		config.maxActive = 145;
		config.testOnBorrow = true;
		config.testWhileIdle = true;
		config.timeBetweenEvictionRunsMillis = 100;
		config.minEvictableIdleTimeMillis = 600;

		GenericObjectPoolFactory genericObjectPoolFactory = new GenericObjectPoolFactory(mySqlPoolableObjectFactory, config);
		ObjectPool pool = genericObjectPoolFactory.createPool();

		return pool;
	}

	private void safeClose(PreparedStatement stmt) {
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				System.out.printf("Failed to close databse resultset", e);
			}
		}
	}

	private void safeClose(ResultSet res) {
		if (res != null) {
			try {
				res.close();
			} catch (SQLException e) {
				System.out.printf("Failed to close databse resultset", e);
			}
		}
	}

	public static String toTitleCase(String givenString) {
		String newString = givenString.replace("_", " ");

		String[] arr = newString.split(" ");
		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < arr.length; i++) {
			sb.append(Character.toUpperCase(arr[i].charAt(0))).append(arr[i].substring(1)).append(" ");
		}

		newString = sb.toString().trim();
		newString = newString.replace(" ", "");
		newString = Character.toLowerCase(newString.charAt(0)) + newString.substring(1);

		return newString;
	}
}