package mysql;

import java.util.HashMap;

public class MySQL_Conn_Data {
	
    private HashMap<String, String> globalData;

    public MySQL_Conn_Data(HashMap<String, String> globalData) {
         this.globalData = globalData;
    }
	
	public HashMap<String, String> mysqlData = new HashMap<String, String>();
	
	public HashMap<String, String> getMySQLdata() throws Exception {
		mysqlData.put("host", globalData.get("mysql_host"));
		mysqlData.put("port", globalData.get("mysql_port"));
		mysqlData.put("schema", globalData.get("mysql_schema"));
		mysqlData.put("user", globalData.get("mysql_user"));
		mysqlData.put("password", globalData.get("mysql_password"));
		
		return mysqlData;		
	}
	
}
