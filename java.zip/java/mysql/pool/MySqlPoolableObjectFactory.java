package mysql.pool;

import java.sql.DriverManager;
import java.util.HashMap;

import org.apache.commons.pool.BasePoolableObjectFactory;
 
public class MySqlPoolableObjectFactory extends BasePoolableObjectFactory {
     private String host;
     private int port;
     private String schema;
     private String user;
     private String password;
 
     public MySqlPoolableObjectFactory(HashMap<String, String> mysqlData) {
          this.host = mysqlData.get("host");
          this.port = Integer.parseInt(mysqlData.get("port"));
          this.schema = mysqlData.get("schema");
          this.user = mysqlData.get("user");
          this.password = mysqlData.get("password");
     }

	@Override
	public Object makeObject() throws Exception {
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		
		String url = "jdbc:mysql://" + host + ":" + port + "/" + schema + "?autoReconnectForPools=true";
		
		return DriverManager.getConnection(url, user, password);
	}
}