package mysql;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

public class Queries {
	
    private String schema;

    public Queries(HashMap<String, String> mysqlData) {
         this.schema = mysqlData.get("schema");
    }
    
    public String idColumn(String table){
    	List<String> vbfArray = new ArrayList<>();
    	
    	vbfArray.add("pd_benefits");
    	vbfArray.add("hh_comp");
    	vbfArray.add("cca_renewal");
		vbfArray.add("enrollments");
		vbfArray.add("mmis");
		vbfArray.add("notices");
		vbfArray.add("pd_admin_closure");
		vbfArray.add("r21_hcr123");
		vbfArray.add("r21_dr");
		vbfArray.add("r21_oe2021");
		vbfArray.add("r21_csi");
    	//r21_hcr123_data
		
    	String id = "";
    	
    	for(String vbf : vbfArray){
    		if(table.contains(vbf)){
    			id = vbf + "_id";
    			break;
    		}
    	}
    	
    	return id;
    }
    
    public String vbfInd(String table){
    	String vbfInd = "";
    	
    	for(int i = 0; i < table.split("_").length; i++){
    		if(i == 0){
    			vbfInd = vbfInd + table.split("_", i).toString();
    		}else{
    			vbfInd = vbfInd + table.split("_", i).toString().toUpperCase();
    		}
    	}
    	
    	return vbfInd;
    }
	
	public String selectTestDataQuery(String table, String featureFile) {		
    	String selectQuery = "SELECT * FROM " + table + " WHERE SCENARIO = '" + featureFile + "'";
    	return selectQuery;
	}
	
	public String showProcessListQuery() {		
    	String showProcessList = "SHOW PROCESSLIST";
    	return showProcessList;
	}
	
	public String killProcessQuery(String id) {		
    	String killProcess = "KILL " + id;
    	return killProcess;
	}
	
    public String deleteTestDataQuery(String table) {		
    	String deleteQuery = "DELETE FROM " + schema + "." + table;
    	return deleteQuery;
	}
    
    public String truncateTestDataQuery(String table) {		
    	String truncateQuery = "TRUNCATE TABLE " + schema + "." + table; 						     
        return truncateQuery;
	}
    
    public String getScenarioQuery(String table) {		
    	String scenario = "SELECT DISTINCT " + table + ".scenario AS scenario " +
			    		  "FROM " + table; 						     
        return scenario;
	}
    
    public String selectPdBenefitsIdQuery(String table, String scenario) {		
    	String pdBenefitsId = "SELECT DISTINCT " + table + ".pd_benefits_id AS pd_benefits_id " +
			    		      "FROM " + table + " " +
    						  "WHERE " + table + ".scenario = '" + scenario + "'";
        return pdBenefitsId;
	}
    
    public String selectElgIdQuery(String table) {		
    	String pdBenefitsId = "SELECT " + table + ".elg_id AS elg_id" +
    						  " FROM " + table +
    						  " WHERE " + table + ".elg_id IS NOT NULL";
        return pdBenefitsId;
	}
    
    public String memCountQuery(String table, String scenario) {		
    	String memCount = "SELECT COUNT(DISTINCT(" + table + ".mem_id)) AS count " +
    						"FROM " + table + " " +
    						"WHERE " + table + ".scenario = '" + scenario + "'"; 						     
        return memCount;
	}
    
    public String taxHHCountQuery(String table, String scenario) {		
    	String taxHHCount = "SELECT COUNT(DISTINCT(" + table + ".ms_tax_hh_index)) AS count " +
    						"FROM " + table + " " +
    						"WHERE " + table + ".scenario = '" + scenario + "'"; 						     
        return taxHHCount;
	}
    
    public String sumTaxHhIncomeQuery(String table, String scenario, int taxHH) {
    	String id = idColumn(table);
    	
		//String sumTaxHhIncome = "SELECT SUM(a.ms_tax_hh_income) AS sum " + 
		String sumTaxHhIncome = "SELECT taxHhIncome(a." + id + ", a.mem_id, getTaxHhFpl(a.ms_magi_hh_size, " +
									"@sum := SUM(IF(a.ms_alt_expected_yearly_income IS NULL,  " +
									"getIncome(ms_job_income) +  " +
									"IF(ms_se_income IS NULL, 0, ms_se_income) +  " +
									"getIncome(ms_fishing_farming_income) + " +
									"getIncome(ms_ssb_income) + " +
									"getIncome(ms_unemployment_income) + " +
									"getIncome(ms_retirement_income) + " +
									"IF(ms_cg_income IS NULL, 0, ms_cg_income) +  " +
									"getIncome(ms_ii_income) + " +
									"getIncome(ms_rental_ri_income) + " +
									"getIncome(ms_alimony_income) + " +
									"getIncome(ms_other_income), " +
									"a.ms_alt_expected_yearly_income)))) AS sum " +
								"FROM " + table + " a " +
								"WHERE a.scenario = '" + scenario + "' " +
								"AND a.ms_tax_hh_index = " + taxHH;
 						  
        return sumTaxHhIncome;
	}
    
    public String updateTaxHhIncomeQuery(String table,  String scenario, int taxHH, String taxHhIncome) {
    	String updateTaxHhIncome = "UPDATE " + table + " " +
								   "SET " + table + ".ms_tax_hh_income = '" + taxHhIncome + "' " +
								   "WHERE " + table + ".scenario = '"  + scenario + "' " +
								   "AND " + table + ".ms_tax_hh_index = " + taxHH;
 		
    	return updateTaxHhIncome;
	}
    
    public String magiHhCountQuery(String table, String scenario) {		
    	String magiHhCount = "SELECT COUNT(DISTINCT(" + table + ".ms_magi_hh_members)) AS count " +
    					     "FROM " + table + " " +
    					     "WHERE " + table + ".scenario = '" + scenario + "'";				     
        return magiHhCount;
	}
    
    public String magiHhMemQuery(String table, String scenario) {		
    	String magiHhMem = "SELECT DISTINCT(" + table + ".ms_magi_hh_members) AS members " +
    					   "FROM " + table + " " +
    					   "WHERE " + table + ".scenario = '" + scenario + "'";				     
        return magiHhMem;
	}
    
    public String sumMagiHhIncomeQuery(HashMap<String, String> gd, String table, String scenario, String magiHhMembers) {
    	String id = idColumn(table);
    	
    	String earnedThreshold = gd.get("Earned_Threshold");
    	String unearnedThreshold = gd.get("Unearned_Threshold");
    	
    	String vbf = null;
    	
		if (Stream.of("pd_benefits").anyMatch(table::contains)) {
			vbf = "'pdBen'";
		} else {
			vbf = "'vbf'";
		}
    	
		String sumMagiHhIncome = "SELECT magiHhIncome(" + vbf + ", a." + id + " , a.mem_id, getMagiHhFpl(a.ms_magi_hh_size, IF( " +
									"SUM(IF(getIncome(ms_job_income) IS NULL, 0, getIncome(ms_job_income)) + " +
										"IF(ms_se_income IS NULL, 0, ms_se_income) +  " +
										"IF(getIncome(ms_fishing_farming_income) IS NULL, 0, getIncome(ms_fishing_farming_income))) < " + earnedThreshold + " AND " +
									"SUM(IF(getIncome(ms_ssb_income) IS NULL, 0, getIncome(ms_ssb_income)) + " +
										"IF(getIncome(ms_unemployment_income) IS NULL, 0, getIncome(ms_unemployment_income)) + " +
										"IF(getIncome(ms_retirement_income) IS NULL, 0, getIncome(ms_retirement_income)) + " +
										"IF(ms_cg_income IS NULL, 0, ms_cg_income) +  " +
										"IF(getIncome(ms_ii_income) IS NULL, 0, getIncome(ms_ii_income)) + " +
										"IF(getIncome(ms_rental_ri_income) IS NULL, 0, getIncome(ms_rental_ri_income)) + " +
										"IF(getIncome(ms_ii_income) IS NULL, 0, getIncome(ms_ii_income)) + " +
										"IF(getIncome(ms_alimony_income) IS NULL, 0, getIncome(ms_alimony_income)) + " +
										"IF(getIncome(ms_other_income) IS NULL, 0, getIncome(ms_other_income))) < " + unearnedThreshold + ", @sum := 0, @sum := " +
									"SUM(getIncome(ms_job_income) +  " +
										"IF(ms_se_income IS NULL, 0, ms_se_income) +  " +
										"getIncome(ms_fishing_farming_income) + " +
										"getIncome(ms_ssb_income) + " +
										"getIncome(ms_unemployment_income) + " +
										"getIncome(ms_retirement_income) + " +
										"IF(ms_cg_income IS NULL, 0, ms_cg_income) +  " +
										"getIncome(ms_ii_income) + " +
										"getIncome(ms_rental_ri_income) + " +
										"getIncome(ms_alimony_income) + " +
										"getIncome(ms_other_income))))) AS sum " +
								 "FROM " + schema + "." + table + " a " +
								 "WHERE a.scenario = '" + scenario + "' " +
								 "AND a.ms_magi_hh_index IN (" + magiHhMembers + ")";
        return sumMagiHhIncome;
	}
    
    public String updateMagiHhIncomeQuery(String table,  String scenario, String magiHhMembers, String magiHhIncome) {
    	String updateMagixHhIncome = "UPDATE " + table + " " +
								     "SET " + table + ".ms_magi_hh_income = '" + magiHhIncome + "' " +
								     "WHERE " + table + ".scenario = '"  + scenario + "' " +
								     "AND " + table + ".ms_magi_hh_members = '" + magiHhMembers + "'";
 		
    	return updateMagixHhIncome;
	}
    
    public String updateEligibilityIdQuery(String table,  String scenario, String eligibilityId) {
    	String updateEligibilityId = "UPDATE " + table + " " +
								     "SET " + table + ".ref_id = " + eligibilityId + " " +
								     "WHERE " + table + ".scenario = '"  + scenario;
 		
    	return updateEligibilityId;
	}
    
    public String updateRefIdQuery(String table,  String scenario, String refId) {
    	String updateRefId = "UPDATE " + table + " " +
							 "SET " + table + ".ref_id = " + refId + " " +
							 "WHERE " + table + ".scenario = '"  + scenario;
 		
    	return updateRefId;
	}
    
    public String evpdColumns(String id) {
    	String columns = id + ", " +
    					 "scenario, " +
    					 "portal, " +
    					 "role, " +
    					 "app_type, " +
    					 "mem_id, " +
    					 "ms_fn, " +
    					 "ms_mn, " +
    					 "ms_ln, " +
    					 "ms_suffix, " +
    					 "ms_age, " +
    					 "ms_zip_code, " +
    					 "ms_applying_for_cov, " +
    					 "spoken_lang, " +
    					 "written_lang, " +
    					 "who_is_applying, " +
    					 "fa_reqd, " +
    					 "ms_count, " +
    					 "tax_hh_id, " +
    					 "tax_hh_applying, " +
    					 "tax_hh_married, " +
    					 "tax_hh_filing_jointly, " +
    					 "tax_hh_spouse, " +
    					 "tax_hh_dep, " +
    					 "ms_relation, " +
    					 "ms_gender, " +
    					 "ms_ssn, " +
    					 "ms_imm_status, " +
    					 "ms_ethnicity, " +
    					 "ms_race, " +
    					 "not_living_with_hoh, " +
    					 "ms_lives_in_ma, " +
    					 "ms_temp_outside_ma, " +
    					 "ms_intend_reside_ma, " +
    					 "ms_disabled, " +
    					 "ms_aian, " +
    					 "ms_parent_caretaker," +
    					 "ms_pregnant, " +
    					 "pregnant_baby_count, " +
    					 "ms_foster_care, " +
    					 "ms_bcc, " +
    					 "ms_hiv, " +
    					 "ms_reasonable_acc, " +
    					 "ms_prison, " +
    					 "ms_awaiting_trial, " +
    					 "ms_job_income, " +
    					 "ms_se_income, " +
    					 "ms_fishing_farming_income, " +
    					 "ms_ssb_income, " +
    					 "ms_unemployment_income, " +
    					 "ms_retirement_income, " +
    					 "ms_cg_income, " +
    					 "ms_ii_income, " +
    					 "ms_rental_ri_income, " +
    					 "ms_alimony_income, " +
    					 "ms_other_income, " +
    					 "ms_employer_name, " +
    					 "ms_hrs_weekly, " +
    					 "ms_sheltered_attestation, " +
    					 "ms_educator_deduction_yearly, " +
    					 "ms_business_expenses_ded, " +
    					 "ms_health_savings_ded, " +
    					 "ms_job_change_ded, " +
    					 "ms_self_emp_tax_ded, " +
    					 "ms_contributed_self_emp_ded, " +
    					 "ms_self_emp_health_ins_ded, " +
    					 "ms_penalty_withdraw_ded, " +
    					 "ms_alimony_paid_ded, " +
    					 "ms_ind_retirement_amt_ded, " +
    					 "ms_student_loan_ded, " +
    					 "ms_high_school_education_ded, " +
    					 "ms_dom_prod_ded, " +
    					 "ms_other_ded, " +
    					 "ms_alt_expected_yearly_income, " +
    					 "enrolled_in_hi, " +
    					 "offered_hi, " +
    					 "ms_esi, " + 
    					 "ms_current_job, " +
    					 "ms_covered_in_hoh_esi, " +
    					 "esi_coverage_affordable, " +
    					 "esi_premium_amount, " +
    					 "ms_cobra, " +
    					 "ms_covered_in_hoh_cobra, " +
    					 "cobra_ms_coverage_affordable, " +
    					 "cobra_premium_amount, " +
    					 "ms_retiree_hp, " +
    					 "ms_covered_in_hoh_rhp, " +
    					 "rhp_ms_coverage_affordable, " +
    					 "rhp_premium_amount, " +
    					 "ms_va_hp, " +
    					 "ms_with_medicaid, " +
    					 "ms_with_medicare, " +
    					 "ms_with_peace_corps, " +
    					 "ms_with_tricare, " +
    					 "ms_with_va_hp, " +
    					 "ms_with_other, " +
    					 "ms_with_ncp_rfi, " +
    					 "hoh_apply_for_vote, " +
    					 "ms_tax_hh_size, " +
    					 "ms_tax_hh_index, " +
    					 "ms_tax_hh_mem_index, " +
    					 "ms_tax_hh_income, " +
    					 "ms_tax_fpl, " +
    					 "ms_tax_hh_pe, " +
    					 "ms_magi_hh_size, " +
    					 "ms_magi_hh_index, " +
    					 "ms_magi_hh_members, " +
    					 "ms_magi_hh_income, " +    					 
    					 "ms_magi_fpl, " +   		
    					 "ms_aid_cat, " +
    					 "ms_program_determination, " +
    					 "rfi_ind, " +
    					 "total_pbfg_group, " +
    					 "pbfg_monthly_premium, " +
    					 "hub_req_resp_logic_required, " +
						 "user_ref_id, " +
						 "elg_id";
 		
    	return columns;
	}
    
    public String enrollmentsColumns(String id) {
    	String columns = id + ", " +
    					 "scenario, " +
    					 "seq_ind, " +
    					 "portal, " +
    					 "role, " +
    					 "mem_id, " +
    					 "variant, " +
    					 "subscriber, " +
    					 "enrolled_in_plans, " +
    					 "transaction_type, " +
    					 "maintainence_type_code, " +
    					 "maintainence_reason_code, " +
    					 "lose_hi_coverage, " +
    					 "not_paying_premiums, " +
    					 "health_insurance, " +
    					 "gain_a_dependent, " +
    					 "recently_married, " +
    					 "birth_in_household, " +
    					 "foster_care, " +
    					 "lawfully_present_immigrant, " +
    					 "move_to_mass, " +
    					 "recently_released_from_prison, " +
    					 "victim_dom_abuse_aban";
 		
    	return columns;
	}
    
    public String initialPrelimColumns(String id) {
    	String columns = id + ", " +
						"scenario, " +
						"mem_id, " +
						"renewal_status, " +
						"rrv_ssa_disability, " +
						"rrv_ssa_death, " +
						"rrv_ssa_title_ii_income, " +
						"rrv_irs_income, " +
						"rrv_irs_ssb_income, " +
						"dor_response, " +
						"rrv_mec";
 		
    	return columns;
	}
    
    public String pdBenefitQuery(String table){
    	String pdBenefitQuery = "";
		
		pdBenefitQuery = "SELECT * " +
						 "FROM (SELECT @vbfId := a.pd_benefits_id AS pd_benefits_id, ";
							
		if(table.equalsIgnoreCase("pd_benefits")){
			pdBenefitQuery = pdBenefitQuery + "CONCAT('Scenario_', a.pd_benefits_id) AS scenario, ";   
			
		}else if(table.equalsIgnoreCase("pd_benefits_critical")){
			pdBenefitQuery = pdBenefitQuery + "CONCAT('Scenario_', a.id) AS scenario, ";
			
		}
			
			pdBenefitQuery = pdBenefitQuery + "ELT(FLOOR(RAND() * 2) + 1, 'A', 'I') AS portal, " +
											"NULL AS role, " +
											"NULL AS app_type, " +
											"@memId := 'M1' AS mem_id, " +
											"cvbfProcedure(@pdBenId := pd_benefits_id, '', 'pdBenFirstName') AS ms_fn, " +
											"NULL AS ms_mn, " +
											"cvbfProcedure(@pdBenId := a.pd_benefits_id, '', 'pdBenLastName') AS ms_ln, " +
											"NULL AS ms_suffix, " +
											"cvbfProcedure(@pdBenId, '', 'pdBenAge') AS ms_age, " +
											"NULL AS ms_zip_code, " +
											"NULL AS ms_applying_for_cov, " +
											"ELT(FLOOR(RAND() * 2) + 1, 'English', 'Spanish') AS spoken_lang, " +
											"ELT(FLOOR(RAND() * 2) + 1, 'English', 'Spanish') AS written_lang, " +
											"IF(a.parent_caretaker = 'Y', 'SELF_FAMILY', 'SELF') AS who_is_applying, " +
											"'TRUE' AS fa_reqd, " +
											"@mCount := IF(a.parent_caretaker = 'Y', 2, 1) AS ms_count, ";
		
		if(table.equalsIgnoreCase("pd_benefits")){
			pdBenefitQuery = pdBenefitQuery + "a.pd_benefits_id AS tax_hh_id, ";                                                          
		}else if(table.equalsIgnoreCase("pd_benefits_critical")){
			pdBenefitQuery = pdBenefitQuery + "a.id AS tax_hh_id, ";
		}
		
		pdBenefitQuery = pdBenefitQuery + "'TRUE' AS tax_hh_applying, " + 
		
											"'FALSE' AS tax_hh_married, " +
											"NULL AS tax_hh_filing_jointly, " +
											"NULL AS tax_hh_spouse, " +
											"IF(a.parent_caretaker = 'Y', 'M2', NULL) AS tax_hh_dep, " +
											"IF(a.parent_caretaker = 'Y', 'M2:CHD', NULL) AS ms_relation, " +
											"cvbfProcedure(@pdBenId, '', 'pdBenGender') AS ms_gender, " +
											"NULL AS ms_ssn, " +
											"cvbfProcedure(@pdBenId, '', 'pdBenImmStatus') AS ms_imm_status, " +
											"NULL AS ms_ethnicity, " +
											"NULL AS ms_race, " +
											"NULL AS not_living_with_hoh, " +
											"NULL AS ms_lives_in_ma, " +
											"NULL AS ms_temp_outside_ma, " +
											"NULL AS ms_intend_reside_ma, " +
											"cvbfProcedure(@pdBenId, '', 'pdBenDisabled') AS ms_disabled, " +
											"NULL AS ms_aian, " +
											"cvbfProcedure(@pdBenId, '', 'pdBenParentCaretaker') AS ms_parent_caretaker, " +
											"cvbfProcedure(@pdBenId, '', 'pdBenPregnant') AS ms_pregnant, " +
											"@bCount := cvbfProcedure(@pdBenId, '', 'pdBenPregnantBabyCount') AS pregnant_baby_count, " +
											"cvbfProcedure(@pdBenId, '', 'pdBenFosterCare') AS ms_foster_care, " +
											"cvbfProcedure(@pdBenId, '', 'pdBenBCC') AS ms_bcc, " +
											"cvbfProcedure(@pdBenId, '', 'pdBenHIV') AS ms_hiv, " +
											"NULL AS ms_reasonable_acc, " +
											"NULL AS ms_prison, " +
											"NULL AS ms_awaiting_trial, " +
											"IF(saIncomeSource('earned') = 'JB', CONCAT(@saEarnedIncome := saIncome('pdBen', 'hoh'), 'YR'), NULL) AS ms_job_income, " +
											"IF(@saEarnedIncomeSource = 'SE', @saEarnedIncome := saIncome('pdBen', 'hoh'), NULL) AS ms_se_income, " +
											"IF(@saEarnedIncomeSource = 'FF', CONCAT(@saEarnedIncome := saIncome('pdBen', 'hoh'), 'YR'), NULL) AS ms_fishing_farming_income, " +
									        "NULL AS ms_ssb_income, " +
											"NULL AS ms_unemployment_income, " +
											"NULL AS ms_retirement_income, " +
											"NULL AS ms_cg_income, " +
											"NULL AS ms_ii_income, " +
											"NULL AS ms_rental_ri_income, " +
											"NULL AS ms_alimony_income, " +
											"NULL AS ms_other_income, " +
											"NULL AS ms_employer_name, " +
											"NULL AS ms_hrs_weekly, " +
											"NULL AS ms_sheltered_attestation, " +
											"NULL AS ms_educator_deduction_yearly, " +
											"NULL AS ms_business_expenses_ded, " +
											"NUll AS ms_health_savings_ded, " +
											"NULL AS ms_job_change_ded, " +
											"NULL AS ms_self_emp_tax_ded, " +
											"NULL AS ms_contributed_self_emp_ded, " +
											"NULL AS ms_self_emp_health_ins_ded, " +
											"NULL AS ms_penalty_withdraw_ded, " +
											"NULL AS ms_alimony_paid_ded, " +
											"NULL AS ms_ind_retirement_amt_ded, " +
											"NULL AS ms_student_loan_ded, " +
											"NULL AS ms_high_school_education_ded, " +
											"NULL AS ms_dom_prod_ded, " +
											"NULL AS ms_other_ded, " +
											"IF((@altIncome := cvbfProcedure(@pdBenId, 'pdBen', 'altIncomeProcedure')) = 'none', NULL, @altIncome) AS ms_alt_expected_yearly_income, " +
					    					"'FALSE' AS enrolled_in_hi, " +
					    					"'FALSE' AS offered_hi, " +
											"NULL AS ms_esi, " +
					    					"NULL AS ms_current_job, " +
											"NULL AS ms_covered_in_hoh_esi, " +
											"NULL AS esi_coverage_affordable, " +
											"NULL AS esi_premium_amount, " +
											"NULL AS ms_cobra, " +
											"NULL AS ms_covered_in_hoh_cobra, " +
											"NULL AS cobra_ms_coverage_affordable, " +
											"NULL AS cobra_premium_amount, " +
											"NULL AS ms_retiree_hp, " +
											"NULL AS ms_covered_in_hoh_rhp, " +
											"NULL AS rhp_ms_coverage_affordable, " +
											"NULL AS rhp_premium_amount, " +
											"NULL AS ms_va_hp, " +
											"NULL AS ms_with_medicaid, " +
											"cvbfProcedure(@pdBenId, '', 'pdBenMedicare') AS ms_with_medicare, " +
											"NULL AS ms_with_peace_corps, " +
											"NULL AS ms_with_tricare, " +
											"NULL AS ms_with_va_hp, " +
											"NULL AS ms_with_other, " +
											"NULL AS ms_with_ncp_rfi, " +
											"NULL AS hoh_apply_for_vote, " +
											"IF(a.parent_caretaker = 'Y', 2, 1) AS ms_tax_hh_size, " +
											"1 AS ms_tax_hh_index, " +
											"1 AS ms_tax_hh_mem_index, " +
											"IF(@altIncome = 'none', @saEarnedIncome + @saUnearnedIncome, @altIncome) AS ms_tax_hh_income, " +
											"NULL AS ms_tax_fpl, " +
											"NULL AS ms_tax_hh_pe, " +
											"@magiHh := magiHhCalc(@mCount, IF(@bCount IS NULL, 0, @bCount)) AS ms_magi_hh_size, " +
											"'1' AS ms_magi_hh_index, " +
											"magiHhMembers(@magiHh) AS ms_magi_hh_members, " +
											"NULL AS ms_magi_hh_income, " +
											"NULL AS ms_magi_fpl, " +
											"NULL AS ms_aid_cat, " +
											"NULL AS ms_program_determination, " +
											"'Y' AS rfi_ind, " +
											"NULL AS total_pbfg_group, " +
											"NULL AS pbfg_monthly_premium, " +
											"NULL AS hub_req_resp_logic_required, " +
											"NULL AS user_ref_id, " +
										    "NULL AS elg_id " +
								"FROM " + schema + ".cvbf_" + table + " a " +
                                "UNION " +
                                "SELECT a.pd_benefits_id AS pd_benefits_id, ";
		
		if(table.equalsIgnoreCase("pd_benefits")){
			pdBenefitQuery = pdBenefitQuery + "CONCAT('Scenario_', a.pd_benefits_id) AS scenario, ";   
		}else if(table.equalsIgnoreCase("pd_benefits_critical")){
			pdBenefitQuery = pdBenefitQuery + "CONCAT('Scenario_', a.id) AS scenario, ";
		}
		
		pdBenefitQuery = pdBenefitQuery + "NULL AS portal, " +
											"NULL AS role, " +
											"NULL AS app_type, " +
											"'M2' AS mem_id, " +
											"'STR_O' AS ms_fn, " +
											"NULL AS ms_mn, " +
											"NULL AS ms_ln, " +
											"NULL AS ms_suffix, " +
											"(CASE " +
												"WHEN a.age = '>= 1 <= 18' THEN FLOOR(RAND() * (2 - 1 + 1) + 1) " +
												"WHEN a.age = '>= 1 <= 20' THEN FLOOR(RAND() * (2 - 1 + 1) + 1) " +
												"WHEN a.age = '>= 6 <= 17' THEN FLOOR(RAND() * (2 - 1 + 1) + 1) " +
												"WHEN a.age = '>= 15 <= 17' THEN FLOOR(RAND() * (2 - 1 + 1) + 1) " +
												"WHEN a.age = '18' THEN FLOOR(RAND() * (2 - 1 + 1) + 1) " +
												"WHEN a.age = '>= 18' THEN FLOOR(RAND() * (2 - 1 + 1) + 1) " +
												"WHEN a.age = '>= 18 <= 20' THEN FLOOR(RAND() * (2 - 1 + 1) + 1) " +
												"WHEN a.age = '>= 18 <= 25' THEN FLOOR(RAND() * (3 - 1 + 1) + 1) " +
												"WHEN a.age = '>= 19 <= 20' THEN FLOOR(RAND() * (2 - 1 + 1) + 1) " +
												"WHEN a.age = '>= 21' THEN FLOOR(RAND() * (5 - 3 + 1) + 3) " +
												"WHEN a.age = '>= 21 <= 25' THEN FLOOR(RAND() * (5 - 3 + 1) + 3) " +
												"WHEN a.age = '>= 21 <= 64' THEN FLOOR(RAND() * (5 - 3 + 1) + 3) " +
												"WHEN a.age = '>= 26 <= 64' THEN FLOOR(RAND() * (9 - 3 + 1) + 3) " +
												"WHEN a.age = '> 64' THEN FLOOR(RAND() * (18 - 16 + 1) + 16) " +
												"WHEN a.age = 'any' THEN FLOOR(RAND() * (3 - 1 + 1) + 1) " +
												"ELSE NULL " +
											"END) AS ms_age, " +
											"NULL AS ms_zip_code, " +
											"'TRUE' AS ms_applying_for_cov, " +
											"NULL AS spoken_lang, " +
											"NULL AS written_lang, " +
											"NULL AS who_is_applying, " +
											"NULL AS fa_reqd, " +
											"NULL AS ms_count, ";
		
		if(table.equalsIgnoreCase("pd_benefits")){
			pdBenefitQuery = pdBenefitQuery + "a.pd_benefits_id AS tax_hh_id, ";                                                          
		}else if(table.equalsIgnoreCase("pd_benefits_critical")){
			pdBenefitQuery = pdBenefitQuery + "a.id AS tax_hh_id, ";
		}
		
		pdBenefitQuery = pdBenefitQuery + "NULL AS tax_hh_applying, " + 
											"NULL AS tax_hh_married, " +
											"NULL AS tax_hh_filing_jointly, " +
											"NULL AS tax_hh_spouse, " +
											"NULL AS tax_hh_dep, " +
											"'M1:PRT' AS ms_relation, " +
											"ELT(FLOOR(RAND() * 2) + 1, 'F', 'M') AS ms_gender, " +
											"NULL AS ms_ssn, " +
											"'CIT' AS ms_imm_status, " +
											"NULL AS ms_ethnicity, " +
											"NULL AS ms_race, " +
											"NULL AS not_living_with_hoh, " +
											"NULL AS ms_lives_in_ma, " +
											"NULL AS ms_temp_outside_ma, " +
											"NULL AS ms_intend_reside_ma, " +
											"NULL AS ms_disabled, " +
											"NULL AS ms_aian, " +
											"NULL AS ms_parent_caretaker, " +
											"NULL AS ms_pregnant, " +
											"NULL AS pregnant_baby_count, " +
											"NULL AS ms_foster_care, " +
											"NULL AS ms_bcc, " +
											"NULL AS ms_hiv, " +
											"NULL AS ms_reasonable_acc, " +
											"NULL AS ms_prison, " +
											"NULL AS ms_awaiting_trial, " +
											"'0YR' AS ms_job_income, " +
											"NULL AS ms_employer_name, " +
											"NULL AS ms_hrs_weekly, " +
											"NULL AS ms_sheltered_attestation, " +
											"NULL AS ms_se_income, " +
											"NULL AS ms_ssb_income, " +
											"NULL AS ms_unemployment_income, " +
											"NULL AS ms_retirement_income, " +
											"NULL AS ms_cg_income, " +
											"NULL AS ms_ii_income, " +
											"NULL AS ms_rental_ri_income, " +
											"NULL AS ms_fishing_farming_income, " +
											"NULL AS ms_alimony_income, " +
											"NULL AS ms_other_income, " +
											"NULL AS ms_educator_deduction_yearly, " +
											"NULL AS ms_business_expenses_ded, " +
											"NUll AS ms_health_savings_ded, " +
											"NULL AS ms_job_change_ded, " +
											"NULL AS ms_self_emp_tax_ded, " +
											"NULL AS ms_contributed_self_emp_ded, " +
											"NULL AS ms_self_emp_health_ins_ded, " +
											"NULL AS ms_penalty_withdraw_ded, " +
											"NULL AS ms_alimony_paid_ded, " +
											"NULL AS ms_ind_retirement_amt_ded, " +
											"NULL AS ms_student_loan_ded, " +
											"NULL AS ms_high_school_education_ded, " +
											"NULL AS ms_dom_prod_ded, " +
											"NULL AS ms_other_ded, " +
											"NULL AS ms_alt_expected_yearly_income, " +
					    					"'FALSE' AS enrolled_in_hi, " +
					    					"'FALSE' AS offered_hi, " +
											"NULL AS ms_esi, " +
											"NULL AS ms_current_job, " +
											"NULL AS ms_covered_in_hoh_esi, " +
											"NULL AS esi_coverage_affordable, " +
											"NULL AS esi_premium_amount, " +
											"NULL AS ms_cobra, " +
											"NULL AS ms_covered_in_hoh_cobra, " +
											"NULL AS cobra_ms_coverage_affordable, " +
											"NULL AS cobra_premium_amount, " +
											"NULL AS ms_retiree_hp, " +
											"NULL AS ms_covered_in_hoh_rhp, " +
											"NULL AS rhp_ms_coverage_affordable, " +
											"NULL AS rhp_premium_amount, " +
											"NULL AS ms_va_hp, " +
											"NULL AS ms_with_medicaid, " +
											"NULL AS ms_with_medicare, " +
											"NULL AS ms_with_peace_corps, " +
											"NULL AS ms_with_tricare, " +
											"NULL AS ms_with_va_hp, " +
											"NULL AS ms_with_other, " +
											"NULL AS ms_with_ncp_rfi, " +
											"NULL AS hoh_apply_for_vote, " +
											"IF(a.parent_caretaker = 'Y', 2, 1) AS ms_tax_hh_size, " +
											"1 AS ms_tax_hh_index, " +
											"2 AS ms_tax_hh_mem_index, " +
											"0 AS ms_tax_hh_income, " +
											"NULL AS ms_tax_fpl, " +
											"NULL AS ms_tax_hh_pe, " +
											"@magiHh := magiHhCalc( " +
												"IF(a.parent_caretaker = 'Y', 2, 1), " +
												"IF(a.pregnant = 'Y', 1, 0) " +
											") AS ms_magi_hh_size, " +
											"2 AS ms_magi_hh_index, " +
											"magiHhMembers(@magiHh) AS ms_magi_hh_members, " +
											"0 AS ms_magi_hh_income, " +
											"NULL AS ms_magi_fpl, " +
											"NULL AS ms_aid_cat, " +
											"NULL AS ms_program_determination, " +
											"'Y' AS rfi_ind, " +
											"NULL AS total_pbfg_group, " +
											"NULL AS pbfg_monthly_premium, " +
											"NULL AS hub_req_resp_logic_required, " +
											"NULL AS user_ref_id, " +
										    "NULL AS elg_id " +
								"FROM " + schema + ".cvbf_" + table + " a " +
		                        "WHERE a.parent_caretaker = 'Y' " +
		                 ") results " +
		                 "ORDER BY tax_hh_id, ms_magi_hh_index";
    	
    	return pdBenefitQuery;
    }
    
    public String hhCompQuery(){
    	String hhCompQuery = "";
    	
    	hhCompQuery = "SELECT @vbfId := a.hh_comp_id AS hh_comp_id, " +
				        "CONCAT('Scenario_', a.hh_comp_id) AS scenario, " +
				    	"IF(a.member_id = 'M1', ELT(FLOOR(RAND() * 2) + 1, 'A', 'I'), NULL) AS portal, " +
				    	"NULL AS role, " +
				    	"NULL AS app_type, " +
				    	"@memId := a.member_id AS mem_id, " +
				    	"NULL AS ms_fn, " +
				    	"NULL AS ms_mn, " +
				    	"lastName(@id = idRandomizer()) AS ms_ln, " +
				    	"NULL AS ms_suffix, " +
				    	"@memAge := generateAge(a.hh_comp_id, a.age, a.relationship, a.pregnant) AS ms_age, " +
				    	"NULL AS ms_zip_code, " +
				    	"cvbfProcedure(@hhCompId := a.hh_comp_id, a.member_id, 'hhCompAppForCov') AS ms_applying_for_cov, " +
				    	"IF(a.member_id = 'M1', ELT(FLOOR(RAND() * 2) + 1, 'English', 'Spanish'), NULL) AS spoken_lang, " +
				    	"IF(a.member_id = 'M1', ELT(FLOOR(RAND() * 2) + 1, 'English', 'Spanish'), NULL) AS written_lang, " +
				    	"IF(a.member_id = 'M1', cvbfProcedure(@hhCompId, a.member_id, 'hhCompWhoIsApplying'), NULL) AS who_is_applying, " +
				    	"IF(a.member_id = 'M1', 'TRUE', NULL) AS fa_reqd, " +
				    	"IF(a.member_id = 'M1', cvbfProcedure(@hh_comp_id, a.member_id, 'hhCompMemCount'), NULL) AS ms_count, " +
				    	"@hhCompId AS tax_hh_id,     " +
				    	"cvbfProcedure(@hhCompId, a.member_id, 'hhCompTaxHhApplying') AS tax_hh_applying, " +
				    	"cvbfProcedure(@hhCompId, a.member_id, 'hhCompTaxHhMarried') AS tax_hh_married, " +
				    	"cvbfProcedure(@hhCompId, a.member_id, 'hhCompTaxHhFilingJointly') AS tax_hh_filing_jointly, " +
				    	"cvbfProcedure(@hhCompId, a.member_id, 'hhCompTaxHhSpouse') AS tax_hh_spouse, " +
				    	"cvbfProcedure(@hhCompId, a.member_id, 'hhCompTaxHhDep') AS tax_hh_dep, " +
				    	"cvbfProcedure(@hhCompId, a.member_id, 'hhCompRelationship') AS ms_relation, " +
				    	"IF(a.pregnant = 'Y', 'F', ELT(FLOOR(RAND() * 2) + 1, 'F', 'M')) AS ms_gender,     " +
				    	"NULL AS ms_ssn, " +
				    	"ELT(FLOOR(RAND() * 6) + 1, 'CIT', 'QLP', 'QAB', 'ILP', 'NQP', 'UND') AS ms_imm_status, " +
				    	"NULL AS ms_ethnicity, " +
				    	"NULL AS ms_race, " +
				    	"cvbfProcedure(@hhCompId, a.member_id, 'hhCompNotLivingWithHoh') AS not_living_with_hoh, " +
				    	"NULL AS ms_lives_in_ma, " +
				    	"NULL AS ms_temp_outside_ma, " +
				    	"NULL AS ms_intend_reside_ma, " +
				    	"ELT(FLOOR(RAND() * 2) + 1, 'TRUE', 'FALSE') AS ms_disabled, " +
				    	"NULL AS ms_aian, " +
				    	"IF(a.parent_caretaker = 'Y', 'TRUE', 'FALSE') AS ms_parent_caretaker, " +
				    	"IF(a.pregnant = 'Y', 'TRUE', 'FALSE') AS ms_pregnant, " +
				    	"a.expected_number_of_children AS pregnant_baby_count,     " +
				    	"IF(@memAge BETWEEN 18 AND 25, ELT(FLOOR(RAND() * 2) + 1, 'TRUE', 'FALSE'), 'FALSE') AS ms_foster_care,     " +
				    	"ELT(FLOOR(RAND() * 2) + 1, 'TRUE', 'FALSE') AS ms_bcc, " +
				    	"ELT(FLOOR(RAND() * 2) + 1, 'TRUE', 'FALSE') AS ms_hiv, " +
				    	"NULL AS ms_reasonable_acc, " +
				    	"NULL AS ms_prison, " +
				    	"NULL AS ms_awaiting_trial, " +
				    	"IF(saIncomeSource('earned') = 'JB', CONCAT(@saEarnedIncome := saIncome('hhComp', 'earned'), 'YR'), NULL) AS ms_job_income, " +
				    	"IF(@saEarnedIncomeSource = 'SE', @saEarnedIncome := saIncome('hhComp', 'earned'), NULL) AS ms_se_income, " +
				    	"IF(@saEarnedIncomeSource = 'FF', CONCAT(@saEarnedIncome := saIncome('hhComp', 'earned'), 'YR'), NULL) AS ms_fishing_farming_income, " +
				    	"NULL AS ms_ssb_income, " +
				    	"IF(saIncomeSource('unearned') = 'UE', CONCAT(IF(@saUnearnedIncome = 0, NULL, @saUnearnedIncome), 'YR'), NULL) AS ms_unemployment_income, " +
				    	"IF(@saUnearnedIncomeSource = 'RP', CONCAT(@saUnearnedIncome := saIncome('hhComp', 'unearned'), 'YR'), NULL) AS ms_retirement_income, " +
				    	"IF(@saUnearnedIncomeSource = 'CG', @saUnearnedIncome := saIncome('hhComp', 'unearned'), NULL) AS ms_cg_income, " +
				    	"NULL AS ms_ii_income, " +
				    	"IF(@saUnearnedIncomeSource = 'RR', CONCAT(@saUnearnedIncome := saIncome('hhComp', 'unearned'), 'YR'), NULL) AS ms_rental_ri_income, " +
				    	"IF(@saUnearnedIncomeSource = 'AR', CONCAT(@saUnearnedIncome := saIncome('hhComp', 'unearned'), 'YR'), NULL) AS ms_alimony_income, " +
				    	"IF(@saUnearnedIncomeSource = 'OI', CONCAT(@saUnearnedIncome := saIncome('hhComp', 'unearned'), 'YR'), NULL) AS ms_other_income, " +
				    	"NULL AS ms_employer_name, " +
				    	"NULL AS ms_hrs_weekly, " +
				    	"NULL AS ms_sheltered_attestation, " +
				    	"NULL AS ms_educator_deduction_yearly, " +
				    	"NULL AS ms_business_expenses_ded, " +
				    	"NUll AS ms_health_savings_ded, " +
				    	"NULL AS ms_job_change_ded, " +
				    	"NULL AS ms_self_emp_tax_ded, " +
				    	"NULL AS ms_contributed_self_emp_ded, " +
				    	"NULL AS ms_self_emp_health_ins_ded, " +
				    	"NULL AS ms_penalty_withdraw_ded, " +
				    	"NULL AS ms_alimony_paid_ded, " +
				    	"NULL AS ms_ind_retirement_amt_ded, " +
				    	"NULL AS ms_student_loan_ded, " +
				    	"NULL AS ms_high_school_education_ded, " +
				    	"NULL AS ms_dom_prod_ded, " +
				    	"NULL AS ms_other_ded, " +
				    	"NULL AS ms_alt_expected_yearly_income, " +
    					"'FALSE' AS enrolled_in_hi, " +
    					"'FALSE' AS offered_hi, " +
				    	"NULL AS ms_esi, " +
				    	"NULL AS ms_current_job, " +
				    	"NULL AS ms_covered_in_hoh_esi, " +
				    	"NULL AS esi_coverage_affordable, " +
				    	"NULL AS esi_premium_amount, " +
				    	"NULL AS ms_cobra, " +
				    	"NULL AS ms_covered_in_hoh_cobra, " +
				    	"NULL AS cobra_ms_coverage_affordable, " +
				    	"NULL AS cobra_premium_amount, " +
				    	"NULL AS ms_retiree_hp, " +
				    	"NULL AS ms_covered_in_hoh_rhp, " +
				    	"NULL AS rhp_ms_coverage_affordable, " +
				    	"NULL AS rhp_premium_amount, " +
				    	"NULL AS ms_va_hp, " +
				    	"NULL AS ms_with_medicaid, " +
				    	"ELT(FLOOR(RAND() * 2) + 1, 'TRUE', 'FALSE') AS ms_with_medicare, " +
				    	"NULL AS ms_with_peace_corps, " +
				    	"NULL AS ms_with_tricare, " +
				    	"NULL AS ms_with_va_hp, " +
				    	"NULL AS ms_with_other, " +
				    	"NULL AS ms_with_ncp_rfi, " +
				    	"NULL AS hoh_apply_for_vote, " +
				    	"cvbfProcedure(@hhCompId, '', 'hhCompTaxHhSize') AS ms_tax_hh_size, " +
				    	"cvbfProcedure(@hhCompId, '', 'hhCompTaxHhIndex') AS ms_tax_hh_index, " +
				    	"cvbfProcedure(@hhCompId, '', 'hhCompTaxHhMemIndex') AS ms_tax_hh_mem_index, " +
				    	"@saEarnedIncome + @saUnearnedIncome AS ms_tax_hh_income, " +
				    	"NULL AS ms_tax_fpl, " +
				    	"NULL AS ms_tax_hh_pe, " +
				    	"cvbfProcedure(@hhCompId, '', 'hhCompMagiHhSize') AS ms_magi_hh_size, " +
				    	"cvbfProcedure(@hhCompId, '', 'hhCompMagiHhIndex') AS ms_magi_hh_index, " +
				    	"cvbfProcedure(@hhCompId, '', 'hhCompMagiHhMembers') AS ms_magi_hh_members, " +
				    	"NULL AS ms_magi_hh_income, " +
				    	"NULL AS ms_magi_fpl, " +
				    	"NULL AS ms_aid_cat, " +
				   		"NULL AS ms_program_determination, " +
				   		"'Y' AS rfi_ind, " +
				    	"NULL AS total_pbfg_group, " +
				    	"NULL AS pbfg_monthly_premium, " +
				    	"NULL AS hub_req_resp_logic_required, " +
				    	"NULL AS user_ref_id, " +
				    	"NULL AS elg_id " +
				      "FROM " + schema + ".cvbf_hh_comp a";

    	return hhCompQuery;
    }
    
    public String vbfQuery(String table, String id){
    	String vbfQuery = "";
    	
    	vbfQuery = "SELECT @vbfId := a." + id + " AS " + id + ", " + 
					    	  "CONCAT('Scenario_', a." + id + ") AS scenario, " +
					    	  "IF(a.member_id = 'M1', ELT(FLOOR(RAND() * 2) + 1, 'A', 'I'), NULL) AS portal, " +
					    	  "NULL AS role, " +
					    	  "NULL AS app_type, " +
					    	  "@memId := a.member_id AS mem_id, ";
					      	
  		if(table.equalsIgnoreCase("cca_renewals")){
  			vbfQuery = vbfQuery + "IF(a.mmis_returns_03 = 'Y', 'MOE', cvbfProcedure(@pdBenId := pd_benefits_id, '', 'pdBenFirstName')) AS ms_fn, ";
  		}else{
  			vbfQuery = vbfQuery + "cvbfProcedure(@pdBenId := pd_benefits_id, '', 'pdBenFirstName') AS ms_fn, ";
  		}					    	
  					    	
      	vbfQuery = vbfQuery + "NULL AS ms_mn, " + 
	    			  		  "cvbfProcedure(@pdBenId := a.pd_benefits_id, '', 'pdBenLastName') AS ms_ln, " + 
					    	  "NULL AS ms_suffix, " +
					    	  "cvbfProcedure(@pdBenId, '', 'pdBenAge') AS ms_age, " +
					    	  "NULL AS ms_zip_code, " +
					    	  "cvbfProcedure(@hhCompId := a.hh_comp_id, '', 'hhCompAppForCov') AS ms_applying_for_cov, " +
					    	  "IF(@memId = 'M1', ELT(FLOOR(RAND() * 2) + 1, 'English', 'Spanish'), NULL) AS spoken_lang, " +
					    	  "IF(@memId = 'M1', ELT(FLOOR(RAND() * 2) + 1, 'English', 'Spanish'), NULL) AS written_lang,	" +
					    	  "cvbfProcedure(@hhCompId, a.member_id, 'hhCompWhoIsApplying') AS who_is_applying, " + 
					    	  "IF(@memId = 'M1', 'TRUE', NULL) AS fa_reqd, " +
					    	  "@mCount := cvbfProcedure(@hhCompId, a.member_id, 'hhCompMemCount') AS ms_count, " +
					    	  "@hhCompId AS tax_hh_id, " + 
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompTaxHhApplying') AS tax_hh_applying, " +
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompTaxHhMarried') AS tax_hh_married, " +
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompTaxHhFilingJointly') AS tax_hh_filing_jointly, " +
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompTaxHhSpouse') AS tax_hh_spouse, " +
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompTaxHhDep') AS tax_hh_dep, " +
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompRelationship') AS ms_relation, " +
					    	  "cvbfProcedure(@pdId, '', 'pdBenGender') AS ms_gender, ";
    	
		if(table.equalsIgnoreCase("cca_renewals")){
			vbfQuery = vbfQuery + "IF(a.ssn = 'Y', NULL, 'NO_JA') AS ms_ssn, ";
		}else{
			vbfQuery = vbfQuery + "NULL AS ms_ssn, ";
		}					    	
					    	
    	vbfQuery = vbfQuery + "cvbfProcedure(@pdBenId, '', 'pdBenImmStatus') AS ms_imm_status, " +
					    	  "NULL AS ms_ethnicity, " +
					    	  "NULL AS ms_race, " +
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompNotLivingWithHoh') AS not_living_with_hoh, " +
					    	  "NULL AS ms_lives_in_ma, " +
					    	  "NULL AS ms_temp_outside_ma, " + 
					    	  "NULL AS ms_intend_reside_ma, " +
					    	  "cvbfProcedure(@pdBenId, '', 'pdBenDisabled') AS ms_disabled, " + 
					    	  "NULL AS ms_aian, " +
					    	  "cvbfProcedure(@pdBenId, '', 'pdBenParentCaretaker') AS ms_parent_caretaker, " +
					    	  "cvbfProcedure(@pdBenId, '', 'pdBenPregnant') AS ms_pregnant, " + 
					    	  "@bCount := cvbfProcedure(@pdBenId, '', 'pdBenPregnantBabyCount') AS pregnant_baby_count, " + 
					    	  "cvbfProcedure(@pdBenId, '', 'pdBenFosterCare') AS ms_foster_care, " +
					    	  "cvbfProcedure(@pdBenId, '', 'pdBenBCC') AS ms_bcc, " +
					    	  "cvbfProcedure(@pdBenId, '', 'pdBenHIV') AS ms_hiv, " +
					    	  "NULL AS ms_reasonable_acc, " +
					    	  "NULL AS ms_prison, " +
					    	  "NULL AS ms_awaiting_trial, " +
					    	  "IF(a.income_source = 'N', '0YR', IF(saIncomeSource('earned') = 'JB', IF((@saEarnedIncome := saIncome('vbf', '')) = 'ERROR', @saEarnedIncome, CONCAT(@saEarnedIncome, 'YR')), NULL)) AS ms_job_income, " +
					    	  "IF(a.income_source = 'N', NULL, IF(@saEarnedIncomeSource = 'SE', IF((@saEarnedIncome := saIncome('vbf', '')) = 'ERROR', @saEarnedIncome, @saEarnedIncome), NULL)) AS ms_se_income, " +
					    	  "IF(a.income_source = 'N', NULL, IF(@saEarnedIncomeSource = 'FF', IF((@saEarnedIncome := saIncome('vbf', '')) = 'ERROR', @saEarnedIncome, CONCAT(@saEarnedIncome, 'YR')), NULL)) AS ms_fishing_farming_income, " +
					    	  "NULL AS ms_ssb_income, " +
					    	  "NULL AS ms_unemployment_income, " +
					    	  "NULL AS ms_retirement_income, " +
					    	  "NULL AS ms_cg_income, " +
					    	  "NULL AS ms_ii_income, " +
					    	  "NULL AS ms_rental_ri_income, " +
					    	  "NULL AS ms_alimony_income, " +
					    	  "NULL AS ms_other_income, " +
						      "NULL AS ms_employer_name, " +
						      "NULL AS ms_hrs_weekly, " +
						      "NULL AS ms_sheltered_attestation, " +
					    	  "NULL AS ms_educator_deduction_yearly, " + 
					    	  "NULL AS ms_business_expenses_ded, " +
							  "NUll AS ms_health_savings_ded, " +
							  "NULL AS ms_job_change_ded, " +
							  "NULL AS ms_self_emp_tax_ded, " +
							  "NULL AS ms_contributed_self_emp_ded, " +
							  "NULL AS ms_self_emp_health_ins_ded, " +
							  "NULL AS ms_penalty_withdraw_ded, " +
							  "NULL AS ms_alimony_paid_ded, " +
							  "NULL AS ms_ind_retirement_amt_ded, " +
							  "NULL AS ms_student_loan_ded, " +
							  "NULL AS ms_high_school_education_ded, " +
							  "NULL AS ms_dom_prod_ded, " +
							  "NULL AS ms_other_ded, " +
					    	  "IF(a.income_source = 'N', NULL, IF((@altIncome := cvbfProcedure(@pdBenId, '', 'altIncomeProcedure')) = 'none', NULL, @altIncome)) AS ms_alt_expected_yearly_income, " +
					    	  /*"NULL AS ms_alt_expected_yearly_income, " +*/
		    				  "'FALSE' AS enrolled_in_hi, " +
		    				  "'FALSE' AS offered_hi, " +
					    	  "NULL AS ms_esi, " + 
					    	  "NULL AS ms_current_job, " +
					    	  "NULL AS ms_covered_in_hoh_esi, " +
					    	  "NULL AS esi_coverage_affordable, " +
					    	  "NULL AS esi_premium_amount, " + 
					    	  "NULL AS ms_cobra, " +
					    	  "NULL AS ms_covered_in_hoh_cobra, " +
					    	  "NULL AS cobra_ms_coverage_affordable, " + 
					    	  "NULL AS cobra_premium_amount, " +
					    	  "NULL AS ms_retiree_hp, " +
					    	  "NULL AS ms_covered_in_hoh_rhp, " +
					    	  "NULL AS rhp_ms_coverage_affordable, " + 
					    	  "NULL AS rhp_premium_amount, " + 
					    	  "NULL AS ms_va_hp, " +
					    	  "NULL AS ms_with_medicaid, " + 
					    	  "cvbfProcedure(@pdBenId, '', 'pdBenMedicare') AS ms_with_medicare, " +
					    	  "NULL AS ms_with_peace_corps, " +
					    	  "NULL AS ms_with_tricare, " +
					    	  "NULL AS ms_with_va_hp, " +
					    	  "NULL AS ms_with_other, " +
					    	  "NULL AS ms_with_ncp_rfi, " +
					    	  "NULL AS hoh_apply_for_vote, " + 
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompTaxHhSize') AS ms_tax_hh_size, " +
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompTaxHhIndex') AS ms_tax_hh_index, " + 
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompTaxHhMemIndex') AS ms_tax_hh_mem_index, " +
					    	  "NULL AS ms_tax_hh_income, " + 
					    	  /*"IF(a.income_source = 'N', 0, IF(@altIncome = 'none', @saEarnedIncome + @saUnearnedIncome, @altIncome)) AS ms_tax_hh_income, " + */
					    	  /*"IF(a.income_source = 'N', 0, @saEarnedIncome + @saUnearnedIncome) AS ms_tax_hh_income, " +*/
					    	  "NULL AS ms_tax_fpl, " + 
					    	  "NULL AS ms_tax_hh_pe, " +
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompMagiHhSize') AS ms_magi_hh_size, " + 
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompMagiHhIndex') AS ms_magi_hh_index, " +
					    	  "cvbfProcedure(@hhCompId, '', 'hhCompMagiHhMembers') AS ms_magi_hh_members, " +
					    	  "NULL AS ms_magi_hh_income, " +
					    	  "NULL AS ms_magi_fpl, " +
					   		  "NULL AS ms_aid_cat, " + 
					   		  "NULL AS ms_program_determination, " +
					   		  "'Y' AS rfi_ind, " +
					   		  "NULL AS total_pbfg_group, " +
					   		  "NULL AS pbfg_monthly_premium, " +
					   		  "NULL AS hub_req_resp_logic_required, " +
					   		  "NULL AS user_ref_id, " +
						      "NULL AS elg_id " +
					     "FROM " + schema + ".cvbf_" + table + " a ";

    	return vbfQuery;
    }
    
    public String enrollmentQuery(String table, String id){
    	String enrollmentQuery = "";
    	
    	enrollmentQuery = "SELECT @vbfId := a." + id + " AS " + id + ", " +
    						"CONCAT('Scenario_', a." + id + ") AS scenario, " +
					    	"1 AS seq_ind, " +
					    	"IF(a.member_id = 'M1', 'A', NULL) AS portal, " +
					    	"NULL AS role, " +
					    	"@memId := a.member_id AS mem_id, " +
					    	"1 AS variant, " +
					    	"IF(cvbfProcedure(@hhCompId := a.hh_comp_id, '', 'hhCompTaxHhMemIndex') = 1, enrolled_in_plans, NULL) AS subscriber, " +
					    	"IF(cvbfProcedure(@hhCompId, '', 'hhCompTaxHhMemIndex') <> 1, enrolled_in_plans, NULL) AS enrolled_in_plans, " +
					    	"'ADD' AS transaction_type, " +
					    	"021 AS maintainence_type_code, " +
					    	"28 AS maintainence_reason_code, " +
					    	"IF(@memId = 'M1', 'FALSE', NULL) AS lose_hi_coverage, " +
					    	"'FALSE' AS not_paying_premiums, " +
					    	"'FALSE' AS health_insurance, " +
					    	"IF(@memId = 'M1', 'FALSE', NULL) AS gain_a_dependent, " +
					    	"'FALSE' AS recently_married, " +
					    	"'FALSE' AS birth_in_household, " +
					    	"'FALSE' AS foster_care, " +
					    	"IF(@memId = 'M1', 'FALSE', NULL) AS lawfully_present_immigrant, " +
					    	"IF(@memId = 'M1', 'FALSE', NULL) AS move_to_mass, " +
					    	"IF(@memId = 'M1', 'FALSE', NULL) AS recently_released_from_prison,  " +
					    	"IF(@memId = 'M1', 'TRUE', NULL) AS victim_dom_abuse_aban " +
					      "FROM " + schema + ".cvbf_" + table + " a";

    	return enrollmentQuery;
    }
    
    public String initialPrelimQuery(String table, String id, String scenario, int memInd){
    	String initialPrelimQuery = "";
    	
    	initialPrelimQuery = "SELECT @vbfId := a." + id + " AS " + id + ", " +
				    			"CONCAT('Scenario_', a." + id + ") AS scenario, " +
				    			"b.mem_id AS mem_id, " +
				    			"a.renewal_status AS renewal_status, " +
				    			"a.rrv_ssa_disability AS rrv_ssa_disability, " +
				    			"a.rrv_ssa_death AS rrv_ssa_death, " +
				    			"(CASE " +
			    					"WHEN a.rrv_ssa_title_ii_income LIKE '%ERROR%' THEN a.rrv_ssa_title_ii_income " +
			    				    "WHEN a.rrv_ssa_title_ii_income = 'N' THEN a.rrv_ssa_title_ii_income " +
			    					"ELSE CONCAT(a.rrv_ssa_title_ii_income, '.00') " +
			    				"END) AS rrv_ssa_title_ii_income, " +
				    			"IF(RIGHT(a.rrv_irs_income, 1) = '%',  " +
				    				"ROUND((SUM(getIncome(b.ms_job_income) +  " +
				    					"IF(b.ms_se_income IS NULL, 0, b.ms_se_income) +  " +
				    					"getIncome(b.ms_fishing_farming_income) + " +
				    					"getIncome(b.ms_ssb_income) + " +
				    					"getIncome(b.ms_unemployment_income) + " +
				    					"getIncome(b.ms_retirement_income) + " +
				    					"IF(b.ms_cg_income IS NULL, 0, b.ms_cg_income) +  " +
				    					"getIncome(b.ms_ii_income) + " +
				    					"getIncome(b.ms_rental_ri_income) + " +
				    					"getIncome(b.ms_alimony_income) + " +
				    					"getIncome(b.ms_other_income))) * (1 + (CONCAT('.', SUBSTRING_INDEX(a.rrv_irs_income, '%', 1 )))), 0), a.rrv_irs_income) AS rrv_irs_income, " +
		    					"(CASE " +
			    					"WHEN a.rrv_irs_ssb_income LIKE '%ERROR%' THEN a.rrv_irs_ssb_income " +
			    				    "WHEN a.rrv_irs_ssb_income = 'N' THEN a.rrv_irs_ssb_income " +
			    					"ELSE a.rrv_irs_ssb_income " +
			    				"END) AS rrv_irs_ssb_income, " +
			    				"(CASE " +
									"WHEN a.dor_response = 'N' THEN a.dor_response " +
									"WHEN a.dor_response = '> 133 <= 150' THEN (generateMagiHhIncome(@hhCompId := b.tax_hh_id, FLOOR(RAND() * (150 - 134 + 1) + 134))/4) " +
									"ELSE (a.dor_response/4) " +
								"END) AS dor_response, " +
		    					"a.rrv_mec AS rrv_mec " +
			    			"FROM " + schema + ".cvbf_" + table + "_initial_prelim a " +
			    			"INNER JOIN " + schema + "." + table + "_evpd b " +
			    			"ON a.id = b.id " +
			    			"WHERE b.scenario = '" + scenario + "' " +
			    			"AND b.ms_magi_hh_index = " + memInd;

    	return initialPrelimQuery;
    }
    
    public String evpdQuery(String table) {
    	String id = idColumn(table);
    	
    	String evpdColumns = evpdColumns(id);
    	
		String insert = "INSERT INTO " + table + "_evpd (" + evpdColumns + ") ";
		
		if(Stream.of("pd_benefits", "pd_benefits_critical").anyMatch(table::equalsIgnoreCase)){
			insert = insert + pdBenefitQuery(table);
		}else if(table.equalsIgnoreCase("hh_comp")){
			insert = insert + hhCompQuery();
		}else{
			insert = insert + vbfQuery(table, id);
		}
			
		return insert;
	}
    
    public String enrollmentQuery(String table) {
    	String id = idColumn(table);    	
    	String enrollmentColumns = enrollmentsColumns(id); 
    	
		String insert = "INSERT INTO " + table + "_shopping (" + enrollmentColumns + ") ";		
		insert = insert + enrollmentQuery(table, id);		
		
		return insert;
	}
    
    public String initialPrelimQuery(String table, String scenario, int memInd) {
    	String id = idColumn(table);
    	
    	String initialPrelimColumns = initialPrelimColumns(id);
    	
		String insert = "INSERT INTO " + table + "_initial_prelim (" + initialPrelimColumns + ") ";
		insert = insert + initialPrelimQuery(table, id, scenario, memInd);	
			
		return insert;
	}
    
    public String tempDataQuery(String table) {
    	String id = idColumn(table);
    	
    	String query = "INSERT INTO cvbf01.temp_data " +
						"(vbf_id, " +
						"pd_benefits_id, " +
						"hh_comp_id, " +
						"member_id, " +
						"magi_hh_members, " +
						"magi_hh_mem_index, " +
						"tax_hh_index, " +
						"tax_fpl, " +
						"income_source, " +
						"income) " +
					   "SELECT " + id + " AS vbf_id, " +
					    "@pdBenId := a.pd_benefits_id AS pd_benefits_id, " +
					    "@hhCompId := a.hh_comp_id AS hh_comp_id, " +
					   	"@memId := a.member_id AS member_id, " +
					    "cvbfProcedure(@hhCompId, '', 'hhCompMagiHhMembers') AS magi_hh_members, " +
					    "cvbfProcedure(@hhCompId, '', 'hhCompMagiHhMemIndex') AS magi_hh_mem_index, " +
					    "cvbfProcedure(@hhCompId, '', 'hhCompTaxHhIndex') AS tax_hh_index, " +
					    "cvbfProcedure(@pdBenId, '', 'pdBenTaxFpl') AS tax_fpl, " +
					   	"a.income_source AS income_source, " +
					   	"NULL AS income " +
					   "FROM cvbf01.cvbf_" + table + " a";
		
		return query;
	}

}