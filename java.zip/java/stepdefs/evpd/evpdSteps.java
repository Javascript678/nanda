package stepdefs.evpd;

import java.util.ArrayList;
import java.util.List;

import appdata.common.TempData;
import appdata.pa.PA_MemData;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import enums.PortalName;
import modules.evpd.AdditionalQuestionsModule;
import modules.evpd.FamilyAndHouseholdModule;
import modules.evpd.IncomeModule;
import modules.evpd.ReviewAndSignModule;
import modules.evpd.StartYourApplicationModule;
import pages.accountDashboard.AccountDashboardLandingPage;
import pages.eligibilityResult.CurrentYearEligibilityResultPage;
import pages.eligibilityResult.MedicaidHHDeterminationPage;
import pages.login.HomePage;
import pages.login.Portal;
import pages.manageCustomer.FindACustomerPage;
import pages.myEligibility.EligibilityApplicationPage;
import pages.profile.CreateProfilePage;
import stepdefs.assister.DesignationFormSteps;
import stepdefs.profile.USPSPageSteps;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.HttpsClient;
import utils.PageHeader;
import utils.TestData;

/** @author ppinho
 * 
 * Iterate through the Pages within the respective Module of each Step Definition 
 * and complete each Page with the data given in the excel file.
 * 
 */

public class evpdSteps extends SuperStepDef {
	
	private String ipAddress = globalData.get("Local_IP_Address").trim();
	private String username = globalData.get("username").trim().toLowerCase();
	private String password = globalData.get("password").trim();
	private String schema = globalData.get("mysql_schema").trim();
	
	public evpdSteps(Hook hook) {
		super(hook);
	}
		
	@Given("^EVPD, Login To MAHIX Portal$")
	public void login_To_Portal_EVPD() throws Exception {
		Portal portal = new Portal(hook);
		portal.goToPortal(browserToUse, evpdData.url, evpdData.portal, evpdData.optumIdData);
	}
	
	@Given("^EVPD, Find A Customer With UserProfileRefId And Go To Account Dashboard")
	public void evpdSearchRefID() throws Exception {		
		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.agentPageLoadAndClickOnManageCustomerLink();
		
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(evpdData.memsData.get(0).userRefId);
	}
	
	@Given("^EVPD, Complete Create Profile Page Details$")
	public void complete_Create_Profile_Page_Details() throws Exception {		
		HomePage homePages = new HomePage(driver, testCaseId);

		if(evpdData.portal.equals(PortalName.AGENT.code)){
			homePages.agentPageLoadAndClickOnCreateCustomerProfileLink();
		}

		if(evpdData.portal.equals(PortalName.ASSISTER.code)){
			homePages.clickOnAddNewMemberLink();
			
			DesignationFormSteps designationFormSteps = new DesignationFormSteps(hook);
			designationFormSteps.fill_Designation_Details();
		}
		
		CreateProfilePage createProfilePage = new CreateProfilePage(driver, testCaseId);
		createProfilePage.completeCreateProfilePageDetails(evpdData.portal, evpdData.createProfileData, evpdData.memsData.get(0));
		
		USPSPageSteps uspsPageSteps = new USPSPageSteps(hook);
		uspsPageSteps.evpd_completeUSPSPageDetails();
	}
	
	@And("^EVPD, Complete Start Your Application Module$")
	public void completeStartYourApplicationModule() throws Exception {		
		while(true){
			StartYourApplicationModule startYourApplication = new StartYourApplicationModule(driver, testCaseId);
			
			// Use startYourApplicationHeader method to find the Pager Header and store it in a String
			String header = startYourApplication.startYourApplicationHeader();
			
			// Check if the application is still in the Start Your Application Module else break the loop
			if(header.isEmpty()){
				break;
			}
						
			// Complete each Page with its respective details
			startYourApplication.completeStartYourApplicationDetails(header, evpdData);
		}
		
		sendTempDateToDb();
		
		// Store all the necessary temporary data
		for(int i = 0; i < evpdData.memsData.size(); i++){
			sendDemographicDataToDb(i);
		}
		
		evpdData.memsData.get(0).appCreateDate = evpdData.appDate;
	}
	
	@When("^EVPD, Complete Family And Household Module$")
	public void completeFamilyAndHouseholdModule() throws Exception {
		while(true){
			FamilyAndHouseholdModule familyAndHousehold = new FamilyAndHouseholdModule(driver, testCaseId);
			
			// Check if the application is still in the Family And Household Module else break the loop
			if(!familyAndHousehold.familyAndHouseholdIndicator()){
				break;
			}
			
			PageHeader pageHeader = new PageHeader(driver, testCaseId);			
			
			// Use getPageHeader method to find the Pager Header and store it in a String
			String header = pageHeader.getPageHeader();
			
			// Complete each Page with its respective details
			familyAndHousehold.completeFamilyAndHouseholdDetails(header, evpdData);
		}
	}
	
	@When("^EVPD, Complete Income Module$")
	public void completeImcomeModule() throws Exception {
		while(true){
			IncomeModule income = new IncomeModule(driver, testCaseId);
			
			// Check if the application is still in the Income Module else break the loop
			if(!income.IncomeIndicator()){
				break;
			}
			
			PageHeader pageHeader = new PageHeader(driver, testCaseId);			
			
			// Use getPageHeader method to find the Pager Header and store it in a String
			String header = pageHeader.getPageHeader();
						
			// Complete each Page with its respective details
			income.completeIncomeDetails(header, envData.get("Display.sheltered.workshop.question"), evpdData);
		}		
	}
	
	@When("^EVPD, Complete Additional Questions Module$")
	public void completeAdditionalQuestionsModule() throws Exception {
		while(true){
			AdditionalQuestionsModule additionalQuestions = new AdditionalQuestionsModule(driver, testCaseId);
			
			// Check if the application is still in the Family And Household Module else break the loop
			if(!additionalQuestions.AdditionalQuestionsIndicator()){
				break;
			}
			
			PageHeader pageHeader = new PageHeader(driver, testCaseId);			
			
			// Use getPageHeader method to find the Pager Header and store it in a String
			String header = pageHeader.getPageHeader();
						
			// Complete each Page with its respective details
			additionalQuestions.completeAdditionalQuestionsDetails(header, evpdData);
		}		
	}

	@When("^EVPD, Complete Review And Sign Module$")
	public void completeReviewAndSignModule() throws Exception {
		while(true){
			ReviewAndSignModule reviewAndSign = new ReviewAndSignModule(driver, testCaseId);
			
			// Use startYourApplicationHeader method to find the Pager Header and store it in a String
			String header = reviewAndSign.reviewAndSignHeader();
			
			// Check if the application is still in the Start Your Application Module else break the loop
			if(header.isEmpty()){
				break;
			}
						
			// Complete each Page with its respective details
			reviewAndSign.completeAdditionalQuestionsDetails(header, evpdData);
		}		
	}
	
	@When("^EVPD, Validate Current Year Eligibility Result Page For All Members$")
	public void evpdValidatePDForAllMembers() throws Exception {
		if(evpdData.portal.equals(PortalName.INDIVIDUAL.code) || evpdData.portal.equals(PortalName.ASSISTER.code)){
			hook.closeWebDriver();
			hook.getBrowserInstance();
			
			driver = hook.getDriver();
			
			evpdData.url = "https://" + hook.getEnvironment() + "-agent.mahealthconnector.optum.com/agent/";
			evpdData.optumIdData = TestData.getOptumIdCredentialForAgent(envData);
			
			Portal portal = new Portal(hook);
			portal.goToPortal(browserToUse, evpdData.url, "A", evpdData.optumIdData);
			
			FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
			findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(evpdData.userProfileRefId);
			
			AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
			accountDashboardLandingPage.waitForPageLoaded();
			accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
			
			String year2 = globalData.get("ApplicationCreationYear");
			
			EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
			eligibilityApplicationPage.pageLoadAndClickOnEligibilityDetailsLink(year2);
		}
		
		String year = globalData.get("TaxFPLCalculatorForYear").trim();		
		int intYear = Integer.parseInt(year);
		
		String appDate = DateUtil.getDateInDBFormatUsingPattern(evpdData.memsData.get(0).appCreateDate, DateUtil.UIDatePattern);	
		String currentDate = DateUtil.getDateInDBFormatUsingPattern(hook.runDate, DateUtil.UIDatePattern);
					
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
			
		currentYearEligibilityResultPage.handleWarningDialogIfPresent();
		currentYearEligibilityResultPage.validateEligibilityResults(intYear, evpdData, emptyPaData(evpdData.memCount), appDate, currentDate);		
		currentYearEligibilityResultPage.takeScreenshot();
		
		
		for(int memInd = 0; memInd < evpdData.memCount; memInd++){
			sendPdDataToDb(memInd);
		}
			
		if(evpdData.faReqd){
			currentYearEligibilityResultPage.gotoShowMedicaidHHDetails();
				
			MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
				
			medicaidHHDeterminationPage.validateMedicaidDetailsForAllMember(evpdData.whoIsApplying, evpdData.memsData);
			medicaidHHDeterminationPage.validatePBFGVlaues(evpdData.pbfgData);
			medicaidHHDeterminationPage.clickOnBackToAppResultBtnAtTopAtTop();
		}		
	}
	
	@Given("^EVPD, Verify Renewal Was Initiated$")
	public void verifyRenewalWasInitiated() throws Exception {
		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.waitForRenewalInitiated();
		homePages.takeScreenShot();
	}
	
	public List<PA_MemData> emptyPaData(int memCount) throws Exception {
		List<PA_MemData> memsData = new ArrayList<PA_MemData>();
		
		for(int i = 0; i < memCount; i++){
			memsData.add(new PA_MemData());
		}
		
		for(int i = 0; i < memCount; i++){
			memsData.get(i).tplStatus = null;
			memsData.get(i).basicBenefitLevel = false;
			memsData.get(i).enrolledInMH = false;
			memsData.get(i).coverageType = null;
		}
		
		return memsData;
	}
	
	public void sendTempDateToDb() throws Exception {		
		HttpsClient httpClient = new HttpsClient();		
		TempData tempData = new TempData();
		
		String table = getTempTestData("DataSet") + "_evpd";
		
		tempData.sqlScript = "update " + schema + "." + table + 
				 			 " set " + table + ".user_ref_id = '" + evpdData.userProfileRefId + "', " +
				 			 		   table + ".elg_id = '" + evpdData.eligibilityId + "', " +
				 			 		   table + ".environment = '" + globalData.get("Environment") + "', " +
				 			 		   table + ".app_date = '" + evpdData.appDate + "' " +
				 			 " where " + table + ".scenario = '" + featureFileName + "'" +
				 			 " and " + table + ".mem_id = 'M1'";	
		
		httpClient.updateTempDataMS(ipAddress, username, password, getTempTestData("DataSet"), TempData.updateTempDataRequest(tempData));
	}
	
	public void sendDemographicDataToDb(int memIndex) throws Exception {		
		HttpsClient httpClient = new HttpsClient();		
		TempData tempData = new TempData();
		
		String table = getTempTestData("DataSet") + "_evpd";
		
		if(evpdData.memsData.get(memIndex).middleName != null){
			evpdData.memsData.get(memIndex).middleName = "'" + evpdData.memsData.get(memIndex).middleName + "'";
		}
		
		tempData.sqlScript = "update " + schema + "." + table + 
				 			 " set " + table + ".ms_fn = '" + evpdData.memsData.get(memIndex).firstName + "', " +
				 			 		   table + ".ms_mn = " + evpdData.memsData.get(memIndex).middleName + ", " +
				 			 		   table + ".ms_ln = '" + evpdData.memsData.get(memIndex).lastName + "' " +
				 			 " where " + table + ".scenario = '" + featureFileName + "'" +
				 			 " and " + table + ".mem_id = '" + evpdData.memsData.get(memIndex).memId + "'";	
		
		httpClient.updateTempDataMS(ipAddress, username, password, getTempTestData("DataSet"), TempData.updateTempDataRequest(tempData));
	}
	
	@Given("^Store Elg Id In DB$")
	public void sendELgToDb() throws Exception {		
		HttpsClient httpClient = new HttpsClient();		
		TempData tempData = new TempData();
		EligibilityApplicationPage eligibilityApplicationPage=new EligibilityApplicationPage(driver, testCaseId);
		String table = getTempTestData("DataSet") + "_evpd";
		String year = globalData.get("ApplicationCreationYear");
		String elgId=eligibilityApplicationPage.getLatestEligibilityId(year);
		
		tempData.sqlScript = "update " + schema + "." + table + 
				 			 " set " + 
				 			 		   table + ".elg_id = '" +elgId + "' " +
				 			 " where " + table + ".scenario = '" + featureFileName + "'" +
				 			 " and " + table + ".mem_id = 'M1'";	
		
		httpClient.updateTempDataMS(ipAddress, username, password, getTempTestData("DataSet"), TempData.updateTempDataRequest(tempData));
	}
	
	public void sendPdDataToDb(int memInd) throws Exception {		
		HttpsClient httpClient = new HttpsClient();
		TempData tempData = new TempData();
		
		String table = getTempTestData("DataSet") + "_evpd";
		String programDetermination = null;
		String aidCat = null;
		
		if(!evpdData.memsData.get(memInd).mhAidCat.isEmpty()){
			aidCat = evpdData.memsData.get(memInd).mhAidCat;				
		}else{
			aidCat = evpdData.memsData.get(memInd).ccaAidCat;
		}
		
		if(!evpdData.memsData.get(memInd).mhAidCat.isEmpty()){
			programDetermination = evpdData.memsData.get(memInd).mhProgramDetermination;		
		}else{
			programDetermination = evpdData.memsData.get(memInd).ccaProgramDetermination + " " + 
								   evpdData.memsData.get(memInd).mhProgramDetermination;
		}
		
		tempData.sqlScript = "update " + schema + "." + table + 
	 			 " set " + table + ".ms_aid_cat = '" + aidCat + "', " +
	 			 		   table + ".ms_program_determination = '" + programDetermination + "' " +
	 			 " where " + table + ".scenario = '" + featureFileName + "'" +
	 			 " and " + table + ".mem_id = '" + evpdData.memsData.get(memInd).memId + "'";	
				
		httpClient.updateTempDataMS(ipAddress, username, password, getTempTestData("DataSet"), TempData.updateTempDataRequest(tempData));
	}
	
}
