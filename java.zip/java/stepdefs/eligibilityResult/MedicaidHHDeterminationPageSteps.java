package stepdefs.eligibilityResult;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import pages.eligibilityResult.MedicaidHHDeterminationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.FPLCalculator;
import utils.TestData;

public class MedicaidHHDeterminationPageSteps extends SuperStepDef{
	
	public MedicaidHHDeterminationPageSteps(Hook hook){
		super(hook);
	}
	
	/**
	 * @author vkuma212
	 */
	@Given("^From Medicaid HH Details Page, Take Screenshot For All members$")
	public void validatePDForAllMembersOnMedicaidPage() throws Exception{
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
		medicaidHHDeterminationPage.takeScreensForAllMembersData(memCount);
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@Given("^From Medicaid HH Details Page, Take Screenshot For the Medicaid Page$")
	public void taksScreenShot() throws Exception {
		MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
		medicaidHHDeterminationPage.taksScreenShot();
	}
	
	//Amrita
	@Given("^From Medicaid HH Details Page, Click On Back To Eligibility Application Button On Top of Page$")
	public void ClickBackToEligibilityAppBtnAtTop() throws Exception {
		MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
		medicaidHHDeterminationPage.clickOnBackToEligibilityAppBtnAtTop();
	}
	
	//Amrita
	@Given("^From Medicaid HH Details Page, Click On Back To Eligibility Application Button On Bottom of Page$")
	public void ClickBackToEligibilityAppBtnAtBottom() throws Exception {
		MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
		medicaidHHDeterminationPage.clickOnBackToEligibilityAppBtnAtBottom();
	}
	//Amrita
	@Given("^From Medicaid HH Details Page, Click On Back To Application Result Button On Top of Page$")
	public void ClickBackToEligAppResultBtnAtTop() throws Exception {
		MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
		medicaidHHDeterminationPage.clickOnBackToAppResultBtnAtTopAtTop();
	}
	 //Amrita
	@Given("^From Medicaid HH Details Page, Click On Back To Application Result Button On Bottom of Page$")
	public void ClickBackToEligAppResultBtnAtBottom() throws Exception {
		MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
		medicaidHHDeterminationPage.clickOnBackToAppResultBtnAtBottom();
	}
	 //Amrita
	@Given("^From Medicaid HH Details Page, Click On Previous Button$")
	public void ClickPreviousBtn() throws Exception {
		MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
		medicaidHHDeterminationPage.clickOnPrevBtn();
	}
	    
	 //Amrita
	@Given("^From Medicaid HH Details Page, Click On Next Button$")
	public void ClickNextBtn() throws Exception {
		MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
		medicaidHHDeterminationPage.clickOnNextBtn();
	}
	
	 //Amrita
	@Given("^From Medicaid HH Details Page, Get Eligibility Id And Store in Temp Data With Variable As CurrentEligibilityId$")
	public void getEligibilityId() throws Exception {
		MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
		String elgId = medicaidHHDeterminationPage.getEligibilityId();
		storeTempTestData("CurrentEligibilityId", elgId);
	}
	
	/**@author vkuma212
	 
	 From Medical HH Details Page, Expand Tab For Member "1"

	 */
	@When("^From Medical HH Details Page, Expand Tab For Member \"(.*?)\"$")
	public void expandMemMedicaidDetailsAndCloseForOthers(String memNo) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.expandMemMedicaidDetailsAndCloseForOthers(memIndex, evpdData.memCount);
	}
	
	/**@author vkuma212
	 
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 AgeFormat :- "32","32:01", "00:00:05"

		From Medical HH Details Page, For Member "2", Validate DOB With Age As "36"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate DOB With Age As \"(.*?)\"$")
	public void validateDOBForMember(String memNo,String age) throws Exception{
		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, age);
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateDOBForMember(memIndex, dob);

	}
	
	/**
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 VerifiedDisability :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "", Validate Disability Status As "yes"
	 
	 * @throws Exception
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Disability Status As \"(.*?)\"$")
	public void validateDisabilityStatusForMember(String memNo,String diabilityStatus) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateDisabilityStatusForMember(memIndex, diabilityStatus);

	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Head of Household? :- 
	 * 						1.	yes
	 						2.  no
	 From Medical HH Details Page, For Member "2", Validate HOH Status As "yes"
	 
	 * @throws Exception
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate HOH Status As \"(.*?)\"$")
	public void validateHOHstatusForMember(String memNo,String hohStatus) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateHOHStatusForMember(memIndex, hohStatus);

	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 HIV+? :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "2", Validate HIV Status As "yes"
	 
	 * @throws Exception
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate HIV Status As \"(.*?)\"$")
	public void validateHIVstatusForMember(String memNo,String hivStatus) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateHIVStatusForMember(memIndex, hivStatus);

	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Filing Jointly? :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "2", Validate Filing Jointly Status As "yes"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Filing Jointly Status As \"(.*?)\"$")
	public void validateFilingJointlyStatusForMember(String memNo,String filingJointlyStatus) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateFilingJointlyStatusForMember(memIndex, filingJointlyStatus);

	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Receiving DMH Services? :- 
	 * 						1.	yes
	 * 						2.  no
	 From Medical HH Details Page, For Member "2", Validate DMH Received Status As "yes"
	 
	 * @throws Exception
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate DMH Received Status As \"(.*?)\"$")
	public void validateDMHReceivedStatusForMember(String memNo,String receivedDMHServicesStatus) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateReceivedDMHServicesStatusForMember(memIndex, receivedDMHServicesStatus);

	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Claiming Dependents? :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "3", Validate Claiming Dependants Status As "no"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Claiming Dependants Status As \"(.*?)\"$")
	public void validateDependantClaimingStatusForMember(String memNo,String claimingDependentsStatus) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateClaimingDependentsForMember(memIndex, claimingDependentsStatus);

	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Former Foster Care?  :- 
	 * 						1.	yes
	 * 						2.  no
	 * 
	 From Medical HH Details Page, For Member "2", Validate Former Foster Care Status As "yes"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Former Foster Care Status As \"(.*?)\"$")
	public void validateFormerFosterCareStatusForMember(String memNo,String formerFosterCareStatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateFormerFosterCareStatusForMember(memIndex, formerFosterCareStatus);

	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Self-attested Disability?  :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "2", Validate Self Attested Disability Status As "yes"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Self Attested Disability Status As \"(.*?)\"$")
	public void validateSelfAttestedDisabilityStatusForMember(String memNo,String SelfattestedDisabilityStatus) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateSelfattestedDisabilityForMember(memIndex, SelfattestedDisabilityStatus);

	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Is Safe Harbor Eligible?   :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "3", Validate Safe Harbor Eligible Status As "yes"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Safe Harbor Eligible Status As \"(.*?)\"$")
	public void validateSafeHarborEligibleStatusForMember(String memNo,String IsSafeHarborStatus) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateIsSafeHarborForMember(memIndex, IsSafeHarborStatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Aid Category   :- From Aid Cat Table
	 
	 From Medical HH Details Page, For Member "3", Validate Aid Category As "A1"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Aid Category As \"(.*?)\"$")
	public void validateAidCategoryForMember(String memNo,String aidCat) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateAidCategoryForMember(memIndex, aidCat);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Citizenship/Immigration Status    :- CIT,CITN,QLP,QAB,ILP,NQP,UND       
	 
		From Medical HH Details Page, For Member "3", Validate Citizenship Status As "CIT"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Citizenship Status As \"(.*?)\"$")
	public void validateCitizenshipStatusForMember(String memNo,String immStatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateCitizenImmigrationStatusForMember(memIndex, immStatus);
	}
	

	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Is Post Partum Eligible?    :- 
	 * 						1.	yes
	 * 						2.  no
	
		From Medical HH Details Page, For Member "1", Validate Post Partum Eligible Status As "yes"
	
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Post Partum Eligible Status As \"(.*?)\"$")
	public void validatePostPartumEligibleStatusForMember(String memNo,String IsPostPartum) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validatesPostPartumEligibleForMember(memIndex, IsPostPartum);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Pregnant?    :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "1", Validate Pregnant Status As "yes"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Pregnant Status As \"(.*?)\"$")
	public void validatePregnantStatusForMember(String memNo,String IsPregnant) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validatePregnantForMember(memIndex, IsPregnant);
	}
	
	/**@author Amrita
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Admin Closure    :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "1", Validate Admin Closure Status As "yes"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Admin Closure Status As \"(.*?)\"$")
	public void validateAdminClosureStatusForMember(String memNo,String AdminClosure) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateAdminClosureForMember(memIndex, AdminClosure);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Married?   :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "1", Validate Married Status As "no"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Married Status As \"(.*?)\"$")
	public void validateMarriedStatusForMember(String memNo,String Marriedstatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateMarriedstatusForMember(memIndex, Marriedstatus);
	}
	
	/**@author Amrita
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Claimed by Non-Custodial Parent?    :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "1", Validate Claimed By NCP Status As "yes"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Claimed By NCP Status As \"(.*?)\"$")
	public void validateClaimedByNCPStatusForMember(String memNo,String NonCustodialParentstatus) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateNonCustodialParentstatusForMember(memIndex, NonCustodialParentstatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Other Health Insurance    :- 
	 * 						1.	yes
	 * 						2.  no
	
		From Medical HH Details Page, For Member "1", Validate Other Health Insurance Status As "yes"
	
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Other Health Insurance Status As \"(.*?)\"$")
	public void validateOtherHealthInsuranceStatusForMember(String memNo,String OtherHealthInsurancestatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateOtherHealthInsuranceLabelstatusForMember(memIndex, OtherHealthInsurancestatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Medicaid Child Age?     :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "2", Validate Medicaid Child Age Status As "yes"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Medicaid Child Age Status As \"(.*?)\"$")
	public void validateMedicaidChildAgeStatusForMember(String memNo,String MedicaidChildAgestatus) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateMedicaidChildAgeForMember(memIndex, MedicaidChildAgestatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					BCC?    :- 
	 * 						1.	yes
	 * 						2.  no
		From Medical HH Details Page, For Member "1", Validate BCC Status As "yes"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate BCC Status As \"(.*?)\"$")
	public void validateBCCStatusForMember(String memNo,String BCCstatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateBCCForMember(memIndex, BCCstatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Required to Files Taxes    :- 
	 * 						1.	yes
	 * 						2.  no

		From Medical HH Details Page, For Member "1", Validate Required to Files Taxes Status As "yes"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Required to Files Taxes Status As \"(.*?)\"$")
	public void validateRequiredToFilesTaxesStatusForMember(String memNo,String RequiredtoFilesTaxesstatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateRequiredtoFilesTaxesForMember(memIndex, RequiredtoFilesTaxesstatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Received Medicaid In Foster Care?    :- 
	 * 						1.	yes
	 * 						2.  no
		From Medical HH Details Page, For Member "1", Validate Received Medicaid In Foster Care Status As "yes"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Received Medicaid In Foster Care Status As \"(.*?)\"$")
	public void validateReceivedMedicaidInFosterCareStatusForMember(String memNo,String ReceivedMedicaidInFosterCarestatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateReceivedMedicaidInFosterCareForMember(memIndex, ReceivedMedicaidInFosterCarestatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Claimed as a Dependent?     :- 
	 * 						1.	yes
	 * 						2.  no
		From Medical HH Details Page, For Member "1", Validate Claimed as a Dependent Status As "yes"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Claimed as a Dependent Status As \"(.*?)\"$")
	public void validateClaimedasaDependentStatusForMember(String memNo,String ClaimedasaDependentstatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateClaimedasaDependentForMember(memIndex, ClaimedasaDependentstatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Born MH Eligible     :- 
	 * 						1.	yes
	 * 						2.  no 

		From Medical HH Details Page, For Member "1", Validate Born MH Eligible Status As "yes"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Born MH Eligible Status As \"(.*?)\"$")
	public void validateBornMHEligibleStatusForMember(String memNo,String BornMHEligiblestatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateBornMHEligibleForMember(memIndex, BornMHEligiblestatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Medicaid Tax Role     :- 
	 * 						-Any valid tax role description
	
	From Medical HH Details Page, For Member "1", Validate Medicaid Tax Role Status As ""
	
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Medicaid Tax Role Status As \"(.*?)\"$")
	public void validateMedicaidTaxRoleStatusForMember(String memNo,String MedicaidTaxRolestatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateMedicaidTaxRoleForMember(memIndex, MedicaidTaxRolestatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Self-attested Incarceration?     :- 
	 * 						1.	yes
	 * 						2.  no
	 
		From Medical HH Details Page, For Member "1", Validate Self-attested Incarceration Status As "yes"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Self-attested Incarceration Status As \"(.*?)\"$")
	public void validateIncarcerationStatusForMember(String memNo,String incarcerationStatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateIncarcerationStatusForMember(memIndex, incarcerationStatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Medically Frail?      :- 
	 * 						1.	yes
	 * 						2.  no
	
		From Medical HH Details Page, For Member "1", Validate Medically Frail Status As "yes"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Medically Frail Status As \"(.*?)\"$")
	public void validateMedicallyFrailStatusForMember(String memNo,String MedicallyFrailstatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateMedicallyFrailForMember(memIndex, MedicallyFrailstatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Medically Frail Effective Date       :- 
	 * 						1.	yes
	 * 						2.  no
	 
	 From Medical HH Details Page, For Member "1", Validate Medically Frail Effective Date As "09/10/2018"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Medically Frail Effective Date As \"(.*?)\" days prior from app date$")
	public void validateMedicallyFrailEffectiveDateStatusForMember(String memNo,String MedicallyFrailEffectiveDatePriorFromToday) throws Exception{
		
        String appDate = TestData.getTempTestData("AppDate", featureFileName);
		
		int memIndex = Integer.parseInt(memNo)-1;
		String medicallyFrailEffectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+MedicallyFrailEffectiveDatePriorFromToday);
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateMedicallyFrailEffectiveDateForMember(memIndex, medicallyFrailEffectiveDate);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					TPL Status :- 
	 * 						-Valid TPL status value
	 
		From Medical HH Details Page, For Member "1", Validate TPL Status As "P"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate TPL Status As \"(.*?)\"$")
	public void validateTPLStatusForMember(String memNo,String TPLStatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateTPLStatusForMember(memIndex, TPLStatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					TMA Period End Date :- 
	 * 						-Valid Date value
	
		From Medical HH Details Page, For Member "1", Validate TMA Period End Date As "09/10/2018"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate TMA Period End Date As \"(.*?)\" days in future from app date$")
	public void validateTMAPeriodEndDateForMember(String memNo,String TMAPeriodEndDateInFutureFromToday) throws Exception{
		
		//initail App, RAC update income -- income effective date
		// tma eligible then asked this question
		// to be taken from temp variable "TMA_ENDDate"
		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		
		int memIndex = Integer.parseInt(memNo)-1;
		String tmaEndDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:-"+TMAPeriodEndDateInFutureFromToday);

		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateTMAPeriodEndDateForMember(memIndex, tmaEndDate);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Continued MassHealth Standard Eligibility for Pregnant Women :- 
	 * 						-yes
	 *                      -no
	
	From Medical HH Details Page, For Member "1", Validate Continued MassHealth Status As "yes"
	
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Continued MassHealth Status As \"(.*?)\"$")
	public void validateContinuedMassHealthStatusForMember(String memNo,String MassHealthStandardEligibilityforPregnantWomenStatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateMassHealthStandardEligibilityforPregnantWomenForMember(memIndex, MassHealthStandardEligibilityforPregnantWomenStatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Pregnancy End Date :- 
	 * 						-Valid date value
	
    And From Medical HH Details Page, For Member "1", Validate Post Partum Start Date as "1" days prior from app date
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Post Partum Start Date as \"(.*?)\" days prior from app date$")
	public void validatePostPartumStartDateForMember(String memNo,String PostPartumStartDatePriorFromToday) throws Exception{
        String appDate = TestData.getTempTestData("AppDate", featureFileName);
		
		int memIndex = Integer.parseInt(memNo)-1;
		String postPartumStartDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+PostPartumStartDatePriorFromToday);
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validatePostPartumStartDateForMember(memIndex, postPartumStartDate);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Pregnancy End Date :- 
	 * 						-Valid date value
	
	And From Medical HH Details Page, For Member "1", Validate Post Partum End Date as "12/31/2018"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Post Partum End Date as \"(.*?)\"$")
	public void validatePostPartumEndDateForMember(String memNo,String PostPartumEndDate) throws Exception{
        String appDate = TestData.getTempTestData("AppDate", featureFileName);
		
		int memIndex = Integer.parseInt(memNo)-1;
		String postPartumEndDate = DateUtil.getLastDayOfTheCurrentYear(appDate, DateUtil.UIDatePattern, PostPartumEndDate);
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validatePostPartumEndDateForMember(memIndex, postPartumEndDate);
	}

	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Pregnancy End Date :- 
	 * 						-Valid date value
	
	 From Medical HH Details Page, For Member "1", Validate Pregnancy End Date as "1" days prior from app date
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Pregnancy End Date as \"(.*?)\" days prior from app date$")
	public void validatePregnancyEndDateForMember(String memNo,String PregnancyEndDatePriorFromToday) throws Exception{
        String appDate = TestData.getTempTestData("AppDate", featureFileName);
		
		int memIndex = Integer.parseInt(memNo)-1;
		String pregnancyEndDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+PregnancyEndDatePriorFromToday);
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validatePregnancyEndDateForMember(memIndex, pregnancyEndDate);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					MH Pending :- 
	 * 						-yes
	 *                      -no
	
	From Medical HH Details Page, For Member "1", Validate MH Pending Status As "yes"
	
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate MH Pending Status As \"(.*?)\"$")
	public void validateMHPendingStatusForMember(String memNo,String MHpendingStatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateMHpendingForMember(memIndex, MHpendingStatus);
	}
	
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Second Provisional Restricted  :- 
	 * 						-yes
	 *                      -no
	
	From Medical HH Details Page, For Member "1", Validate Second Provisional Restricted  Status As "yes"
	
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Second Provisional Restricted  Status As \"(.*?)\"$")
	public void validateSecondProvisionalRestrictedStatusForMember(String memNo,String SecondProvisionalRestrictedStatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateSecondProvisionalRestrictedForMember(memIndex, SecondProvisionalRestrictedStatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Closure Reason  :-  
	 * 						-Any valid Admin Closure reason code from AdminClosureReason Enum
	 
	 From Medical HH Details Page, For Member "1", Validate Admin Closure Reason As "38"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Admin Closure Reason As \"(.*?)\"$")
	public void validateAdminClosureReasonForMember(String memNo,String ClosureReasonstatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateClosurestatusForMember(memIndex, ClosureReasonstatus);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					Eligibility Begin Date should be always validated as 10 days prior to the application date
	 

	From Medical HH Details Page, For Member "1", Validate Eligibility Begin Date as "10" days prior from app date
	
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Eligibility Begin Date as \"(.*?)\" days prior from app date$")
	public void validateEligibilityBeginDateForMember(String memNo, String EligibilityBeginDatePriorFromToday) throws Exception{
			
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		
		int memIndex = Integer.parseInt(memNo)-1;
		String eligBeginDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+EligibilityBeginDatePriorFromToday);

		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateEligibilityBeginstatusDateLabelForMember(memIndex,eligBeginDate);
	}
	
	/**@author averma77
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					EligibilityBeginDateStatus :- Blank
	 * 					EligibilityBeginDateValue :- "--"
	 
	From Medical HH Details Page, For Member "1", Validate Eligibility Begin Date As "--"
	From Medical HH Details Page, For Member "1", Validate Eligibility Begin Date As "10/27/2018"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Eligibility Begin Date As \"(.*?)\"$")
	public void validateEligibilityBeginDateAsBlank(String memNo,String dateStatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateEligibilityBeginstatusDateLabelForMember(memIndex, dateStatus);
	}

	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					    Grant Date  :- 
	 * 						-Valid date value
	 
	 From Medical HH Details Page, For Member "1", Validate Grant Date As "09/10/2018"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Grant Date as \"(.*?)\" days prior from app date$")
	public void validateGrantDateForMember(String memNo,String GrantDatePriorFromToday) throws Exception{
		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		
		int memIndex = Integer.parseInt(memNo)-1;
		String grantDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+GrantDatePriorFromToday);

		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateGrantDateForMember(memIndex, grantDate);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					    MAGI HH Size  :- 
	 * 						-Valid numeric value
	 
	 From Medical HH Details Page, For Member "1", Validate MAGI HH Size As "1"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate MAGI HH Size As \"(.*?)\"$")
	public void validateMAGIHHSizeForMember(String memName, int magiHHSize) throws Exception {		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateMAGIHHSizeForMember(magiHHSize, memName);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					    Tax HH Size  :- 
	 * 						-Valid numeric value
	 
	 From Medical HH Details Page, For Member "1", Validate Tax HH Size As "2"
	 
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Tax HH Size As \"(.*?)\"$")
	public void validateTaxHHSizeForMember(String memNo,int taxHHSize) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateTaxHHSizeForMember(memIndex, taxHHSize);
	}
	
	/**@author akumari4
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					    MAGI FPL Value  :- 
	 * 						-Valid FPL value
	 
	 From Medical HH Details Page, For Member "1", Validate MAGI FPL As "102.34%"
	 
	 * @throws Exception
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate MAGI FPL As \"(.*?)\"$")
	public void validateMAGIFPLForMember(String memNo, String magiFPL) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateMAGIFPLForMember(memIndex, magiFPL);
	}
	
	/**@author vinay
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					    House Hold Size Value   :-1,2,3,4 
	 * 						-House Hold Income Value :- 2000, 2300.35
	 
	 From Medical HH Details Page, For Member "1", Validate MAGI FPL With HouseHold Size As "5" and Household Income As "50000.67"
	 
	 * @throws Exception
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate MAGI FPL With HouseHold Size As \"(.*?)\" and Household Income As \"(.*?)\"$")
	public void validateMAGIFPLForMemberUsingCalculator(String memNo, String magiHHSize, String hhIncome) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		int intMagiHHSize = Integer.parseInt(magiHHSize);
		double doubleHhIncome = Double.parseDouble(hhIncome);
		String year = globalData.get("MAGI_FPLCalculatorForYear").trim();
		int intYear = Integer.parseInt(year);

		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		appDate = DateUtil.getDateInDBFormatUsingPattern(appDate, DateUtil.UIDatePattern);	
		String magiFPL = FPLCalculator.getMAGI_FPLUsingCalculator(intYear, intMagiHHSize, doubleHhIncome, appDate);
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateMAGIFPLForMember(memIndex, magiFPL);
	}
	
	/**@author Amrita
	 * Accepted Value :- MemNo :- 1,2,3,4
		
		From Medical HH Details Page, For Member "1", Validate Tax FPL As "200.00%"
		
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate Tax FPL As \"(.*?)\"$")
	public void validateTaxFPLForMember(String memNo, String taxFPL ) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateTaxFPLForMember(memIndex, taxFPL);
	}
	
	/**@author vinay
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					    House Hold Size Value   :-1,2,3,4 
	 * 						-House Hold Income Value :- 2000, 2300.35
	 
	 From Medical HH Details Page, For Member "1", Validate TAX FPL With HouseHold Size As "5" and Household Income As "50000.67"
	 
	 * @throws Exception
	 */
	@When("^From Medical HH Details Page, For Member \"(.*?)\", Validate TAX FPL With HouseHold Size As \"(.*?)\" and Household Income As \"(.*?)\"$")
	public void validateTAXFPLForMemberUsingCalculator(String memNo, String taxHHSize, String hhIncome) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		int intTaxHHSize = Integer.parseInt(taxHHSize);
		double doubleHhIncome = Double.parseDouble(hhIncome);
		String year = globalData.get("TaxFPLCalculatorForYear").trim();
		int intYear = Integer.parseInt(year);
		
		String taxFPL = FPLCalculator.getTaxFPLUsingCalculator(intYear, intTaxHHSize, doubleHhIncome);
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validateTaxFPLForMember(memIndex, taxFPL);
	}
	/**@author akumari4
	 * Accepted Value :- PBFGNo :- 1,2,3,4
	 * 					    Monthly Premium Value  :- 
	 * 						-Valid  premium and PBFG value
	 
		From Medical HH Details Page, For PBFG "1", Validate Monthly Premium Value As "$200.00"
		
	 * @throws Exception
	 */
	@When("^From Medical HH Details Page, For PBFG \"(.*?)\", Validate Monthly Premium Value As \"(.*?)\"$")
	public void validateMonthlyPremiumValueForMember(String strPbfgNo, String monthlyPremiumAmt) throws Exception{
		
		int pbfgNo = Integer.parseInt(strPbfgNo);
		
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validatePBFGMonthlyPremium(pbfgNo, monthlyPremiumAmt);
	}
	
	/**@author Aashita
	* Accepted Value :- MemberNo :- 1,2,3,4
	*     Monthly Premium Value  :- 
			* -Valid  premium value

	From Medical HH Details Page, For MemberNo "1", Validate Monthly Premium Value As "$200.00"

	* @throws Exception
	*/
	@When("^From Medical HH Details Page, For MemberNo \"(.*?)\", Validate Monthly Premium Value As \"(.*?)\"$")
	public void validateMonthlyPremiumValueFromMemberNo(String memNoInput, String monthlyPremiumAmt) throws Exception{
		int memIndex = Integer.parseInt(memNoInput)-1 ;
		String userProfileRefID = getTempTestData("UserProfileRefId");
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String fullName = elgMemberTable.getFullNameUsingUserProfileRefId(userProfileRefID,memIndex );
		MedicaidHHDeterminationPage MedicaidHHDeterminationPage = new pages.eligibilityResult.MedicaidHHDeterminationPage(driver, testCaseId);
		MedicaidHHDeterminationPage.validatePBFGMonthlyPremiumFromMember(fullName, monthlyPremiumAmt);
	}
}
