package stepdefs.eligibilityResult;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import appdata.common.TempData;
import appdata.pa.PA_MemData;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import enums.PortalName;
import pages.accountDashboard.AccountDashboardLandingPage;
import pages.eligibilityResult.AdminSEPPage;
import pages.eligibilityResult.CurrentYearEligibilityResultPage;
import pages.eligibilityResult.MedicaidHHDeterminationPage;
import pages.login.Portal;
import pages.manageCustomer.FindACustomerPage;
import pages.myEligibility.EligibilityApplicationPage;
import pages.shopping.DentalPlanShopingPage;
import pages.shopping.EnrollPage;
import pages.shopping.FindAHealthOrDentalPlanPage;
import pages.shopping.HealthPlanShopingPage;
import pages.shopping.MyEnrollmentPage;
import pages.shopping.PlanFinderToolPage;
import pages.shopping.QualifyingLifeEventPage;
import pages.shopping.ReviewApplicationPage;
import pages.shopping.ReviewShoppingCartPage;
import pages.shopping.ShopAndEnrollPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.FPLCalculator;
import utils.HttpsClient;
import utils.TestData;

public class CurrentYearEligibilityResultSteps extends SuperStepDef {
	
	public CurrentYearEligibilityResultSteps(Hook hook) {
		super(hook);
	}
	
	/** @author ppinho 
	 * 
	 *  From Current Year Eligibility Result Page, Validate PD for All members
	 *  
	 */
	
	@Given("^From Current Year Eligibility Result Page, Validate PD for All members$")
	public void validateEligibilityResultsForAllMembers() throws Exception {
		if(evpdData.portal.equals(PortalName.INDIVIDUAL.code) || evpdData.portal.equals(PortalName.ASSISTER.code)){
			hook.closeWebDriver();
			hook.getBrowserInstance();
			
			driver = hook.getDriver();
			
			evpdData.url = "https://" + hook.getEnvironment() + "-agent.mahealthconnector.optum.com/agent/";
			evpdData.optumIdData = TestData.getOptumIdCredentialForAgent(envData);
			
			Portal portal = new Portal(hook);
			portal.goToPortal(browserToUse, evpdData.url, "A", evpdData.optumIdData);
						
			FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
			findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(evpdData.userProfileRefId);
			
			AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
			accountDashboardLandingPage.waitForPageLoaded();
			accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
			
			String year2 = globalData.get("ApplicationCreationYear");
			
			EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
			eligibilityApplicationPage.pageLoadAndClickOnEligibilityDetailsLink(year2);
		}
		
		String year = globalData.get("TaxFPLCalculatorForYear").trim();		
		int intYear = Integer.parseInt(year);
		
		String appDate = DateUtil.getDateInDBFormatUsingPattern(evpdData.memsData.get(0).appCreateDate, DateUtil.UIDatePattern);	
		String currentDate = DateUtil.getDateInDBFormatUsingPattern(hook.runDate, DateUtil.UIDatePattern);
			
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
			
		currentYearEligibilityResultPage.handleWarningDialogIfPresent();
		currentYearEligibilityResultPage.validateEligibilityResults(intYear, evpdData, emptyPaData(evpdData.memCount), appDate, currentDate);		
		currentYearEligibilityResultPage.takeScreenshot();
		
		for(int memInd = 0; memInd < evpdData.memCount; memInd++){
			sendPdDataToDb(memInd);
		}
			
		if(evpdData.faReqd){
			currentYearEligibilityResultPage.gotoShowMedicaidHHDetails();
				
			MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
				
			medicaidHHDeterminationPage.validateMedicaidDetailsForAllMember(evpdData.whoIsApplying, evpdData.memsData);
			medicaidHHDeterminationPage.validatePBFGVlaues(evpdData.pbfgData);
			medicaidHHDeterminationPage.clickOnBackToAppResultBtnAtTopAtTop();
		}		
	}
	
	@Given("^From Current Year Eligibility Result Page, Complete Health And Dental Shopping$")
	public void completeShoppingDetails_ForAllGroup() throws Exception {

		String gpHealth=enrollmentData.memsData.get(0).gpHealthPlan;
		System.out.println(gpHealth);
		String gpDental=enrollmentData.memsData.get(0).gpDentalPlan;
		System.out.println(gpDental);
		
		/*if(!(enrollmentData.memsData.get(0).transactionType1.equals("")))
		{
		storeTempTestData("transactionType1",enrollmentData.memsData.get(0).transactionType1);
		}*/
		
		if(!(enrollmentData.memsData.get(0).transactionType1.equals(""))){storeTempTestData("transactionType1",enrollmentData.memsData.get(0).transactionType1);}
		if(!(enrollmentData.memsData.get(0).maintainenceTypeCode1.equals(""))){storeTempTestData("maintainenceTypeCode1",enrollmentData.memsData.get(0).maintainenceTypeCode1);}
		if(!(enrollmentData.memsData.get(0).maintainenceReasonCode1.equals(""))){storeTempTestData("maintainenceReasonCode1",enrollmentData.memsData.get(0).maintainenceReasonCode1);}
		if(!(enrollmentData.memsData.get(0).elgBegDateHealth1.equals(""))){storeTempTestData("elgBegDateHealth1",enrollmentData.memsData.get(0).elgBegDateHealth1);}
		if(!(enrollmentData.memsData.get(0).elgEndDateHealth1.equals(""))){storeTempTestData("elgEndDateHealth1",enrollmentData.memsData.get(0).elgEndDateHealth1);}
		if(!(enrollmentData.memsData.get(0).elgBegDateDental1.equals(""))){storeTempTestData("elgBegDateDental1",enrollmentData.memsData.get(0).elgBegDateDental1);}
		if(!(enrollmentData.memsData.get(0).elgEndDateDental1.equals(""))){storeTempTestData("elgEndDateDental1",enrollmentData.memsData.get(0).elgEndDateDental1);}
		if(!(enrollmentData.memsData.get(0).transactionType2.equals(""))){storeTempTestData("transactionType2",enrollmentData.memsData.get(0).transactionType2);}
		if(!(enrollmentData.memsData.get(0).maintainenceTypeCode2.equals(""))){storeTempTestData("maintainenceTypeCode2",enrollmentData.memsData.get(0).maintainenceTypeCode2);}
		if(!(enrollmentData.memsData.get(0).maintainenceReasonCode2.equals(""))){storeTempTestData("maintainenceReasonCode2",enrollmentData.memsData.get(0).maintainenceReasonCode2);}
		if(!(enrollmentData.memsData.get(0).elgBegDateHealth2.equals(""))){storeTempTestData("elgBegDateHealth2",enrollmentData.memsData.get(0).elgBegDateHealth2);}
		if(!(enrollmentData.memsData.get(0).elgEndDateHealth2.equals(""))){storeTempTestData("elgEndDateHealth2",enrollmentData.memsData.get(0).elgEndDateHealth2);}
		if(!(enrollmentData.memsData.get(0).elgBegDateDental2.equals(""))){storeTempTestData("elgBegDateDental2",enrollmentData.memsData.get(0).elgBegDateDental2);}
		if(!(enrollmentData.memsData.get(0).elgEndDateDental2.equals(""))){storeTempTestData("elgEndDateDental2",enrollmentData.memsData.get(0).elgEndDateDental2);}
		if(!(enrollmentData.memsData.get(0).transactionType3.equals(""))){storeTempTestData("transactionType3",enrollmentData.memsData.get(0).transactionType3);}
		if(!(enrollmentData.memsData.get(0).maintainenceTypeCode3.equals(""))){storeTempTestData("maintainenceTypeCode3",enrollmentData.memsData.get(0).maintainenceTypeCode3);}
		if(!(enrollmentData.memsData.get(0).maintainenceReasonCode3.equals(""))){storeTempTestData("maintainenceReasonCode3",enrollmentData.memsData.get(0).maintainenceReasonCode3);}
		if(!(enrollmentData.memsData.get(0).elgBegDateHealth3.equals(""))){storeTempTestData("elgBegDateHealth3",enrollmentData.memsData.get(0).elgBegDateHealth3);}
		if(!(enrollmentData.memsData.get(0).elgEndDateHealth3.equals(""))){storeTempTestData("elgEndDateHealth3",enrollmentData.memsData.get(0).elgEndDateHealth3);}
		if(!(enrollmentData.memsData.get(0).elgBegDateDental3.equals(""))){storeTempTestData("elgBegDateDental3",enrollmentData.memsData.get(0).elgBegDateDental3);}
		if(!(enrollmentData.memsData.get(0).elgEndDateDental3.equals(""))){storeTempTestData("elgEndDateDental3",enrollmentData.memsData.get(0).elgEndDateDental3);}
		if(!(enrollmentData.memsData.get(0).transactionType4.equals(""))){storeTempTestData("transactionType4",enrollmentData.memsData.get(0).transactionType4);}
		if(!(enrollmentData.memsData.get(0).maintainenceTypeCode4.equals(""))){storeTempTestData("maintainenceTypeCode4",enrollmentData.memsData.get(0).maintainenceTypeCode4);}
		if(!(enrollmentData.memsData.get(0).maintainenceReasonCode4.equals(""))){storeTempTestData("maintainenceReasonCode4",enrollmentData.memsData.get(0).maintainenceReasonCode4);}
		if(!(enrollmentData.memsData.get(0).elgBegDateHealth4.equals(""))){storeTempTestData("elgBegDateHealth4",enrollmentData.memsData.get(0).elgBegDateHealth4);}
		if(!(enrollmentData.memsData.get(0).elgEndDateHealth4.equals(""))){storeTempTestData("elgEndDateHealth4",enrollmentData.memsData.get(0).elgEndDateHealth4);}
		if(!(enrollmentData.memsData.get(0).elgBegDateDental4.equals(""))){storeTempTestData("elgBegDateDental4",enrollmentData.memsData.get(0).elgBegDateDental4);}
		if(!(enrollmentData.memsData.get(0).elgEndDateDental4.equals(""))){storeTempTestData("elgEndDateDental4",enrollmentData.memsData.get(0).elgEndDateDental4);}
		if(!(enrollmentData.memsData.get(0).transactionType5.equals(""))){storeTempTestData("transactionType5",enrollmentData.memsData.get(0).transactionType5);}
		if(!(enrollmentData.memsData.get(0).maintainenceTypeCode5.equals(""))){storeTempTestData("maintainenceTypeCode5",enrollmentData.memsData.get(0).maintainenceTypeCode5);}
		if(!(enrollmentData.memsData.get(0).maintainenceReasonCode5.equals(""))){storeTempTestData("maintainenceReasonCode5",enrollmentData.memsData.get(0).maintainenceReasonCode5);}
		if(!(enrollmentData.memsData.get(0).elgBegDateHealth5.equals(""))){storeTempTestData("elgBegDateHealth5",enrollmentData.memsData.get(0).elgBegDateHealth5);}
		if(!(enrollmentData.memsData.get(0).elgEndDateHealth5.equals(""))){storeTempTestData("elgEndDateHealth5",enrollmentData.memsData.get(0).elgEndDateHealth5);}
		if(!(enrollmentData.memsData.get(0).elgBegDateDental5.equals(""))){storeTempTestData("elgBegDateDental5",enrollmentData.memsData.get(0).elgBegDateDental5);}
		if(!(enrollmentData.memsData.get(0).elgEndDateDental5.equals(""))){storeTempTestData("elgEndDateDental5",enrollmentData.memsData.get(0).elgEndDateDental5);}


		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		
		
		if(currentYearEligibilityResultPage.isQLEPresent()){
			currentYearEligibilityResultPage.clickOnCanIShopBtn();
			qualifyingLifeEventPage.completeQLEDetails(evpdData, enrollmentData);
		}

		
		String subscriber=enrollmentData.memsData.get(0).subscriber;
		storeTempTestData("subscriber", subscriber);
		
		String racdetails1=enrollmentData.memsData.get(0).racdetails1;
		storeTempTestData("racdetails1", racdetails1);
		
		storeTempTestData("type1",enrollmentData.memsData.get(0).type1);
		storeTempTestData("type2",enrollmentData.memsData.get(0).type2);
		storeTempTestData("type3",enrollmentData.memsData.get(0).type3);
		storeTempTestData("type4",enrollmentData.memsData.get(0).type4);
		storeTempTestData("type5",enrollmentData.memsData.get(0).type5);
		
		storeTempTestData("qtype1",enrollmentData.memsData.get(0).qtype1);
		storeTempTestData("qtype2",enrollmentData.memsData.get(0).qtype2);
		storeTempTestData("qtype3",enrollmentData.memsData.get(0).qtype3);
		storeTempTestData("qtype4",enrollmentData.memsData.get(0).qtype4);
		storeTempTestData("qtype5",enrollmentData.memsData.get(0).qtype5);
		
		/*System.out.println("SHOPPING");
		System.out.println(subscriber);
		String[] arrSplit = subscriber.split("_");
		int memCount =arrSplit.length;
		storeTempTestData("MemberCount", memCount+"");
		for (int i=0; i < arrSplit.length; i++)
	    {
	      System.out.println(arrSplit[i]);
	      String[] subs = arrSplit[i].split(":");
	      System.out.println(subs[1]);
	      storeTempTestData("subscriber_M"+(i+1)+"", subs[1]);
	    
	    }*/

		int healthPlanGp=Integer.parseInt(Character.toString(enrollmentData.memsData.get(0).gpHealthPlan.charAt(1))); 
		int dentalPlanGp=Integer.parseInt(Character.toString(enrollmentData.memsData.get(0).gpDentalPlan.charAt(1))); 

		currentYearEligibilityResultPage.gotoFindAPlanPage();

		ShopAndEnrollPage shopAndEnrollPage = new ShopAndEnrollPage(driver, testCaseId);
		shopAndEnrollPage.pageLoadAndClickOnSaveAndContinue();

		PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);

		HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
		DentalPlanShopingPage dentalPlanShopingPage = new DentalPlanShopingPage(driver, testCaseId);

		for(int i = 0; i < healthPlanGp; i++){
			healthPlanShopingPage.clickOnFindAPlanForShoppingGrp(i + 1);
			planFinderToolPage.pageLoadAndSkipPlanShopping();
			findAHealthOrDentalPlanPage.findAHealthPlanPageLoadAndClickOnAddToCart(1);
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
		}	             

		healthPlanShopingPage.pageLoadAndClickOnContinueBtn();

		for(int i = 0; i < dentalPlanGp; i++){
			dentalPlanShopingPage.clickOnFindAPlanForShoppingGrp(i + 1);
			planFinderToolPage.pageLoadAndSkipPlanShopping();
			findAHealthOrDentalPlanPage.findADentalPlanPageLoadAndClickOnAddToCart(1);
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
		}

		dentalPlanShopingPage.pageLoadAndClickOnContinueBtn();

		ReviewShoppingCartPage reviewShoppingCartPage = new ReviewShoppingCartPage(driver, testCaseId);
		reviewShoppingCartPage.pageLoadAndClickOnSaveAndContinue();

		ReviewApplicationPage reviewApplicationPage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPage.pageLoadAndClickOnSaveAndContinue();

		EnrollPage enrollPage = new EnrollPage(driver, testCaseId);
		enrollPage.enterHohSignAndContinue();

		MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver, testCaseId);
		myEnrollmentPage.verifyPageLoad();
		myEnrollmentPage.takeScreenshot();
	}
	

	/** @author Ritika 
	 * 
	 *  From Current Year Eligibility Result Page, Complete Shopping For "2" Group
	 *  
	 */
	
	@Given("^From Current Year Eligibility Result Page, Complete Shopping For \"(.*?)\" Group$")
	public void completeShoppingDetails(String gpNo) throws Exception {
		int groupSize = Integer.parseInt(gpNo);
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.gotoFindAPlanPage();

		ShopAndEnrollPage shopAndEnrollPage = new ShopAndEnrollPage(driver, testCaseId);
		shopAndEnrollPage.pageLoadAndClickOnSaveAndContinue();

		PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);

		HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
		DentalPlanShopingPage dentalPlanShopingPage = new DentalPlanShopingPage(driver, testCaseId);
		
		for(int i = 0; i < groupSize; i++){
			healthPlanShopingPage.clickOnFindAPlanForShoppingGrp(i + 1);
			planFinderToolPage.pageLoadAndSkipPlanShopping();
			findAHealthOrDentalPlanPage.findAHealthPlanPageLoadAndClickOnAddToCart(1);
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
		}
		
		healthPlanShopingPage.pageLoadAndClickOnContinueBtn();
		
		for(int i = 0; i < groupSize; i++){
			dentalPlanShopingPage.clickOnFindAPlanForShoppingGrp(i + 1);
			planFinderToolPage.pageLoadAndSkipPlanShopping();
			findAHealthOrDentalPlanPage.findADentalPlanPageLoadAndClickOnAddToCart(1);
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
		}
		
		dentalPlanShopingPage.pageLoadAndClickOnContinueBtn();
		
		ReviewShoppingCartPage reviewShoppingCartPage = new ReviewShoppingCartPage(driver, testCaseId);
		reviewShoppingCartPage.pageLoadAndClickOnSaveAndContinue();

		ReviewApplicationPage reviewApplicationPage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPage.pageLoadAndClickOnSaveAndContinue();

		EnrollPage enrollPage = new EnrollPage(driver, testCaseId);
		enrollPage.enterHohSignAndContinue();

		MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver, testCaseId);
		myEnrollmentPage.verifyPageLoad();
		myEnrollmentPage.takeScreenshot();
	}
	
	/**
	 * 
	 * From Current Year Eligibility Result Page, Complete "Health" Shopping For All Group With Total Group Count As "2"
	 * From Current Year Eligibility Result Page, Complete "Dental" Shopping For All Group With Total Group Count As "1"
	 * 
	 */
	
	@Given("^From Current Year Eligibility Result Page, Complete \"(.*?)\" Shopping For All Group With Total Group Count As \"(.*?)\"$")
	public void completeShoppingDetails_ForAllGroup(String shoppingType, String gpNo) throws Exception {
		int groupSize = Integer.parseInt(gpNo);
	             
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
	    currentYearEligibilityResultPage.gotoFindAPlanPage();

	    ShopAndEnrollPage shopAndEnrollPage = new ShopAndEnrollPage(driver, testCaseId);
	    shopAndEnrollPage.pageLoadAndClickOnSaveAndContinue();

	    PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
	    FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);

	    HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
	    DentalPlanShopingPage dentalPlanShopingPage = new DentalPlanShopingPage(driver, testCaseId);

	    if(shoppingType.equalsIgnoreCase("Health")) {
	    	for(int i = 0; i < groupSize; i++){
	    		healthPlanShopingPage.clickOnFindAPlanForShoppingGrp(i + 1);
	    		planFinderToolPage.pageLoadAndSkipPlanShopping();
	            findAHealthOrDentalPlanPage.findAHealthPlanPageLoadAndClickOnAddToCart(1);
	            findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
	    	}	             
	    }

	    healthPlanShopingPage.pageLoadAndClickOnContinueBtn();

	    if(shoppingType.equalsIgnoreCase("Dental")){
	    	for(int i = 0; i < groupSize; i++){
	    		dentalPlanShopingPage.clickOnFindAPlanForShoppingGrp(i + 1);
	    		planFinderToolPage.pageLoadAndSkipPlanShopping();
	            findAHealthOrDentalPlanPage.findADentalPlanPageLoadAndClickOnAddToCart(1);
	            findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
	    	}
	    }
	             
	    dentalPlanShopingPage.pageLoadAndClickOnContinueBtn();

	    ReviewShoppingCartPage reviewShoppingCartPage = new ReviewShoppingCartPage(driver, testCaseId);
	    reviewShoppingCartPage.pageLoadAndClickOnSaveAndContinue();

	    ReviewApplicationPage reviewApplicationPage = new ReviewApplicationPage(driver, testCaseId);
	    reviewApplicationPage.pageLoadAndClickOnSaveAndContinue();

	    EnrollPage enrollPage = new EnrollPage(driver, testCaseId);
	    enrollPage.enterHohSignAndContinue();

	    MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver, testCaseId);
	    myEnrollmentPage.verifyPageLoad();
	    myEnrollmentPage.takeScreenshot();
	}
	
	/** @author sshriv16
	 * 
	 *  From Current Year Eligibility Result Page, Update Health And Dental Shopping For "2" Shopping Groups
	 *  
	 */
	
	@Given("^From Current Year Eligibility Result Page, Update Health And Dental Shopping For \"(.*?)\" Shopping Groups$")
	public void completeNewShoppingDetails(String gpNo) throws Exception {
		int groupSize=Integer.parseInt(gpNo);
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.gotoFindAPlanPage();

		ShopAndEnrollPage shopAndEnrollPage = new ShopAndEnrollPage(driver, testCaseId);
		shopAndEnrollPage.pageLoadAndClickOnSaveAndContinue();

		PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);

		HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
		DentalPlanShopingPage dentalPlanShopingPage = new DentalPlanShopingPage(driver, testCaseId);
		
		for(int i = 0; i < groupSize; i++){
			healthPlanShopingPage.clickOnFindAPlanForShoppingGrp(i + 1);
			planFinderToolPage.pageLoadAndSkipPlanShopping();
			findAHealthOrDentalPlanPage.findAHealthPlanPageLoadAndClickOnAddToCart(2);
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
		}
		
		healthPlanShopingPage.pageLoadAndClickOnContinueBtn();
		
		for(int i = 0; i < groupSize; i++){		
			dentalPlanShopingPage.clickOnFindAPlanForShoppingGrp(i + 1);
			planFinderToolPage.pageLoadAndSkipPlanShopping();
			findAHealthOrDentalPlanPage.findADentalPlanPageLoadAndClickOnAddToCart(2);
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
		}
		
		dentalPlanShopingPage.pageLoadAndClickOnContinueBtn();
		
		ReviewShoppingCartPage reviewShoppingCartPage = new ReviewShoppingCartPage(driver, testCaseId);
		reviewShoppingCartPage.pageLoadAndClickOnSaveAndContinue();

		ReviewApplicationPage reviewApplicationPage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPage.pageLoadAndClickOnSaveAndContinue();

		EnrollPage enrollPage = new EnrollPage(driver, testCaseId);
		enrollPage.enterHohSignAndContinue();

		MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver, testCaseId);
		myEnrollmentPage.verifyPageLoad();
		myEnrollmentPage.takeScreenshot();
	}
	

	/** @author Ritika
	 * 
	 * From Current Year Eligibility Result Page, Complete Change Shopping
	 * | Group | HealthPlanName    | DentalPlanName |
	 * | 3     | Tufts Health Plan | Altus Dental	|
	 * 
	 */
	
	@Given("^From Current Year Eligibility Result Page, Complete Change Shopping$")
	public void completeChangeShoppingDetails(DataTable table) throws Exception {
		List<List<String>> scenarioData = table.raw();
		
		String gpNo = scenarioData.get(1).get(0);		
		int groupSize = Integer.parseInt(gpNo);
		
		String hltPlan =scenarioData.get(1).get(1).trim();
		String dtlPlan =scenarioData.get(1).get(2).trim();
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.clickOnChangeEnrollmentAndoToMyEnrollmentPage();
		
		MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver,testCaseId);
		myEnrollmentPage.clickOnSubmitButton();
		myEnrollmentPage.clickOnChangeEnrollmentButton();
		myEnrollmentPage.clickOnDialogOkButton();
	 
		ShopAndEnrollPage shopAndEnrollPage = new ShopAndEnrollPage(driver, testCaseId);
		shopAndEnrollPage.pageLoadAndClickOnSaveAndContinue();

		PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);

		HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
		DentalPlanShopingPage dentalPlanShopingPage = new DentalPlanShopingPage(driver, testCaseId);
		
		for(int i = 0; i < groupSize; i++){
			healthPlanShopingPage.clickOnFindAPlanForShoppingGrp(i + 1);
			planFinderToolPage.pageLoadAndSkipPlanShopping();
			findAHealthOrDentalPlanPage.selectShoppingPlan(hltPlan);
			findAHealthOrDentalPlanPage.clickOnApplyBtn();
			findAHealthOrDentalPlanPage.findAHealthPlanPageLoadAndClickOnAddToCart(1);
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
		}
		
		healthPlanShopingPage.pageLoadAndClickOnContinueBtn();
		
		for(int i = 0; i < groupSize; i++){
			dentalPlanShopingPage.clickOnFindAPlanForShoppingGrp(i + 1);
			planFinderToolPage.pageLoadAndSkipPlanShopping();
			findAHealthOrDentalPlanPage.selectShoppingPlan(dtlPlan);
			findAHealthOrDentalPlanPage.clickOnApplyBtn();
			findAHealthOrDentalPlanPage.findADentalPlanPageLoadAndClickOnAddToCart(1);
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
		}
		
		dentalPlanShopingPage.pageLoadAndClickOnContinueBtn();
		
		ReviewShoppingCartPage reviewShoppingCartPage = new ReviewShoppingCartPage(driver, testCaseId);
		reviewShoppingCartPage.pageLoadAndClickOnSaveAndContinue();

		ReviewApplicationPage reviewApplicationPage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPage.pageLoadAndClickOnSaveAndContinue();

		EnrollPage enrollPage = new EnrollPage(driver, testCaseId);
		enrollPage.enterHohSignAndContinue();

		myEnrollmentPage.verifyPageLoad();
		myEnrollmentPage.takeScreenshot();
	}

	@Given("^From Current Year Eligibility Result Page, Cancel Enrollment$")
	public void completeCancelShopping() throws Exception {
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.clickOnChangeEnrollmentAndoToMyEnrollmentPage();
		
		MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver,testCaseId);
		myEnrollmentPage.clickOnSubmitButton();
		myEnrollmentPage.clickOnCancelEnrollmentButton();
		myEnrollmentPage.clickOnDialogOkButton();
	}
	
	/** @author Ritika
	 * 
	 * @param shoppingType - Health,Dental
	 * 
	 * From Current Year Eligibility Result Page, Complete "Health" Shopping For Group "1"
	 * From Current Year Eligibility Result Page, Complete "Dental" Shopping For Group "2"
	 * 
	 */
	
	@Given("^From Current Year Eligibility Result Page, Complete \"(.*?)\" Shopping For Group \"(.*?)\"$")
	public void completeShoppingDetails(String shoppingType,String gpNo) throws Exception {
		int groupNo=Integer.parseInt(gpNo);
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.gotoFindAPlanPage();

		ShopAndEnrollPage shopAndEnrollPage = new ShopAndEnrollPage(driver, testCaseId);
		shopAndEnrollPage.pageLoadAndClickOnSaveAndContinue();

		PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);

		HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
		DentalPlanShopingPage dentalPlanShopingPage = new DentalPlanShopingPage(driver, testCaseId);

		if(shoppingType.equalsIgnoreCase("Health")){
			healthPlanShopingPage.clickOnFindAPlanForShoppingGrp(groupNo);
			planFinderToolPage.pageLoadAndSkipPlanShopping();
			findAHealthOrDentalPlanPage.findAHealthPlanPageLoadAndClickOnAddToCart(1);
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
		}
		
		healthPlanShopingPage.pageLoadAndClickOnContinueBtn();

		if(shoppingType.equalsIgnoreCase("Dental")){
			dentalPlanShopingPage.clickOnFindAPlanForShoppingGrp(groupNo);
			planFinderToolPage.pageLoadAndSkipPlanShopping();
			findAHealthOrDentalPlanPage.findADentalPlanPageLoadAndClickOnAddToCart(1);
			findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
		}

		dentalPlanShopingPage.pageLoadAndClickOnContinueBtn();

		ReviewShoppingCartPage reviewShoppingCartPage = new ReviewShoppingCartPage(driver, testCaseId);
		reviewShoppingCartPage.pageLoadAndClickOnSaveAndContinue();

		ReviewApplicationPage reviewApplicationPage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPage.pageLoadAndClickOnSaveAndContinue();

		EnrollPage enrollPage = new EnrollPage(driver, testCaseId);
		enrollPage.enterHohSignAndContinue();

		MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver, testCaseId);
		myEnrollmentPage.verifyPageLoad();
		myEnrollmentPage.takeScreenshot();
	}
	
	@Given("^From Current Year Eligibility Result Page, Take Screenshot$")
	public void takeScreenshot() throws Exception {
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.takeScreenshot();
	}
	
	/**
	 * 
	 * This type of warning appear if Propogation period is ON and system want to create next year app out of current year.
	 * 
	 */
	
	@Given("^From Current Year Eligibility Result Page, Handle Warning Dialog If Present$")
	public void handleWarningDialogIfPresent() throws Exception {
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.handleWarningDialogIfPresent();
	}
	
	@Given("^From Current Year Eligibility Result Page, Go to CanIShop$")
	public void completeQLEDetails() throws Exception {
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.gotoQLEPage();
	}
	
	@Given("^From Current Year Eligibility Result Page, Go to Medical HH Details$")
	public void gotoShowMedicaidHHDetails() throws Exception {
			CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
			currentYearEligibilityResultPage.gotoShowMedicaidHHDetails();
	}
	
	//Amrita
	@Given("^From Current Year Eligibility Result Page, Go to Medicaid Notice Screen$")
	public void gotoMedicaidNotice() throws Exception {
			CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
			currentYearEligibilityResultPage.gotoShowMedicaidNotices();
	}
	
	@Given("^From Current Year Eligibility Result Page, Click On Back To EligibilityApplicationsBtn$")
	public void clickOnBackToEligibilityApplicationsBtn() throws Exception {
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.clickOnBackToEligibilityApplicationsBtn();
	}
	
	/** @author vkuma212
	 * 
	 * @param TAXHHNo: 1,2,3,4
	 * @param FPL Value: 220.50%
	 *
	 * From Current Year Eligibility Result Page, Validate FPL Based On Self Reported Income As "102.34%" For TaxHH "1"
	 *
	 */
	
	@Given("^From Current Year Eligibility Result Page, Validate FPL Based On Self Reported Income As \"(.*?)\" For TaxHH \"(.*?)\"$")
	public void validateFPLForTaxHHBasedOnSelfReportedIncome(String expFPL, String strTaxHH) throws Exception {		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		int taxHHNo = Integer.parseInt(strTaxHH);
		currentYearEligibilityResultPage.validateFPLForTaxHHBasedOnSelfReportedIncome(taxHHNo, expFPL);
	}
	
	/**@author vinay
	 * 
	 * @param TaxHHNo: 1,2,3,4
	 * @param TAX House Hold Size Value: 1,2,3,4 
	 * @param TAX House Hold Income Value: 2000, 2300.35
	 * @throws Exception
	 * 
	 * From Current Year Eligibility Result Page, Validate TAX FPL Based On Self Reported Income For TaxHH "1", With HouseHold Size As "5" and Household Income As "50000.67"
	 *
	 */
	
	@When("^From Current Year Eligibility Result Page, Validate TAX FPL Based On Self Reported Income For TaxHH \"(.*?)\", With HouseHold Size As \"(.*?)\" and Household Income As \"(.*?)\"$")
	public void validateFPLForTaxHHBasedOnSelfReportedIncomeUsingCalculator(String taxHHNo, String taxHHSize, String hhIncome) throws Exception {
		int intTaxHHNo = Integer.parseInt(taxHHNo);
		int intTaxHHSize = Integer.parseInt(taxHHSize);
		
		double doubleHhIncome = Double.parseDouble(hhIncome);
		
		String year = globalData.get("TaxFPLCalculatorForYear").trim();
		int intYear = Integer.parseInt(year);
		
		String taxFPL = FPLCalculator.getTaxFPLUsingCalculator(intYear, intTaxHHSize, doubleHhIncome);
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.validateFPLForTaxHHBasedOnSelfReportedIncome(intTaxHHNo, taxFPL);
	}
	
	/**@author vkuma212
	 * 
	 * @param TAXHHNo: 1,2,3,4
	 * @param FPL Value: 430.00%
	 *
	 * From Current Year Eligibility Result Page, Validate FPL Used To Decide PE "430.00%" For TaxHH "1"
	 *
	 */
	
	@Given("^From Current Year Eligibility Result Page, Validate FPL Used To Decide PE \"(.*?)\" For TaxHH \"(.*?)\"$")
	public void validateFPLForTaxHHUsedToDecidePE(String expFPL, String strTaxHH) throws Exception {		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		int taxHHNo = Integer.parseInt(strTaxHH);
		currentYearEligibilityResultPage.validateFPLForTaxHHUsedToDecidePE(taxHHNo, expFPL);
	}
	
	/**@author vinay
	 * 
	 * @param TaxHHNo: 1,2,3,4
	 * @param TAX House Hold Size Value: 1,2,3,4 
	 * @param TAX House Hold Income Value: 2000, 2300.35
	 * @throws Exception
	 * 
	 * From Current Year Eligibility Result Page, Validate TAX FPL Used To Decide PE For TaxHH "1", With HouseHold Size As "5" and Household Income As "50000.67"
	 *
	 */
	
	@When("^From Current Year Eligibility Result Page, Validate TAX FPL Used To Decide PE For TaxHH \"(.*?)\", With HouseHold Size As \"(.*?)\" and Household Income As \"(.*?)\"$")
	public void validateFPLForTaxHHUsedToDecidePEUsingCalculator(String taxHHNo, String taxHHSize, String hhIncome) throws Exception {
		int intTaxHHNo = Integer.parseInt(taxHHNo);
		int intTaxHHSize = Integer.parseInt(taxHHSize);
		
		double doubleHhIncome = Double.parseDouble(hhIncome);
		
		String year = globalData.get("TaxFPLCalculatorForYear").trim();
		int intYear = Integer.parseInt(year);
		
		String taxFPL = FPLCalculator.getTaxFPLUsingCalculator(intYear, intTaxHHSize, doubleHhIncome);
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.validateFPLForTaxHHUsedToDecidePE(intTaxHHNo, taxFPL);
	}
	
	/**@author vverma25
	 * 
	 * @param PD: MassHealth Standard
	 *     		  MassHealth CommonHealth
	 *     		  MassHealth Family Assistance
	 *     		  MassHealth CarePlus 
	 *     		  Children's Medical Security Plan
	 *     		  HealthConnector with APTC
	 *     		  Health connector Plans
	 *			  ConnactorCare Plus
	 *            Health Safety Net Full
	 *            Health Safety Net Partial
	 * 
	 * @param TAXHHNo: 1,2,3,4
	 * @param MemberNo: -1,2,3,4
	 * 
	 *  From Current Year Eligibility Result Page, For TaxHH "1" and Member "1" , Validate That PD "MassHealth Standard" 
	 * 
	 */
	
	@Given("^From Current Year Eligibility Result Page, For TaxHH \"(.*?)\" and Member \"(.*?)\" , Validate That PD \"(.*?)\"$")
	public void validatePDForMemberInTaxHH(int taxHHNo,int memNo,String expPrg) throws Exception {		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.validatePDForMemberInTaxHH(taxHHNo, memNo, expPrg);		
	}
	
	
	/**@author ppinho
	 * 
	 * @param TAXHHNo: -1,2,3,4
	 * @param APTC Amount Value: 108.00
	 *
	 * From Current Year Eligibility Result Page, Validate APTC Amount As $ "108.00" For TaxHH "1"
	 * 
	 */
	
	@Given("^From Current Year Eligibility Result Page, Validate APTC Amount As \"(.*?)\" For TaxHH \"(.*?)\"$")
	public void validateAPTCamountForTaxHH(String expFPL, String strTaxHH) throws Exception {		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);			
		int taxHHNo = Integer.parseInt(strTaxHH);
		currentYearEligibilityResultPage.validateAPTCamountForTaxHH(taxHHNo, expFPL);
	}

	/**@author Ritu
	 * 
	 * From Current Year Eligibility Result Page, For TaxHH "1" and Member "1" , Validate That No RFI Is Present
	 * 
	 */
	
	@Given("^From Current Year Eligibility Result Page, For TaxHH \"(.*?)\" and Member \"(.*?)\" , Validate That No RFI Is Present$")
    public void ValidateNoRFI_ForMemberInTaxHH_Present(int taxHHNo, int memNo) throws Exception {          
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.ValidateNORFI_ForMemberInTaxHH_Present(taxHHNo, memNo);          
    }

	/**@author vverma25
	 * 
	 * @param TAXHHNo: 1,2,3,4
	 * @param MemberNo: 1,2,3,4
	 * @param RFI: Proof of Residency
	 * 			   Proof of Income
	 * 			   Proof of Immigration
	 *             Proof of Social Security Number
	 *             Proof of U.S. Citizenship Status
	 *             Completion of the Non-Custodial Parent Form
	 *             NCP-1           // short form for above word in bracket
	 * 			   Proof of Address 
	 * 			   Proof of Incarceration
	 * 			   Proof of AI/AN
	 * 
	 *	From Current Year Eligibility Result Page, For TaxHH "1" and Member "2" , Validate That RFI "Proof of Residency" Is Present
	 * 
	 */
	
	@Given("^From Current Year Eligibility Result Page, For TaxHH \"(.*?)\" and Member \"(.*?)\" , Validate That RFI \"(.*?)\" Is Present$")
	public void ValidateRFI_ForMemberInTaxHH_Present(int taxHHNo, int memNo, String expRfi) throws Exception {		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.ValidateRFI_ForMemberInTaxHH_Present(taxHHNo, memNo, expRfi);		
	}
	
	/**@author vverma2
	 * 
	 * @param TAXHHNo: -1,2,3,4
	 * @param MemberNo: -1,2,3,4
	 * @param RFI: Proof of Residency 
	 * 			   Proof of Income
	 * 			   Proof of Immigration
	 *             Proof of Social Security Number
	 *             Proof of U.S. Citizenship Status
	 *             Proof of NCP
	 * 			   Proof of Address 
	 * 			   Proof of Incarceration
	 * 			   Proof of AI/AN		  
	 * 
	 *	From Current Year Eligibility Result Page, For TaxHH "1" and Member "1" , Validate That RFI "Proof of Residency" Is Not Present
	 *
	 */
	
	@Given("^From Current Year Eligibility Result Page, For TaxHH \"(.*?)\" and Member \"(.*?)\" , Validate That RFI \"(.*?)\" Is Not Present$")
	public void ValidateRFI_ForMemberInTaxHH_NotPresent(int taxHHNo, int memNo, String expRfi) throws Exception {
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.ValidateRFI_ForMemberInTaxHH_NotPresent(taxHHNo, memNo, expRfi);
	}
	
	
	/**@author vverma25
	 * 
	 * @param TAXHHNo: 1,2,3,4
	 * @param MemberNo: -1,2,3,4
	 * @param RFI: Proof of Residency
	 * 			   Proof of Income
	 * 			   Proof of Immigration
	 *             Proof of Social Security Number
	 *             Proof of U.S. Citizenship Status
	 *             Proof of NCP
	 *             Proof of NCP
	 * 			   Proof of Address 
	 * 			   Proof of Incarceration
	 * 			   Proof of AI/AN
	 * @param Status: Active
	 *    			  Expired
	 *    
	 *	From Current Year Eligibility Result Page, For TaxHH "1" and Member "1" and RFI "Proof of Residency" , Validate That Status "Active" Is Present
	 * 
	 */
	
	@Given("^From Current Year Eligibility Result Page, For TaxHH \"(.*?)\" and Member \"(.*?)\" and RFI \"(.*?)\" , Validate That Status \"(.*?)\" Is Present$")
	public void ValidateRFIstatus_ForMemberInTaxHH_Present(int taxHHNo, int memNo, String rfi, String expStatus) throws Exception {		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.ValidateRFIstatus_ForMemberInTaxHH_Present(taxHHNo, memNo, rfi, expStatus);		
	}
	
	/**@author ppinho
	 * 
	 * @param TAXHHNo: 1,2,3,4
	 * @param MemberNo: -1,2,3,4
	 * @param RFI: Proof of New legal dependent
	 * 
	 *	From Current Year Eligibility Result Page, For TaxHH "1" and Member "3" Documents Required As "Proof of New legal dependent" Is Present
	 * 
	 */
		
	@Given("^From Current Year Eligibility Result Page, For TaxHH \"(.*?)\" and Member \"(.*?)\" Documents Required As \"(.*?)\" Is Present$")
	public void ValidateQLERFIstatus_ForMemberInTaxHH_Present(int taxHHNo, String memNos, String expRFI) throws Exception {
		String[] arrMemNos = memNos.split(",");
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		String eligibilityId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);	
		
		for(int mCounter = 0; mCounter < arrMemNos.length; mCounter++){
			int memIndex = Integer.parseInt(arrMemNos[mCounter]) - 1;
			
			String fName = elgMemberTable.getFirstName(eligibilityId, memIndex);
			String lName = elgMemberTable.getLastName(eligibilityId, memIndex);
			
			CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
				
			currentYearEligibilityResultPage.ValidateQLERFIstatus_ForMemberInTaxHH_Present(taxHHNo, fName, lName, expRFI);
		}			
	}

	@Given("^From Current Year Eligibility Result Page, Click On Application Summary Button$")
	public void clickOnApplicationSummaryBtn() throws Exception {
			CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
			currentYearEligibilityResultPage.clickOnApplicationSummaryBtn();
	}
	
	@Given("^From Current Year Eligibility Result Page, Click On Find A Plan$")
	public void clickOnFindAPlanBtn() throws Exception {
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.clickOnFindAPlanBtn();
	}

	/** @author Ritu
	 * 
     * From Current Year Eligibility Result Page, Click On Find A Plan And Go To Health Plan Shopping Page
     * 
     */
	
     @Given("^From Current Year Eligibility Result Page, Click On Find A Plan And Go To Health Plan Shopping Page$")
     public void clickOnFindAPkan() throws Exception {           
           CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
           currentYearEligibilityResultPage.gotoFindAPlanPage();

           ShopAndEnrollPage shopAndEnrollPage = new ShopAndEnrollPage(driver, testCaseId);
           shopAndEnrollPage.pageLoadAndClickOnSaveAndContinue();
     }
     
	/** @author rgupta64
	*
	* From Current Year Eligibility Result Page, Enter AdminSEP Details For Member "1", With Reason As "Other exceptional circumstances"
	*
	*/

	@Given("^From Current Year Eligibility Result Page, Enter AdminSEP Details For Member \"(.*?)\" , With Reason As \"(.*?)\"$")
	public void enterAdminSEPDetails(String memNo, String reason) throws Exception {
		int memIndex = Integer.parseInt(memNo);
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.clickOnAdminSEPBtn();

		AdminSEPPage adminSEP= new AdminSEPPage(driver, testCaseId);
		adminSEP.enterAdminSEPDetails(memIndex, reason, "abc");
	}
	
	
	public void setMemberNames() throws Exception {
		for(int i = 0; i < evpdData.memsData.size(); i++){
			evpdData.memsData.get(i).firstName = TestData.getTempTestData("Mem_" + (i + 1) + "_FirstName", featureFileName);			
			evpdData.memsData.get(i).lastName = TestData.getTempTestData("Mem_" + (i + 1) + "_LastName", featureFileName);
			
			if(i == 0){
				evpdData.memsData.get(i).middleName = TestData.getTempTestData("Mem_" + (i + 1) + "_MidName", featureFileName);
				
				if(!evpdData.memsData.get(0).middleName.isEmpty()){
					evpdData.memsData.get(0).fullName = evpdData.memsData.get(0).firstName + " " + evpdData.memsData.get(0).middleName + " " + evpdData.memsData.get(0).lastName;
				}else{
					evpdData.memsData.get(0).fullName = evpdData.memsData.get(0).firstName + " " + evpdData.memsData.get(0).lastName;
				}
			}else{
				evpdData.memsData.get(i).fullName = evpdData.memsData.get(i).firstName + " " + evpdData.memsData.get(i).lastName;
			}
		}
	}
	
	public List<PA_MemData> emptyPaData(int memCount) throws Exception {
		List<PA_MemData> memsData = new ArrayList<PA_MemData>();
		
		for(int i = 0; i < memCount; i++){
			memsData.add(new PA_MemData());
		}
		
		for(int i = 0; i < memCount; i++){
			memsData.get(i).tplStatus = null;
			memsData.get(i).basicBenefitLevel = false;
			memsData.get(i).enrolledInMH = false;
			memsData.get(i).coverageType = null;
		}
		
		return memsData;
	}
	
	public void sendPdDataToDb(int memInd) throws Exception {
		String ipAddress = globalData.get("Local_IP_Address").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		String schema = globalData.get("mysql_schema").trim();
		
		HttpsClient httpClient = new HttpsClient();
		TempData tempData = new TempData();
		
		String table = getTempTestData("DataSet") + "_evpd";
		String programDetermination = null;
		String aidCat = null;
		
		if(!evpdData.memsData.get(memInd).mhAidCat.isEmpty()){
			aidCat = evpdData.memsData.get(memInd).mhAidCat;				
		}else{
			aidCat = evpdData.memsData.get(memInd).ccaAidCat;
		}
		
		if(!evpdData.memsData.get(memInd).mhAidCat.isEmpty()){
			programDetermination = evpdData.memsData.get(memInd).mhProgramDetermination;		
		}else{
			programDetermination = evpdData.memsData.get(memInd).ccaProgramDetermination + " " + 
								   evpdData.memsData.get(memInd).mhProgramDetermination;
		}
		
		tempData.sqlScript = "update " + schema + "." + table + 
	 			 " set " + table + ".ms_aid_cat = '" + aidCat + "', " +
	 			 		   table + ".ms_program_determination = '" + programDetermination + "' " +
	 			 " where " + table + ".scenario = '" + featureFileName + "'" +
	 			 " and " + table + ".mem_id = '" + evpdData.memsData.get(memInd).memId + "'";	
				
		httpClient.updateTempDataMS(ipAddress, username, password, getTempTestData("DataSet"), TempData.updateTempDataRequest(tempData));
	}
}
