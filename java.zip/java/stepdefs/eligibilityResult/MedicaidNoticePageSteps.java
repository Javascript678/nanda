package stepdefs.eligibilityResult;

import cucumber.api.java.en.Given;
import pages.eligibilityResult.MedicaidNoticePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;


public class MedicaidNoticePageSteps extends SuperStepDef{
	
	public MedicaidNoticePageSteps(Hook hook){
		super(hook);
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@Given("^From Medicaid Notices Page, Take Screenshot$")
	public void takeScreenShot() throws Exception {
		MedicaidNoticePage medicaidNoticePage = new MedicaidNoticePage(driver, testCaseId);
		medicaidNoticePage.takeScreenShot();
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@Given("^From Medicaid Notices Page, Verify no medicaid notices are generated$")
	public void noMedicaidNotice() throws Exception {
		MedicaidNoticePage medicaidNoticePage = new MedicaidNoticePage(driver, testCaseId);
		medicaidNoticePage.verifyNoNoticeMsg();
	}
	
	
}
