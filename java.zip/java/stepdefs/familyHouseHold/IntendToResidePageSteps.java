package stepdefs.familyHouseHold;
import cucumber.api.java.en.When;
import pages.familyHouseHold.IntendToResidePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class IntendToResidePageSteps extends SuperStepDef{
	
	public IntendToResidePageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Intend To Reside Page, Enter Address For Member$")
	public void selectMembersIntendToResideOutsideMA() throws Exception {
		IntendToResidePage intendToResidePage = new IntendToResidePage(driver, testCaseId);
		intendToResidePage.selectMembersIntendToResideOutsideMA(evpdData.memsData);		
	}
	
	/**
	 *  Accepted Value :- MemNos :- 1,2,3,4,5
	
	From Intend To Reside Page, Select Members "1,2,3,4" Intend To Reside In MA And Continue
	
	 */
	@When("^From Intend To Reside Page, Select Members \"(.*?)\" Intend To Reside In MA And Continue$")
	public void selectIntendToResideChkBxForMember(String memNos) throws Exception{
		String[] arrMemNos = memNos.split(",");
		
		IntendToResidePage intendToResidePage = new IntendToResidePage(driver, testCaseId);

		for(int mCounter=0; mCounter<arrMemNos.length; mCounter++){
			int memIndex = Integer.parseInt(arrMemNos[mCounter])-1;
			
			intendToResidePage.selectIntendToResideChkBxForMember(memIndex);
		}
		intendToResidePage.clickOnSaveAndContinueBtn();
	}
	
	@When("^From Intend To Reside Page, Select None Of These People Intend To Reside In MA And Continue$")
		public void selectNoneOfTheseChkBox() throws Exception{
		IntendToResidePage intendToResidePage = new IntendToResidePage(driver, testCaseId);
		intendToResidePage.waitForPageLoaded();
		intendToResidePage.selectNoMemIntendToResideChkBx();
		intendToResidePage.clickOnSaveAndContinueBtn();
	}
	
	@When("^From Intend To Reside Page, Page Load And Click On Save And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		
		IntendToResidePage intendToResidePage = new IntendToResidePage(driver, testCaseId);
		intendToResidePage.pageLoadAndClickOnSaveAndContinueBtn();
	}
}
