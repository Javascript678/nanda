package stepdefs.familyHouseHold;
import cucumber.api.java.en.When;
import pages.familyHouseHold.IsAnyOneInJailPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class IsAnyoneInJailPageSteps extends SuperStepDef{
	
	public IsAnyoneInJailPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Is Any One In Jail Page, Provide Details For Member$")
	public void provideDetailIfAnyMemberInJail() throws Exception {
		IsAnyOneInJailPage isAnyOneInJailPage = new IsAnyOneInJailPage(driver, testCaseId);
		isAnyOneInJailPage.provideDetailIfAnyMemberInJail(evpdData.memsData);
	}
	
	@When("^From Is Any One In Jail Page, Consider No One In Jail and Continue$")
	public void provideDetailsAsNoOneInJail() throws Exception {
		
		IsAnyOneInJailPage isAnyOneInJailPage = new IsAnyOneInJailPage(driver, testCaseId);
		isAnyOneInJailPage.selectIfNoOneIncarcerated(true);
		isAnyOneInJailPage.clickOnSaveAndContinueBtn();
	}
		
	/**Shailza
	 
	  From Is Any One In Jail Page, Select The Members Who Are In Jail As "1,2,3" And Awaiting Trial As "TRUE"
	  From Is Any One In Jail Page, Select The Members Who Are In Jail As "2" And Awaiting Trial As "FALSE"
	 
	 */
	
	@When("^From Is Any One In Jail Page, Select The Members Who Are In Jail As \"(.*?)\" And Awaiting Trial As \"(.*?)\"$")
    public void selectMembersWhoAreInJail(String members, String awaitingTrial) throws Exception {
          String[] arrMemNos = members.trim().split(",");
          Boolean trueFalseValue = awaitingTrial.equalsIgnoreCase("TRUE")?true:false;
          IsAnyOneInJailPage isAnyOneInJailPage = new IsAnyOneInJailPage(driver, testCaseId);
          isAnyOneInJailPage.selectIfNoOneIncarcerated(false);
          
          for (int mCounter = 0; mCounter < arrMemNos.length; mCounter++) {

                 int memIndex = Integer.parseInt(arrMemNos[mCounter]) - 1;
                 isAnyOneInJailPage.selectInJailChkBxForMember(memIndex);
                 isAnyOneInJailPage.selectIfMemberAwaitingTrial(memIndex, trueFalseValue);
          }
          
          isAnyOneInJailPage.clickOnSaveAndContinueBtn();
    }

	
	@When("^From Is Any One In Jail Page, Click On Save and Continue$")
	public void SaveAndContinue() throws Exception {		
		IsAnyOneInJailPage isAnyOneInJailPage = new IsAnyOneInJailPage(driver, testCaseId);
		isAnyOneInJailPage.clickOnSaveAndContinueBtn();
	}
}
