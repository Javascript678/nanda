package stepdefs.familyHouseHold;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import enums.PortalName;
import enums.TrueFalseValue;
import pages.familyHouseHold.AddressDetailsPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class AddressDetailsPageSteps extends SuperStepDef{
	
	public AddressDetailsPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Address Details Page, Enter Address For Member$")
	public void enterAddressDetailsForMembers() throws Exception {		
		AddressDetailsPage addressDetailsPage = new AddressDetailsPage(driver, testCaseId);
		addressDetailsPage.enterAddressDetailsForMembers(evpdData.whoIsApplying, evpdData.memsData);
	}
	
	@When("^From Address Details Page, Consider Address For All Member As Same As HOH And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		
		AddressDetailsPage addressDetailsPage = new AddressDetailsPage(driver, testCaseId);
		addressDetailsPage.pageLoadThenClickOnSaveAndContinueBtn();
		
	}
	
	/**@author akumari4
	 * 
	 From Address Details Page, Select No Home Address For Member "2"
	 * @param memNo
	 * @throws Exception
	 */
	@When("^From Address Details Page, Select No Home Address For Member \"(.*)\"$")
	public void selectNoHomeAddressForMember(String memNo) throws Exception {
		
		AddressDetailsPage addressDetailsPage = new AddressDetailsPage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		addressDetailsPage.clickOnNoHomeAddressForMember(memIndex);
		
	}
	
	/**@author akumari4
	 * 
	    From Address Details Page, Select Members "2,3" Is Living At Different Address Than HOH
	 * @param memNos
	 * @throws Exception
	 */
	@When("^From Address Details Page, Select Members \"(.*)\" Is Living At Different Address Than HOH$")
	public void enterOtherAddressMembers(String memNos) throws Exception {
		
		String arrMemNos[]  = memNos.split(",");
		AddressDetailsPage addressDetailsPage = new AddressDetailsPage(driver, testCaseId);
		for(int mCounter=0; mCounter<arrMemNos.length; mCounter++){
			int memIndex = Integer.parseInt(arrMemNos[mCounter])-1;
		addressDetailsPage.clickOnOtherAddressChkBxForMember(memIndex);
		
	}
	}
	
	/**@author akumari4
	 * 
	    From Address Details Page, Enter Address Details For Members "2,3" Living At Address Than HOH
	 * @param memNos
	 * @throws Exception
	 */
	@When("^From Address Details Page, Enter Address Details For Members \"(.*)\" Living At Address Than HOH$")
	public void enterOtherAddressDetailsForMembers(String memNos) throws Exception {
		
		String arrMemNos[]  = memNos.split(",");
		String StreetAddress = globalData.get("MemberNotLivingWithHOH_StreetAddress");
		String city = globalData.get("MemberNotLivingWithHOH_City");
		String zip = globalData.get("MemberNotLivingWithHOH_Zip");
		String county = globalData.get("MemberNotLivingWithHOH_County");
		
		AddressDetailsPage addressDetailsPage = new AddressDetailsPage(driver, testCaseId);
		for(int mCounter=0; mCounter<arrMemNos.length; mCounter++)
		{
		   int memIndex = Integer.parseInt(arrMemNos[mCounter])-1;
		   addressDetailsPage.enterPrimaryAddressStreetForMember(memIndex, StreetAddress);
		   addressDetailsPage.enterPrimaryCityForMember(memIndex, city);
		   addressDetailsPage.enterPrimaryZipForMember(memIndex, zip);
		   addressDetailsPage.selectPrimaryCountyForMember(memIndex, county);
		}
}
	
	/**@author akumari4
	  
	  From Address Details Page, Click On USPS For Member "2" On Portal As "A"
	  
	 * @param memno
	 * @throws Exception
	 */
	@Given("^From Address Details Page, Click On USPS For Member \"(.*)\" On Portal As \"(.*)\"$")
	public void clickOnUSPSforMember(String memno, String portal) throws Exception {
		int memIndex = Integer.parseInt(memno)-1;

		AddressDetailsPage addressDetailsPage = new AddressDetailsPage(driver, testCaseId);
		Boolean individualByPassUsps = envData.get("Individual_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		Boolean agentByPassUsps = envData.get("Agent_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		Boolean assisterByPassUsps = envData.get("Assister_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		
		Boolean byPassUsps=false;
		if(portal.equals(PortalName.INDIVIDUAL.code)){
			byPassUsps = individualByPassUsps;
		}else if(portal.equals(PortalName.AGENT.code)){
			byPassUsps = agentByPassUsps;
		}if(portal.equals(PortalName.ASSISTER.code)){
			byPassUsps = assisterByPassUsps;
		}
		
		if(byPassUsps==false){
			addressDetailsPage.clickOnUSPSOtherAddressForMember(memIndex);
			addressDetailsPage.clickOnOkBtn();
		}
		
	}

	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@Given("^From Address Details Page, Take Screenshot$")
	public void taksScreenShot() throws Exception {
		AddressDetailsPage addressDetailsPage = new AddressDetailsPage(driver, testCaseId);
		addressDetailsPage.taksScreenShot();
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@When("^From Address Details Page, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception {
		
		AddressDetailsPage addressDetailsPage = new AddressDetailsPage(driver, testCaseId);
		addressDetailsPage.pageLoadThenClickOnSaveAndContinueBtn();
		
	}

}
