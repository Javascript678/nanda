package stepdefs.familyHouseHold;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import pages.familyHouseHold.EnterHHMemRelationshipPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class EnterHHMemberRelationshipPageSteps extends SuperStepDef{
	
	public EnterHHMemberRelationshipPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Enter HH Member Relationship Page, Select Members Relationship$")
	public void selectMemsRelationship() throws Exception {		
		EnterHHMemRelationshipPage enterHHMemRelationshipPage = new EnterHHMemRelationshipPage(driver, testCaseId);
		enterHHMemRelationshipPage.selectMemsRelationship(evpdData.memsData);		
	}
	
	/**
	 * 
	 * @param table
	 * @throws Exception
	 */
	@When("^From Enter HH Member Relationship Page, Select Members Relationship With Others$")
	public void selectMemsRelationshipWithOthers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		int colCount = scenarioData.get(0).size();
		
		EnterHHMemRelationshipPage enterHHMemRelationshipPage = new EnterHHMemRelationshipPage(driver, testCaseId);
		
		for(int rowIndex=1;rowIndex<rowCount-1;rowIndex++){
			int mem1Index = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			
			for(int columnIndex=rowIndex+1; columnIndex < colCount;  columnIndex++){
				int mem2Index = columnIndex-1;
				String relationship = scenarioData.get(rowIndex).get(columnIndex);
				enterHHMemRelationshipPage.selectMemsRelationship(mem1Index, mem2Index, relationship);	
			}
			enterHHMemRelationshipPage.clickOnSaveAndContinueBtn();
		}
	}
	
	/**@author akumari4
	 * 
	 From Enter HH Member Relationship Page, Relation Between Member "5" And Member "6" Is "Unrelated"
	 * @param mem1No
	 * @param mem2No
	 * @param relationship
	 * @throws Exception
	 */
	@When("^From Enter HH Member Relationship Page, Relation Between Member \"(.*)\" And Member \"(.*)\" Is \"(.*)\"$")
	public void selectRaceForMembers(String mem1No, String mem2No, String relationship) throws Exception{
		EnterHHMemRelationshipPage enterHHMemRelationshipPage = new EnterHHMemRelationshipPage(driver, testCaseId);
		int mem1Index = Integer.parseInt(mem1No)-1;
		int mem2Index = Integer.parseInt(mem2No)-1;
		enterHHMemRelationshipPage.selectMemsRelationship(mem1Index, mem2Index, relationship);
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@When("^From Enter HH Member Relationship Page, Click On Save and Continue$")
	public void clickOnSaveAndContinue() throws Exception {
		
		EnterHHMemRelationshipPage enterHHMemRelationshipPage = new EnterHHMemRelationshipPage(driver, testCaseId);
		enterHHMemRelationshipPage.pageLoadThenClickOnSaveAndContinueBtn();
		
	}
		

}
