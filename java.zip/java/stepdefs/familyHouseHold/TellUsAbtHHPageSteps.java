package stepdefs.familyHouseHold;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import db.DualTable;
import pages.familyHouseHold.TellUsAboutHHPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.RandomGenerator;
import utils.WordUtil;

public class TellUsAbtHHPageSteps extends SuperStepDef{
	
	public TellUsAbtHHPageSteps(Hook hook){
		super(hook);
	}
	
	@When("^From Tell Us About HH Page, Complete Details$")
	public void selectDetailsForTaxHH() throws Exception {		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.selectDetailsForTaxHH(evpdData.memsData );
	}
	
	/**@author vkuma212
	 * Accepted Value :-
	 * 		TaxHHNO      :- 1,2,3,4,5
	 * 		TaxFillingStatus :- TRUE, FALSE
	 
	 From Tell Us About HH Page, Select Tax HH "1" Filing Taxes As "TRUE"
		
	 */
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Filing Taxes As \"(.*?)\"$")
	public void selecIfTaxHHFilingTaxes(String taxHHNo,  String taxFillingStatus) throws Exception{
		
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		Boolean trueFalseValue = taxFillingStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerHHAgreeToFileITR(taxHHIndex, trueFalseValue);
	}
	
	/**@author ppinho
	 * Accepted Value :-
	 * 		memNo      :- 1,2,3,4,5
	 * 		TaxFillingStatus :- TRUE, FALSE
	 
	 From Tell Us About HH Page, Select Member "1" Filing Taxes As "TRUE"
		
	 */
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" Filing Taxes As \"(.*?)\"$")
	public void selecIfMemberFilingTaxes(String memNo,  String taxFillingStatus) throws Exception{		
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValue = taxFillingStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerHHAgreeToFileITR(memIndex, trueFalseValue);
	}
	/**@author vkuma212
	 * Accepted Value :- TaxHHNO :- 1,2,3,4,5
	 * 					LegallyMarriedStatus  :- TRUE, FALSE
	 		
	From Tell Us About HH Page, Select Tax HH "1" Is Legally Married As "TRUE"
	
	*/
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Is Legally Married As \"(.*?)\"$")
	public void selecIfTaxHHLegallyMarried(String taxHHNo, String  legallyMarriedStatus) throws Exception{
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		Boolean trueFalseValue = legallyMarriedStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerHHLegallyMarried(taxHHIndex, trueFalseValue);
	}
	
	/**@author ppinho
	 * Accepted Value :- memNo :- 1,2,3,4,5
	 * 					LegallyMarriedStatus  :- TRUE, FALSE
	 		
	From Tell Us About HH Page, Select Member "1" Is Legally Married As "TRUE"
	
	*/
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" Is Legally Married As \"(.*?)\"$")
	public void selecIfMemberLegallyMarried(String memNo, String  legallyMarriedStatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValue = legallyMarriedStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerHHLegallyMarried(memIndex, trueFalseValue);
	}
	/**@author vkuma212
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  TaxFillingJointly  :-  TRUE, FALSE
		
	From Tell Us About HH Page, Select Tax HH "1" Filing Taxes Jointly As "TRUE"
	
	 */
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Filing Taxes Jointly As \"(.*?)\"$")
	public void answerHHFilingTaxJointly(String taxHHNo, String  taxFillingJointlyStatus) throws Exception{
		
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		Boolean trueFalseValue = taxFillingJointlyStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerHHFilingTaxJointly(taxHHIndex, trueFalseValue);
	}
	
	/**@author ppinho
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  TaxFillingJointly  :-  TRUE, FALSE
		
	From Tell Us About HH Page, Select Member "1" Filing Taxes Jointly As "TRUE"
	
	 */
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" Filing Taxes Jointly As \"(.*?)\"$")
	public void answerMemberFilingTaxJointly(String memNo, String  taxFillingJointlyStatus) throws Exception{		
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValue = taxFillingJointlyStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerHHFilingTaxJointly(memIndex, trueFalseValue);
	}
	
	/** @author sshriv16
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  livingWithSpouseStatus  :-  TRUE, FALSE
	 
	 	From Tell Us About HH Page, Select Tax HH "1" Is Living With Spouse As "FALSE"
	 
	 */
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Is Living With Spouse As \"(.*?)\"$")
	public void selecIfTaxHHIsLivingWithSpouse(String taxHHNo, String  livingWithSpouseStatus) throws Exception{
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		Boolean trueFalseValue = livingWithSpouseStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerTaxHHLiveWithSpouse_RdBtn(taxHHIndex, trueFalseValue);
	}
	
	/** @author ppinho
	 * Accepted Value :-  memNo = 1,2,3,4,5
	 * 					  livingWithSpouseStatus  :-  TRUE, FALSE
	 
	 	From Tell Us About HH Page, Select Member "1" Is Living With Spouse As "FALSE"
	 
	 */
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" Is Living With Spouse As \"(.*?)\"$")
	public void selecIfMemberIsLivingWithSpouse(String memNo, String  livingWithSpouseStatus) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValue = livingWithSpouseStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerTaxHHLiveWithSpouse_RdBtn(memIndex, trueFalseValue);
	}
	
	/**@author sshriv16
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  TaxHHSpouseMemNo  :-  1,2,3,4
	 
	From Tell Us About HH Page, Select Tax HH "1" Spouse Member Number As "2"
	
	 */
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Spouse Member Number As \"(.*?)\"$")
	public void selecTaxHHIsSpouse(String taxHHNo, String taxHHSpouseMemNo) throws Exception{
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		int taxHHSpouseIndex = Integer.parseInt(taxHHSpouseMemNo)-1;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerWhoIsTaxHHSpouse_RdBtn(taxHHIndex, taxHHSpouseIndex+"");
	}
	
	/**@author ppinho
	 * Accepted Value :-  memNo = 1,2,3,4,5
	 * 					  TaxHHSpouseMemNo  :-  1,2,3,4
	 
	From Tell Us About HH Page, Select Member "1" Spouse Member Number As "2"
	
	 */
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" Spouse Member Number As \"(.*?)\"$")
	public void selecMemberIsSpouse(String memNo, String taxHHSpouseMemNo) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		int memSpouseIndex = Integer.parseInt(taxHHSpouseMemNo)-1;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerWhoIsTaxHHSpouse_RdBtn(memIndex, memSpouseIndex+"");
	}

	/**@author abajpai3
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					
	 
	From Tell Us About HH Page, Select Tax HH \"(.*?)\" Spouse who is not seeking health insurance
	
	 */
	
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Spouse who is not seeking health insurance$")
	public void selectTaxHHSpouseWhoIsNotSeekingHI(String taxHHNo) throws Exception{
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.selectTaxHHSpouseWhoIsNotSeekingHI(taxHHIndex);
	}
	
	/**@author ppinho
	 * Accepted Value :-  mamNo = 1,2,3,4,5
	 * 					
	 
	From Tell Us About HH Page, Select Member \"(.*?)\" Spouse who is not seeking health insurance
	
	 */
	
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" Spouse who is not seeking health insurance$")
	public void selectMemSpouseWhoIsNotSeekingHI(String memNo) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.selectTaxHHSpouseWhoIsNotSeekingHI(memIndex);
	}	
	

	/**@author abajpai3
	 * Accepted Value :-  Mem No-1,2,3,4					
	 
	From Tell Us About HH Page, Enter Spouse Details who is not seeking Health Insurance
	|MemNo|FirstNameFormat |  LastNameFormat  |Age   |
	|	1 |		           |			      |	35   |
	
	 */
	
	@And("^From Tell Us About HH Page, Enter Spouse Details who is not seeking Health Insurance$")
	public void provideSpouseDetail(DataTable table) throws Exception{
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
				
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String fNameFormat = scenarioData.get(rowIndex).get(1);
			String lNameFormat = scenarioData.get(rowIndex).get(2);
			String age = scenarioData.get(rowIndex).get(3);
	
			int memberNo = Integer.parseInt(strMemNo);
			String firstName = RandomGenerator.getRunTimeName("MEM", fNameFormat);
			String lastName = RandomGenerator.getRunTimeName(WordUtil.getWord(rowIndex+1), lNameFormat);
			
			String appDate = new DualTable(conn,"").getSysDate();
			appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
			
			String dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, age);
			
			
			tellUsAboutHHPage.provideSpouseDetail(memberNo, firstName,lastName, dob);
			
		}
		
	}
	
	/**@author vkuma212
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  ClaimAnyDependent  :-  TRUE, FALSE
	 
	 From Tell Us About HH Page, Select Tax HH "1" Cliam Any Dependent On ITR As "TRUE"
	 
	 */
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Cliam Any Dependent On ITR As \"(.*?)\"$")
	public void selecIfTaxHHClaimAnyDependentOnITR(String taxHHNo, String  claimAnyDependent) throws Exception{

		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		Boolean trueFalseValue = claimAnyDependent.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerIfTaxHHClaimAnyDependentOnTheirITR_RdBtn(taxHHIndex, trueFalseValue);
	}
	
	/**@author ppinho
	 * Accepted Value :-  mamNo = 1,2,3,4,5
	 * 					  ClaimAnyDependent  :-  TRUE, FALSE
	 
	 From Tell Us About HH Page, Select Member "1" Cliam Any Dependent On ITR As "TRUE"
	 
	 */
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" Cliam Any Dependent On ITR As \"(.*?)\"$")
	public void selecIfMemClaimAnyDependentOnITR(String memNo, String  claimAnyDependent) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValue = claimAnyDependent.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerIfTaxHHClaimAnyDependentOnTheirITR_RdBtn(memIndex, trueFalseValue);
	}
	
	/**@author vkuma212
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  WhoAllLivesWithHOH  :-  2,3,4,5,6
	 
	 From Tell Us About HH Page, Select Who All Lives with Tax HH "1" As dependents As "2"
	 
	 */
	@When("^From Tell Us About HH Page, Select Who All Lives with Tax HH \"(.*?)\" As dependents As \"(.*?)\"$")
	public void answerWhoAllLiveWithTaxHH(String taxHHNo, String whoAllLivesWithHOH) throws Exception{
		
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		String[] arrWhoAllLivesWithHOH = whoAllLivesWithHOH.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrWhoAllLivesWithHOH.length;mCouter++){
			int whoAllLivesWithHOHMemIndex =  Integer.parseInt(arrWhoAllLivesWithHOH[mCouter])-1;
			
			//tellUsAboutHHPage.answerWhoAllLiveWithMem(taxHHIndex, whoAllLivesWithHOHMemIndex+"");
		}
		
	}
	
	/**@author ppinho
	 * Accepted Value :-  mamNo = 1,2,3,4,5
	 * 					  WhoAllLivesWithHOH  :-  2,3,4,5,6
	 
	 From Tell Us About HH Page, Select Who All Lives with Member "1" As dependents As "2"
	 
	 */
	@When("^From Tell Us About HH Page, Select Who All Lives with Member \"(.*?)\" As dependents As \"(.*?)\"$")
	public void answerWhoAllLiveWithMem(String memNo, String whoAllLivesWithHOH) throws Exception{		
		int memIndex = Integer.parseInt(memNo)-1;
		String[] arrWhoAllLivesWithHOH = whoAllLivesWithHOH.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrWhoAllLivesWithHOH.length;mCouter++){
			int whoAllLivesWithHOHMemIndex =  Integer.parseInt(arrWhoAllLivesWithHOH[mCouter])-1;
			
			//tellUsAboutHHPage.answerWhoAllLiveWithMem(memIndex, whoAllLivesWithHOHMemIndex+"");
		}		
	}
	
	/**@author sshriv16
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  BeClaimAsDependent  :-  TRUE, FALSE
	 
	 From Tell Us About HH Page, Select Tax HH "1" Will Be Claimed As Dependent As "TRUE"
	
	*/
	
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Will Be Claimed As Dependent As \"(.*?)\"$")
	public void selecIfTaxHHWillBeClaimedAsDependent(String taxHHNo,  String beClaimedAsDependentStatus) throws Exception{
		
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		Boolean trueFalseValue = beClaimedAsDependentStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerIfTaxHHBeClaimedAsDependentOnSomeOneElseITR_RdBtn(taxHHIndex, trueFalseValue);
	}
	
	/**@author ppinho
	 * Accepted Value :-  mamNo = 1,2,3,4,5
	 * 					  BeClaimAsDependent  :-  TRUE, FALSE
	 
	 From Tell Us About HH Page, Select Member "1" Will Be Claimed As Dependent As "TRUE"
	
	*/
	
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" Will Be Claimed As Dependent As \"(.*?)\"$")
	public void selecIfMemWillBeClaimedAsDependent(String memNo,  String beClaimedAsDependentStatus) throws Exception{		
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValue = beClaimedAsDependentStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerIfTaxHHBeClaimedAsDependentOnSomeOneElseITR_RdBtn(memIndex, trueFalseValue);
	}
	/**@author sshriv16
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  WhoWillClaimTaxHHAsDependent  :-  2,3,4,5,6
	 
	 From Tell Us About HH Page, Select The Tax Filer "1" Who Will Claim Tax HH As dependents As "2"
		
	 */
	
	@When("^From Tell Us About HH Page, Select The Tax Filer \"(.*?)\" Who Will Claim Tax HH As dependents As \"(.*?)\"$")
	public void answerWhoWillClaimTaxHHAsDependent(String taxHHNo,  String WhoWillClaimTaxHHAsDependent) throws Exception{
		
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		int whoWillClaimTaxHHAsDependentIndex = Integer.parseInt(WhoWillClaimTaxHHAsDependent)-1;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.answerWhoWillClaimTaxHHAsDependent(taxHHIndex, whoWillClaimTaxHHAsDependentIndex+"");
	}
	
		
	/**@author ppinho
	 * Accepted Value :-  mamNo = 1,2,3,4,5
	 * 					  WhoWillClaimMemAsDependent  :-  2,3,4,5,6
	 	
	From Tell Us About HH Page, Select The Tax Filer "1" Who Will Claim Member As dependents As "2"
	 */
	
	@When("^From Tell Us About HH Page, Select The Member \"(.*?)\" Who Will Claim Member As dependents As \"(.*?)\"$")
	public void answerWhoWillClaimMemAsDependent(String memNo,  String WhoWillClaimMemAsDependent) throws Exception{		
		int memIndex = Integer.parseInt(memNo)-1;
		int whoWillClaimMemAsDependentIndex = Integer.parseInt(WhoWillClaimMemAsDependent)-1;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.answerWhoWillClaimTaxHHAsDependent(memIndex, whoWillClaimMemAsDependentIndex+"");
	}
	
	/**
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  MemNo  :-  2,3,4,5,6
	 * 					  CommonRelationShip	:- "Child"
	 
	 From Tell Us About HH Page, Select Tax HH "1" And Members "2,3,4" Relationship As "Child"
		
	 */
	
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" And Members \"(.*?)\" Relationship As \"(.*?)\"$")
	public void answerTaxHHMemberRelationship(String taxHHNo,  String MemNo, String CommonRelationShip ) throws Exception{
		
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		String[] arrMemNos = MemNo.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
			int memIndex =  Integer.parseInt(arrMemNos[mCouter])-1;
			
			//tellUsAboutHHPage.answerTaxHHMemberRelationship(taxHHIndex, memIndex, CommonRelationShip);
		}
	}
	
	/**@author ppinho
	 * Accepted Value :-  mem1No = 1,2,3,4,5
	 * 					  mem2No  :-  2,3,4,5,6
	 * 					  CommonRelationShip	:- "Child"
	 
	 From Tell Us About HH Page, Select Member "1" And Members "2,3,4" Relationship As "Child"
		
	 */	
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" And Members \"(.*?)\" Relationship As \"(.*?)\"$")
	public void answerMemMemberRelationship(String mem1No,  String mem2No, String CommonRelationShip ) throws Exception{		
		int mem1Index = Integer.parseInt(mem1No)-1;
		String[] arrMemNos = mem2No.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
			int mem2Index = Integer.parseInt(arrMemNos[mCouter])-1;
			
			//tellUsAboutHHPage.answerTaxHHMemberRelationship(mem1Index, mem2Index, CommonRelationShip);
		}
	}
	/**
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  MemNo  :-  2,3,4,5,6
	 * 					  CommonRelationShip	:- "Child"
	 
	 From Tell Us About HH Page, Select Tax HH "1" Spouse and Members "2" Relationship As "Child"
		
	 */
	
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Spouse and Members \"(.*?)\" Relationship As \"(.*?)\"$")
	public void answerTaxHHSpouseMemberRelationship(String taxHHNo,  String MemNo, String CommonRelationShip) throws Exception{
		
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		String[] arrMemNos = MemNo.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
			int memIndex =  Integer.parseInt(arrMemNos[mCouter])-1;
			
			tellUsAboutHHPage.answerTaxHHSpouseMemberRelationship(taxHHIndex, memIndex, CommonRelationShip);
		}
	}
	
	/**@author ppinho
	 * Accepted Value :-  mem1No = 1,2,3,4,5
	 * 					  mem2No  :-  2,3,4,5,6
	 * 					  CommonRelationShip	:- "Child"
	 
	 From Tell Us About HH Page, Select Member "1" Spouse and Members "2" Relationship As "Child"
		
	 */
	
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" Spouse and Members \"(.*?)\" Relationship As \"(.*?)\"$")
	public void answerMemSpouseMemberRelationship(String mem1No,  String mem2No, String CommonRelationShip) throws Exception{		
		int mem1Index = Integer.parseInt(mem1No)-1;
		String[] arrMemNos = mem2No.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
			int mem2Index =  Integer.parseInt(arrMemNos[mCouter])-1;
			
			tellUsAboutHHPage.answerTaxHHSpouseMemberRelationship(mem1Index, mem2Index, CommonRelationShip);
		
		}
	}
	
	/**@author ppinho
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  MemNo  :-  2,3,4,5,6
	 * 					  CommonRelationShip	:- "Child"
		 
	 From Tell Us About HH Page, Select Tax HH And Members Relationship
	 	| TaxHHNO | MemNo | CommonRelationShip | Other        | 
		| 1       |	2,3,4 |	Other unrelated    | Foster Child |
			
	 */
		
	@When("^From Tell Us About HH Page, Select Tax HH And Members Relationship$")
	public void answerTaxHHMemberRelationshipAdvance(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
			
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			int taxHHIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String[] arrMemNos = scenarioData.get(rowIndex).get(1).split(",");
				
			String CommonRelationShip = scenarioData.get(rowIndex).get(2);
			String SecondaryRelationShip = scenarioData.get(rowIndex).get(3);
				
			TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
			for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
				int memIndex =  Integer.parseInt(arrMemNos[mCouter])-1;
					
				//tellUsAboutHHPage.answerTaxHHMemberRelationship(taxHHIndex, memIndex, CommonRelationShip, SecondaryRelationShip);
			}
		}
	}
	
	/**@author ppinho
	* Accepted Value :-  mem1No = 1,2,3,4,5
	 * 					  mem2No  :-  2,3,4,5,6
	 * 					  CommonRelationShip	:- "Child"
		 
	 From Tell Us About HH Page, Select Member And Members Relationship
	 	| mem1No | mem2No | CommonRelationShip | Other        | 
		| 1      | 2,3,4  | Other unrelated    | Foster Child |
			
	 */
		
	@When("^From Tell Us About HH Page, Select Member And Members Relationship$")
	public void answerMemMemberRelationshipAdvance(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
			
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			int mem1Index = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String[] arrMemNos = scenarioData.get(rowIndex).get(1).split(",");
				
			String CommonRelationShip = scenarioData.get(rowIndex).get(2);
			String SecondaryRelationShip = scenarioData.get(rowIndex).get(3);
				
			TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
			
			for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
				int mem2Index =  Integer.parseInt(arrMemNos[mCouter])-1;
					
				//tellUsAboutHHPage.answerTaxHHMemberRelationship(mem1Index, mem2Index, CommonRelationShip, SecondaryRelationShip);
			}
		}
	}
	
	/**@author ppinho
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  MemNo  :-  2,3,4,5,6
	 * 					  CommonRelationShip	:- "Child"
		 
	 From Tell Us About HH Page, Select Tax HH Spouse and Members Relationship
	 	| TaxHHNO | MemNo | CommonRelationShip | Other        | 
		| 1       |	2,3,4 |	Other unrelated    | Foster Child |
			
	 */
		
	@When("^From Tell Us About HH Page, Select Tax HH Spouse and Members Relationship$")
	public void answerTaxHHSpouseMemberRelationshipAdvance(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
			
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			int taxHHIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String[] arrMemNos = scenarioData.get(rowIndex).get(1).split(",");
				
			String CommonRelationShip = scenarioData.get(rowIndex).get(2);
			String SecondaryRelationShip = scenarioData.get(rowIndex).get(3);
				
			TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
			for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
				int memIndex =  Integer.parseInt(arrMemNos[mCouter])-1;
					
	//tellUsAboutHHPage.answerTaxHHSpouseMemberRelationship(taxHHIndex, memIndex, CommonRelationShip, SecondaryRelationShip);
			}
		}
	}

	/**@author ppinho
	 * Accepted Value :-  mem1No = 1,2,3,4,5
	 * 					  mem2No  :-  2,3,4,5,6
	 * 					  CommonRelationShip	:- "Child"
		 
	 From Tell Us About HH Page, Select Member Spouse and Members Relationship
	 	| mem1No | mem2No | CommonRelationShip | Other        | 
		| 1      | 2,3,4  |	Other unrelated    | Foster Child |
			
	 */
		
	@When("^From Tell Us About HH Page, Select Member Spouse and Members Relationship$")
	public void answerMemSpouseMemberRelationshipAdvance(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
			
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			int mem1Index = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String[] arrMemNos = scenarioData.get(rowIndex).get(1).split(",");
				
			String CommonRelationShip = scenarioData.get(rowIndex).get(2);
			String SecondaryRelationShip = scenarioData.get(rowIndex).get(3);
				
			TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
			for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
				int mem2Index =  Integer.parseInt(arrMemNos[mCouter])-1;
					
				//tellUsAboutHHPage.answerTaxHHSpouseMemberRelationship(mem1Index, mem2Index, CommonRelationShip, SecondaryRelationShip);
			}
		}
	}
	
	/**
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  MemNo  :-  2,3,4,5,6
	 * 					  IsLivingWithHOH	:- TRUE, FALSE
	 * 					  IsLivingWithParentStepParentOtherThanHOH	:- TRUE, FALSE
	 
	 From Tell Us About HH Page, Select If Members "3" Living With Tax HH "1" And Its Spouse As "TRUE"
	 	
	 */
	
	@When("^From Tell Us About HH Page, Select If Members \"(.*?)\" Living With Tax HH \"(.*?)\" And Its Spouse As \"(.*?)\"$")
	public void answerIfMemberLivesWithTaxHH(String memNo,  String taxHHNo, String isLivingWithHOHSpouse ) throws Exception{
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		String[] arrMemNos = memNo.split(",");
		Boolean trueFalseValue = isLivingWithHOHSpouse.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
			int memIndex =  Integer.parseInt(arrMemNos[mCouter])-1;
			
			tellUsAboutHHPage.answerIfMemberLivesWithTaxHH(taxHHIndex, memIndex, trueFalseValue);
		}
	}
	
	/**@author ppinho
	 * Accepted Value :-  mem1No = 1,2,3,4,5
	 * 					  mem2No  :-  2,3,4,5,6
	 * 					  IsLivingWithHOH	:- TRUE, FALSE
	 * 					  IsLivingWithParentStepParentOtherThanHOH	:- TRUE, FALSE
	 
	 From Tell Us About HH Page, Select If Members "5" Living With Member "3" And Its Spouse As "TRUE"
	 	
	 */
	
	@When("^From Tell Us About HH Page, Select If Members \"(.*?)\" Living With Member \"(.*?)\" And Its Spouse As \"(.*?)\"$")
	public void answerIfMemberLivesWithMem(String mem1No,  String mem2No, String isLivingWithHOHSpouse ) throws Exception{
		String[] arrMemNos = mem1No.split(",");
		int mem2Index = Integer.parseInt(mem2No)-1;		
		Boolean trueFalseValue = isLivingWithHOHSpouse.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
			int mem1Index =  Integer.parseInt(arrMemNos[mCouter])-1;
			
			tellUsAboutHHPage.answerIfMemberLivesWithTaxHH(mem2Index, mem1Index, trueFalseValue);
		}
	}
	
	/**
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  MemNo  :-  2,3,4,5,6
	 * 					  IsLivingWithHOH	:- TRUE, FALSE
	 * 					  IsLivingWithParentStepParentOtherThanHOH	:- TRUE, FALSE
	 
	 From Tell Us About HH Page, Select If Members "2,3,4" Living With Tax HH "1" "TRUE" And Parent Step Parent Other Than HOH "TRUE"
	 	
	 */
	
	@When("^From Tell Us About HH Page, Select If Members \"(.*?)\" Living With Tax HH \"(.*?)\" \"(.*?)\" And Parent Step Parent Other Than HOH \"(.*?)\"$")
	public void answerIfMemberLivesWithTaxHH(String memNo,  String taxHHNo, String isLivingWithHOH, String isLivingWithParentStepParentOtherThanHOH ) throws Exception{
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		String[] arrMemNos = memNo.split(",");
		Boolean trueFalseValue1 = isLivingWithHOH.equalsIgnoreCase("TRUE")?true:false;
		Boolean trueFalseValue2 = isLivingWithParentStepParentOtherThanHOH.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
			int memIndex =  Integer.parseInt(arrMemNos[mCouter])-1;
			
			tellUsAboutHHPage.answerIfMemberLivesWithTaxHH(taxHHIndex, memIndex, trueFalseValue1);
			tellUsAboutHHPage.answerIfMemberLivesWithParentStepOtherThanTaxHH(taxHHIndex, memIndex, trueFalseValue2);
		}
	}
	
	/**@author ppinho
	 * Accepted Value :-  mem1No = 1,2,3,4,5
	 * 					  mem2No  :-  2,3,4,5,6
	 * 					  IsLivingWithHOH	:- TRUE, FALSE
	 * 					  IsLivingWithParentStepParentOtherThanHOH	:- TRUE, FALSE
	 
	 From Tell Us About HH Page, Select If Members "2,3,4" Living With Member "1" "TRUE" And Parent Step Parent Other Than HOH "TRUE"
	 	
	 */
	
	@When("^From Tell Us About HH Page, Select If Members \"(.*?)\" Living With Member \"(.*?)\" \"(.*?)\" And Parent Step Parent Other Than HOH \"(.*?)\"$")
	public void answerIfMemberLivesWithMem(String mem1No,  String mem2No, String isLivingWithHOH, String isLivingWithParentStepParentOtherThanHOH ) throws Exception{
		String[] arrMemNos = mem1No.split(",");
		int mem2Index = Integer.parseInt(mem2No)-1;
		Boolean trueFalseValue1 = isLivingWithHOH.equalsIgnoreCase("TRUE")?true:false;
		Boolean trueFalseValue2 = isLivingWithParentStepParentOtherThanHOH.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
			int mem1Index =  Integer.parseInt(arrMemNos[mCouter])-1;
			
			tellUsAboutHHPage.answerIfMemberLivesWithTaxHH(mem2Index, mem1Index, trueFalseValue1);
			tellUsAboutHHPage.answerIfMemberLivesWithParentStepOtherThanTaxHH(mem2Index, mem1Index, trueFalseValue2);
		}
	}
	
	/**@author ppinho
	 * Accepted Value :-  memNo = 1,2,3,4,5
	 * 					  ParentStepparent  :-  2,3,4,5,6
	 
	 From Tell Us About HH Page, Select Who All Lives with Member "6" As Parent Stepparent As Member "5"
	 
	 */
	@When("^From Tell Us About HH Page, Select Who All Lives with Member \"(.*?)\" As Parent Stepparent As Member \"(.*?)\"$")
	public void answerParentStepparentWhoLiveWithMem(String memNo, String ParentStepparent) throws Exception{		
		int memIndex = Integer.parseInt(memNo)-1;
		String[] arrParentStepparentWhoLiveWithMem = ParentStepparent.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrParentStepparentWhoLiveWithMem.length;mCouter++){
			int parentStepparentWhoLiveWithMemIndex =  Integer.parseInt(arrParentStepparentWhoLiveWithMem[mCouter])-1;
			
			tellUsAboutHHPage.answerAllParentStepparentWhoLiveWithMem(memIndex, parentStepparentWhoLiveWithMemIndex);
		}		
	}
	
	/**@author ppinho
	 * Accepted Value :-  memNO = 1,2,3,4,5
	 * 					  WhoAllLivesWithmem  :-  2,3,4,5,6
		 
	 From Tell Us About HH Page, Select All Who Are Mem "3" Parents Stepparents As "1,2"
		 
	 */
	@When("^From Tell Us About HH Page, Select All Who Are Mem \"(.*?)\" Parents Stepparents As \"(.*?)\"$")
	public void answerAllWhoAreMemParentStepparent(String memNo, String whoAllAreMemParentStepparent) throws Exception{
			
		int taxHHIndex = Integer.parseInt(memNo)-1;
		String[] arrWhoAllAreMemParentStepparent = whoAllAreMemParentStepparent.split(",");
			
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrWhoAllAreMemParentStepparent.length;mCouter++){
		int whoAllAreMemParentStepparentIndex =  Integer.parseInt(arrWhoAllAreMemParentStepparent[mCouter])-1;
				
		tellUsAboutHHPage.answerAllWhoAreMemParentStepparent(taxHHIndex, whoAllAreMemParentStepparentIndex+"");
		}
			
	}

	/**@author sshriv16
	 * Accepted Value :-  MemNo = 1,2,3,4,5
	 * 					  IsLivingWithParentStepParent	:- TRUE, FALSE
	 
	 From Tell Us About HH Page, Select If Member "1" Live With Parent Step Parent As "FALSE"
		
	 */
	
	@When("^From Tell Us About HH Page, Select If Member \"(.*?)\" Live With Parent Step Parent As \"(.*?)\"$")
	public void answerIfTaxHHLivesWithParentStepParent(String memNo, String isLivingWithParentStepParent) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValueForIsLivingWithParentStepParent = isLivingWithParentStepParent.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerIfMemberWithParentStepParent(memIndex, trueFalseValueForIsLivingWithParentStepParent);
	}
	
	/**@author sshriv16
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  siblingMemNo  :-  2,3,4,5,6
	 
	 From Tell Us About HH Page, Select Tax HH "4" Parent Or Stepparent As "2,3"
	 
	 */
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Parent Or Stepparent As \"(.*?)\"$")
	public void selectTaxHHParentOrStepparent(String taxHHNo, String parentMemNo) throws Exception{
		
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		String[] arrParentMemNo = parentMemNo.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrParentMemNo.length;mCouter++){
			int parentOfTaxHHMemIndex =  Integer.parseInt(arrParentMemNo[mCouter])-2;
			
			tellUsAboutHHPage.parentLivingWithTaxHH(taxHHIndex, parentOfTaxHHMemIndex+"");
		}
		
	}
	
	/**@author ppinho
	 * Accepted Value :-  memNo = 1,2,3,4,5
	 * 					  siblingMemNo  :-  2,3,4,5,6
	 
	 From Tell Us About HH Page, Select Member "4" Parent Or Stepparent As "2,3"
	 
	 */
	@When("^From Tell Us About HH Page, Select Member \"(.*?)\" Parent Or Stepparent As \"(.*?)\"$")
	public void selectMemParentOrStepparent(String memNo, String parentMemNo) throws Exception{		
		int memIndex = Integer.parseInt(memNo)-1;
		String[] arrParentMemNo = parentMemNo.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrParentMemNo.length;mCouter++){
			int parentOfMemMemIndex =  Integer.parseInt(arrParentMemNo[mCouter])-2;
			
			tellUsAboutHHPage.parentLivingWithTaxHH(memIndex, parentOfMemMemIndex+"");
		}		
	}
	
	/**@author sshriv16
	 * Accepted Value :-  MemNo = 1,2,3,4,5
	 * 					  IsLivingWithBrotherSister	:- TRUE, FALSE
	 
	 From Tell Us About HH Page, Select If Member "1" Live With Brother Sister As "FALSE"
		
	 */
	
	@When("^From Tell Us About HH Page, Select If Member \"(.*?)\" Live With Brother Sister As \"(.*?)\"$")
	public void answerIfTaxHHLivesWithBrotherSister(String memNo, String isLivingWithBrotherSister) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValueForIsLivingWithBrotherSister = isLivingWithBrotherSister.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerIfMemberLivesWithBrotherSister(memIndex, trueFalseValueForIsLivingWithBrotherSister);
		
	}
	
	/**@author sshriv16
	 * Accepted Value :-  TaxHHNO = 1,2,3,4,5
	 * 					  siblingMemNo  :-  2,3,4,5,6
	 
	 From Tell Us About HH Page, Select Who Are The Brother Or Sister Living with Tax HH "4" As "2,3"
	 
	 */
	@When("^From Tell Us About HH Page, Select Who Are The Brother Or Sister Living with Tax HH \"(.*?)\" As \"(.*?)\"$")
	public void selectTaxHHSiblings(String taxHHNo, String siblingMemNo) throws Exception{
		
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		String[] arrSiblingMemNo = siblingMemNo.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrSiblingMemNo.length;mCouter++){
			int siblingOfTaxHHMemIndex =  Integer.parseInt(arrSiblingMemNo[mCouter])-1;
			
			tellUsAboutHHPage.brotherSisterLivingWithTaxHH(taxHHIndex, siblingOfTaxHHMemIndex+"");
		}		
	}
	
	/**@author ppinho
	 * Accepted Value :-  mamNo = 1,2,3,4,5
	 * 					  siblingMemNo  :-  2,3,4,5,6
	 
	 From Tell Us About HH Page, Select Who Are The Brother Or Sister Living with Member "4" As "2,3"
	 
	 */
	@When("^From Tell Us About HH Page, Select Who Are The Brother Or Sister Living with Member \"(.*?)\" As \"(.*?)\"$")
	public void selectMemSiblings(String memNo, String siblingMemNo) throws Exception{		
		int memIndex = Integer.parseInt(memNo)-1;
		String[] arrSiblingMemNo = siblingMemNo.split(",");
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrSiblingMemNo.length;mCouter++){
			int siblingOfMemMemIndex =  Integer.parseInt(arrSiblingMemNo[mCouter])-1;
			
			tellUsAboutHHPage.brotherSisterLivingWithTaxHH(memIndex, siblingOfMemMemIndex+"");
		}		
	}
	
	/**@author sshriv16
	 * Accepted Value :-  MemNo = 1,2,3,4,5
	 * 					  IsLivingWithSonDaughterStepSonDaughter	:- TRUE, FALSE
	 
	 From Tell Us About HH Page, Select If Member "1" Live With Son Daughter StepSon Daughter "TRUE"
		
	 */
	
	@When("^From Tell Us About HH Page, Select If Member \"(.*?)\" Live With Son Daughter StepSon Daughter \"(.*?)\"$")
	public void answerIfTaxHHLivesWithSonOrDaughter(String memNo, String isLivingWithSonDaughterStepSonDaughter) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValueForIsLivingWithSonDaughterStepSonDaughter = isLivingWithSonDaughterStepSonDaughter.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		//tellUsAboutHHPage.answerIfMemberLivesWithSonDoughterStepSonDaughter(memIndex, trueFalseValueForIsLivingWithSonDaughterStepSonDaughter);
		
	}
	
	/**@author vkuma212
	 * Accepted Value :-  TaxHH1NO = 1,2,3,4,5
	 * 					  TaxHH2NO = 1,2,3,4,5
	 * 					   RelationShip :- "Son", "Uncle" 
	 
	 From Tell Us About HH Page, Select TaxHH1 "1" to TaxHH2 "2" Relationship "Son"
	
	*/
	
	@When("^From Tell Us About HH Page, Select TaxHH1 \"(.*?)\" to TaxHH2 \"(.*?)\" Relationship \"(.*?)\"$")
	public void selectTaxHH1IstheOfTaxHH2(String taxHH1No,  String taxHH2No, String relation) throws Exception{
		int taxHH1Index = Integer.parseInt(taxHH1No)-1;
		int taxHH2Index = Integer.parseInt(taxHH2No)-1;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.selectTaxHH1IstheOfTaxHH2(taxHH1Index, taxHH2Index, relation);
		
	}
	
	/**@author vkuma212
	 * Accepted Value :-  TaxHH1NO = 1,2,3,4,5
	 * 					  TaxHH2NO = 1,2,3,4,5
	 * 					   IsLivingTogether :- TRUE, FALSE 
	 
	 From Tell Us About HH Page, Select If TaxHH1 "1" Lives With TaxHH2 "2" "TRUE" 
	
	*/
	
	@When("^From Tell Us About HH Page, Select If TaxHH1 \"(.*?)\" Lives With TaxHH2 \"(.*?)\" \"(.*?)\"$")
	public void selectTaxHH1LivesWithTaxHH2(String taxHH1No,  String taxHH2No, String IsLivingTogether) throws Exception{
		int taxHH1Index = Integer.parseInt(taxHH1No)-1;
		int taxHH2Index = Integer.parseInt(taxHH2No)-1;
		
		Boolean trueFalseValue = IsLivingTogether.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.selectTaxHH1LivesWithTaxHH2(taxHH1Index, taxHH2Index, trueFalseValue);
		
	}
	
	/**@author akumari4
	 * 
	   From Tell Us About HH Page, Select TaxHH "4" Is Claimed By Someone Not Applying
	 * @param taxHHNo
	 * @param IsClaimedByNotAppying
	 * @throws Exception
	 */
	@When("^From Tell Us About HH Page, Select TaxHH \"(.*?)\" Is Claimed By Someone Not Applying$")
	public void selectTaxHHClaimedBySomeoneNotApplying(String taxHHNo) throws Exception{
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
				
		//Boolean trueFalseValue = IsClaimedByNotAppying.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.selectTaxHHClaimedBySomeoneNotApplying(taxHHIndex);
		
	}
	
	/**@author akumari4
	 
	  From Tell Us About HH Page, Enter First Name For Not Applying Member Claiming TaxHH "4" As "NotApplyingMemFirstName"
	 * @param memNumber
	 * @param fName
	 * @throws Exception
	 */
	@And("^From Tell Us About HH Page, Enter First Name For Not Applying Member Claiming TaxHH \"(.*?)\" As \"(.*?)\"$")
	public void enterFirstNameForNotApplyingMember(String memNumber,String fName) throws Exception{
		int memNo = Integer.parseInt(memNumber);
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.enterNotApplyingMemberFirstName(memNo, fName);
	}
	
	/**@author akumari4
	  	  From Tell Us About HH Page, Enter Middle Name For Not Applying Member Claiming TaxHH "4" As "NotApplyingMemMiddleName"

	 * @param memNumber
	 * @param mName
	 * @throws Exception
	 */
	@And("^From Tell Us About HH Page, Enter Middle Name For Not Applying Member Claiming TaxHH \"(.*?)\" As \"(.*?)\"$")
	public void enterMiddleNameForNotApplyingMember(String memNumber,String mName) throws Exception{
		int memNo = Integer.parseInt(memNumber);
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.enterNotApplyingMemberMiddleName(memNo, mName);
	}
	
	/**@author akumari4
	  
	  	  From Tell Us About HH Page, Enter Last Name For Not Applying Member Claiming TaxHH "4" As "NotApplyingMemLastName"

	 * @param memNumber
	 * @param lName
	 * @throws Exception
	 */
	@And("^From Tell Us About HH Page, Enter Last Name For Not Applying Member Claiming TaxHH \"(.*?)\" As \"(.*?)\"$")
	public void enterLastNameForNotApplyingMember(String memNumber,String lName) throws Exception{
		int memNo = Integer.parseInt(memNumber);
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.enterNotApplyingMemberLastName(memNo, lName);
	}
	
	/**@author akumari4
	 * 
	  From Tell Us About HH Page, Enter DOB For Not Applying Member Claiming TaxHH "4" With Age As "40"
	 * @param memNumber
	 * @param age
	 * @throws Exception
	 */
	@And("^From Tell Us About HH Page, Enter DOB For Not Applying Member Claiming TaxHH \"(.*?)\" With Age As \"(.*?)\"$")
	public void enterDOBForNotApplyingMember(String memNumber,String age) throws Exception{
		int memNo = Integer.parseInt(memNumber);
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		String dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, age);

		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.enterNotApplyingMemberDOB(memNo, dob);
	}
	
	/**@author akumari4
	 * 
	  From Tell Us About HH Page, Select Married Status for Not Applying Member Who is Claiming Tax HH "4" As "FALSE"
	 * @param taxHHNo
	 * @param legallyMarriedStatus
	 * @throws Exception
	 */
	@When("^From Tell Us About HH Page, Select Married Status for Not Applying Member Who is Claiming Tax HH \"(.*?)\" As \"(.*?)\"$")
	public void selecIfNotApplyingMemberLegallyMarried(String taxHHNo, String  legallyMarriedStatus) throws Exception{
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
		Boolean trueFalseValue = legallyMarriedStatus.equalsIgnoreCase("TRUE")?true:false;
		
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.answerNotApplyingMemberLegallyMarried(taxHHIndex, trueFalseValue);
	}
	
	/**@author akumari4
	 * 
	 * From Tell Us About HH Page, Select Tax HH "4" Relationship With Not Applying Member As "Unrelated"
	 * @param taxHHNo
	 * @param relationShipVal
	 * @throws Exception
	 */
	@When("^From Tell Us About HH Page, Select Tax HH \"(.*?)\" Relationship With Not Applying Member As \"(.*?)\"$")
	public void answerTaxHHRelationshipWithNotApplyingMember(String taxHHNo, String relationShipVal ) throws Exception{
		
		int taxHHIndex = Integer.parseInt(taxHHNo)-1;
			
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.answerTaxHHRelationWithMemNotApplying(taxHHIndex, relationShipVal);
	}
	
	
	@When("^From Tell Us About HH Page, Take Screenshot$")
	public void takeScreenshot() throws Exception{
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.takeScreenshot();
		
	}
	
	@When("^From Tell Us About HH Page, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception{
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.clickOnSaveAndContinueBtn();
		
	}
	
	@When("^From Tell Us About HH Page, Page Load And Click On Save And Continue$")
	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception{
		TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
		tellUsAboutHHPage.pageLoadAndClickOnSaveAndContinueBtn();
		
	}
		

}
