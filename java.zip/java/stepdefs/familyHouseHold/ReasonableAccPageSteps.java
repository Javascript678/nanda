package stepdefs.familyHouseHold;
import cucumber.api.java.en.When;
import pages.familyHouseHold.ReasonableAccomPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ReasonableAccPageSteps extends SuperStepDef{
	
	public ReasonableAccPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Reasonable Accomodation Page, Complete Resonable Accomodation For Member$")
	public void completeResonableAccForMembers() throws Exception {
		ReasonableAccomPage reasonableAccomPage = new ReasonableAccomPage(driver, testCaseId);
		reasonableAccomPage.completeResonableAccForMembers(evpdData.memsData);
	}
	
	@When("^From Reasonable Accomodation Page, Page Load And Click On Save And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		ReasonableAccomPage reasonableAccomPage = new ReasonableAccomPage(driver, testCaseId);
		reasonableAccomPage.pageLoadThenClickOnSaveAndContinueBtn();
	}
	
	@When("^From Reasonable Accomodation Page, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception {
		ReasonableAccomPage reasonableAccomPage = new ReasonableAccomPage(driver, testCaseId);
		reasonableAccomPage.clickOnSaveAndContinueBtn();
	}
	
	/**@author sshriv16
	 * From More About This HH Page, Select Member "1" Having Type Of Condition As "BLIND" and Having Type Of Accomodation As "PUBLICATIONS_IN_BRAILLE,ASSIST_LISTEN_DEVICE"
		Accepted Type Of Condition :- Multiple Value seperated by Commas
									  BLIND, 
									  DEAF,
									  DEVELOPMENTAL_DISABLED, 
									  HARD_OF_HEARING ,
									  INTELLECTUAL_DISABLED,
									  LOW_VISION,PHYSICALLY_DISABLED, 
									  OTHER
		Accepted Typs Of Accomodation :- Multiple Value seperated by Commas
										 AMERICAN_SIGN_LANG_INTERPRETER
										 ASSIST_LISTEN_DEVICE
										 COMMUNICATION_ACCESS_REAL_TIME_TRANSLATIONS
										 LARGE_PRINT_PUBLICATION
										 PUBLICATION_IN_ELECTRONIC_FORMAT
										 PUBLICATIONS_IN_BRAILLE
										 TTY
										 VIDEO_RELAY_SERVICE
										 OTHER
		
	 */
	
	@When("^From Reasonable Accomodation Page, Complete Reasonable Accomodation For Member \"(.*)\" Having Type Of Condition As \"(.*)\" and Having Type Of Accomodation As \"(.*)\"$")
	public void completeReasonableAccForMembers(String memNo, String typeOfCondition, String typeOfAccomodation) throws Exception {
		ReasonableAccomPage reasonableAccomPage = new ReasonableAccomPage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		reasonableAccomPage.completeReasonableAccForMembers(memIndex, typeOfCondition,typeOfAccomodation);
	}
}
