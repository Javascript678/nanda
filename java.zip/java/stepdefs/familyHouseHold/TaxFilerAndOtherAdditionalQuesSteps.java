package stepdefs.familyHouseHold;
import cucumber.api.java.en.When;
import pages.additionalQuestion.TaxFilerAndOtherAdditionalQuePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class TaxFilerAndOtherAdditionalQuesSteps extends SuperStepDef{
	
	public TaxFilerAndOtherAdditionalQuesSteps(Hook hook){
		super(hook);
	}
	
	/*Ritu
	 * Always accepted value As FALSE
	 
	 From Tax Filer and FamilyHH Page, Select Member "1" Is Filing A Joint Federal Income Tax Return With His Spouse As "FALSE"
	 
	 */
	@When("^From Tax Filer and FamilyHH Page, Select Member \"([^\"]*)\" Is Filing A Joint Federal Income Tax Return With His Spouse As \"([^\"]*)\"$")
	public void selectMemberFilingTaxJointy(String memNo, String filingTaxAns) throws Exception {
        Boolean taxFilerQuestionAns = filingTaxAns.equalsIgnoreCase("TRUE")?true:false;
        int taxHHIndex = Integer.parseInt(memNo) - 1;
        
        TaxFilerAndOtherAdditionalQuePage taxFilerAdditionalQuesPage = new TaxFilerAndOtherAdditionalQuePage(driver, testCaseId);
        taxFilerAdditionalQuesPage.evpdCompleteTaxFilerQuestion(taxHHIndex, taxFilerQuestionAns);
	}
	
	/*Vinay
	 * Always accepted value As FALSE 
	 
	 From Tax Filer and FamilyHH Page, Select If Member "1" Provide SSN Value As "FALSE"
	 
	 */
	@When("^From Tax Filer and FamilyHH Page, Select If Member \"([^\"]*)\" Provide SSN Value As \"([^\"]*)\"$")
	public void completeSSNQuestion(String memNo, String noSSNAnswer) throws Exception {
        Boolean noSSNQuestionAns = noSSNAnswer.equalsIgnoreCase("TRUE")?true:false;
        int taxHHIndex = Integer.parseInt(memNo) - 1;
        
        TaxFilerAndOtherAdditionalQuePage taxFilerAdditionalQuesPage = new TaxFilerAndOtherAdditionalQuePage(driver, testCaseId);
        taxFilerAdditionalQuesPage.evpdCompleteSSNQuestion(taxHHIndex, noSSNQuestionAns);
	}
	
	@When("^From Tax Filer and Additional Question Start Page, Click On Save And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		TaxFilerAndOtherAdditionalQuePage taxFilerAdditionalQuesPage = new TaxFilerAndOtherAdditionalQuePage(driver, testCaseId);
		taxFilerAdditionalQuesPage.clickOnSaveAndContinueBtn();
	}

}
