package stepdefs.familyHouseHold;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import db.DualTable;
import db.ElgMemberTable;
import pages.familyHouseHold.CitizenImmigrationStatusPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.StubLogic;
import utils.TestData;

public class CitizenImmPageSteps extends SuperStepDef {

	public CitizenImmPageSteps(Hook hook) {
		super(hook);
	}

	@When("^From Citizen Immigration Page, Select Immigartion Status For Member$")
	public void selectImmigartionStatusForMember() throws Exception {
		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver, testCaseId);
		citizenImmigrationStatusPage.selectImmigartionStatusForMember(evpdData.whoIsApplying, evpdData.memsData);
	}

	@When("^From Citizen Immigration Page, Click On Save And Continue For All Member, Considering All Are Citizen$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {

		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);
		for (int mCounter = 0; mCounter < memCount; mCounter++) {
			citizenImmigrationStatusPage.pageLoadThenClickOnSaveAndContinueBtn(mCounter);
		}
	}

	/**
	 * @author Ritu 
	 From Citizen Immigration Page, Select Immigartion Status For Members "1,2,3,4" As CIT	
	 */
	@When("^From Citizen Immigration Page, Select Immigartion Status For Members \"(.*?)\" As CIT$")
	public void selectImmigartionStatusForMemberAsCIT(String members) throws Exception {

		String[] arrMemNos = members.trim().split(",");

		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);
		for (int mCounter = 0; mCounter < arrMemNos.length; mCounter++) {

			int memIndex = Integer.parseInt(arrMemNos[mCounter]) - 1;

			citizenImmigrationStatusPage.selectIfMemIsUSCitizen(memIndex, true);
			citizenImmigrationStatusPage.selectIfMemIsNaturalizedCitizen(memIndex, false);
			citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();

		}
	}
	
	/**
	 * @author vkuma212 
	 From Citizen Immigration Page, Select Immigartion Status For Members "1,2,3,4,5,6,7" As Naturalized Citizen	
	 */
	@When("^From Citizen Immigration Page, Select Immigartion Status For Members \"(.*?)\" As Naturalized Citizen$")
	public void selectImmigartionStatusForMemberAsNaturalizedCitizen(String memNos) throws Exception {

		String[] arrMemNos = memNos.split(",");
		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);
		for (int mCounter = 0; mCounter < arrMemNos.length; mCounter++) {

			int memIndex = Integer.parseInt(arrMemNos[mCounter]) - 1;

			citizenImmigrationStatusPage.selectIfMemIsUSCitizen(memIndex, true);
			citizenImmigrationStatusPage.selectIfMemIsNaturalizedCitizen(memIndex, true);
			citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();
		}
	}
	
	/**
	 * @author Yamini Upreti
	 From Citizen Immigration Page, Select Immigartion Status For Members "1,2,3,4,5,6,7" As Naturalized Citizen When RFI is required	
	 */
	@When("^From Citizen Immigration Page, Select Immigartion Status For Members \"(.*?)\" As Naturalized Citizen When RFI is required$")
	public void selectImmigartionStatusForMemberAsNaturalizedCitizenWhenRfIisRequired(String memNos) throws Exception {

		String[] arrMemNos = memNos.split(",");
		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);
		for (int mCounter = 0; mCounter < arrMemNos.length; mCounter++) {

			int memIndex = Integer.parseInt(arrMemNos[mCounter]) - 1;

			citizenImmigrationStatusPage.selectIfMemIsUSCitizen(memIndex, true);
			citizenImmigrationStatusPage.selectIfMemIsNaturalizedCitizen(memIndex, true);
			citizenImmigrationStatusPage.selectDocTypeForNaturalizedCitizen();
			citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();
		}
	}

	/**
	 * @author vkuma212 
	 Accepted Condition :- Member Number Should be in Sequence
	 From Citizen Immigration Page, Select Immigartion Status For Members "1,2,3" As UND	

	 */
	@When("^From Citizen Immigration Page, Select Immigartion Status For Members \"(.*?)\" As UND$")
	public void selectImmigartionStatusForMemberAsUND(String memNos) throws Exception {
		String[] arrMemNos = memNos.split(",");

		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);
		for (int mCounter = 0; mCounter < arrMemNos.length; mCounter++) {

			int memIndex = Integer.parseInt(arrMemNos[mCounter]) - 1;

			citizenImmigrationStatusPage.selectIfMemIsUSCitizen(memIndex, false);
			citizenImmigrationStatusPage.selectIfMemIsVeteran(memIndex, false);
			citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();
			citizenImmigrationStatusPage.clickOnWarningPopUpOKBtn();
		}
	}

	/**
	 * @author Ritu 
	 Member Number in row should be sequnce
	  
	 From Citizen Immigration Page, Select Immigartion Status For Members As QLP
	    |MemberNumbers 	| AlientNameSameAsAppear| AlienNumber| ArrivedInUSAfter1996|ImmStatusvlpErrorIndex|
		|1				|  TRUE  				|	223480923| TRUE					| 1                    |
	 * 
	 * @param table
	 * @throws Exception
	 */
	@When("^From Citizen Immigration Page, Select Immigartion Status For Members As QLP$")
	public void selectImmigartionStatusForMemberAsQLP(DataTable table) throws Exception {

		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();

		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);
		for (int rowIndex = 1; rowIndex < rowCount; rowIndex++) {
			String memNos = scenarioData.get(rowIndex).get(0);
			int memIndex = Integer.parseInt(memNos) - 1;
			Boolean alientNameSameAsAppear = scenarioData.get(rowIndex).get(1).equalsIgnoreCase("TRUE") ? true : false;
			String alienNumber = scenarioData.get(rowIndex).get(2);
			Boolean arrivedInUSAfter1996 = scenarioData.get(rowIndex).get(3).equalsIgnoreCase("TRUE") ? true : false;
			String lastName = elg_MemberTable.getLastNameUsingUserProfileRefId(userProfileRefId, memIndex);
			int immStatusvlpErrorIndex = Integer.parseInt(scenarioData.get(rowIndex).get(4));

			citizenImmigrationStatusPage.selectIfMemIsUSCitizen(memIndex, false);
			citizenImmigrationStatusPage.clickOnImmigrationCheckBox();
			citizenImmigrationStatusPage.clickOnReEntryPermitI327RdBtn(memIndex);
			citizenImmigrationStatusPage.enterAlienNo(alienNumber);
			citizenImmigrationStatusPage.selectIfMemNameSameAsAppearOnSSN(memIndex,alientNameSameAsAppear);
			citizenImmigrationStatusPage.selectIfMemArriveInUSAfter1960(memIndex, arrivedInUSAfter1996);
			citizenImmigrationStatusPage.selectIfMemIsVeteran(memIndex, true);
			citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();

			if (StubLogic.isMemberExpecting_QLP_RFI(lastName)) {
				citizenImmigrationStatusPage.clickOnVeriyMannualBtn();
				citizenImmigrationStatusPage.selectImmStatusForMember(memIndex, immStatusvlpErrorIndex);
				citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();
			}

		}
	}
	/**
	 * @author Ritu 
	 * 			Member Number in row should be sequence
	 From Citizen Immigration Page, Select Immigartion Status For Members As QAB 
	    |MemberNumbers 	| AlientNameSameAsAppear| AlienNumber| ArrivedInUSAfter1996|ImmStatusvlpErrorIndex|ImmStatusAwardDatePriorFromToday|
		|1				|  TRUE  				|	223480923| TRUE				   | 12                   |365					          |
		
	 * @param table
	 * @throws Exception
	 */
	@When("^From Citizen Immigration Page, Select Immigartion Status For Members As QAB$")
	public void selectImmigartionStatusForMemberAsQAB(DataTable table) throws Exception {

		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		
		

		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);
		for (int rowIndex = 1; rowIndex < rowCount; rowIndex++) {
			String memNos = scenarioData.get(rowIndex).get(0);
			int memIndex = Integer.parseInt(memNos) - 1;
			Boolean alientNameSameAsAppear = scenarioData.get(rowIndex).get(1).equalsIgnoreCase("TRUE") ? true : false;
			String alienNumber = scenarioData.get(rowIndex).get(2);
			Boolean arrivedInUSAfter1996 = scenarioData.get(rowIndex).get(3).equalsIgnoreCase("TRUE") ? true : false;
			String lastName = elg_MemberTable.getLastNameUsingUserProfileRefId(userProfileRefId, memIndex);
			int immStatusvlpErrorIndex = Integer.parseInt(scenarioData.get(rowIndex).get(4));
			String immStatusAwardDatePriorFromToday = scenarioData.get(rowIndex).get(5);
			String appDate = new DualTable(conn,"").getSysDate();
			appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
			String immStatusAwardDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:"+immStatusAwardDatePriorFromToday);
			
			citizenImmigrationStatusPage.selectIfMemIsUSCitizen(memIndex, false);
			citizenImmigrationStatusPage.clickOnImmigrationCheckBox();
			citizenImmigrationStatusPage.clickOnReEntryPermitI327RdBtn(memIndex);
			citizenImmigrationStatusPage.enterAlienNo(alienNumber);
			citizenImmigrationStatusPage.selectIfMemNameSameAsAppearOnSSN(memIndex,alientNameSameAsAppear);
			citizenImmigrationStatusPage.selectIfMemArriveInUSAfter1960(memIndex, arrivedInUSAfter1996);
			citizenImmigrationStatusPage.selectIfMemIsVeteran(memIndex, false);
			citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();

			if (StubLogic.isMemberExpecting_QAB_RFI(lastName)) {
				citizenImmigrationStatusPage.clickOnVeriyMannualBtn();
				citizenImmigrationStatusPage.selectImmStatusForMember(memIndex, immStatusvlpErrorIndex);
				
				//For LawFully Present (12) , Enter Award Date within 5 years
				//For Cuban Haitian entrant   (3) , Dont Enter Award Date
				if(immStatusvlpErrorIndex !=3){
					citizenImmigrationStatusPage.enterCitizenStatusAwardDateForMemo(memIndex, immStatusAwardDate);
				}
				
				citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();

			}

		}
	}
	
	/**
	 * @author Ritu 
	 * 			Accepted Value 
	 * 
	 Member Number in row should be sequence
	 
	 From Citizen Immigration Page, Select Immigartion Status For Members As ILP
	    |MemberNumbers 	| AlientNameSameAsAppear| AlienNumber| ArrivedInUSAfter1996|ImmStatusvlpErrorIndex|
		|1				|  TRUE  				|	223480923| TRUE				   | 15                   |
		
	 * @param table
	 * @throws Exception
	 */

	@When("^From Citizen Immigration Page, Select Immigartion Status For Members As ILP$")
	public void selectImmigartionStatusForMemberAsILP(DataTable table) throws Exception {

		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();

		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);
		for (int rowIndex = 1; rowIndex < rowCount; rowIndex++) {
			String memNos = scenarioData.get(rowIndex).get(0);
			int memIndex = Integer.parseInt(memNos) - 1;
			Boolean alientNameSameAsAppear = scenarioData.get(rowIndex).get(1).equalsIgnoreCase("TRUE") ? true : false;
			String alienNumber = scenarioData.get(rowIndex).get(2);
			Boolean arrivedInUSAfter1996 = scenarioData.get(rowIndex).get(3).equalsIgnoreCase("TRUE") ? true : false;
			String lastName = elg_MemberTable.getLastNameUsingUserProfileRefId(userProfileRefId, memIndex);
			int immStatusvlpErrorIndex = Integer.parseInt(scenarioData.get(rowIndex).get(4));

			citizenImmigrationStatusPage.selectIfMemIsUSCitizen(memIndex, false);
			citizenImmigrationStatusPage.clickOnImmigrationCheckBox();
			citizenImmigrationStatusPage.clickOnReEntryPermitI327RdBtn(memIndex);
			citizenImmigrationStatusPage.enterAlienNo(alienNumber);
			citizenImmigrationStatusPage.selectIfMemNameSameAsAppearOnSSN(memIndex,alientNameSameAsAppear);
			citizenImmigrationStatusPage.selectIfMemArriveInUSAfter1960(memIndex, arrivedInUSAfter1996);
			citizenImmigrationStatusPage.selectIfMemIsVeteran(memIndex, true);
			citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();

			if (StubLogic.isMemberExpecting_ILP_RFI(lastName)) {
				citizenImmigrationStatusPage.clickOnVeriyMannualBtn();
				citizenImmigrationStatusPage.selectImmStatusForMember(memIndex, immStatusvlpErrorIndex);
				citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();
			}
		}
	}
	
	/**
     * @author Shailza 
      *                  Accepted Value 
      * 
      Member Number in row should be sequence
     
      From Citizen Immigration Page,During RAC, Select Immigration Status For Members As ILP
         |MemberNumbers | AlientNameSameAsAppear| AlienNumber	| ArrivedInUSAfter1996|ImmStatusvlpErrorIndex| ReceiptCardNumber   |
         |2             |  TRUE                 |      223480923| TRUE                | 15                   | KBL2234578968       |
           
     * @param table
     * @throws Exception
     */

     @When("^From Citizen Immigration Page,During RAC, Select Immigration Status For Members As ILP$")
     public void selectImmigartionStatusForMemberAsILPDuringRAC(DataTable table) throws Exception {

           
           String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
           ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
           
           List<List<String>> scenarioData = table.raw();
           int rowCount = scenarioData.size();

           CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
                        testCaseId);
           for (int rowIndex = 1; rowIndex < rowCount; rowIndex++) {
                  String memNos = scenarioData.get(rowIndex).get(0);
                  int memIndex = Integer.parseInt(memNos) - 1;
                  Boolean alientNameSameAsAppear = scenarioData.get(rowIndex).get(1).equalsIgnoreCase("TRUE") ? true : false;
                  String alienNumber = scenarioData.get(rowIndex).get(2);
                  Boolean arrivedInUSAfter1996 = scenarioData.get(rowIndex).get(3).equalsIgnoreCase("TRUE") ? true : false;
                  String lastName = elg_MemberTable.getLastNameUsingUserProfileRefId(userProfileRefId, memIndex);
                  int immStatusvlpErrorIndex = Integer.parseInt(scenarioData.get(rowIndex).get(4));
                  String receiptCardNumber= scenarioData.get(rowIndex).get(5);

                  citizenImmigrationStatusPage.selectIfMemIsUSCitizen(memIndex, false);
                  citizenImmigrationStatusPage.clickOnPermanentResidentCardI551RdBtn();
                  citizenImmigrationStatusPage.enterAlienNo(alienNumber);
                  citizenImmigrationStatusPage.enterReceiptCardNumber(receiptCardNumber);
                  citizenImmigrationStatusPage.selectIfMemNameSameAsAppearOnSSN(memIndex,alientNameSameAsAppear);
                  citizenImmigrationStatusPage.selectIfMemArriveInUSAfter1960(memIndex, arrivedInUSAfter1996);
                  citizenImmigrationStatusPage.selectIfMemIsVeteran(memIndex, true);
                  citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();

                  if (StubLogic.isMemberExpecting_ILP_RFI(lastName)) {
                        citizenImmigrationStatusPage.clickOnVeriyMannualBtn();
                        citizenImmigrationStatusPage.selectImmStatusForMember(memIndex, immStatusvlpErrorIndex);
                        citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();
                  }
           }
     }

	/**
	 * @author Ritu 
	 * 			Member Number in row should be sequnce
	 * 
	 From Citizen Immigration Page, Select Immigartion Status For Members As NQP
	    |MemberNumbers 	| AlientNameSameAsAppear| AlienNumber| ArrivedInUSAfter1996|ImmStatusvlpErrorIndex|
		|1				|  TRUE  				|	223480923| TRUE				   | 29                   |
	 * @param table
	 * @throws Exception
	 */

	@When("^From Citizen Immigration Page, Select Immigartion Status For Members As NQP$")
	public void selectImmigartionStatusForMemberAsNQP(DataTable table) throws Exception {

		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);
		for (int rowIndex = 1; rowIndex < rowCount; rowIndex++) {
			String memNos = scenarioData.get(rowIndex).get(0);
			int memIndex = Integer.parseInt(memNos) - 1;
			Boolean alientNameSameAsAppear = scenarioData.get(rowIndex).get(1).equalsIgnoreCase("TRUE") ? true : false;
			String alienNumber = scenarioData.get(rowIndex).get(2);
			Boolean arrivedInUSAfter1996 = scenarioData.get(rowIndex).get(3).equalsIgnoreCase("TRUE") ? true : false;
			String lastName = elg_MemberTable.getLastNameUsingUserProfileRefId(userProfileRefId, memIndex);
			int immStatusvlpErrorIndex = Integer.parseInt(scenarioData.get(rowIndex).get(4));

			citizenImmigrationStatusPage.selectIfMemIsUSCitizen(memIndex, false);
			citizenImmigrationStatusPage.clickOnImmigrationCheckBox();
			citizenImmigrationStatusPage.clickOnReEntryPermitI327RdBtn(memIndex);
			citizenImmigrationStatusPage.enterAlienNo(alienNumber);
			citizenImmigrationStatusPage.selectIfMemNameSameAsAppearOnSSN(memIndex,alientNameSameAsAppear);
			citizenImmigrationStatusPage.selectIfMemArriveInUSAfter1960(memIndex, arrivedInUSAfter1996);
			citizenImmigrationStatusPage.selectIfMemIsVeteran(memIndex, true);
			citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();

			if (StubLogic.isMemberExpecting_NQP_RFI(lastName)) {
				citizenImmigrationStatusPage.clickOnVeriyMannualBtn();

			}

			citizenImmigrationStatusPage.selectImmStatusForMember(memIndex, immStatusvlpErrorIndex);
			citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();
		}
	}
	
	/**
	 * @author Vinay 
	 From Citizen Immigration Page, Select If Member "1" Is US Citizen As "TRUE"	
	 */
	@When("^From Citizen Immigration Page, Select If Member \"(.*?)\" Is US Citizen As \"(.*?)\"$")
	public void selectIfMemIsUSCitizen(String memNo, String usCitiStatus) throws Exception {

		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);

		int memIndex = Integer.parseInt(memNo) - 1;
		Boolean bUsCitizenStatus = usCitiStatus.equalsIgnoreCase("TRUE")?true:false;

		citizenImmigrationStatusPage.selectIfMemIsUSCitizen(memIndex, bUsCitizenStatus);
	}
	
	/**
	 * @author Vinay 
	 From Citizen Immigration Page, Select If Member "1" Is Naturalized Citizen As "FALSE"	
	 */
	@When("^From Citizen Immigration Page, Select If Member \"(.*?)\" Is Naturalized Citizen As \"(.*?)\"$")
	public void selectIfMemIsNaturalizedCitizen(String memNo, String naturalizedCitiStatus) throws Exception {

		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);

		int memIndex = Integer.parseInt(memNo) - 1;
		Boolean bNaturalizedCitizenStatus = naturalizedCitiStatus.equalsIgnoreCase("TRUE")?true:false;

		citizenImmigrationStatusPage.selectIfMemIsNaturalizedCitizen(memIndex, bNaturalizedCitizenStatus);
	}
	
	/**
	 * @author Vinay 
	 From Citizen Immigration Page, Validate Page Title is Not Having Name of Member "1"	
	 */
	@When("^From Citizen Immigration Page, Validate Page Title is Not Having Name of Member \"(.*?)\"$")
	public void validatePageTitleDontContainsName(String memNo) throws Exception {

		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
	     
	     int memIndex = Integer.parseInt(memNo)-1;
	     
	     ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		 String fullName = elgMemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
		 
		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,
				testCaseId);

		citizenImmigrationStatusPage.validatePageTitleDontContainsName(fullName);
	}
	
	//Amrita
	@When("^From Citizen Immigration Page, Click On Save And Continue$")
	public void ClickOnSaveAndContinueBtn() throws Exception {

		CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,testCaseId);
		citizenImmigrationStatusPage.pageLoadThenClickOnSaveAndContinueBtn();
		
	}
	
	/*Ritu
	 * 
	 From Citizen Immigration Page Load, Click On Save And Continue For Member "1"
      
      * */
     
     @When("^From Citizen Immigration Page Load, Click On Save And Continue For Member \"(.*?)\"$")
     public void pageLoadAndClickOnSaveAndContinueBtn(String memNo) throws Exception {
           int memIndex = Integer.parseInt(memNo)-1;
           CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,testCaseId);
           citizenImmigrationStatusPage.pageLoadThenClickOnSaveAndContinueBtn(memIndex);
            
     }

  // added by ppinho
     @When("^From Citizen Immigration Page, Click On Manual Verification For All Member, Considering All Are Non Citizen$")
     public void pageLoadThenClickOnContinueWithManualVerificationBtn() throws Exception {

     	String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
     	ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
     	int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

     	CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver, testCaseId);
     	for (int mCounter = 0; mCounter < memCount; mCounter++) {
     		citizenImmigrationStatusPage.pageLoadThenClickOnSaveAndContinueBtn(mCounter);
     		citizenImmigrationStatusPage.pageLoadThenClickOnContinueWithManualVerificationBtn(mCounter);
     		citizenImmigrationStatusPage.clickOnSaveAndContinueBtn();
     	}
     }
     // added by ppinho
     @When("^From Citizen Immigration Page, Click On Continue With Manual Verification$")
     public void ClickOnContinueWithManualVerificationBtn() throws Exception {
     	CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver,testCaseId);
     	citizenImmigrationStatusPage.pageLoadThenClickOnContinueWithManualVerificationBtn();
     }



}