package stepdefs.familyHouseHold;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import pages.familyHouseHold.EthnicityRacePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class EthnicityRacePageSteps extends SuperStepDef{
	
	public EthnicityRacePageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Ethnicity Race Page, Select Ethnicity Race For Member$")
	public void selectEthnicityRaceForMembrs() throws Exception {
		EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);
		ethnicityRacePage.selectEthnicityRaceForMembrs(evpdData.whoIsApplying, evpdData.memsData);
	}
		
	@When("^From Ethnicity Race Page, Skip Ethnicity Race For All Members$")
	public void skipEthnicityRaceForMembrs() throws Exception{
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

		EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);

		for(int mCounter=0; mCounter<memCount; mCounter++){
			ethnicityRacePage.pageLoadThenClickOnSaveAndContinueBtn(mCounter);
		}
	}
	
	@When("^From Ethnicity Race Page, Skip Ethnicity Race For All Members For SS$")
	public void skipEthnicityRaceForMembrsForSS() throws Exception{
		EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);
		String totmem = TestData.getTempTestData("MemCount",featureFileName);
		int memCount =Integer.parseInt(totmem);
		for(int mCounter=0; mCounter<memCount; mCounter++){
			ethnicityRacePage.pageLoadThenClickOnSaveAndContinueBtn(mCounter);
		}
	}
	
	//Vinay
	@When("^From Ethnicity Race Page, Skip Ethnicity Race For All Members After Validating Page Title Dont Contain Member Name$")
	public void skipEthnicityRaceForMembrsAfterValidatingPageTitleDontContainsName() throws Exception{
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

		EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);

		for(int mCounter=0; mCounter<memCount; mCounter++){
			String fullName = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, mCounter);
			
			ethnicityRacePage.pageLoadValidatePageTitleDontContainsNameThenClickOnSave(mCounter, fullName);
		}
	}
	
	/**@author Shialza

	Pre Condition:-  Members should be in sequence
	From Ethnicity Race Page, Skip Ethnicity Race For Members "2,3,4,5"
	
	 * 
	 */
	
	@When("^From Ethnicity Race Page, Skip Ethnicity Race For Members \"(.*)\"$")
	public void skipEthnicityRaceForMembrs(String memNos) throws Exception{
		
		String arrMemNos[]  = memNos.split(",");
		EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);
		for(int mCounter=0; mCounter<arrMemNos.length; mCounter++){
			int memIndex = Integer.parseInt(arrMemNos[mCounter])-1;
			ethnicityRacePage.pageLoadThenClickOnSaveAndContinueBtn(memIndex);
		}
	}
	
	/**@author sshriv16
	 * We can provide different Ethnicity List seperated by Commas
	 * 
	 * From Ethnicity Race Page, Select Ethnicity For Member "1" As "Puerto_Rican"
	 
	 Valid Ethnicity available is :- Puerto_Rican
	 								Cuban
	 								Mexican_Mexican American_or_Chicanoa
	 								
	 								
	 */
	
	@When("^From Ethnicity Race Page, Select Ethnicity For Member \"(.*)\" As \"(.*)\"$")
	public void selectEthnicityForMembers(String memNo, String ethnicityList) throws Exception{
		EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		ethnicityRacePage.selectMemOtherOriginRdBtn(memIndex, true);
		ethnicityRacePage.selectEthnicityForMember(memIndex, ethnicityList);
	}
	
	/**@author sshriv16
	 * 
	 * We can provide different Race List seperated by Commas
	 * 
	 * From Ethnicity Race Page, Select Race For Member "1" As "AMERICAN_INDIAN_OR_ALASKA_NATIVE"
		Valid Race List :- 
					AMERICAN_INDIAN_OR_ALASKA_NATIVE, 
					ASIAN_INDIAN, AFRICAN_AMERICAN
					CHINESE
					FILIPINO
					GUAMANIAN_OR_CHAMORRO
					JAPANESE
					Native_Hawaiian
					OTHER_ASIAN
					OTHER_PACIFIC_ISLANDER
					SAMOAN
					VIETNAMESE
					WHITE
					otherRaceCheck
	 */
	
	@When("^From Ethnicity Race Page, Select Race For Member \"(.*)\" As \"(.*)\"$")
	public void selectRaceForMembers(String memNo, String raceList) throws Exception{
		EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		ethnicityRacePage.selectMemOtherOriginRdBtn(memIndex, true);
		ethnicityRacePage.selectRaceForMember(memIndex, raceList);
	}
	
	@When("^From Ethnicity Race Page, Click on Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception{
		EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);
		ethnicityRacePage.clickOnSaveAndContinueBtn();
	}
	
	/**Ritu
	 
		From Ethnicity Race Page, Page Load And Click on Save And Continue For "1"
		
	 */
	@When("^From Ethnicity Race Page, Page Load And Click on Save And Continue For \"(.*)\"$")
    public void pageLoadClickOnSaveAndContinueBtn(String memNo) throws Exception{
          int memIndex = Integer.parseInt(memNo)-1;
          EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);
          ethnicityRacePage.pageLoadThenClickOnSaveAndContinueBtn(memIndex);
    }

}
