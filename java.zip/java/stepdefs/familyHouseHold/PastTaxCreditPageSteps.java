package stepdefs.familyHouseHold;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import pages.familyHouseHold.PastTaxCreditPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class PastTaxCreditPageSteps extends SuperStepDef{
	
	public PastTaxCreditPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^EVPD, From Past Tax Credit HH Page, Page Load And Click On Save And Continue Button$")
	public void evpd_pageLoadThenClickOnSaveAndContinueBtn() throws Exception {		
		PastTaxCreditPage postTaxCreditPage = new PastTaxCreditPage(driver, testCaseId);
		postTaxCreditPage.pageLoadThenClickOnSaveAndContinueBtn(evpdData.faReqd, evpdData.memsData.get(0).filingTaxes);		
	}
	
	/**
	 * @author vkuma212
	 * From Past Tax Credit HH Page, Select Past Tax Credit For House Holds
	 * | HHNos   |
	 * | 1,3,4	 |
	 
	 * @throws Exception
	 */
	@When("^From Past Tax Credit HH Page, Select Past Tax Credit For House Holds$")
	public void selectCheckBoxForHouseHold(DataTable table) throws Exception {

		List<List<String>> scenarioData = table.raw();
		String hhNos = scenarioData.get(1).get(0);
		String[] arrHHNos = hhNos.split(",");

		PastTaxCreditPage postTaxCreditPage = new PastTaxCreditPage(driver, testCaseId);
		
		for (int hhCounter = 0; hhCounter < arrHHNos.length; hhCounter++) {

			int hhIndex = Integer.parseInt(arrHHNos[hhCounter])-1;
			postTaxCreditPage.selectPastTaxCreditForHouseHold(hhIndex);
		}
		
	}
	
	@When("^From Past Tax Credit HH Page, Page Load And Click On Save And Continue Button$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		
		PastTaxCreditPage postTaxCreditPage = new PastTaxCreditPage(driver, testCaseId);
		postTaxCreditPage.pageLoadThenClickOnSaveAndContinueBtn();
		
	}
	
	@When("^From Past Tax Credit HH Page, Click On Save And Continue Button$")
	public void clickOnSaveAndContinueBtn() throws Exception {
		
		PastTaxCreditPage postTaxCreditPage = new PastTaxCreditPage(driver, testCaseId);
		postTaxCreditPage.clickOnSaveAndContinueBtn();
		
	}
		

}
