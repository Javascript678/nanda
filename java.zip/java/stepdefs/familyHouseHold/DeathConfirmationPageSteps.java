package stepdefs.familyHouseHold;
import cucumber.api.java.en.When;
import db.DualTable;
import pages.familyHouseHold.DeathConfirmationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;

public class DeathConfirmationPageSteps extends SuperStepDef{
	
	public DeathConfirmationPageSteps(Hook hook){
		super(hook);
	}
	
	/**Ritu
	 
	 From DeathConfirmation Page, Select Deceased Status For Member "1" As "TRUE"
	 
	 */
	@When("^From DeathConfirmation Page, Select Deceased Status For Member \"(.*)\" As \"(.*)\"$")
	public void evpd_pageLoadThenClickOnSaveAndContinueBtn(String memNo, String deathStatus) throws Exception {
		
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValue = deathStatus.equalsIgnoreCase("TRUE")?true:false;
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		String deathDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:10");
		DeathConfirmationPage deathConfirmationPage = new DeathConfirmationPage(driver, testCaseId);
		deathConfirmationPage.selectDeceasedStatusForMember(memIndex, trueFalseValue,deathDate);
		
	}
	
	
	@When("^From Death Confirmation Page, Click On Save And Continue Button$")
	public void clickOnSaveAndContinueBtn() throws Exception {
		
		DeathConfirmationPage deathConfirmationPage = new DeathConfirmationPage(driver, testCaseId);
		deathConfirmationPage.clickOnSaveAndContinueBtn();
		
	}
	

	@When("^From Death Confirmation Page, Click On WarningPopOk Button$")
	public void clickOnWarningPopBtn() throws Exception {
		
		DeathConfirmationPage deathConfirmationPage = new DeathConfirmationPage(driver, testCaseId);
		deathConfirmationPage.clickOnWarningPopOkBtn();
		
	}
	
	
		

}
