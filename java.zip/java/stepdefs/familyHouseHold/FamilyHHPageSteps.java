package stepdefs.familyHouseHold;

import cucumber.api.java.en.When;
import pages.familyHouseHold.FamilyHHStartPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class FamilyHHPageSteps extends SuperStepDef{
	
	public FamilyHHPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^EVPD, Complete Family House Hold Details$")
	public void completFamilyHHDetails() throws Exception {		
		FamilyHHStartPage familyHHStartPage = new FamilyHHStartPage(driver, testCaseId);
		familyHHStartPage.pageLoadThenClickOnSaveAndContinueBtn();
				
		TellUsAbtHHPageSteps tellUsAbtHHPageSteps = new TellUsAbtHHPageSteps(hook);
		tellUsAbtHHPageSteps.selectDetailsForTaxHH();
		
		PastTaxCreditPageSteps postTaxCreditPageSteps = new PastTaxCreditPageSteps(hook);
		postTaxCreditPageSteps.evpd_pageLoadThenClickOnSaveAndContinueBtn();
		
		ParentCareTakerRelativePageSteps parentCareTakerRelativePageSteps = new ParentCareTakerRelativePageSteps(hook);
		parentCareTakerRelativePageSteps.completeParentCaretakerInfo();
		
		PersonalInfoPageSteps personalInfoPageSteps = new PersonalInfoPageSteps(hook);
		personalInfoPageSteps.enterMemPersonalInfo();
		
		CitizenImmPageSteps citizenImmPageSteps = new CitizenImmPageSteps(hook);
		citizenImmPageSteps.selectImmigartionStatusForMember();
		
		EthnicityRacePageSteps ethnicityRacePageSteps = new EthnicityRacePageSteps(hook);
		ethnicityRacePageSteps.selectEthnicityRaceForMembrs();
		
		AddressDetailsPageSteps addressDetailsPageSteps = new AddressDetailsPageSteps(hook);
		addressDetailsPageSteps.enterAddressDetailsForMembers();
		
		IntendToResidePageSteps intendToResidePageSteps = new IntendToResidePageSteps(hook);
		intendToResidePageSteps.selectMembersIntendToResideOutsideMA();
		
		MoreAbtThisHHPageSteps moreAbtThisHHPageSteps = new MoreAbtThisHHPageSteps(hook);
		moreAbtThisHHPageSteps.completeMoreAboutHHForMembers();
		
		EnterHHMemberRelationshipPageSteps enterHHMemberRelationshipPageSteps = new EnterHHMemberRelationshipPageSteps(hook);
		enterHHMemberRelationshipPageSteps.selectMemsRelationship();
		
		ReasonableAccPageSteps reasonableAccPageSteps = new ReasonableAccPageSteps(hook);
		reasonableAccPageSteps.completeResonableAccForMembers();
		
		IsAnyoneInJailPageSteps isAnyoneInJailPageSteps = new IsAnyoneInJailPageSteps(hook);
		isAnyoneInJailPageSteps.provideDetailIfAnyMemberInJail();
		
		FamilyHHSummaryPageSteps familyHHSummaryPageSteps = new FamilyHHSummaryPageSteps(hook);
		familyHHSummaryPageSteps.pageLoadThenClickOnSaveAndContinueAndHandleContinueAppIssue();
		
	}
	
	@When("^From Family HH Start Page, Click On Save And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		
		FamilyHHStartPage familyHHStartPage = new FamilyHHStartPage(driver, testCaseId);
		familyHHStartPage.pageLoadThenClickOnSaveAndContinueBtn();
	}

}
