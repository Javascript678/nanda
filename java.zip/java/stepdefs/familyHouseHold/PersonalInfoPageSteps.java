package stepdefs.familyHouseHold;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import pages.familyHouseHold.PersonalInformationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.RandomGenerator;
import utils.TestData;

public class PersonalInfoPageSteps extends SuperStepDef{
	
	public PersonalInfoPageSteps(Hook hook){
		super(hook);
	}
	
	//Vinay
	@When("^From Personal Info Page, Enter Member Personal Information$")
	public void enterMemPersonalInfo() throws Exception {		
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
		personalInformationPage.enterMemPersonalInfo(evpdData.whoIsApplying, evpdData.memsData);		
	}
	
	/**@author vkuma212
	 * AcceptedValue :- MemNo :- 1,2,3,4
	 * 					Gender :- M,F
	 * 					SSN Fomat :- "BLANK" means any random SSN
	 * 								 STR_3, END_5, NO_JA
	 
	 And From Personal Info Page, Enter Personal Information For Members
		|   MemNo		|Gender |	SSNFormat|
		|	1			|	M	| 			 |
		|	2			|	F	| 			 |

	 */
	@When("^From Personal Info Page, Enter Personal Information For Members$")
	public void enterPersonalInformationForMember(DataTable table) throws Exception{
		
		
		
		List<List<String>> scenarioData = table.raw();
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
		
		int rowCount = scenarioData.size();
		
		for(int rowCounter=1;rowCounter<rowCount;rowCounter++){
			
			String strMemNo = scenarioData.get(rowCounter).get(0);
			String gender = scenarioData.get(rowCounter).get(1);
			String ssnFormat = scenarioData.get(rowCounter).get(2);
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			
			personalInformationPage.selectMemGender(memIndex, gender);
			
			String[] ssnStatus = RandomGenerator.getRunTimeSSN(ssnFormat);
			
			Boolean hasSSN = ssnStatus[0].equals("true")?true:false;
			personalInformationPage.selectIfMemHasSSN(memIndex, hasSSN);
			
			if(hasSSN){
				personalInformationPage.enterSSN(memIndex, ssnStatus[1]);
				personalInformationPage.selectIfMemNameSameAsONSSNCardRdBtn(memIndex, true);
				personalInformationPage.clickOnSaveAndContinueBtn();
			}else{
				personalInformationPage.selectMemNoSSNReason(memIndex, ssnStatus[2]);
				personalInformationPage.clickOnSaveAndContinueBtn();
			}
		}
		
		
	}
	
	/**
	 * @author abajpai3
	 * AcceptedValue :- MemNo :- 1,2,3,4
	 * 					Gender :-M
	  							 F
	 * From Personal Info Page, Select Member "1" Gender Status As "M"
	 */
	@When("^From Personal Info Page, Select Member \"(.*?)\" Gender Status As \"(.*?)\"$")
	 public void selectMemGender(String memNo, String gender) throws Exception{
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
		int memberNo=Integer.parseInt(memNo)-1;
			
		personalInformationPage.selectMemGender(memberNo, gender);
		
	}
	
	/**
	 * abajpai3
	 * AcceptedValue :- MemNo :- 1,2,3,4
	 * 					Has SSN :-TRUE
	 * 							  FALSE
	 * 										
	 * From Personal Info Page, Select Member "1" Has SSN As "TRUE"
	 */
	@When("^From Personal Info Page, Select Member \"(.*?)\" Has SSN As \"(.*?)\"$")
	public void selectIfMemHasSSN(String memNo, String hasSSN) throws Exception{
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
		int memberNo=Integer.parseInt(memNo)-1;
		boolean memHasSSN=Boolean.parseBoolean(hasSSN);
		personalInformationPage.selectIfMemHasSSN(memberNo, memHasSSN);
	}
	
	/**
	 * @author abajpai3
	 * AcceptedValue :- MemNo :- 1,2,3,4
	 * 					Want To Provide SSN :-TRUE
	 * 										  FALSE
	 * 												 
	 * From Personal Info Page, Select Will Member "1" Want to Provide SSN As "TRUE"
	 */
	@When("^From Personal Info Page, Select Will Member \"(.*?)\" Want to Provide SSN As \"(.*?)\"$")
	 public void selectIfMemWantToProvideSSN(String memNo, String  provideSSN) throws Exception{
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
		int memberNo=Integer.parseInt(memNo)-1;
		boolean wantToProvideSSN=Boolean.parseBoolean(provideSSN);
		personalInformationPage.selectIfMemWantToProvideSSN(memberNo, wantToProvideSSN);
	}
	
	/**
	 * @author abajpai3
	 * 
	 * AcceptedValue :- MemNo :- 1,2,3,4
	 * 					SSN Fomat :- "BLANK" means any random SSN
	 * 								 STR_3, END_5, NO_JA
	 * 					SSN :-Any 9 digit numeric value
	 From Personal Info Page, For Member "1", Enter SSN With Format As "STR_3"
	 										 
	 */
	@When("^From Personal Info Page, For Member \"(.*?)\", Enter SSN With Format As \"(.*?)\"$")
	public void enterSSN(String memNo, String ssnFormat) throws Exception{
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
		int memberNo=Integer.parseInt(memNo)-1;	
		String[] ssnVal = RandomGenerator.getRunTimeSSN(ssnFormat);
		personalInformationPage.enterSSN(memberNo, ssnVal[1]);
	}
	
	/**
	 * @author abajpai3
	 * 
	 * AcceptedValue :- MemNo :- 1,2,3,4
	 * 					Name Same On SSN Card :- TRUE
	 * 											 FALSE
	 From Personal Info Page, Select Member "1" Name Same As On SSN Card As "TRUE"
	 			   												 
	 */
	@When("^From Personal Info Page, Select Member \"(.*?)\" Name Same As On SSN Card As \"(.*?)\"$")
	public void selectIfMemNameSameAsONSSNCardRdBtn(String memNo, String memNameSame) throws Exception{
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
			int memberNo=Integer.parseInt(memNo)-1;	
			boolean memNameSameOnSSNCard=Boolean.parseBoolean(memNameSame);
			personalInformationPage.selectIfMemNameSameAsONSSNCardRdBtn(memberNo, memNameSameOnSSNCard);
	}
	
	@When("^From Personal Info Page, Click On Save And Continue For All Members$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
		
		for(int rowCounter=0;rowCounter<memCount;rowCounter++){
			personalInformationPage.pageLoadThenClickOnSaveAndContinueBtn(rowCounter);
		}
	}
	
	/*Ritu
     * 
        From Personal Info Page, Click On Save And Continue For "2" Members
     *  */

	@When("^From Personal Info Page, Click On Save And Continue For \"(.*?)\" Members$")
	public void pageLoadThenClickOnSaveAndContinueBtn(String memnos) throws Exception{
	     
	     
	     int memCount = Integer.parseInt(memnos);
	     PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
	     
	     for(int rowCounter=0;rowCounter<memCount;rowCounter++){
	            personalInformationPage.pageLoadThenClickOnSaveAndContinueBtn(rowCounter);
	     }
	}
	
	/*Ritu
     * 
        From Personal Info Page, Click On Save And Continue For Member "3" Only
        
     *  */

	@When("^From Personal Info Page, Click On Save And Continue For Member \"(.*?)\" Only$")
	public void pageLoadThenClickOnSaveAndContinueBtnForMemOnly(String memno) throws Exception{
	     
	     
	     int memIndex = Integer.parseInt(memno)-1;
	     PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
         personalInformationPage.pageLoadThenClickOnSaveAndContinueBtn(memIndex);
	}

	@When("^From Personal Info Page, Click On Save And Continue$")
    public void ClickOnSaveAndContinueBtn() throws Exception{
        
         PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
      personalInformationPage.clickOnSaveAndContinueBtn();
    }

	// added by ppinho
	@When("^From Personal Info Page, Validate SSN is Masked For Member \"(.*?)\", Then Click On Save And Continue$")
	public void pageLoadValidateSSNIsMaskedThenClickOnSaveAndContinueBtn(String memNo) throws Exception{  
	       int memIndex = Integer.parseInt(memNo)-1;
	             
	       PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);         
	       personalInformationPage.pageLoadValidateSSNIsMaskedThenClickOnSaveAndContinueBtn(memIndex);
	}

	/*Vinay
     * 
        From Personal Info Page, Validate Page Title is Not Having Name of Member "1"
        
     *  */

	@When("^From Personal Info Page, Validate Page Title is Not Having Name of Member \"(.*?)\"$")
	public void validatePageTitleDontContainsName(String memNo) throws Exception{
		 String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
	     
	     int memIndex = Integer.parseInt(memNo)-1;
	     
	     ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		 String fullName = elgMemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
	     PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
         personalInformationPage.validatePageTitleDontContainsName(fullName);
	}
	
	
	@When("^From Personal Info Page, Validate SSN is Masked , Then Click On Save And Continue For All Members$")
	public void pageLoadValidateSSNIsMaskedThenClickOnSaveAndContinueBtn() throws Exception{
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
		
		for(int rowCounter=0;rowCounter<memCount;rowCounter++){
			personalInformationPage.pageLoadValidateSSNIsMaskedThenClickOnSaveAndContinueBtn(rowCounter);
		}
	}
		

}
