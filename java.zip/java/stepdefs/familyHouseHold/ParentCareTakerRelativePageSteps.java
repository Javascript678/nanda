package stepdefs.familyHouseHold;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import pages.familyHouseHold.ParentCaretakerRelativesPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ParentCareTakerRelativePageSteps extends SuperStepDef{
	
	public ParentCareTakerRelativePageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Parent Care Taker Relative Page, Complete Information$")
	public void completeParentCaretakerInfo() throws Exception {		
		ParentCaretakerRelativesPage parentCaretakerRelativesPage = new ParentCaretakerRelativesPage(driver, testCaseId);
		parentCaretakerRelativesPage.completeParentCaretakerInfo(evpdData.faReqd, evpdData.memsData);		
	}
	
	/**
	 * Accepted Value :-  MemNo = 1
	 * 					  LivingWithAtleastOneU19Child  :-  TRUE, FALSE
	 
	 From Parent Care Taker Relative Page, Select Member "1" Living with Atleaset One U19 Child As "TRUE"
	 
	 */
	@When("^From Parent Care Taker Relative Page, Select Member \"(.*?)\" Living with Atleaset One U19 Child As \"(.*?)\"$")
	public void selectIfMemLivingWithAtleastOneU19Child(String memNo, String  livingWithAtleastOneU19Child) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValue = livingWithAtleastOneU19Child.equalsIgnoreCase("TRUE")?true:false;
		
		ParentCaretakerRelativesPage parentCaretakerRelativesPage = new ParentCaretakerRelativesPage(driver, testCaseId);
		parentCaretakerRelativesPage.selectIfMemLivingWithAtleastOneU19Child(memIndex, trueFalseValue);
		
	}
	
	/**
	 * Accepted Value :-  MemNo = 1
	 * 					  U19MembersLivingWithMember  :-  2,3,4,5,6,7
	 * @param table
	 * @throws Exception
	 */
	@When("^From Parent Care Taker Relative Page, Select U19 Members Living With Members$")
	public void selectU19MemsLivingWithMember(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String memNo = scenarioData.get(1).get(0);
		
		String u19MemNos  = scenarioData.get(1).get(1);
		String[] arrU19MemNos = u19MemNos.split(",");
		
		ParentCaretakerRelativesPage parentCaretakerRelativesPage = new ParentCaretakerRelativesPage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		
		for(int mCounter=0;mCounter < arrU19MemNos.length; mCounter++){
			
			int u19MemIndex = Integer.parseInt(arrU19MemNos[mCounter])-1;
			parentCaretakerRelativesPage.selectU19MemsLivingWithMember(memIndex, u19MemIndex+"");
		}
	}
	
	/**
	 * Accepted Value :-  MemNo = 1
	 * 					  U19Members  :-  2,3,4,5,6,7
	 * 					  isU19MemLivingWithTwoBirthOrAdoptiveParents :- TRUE, FALSE
	 * @param table
	 * @throws Exception
	 */
	@When("^From Parent Care Taker Relative Page, Select If U19 Members Living With Two Birth Or Adoptive Parents$")
	public void selectIfMemLivingWithTwoBirthOrAdoptiveParent(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String memNo = scenarioData.get(1).get(0);
		String u19MemNos  = scenarioData.get(1).get(1);
		String isU19MemLivingWithTwoBirthOrAdoptiveParents =scenarioData.get(1).get(2); 
		
		String[] arrU19MemNos = u19MemNos.split(",");
		
		ParentCaretakerRelativesPage parentCaretakerRelativesPage = new ParentCaretakerRelativesPage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValue = isU19MemLivingWithTwoBirthOrAdoptiveParents.equalsIgnoreCase("TRUE")?true:false;
		
		for(int mCounter=0;mCounter < arrU19MemNos.length; mCounter++){
			
			int u19MemIndex = Integer.parseInt(arrU19MemNos[mCounter].trim())-1;
			parentCaretakerRelativesPage.selectIfMemLivingWithTwoBirthOrAdoptiveParent(memIndex, u19MemIndex,trueFalseValue );
		}
	}
	
	/**Paul
	 * From Parent Care Taker Relative Page, Select Member "1" And Member "3" Relationship As "Parent"
	 * From Parent Care Taker Relative Page, Select Member "1" And Member "3,4" Relationship As "Parent"
	 * From Parent Care Taker Relative Page, Select Member "1" And Member "3,4,5" Relationship As "Parent"
	 */
	@When("^From Parent Care Taker Relative Page, Select Member \"(.*?)\" And Member \"(.*?)\" Relationship As \"(.*?)\"$")
	public void answerMemberRelationship(String memOneNo,  String memTwoNo, String CommonRelationShip ) throws Exception{
		
		int memIndex = Integer.parseInt(memOneNo)-1;
		String[] arrMemNos = memTwoNo.split(",");
		
		ParentCaretakerRelativesPage parentCaretakerRelativesPage = new ParentCaretakerRelativesPage(driver, testCaseId);
		for(int mCouter=0;mCouter<arrMemNos.length;mCouter++){
			int depIndex =  Integer.parseInt(arrMemNos[mCouter])-1;
			
			parentCaretakerRelativesPage.answerMemberRelationship(memIndex, depIndex, CommonRelationShip);
		}
	}
	
	@When("^From Parent Care Taker Relative Page, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception{
		
		ParentCaretakerRelativesPage parentCaretakerRelativesPage = new ParentCaretakerRelativesPage(driver, testCaseId);
		parentCaretakerRelativesPage.clickOnSaveAndContinueBtn();
	}
	
	@When("^From Parent Care Taker Relative Page, Page Load And Click On Save And Continue$")
	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception{
		
		ParentCaretakerRelativesPage parentCaretakerRelativesPage = new ParentCaretakerRelativesPage(driver, testCaseId);
		parentCaretakerRelativesPage.pageLoadAndClickOnSaveAndContinueBtn();
	}
	
}
