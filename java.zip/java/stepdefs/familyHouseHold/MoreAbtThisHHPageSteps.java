package stepdefs.familyHouseHold;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import db.DualTable;
import db.ElgMemberTable;
import pages.familyHouseHold.MoreAboutThisHHPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class MoreAbtThisHHPageSteps extends SuperStepDef{
	
	public MoreAbtThisHHPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From More About This HH Page, Complete More About HH For Members$")
	public void completeMoreAboutHHForMembers() throws Exception {
		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);
		moreAboutThisHHPage.completeMoreAboutHHForMembers(evpdData.faReqd, evpdData.whoIsApplying, evpdData.memsData);		
	}
	
	/**@author vkuma212
	 From More About This HH Page, Select Members With Disability Status
		|	MemberNos 		|	
		|     1,2,3,4,5		|	
	 */
	@When("^From More About This HH Page, Select Members With Disability Status$")
	public void selectIfMemberIsDisbaled(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String memNos = scenarioData.get(1).get(0);
		String[] arrMemNos = memNos.split(",");
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);

		for(int mCounter=0; mCounter<arrMemNos.length; mCounter++){
			int memIndex = Integer.parseInt(arrMemNos[mCounter])-1;
			moreAboutThisHHPage.selectIfMemberIsDisbaled(memIndex,memCount); 
		}		
	}
	
	/**@author sshriv16
	 * From More About This HH Page, Select Members Who Are American Indian Or Alaskan Native
		|	MemberNo 		| State    | Tribe  |	
		|     1				|		   |        |
	 */

	@When("^From More About This HH Page, Select Members Who Are American Indian Or Alaskan Native$")
	public void selectIfMemberIsAIAN(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);

		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			String memNos = scenarioData.get(rowIndex).get(0);
			String state = scenarioData.get(rowIndex).get(1);
			String tribe = scenarioData.get(rowIndex).get(2);
			
			int memIndex = Integer.parseInt(memNos)-1;
			moreAboutThisHHPage.selectIfMemberIsAIAN(memIndex,memCount); 
			moreAboutThisHHPage.selectAIANStateForMember(memIndex, state);
			moreAboutThisHHPage.selectAIANTribeForMember(memIndex, tribe);
		}		
	}
	
	/**@author sshriv16
	 * From More About This HH Page, Select Members Who Have Been In Foster Care
		|	MemberNo 		| State   | Age    |	
		|     2				|	MA	  |   18   |
	 */

	@When("^From More About This HH Page, Select Members Who Have Been In Foster Care$")
	public void selectIfMemberHasBeenInFosterCare(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		//to be used if foster care have Rd button for 1 member
		/*String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);*/

		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);

		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			String memNo = scenarioData.get(rowIndex).get(0);
			String state = scenarioData.get(rowIndex).get(1);
			int age = Integer.parseInt(scenarioData.get(rowIndex).get(2));
			
			int memIndex = Integer.parseInt(memNo)-1;
			
			moreAboutThisHHPage.selectIfMemberWasInFosterCare(memIndex, rowCount);   //memCount to be used if foster care have Rd button for 1 member
			moreAboutThisHHPage.selectFosterCareStateForMember(memIndex, state);
			moreAboutThisHHPage.selectYesForFosterCareMemberhasStatePlan(memIndex);
			moreAboutThisHHPage.selectFosterCareAgeLeftForMember(memIndex, age);
		}		
	}
	
	/**@author sshriv16
	 * From More About This HH Page, Select Members Who Have Breast Or Cervical Cancer
		|	MemberNos 		|	
		|     1,2,3,4,5		|	
	 */

	@When("^From More About This HH Page, Select Members Who Have Breast Or Cervical Cancer$")
	public void selectIfMemberHasBCC(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String memNos = scenarioData.get(1).get(0);
		String[] arrMemNos = memNos.split(",");
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);

		for(int mCounter=0; mCounter<arrMemNos.length; mCounter++){
			int memIndex = Integer.parseInt(arrMemNos[mCounter])-1;
			moreAboutThisHHPage.selectIfMemberIsBreastCancerPatient(memIndex,memCount); 
		}		
	}
	
	/**@author sshriv16
	 * From More About This HH Page, Select Members Who Have HIV
		|	MemberNos 		|	
		|     1,2,3,4,5		|	
	 */

	@When("^From More About This HH Page, Select Members Who Have HIV$")
	public void selectIfMemberHasHIV(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String memNos = scenarioData.get(1).get(0);
		String[] arrMemNos = memNos.split(",");
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);

		for(int mCounter=0; mCounter<arrMemNos.length; mCounter++){
			int memIndex = Integer.parseInt(arrMemNos[mCounter])-1;
			moreAboutThisHHPage.selectIfMemberIsHIVPatient(memIndex,memCount); 
		}		
	}
	
	/**@author vkuma212
	 * From More About This HH Page, Select Members With Pregnant Status and Child Count
		| MemNo | BabyCount |
		| 1		|   2		|
	 * @throws Exception
	 */
	@When("^From More About This HH Page, Select Members With Pregnant Status and Child Count$")
	public void selectIfMemberIsPregnant(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();

		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		int rowCount = scenarioData.size();
		
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		
		//consider baby was born 10 days before app Date
		String babyDueDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:-10");

		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			String memNo = scenarioData.get(rowIndex).get(0);
			String babyCount = scenarioData.get(rowIndex).get(1);
			int memIndex = Integer.parseInt(memNo)-1;
			int intBabyCount = Integer.parseInt(babyCount);
			
			moreAboutThisHHPage.selectIfMemberIsPregnant(memIndex,memCount); 
			moreAboutThisHHPage.selectPregMemberBabyCount(memIndex, intBabyCount);
			moreAboutThisHHPage.enterPregMemberBabyDueDate(memIndex, babyDueDate);
		}		
	}
	
	@When("^From More About This HH Page, Page Load And Click On Save and Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);
		moreAboutThisHHPage.pageLoadThenClickOnSaveAndContinueBtn();
	}
	
	@When("^From More About This HH Page, Click On Save and Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception{
		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);
		moreAboutThisHHPage.clickOnSaveAndContinueBtn();
	}
	
	
	@When("^From More About This HH Page, Select Members Who Are American Indian Or Alaskan Native For SS$")
	public void selectIfMemberIsAIANSS(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
	
		String memCou = TestData.getTempTestData("MemberCount", featureFileName);
		int memCount=Integer.parseInt(memCou);

		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);

		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			String memNos = scenarioData.get(rowIndex).get(0);
			String state = scenarioData.get(rowIndex).get(1);
			String tribe = scenarioData.get(rowIndex).get(2);
			
			int memIndex = Integer.parseInt(memNos)-1;
			moreAboutThisHHPage.selectIfMemberIsAIAN(memIndex,memCount); 
			moreAboutThisHHPage.selectAIANStateForMember(memIndex, state);
			moreAboutThisHHPage.selectAIANTribeForMember(memIndex, tribe);
		}		
	}
	@When("^From More About This HH Page, Take Screenshot$")
	public void takeScreenshot() throws Exception{
		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);
		moreAboutThisHHPage.takeScreenshot();
	}
	
	/**@author rnegi101
	 *From More About This HH Page, Removed Member Pragnancy and set Pregnacy end Date
		| MemNo |           
		| 2		|   	    
	 * @throws Exception
	 */
	@When("^From More About This HH Page, Removed Member Pragnancy and set Pregnacy end Date$")
	public void removeMemberPregnancy(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();

		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		int rowCount = scenarioData.size();
		
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		
		//consider baby was born 5 days before app Date
		String pregEndDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:05");
		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			String memNo = scenarioData.get(rowIndex).get(0);
			int memIndex = Integer.parseInt(memNo)-1;
			
			moreAboutThisHHPage.selectIfMemberIsPregnant(memIndex,memCount); 
			moreAboutThisHHPage.enterPregMemberEndDate(memIndex, pregEndDate);
		}	
		
		
	}
	
	/*
	 * Ritu 
    */
	
	@When("^From More About This HH Page, Select None of these Pregnant$")
	public void selectNoneOfTheseMemberIsPregnant() throws Exception{
		MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);
		moreAboutThisHHPage.selectNoneOfTheseMemberIsPregnant();
	}
	
	/*
     * Ritu 
  */
     
     @When("^From More About This HH Page, Select None of these BCC$")
     public void selectNoneOfTheseMemberIsBCC() throws Exception{
           MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);
           moreAboutThisHHPage.selectNoneOfTheseMemberIsBCC();
     }


}
