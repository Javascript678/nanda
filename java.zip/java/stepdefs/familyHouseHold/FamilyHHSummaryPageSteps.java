package stepdefs.familyHouseHold;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import pages.familyHouseHold.FamilyHHSummaryPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class FamilyHHSummaryPageSteps extends SuperStepDef{
	
	public FamilyHHSummaryPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Family HH Summary Page, Click On Save And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		
		FamilyHHSummaryPage familyHHSummaryPage = new FamilyHHSummaryPage(driver, testCaseId);
		familyHHSummaryPage.pageLoadThenClickOnSaveAndContinueBtn();
	}
	
	@When("^From Family HH Summary Page, Click On Save And Continue And Handle Continue App Issue$")
	public void pageLoadThenClickOnSaveAndContinueAndHandleContinueAppIssue() throws Exception {		
		FamilyHHSummaryPage familyHHSummaryPage = new FamilyHHSummaryPage(driver, testCaseId);
		familyHHSummaryPage.pageLoadThenClickOnSaveAndContinueAndHandleContinueAppIssue();
	}
	
	/**
	 * @author sshriv16
	
	 From Family HouseHold Summary Page, Validate SSN Is Masked For Member "1,2,3,4"
	
	 */
	@When("^From Family HouseHold Summary Page, Validate SSN Is Masked For Member \"(.*?)\"$")
	public void validateSSNForMembers(String memNos) throws Exception{
		String arrMemNo[] = memNos.split(",");
		
		FamilyHHSummaryPage familyHHSummaryPage = new FamilyHHSummaryPage(driver, testCaseId);
		for(int memCounter=0; memCounter<arrMemNo.length; memCounter++){
			int memIndex = Integer.parseInt(arrMemNo[memCounter])-1;
			familyHHSummaryPage.validateSSNIsMaskedForMember(memIndex);
		}
	}
	
	/**
	 * @author sshriv16
	 From Family HouseHold Summary Page, Validate Whether The Member Is Applying For Coverage
	 | MemNo   | Applying For Coverage		|
	 |  1	   | TRUE   					|
	 |  2	   | FALSE   					|
	 * @throws Exception
	 */
	@When("^From Family HouseHold Summary Page, Validate Whether The Member Is Applying For Coverage$")
	public void validateMemberApplyingForCoverage(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		FamilyHHSummaryPage familyHHSummaryPage = new FamilyHHSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String applyingForCoverage = scenarioData.get(rowIndex).get(1).equalsIgnoreCase("TRUE")?"Yes":"No";
			familyHHSummaryPage.validateIfMemberIsApplyingForCoverage(memIndex, applyingForCoverage);
		}
	}
	
	/**
	 * @author sshriv16
	 From Family HouseHold Summary Page, Validate Whether The Member Is Incarcerated
	 | MemNo   | Incarcerated				|
	 |  1	   | TRUE   					|
	 |  2	   | FALSE   					|
	 * @throws Exception
	 */
	@When("^From Family HouseHold Summary Page, Validate Whether The Member Is Incarcerated$")
	public void validateMemberIsIncarcerated(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		FamilyHHSummaryPage familyHHSummaryPage = new FamilyHHSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String memberIncarcerated = scenarioData.get(rowIndex).get(1).equalsIgnoreCase("TRUE")?"Yes":"No";
			familyHHSummaryPage.validateIfMemberIsIncarcerated(memIndex, memberIncarcerated);
		}
	}
	
	/**
	 * @author sshriv16
	 From Family HouseHold Summary Page, Validate Member Relationship To TaxHH
	 |TaxHHNo	| MemNo   	| Relationship				|
	 |2			|  1	   	| Spouse   					|
	 |1			|  2	   	| Child   					|
	 * @throws Exception
	 */
	@When("^From Family HouseHold Summary Page, Validate Member Relationship To TaxHH$")
	public void validateMemberRelationShipToTaxHH(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		FamilyHHSummaryPage familyHHSummaryPage = new FamilyHHSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int TaxHHIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(1))-1;
			String relationShip = scenarioData.get(rowIndex).get(2);
			familyHHSummaryPage.validateMemberRelationShipWithTaxHH(TaxHHIndex, memIndex, relationShip);
		}
	}
	
	/**
	 * @author ppinho

	 From Family HH Summary Page, Click On Duplicate App Warning Pop Up
		
	 */
	@When("^From Family HH Summary Page, Click On Duplicate App Warning Pop Up$")
	public void pageLoadThenClickOnDuplicateAppWarningPopUp() throws Exception {		
		FamilyHHSummaryPage familyHHSummaryPage = new FamilyHHSummaryPage(driver, testCaseId);
		familyHHSummaryPage.clickOnDuplicateWarningPopUpBtn();
	}

		

}
