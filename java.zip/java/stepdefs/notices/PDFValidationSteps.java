package stepdefs.notices;

import java.io.File;
import java.util.HashMap;
import java.util.Scanner;

import cucumber.api.java.en.Then;
import db.AddressTable;
import db.ElgMemberTable;
import notices.PDFDataCheck;
import pages.manageCustomer.FindAndViewMedicaidNoticesPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;

public class PDFValidationSteps extends SuperStepDef {

	public PDFValidationSteps(Hook hook) {
		super(hook);
	}

	/** This method is limited for APPR_STD as of now.
	 * 
	 Download PDF With Notice Type As "APPR-STD" For Member "2"
	 
	 */
	@Then("^Download PDF With Notice Type As \"([^\"]*)\" For Member \"([^\"]*)\"$")
	public void print_following_queries(String nType, int memNo) throws Throwable {
		String elgId = getTempTestData("CurrentEligibilityId");
		
		int memIndex = memNo-1;
		FindAndViewMedicaidNoticesPage findAndViewMedicaidNoticesPage = new FindAndViewMedicaidNoticesPage(driver, testCaseId);
	        
        ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
        
        String memFName =  elg_MemberTable.getFirstName(elgId, memIndex);
        String memLName = elg_MemberTable.getLastName(elgId, memIndex);
        String memDOB = elg_MemberTable.getDOB(elgId, memIndex);
        memDOB = DateUtil.getDateInUIFormatUsingPattern(memDOB, DateUtil.dbDatePattern);
                       
        //download PDF from UI
        findAndViewMedicaidNoticesPage.enterSearchDetailsAndClickOnSearchButton(elgId, memDOB, memFName, memLName);
        findAndViewMedicaidNoticesPage.downloadNotices(elgId, memFName, memLName, nType);
					
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn,testCaseId);
		String name = elgMemberTable.getFullName(elgId, memIndex);
		
		AddressTable addressTable = new AddressTable(conn,testCaseId);
		String address = addressTable.getAdressUsingElgId(elgId, memIndex);
				
		
    	StringBuilder sb = new StringBuilder();
		Scanner sc = new Scanner(name);
		while(sc.hasNext())
		{
			String a=sc.next();
			String firstLetter = a.substring(0,1).toUpperCase();
			String restLetters = a.substring(1).toLowerCase();

			sb.append(firstLetter + restLetters+" ");
			
		}
		name =sb.toString().trim(); 
		 
		int fn = address.indexOf('\n');
		String hohadd1 = address.substring(0, fn).trim();
		address = address.substring(fn+1).trim();
		int sn = address.indexOf('\n');
		String hohadd2 = address.substring(0,sn).trim();
		String hohadd3 = address.substring(sn+1).trim();
		
		HashMap<String, String> expectedValuesHM = new HashMap<String, String>();

	    //adding elements to the hashmap
		expectedValuesHM.put("HOHName", name);
		expectedValuesHM.put("Add1", hohadd1);
		expectedValuesHM.put("Add2", hohadd2);
		expectedValuesHM.put("Add3", hohadd3);
	    
//	    Old sample
//	    expectedValuesHM.put("HOHName", name);
//	    expectedValuesHM.put("HOHAdd1", hohadd1);
//	    expectedValuesHM.put("HOHAdd2", hohadd2);
//	    expectedValuesHM.put("HOHAdd3", hohadd3);
		
//		System.out.println(address.indexOf('\n'));
//		System.out.println(address.substring(10).indexOf('\n'));
//		System.out.println(sb.toString());
//		MedicaidNoticeVal medicaidNoticeVal = new MedicaidNoticeVal(conn, testCaseId);
//		String name = medicaidNoticeVal.getFullNameOfMemUsingRef_iId(referenceId, memNo);
//		String address = medicaidNoticeVal.getHohAdressByRef_id(referenceId);
//		String ncd = medicaidNoticeVal.getNoticeCreationDateByRef_id(referenceId);
//		String ssn = medicaidNoticeVal.getSSNNumberUsingRef_id(referenceId, memNo);
		System.out.println(name+"\n"+address+"\n");
		
		String sampleFile="src"+File.separator+"main"+File.separator+"resources"+File.separator+"Notice_Pdf" + File.separator + "APPR_STD_1.pdf";
		String actualFile="Test_Report\\PDFValidation\\PDF\\"+elgId+"_"+memFName+"_"+memLName+"_"+nType+".pdf";
		
		PDFDataCheck pDFDataCheck = new PDFDataCheck(testCaseId,sampleFile,actualFile);
		pDFDataCheck.dynamicPDFMatch(expectedValuesHM);
		sc.close();
		
		
	}
	
	
}
