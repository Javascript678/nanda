package stepdefs.overrideEligibility;

import pages.overrideEligibility.*;

import java.util.List;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import db.DualTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;

public class OverrideEligibiltyPageSteps extends SuperStepDef {

	public OverrideEligibiltyPageSteps(Hook hook) {
		super(hook);
	}

	/**
	 * Ritu From Override Eligibility Page, Validate Error Message
	 */
	@And("^From Override Eligibility Page, Validate Error Message$")
	public void vaidateErrorMsg() throws Exception {

		OverrideEligibiltyPage OverrideEligibiltyPage = new OverrideEligibiltyPage(driver, testCaseId);
		OverrideEligibiltyPage.validateErrorMessage();
	}

	/**
	 * @author Ritika
	 * 
	
	From Override Eligibility Page,Enter Details on Override Tab 
	 | MemNo 	| PrimaryProgram 											|SecondaryProgram	| MassHealthCov 				|AidCategory 	| StartDate | EndDate 	| 
	 | 1 		|MassHealth 												| NONE 				|MassHealth CarePlus			| D1 			| 10 		| -20 		|
	 | 1 		|MassHealth Children's Health Insurance Program (CHIP) 		| NONE 				|MassHealth Family Assistance	| 93 			| 10 		| -20 		|
	 
	 */

	@Given("^From Override Eligibility Page,Enter Details on Override Tab$")
	public void selectOverrideDetails(DataTable table) throws Exception {
		List<List<String>> scenarioData = table.raw();
		String memNo = scenarioData.get(1).get(0);

		String primaryPg = scenarioData.get(1).get(1).trim();
		String secPg = scenarioData.get(1).get(2).trim();
		String massHealthCov = scenarioData.get(1).get(3).trim();
		String aidCat = scenarioData.get(1).get(4).trim();
		String stDate = scenarioData.get(1).get(5).trim();
		String eDate = scenarioData.get(1).get(6).trim();

		String currentDate = new DualTable(conn, "").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);

		OverrideEligibiltyPage overrideEligibilty = new OverrideEligibiltyPage(driver, testCaseId);
		overrideEligibilty.clickOnOverrideTab();
		overrideEligibilty.clickOnOverride();

		String[] arrMemNos = memNo.split(",");
		for (int mCouter = 0; mCouter < arrMemNos.length; mCouter++) {
			int memIndex = Integer.parseInt(arrMemNos[mCouter]) - 1;
			overrideEligibilty.clickOnMemberChkBx(memIndex);
		}
		overrideEligibilty.clickOnEditBtn();
		overrideEligibilty.selectPrimaryPgTypeDD(primaryPg);

		if (!secPg.equalsIgnoreCase("NONE")) {
			overrideEligibilty.selectSecondaryProgTypeDD(secPg);
		}
		if(primaryPg.equalsIgnoreCase("MassHealth"))
			overrideEligibilty.selectMassHltCovDD(massHealthCov);
		else
			overrideEligibilty.selectMassHltCovDDForCHIP(massHealthCov);
		overrideEligibilty.selectAidCategoryDD(aidCat);

		if (!stDate.equalsIgnoreCase("NONE")) {
			String startDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern,
					"00:00:" + stDate);
			overrideEligibilty.enterBenefitStartDateTxt(startDate);
		}
		if (!eDate.equalsIgnoreCase("NONE")) {
			String endDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern,
					"00:00:" + eDate);
			overrideEligibilty.enterProtectionEndDateTxt(endDate);
		}
	}

	/**
	 * @author Ritu 
	 * Accepted Aid Cat :- 37, 1X, NONE
	 * 
	 From Override Eligibility Page,Enter Details on Override Tab For Program Type As ConnectorcarePlanAndAPTC 
	 | MemNo 	|	PrimaryProgram 		|SecondaryProgram 					| PlanType 	| AidCategory 	|StartDate 	| EndDate | 
	 | 2 		| ConnectorCare Plans 	|	 Limited + Health Safety Net 	| 1 		| 37 			| 0 		| -33 	  |
	  
	 */

	@Given("^From Override Eligibility Page,Enter Details on Override Tab For Program Type As ConnectorcarePlanAndAPTC$")
	public void selectOverrideDetailsForCCAPTC(DataTable table) throws Exception {
		List<List<String>> scenarioData = table.raw();
		String memNo = scenarioData.get(1).get(0);

		String primaryPg = scenarioData.get(1).get(1).trim();
		String secPg = scenarioData.get(1).get(2).trim();
		String planType = scenarioData.get(1).get(3).trim();
		String aidCat = scenarioData.get(1).get(4).trim();
		String stDate = scenarioData.get(1).get(5).trim();
		String eDate = scenarioData.get(1).get(6).trim();

		String currentDate = new DualTable(conn, "").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);

		OverrideEligibiltyPage overrideEligibilty = new OverrideEligibiltyPage(driver, testCaseId);
		overrideEligibilty.clickOnOverrideTab();
		overrideEligibilty.clickOnOverride();

		String[] arrMemNos = memNo.split(",");
		for (int mCouter = 0; mCouter < arrMemNos.length; mCouter++) {
			int memIndex = Integer.parseInt(arrMemNos[mCouter]) - 1;
			overrideEligibilty.clickOnMemberChkBx(memIndex);
		}
		overrideEligibilty.clickOnEditBtn();
		overrideEligibilty.selectPrimaryPgTypeDD(primaryPg);

		if (!secPg.equalsIgnoreCase("NONE")) {
			overrideEligibilty.selectSecondaryProgTypeDD(secPg);
		}
		overrideEligibilty.selectPlanType(planType);
		
		if (!aidCat.equalsIgnoreCase("NONE")) {
			overrideEligibilty.selectAidCategoryDD2(aidCat);
		}

		if (!stDate.equalsIgnoreCase("NONE")) {
			String startDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern,
					"00:00:" + stDate);
			overrideEligibilty.enterBenefitStartDateTxt2(startDate);
		}
		if (!eDate.equalsIgnoreCase("NONE")) {
			String endDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern,
					"00:00:" + eDate);
			overrideEligibilty.enterProtectionEndDateTxt(endDate);
		}
	}
	
	/**
	 * @author Amrita 
	 * 
	 From Override Eligibility Page,Enter Details on Override Tab For Program Type As Health Connector
	 | MemNo 	|	PrimaryProgram 		                                    |SecondaryProgram | AidCategory 	| StartDate  | EndDate |
	 | 2 		| Health Connector Plans with Advance Premium Tax Credit 	|	 N/A 	      |  None          |   None      |  None   |
	  
	 */

	@Given("^From Override Eligibility Page,Enter Details on Override Tab For Program Type As Health Connector$")
	public void selectOverrideDetailsForUnsubQHP(DataTable table) throws Exception {
		List<List<String>> scenarioData = table.raw();
		String memNo = scenarioData.get(1).get(0);

		String primaryPg = scenarioData.get(1).get(1).trim();
		String secPg = scenarioData.get(1).get(2).trim();
		String aidCat = scenarioData.get(1).get(3).trim();
		String stDate = scenarioData.get(1).get(4).trim();
		String eDate = scenarioData.get(1).get(5).trim();

		String currentDate = new DualTable(conn, "").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);

		OverrideEligibiltyPage overrideEligibilty = new OverrideEligibiltyPage(driver, testCaseId);
		overrideEligibilty.clickOnOverrideTab();
		overrideEligibilty.clickOnOverride();

		String[] arrMemNos = memNo.split(",");
		for (int mCouter = 0; mCouter < arrMemNos.length; mCouter++) {
			int memIndex = Integer.parseInt(arrMemNos[mCouter]) - 1;
			overrideEligibilty.clickOnMemberChkBx(memIndex);
		}
		overrideEligibilty.clickOnEditBtn();
		overrideEligibilty.selectPrimaryPgTypeDD(primaryPg);

		if (!secPg.equalsIgnoreCase("NONE")) {
			overrideEligibilty.selectSecondaryProgTypeDD(secPg);
		}
				
		if (!aidCat.equalsIgnoreCase("NONE")) {
			overrideEligibilty.selectAidCategoryDD2(aidCat);
		}

		if (!stDate.equalsIgnoreCase("NONE")) {
			String startDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern,
					"00:00:" + stDate);
			overrideEligibilty.enterBenefitStartDateTxt2(startDate);
		}
		if (!eDate.equalsIgnoreCase("NONE")) {
			String endDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern,
					"00:00:" + eDate);
			overrideEligibilty.enterProtectionEndDateTxt(endDate);
		}
	}


	/**
	 * Ritika
	 * 
	 From Override Eligibility Page,Enter TMA Date on Override Tab 
	  | StartDate 	| EndDate 		|EffectiveDate | 
	  | -30 		| 10/31/2019 	| 01/01/2019 |
	 * 
	 * @throws Exception
	 */

	@Given("^From Override Eligibility Page,Enter TMA Date on Override Tab$")
	public void selectTMADetails(DataTable table) throws Exception {
		String currentDate = new DualTable(conn, "").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);

		List<List<String>> scenarioData = table.raw();
		String stDate = scenarioData.get(1).get(0);
		String endDate = scenarioData.get(1).get(1);
		String effDate = scenarioData.get(1).get(2);
		String startDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern,
				"00:00:" + stDate);

		OverrideEligibiltyPage overrideEligibilty = new OverrideEligibiltyPage(driver, testCaseId);
		overrideEligibilty.enterTMAStartDateTxt(startDate);
		overrideEligibilty.selectTMAEndDateTxt(endDate);
		overrideEligibilty.enterTMAEffDateTxt(effDate);
	}

	/**
	 * Ritika 
	  From Override Eligibility Page,Enter Notice Details on Override Tab 
	 	| MH Notice | CCA Notice |TMA Notice | | TRUE | TRUE | TRUE |
	 **/

	@Given("^From Override Eligibility Page,Enter Notice Details on Override Tab$")
	public void selectNoticeDetails(DataTable table) throws Exception {
		List<List<String>> scenarioData = table.raw();
		OverrideEligibiltyPage overrideEligibilty = new OverrideEligibiltyPage(driver, testCaseId);

		overrideEligibilty.clickOnSaveBtn();
		overrideEligibilty.handleWarningDialogIfPresent();
		Boolean MHNotice = (scenarioData.get(1).get(0).trim()).equalsIgnoreCase("TRUE") ? true : false;
		Boolean CCANotice = (scenarioData.get(1).get(1).trim()).equalsIgnoreCase("TRUE") ? true : false;
		Boolean TMANotice = (scenarioData.get(1).get(2).trim()).equalsIgnoreCase("TRUE") ? true : false;
		overrideEligibilty.selectSendMHNoticeRdBtn(MHNotice);
		overrideEligibilty.selectSendCCANoticeRdBtn(CCANotice);
		overrideEligibilty.selectSendTMANoticeRdBtn(TMANotice);
		overrideEligibilty.enterComments("Override done");
		overrideEligibilty.clickOnApplyBtn();
		overrideEligibilty.clickOnWarningOkButton();

	}
	
	/**@author ppinho
	 * From Override Eligibility Page, Click On Override Tab
	 */
	@Given("^From Override Eligibility Page, Click On Override Tab$")
	public void goToOverrideEligibilityTab() throws Exception {
		OverrideEligibiltyPage override = new OverrideEligibiltyPage(driver, testCaseId);
		override.overrideEligibilityPageLoadAndClickOnOverrideTab();
	}
	
	/**@author Paul Pinho
	 * Accepted Value :-
	 * 		Submission Date :- F_00:00:00, P_00:00:00, 00:00:00 ( F - Future Date, P - Past Date)
	 *
	 * From Override Eligibility Left Menu, Set Submission Date To "F_00:00:00"
	 *	
	 */
		
	@Given("^From Override Eligibility Left Menu, Set Submission Date To \"(.*?)\"$")
	public void setSubmissionDate(String date) throws Exception {
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
			
		String[] submissionDateActual = date.split("_");
		String submissionDate;
			
		if(submissionDateActual[0].equals("P")){			
	submissionDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, submissionDateActual[1]);
		}else if(submissionDateActual[0].equals("F")){
	submissionDate = DateUtil.getFutureDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, submissionDateActual[1]);
		}else{
			submissionDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern);
		}
			
		OverrideEligibiltyPage override = new OverrideEligibiltyPage(driver, testCaseId);
			
		override.overrideEligibilitySubmissionDate(submissionDate);
	}

	/**@author ppinho
	 *  Accepted Value :- 1. MemNo :- 1
	 *  				  2. OverrideEligibility :- TRUE, FALSE
	 *  				  3. ProgramType - CHIP, HCP, MH, HCP_W_APTC, CCA
	 *  				  4. One - Placeholder for variable to use with respective ProgramType
	 *  				  4. Two - Placeholder for variable to use with respective ProgramType
	 *  				  4. Three - Placeholder for variable to use with respective ProgramType
	 *  				  4. Four - Placeholder for variable to use with respective ProgramType
	 *  				  4. Five - Placeholder for variable to use with respective ProgramType
	 *  
		From Override Eligibility Page, On Override Tab Select Details For Members
	 
	 * @throws Exception
	 */
	@And("^From Override Eligibility Page, On Override Tab Select Details For Members$")
	public void completeOverrideEligibilityDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
			
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
			
		OverrideEligibiltyPage override = new OverrideEligibiltyPage(driver, testCaseId);
			
		override.clickOnMemberDetails();
		override.clickOnOverride();
					
		for(int mCounter = 1; mCounter < rowCount; mCounter++){			
			int memIndex = Integer.parseInt(scenarioData.get(mCounter).get(0))-1;			
			Boolean overrideEligibility = scenarioData.get(mCounter).get(2).equalsIgnoreCase("TRUE")?true:false;
				
			override.overrideEligibilityIfTrue(memIndex, overrideEligibility);
		}
			
		override.clickOnEditBtn();
			
		String PrimaryProgramType = scenarioData.get(1).get(3);
		String variableOne = scenarioData.get(1).get(4);
		String variableTwo = scenarioData.get(1).get(5);
		String variableThree = scenarioData.get(1).get(6);
		String variableFour = scenarioData.get(1).get(7);
		String variableFive = scenarioData.get(1).get(8);
			
		override.selectPrimaryProgramType(appDate, PrimaryProgramType, variableOne, variableTwo, variableThree, variableFour, variableFive);
	}

	/**@author ppinho
	 *  From Override Eligibility Page, Save Override Eligibility Results Details And Handle Warning If Present
	 */
		
	@And("^From Override Eligibility Page, Save Override Eligibility Results Details And Handle Warning If Present$")
	public void saveOverrideEligibilityResultsDetails() throws Exception{		
		OverrideEligibiltyPage override = new OverrideEligibiltyPage(driver, testCaseId);
				
		override.clickOnSaveBtn();
		override.handleWarningDialogIfPresent();
	}

	/**@author ppinho
	 *  Accepted Value :- 1. taxHH :- 1
	 *  				  2. NewAPTCAmount :- 100
	 *  				  3. OverrideProtectionEndDate (future date) :- 00:00:00
	 *  
	 *  From Override Eligibility Page, On Override Tab Override APTC Amount For Members
	 * @throws Exception
	 */
		
	@And("^From Override Eligibility Page, On Override Tab Override APTC Amount For Members$")
	public void completeOverrideAPTCamount(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
			
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
					
		OverrideEligibiltyPage override = new OverrideEligibiltyPage(driver, testCaseId);
		override.clickOnOverrideAPTCamount();
					
		for(int roxCounter = 1; roxCounter < rowCount; roxCounter++){			
			int taxHHindex = Integer.parseInt(scenarioData.get(roxCounter).get(0))-1;			
	Boolean overrideAPTCAmount = scenarioData.get(roxCounter).get(1).equalsIgnoreCase("TRUE")?true:false;
				
				override.overrideAPTCAmountIfTrue(taxHHindex, overrideAPTCAmount);
			}
			
			override.clickOnEditAPTCamount();
			
			String newAPTCAmount = scenarioData.get(1).get(2);
			String overrideProtectionEndDate = scenarioData.get(1).get(3);
			
			override.newAPTCamount(appDate, newAPTCAmount, overrideProtectionEndDate);
			override.clickOnSaveHHbtn();
			override.handleWarningDialogIfPresent();
		}

	/**@author ppinho
	 *  Accepted Value :- 1. MHNotice :- TRUE, FALSE
	 *  				  2. CCANotice :- TRUE, FALSE
	 *  				  3. TMANotice :- TRUE, FALSE
	 *  
	 *  From Override Eligibility Page, Select Notices to Override
	 *	| MHNotice | CCANotice | TMANotice |
	 *	| TRUE     | TRUE      | FALSE     |
	 * @throws Exception
	 */
		
	@And("^From Override Eligibility Page, Select Notices to Override$")
	public void selectNoticesToOverride(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		
		OverrideEligibiltyPage override = new OverrideEligibiltyPage(driver, testCaseId);
			
		Boolean MHNotice = scenarioData.get(1).get(0).equalsIgnoreCase("TRUE")?true:false;
		Boolean CCANotice = scenarioData.get(1).get(1).equalsIgnoreCase("TRUE")?true:false;
		Boolean TMANotice = scenarioData.get(1).get(2).equalsIgnoreCase("TRUE")?true:false;
			
		override.selectNoticeResponse(MHNotice, CCANotice, TMANotice);	
		override.enterComments("update");
	}

	/**@author ppinho
	 *  From Override Eligibility Page, Apply And Confirm Changes Being Made
	 */
		
	@And("^From Override Eligibility Page, Apply And Confirm Changes Being Made$")
	public void applyConfirmChanges() throws Exception{		
		OverrideEligibiltyPage override = new OverrideEligibiltyPage(driver, testCaseId);
				
		override.clickOnApplyBtn();
		override.handleWarningDialogIfPresent();
	}
		
	/**@author ppinho
	 *  From Override Eligibility Left Menu, Go to Account Dashboard
	 */
	@Given("^From Override Eligibility Left Menu, Go to Account Dashboard$")
	public void goToAccountDashboard() throws Exception {
	OverrideEligibiltyPage accountDashboardLandingPage = new OverrideEligibiltyPage(driver, testCaseId);
		accountDashboardLandingPage.clickOnAccountDashboard();
	}

}
