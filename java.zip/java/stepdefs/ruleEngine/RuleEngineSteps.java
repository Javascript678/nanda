package stepdefs.ruleEngine;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.Days;
import org.joda.time.LocalDate;

import appdata.evpd.EVPD_MemData;
import appdata.pa.PA_MemData;
import appdata.ruleEngine.RuleEngine_Data;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import drools.pdrules.DecisionTable;
import drools.pdrules.model.AidCat;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.EligibilityRuleEngine;
import utils.FPLCalculator;

/** @author Paul Pinho */

public class RuleEngineSteps extends SuperStepDef {
	
	public List<RuleEngine_Data> ruleEngineData = new ArrayList<RuleEngine_Data>();
	
	public RuleEngineSteps(Hook hook){
		super(hook);
	}
	
	@Then("^Run PD Rule Engine And Validate Respective PD$")
	public void runPDRuleEngineValidateRespectivePD() throws Exception {
		String appDate = DateUtil.getDateInDBFormatUsingPattern("11/14/2019", DateUtil.UIDatePattern);
		String currentDate = DateUtil.getDateInDBFormatUsingPattern("11/14/2019", DateUtil.UIDatePattern);
		
		for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){		
			if(evpdData.memsData.get(memIndex).isTaxHHMember){
				try{
					EligibilityRuleEngine.runEligibilityRuleEngine(2019, evpdData, paData.memsData, memIndex, appDate, currentDate);
				}catch(NullPointerException npe){
					EligibilityRuleEngine.runEligibilityRuleEngine(2019, evpdData, emptyPaData(evpdData.memCount), memIndex, appDate, currentDate);
				}
				
				// Validate PD for each member
				if(!evpdData.memsData.get(memIndex).mhProgramDetermination.isEmpty() && !evpdData.memsData.get(memIndex).ccaProgramDetermination.isEmpty() && Integer.valueOf(evpdData.memsData.get(memIndex).age) < 65){
					System.out.println(evpdData.memsData.get(memIndex).mhProgramDetermination);
					System.out.println(evpdData.memsData.get(memIndex).ccaProgramDetermination);
				}else if(!evpdData.memsData.get(memIndex).ccaProgramDetermination.isEmpty()){
					System.out.println(evpdData.memsData.get(memIndex).mhProgramDetermination);
					System.out.println(evpdData.memsData.get(memIndex).ccaProgramDetermination);
				}else{
					
				}
			}
		}
	}
	
	public List<PA_MemData> emptyPaData(int memCount) throws Exception {
		List<PA_MemData> memsData = new ArrayList<PA_MemData>();
		
		for(int i = 0; i < memCount; i++){
			memsData.add(new PA_MemData());
		}
		
		for(int i = 0; i < memCount; i++){
			memsData.get(i).tplStatus = null;
			memsData.get(i).basicBenefitLevel = false;
			memsData.get(i).enrolledInMH = false;
			memsData.get(i).coverageType = null;
		}
		
		return memsData;
	}
	
}
