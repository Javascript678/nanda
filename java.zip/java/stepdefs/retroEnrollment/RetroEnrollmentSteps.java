package stepdefs.retroEnrollment;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import pages.retroEnrollment.*;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

//Amrita
public class RetroEnrollmentSteps extends SuperStepDef{
	
	public RetroEnrollmentSteps(Hook hook){
		super(hook);
	}
	
	@Given("^From Retro Enrollment Page, Take Screenshot$")
	public void takseScreenShot() throws Exception {
		RetroEnrollmentPage retroenroll = new RetroEnrollmentPage(driver, testCaseId);
		retroenroll.takseScreenShot();
	}
	
	@Given("^From Retro Enrollment Page, Handle Warning Dialog If Present$")
	public void handleWarningDialogIfPresent() throws Exception {
		RetroEnrollmentPage retroenroll = new RetroEnrollmentPage(driver, testCaseId);
		retroenroll.handleWarningDialogIfPresent();
	}
	
	@Given("^From Retro Enrollment Page, With Plan Year As \"(.*?)\",Plan Type As \"(.*?)\" and Member Number \"(.*?)\" Search For Details$")
	public void searchMember(String planYr,String planType,String memNum) throws Exception {
		RetroEnrollmentPage retroenroll = new RetroEnrollmentPage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNum)-1;
		String currentEligibilityId = TestData.getTempTestData("CurrentEligibilityId",featureFileName);
		ElgMemberTable elgMem = new ElgMemberTable(conn, currentEligibilityId);
		String subscriberName=elgMem.getFullName(currentEligibilityId, memIndex);
		retroenroll.selectPlanYear(planYr);
		retroenroll.selectPlanType(planType);
		retroenroll.selectSubscriber(subscriberName);
		retroenroll.clickOnSearch();
	}
	
	@Given("^From Retro Enrollment Page, Perform Retro Void For Member \"(.*?)\" With Comments As \"(.*?)\"$")
	public void performRetroVoid(String memNum,String comments) throws Exception {
		RetroEnrollmentPage retroenroll = new RetroEnrollmentPage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNum)-1;
		retroenroll.performRetroVoid(memIndex,comments);
		}
	
	
	/**@author ppinho
	 *  Store Member "1" Name In TempData With Same Name
	 */
		
	@And("^Store Member \"(.*?)\" Name In TempData With Same Name$")
	public void storeElgIdRefIdAndAppDate(String memNo) throws Exception {
		RetroEnrollmentPage retroEnrollment = new RetroEnrollmentPage(driver, testCaseId);		
		String subscriber = retroEnrollment.getSubscriber(memNo);
		storeTempTestData("Member" + memNo, subscriber);		
		displayDataInReport("Subscriber" + memNo, subscriber);	
	}
		
	 /**@author ppinho
	 *  Accepted Value :- 1. Subscriber :- 1
	 *  				  2. PlanYear :- Default Current Year
	 *  				  3. PlanType :- Health, Dental
	 *  
	 *  From Override Eligibility Page, On Override Tab Select Details For Members
	 *	| MemNo | PlanYear | PlanType |
	 *	| 1 	| 2018     | HEALTH   |
	 * @throws Exception
	 */
	@When("^From Retro Enrollment Page, Search Active Plans For SUBSCRIBER$")
	public void searchForActivePlans(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();

		RetroEnrollmentPage retroEnrollment = new RetroEnrollmentPage(driver, testCaseId);
		
		int rowCount = scenarioData.size();
					
		for(int mCounter = 1; mCounter < rowCount; mCounter++){
			String memNo = scenarioData.get(mCounter).get(0);
			String subscriber = TestData.getTempTestData("Member" + memNo, featureFileName);
				
			String planYear = scenarioData.get(mCounter).get(1);
			String planType = scenarioData.get(mCounter).get(2);

			retroEnrollment.searchForActivePlans(subscriber, planYear, planType);
		}
	}
		
	 /**@author ppinho
	 *  Accepted Value :- 1. Subscriber :- 1, 2
	 *  				  2. PlanYear :- TRUE, FALSE
	 *  				  3. PlanType :- MM/DD/YYYY
	 *  
	 *  From Retro Enrollment Page, Open Active Plans And Change Effective Date
	 *	 |MemNo|ChangeDate|StartDate |EndDate   |
	 *	 |1	   |TRUE      |MM/DD/YYYY|MM/DD/YYYY|
	 *	 |2	   |TRUE      |			 |			|
	 * @throws Exception
	 */
		
	@When("^From Retro Enrollment Page, Open Active Plans And Change Effective Date$")
	public void openActivePlansChangeEndDate(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		
		int rowCount = scenarioData.size();
		String startDate = null;
		String endDate = null;
		
		RetroEnrollmentPage retroEnrollment = new RetroEnrollmentPage(driver, testCaseId);
		
		for(int mCounter = 1; mCounter < rowCount; mCounter++){			
			int memIndex = Integer.parseInt(scenarioData.get(mCounter).get(0)) - 1;			
	Boolean changeEndDate = scenarioData.get(mCounter).get(1).equalsIgnoreCase("TRUE")?true:false;			
			retroEnrollment.selectActiveMemberIfTrue(memIndex, changeEndDate);
		}
			
		startDate = scenarioData.get(1).get(2);		
			
		if(startDate.equals(null) || startDate.trim().equals("")){
			System.out.print("Start Date Not Provided");
		}else{
			retroEnrollment.changeActivePlanStartDateForSelectedMember(startDate);
		}
			
		endDate = scenarioData.get(1).get(3);
			
		if(endDate.equals(null) || endDate.trim().equals("")){
			System.out.print("End Date Not Provided");
		}else{
			retroEnrollment.changeActivePlanEndDateForSelectedMember(endDate);
		}
			
	}
		





















	 /**@author ppinho
	 *  Accepted Value :- 1. Subscriber :- 1, 2
	 *  				  2. PlanYear :- TRUE, FALSE
	 *  				  3. PlanType :- MM/DD/YYYY
	 *  
	 *  From Retro Enrollment Page, Open Terminated Plans And Change Effective Date
	 *	 |MemNo|ChangeDate|StartDate |EndDate   |
	 *	 |1	   |TRUE      |MM/DD/YYYY|MM/DD/YYYY|
	 *	 |2	   |TRUE      |			 |			|
	 * @throws Exception
	 */

	@When("^From Retro Enrollment Page, Open Terminated Plans And Change Effective Date$")
	public void openTerminatedPlansChangeEndDate(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		
		int rowCount = scenarioData.size();
		String startDate = null;
		String endDate = null;
		
		RetroEnrollmentPage retroEnrollment = new RetroEnrollmentPage(driver, testCaseId);
		
		retroEnrollment.openTerminatedPlans();
			
		for(int mCounter = 1; mCounter < rowCount; mCounter++){			
			int memIndex = Integer.parseInt(scenarioData.get(mCounter).get(0)) - 1;			
	Boolean changeEndDate = scenarioData.get(mCounter).get(1).equalsIgnoreCase("TRUE")?true:false;			
			retroEnrollment.selectTerminatedMemberIfTrue(memIndex, changeEndDate);
		}
			
		startDate = scenarioData.get(1).get(2);		
		
		if(startDate.equals(null) || startDate.trim().equals("")){
			System.out.print("Start Date Not Provided");
		}else{
			retroEnrollment.changeTerminatedPlanStartDateForSelectedMember(startDate);
		}
			
		endDate = scenarioData.get(1).get(3);
		
		if(endDate.equals(null) || endDate.trim().equals("")){
			System.out.print("End Date Not Provided");
		}else{
			retroEnrollment.changeTerminatedPlanEndDateForSelectedMember(endDate);
		}
		
	}
		
	/**@author ppinho
	 * Accepted Value :- Date   :- MM/DD/YYYY
	 
	 From Retro Enrollment Page, Validate Terminated End Date As "MM/DD/YYYY"
	 
	 */
	@When("^From Retro Enrollment Page, Validate Active Start Date As \"(.*?)\"$")
	public void validateActiveStartDate(String startDate) throws Exception{		
		RetroEnrollmentPage retroEnrollment = new RetroEnrollmentPage(driver, testCaseId);
		
		String actualActivePlanStartDate = startDate + " -";
		
		retroEnrollment.validateActivePlanStartDate(actualActivePlanStartDate);
	}

	/**@author ppinho
	 * Accepted Value :- Date   :- MM/DD/YYYY
	 
	 From Retro Enrollment Page, Validate Terminated End Date As "MM/DD/YYYY"
	 
	 */
	@When("^From Retro Enrollment Page, Validate Terminated End Date As \"(.*?)\"$")
	public void validateTerminatedEndDate(String endDate) throws Exception{		
		RetroEnrollmentPage retroEnrollment = new RetroEnrollmentPage(driver, testCaseId);		
		String actualTerminatedPlanEndDate = "- " + endDate;
		retroEnrollment.validateTerminatedPlanEndDate(actualTerminatedPlanEndDate);
	}
}	