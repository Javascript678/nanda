package stepdefs.pa;

import java.util.List;

import appdata.common.TempData;
import appdata.evpd.EVPD_MemData;
import appdata.pa.PA_MemData;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.DualTable;
import db.ElgMemberTable;
import pages.login.Portal;
import pages.manageCustomer.FindACustomerPage;
import pages.pa.AddNewPolicyInfoPage;
import pages.pa.LandingPage;
import stepdefs.ruleEngine.RuleEngineSteps;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.EligibilityRuleEngine;
import utils.HttpsClient;
import utils.TestData;

public class paSteps extends SuperStepDef {
	
	public paSteps(Hook hook) {
		super(hook);
	}
	
	@Given("^PA, Login To MAHIX Portal$")
	public void loginToAgentPortalTplUser() throws Exception {
		Portal portal = new Portal(hook);
		portal.goToPortal(browserToUse, paData.url, paData.portal, paData.optumIdData);
	}
	
	@Given("^PA, Find A Customer With UserProfileRefId And Go To Premium Assistance Dashboard$")
	public void findCustomerWithUserProfileRefId() throws Exception {
		String userProfileRefId = evpdData.memsData.get(0).userRefId;
		
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToPremiumAssistanceDashBoard(userProfileRefId);
		
		LandingPage pa_LandingPage = new LandingPage(driver, testCaseId);
		pa_LandingPage.waitForPageLoaded();
	}
	
	@Given("^PA, Complete Add New Policy Module$")
	public void completeAddPolicyModule() throws Exception {
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		paLandingPage.goToAddNewPolicyScreen();
		
		AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
		
		for(int memInd = 0; memInd < paData.memCount; memInd++){
			if(paData.memsData.get(memInd).policySource.isEmpty() || paData.memsData.get(memInd).policySource == null){
				continue;
			}
			
			for(int i = 0; i < evpdData.memCount; i++){
				if(evpdData.memsData.get(i).memId.equalsIgnoreCase(paData.memsData.get(memInd).memId)){					
					paData.memsData.get(memInd).policyHolderName = evpdData.memsData.get(i).fullName;
					break;
				}
			}			
			
			addNewPolicyPage.paEnterEmployeeSponsoredPolicyDetails(paData, memInd);
			
			if(memInd < paData.memCount){
				paLandingPage.goToAddNewPolicyScreen();
			}
		}
		
		addNewPolicyPage.clickOnPremiumAssistanceHomePage();
	}
	
	@Given("^PA, Edit Policy And Perform Overide$")
	public void editPolicyToPerformOverideBySuperUser() throws Exception {
		AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
				
		for(int memInd = 0; memInd < paData.memCount; memInd++){
			int memNo = Integer.parseInt(paData.memsData.get(memInd).memId.substring(paData.memsData.get(memInd).memId.indexOf("M") + 1)) - 1;
			
			paLandingPage.goToEditToOverridePAOnHealthInsurancePolicyScreen(evpdData.memsData.get(memNo).fullName);
			addNewPolicyPage.paEnterPolicyOverrideDetailsAndCalculatePA(paData, memInd);
		}
	}
	
	@Given("^PA, Validate Premium Assistance Summary$")
	public void validatePASummaryCriteria() throws Exception {
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		
		for(int memInd = 0; memInd < paData.memCount; memInd++){
			if(paData.memsData.get(memInd).policySource.isEmpty() || paData.memsData.get(memInd).policySource == null){
				continue;
			}
			
			paLandingPage.paValidatePaSummary(evpdData, paData, memInd);
		}
	}
	
	@Given("PA, Validate Premium Assistance Investigation Referal Criteria$")
	public void validatePAInvestigationReferalCriteria() throws Exception {
		for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
			int year = Integer.parseInt(globalData.get("TaxFPLCalculatorForYear").trim());
			
			String appDate = DateUtil.getDateInDBFormatUsingPattern(evpdData.memsData.get(0).appCreateDate, DateUtil.UIDatePattern);
			String currentDate = DateUtil.getDateInDBFormatUsingPattern(hook.runDate, DateUtil.UIDatePattern);
			
			EligibilityRuleEngine.runEligibilityRuleEngine(year, evpdData, paData.memsData, memIndex, appDate, currentDate);
			sendPdDataToDb(memIndex);

			LandingPage paLandingPage = new LandingPage(driver, testCaseId);
			paLandingPage.paValidatePremiumAssistanceInvestigationReferalCriteria(evpdData, paData, memIndex);
		}
	}
	
	public void sendPdDataToDb(int memInd) throws Exception {
		String ipAddress = globalData.get("Local_IP_Address").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		String schema = globalData.get("mysql_schema").trim();
		
		HttpsClient httpClient = new HttpsClient();
		TempData tempData = new TempData();
		
		String table = getTempTestData("DataSet") + "_evpd";
		String programDetermination = null;
		String aidCat = null;
		
		if(!evpdData.memsData.get(memInd).mhAidCat.isEmpty()){
			aidCat = evpdData.memsData.get(memInd).mhAidCat;				
		}else{
			aidCat = evpdData.memsData.get(memInd).ccaAidCat;
		}
		
		if(!evpdData.memsData.get(memInd).mhAidCat.isEmpty()){
			programDetermination = evpdData.memsData.get(memInd).mhProgramDetermination;		
		}else{
			programDetermination = evpdData.memsData.get(memInd).ccaProgramDetermination + " " + 
								   evpdData.memsData.get(memInd).mhProgramDetermination;
		}
		
		tempData.sqlScript = "update " + schema + "." + table + 
	 			 " set " + table + ".ms_aid_cat = '" + aidCat + "', " +
	 			 		   table + ".ms_program_determination = '" + programDetermination + "' " +
	 			 " where " + table + ".scenario = '" + featureFileName + "'" +
	 			 " and " + table + ".mem_id = '" + evpdData.memsData.get(memInd).memId + "'";	
				
		httpClient.updateTempDataMS(ipAddress, username, password, getTempTestData("DataSet"), TempData.updateTempDataRequest(tempData));
	}
}
