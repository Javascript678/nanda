package stepdefs.enrollment;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;

import appdata.common.TempData;
import appdata.enrollment.Enrollment_Data;
import appdata.evpd.EVPD_Data;
import appdata.pa.PA_MemData;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import enums.PortalName;
import modules.enrollment.EnrollmentsModule;
import modules.evpd.AdditionalQuestionsModule;
import modules.evpd.FamilyAndHouseholdModule;
import modules.evpd.IncomeModule;
import modules.evpd.ReviewAndSignModule;
import modules.evpd.StartYourApplicationModule;
import mysql.MySQL;
import mysql.MySQL_Conn_Data;
import pages.accountDashboard.AccountDashboardLandingPage;
import pages.eligibilityResult.CurrentYearEligibilityResultPage;
import pages.eligibilityResult.MedicaidHHDeterminationPage;
import pages.login.HomePage;
import pages.login.Portal;
import pages.manageCustomer.FindACustomerPage;
import pages.myEligibility.EligibilityApplicationPage;
import pages.profile.CreateProfilePage;
import pages.shopping.DentalPlanShopingPage;
import pages.shopping.EnrollPage;
import pages.shopping.FindAHealthOrDentalPlanPage;
import pages.shopping.HealthPlanShopingPage;
import pages.shopping.MyEnrollmentPage;
import pages.shopping.PlanFinderToolPage;
import pages.shopping.QualifyingLifeEventPage;
import pages.shopping.ReviewApplicationPage;
import pages.shopping.ReviewShoppingCartPage;
import pages.shopping.ShopAndEnrollPage;
import stepdefs.assister.DesignationFormSteps;
import stepdefs.eligibilityResult.CurrentYearEligibilityResultSteps;
import stepdefs.microservice.MicroserviceSteps;
import stepdefs.profile.USPSPageSteps;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.HttpsClient;
import utils.PageHeader;
import utils.TestData;

public class enrollmentSteps extends SuperStepDef {
	
	public enrollmentSteps(Hook hook) {
		super(hook);
	}
		
	@Given("^Enrollment, Login To MAHIX Portal$")
	public void enrollmentLoginToPortal() throws Exception {
		Portal portal = new Portal(hook);
		portal.goToPortal(browserToUse, enrollmentData.url, enrollmentData.portal, enrollmentData.optumIdData);
	}
	
	@Given("^Enrollment, Find A Customer With UserProfileRefId From DashBoard")
	public void enrollmentSearchRefID() throws Exception {		
		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.agentPageLoadAndClickOnManageCustomerLink();
		
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(evpdData.memsData.get(0).userRefId);
		
		String year = globalData.get("ApplicationCreationYear");
		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
		
		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		eligibilityApplicationPage.pageLoadAndClickOnEligibilityDetailsLink(year);
	}
	
	@Given("^Enrollment, Find A Customer and Go to Eligibility Page")
	public void SearchRefID() throws Exception {		
		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.agentPageLoadAndClickOnManageCustomerLink();
		
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(evpdData.memsData.get(0).userRefId);
		
		String year = globalData.get("ApplicationCreationYear");
		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
		
		//EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		//eligibilityApplicationPage.pageLoadAndClickOnEligibilityDetailsLink(year);
	}
	
	/*@Given("^Enrollment, Complete Health And Dental Shopping Module$")
	public void enrollmentsCompleteShoppingDetailsForAllGroup() throws Exception {
		EnrollmentsModule enrollments = new EnrollmentsModule(driver, testCaseId);
		
		if(enrollments.isQLEPresent()){
			enrollments.completeQLEDetails(evpdData, enrollmentData);
		}
		
		enrollments.completeHealthAndDentalPlanShopping(evpdData, enrollmentData);
	}*/
	
}
