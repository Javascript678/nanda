package stepdefs.disability;

import pages.disability.DisabilityInfoPage;
import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;



public class DisabilityInfoPageSteps extends SuperStepDef {

	public DisabilityInfoPageSteps(Hook hook){
		super(hook);
	}

	/*
	 * Disability Code: DA, MA, BL
	 * From Disability Info Page,Select Disability for member "1" As "TRUE" and BackOffice Disability Code As "BO"
	 * */
	@Given("^From Disability Info Page, Select Disability for member \"(.*?)\" As \"(.*?)\" and BackOffice Disability Code As \"(.*?)\"$")
	public void selectDisabilityAndRerun(String memno,String isDisabled, String boDisabilityCode) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		DisabilityInfoPage disabilityInfoPage = new DisabilityInfoPage(driver, testCaseId);
		int memIndex = Integer.parseInt(memno) - 1;
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		
		boolean isDisable = isDisabled.equalsIgnoreCase("TRUE")?true:false;
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
		
		disabilityInfoPage.selectDisabilityAndRerun(name, isDisable, boDisabilityCode);
	}

}
