package stepdefs.printVendor;

import cucumber.api.java.en.Given;
import db.ElgMedicaidNoticeXmlTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.EmailUtil;

public class PrintVendorSteps extends SuperStepDef{
	
	public PrintVendorSteps(Hook hook){
		super(hook);
	}
	
	@Given("^Validate Print Vendor$")
	public void printVendorTesting() throws Exception {
		//TODO:
		System.out.println("ABC");
		
		/**1. Get Distinct Notice Type 
		 * SELECT DISTINCT(NOTICE_TYPE) FROM MAHX_OWN.ELG_MEDICAID_NOTICE_XML WHERE FINAL_NOTICE_PROCESS_ID IS NULL AND
MERGED_PDF_FILE_NAME IS NULL
		

		 *2. Get List of Notice Type From Master List from excel file in TestData ( PrintVendor.xls )
		 * 
		 * 3. From 1. Querry , validate that all notice type are covered.
		 * 4. Create a querry to get all recent elg id for application picked up for merged pdf - one for each notices
		 * 	 Srikant
		 * 5. Consider that dummy list of elg id is already available.
		 *  Validate in ELG_MEDICAID_NOTICE_XML tab;e that notice is processed with not null process id
		 */
		
		ElgMedicaidNoticeXmlTable elgMedicaidNoticeXmlTable = new ElgMedicaidNoticeXmlTable(conn, testCaseId);
		//This is a working copy , tried and Tested
		
		EmailUtil.sendMail("vinay_kumar2@optum.com", "vinay_kumar2@optum.com", "vinay_kumar2@optum.com", "Print Vendor Testing", "Hi,\n\n Please run batch Job 19,17,18.\n\n\n Thanks and Regards,\n Automation Team", "");
		
	}
	

}
