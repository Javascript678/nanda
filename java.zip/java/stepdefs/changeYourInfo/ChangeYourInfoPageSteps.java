package stepdefs.changeYourInfo;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import pages.rac.ChangeYourInfoPage;
import pages.startApplication.HOHContactInformationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class ChangeYourInfoPageSteps extends SuperStepDef{
	
	public ChangeYourInfoPageSteps(Hook hook){
		super(hook);
	}
	
	@Given("^From Change Your Info Page, Take Screenshot$")
	public void takseScreenShot() throws Exception {
		ChangeYourInfoPage changeYourInfo = new ChangeYourInfoPage(driver, testCaseId);
		changeYourInfo.takseScreenShot();
	}
	
	@Given("^From Change Your Info Page, Handle Warning Dialog If Present$")
	public void handleWarningDialogIfPresent() throws Exception {
		ChangeYourInfoPage changeYourInfo = new ChangeYourInfoPage(driver, testCaseId);
		changeYourInfo.handleWarningDialogIfPresent();
	}
	
	
	
	/**
	 * Accepted Value Separated By Comma :-
	 * 		1. ADD_FAMILY
	 * 	    2. REMOVE_FAMILY
	 * 	    3. UPDATE_INCOME
	 * 		4. CHANGE_STATUS
	 * 		5. CHANGE_ADDR
	 * 		6. CHANGE_APP_TYPE
	 * 		7. CHANGE_FTR
	 
	 From Change Your Info Page, Select Required Radio Btn and Click On Report a Change
		| RAC_Types 					|
		| ADD_FAMILY, UPDATE_INCOME		|
		
	 */
	@Given("^From Change Your Info Page, Select Required Radio Btn and Click On Report a Change$")
	public void clickOnReportAChangeForIncome(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String changeInfos = scenarioData.get(1).get(0);
		
		String[] arrChangeInfo = changeInfos.split(",");
		
		ChangeYourInfoPage changeYourInfoPage = new ChangeYourInfoPage(driver, testCaseId);
		
		for(int counter=0; counter < arrChangeInfo.length;counter++){
			String changeStatusVal =arrChangeInfo[counter].trim();
			
			if(changeStatusVal.equalsIgnoreCase("ADD_FAMILY")){
				changeYourInfoPage.selectAddFamilyMemRdBtn(true);
			}
			
			if(changeStatusVal.equalsIgnoreCase("REMOVE_FAMILY")){
				changeYourInfoPage.selectRemoveFamilyMemRdBtn(true);
			}
			
			if(changeStatusVal.equalsIgnoreCase("UPDATE_INCOME")){
				changeYourInfoPage.selectUpdateIncomeRdBtn(true);
			}
			
			if(changeStatusVal.equalsIgnoreCase("CHANGE_STATUS")){
				changeYourInfoPage.selectChangeStatusRdBtn(true);
			}
			
			if(changeStatusVal.equalsIgnoreCase("CHANGE_ADDR")){
				changeYourInfoPage.selectChangeHomeAddrRdBtn(true);
			}
			
			if(changeStatusVal.equalsIgnoreCase("CHANGE_APP_TYPE")){
				changeYourInfoPage.selectChangeAppTypeRdBtn(true);
			}
			
			if(changeStatusVal.equalsIgnoreCase("CHANGE_FTR")){
				changeYourInfoPage.selectChangePastTaxCreditRdBtn(true);
			}
		}
		
		changeYourInfoPage.clickOnReportChangeBtn();
		
	}
	
	@Given("^From Change Your Info Page Pop Up, Select All Members For Update$")
	public void selectAllMembersForUpdate() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		ChangeYourInfoPage changeYourInfo = new ChangeYourInfoPage(driver, testCaseId);
		changeYourInfo.selectAllMembersForUpdate(memCount);
	}
	
	@Given("^From Change Your Info Page Pop Up, Select All Members For Update As \"(.*?)\"$")
	public void selectAllMembersForUpdate(String memCou) throws Exception {
		/*String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		*/
		int memCount = Integer.parseInt(memCou);
		
		ChangeYourInfoPage changeYourInfo = new ChangeYourInfoPage(driver, testCaseId);
		changeYourInfo.selectAllMembersForUpdate(memCount);
	}
	
	
	//Shailza
	
	/**
	 * From Change Your Info Page Pop Up, Select For Update As "1"
	 */
	
	@Given("^From Change Your Info Page Pop Up, Select For Update As \"(.*?)\"$")
	public void selectMemberForUpdate(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		ChangeYourInfoPage changeYourInfo = new ChangeYourInfoPage(driver, testCaseId);
		changeYourInfo.selectMemberForUpdate(memIndex);
	}
	
	@Given("^From Change Your Info Page, Click On Ok$")
	public void clickOnOkBtn() throws Exception {
		ChangeYourInfoPage changeYourInfo = new ChangeYourInfoPage(driver, testCaseId);
		changeYourInfo.clickOnOkBtn();
	}
	
	@Given("^From Change Your Info Page, Click On Change contact information and change address$")
	public void clickOnContactInfo() throws Exception {
		ChangeYourInfoPage changeYourInfo = new ChangeYourInfoPage(driver, testCaseId);
		changeYourInfo.contactInfoPreferences();
		String email="aa@a.com";
		String zip = "02056";
		String county = "NORFOLK";
		HOHContactInformationPage hOHContactInformationPage= new HOHContactInformationPage(driver, testCaseId);
		hOHContactInformationPage.enterMailingAddressNew(false, email, zip, county);
	}

}
