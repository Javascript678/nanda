package stepdefs.startApplication;

import cucumber.api.java.en.And;
import pages.startApplication.DoYouWantHelpPayingPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class DoYouWantHelpPayingPageSteps extends SuperStepDef {

	public DoYouWantHelpPayingPageSteps(Hook hook) {
		super(hook);
	}
	
	/**
	 * Accepted Value 
	 * 		1.	Who Is Applying :- SELF,	FAMILY_ONLY,	SELF_FAMILY
	 * 		2. faRedq :- TRUE,	FALSE

	 From Do You Want Help In Paying Page, Complete Details With WhoIsApplying As "SELF_FAMILY" And FA_Reqd As "TRUE"
	 
	 */
	@And("^From Do You Want Help In Paying Page, Complete Details With WhoIsApplying As \"(.*?)\" And FA_Reqd As \"(.*?)\"$")
	public void completeDetails(String whoIsApplying, String strFAReqd) throws Exception{
		Boolean faReqd = strFAReqd.equalsIgnoreCase("TRUE")?true:false;
		
		DoYouWantHelpPayingPage doYouNeedHelpPayingPage = new DoYouWantHelpPayingPage(driver, testCaseId);
		
		doYouNeedHelpPayingPage.selectWhoNeedHealthInsuranceRdBtn(whoIsApplying);
		doYouNeedHelpPayingPage.selectWhoisApplyingAndIfHelpNeede(faReqd);
	}

	/**
	 * Accepted Value 
	 * 		
	 * 		 faRedq :- TRUE,	FALSE

	From Do You Want Help In Paying Page, Select FA_Reqd As "TRUE"
	 
	 */
	@And("^From Do You Want Help In Paying Page, Select FA_Reqd As \"(.*?)\"$")
	public void completeDetails( String strFAReqd) throws Exception{
		Boolean faReqd = strFAReqd.equalsIgnoreCase("TRUE")?true:false;
		
		DoYouWantHelpPayingPage doYouNeedHelpPayingPage = new DoYouWantHelpPayingPage(driver, testCaseId);
		doYouNeedHelpPayingPage.selectWhoisApplyingAndIfHelpNeede( faReqd);
	}
	
	@And("^From Do You Want Help In Paying Page, Handle Warning Dialog If Present$")
	public void handleWarningDialogIfPresent() throws Exception {
		DoYouWantHelpPayingPage doYouNeedHelpPayingPage = new DoYouWantHelpPayingPage(driver, testCaseId);
		doYouNeedHelpPayingPage.handleWarningDialogIfPresent();
	}
	
	@And("^From Do You Want Help In Paying Page, Click On Save And Continue$")
	public void pageLoadAndClickOnSaveAndContinue() throws Exception{
		
		DoYouWantHelpPayingPage doYouNeedHelpPayingPage = new DoYouWantHelpPayingPage(driver, testCaseId);
		doYouNeedHelpPayingPage.pageLoadAndClickOnSaveAndContinue();
	}

}
