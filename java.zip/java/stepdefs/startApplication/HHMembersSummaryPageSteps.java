package stepdefs.startApplication;

import cucumber.api.java.en.And;
import db.ElgMemberTable;
import pages.startApplication.HHMemberSummaryPage;
import pages.startApplication.WhoIsApplyingForHISummaryPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class HHMembersSummaryPageSteps extends SuperStepDef {

	public HHMembersSummaryPageSteps(Hook hook) {
		super(hook);
	}


	@And("^From HouseHold Member Summary Page, Validate Name and DOB for All From DB$")
	public void validateNameAndDOBForMembers() throws Exception {

		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		HHMemberSummaryPage hhMemberSummaryPage = new HHMemberSummaryPage(driver,testCaseId);
		for(int memCounter=0;memCounter<memCount; memCounter++){
			String expName = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memCounter);
			String expDOB = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memCounter);
			hhMemberSummaryPage.validateNameForMember(memCounter, expName);
			hhMemberSummaryPage.validateDOBForMember(memCounter, expDOB);
		}
	}
	
	@And("^From HouseHold Member Summary Page, Page Load And Click on Continue$")
	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception {

		HHMemberSummaryPage hhMemberSummaryPage = new HHMemberSummaryPage(driver,testCaseId);
		hhMemberSummaryPage.pageLoadAndClickOnSaveAndContinueBtn();

	}
	
	@And("^From HouseHold Member Summary, Store Total Member For This Application Is \"(.*?)\"$")
	public void storeMemCount(String totalMem) throws Exception{
		storeTempTestData("MemCount", totalMem);
		displayDataInReport("MemCount", totalMem);
	}
	
	@And("^From HouseHold Member Summary Page, Click on Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception {

		HHMemberSummaryPage hhMemberSummaryPage= new HHMemberSummaryPage(driver,testCaseId);
		hhMemberSummaryPage.clickOnSaveAndContinueBtn();

	}

}
