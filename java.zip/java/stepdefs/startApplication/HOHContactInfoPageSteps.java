package stepdefs.startApplication;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import db.DualTable;
import enums.Language;
import pages.rac.ChangeYourInfoPage;
import pages.startApplication.HOHContactInformationPage;
import pages.startApplication.WhoAreYourHHMemberPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.RandomGenerator;

public class HOHContactInfoPageSteps extends SuperStepDef {

	public HOHContactInfoPageSteps(Hook hook) {
		super(hook);
	}

	/**
	 * Accept DataTable with following value
	 * 1. FirstNameFormat -- STR_YC, END_KED, "","ABCD"
	 * 2. MiddleNameFormat -- STR_YC, END_KED, "","ABCD"
	 * 3. LastNameFormat -- STR_YC, END_KED, "","ABCD"
	 * 4. Age -- 
	 				21 - for 21 Years
	 				00:06:00 -- 06 months
	 				00:06:30 - 30 days
	 				21:06 - 21 years and 6 months
	 * 5. SpokenLang -- English, Spanish
	 * 6. WrittenLanguage -- English, Spanish

	From HOH Contact Info Page, Enter HOH Details
		|FirstNameFormat |MiddleNameFormat|LastNameFormat|Age|SpokenLang|WrittenLanguage	|
		|				 |				  |		     	 |35 |English	|English			|
	
	 */
	@And("^From HOH Contact Info Page, Enter HOH Details$")
	public void fill_Member_Account_Holder_Details(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String fNameFormat = scenarioData.get(1).get(0);
		String mNameFormat = scenarioData.get(1).get(1);
		String lNameFormat = scenarioData.get(1).get(2);
		String age = scenarioData.get(1).get(3);
		String spokenLang = scenarioData.get(1).get(4);
		String writtenLang = scenarioData.get(1).get(5);
		
		String firstName = RandomGenerator.getRunTimeName("MEM", fNameFormat);
		String middleName = RandomGenerator.getRunTimeName("", mNameFormat);
		String lastName = RandomGenerator.getRunTimeName("ONE", lNameFormat);
		
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		
		String dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, age);
		
		String emailId = globalData.get("Member1_EmailAddress");
		String homeStreetAddress = null;
		String homeAptUnit= null;
		String homeCity= null;
		String homeZipCode= null;
		String homeCounty= null;
		String mailStreetAddress= null;
		String mailAptUnit= null;
		String mailCity= null;
		String mailZipCode= null;
		String mailCounty= null; 
		
		Boolean profileAccHolder = globalData.get("IsProfileAccHolder").equalsIgnoreCase("Y")?true:false;
		Boolean noHomeAddressReqd = globalData.get("AccountHolder_NoHomeAddressReqd").equalsIgnoreCase("Y")?true:false;
		if(noHomeAddressReqd == false){
			homeStreetAddress = globalData.get("Member1_H_StreetAddress");
			homeAptUnit = globalData.get("Member1_H_Apt_Unit");
			homeCity = globalData.get("Member1_H_City");
			homeZipCode = globalData.get("Member1_H_ZIP_Code");
			homeCounty = globalData.get("Member1_H_County");
		}
		
		
		Boolean mailingAddressSameAsHomeAddress = globalData.get("AccountHolder_MailingAddressSameAsHA").equalsIgnoreCase("Y")?true:false;
		if(mailingAddressSameAsHomeAddress ==false){
			mailStreetAddress = globalData.get("Member1_M_StreetAddress");
			mailAptUnit = globalData.get("Member1_M_Apt_Unit");
			mailCity = globalData.get("Member1_M_City");
			mailZipCode = globalData.get("Member1_M_ZIP_Code");
			mailCounty = globalData.get("Member1_M_County");
		}
		
		String phoneNo =globalData.get("Member1_PhoneNo");
		String secondaryPhoneNo = globalData.get("Member1_Secondary_PhoneNo");
		
		
		List<String> listNames = Language.getNames();
		if( ! listNames.contains(spokenLang)  ){
			throw new Exception("Language Name is not correct [" + spokenLang + "] Accepted Value " +listNames );
		}
		if( ! listNames.contains(writtenLang)  ){
			throw new Exception("Language Name is not correct [" + writtenLang + "] Accepted Value " +listNames );
		}
		
		HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,
				testCaseId);
		hohContactInformationPage.enterContactInfo(profileAccHolder,
				firstName, lastName,
				middleName, emailId, dob);

		/*hohContactInformationPage.enterHomeAddress(noHomeAddressReqd,
				homeStreetAddress, homeAptUnit,
				homeCity, homeZipCode,
				homeCounty);*/
		hohContactInformationPage.enterMailingAddress(mailingAddressSameAsHomeAddress,
				mailStreetAddress, mailAptUnit,
				mailCity, mailZipCode,
				mailCounty);

		hohContactInformationPage.enterPhoneNos(phoneNo,
				secondaryPhoneNo);
		hohContactInformationPage.enterContactPreferences(spokenLang,
				writtenLang);
	}
	
	/**
	 * Accept DataTable with following value
	 * 1. FirstNameFormat -- STR_YC, END_KED, "","ABCD"
	 * 2. MiddleNameFormat -- STR_YC, END_KED, "","ABCD"
	 * 3. LastNameFormat -- STR_YC, END_KED, "","ABCD"
	 * 4. Age -- Any Digit
	 * 5. SpokenLang -- English, Spanish
	 * 6. WrittenLanguage -- English, Spanish

	From HOH Contact Info Page, Enter HOH Details When Residence RFI Is Required
		|FirstNameFormat |MiddleNameFormat|LastNameFormat|Age|SpokenLang|WrittenLanguage	|
		|				 |				  |		     	 |35 |English	|English			|
	
	 */
	@And("^From HOH Contact Info Page, Enter HOH Details When Residence RFI Is Required$")
	public void fill_Member_Account_Holder_Details_WhenResidenceRFIIsRequired(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String fNameFormat = scenarioData.get(1).get(0);
		String mNameFormat = scenarioData.get(1).get(1);
		String lNameFormat = scenarioData.get(1).get(2);
		String age = scenarioData.get(1).get(3);
		String spokenLang = scenarioData.get(1).get(4);
		String writtenLang = scenarioData.get(1).get(5);
		
		String firstName = RandomGenerator.getRunTimeName("MEM", fNameFormat);
		String middleName = RandomGenerator.getRunTimeName("", mNameFormat);
		String lastName = RandomGenerator.getRunTimeName("ONE", lNameFormat);
		
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		
		String dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, age);
		
		String emailId = globalData.get("Member1_EmailAddress");
		String homeStreetAddress = null;
		String homeAptUnit= null;
		String homeCity= null;
		String homeZipCode= null;
		String homeCounty= null;
		String mailStreetAddress= null;
		String mailAptUnit= null;
		String mailCity= null;
		String mailZipCode= null;
		String mailCounty= null; 
		
		Boolean profileAccHolder = globalData.get("IsProfileAccHolder").equalsIgnoreCase("Y")?true:false;
		Boolean noHomeAddressReqd = globalData.get("AccountHolder_NoHomeAddressReqd").equalsIgnoreCase("Y")?true:false;
		if(noHomeAddressReqd == false){
			homeStreetAddress = globalData.get("Member1_H_StreetAddress");
			homeAptUnit = globalData.get("Member1_H_Apt_Unit");
			homeCity = globalData.get("Member1_H_City_WhenResidencyRFIRequired");
			homeZipCode = globalData.get("Member1_H_ZIP_Code");
			homeCounty = globalData.get("Member1_H_County");
		}
		
		
		Boolean mailingAddressSameAsHomeAddress = globalData.get("AccountHolder_MailingAddressSameAsHA").equalsIgnoreCase("Y")?true:false;
		if(mailingAddressSameAsHomeAddress ==false){
			mailStreetAddress = globalData.get("Member1_M_StreetAddress");
			mailAptUnit = globalData.get("Member1_M_Apt_Unit");
			mailCity = globalData.get("Member1_M_City");
			mailZipCode = globalData.get("Member1_M_ZIP_Code");
			mailCounty = globalData.get("Member1_M_County");
		}
		
		String phoneNo =globalData.get("Member1_PhoneNo");
		String secondaryPhoneNo = globalData.get("Member1_Secondary_PhoneNo");
		
		
		List<String> listNames = Language.getNames();
		if( ! listNames.contains(spokenLang)  ){
			throw new Exception("Language Name is not correct [" + spokenLang + "] Accepted Value " +listNames );
		}
		if( ! listNames.contains(writtenLang)  ){
			throw new Exception("Language Name is not correct [" + writtenLang + "] Accepted Value " +listNames );
		}
		
		HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,
				testCaseId);
		hohContactInformationPage.enterContactInfo(profileAccHolder,
				firstName, lastName,
				middleName, emailId, dob);

		/*hohContactInformationPage.enterHomeAddress(noHomeAddressReqd,
				homeStreetAddress, homeAptUnit,
				homeCity, homeZipCode,
				homeCounty);*/
		hohContactInformationPage.enterMailingAddress(mailingAddressSameAsHomeAddress,
				mailStreetAddress, mailAptUnit,
				mailCity, mailZipCode,
				mailCounty);

		hohContactInformationPage.enterPhoneNos(phoneNo,
				secondaryPhoneNo);
		hohContactInformationPage.enterContactPreferences(spokenLang,
				writtenLang);
	}
	
	
		
	/**@author akumari4
	
	From HOH Contact Info Page, Complete HOH Details When Temp Data is Used
		| SpokenLang|WrittenLanguage|
		|English	|English		|
	
	 */
	@And("^From HOH Contact Info Page, Complete HOH Details When Temp Data is Used$")
	public void fill_Member_Account_Holder_Details_From_TempData(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String fName = getTempTestData("Mem_1FirstName");
		String mName = getTempTestData("Mem_1MiddleName");
		String lName = getTempTestData("Mem_1LastName");
		String dob = getTempTestData("Mem_1DOB");
		String spokenLang = scenarioData.get(1).get(0);
		String writtenLang = scenarioData.get(1).get(1);
		
		String emailId = globalData.get("Member1_EmailAddress");
		String homeStreetAddress = null;
		String homeAptUnit= null;
		String homeCity= null;
		String homeZipCode= null;
		String homeCounty= null;
		String mailStreetAddress= null;
		String mailAptUnit= null;
		String mailCity= null;
		String mailZipCode= null;
		String mailCounty= null; 
		
		Boolean profileAccHolder = globalData.get("IsProfileAccHolder").equalsIgnoreCase("Y")?true:false;
		Boolean noHomeAddressReqd = globalData.get("AccountHolder_NoHomeAddressReqd").equalsIgnoreCase("Y")?true:false;
		if(noHomeAddressReqd == false){
			homeStreetAddress = globalData.get("Member1_H_StreetAddress");
			homeAptUnit = globalData.get("Member1_H_Apt_Unit");
			homeCity = globalData.get("Member1_H_City");
			homeZipCode = globalData.get("Member1_H_ZIP_Code");
			homeCounty = globalData.get("Member1_H_County");
		}
		
		
		Boolean mailingAddressSameAsHomeAddress = globalData.get("AccountHolder_MailingAddressSameAsHA").equalsIgnoreCase("Y")?true:false;
		if(mailingAddressSameAsHomeAddress ==false){
			mailStreetAddress = globalData.get("Member1_M_StreetAddress");
			mailAptUnit = globalData.get("Member1_M_Apt_Unit");
			mailCity = globalData.get("Member1_M_City");
			mailZipCode = globalData.get("Member1_M_ZIP_Code");
			mailCounty = globalData.get("Member1_M_County");
		}
		
		String phoneNo =globalData.get("Member1_PhoneNo");
		String secondaryPhoneNo = globalData.get("Member1_Secondary_PhoneNo");
		
		
		List<String> listNames = Language.getNames();
		if( ! listNames.contains(spokenLang)  ){
			throw new Exception("Language Name is not correct [" + spokenLang + "] Accepted Value " +listNames );
		}
		if( ! listNames.contains(writtenLang)  ){
			throw new Exception("Language Name is not correct [" + writtenLang + "] Accepted Value " +listNames );
		}
		
		HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,testCaseId);
		hohContactInformationPage.enterContactInfo(profileAccHolder,
				fName, lName,
				mName, emailId, dob);

		/*hohContactInformationPage.enterHomeAddress(noHomeAddressReqd,
				homeStreetAddress, homeAptUnit,
				homeCity, homeZipCode,
				homeCounty);*/
		hohContactInformationPage.enterMailingAddress(mailingAddressSameAsHomeAddress,
				mailStreetAddress, mailAptUnit,
				mailCity, mailZipCode,
				mailCounty);

		hohContactInformationPage.enterPhoneNos(phoneNo,
				secondaryPhoneNo);
		hohContactInformationPage.enterContactPreferences(spokenLang,
				writtenLang);
	}
	
	/**Ritu
     * 
    From HOH Contact Info Page,During RAC Change Home Address       
    	|     StreetAddr   |      AptUnit      |      City   |      County     |
     	|     411       |  215          |     CAMBRIDGE|   HAMPSHIRE   |
     */
     @And("^From HOH Contact Info Page,During RAC Change Home Address$")
     public void changeHomeAddr(DataTable table) throws Exception
     {
           List<List<String>> scenarioData = table.raw();
           String streetAddress1 = scenarioData.get(1).get(0);
           String aptUnitNo = scenarioData.get(1).get(1);
           String city = scenarioData.get(1).get(2);
           String county = scenarioData.get(1).get(3);
           
           HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,testCaseId);
           hohContactInformationPage.changeHomeAddressRAC(streetAddress1, aptUnitNo, city, county);
           
     }

     
	/**Ritika
	 * 
	 From HOH Contact Info Page,During RAC Change Mailing Address
	 |	StreetAddr	|	AptUnit	|	City	|	Zip		|	County	|
	 |	430 MAIN	|	215		|	Boston	|	02035	| 	NORFOLK	|
	 */
	@And("^From HOH Contact Info Page,During RAC Change Mailing Address$")
	public void changeMailingAddr(DataTable table) throws Exception
	{
		List<List<String>> scenarioData = table.raw();
		String streetAddress1 = scenarioData.get(1).get(0);
		String aptUnitNo = scenarioData.get(1).get(1);
		String city = scenarioData.get(1).get(2);
		String zip = scenarioData.get(1).get(3);
		String county = scenarioData.get(1).get(4);
		
		HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,testCaseId);
		hohContactInformationPage.changeMailingAddressRAC(streetAddress1, aptUnitNo, city, zip, county);
		
	}
	
	@And("^From HOH Contact Info Page, Page Load And Click On Save And Continue$")
	public void pageLoadAndClickOnSaveAndContinue() throws Exception{
		HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,
				testCaseId);
		hohContactInformationPage.pageLoadAndClickOnSaveAndContinue();
	}
	
	@And("^From HOH Contact Info Page,Update Phone Number$")
	public void changePhoneNumber() throws Exception
	{

		HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,testCaseId);
		hohContactInformationPage.enterPhoneNos("5615551235", "5615551235");
		
	}
	
	@And("^From Change Your Info Page, Click On Change contact information and preferences$")
	public void clickOnContactInfo(DataTable table) throws Exception {
		ChangeYourInfoPage changeYourInfo = new ChangeYourInfoPage(driver, testCaseId);
		changeYourInfo.contactInfoPreferences();
		List<List<String>> scenarioData = table.raw();
		String streetAddress1 = scenarioData.get(1).get(0);
		String aptUnitNo = scenarioData.get(1).get(1);
		String city = scenarioData.get(1).get(2);
		String zip = scenarioData.get(1).get(3);
		String county = scenarioData.get(1).get(4);
		HOHContactInformationPage hOHContactInformationPage= new HOHContactInformationPage(driver, testCaseId);
		hOHContactInformationPage.enterMailingAddress(false, streetAddress1, aptUnitNo, city, zip, county);
	}

	@And("^From HOH Contact Info Page,Click On Save$")
	public void clickOnSave() throws Exception{
		HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,
				testCaseId);
		hohContactInformationPage.clickOnSaveBtn();
	}
	
	/**Shailza
     * 
    From HOH Contact Info Page,During RAC Change HOH Last Name 
    |	LastName	|	
	 |	KAB		|
    */
     @And("^From HOH Contact Info Page,During RAC Change HOH Last Name$")
     public void changeHOHLastName(DataTable table) throws Exception
     {
           List<List<String>> scenarioData = table.raw();
           String lastName = scenarioData.get(1).get(0);
     
           HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,testCaseId);
           hohContactInformationPage.changeLastNameHOH(lastName);
           
     }
     
     /**Shailza
      * 
     From HOH Contact Info Page,During RAC Change HOH Email Address
     |	EmailAddress	|	
 	 |	b@b.com			|
     */
      @And("^From HOH Contact Info Page,During RAC Change HOH Email Address$")
      public void changeHOHEmailAddress(DataTable table) throws Exception
      {
            List<List<String>> scenarioData = table.raw();
            String emailAddress = scenarioData.get(1).get(0);
      
            HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,testCaseId);
            hohContactInformationPage.changeEmailAddress(emailAddress);
            
      }
      
      /**Shailza
       * 
      From HOH Contact Info Page,During RAC Change HOH Email Address
      |	Spoken Language	|	Written Language	|	
  	 |	Spanish		| Spanish		|
      */
       @And("^From HOH Contact Info Page,During RAC Change HOH Contact Preferences$")
       public void changeHOHContactPreferences(DataTable table) throws Exception
       {
             List<List<String>> scenarioData = table.raw();
             String spokenLang = scenarioData.get(1).get(0);
             String writtenLang = scenarioData.get(1).get(1);
       
             HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver,testCaseId);
             hohContactInformationPage.enterContactPreferences(spokenLang,
     				writtenLang);
             
       }
     
     /**Ritika
     
     From Who Is Applying Page, Select Name Change For Same Member On Confirm PopUp
     
     */
    @And("^From HOH Contact Info Page, Select Name Change For Same Member On Confirm PopUp$")
  	public void selectNameChange() throws Exception{
  	WhoAreYourHHMemberPage WhoAreYourHHMemberPage = new WhoAreYourHHMemberPage(driver, testCaseId);
  	WhoAreYourHHMemberPage.selectMemNameChange();
  	WhoAreYourHHMemberPage.clickOnConfirmNameChangePopUp();

  	}
	
}
