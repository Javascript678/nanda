package stepdefs.startApplication;

import cucumber.api.java.en.And;
import pages.startApplication.HowManyApplyingPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class HowManyApplyingPageSteps extends SuperStepDef {

	public HowManyApplyingPageSteps(Hook hook) {
		super(hook);
	}

	/**
	 * Accepted Value 
	 * 		MemCountOnUI :- 1,	2, 3
	 * 
	 From How Many Applying Page, Select Add Member Count On UI As "5"
	 
	 *Member count is mentioned considering that by default 1 person is already selected
	 
	 */
	@And("^From How Many Applying Page, Select Add Member Count On UI As \"(.*?)\"$")
	public void selectAddMemCount(String strAddMemberCountOnUI) throws Exception{
		int memberCountOnUI = Integer.parseInt(strAddMemberCountOnUI);
		
		HowManyApplyingPage howManyApplyingPage = new HowManyApplyingPage(driver, testCaseId);
		howManyApplyingPage.selectAddMemberCountOnUI(memberCountOnUI);

	}
	
	/**
	 * @author akumari4
	 * @param strMemberCountOnUI
	 * @throws Exception
	 * From How Many Applying Page, Select Remove Member Count On UI As "4"
	 */
	@And("^From How Many Applying Page, Select Remove Member Count On UI As \"(.*?)\"$")
	public void selectRemoveMemCount(String strRemoveMemberCountOnUI) throws Exception{
		int memberCountOnUI = Integer.parseInt(strRemoveMemberCountOnUI);
		
		HowManyApplyingPage howManyApplyingPage = new HowManyApplyingPage(driver, testCaseId);
		howManyApplyingPage.selectRemoveMemberCountOnUI(memberCountOnUI);

	}
	
	
	@And("^From How Many Applying Page, Click On Save And Continue$")
	public void selectMemCount() throws Exception{
		
		HowManyApplyingPage howManyApplyingPage = new HowManyApplyingPage(driver, testCaseId);
		howManyApplyingPage.pageLoadAndClickOnSaveAndCOntinue();

	}
	
	@And("^From How Many Applying Page, Click On Warning POPUP$")
	public void clickOnWarningPopUp() throws Exception{
		HowManyApplyingPage howManyApplyingPage = new HowManyApplyingPage(driver, testCaseId);
		howManyApplyingPage.clickOnWarningOkButton();
	}

}
