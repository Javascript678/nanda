package stepdefs.startApplication;

import cucumber.api.java.en.And;
import db.ElgMemberTable;
import pages.startApplication.WhoIsApplyingForHISummaryPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class HelathInsuranceSummaryPageSteps extends SuperStepDef {

	public HelathInsuranceSummaryPageSteps(Hook hook) {
		super(hook);
	}

	//TODO: Validate name, DOB of each members applying
	
	@And("^From Who Is Applying For HI Summary Page, Validate Name and DOB for All From DB$")
	public void validateNameAndDOBForMembers() throws Exception {

		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		WhoIsApplyingForHISummaryPage healthInsuranceSummaryPage = new WhoIsApplyingForHISummaryPage(driver,testCaseId);
		for(int memCounter=0;memCounter<memCount; memCounter++){
			String expName = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memCounter);
			String expDOB = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memCounter);
			healthInsuranceSummaryPage.validateNameForMember(memCounter, expName);
			healthInsuranceSummaryPage.validateDOBForMember(memCounter, expDOB);
		}
	}
	
	@And("^From Who Is Applying For HI Summary Page, Page Load And Click on Continue$")
	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception {

		WhoIsApplyingForHISummaryPage healthInsuranceSummaryPage = new WhoIsApplyingForHISummaryPage(driver,testCaseId);
		healthInsuranceSummaryPage.pageLoadAndClickOnSaveAndContinueBtn();

	}
	
	@And("^From Who Is Applying For HI Summary Page, Click on Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception {

		WhoIsApplyingForHISummaryPage healthInsuranceSummaryPage = new WhoIsApplyingForHISummaryPage(driver,testCaseId);
		healthInsuranceSummaryPage.clickOnSaveAndContinueBtn();

	}

}
