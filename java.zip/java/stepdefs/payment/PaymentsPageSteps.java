package stepdefs.payment;

import cucumber.api.java.en.Given;
import pages.payment.PaymentPortalPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
/**
 * 
 * @author Paul Pinho
 *
 */
public class PaymentsPageSteps extends SuperStepDef{
	
	public PaymentsPageSteps(Hook hook){
		super(hook);
	}
	
@Given("^From Payment Portal Page, Wait For Page To Load$")
	public void checkPaymentPortal() throws Exception {
		PaymentPortalPage paymentPortaltPage = new PaymentPortalPage(driver, testCaseId);
		paymentPortaltPage.waitForPageLoaded();
		paymentPortaltPage.takeScreenshot();
	}
}
