package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;
import cucumber.api.java.en.Then;
import db.BatchEnrollmentXmlControlTable;
import db.ElgMemberTable;
import db.EligibilityTable;
import db.EnrlXmlInputCtrlTable;

/**
 * 
 * @author Ritika
 *	Step Def for Interaction with EnrlXmlInputCtrl Table
 */
public class EnrlXmlInputCtrlTableSteps extends SuperStepDef {


	
	public EnrlXmlInputCtrlTableSteps(Hook hook)  {
		super(hook);
	}
	
	/**
	 * @author Ritika
	 * @param expStatus		:- COMPLETED, 
	 * @param memNo		:- 1,2,3
	 * @param coverageType	:- MEDICAL, DENTAL
	 * @param action		:- INITIAL, TERM , ADD, CHANGE 
	 
	  From EnrlXmlInputCtrl Table, Validate Current Status As "COMPLETED" For Member "1" ,Coverage Type As "MEDICAL" And Action As "INITIAL"
	 
	 */
	@Then("^From EnrlXmlInputCtrl Table, Validate Current Status As \"(.*?)\" For Member \"(.*?)\" ,Coverage Type As \"(.*?)\" And Action As \"(.*?)\"$")
	public void storeCompleteDataInExcel(String expStatus, String memNo, String coverageType, String action) throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		ElgMemberTable elgMemberTable = new db.ElgMemberTable(conn, testCaseId);
		String fName = elgMemberTable.getFirstName(elgId, memIndex);
		String lName = elgMemberTable.getLastName(elgId, memIndex);
		
		EnrlXmlInputCtrlTable enb_inputCtrl_tbale = new EnrlXmlInputCtrlTable(conn, testCaseId);
		enb_inputCtrl_tbale.validateCurrentStatus(elgId, fName, lName, coverageType, action,expStatus);
		
	}
	
	/**
	 * @author Ritika
	 * @param memNo		:- 1,2,3
	 * @param coverageType	:- MEDICAL, DENTAL
	 * @param action		:- INITIAL, TERM , ADD, CHANGE 
	 
	  From EnrlXmlInputCtrl Table, Store Member "1" Input XML for Coverage Type As "MEDICAL" And Action As "INITIAL"
	 
	 */
	@Then("^From EnrlXmlInputCtrl Table, Store Member \"(.*?)\" Input XML for Coverage Type As \"(.*?)\" And Action As \"(.*?)\"$")
	public void storeInputXML(String memNo, String coverageType, String action) throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		ElgMemberTable elgMemberTable = new db.ElgMemberTable(conn, testCaseId);
		String fName = elgMemberTable.getFirstName(elgId, memIndex);
		String lName = elgMemberTable.getLastName(elgId, memIndex);
		
		EnrlXmlInputCtrlTable enb_inputCtrl_tbale = new EnrlXmlInputCtrlTable(conn, testCaseId);
		
		String xmlLink = enb_inputCtrl_tbale.storeInputXML(elgId, fName, lName, coverageType, action);
		System.out.println(xmlLink);
		
		TestData.storeTempTestData("CurrentXML_Link", xmlLink, featureFileName);
		
	}
	
	/**
	 * @author Ritika
	 * @param coverageType	:- MEDICAL, DENTAL
	 * @param action		:- INITIAL, TERM , ADD, CHANGE 

	  From EnrlXmlInputCtrl Table, Store Input XML for Coverage Type As "MEDICAL" And Action As "INITIAL"

	 */
	@Then("^From EnrlXmlInputCtrl Table, Store Input XML for Coverage Type As \"(.*?)\" And Action As \"(.*?)\"$")
	public void storeInputXMLfromDB(String coverageType, String action) throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		String xmlType="";
		int rowIndex;
		if(coverageType.equalsIgnoreCase("MEDICAL"))
		{
			xmlType="HLT";
			rowIndex=0;
			}
		else{
			xmlType="DEN";
			rowIndex=1;
		}

		EligibilityTable eligibiltyTable = new EligibilityTable(conn, testCaseId);
		String userProfileId=eligibiltyTable.getUserProfileId(elgId);

		BatchEnrollmentXmlControlTable batchEnrollmentXmlControlTable = new BatchEnrollmentXmlControlTable(conn, testCaseId);
		String batchXMLCtrlId=batchEnrollmentXmlControlTable.getColumnValueforID(userProfileId, action, rowIndex);

		EnrlXmlInputCtrlTable enrlXmlInputCtrlTable = new EnrlXmlInputCtrlTable(conn, testCaseId);
		String xmlLink = enrlXmlInputCtrlTable.storeInputXMLfromDB(batchXMLCtrlId, xmlType, elgId, coverageType, action);
		System.out.println(xmlLink);

		TestData.storeTempTestData("CurrentXML_Link", xmlLink, featureFileName);

	}

	/**@author akumari4
	 * 
	 From EnrlXmlInputCtrl Table, Store Created Date For Member "1" Input XML With Coverage Type As "MEDICAL" And Action As "INITIAL"

	 */
	@Then("^From EnrlXmlInputCtrl Table, Store Created Date For Member \"(.*?)\" Input XML With Coverage Type As \"(.*?)\" And Action As \"(.*?)\"$")
	public void storeInputXMLCreatedDate(String memNo, String coverageType, String action) throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		ElgMemberTable elgMemberTable = new db.ElgMemberTable(conn, testCaseId);
		String fName = elgMemberTable.getFirstName(elgId, memIndex);
		String lName = elgMemberTable.getLastName(elgId, memIndex);
		
		EnrlXmlInputCtrlTable enb_inputCtrl_tbale = new EnrlXmlInputCtrlTable(conn, testCaseId);
		String createdDate= enb_inputCtrl_tbale.getCreatedDate(elgId, fName, lName, coverageType, action);
		String createdDateInDBFormat = DateUtil.getDateInDBFormatUsingPattern(createdDate, "yyyy-MM-dd");
		storeTempTestData("EnrollmentDate", createdDateInDBFormat);
	}
}
