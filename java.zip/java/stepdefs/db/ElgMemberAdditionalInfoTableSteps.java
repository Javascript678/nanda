package stepdefs.db;

import cucumber.api.java.en.Given;
import db.ElgMemberAdditionalInfoTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class ElgMemberAdditionalInfoTableSteps extends SuperStepDef {
	
	public ElgMemberAdditionalInfoTableSteps(Hook hook) {
		super(hook);
	}
	
	/**@author Ritu
	 
	 From ElgMemberAdditionalInfoTable, Update Post Paturm End Date For Member "2"
	 
	 */
	@Given("^From ElgMemberAdditionalInfoTable, Update Post Paturm End Date For Member \"(.*?)\"$")
	public void expireCitizenshipRFIsForAllMember(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String postPartumEndDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberAdditionalInfoTable elgMemberAdditionalInfoTable = new ElgMemberAdditionalInfoTable(conn, testCaseId);
		elgMemberAdditionalInfoTable.updatePostPartumEndDate(userProfileRefId,memIndex , postPartumEndDate);
		
	}
	
	
	
}
