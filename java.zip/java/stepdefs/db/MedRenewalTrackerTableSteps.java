package stepdefs.db;

import cucumber.api.java.en.Given;
import db.MedRenewalTrackerTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class MedRenewalTrackerTableSteps extends SuperStepDef
{
	public MedRenewalTrackerTableSteps(Hook hook) {
		super(hook);
	}

	/* @author ppinho
	 * 
	   Expected Status
			COMPLETED
			ERROR
			NOT_PROCESSED
			NOT_PROCESSED_999
			RESPONSE_NOT_REQRD

	  
	  From MedRenewalTracker Table,Validate Status As "NOT_PROCESSED", For Member "1"
	 * 
	 */
	@Given("^From MedRenewalTracker Table, Validate Status As \"(.*?)\", For Member \"(.*?)\"$")
	public void validateStatus(String expStatus,int memNo) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		int memIndex = memNo - 1;
		MedRenewalTrackerTable medRenewalTracker = new MedRenewalTrackerTable(conn, testCaseId);
		medRenewalTracker.validateStatus(userProfileRefId, memIndex, expStatus);
	}
	
}
