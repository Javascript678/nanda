package stepdefs.db;

import cucumber.api.java.en.Then;
import db.DualTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class DualTableSteps extends SuperStepDef {
	/**
	 * 
	 * @author Vinay
	 **/
	
	public DualTableSteps(Hook hook) {
		super(hook);
		
		
	}
	
	/**Vinay 
	 * 	Accepted format :- yyyy-MM-dd
	 
	    From Dual Table Validate System Date As "2018-12-27"
	 */
	@Then("^From Dual Table Validate System Date As \"(.*?)\"$")
	public void storeCompleteDataInExcel(String expSysDate) throws Throwable {
		DualTable  dualTable = new DualTable(conn, testCaseId);
		dualTable.validateSysDate(expSysDate);
		
	}
	

}
