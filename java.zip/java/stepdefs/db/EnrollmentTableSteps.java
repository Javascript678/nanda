package stepdefs.db;

import cucumber.api.java.en.Given;
import db.EligibilityTable;
import db.EnrollmentTable;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;



public class EnrollmentTableSteps extends SuperStepDef {

	public EnrollmentTableSteps(Hook hook) {
		super(hook);
	}
	

	/**Aashita 
	 /** For Update Query in PDM batch Jobs.
	
	From EnrollmentTable, Update the status to "Active" for Eligibility Id With Variable Name As "ElgId_Validation" 
	 */
	@Given("^From EnrollmentTable, Update the status to \"(.*?)\" for Eligibility Id With Variable Name As \"(.*?)\"$")
	public void updatestatusforPDM(String statusToSet , String elgIdVariableName ) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		//String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		String elgId = getTempTestData(elgIdVariableName);
		EnrollmentTable enrollmentTable = new EnrollmentTable(conn, testCaseId);
		enrollmentTable.updateStatusPDM(elgId, statusToSet);
	}
	
	/**Aashita 
	 /** For Update Query in PDM batch Jobs.
	
	From EnrollmentTable, Update the status to "Active" for Latest Eligibility Id 
	 */
	@Given("^From EnrollmentTable, Update the status to \"(.*?)\" for Latest Eligibility Id$")
	public void updatestatusforPDMUsingRefId(String statusToSet ) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		EnrollmentTable enrollmentTable = new EnrollmentTable(conn, testCaseId);
		enrollmentTable.updateStatusPDM(elgId, statusToSet);
	}
}
