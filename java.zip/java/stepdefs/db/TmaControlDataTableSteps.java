package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

import cucumber.api.java.en.Then;
import db.TmaControlDataTable;

public class TmaControlDataTableSteps extends SuperStepDef {

	
	
	public TmaControlDataTableSteps(Hook hook)  {
		super(hook);
	}
			
	/**@author ppinho
	*
	*/ 
	@Then("^From TMA Control Data Table, Using Current EligId, Update TMA Period End Date$")
	public void validateDORreferralRecordInterfaceTableStatus() throws Throwable {	
		String eligibilityId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);	
		
		TmaControlDataTable tmaControlDataTable = new TmaControlDataTable(conn, testCaseId);
		
		String effectiveDate = tmaControlDataTable.getTmaPeriodEffectiveDate(eligibilityId);
		effectiveDate = DateUtil.getDateInUIFormatUsingPattern(effectiveDate, DateUtil.dbDatePattern);
		
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(effectiveDate, DateUtil.UIDatePattern, "00:00:02");		
			
		tmaControlDataTable.updateEndDateForElgMemId(eligibilityId, newDueDate);
	}
	
}
