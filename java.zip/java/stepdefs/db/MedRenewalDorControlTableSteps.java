package stepdefs.db;

import cucumber.api.java.en.Given;
import db.MedRenewalDorControlTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class MedRenewalDorControlTableSteps extends SuperStepDef
{


	public MedRenewalDorControlTableSteps(Hook hook) {
		super(hook);
	}

	/*
	 * @Vinay 
	 * Expected Status
			COMPLETED
			ERROR
			NOT_PROCESSED
			NOT_PROCESSED_999
			RESPONSE_NOT_REQRD

	  
	  From MedRenewalDorControl Table,Validate Status As "NOT_PROCESSED",For Member As "1"
	 * 
	 */
	@Given("^From MedRenewalDorControl Table,Validate Status As \"(.*?)\",For Member As \"(.*?)\"$")
	public void validateStatus(String expStatus,int memNo) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		int memIndex = memNo - 1;
		MedRenewalDorControlTable medRenewalDorControlTable = new MedRenewalDorControlTable(conn, testCaseId);
		medRenewalDorControlTable.validateStatus(userProfileRefId, memIndex, expStatus);
	}
	
	/*
	 * @Vinay
	  
	  From MedRenewalDorControl Table,Update Reported Wages As "21000",For Member As "1"
	 * 
	 */
	@Given("^From MedRenewalDorControl Table,Update Reported Wages As \"(.*?)\",For Member As \"(.*?)\"$")
	public void updateReponseXML_reportedWages(String reportedWages,int memNo) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		int memIndex = memNo - 1;
		MedRenewalDorControlTable medRenewalDorControlTable = new MedRenewalDorControlTable(conn, testCaseId);
		medRenewalDorControlTable.updateReponseXML_reportedWages(userProfileRefId, memIndex, reportedWages);
	}
	
	
	
}
