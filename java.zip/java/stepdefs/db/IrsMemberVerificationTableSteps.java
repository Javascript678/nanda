/**
 * 
 */
package stepdefs.db;

import cucumber.api.java.en.Then;
import db.IrsMemberVerificationTable;
import db.IrsResponseMetadataTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

/**
 * @author vverma25
 *Step Def for Interaction with IRS Member Verification Table
 */
public class IrsMemberVerificationTableSteps extends SuperStepDef {

	public IrsMemberVerificationTableSteps(Hook hook) {
		super(hook);
		
	}
	
	//Vimal
	@Then("^From IRS Member Verification Table, Store Completed Data into Excel folder$")
	public void storeCompleteDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		IrsMemberVerificationTable irsMemberVerificationTable = new IrsMemberVerificationTable(conn,testCaseId);
		irsMemberVerificationTable.storeCompleteDataInExcel(elgId, 0);
	}
	
	//Vimal
	@Then("^From IRS Member Verification Table, Store Hub Request Reponse Data into Excel folder$")
	public void storeHubRequestReponseDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		IrsMemberVerificationTable irsMemberVerificationTable = new IrsMemberVerificationTable(conn,testCaseId);
		irsMemberVerificationTable.storeHubRequestReponseDataInExcel(elgId, 0);
	}
	
	// ppinho
	@Then("^From IrsMemberVerification Table, Update Magi Amount For Each Member$")
	public void updateMagiAmountForEachMember() throws Throwable {
		IrsMemberVerificationTable irsMemberVerificationTable = new IrsMemberVerificationTable(conn, testCaseId);
		IrsResponseMetadataTable irsResponseMetadataTable = new IrsResponseMetadataTable(conn, testCaseId);
		
		String userRefId = evpdData.memsData.get(0).userRefId;
				
		for(int memInd = 0; memInd < evpdData.memCount; memInd++){			
			if(initialPrelimData.memsData.get(memInd).hasIrsIncome){			
				if(initialPrelimData.memsData.get(memInd).rrvIrsIncome.contains("ERROR")){
					String[] error = initialPrelimData.memsData.get(memInd).rrvIrsIncome.split(":");
					
					irsMemberVerificationTable.ccaRenewalMagiAmtNullUpdateQuery(userRefId, memInd);
					irsResponseMetadataTable.ccaRenewalResponseCodeDescriptionUpdateQuery(userRefId, memInd, error[1], error[0]);
				}else{
					irsMemberVerificationTable.ccaRenewalMagiAmtUpdateQuery(userRefId, memInd, initialPrelimData.memsData.get(memInd).rrvIrsIncome);
				}
			}
		}		
	}
	
	// ppinho
	@Then("^From IrsMemberVerification Table, Update Taxable SSB For Each Member$")
	public void updateTaxableSsbForEachMember() throws Throwable {
		IrsMemberVerificationTable irsMemberVerificationTable = new IrsMemberVerificationTable(conn, testCaseId);
		IrsResponseMetadataTable irsResponseMetadataTable = new IrsResponseMetadataTable(conn, testCaseId);
		
		String userRefId = evpdData.memsData.get(0).userRefId;
		
		for(int memInd = 0; memInd < evpdData.memCount; memInd++){			
			if(initialPrelimData.memsData.get(memInd).hasIrsSsbIncome){
				if(initialPrelimData.memsData.get(memInd).rrvIrsSsbIncome.contains("ERROR")){
				String[] error = initialPrelimData.memsData.get(memInd).rrvIrsSsbIncome.split(":");
				
				irsMemberVerificationTable.ccaRenewalTaxableSSBNullUpdateQuery(userRefId, memInd);
				irsResponseMetadataTable.ccaRenewalResponseCodeDescriptionUpdateQuery(userRefId, memInd, error[1], error[0]);
				}else{
					irsMemberVerificationTable.ccaRenewalTaxableSSBUpdateQuery(userRefId, memInd, initialPrelimData.memsData.get(memInd).rrvIrsSsbIncome);
				}
			}
		}		
	}
}
