package stepdefs.db;

import cucumber.api.java.en.Then;
import db.MaHubRequestResponseTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

//Vimal
public class MaHubRequestResponseSteps extends SuperStepDef {

	public MaHubRequestResponseSteps(Hook hook) {
		super(hook);
	}

	// ppinho
	@Then("^From MaHubRequestResponse Table, Update Deceased Status For Each Member$")
	public void updateDeceasedStatusForEachMember() throws Throwable {
		MaHubRequestResponseTable maHubRequestResponseTable = new MaHubRequestResponseTable(conn, testCaseId);
				
		String userRefId = evpdData.memsData.get(0).userRefId;
						
		for(int memInd = 0; memInd < evpdData.memCount; memInd++){
			if(initialPrelimData.memsData.get(memInd).hasDeath){
				if(initialPrelimData.memsData.get(memInd).rrvSsaDeath.contains("ERROR")){
					String[] error = initialPrelimData.memsData.get(memInd).rrvSsaDeath.split(":");
					maHubRequestResponseTable.ccaRenewalSsaErrorUpdateQuery(userRefId, memInd, error[1]);
				}else{
					maHubRequestResponseTable.ccaRenewalDeceasedUpdateQuery(userRefId, memInd, initialPrelimData.memsData.get(memInd).rrvSsaDeath);
				}
			}
		}		
	}
}
