package stepdefs.db;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.commons.pool.ObjectPool;
import org.json.JSONObject;
import org.junit.Assert;

import appdata.common.SqlCredentials;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.MedRenewalControlTable;
import db.RenewalElgTrackerTable;
import mysql.MySQL;
import mysql.MySQL_Conn_Data;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.HttpsClient;
import utils.TestData;

public class RenewalElgTrackerTableSteps extends SuperStepDef {
				
	public RenewalElgTrackerTableSteps(Hook hook) {
		super(hook);
	}
	
	/**@author: Ritika 
	* 
	* From RenewalElgTracker Table, Update Status As "Null"
	* 
	*/
	@Given("^From RenewalElgTracker Table, Update Status As \"(.*?)\"$")
	public void expireCitizenshipRFIsForAllMember(String status,String startDate,String endDate) throws Exception {		
		RenewalElgTrackerTable renewalElgTrackerTable = new RenewalElgTrackerTable(conn, testCaseId);
		renewalElgTrackerTable.updateStatus(evpdData.memsData.get(0).userRefId, status);
	}
	
	
	/** @author: ppinho
	* 
	* Expected Status:
	*	NOT_PROCESSED
	*	RENEWAL_INITIATED
	*	COMPLETED
	*  
	* From RenewalElgTracker Table, Validate Status As "NOT_PROCESSED"
	* 
	*/
	@Given("^From RenewalElgTracker Table, Validate Status As \"(.*?)\"$")
	public void validateStatus(String expStatus) throws Exception {
		RenewalElgTrackerTable renewalElgTrackerTable = new RenewalElgTrackerTable(conn, testCaseId);
		renewalElgTrackerTable.validateStatus(evpdData.memsData.get(0).userRefId, expStatus);	
	}
	
	/**@author: ppinho
	* 
	* From RenewalElgTracker Table, Run Query To Hold Elg Ids
	*	| Dataset      |
	*	| cca_renewals |
	* 
	*/
	@Given("From RenewalElgTracker Table, Run Query To Hold Elg Ids$")
	public void initiateCCARenewalHoldElgIdsQuery(DataTable table) throws Exception {
		List<List<String>> dataset = table.raw();
		
		for(int rowIndex = 1; rowIndex < dataset.size(); rowIndex++){
			String elgIds = null;
			
			try{
				hook.makeJDBCConnection();
				
				MySQL mysql = new MySQL(globalData);
				elgIds = mysql.getElgIdsInDB(hook.conn, dataset.get(rowIndex).get(0) + "_evpd");
				
			}catch(Exception e){
				System.out.printf("Table [" + dataset.get(rowIndex).get(0) + "_evpd] Not found: ", e);
	       	 	throw new Exception(e.getMessage());
	       	 	
			}finally{
	        	if(hook.conn != null && !hook.conn.isClosed()){
	        		hook.conn.close();
	        	}
	        }
			
			RenewalElgTrackerTable renewalElgTrackerTable = new RenewalElgTrackerTable(conn, testCaseId);			
			renewalElgTrackerTable.ccaRenewalHoldElgIdsUpdateQuery(elgIds, globalData);
		}
	}
	
	/**@author: ppinho
	* 
	* From RenewalElgTracker Table, Run Query To Update Process Id
	* 
	*/
	@Given("^From RenewalElgTracker Table, Run Query To Update Process Id$")
	public void initiateCCARenewalProcessIdUpdateQuery() throws Exception {
		RenewalElgTrackerTable renewalElgTrackerTable = new RenewalElgTrackerTable(conn, testCaseId);			
		renewalElgTrackerTable.ccaRenewalProcessIdUpdateQuery(evpdData);
	}
	
}
