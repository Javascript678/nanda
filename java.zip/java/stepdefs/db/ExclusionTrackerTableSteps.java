package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;
import cucumber.api.java.en.Then;
import db.ExclusionTrackerTable;


public class ExclusionTrackerTableSteps extends SuperStepDef {

	
	
	public ExclusionTrackerTableSteps(Hook hook)  {
		super(hook);
	}
	
	/**@author vkuma212
	
	From ExclusionTracker Table, Using EligId With Variable As "ElgId_NOTICE1_Validation", Validate Total Row Count As "0"

 */
	@Then("^From ExclusionTracker Table, Using EligId With Variable As \"(.*?)\", Validate Total Row Count As \"(.*?)\"$")
	public void validateRowCountForElgId(String varibleNameFrElgId, String expCount) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		int intExpCount = Integer.parseInt(expCount);
		
		ExclusionTrackerTable exclusionTrackerTable = new ExclusionTrackerTable(conn, testCaseId);
		exclusionTrackerTable.validateRowCountForElgId(eligibilityId, intExpCount);
	}
	
}
