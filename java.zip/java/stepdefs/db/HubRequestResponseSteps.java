package stepdefs.db;

import cucumber.api.java.en.Given;
import db.HubRequestResponseLogTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

//Vimal
public class HubRequestResponseSteps extends SuperStepDef {

	public HubRequestResponseSteps(Hook hook) {
		super(hook);
	}

	/**
	 * Accepted Request reponse type 1. SSA
	 */
	@Given("^HubReqRespTable, Store Resuest XML for $")
	public void store(String reqRespType) throws Exception {
	}

	/*
	 * @Shailza Shrivastava
	 * 
	 */

	/**
	 * From HubReqRespTable, Validate Request Type "VLP_STEP_ONE_PAYLOAD" Is
	 * Generated for Eligibility ID With Variable As "CurrentEligibilityId"
	 * 
	 * Accepted Request reponse type 1. IRSRequestPayLoad 2.
	 * MMIS_MEMBER_SEARCH_PAYLOAD 3. SSACompositeIndividualRequest 4.
	 * NON_ESI_MEC_VERIFICATION_PAYLOAD 5. MMIS_MEMBER_DETAIL_PAYLOAD 6.
	 * SSACompositeIndividualRequest 7. MMIS_POST_ELG_PAYLOAD 8.
	 * VLP_STEP_ONE_PAYLOAD
	 */
	@Given("^From HubReqRespTable, Validate Request Type \"(.*?)\" Is Generated for Eligibility ID With Variable As \"(.*?)\"$")
	public void validateRequestTypeGenerated(String requestType, String varibleNameFrElgId) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		HubRequestResponseLogTable hubRequestResponseLogTable = new HubRequestResponseLogTable(conn, testCaseId);
		hubRequestResponseLogTable.validateRequestTypeIsGenerated(requestType, eligibilityId);
	}

	/*
	 * @Shailza Shrivastava
	 * 
	 */

	/**
	 * From HubReqRespTable, Validate Request Type "VLP_STEP_ONE_PAYLOAD" Is Not
	 * Generated for Eligibility ID With Variable As "CurrentEligibilityId"
	 * 
	 * Accepted Request reponse type 1. IRSRequestPayLoad 2.
	 * MMIS_MEMBER_SEARCH_PAYLOAD 3. SSACompositeIndividualRequest 4.
	 * NON_ESI_MEC_VERIFICATION_PAYLOAD 5. MMIS_MEMBER_DETAIL_PAYLOAD 6.
	 * SSACompositeIndividualRequest 7. MMIS_POST_ELG_PAYLOAD 8.
	 * VLP_STEP_ONE_PAYLOAD
	 */
	@Given("^From HubReqRespTable, Validate Request Type \"(.*?)\" Is Not Generated for Eligibility ID With Variable As \"(.*?)\"$")
	public void validateRequestTypeNotGenerated(String requestType, String varibleNameFrElgId) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		HubRequestResponseLogTable hubRequestResponseLogTable = new HubRequestResponseLogTable(conn, testCaseId);
		hubRequestResponseLogTable.validateRequestTypeIsNotGenerated(requestType, eligibilityId);
	}

}
