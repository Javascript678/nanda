package stepdefs.db;

import cucumber.api.java.en.Given;
import db.RrvTdsReqResCtrlTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class RrvTdsReqResCtrlTableSteps extends SuperStepDef
{

	
	public RrvTdsReqResCtrlTableSteps(Hook hook) {
		super(hook);
	}
	
	/*
	 * @Vinay 
	 
	 Expected Status :-
			1	AWAITING_RESPONSE
			2	RESPONSE_RECEIVED
			3	RESPONSE_NOT_REQRED
			4	NOT_PROCESSED
			5	IN_PROGRESS
			6	ERROR
			7	RESPONSE_RECEIVED 
			8	HOLD
			9	COMPLETED 			
	 
	 Expected TDS :-	
	 		1	SSA
	 		2	IRS
	 		3	MEC
	 		
	 From RrvTdsReqResCtrlTable Table, For TDS As "SSA", Validate Status As "AWAITING_RESPONSE"
	 From RrvTdsReqResCtrlTable Table, For TDS As "IRS", Validate Status As "COMPLETED"
	 
	*/
	
	@Given("^From RrvTdsReqResCtrlTable Table, For TDS As \"(.*?)\", Validate Status As \"(.*?)\"$")
	public void expireCitizenshipRFIsForAllMember(String tdsValue,String expectedStatus) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		
		RrvTdsReqResCtrlTable rrvTdsReqResCtrlTable = new RrvTdsReqResCtrlTable(conn, testCaseId);
		rrvTdsReqResCtrlTable.validateStatus(userProfileRefId, tdsValue, expectedStatus);
	}
	
}
