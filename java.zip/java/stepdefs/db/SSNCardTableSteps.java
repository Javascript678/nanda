package stepdefs.db;


import cucumber.api.java.en.Then;
import db.SSNCardTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

/**
 * @author Vimal
 * Step Def For SSN Field Validation.
 * 
 **/
public class SSNCardTableSteps extends SuperStepDef {

	public SSNCardTableSteps(Hook hook) {
		super(hook);
	}
	@Then("^From SSN CARD Table, Store Completed Data Into Excel folder$")
	public void storeCompleteDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		
		SSNCardTable ssnCardTable = new SSNCardTable(conn,testCaseId);
		ssnCardTable.storeCompleteDataInExcel(elgId);
	}
	
	@Then("^From SSN CARD Table, Store Hub Request Reponse Data Into Excel folder$")
	public void storeHubRequestReponseDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		SSNCardTable ssnCardTable = new SSNCardTable(conn,testCaseId);
		ssnCardTable.storeHubRequestReponseDataInExcel(elgId);
	}
	
	/**
	 From SSN CARD Table, Validate ElgMemberId Column Value As "" ""
	 */
	@Then("^From SSN CARD Table ElgMemberId Column Value As \"([^\"]*)\" \"([^\"]*)\"$")
	public void from_SSN_CARD_Table_ElgMemberId_Column_Value_As(String expElgMemberId, int memIndex) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		SSNCardTable ssnCardTable = new SSNCardTable(conn,testCaseId);
		
		ssnCardTable.validateElgMemberIdUsingRefId(userProfileRefId, expElgMemberId, memIndex);
	}
	
	/**
	 From SSN CARD Table, Validate IsHavingSNN Column Value As "" ""
	 */
	@Then("^From SSN CARD Table, Validate IsHavingSNN Column Value As \"([^\"]*)\" \"([^\"]*)\"$")
	public void from_SSN_CARD_Table_IsHavingSNN_Column_Value_As(String expIsHavingSSN,int memIndex ) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		SSNCardTable ssnCardTable = new SSNCardTable(conn,testCaseId);
		
		ssnCardTable.validateIsHavingSSNUsingRefId(userProfileRefId, expIsHavingSSN, memIndex);
	}
	
	/**
	 From SSN CARD Table, Validate FirstName Column Value As "" ""
	 */
	@Then("^From SSN CARD Table, Validate FirstName Column Value As \"([^\"]*)\" \"([^\"]*)\"$")
	public void from_SSN_CARD_Table_FirstName_Column_Value_As(String expFirstName ,int memIndex) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		SSNCardTable ssnCardTable = new SSNCardTable(conn,testCaseId);
		
		ssnCardTable.validateFirstNameUsingRefId(userProfileRefId, expFirstName, memIndex);
	}
	
	/**
	 From SSN CARD Table, Validate LastName Column Value As "" ""
	 */
	@Then("^From SSN CARD Table, Validate LastName Column Value As \"([^\"]*)\" \"([^\"]*)\"$")
	public void from_SSN_CARD_Table_LastName_Column_Value_As(String expLastName,int memIndex) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		SSNCardTable ssnCardTable = new SSNCardTable(conn,testCaseId);
		
		ssnCardTable.validateLastNameUsingRefId(userProfileRefId, expLastName, memIndex);
	}
	
	/**
	 From SSN CARD Table, Validate NoSSNExplanation Column Value As "" ""
	 */
	@Then("^From SSN CARD Table, Validate NoSSNExplanation Column Value As \"([^\"]*)\" \"([^\"]*)\"$")
	public void from_SSN_CARD_Table_NoSSNExplanation_Column_Value_As(String expNoSSNExplanation,int memIndex) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		SSNCardTable ssnCardTable = new SSNCardTable(conn,testCaseId);
		
		ssnCardTable.validateNoSSNExplanationUsingRefId(userProfileRefId, expNoSSNExplanation, memIndex);
	    
	}
	
	/**
	 From SSN CARD Table, Validate IsDead Column Value As "" ""
	 */
	@Then("^From SSN CARD Table, Validate IsDead Column Value As \"([^\"]*)\" \"([^\"]*)\"$")
	public void from_SSN_CARD_Table_IsDead_Column_Value_As(String expIsDead,int memIndex) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		SSNCardTable ssnCardTable = new SSNCardTable(conn,testCaseId);
		
		ssnCardTable.validateIsDeadUsingRefId(userProfileRefId, expIsDead, memIndex);
	   
	}
	
	/**
	 From SSN CARD Table, Validate IsDeathVerified Column Value As "" ""
	 */
	@Then("^From SSN CARD Table, Validate IsDeathVerified Column Value As \"([^\"]*)\" \"([^\"]*)\"$")
	public void from_SSN_CARD_Table_IsDeathVerified_Column_Value_As(String expIsDeadVerified,int memIndex) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		SSNCardTable ssnCardTable = new SSNCardTable(conn,testCaseId);
		
		ssnCardTable.validateIsDeadVerifiedUsingRefId(userProfileRefId, expIsDeadVerified, memIndex);
	 
	}
	
	/**
	 From SSN CARD Table, Validate DeathVerificationDate Column Value As "" ""
	 */
	@Then("^From SSN CARD Table, Validate DeathVerificationDate Column Value As \"([^\"]*)\" \"([^\"]*)\"$")
	public void from_SSN_CARD_Table_DeathVerificationDate_Column_Value_As(String expIsDeadVerificationDate,int memIndex) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		SSNCardTable ssnCardTable = new SSNCardTable(conn,testCaseId);
		
		ssnCardTable.validateIsDeadVerificationDateUsingRefId(userProfileRefId, expIsDeadVerificationDate, memIndex);
	   
	}


}
