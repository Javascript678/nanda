package stepdefs.db;

import org.json.JSONObject;
import org.junit.Assert;

import appdata.common.SqlCredentials;
import cucumber.api.java.en.Given;
import db.MedRenewalControlTable;
import db.RenewalElgTrackerTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.HttpsClient;
import utils.TestData;

public class MedRenewalControlTableSteps extends SuperStepDef{


	public MedRenewalControlTableSteps(Hook hook) {
		super(hook);
	}

	/** @author: ppinho
	* 
	* Expected Status:
	*	COMPLETED
	*	ERROR
	*	NOT_PROCESSED
	*	NOT_PROCESSED_999
	*	RESPONSE_NOT_REQRD
	*  
	* From MedRenewalControl Table,Validate Status As "NOT_PROCESSED", For Member "1"
	* 
	*/
	@Given("^From MedRenewalControl Table, Validate Status As \"(.*?)\", For Member \"(.*?)\"$")
	public void validateStatusForMember(String expStatus,String memNo) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		int memIndex = Integer.parseInt(memNo) - 1;
		
		MedRenewalControlTable medRenewalControlTable = new MedRenewalControlTable(conn, testCaseId);
		medRenewalControlTable.validateStatus(userProfileRefId, memIndex, expStatus);
	}
	
	/** @author: ppinho
	* 
	* Expected Status:
	*	COMPLETED
	*	ERROR
	*	NOT_PROCESSED
	*	NOT_PROCESSED_999
	*	RESPONSE_NOT_REQRD
	*  
	* From MedRenewalControl Table, Validate Status As "COMPLETED" For Each Member
	* 
	*/
	@Given("^From MedRenewalControl Table, Validate Status As \"(.*?)\" For Each Member$")
	public void validateStatus(String expStatus) throws Exception {
		MedRenewalControlTable medRenewalControlTable = new MedRenewalControlTable(conn, testCaseId);
		
		for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
			medRenewalControlTable.validateStatus(evpdData.memsData.get(0).userRefId, memIndex, expStatus);
		}		
	}
	
	/** @author: ppinho
	 * 	  
	  From MedRenewalControl Table, Update TDS Call Value For Member "1"
	 * 
	 */
	@Given("^From MedRenewalControl Table, Update TDS Call Value For Member \"(.*?)\"$")
	public void updateReponseXML_reportedWages(String memNo) throws Exception {
		MedRenewalControlTable medRenewalControlTable = new MedRenewalControlTable(conn, testCaseId);
		
		for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
			medRenewalControlTable.updateMedRenewalTdsCallValue(evpdData.memsData.get(0).userRefId, memIndex);
		}
	}
	
}
