package stepdefs.db;

import cucumber.api.java.en.Then;
import db.DataSourceRequestLogTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class DataSourceRequestLogTableSteps extends SuperStepDef {
	/**
	 * 
	 * @author Vimal
	 *	Step Def for Interaction with DataSourceRequestLog Table
	 **/
	public DataSourceRequestLogTableSteps(Hook hook) {
		super(hook);
		
		
	}
	//Vimal
	@Then("^From Data Source Request Log Table, Store Completed Data into Excel folder$")
	public void storeCompleteDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		DataSourceRequestLogTable dataSourceRequestLogTable = new DataSourceRequestLogTable(conn,testCaseId);
		dataSourceRequestLogTable.storeCompleteDataInExcel(elgId);
	}
	//Vimal
	@Then("^From Data Source Request Log Table, Store Hub Request Reponse Data into Excel folder$")
	public void storeHubRequestReponseDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		DataSourceRequestLogTable dataSourceRequestLogTable = new DataSourceRequestLogTable(conn,testCaseId);
		dataSourceRequestLogTable.storeHubRequestReponseDataInExcel(elgId);
	}
	
	/**@author Vimal
	 From Data Source Request Log Table, Validate Status Column Value As ""
	 */
	@Then("^From Data Source Request Log Table, Validate Status Column Value As \"(.*?)\"$")
	public void from_Data_Source_Request_Log_Table_Status_Column_Value_As(String expStatus) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		DataSourceRequestLogTable DataSourceRequestLogTable1 = new DataSourceRequestLogTable(conn, testCaseId);
		DataSourceRequestLogTable1.validateStatusUsingRefId(userProfileRefId, expStatus);
	}
	
	/**@author Vimal
	 From Data Source Request Log Table, Validate Type Column Value As ""
	 */
	@Then("^From Data Source Request Log Table, Validate Type Column Value As \"(.*?)\"$")
	public void from_Data_Source_Request_Log_Table_Type_Column_Value_As(String expType) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		DataSourceRequestLogTable DataSourceRequestLogTable1 = new DataSourceRequestLogTable(conn, testCaseId);
		DataSourceRequestLogTable1.validateTypeUsingRefId(userProfileRefId, expType);
	}

	/**@author Vimal
	 From Data Source Request Log Table, Validate MemberRerfenceId Column Value As ""
	 */
	@Then("^From Data Source Request Log Table, Validate MemberRerfenceId Column Value As \"(.*?)\"$")
	public void from_Data_Source_Request_Log_Table_MemberRerfenceId_Column_Value_As(String expMemberRerfenceId) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		DataSourceRequestLogTable DataSourceRequestLogTable1 = new DataSourceRequestLogTable(conn, testCaseId);
		DataSourceRequestLogTable1.validateMemberRerfenceIdUsingRefId(userProfileRefId, expMemberRerfenceId);
	}

}
