package stepdefs.db;

import cucumber.api.java.en.Then;
import db.RidpFederalHubResponseTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class RidpFederalHubResponseTableSteps extends SuperStepDef {
	
	/**
	 * 
	 * @author Vimal
	 *	Step Def for Interaction with RIDP Table
	 **/
	public RidpFederalHubResponseTableSteps(Hook hook) {
		super(hook);
		
	}
	
	@Then("^From RIDP Federal Hub Response Table, Store Completed Data into Excel folder$")
	public void storeCompleteDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		RidpFederalHubResponseTable ridpFederalHubResponseTable1 = new RidpFederalHubResponseTable(conn,testCaseId);
		ridpFederalHubResponseTable1.storeCompleteDataInExcel(elgId);
	}
	
	@Then("^From RIDP Federal Hub Response Table, Store Hub Request Reponse Data into Excel folder$")
	public void storeHubRequestReponseDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		RidpFederalHubResponseTable ridpFederalHubResponseTable1 = new RidpFederalHubResponseTable(conn,testCaseId);
		ridpFederalHubResponseTable1.storeHubRequestReponseDataInExcel(elgId);
	}
	
	/**
	   From RIDP Federal Hub Response Table, Validate UserProfile Id Column Value As ""
	 */
	@Then("^From RIDP Federal Hub Response Table, Validate UserProfile Id Column Value As \"([^\"]*)\"$")
	public void from_RIDP_Federal_Hub_Response_Table_UserProfile_Id_Column_Value_As(String expuserProfileId) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		RidpFederalHubResponseTable RidpFederalHubResponseTable1 = new RidpFederalHubResponseTable(conn,testCaseId);
		RidpFederalHubResponseTable1.validateUserProfileIdUsingRefId(userProfileRefId, expuserProfileId);
	   
	}
	
	/**
	   From RIDP Federal Hub Response Table, Validate Service Type Id Column Value As ""
	 */
	@Then("^From RIDP Federal Hub Response Table, Validate Service Type Column Value As \"([^\"]*)\"$")
	public void from_RIDP_Federal_Hub_Response_Table_Service_Type_Column_Value_As(String expserviceType) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		RidpFederalHubResponseTable RidpFederalHubResponseTable1 = new RidpFederalHubResponseTable(conn,testCaseId);
		RidpFederalHubResponseTable1.validateServiceTypeUsingRefId(userProfileRefId, expserviceType);
	}
	
	/**
	   From RIDP Federal Hub Response Table, Validate Response Code Column Value As ""
	 */
	@Then("^From RIDP Federal Hub Response Table, Validate Response Code Column Value As \"([^\"]*)\"$")
	public void from_RIDP_Federal_Hub_Response_Table_Response_Code_Column_Value_As(String expresponseCode) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		RidpFederalHubResponseTable RidpFederalHubResponseTable1 = new RidpFederalHubResponseTable(conn,testCaseId);
		RidpFederalHubResponseTable1.validateResponseCodeUsingRefId(userProfileRefId, expresponseCode);
		
	   
	}

}
