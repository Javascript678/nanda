package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;
import cucumber.api.java.en.Then;
import db.ElgMedicaidNoticeXmlTable;
import db.ElgMemberTable;


public class ElgMedicaidNoticeXmlTableSteps extends SuperStepDef {

	
	
	public ElgMedicaidNoticeXmlTableSteps(Hook hook)  {
		super(hook);
	}
	
	/**@author vkuma212
	 * 	Available Notice_Type :- ADMIN REV
	 							 APPR-STD
	 							 APPR-FA
	 							 APPR-CP
	 							 APPR-CH
								 APPR-CMSP
	 							 APPR-LIM
	 							 APPR-HSN
	 							 APPR TMA
	 							 APPR-PA
	 							 DENY-ALL
	 							 ELRFI01
	 							 EXP LANE CV
	 							 JOBUP
	 							 TERM-PA
	 							 TMA CHG
	 							 START-NOTICE-PDF
	 							 END-NOTICE-PDF
	 							 MIXED-HH-CV
	 							 EXP LANE CV
	 							 CONF-ACC
	 							 VR									#ForVoterRegistration
	 							 VC1-RFI
	 							 VC1N-RFI											
	 							 TERMINATION
	 							 RENEWAL 
	 							 NONRENEWAL
	 							 AUTO-RENEWAL
	 							 NON AUTO-RENEWAL
	 							   
	 * 	Available Status :- APPROVED
	 * 						NOT_APPROVED
	 * 						SUPRESSED
	 * 						MERGE_PDF_COMPLETED
	 * 						HD_GEN_PDF_COMPLETED
	 * Available Language :- ENG, SPA
		
		From ElgMedicaidNoticeXml Table, Using EligId With Variable As "ElgId_NOTICE1_Validation", For Member "1" And Notice Type As "APPR-STD" And Language As "ENG", Validate Status "APPROVED"
	
	**/ 
	@Then("^From ElgMedicaidNoticeXml Table, Using EligId With Variable As \"(.*?)\", For Member \"(.*?)\" And Notice Type As \"(.*?)\" And Language As \"(.*?)\", Validate Status \"(.*?)\"$")
	public void validateStatus(String varibleNameFrElgId, String memNo, String noticeType, String language, String expStatus) throws Throwable {
		int memIndex = Integer.parseInt(memNo)-1;
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memFName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String memLName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		ElgMedicaidNoticeXmlTable elgMedicaidNoticeXmlTable = new ElgMedicaidNoticeXmlTable(conn, testCaseId);
		elgMedicaidNoticeXmlTable.validateStatus(eligibilityId, memFName, memLName, noticeType, language, expStatus);
	}
	
	/**@author ppinho
	 *  
	 * Second variation of above.
	 	
	 	From ElgMedicaidNoticeXml Table, Using EligId With Variable As "ElgId_NOTICE1_Validation", For Member "1" And Notice Type As "APPR-STD" And Language As "ENG", Validate Current Status "SUPRESSED"
	
	 **/ 
	
	@Then("^From ElgMedicaidNoticeXml Table, Using EligId With Variable As \"(.*?)\", For Member \"(.*?)\" And Notice Type As \"(.*?)\" And Language As \"(.*?)\", Validate Current Status \"(.*?)\"$")
	public void validateCurrentStatus(String varibleNameFrElgId, String memNo, String noticeType, String language, String expStatus) throws Throwable {
		int memIndex = Integer.parseInt(memNo)-1;
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memFName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String memLName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		ElgMedicaidNoticeXmlTable elgMedicaidNoticeXmlTable = new ElgMedicaidNoticeXmlTable(conn, testCaseId);
		elgMedicaidNoticeXmlTable.validateCurrentStatus(eligibilityId, memFName, memLName, noticeType, language, expStatus);
	}
	
	/**@author vkuma212
	
	From ElgMedicaidNoticeXml Table, Using EligId With Variable As "ElgId_NOTICE1_Validation", Validate Total NOTICE Count As "5"

 */
	@Then("^From ElgMedicaidNoticeXml Table, Using EligId With Variable As \"(.*?)\", Validate Total NOTICE Count As \"(.*?)\"$")
	public void validateRowCountForElgId(String varibleNameFrElgId, String expCount) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		int intExpCount = Integer.parseInt(expCount);
		
		ElgMedicaidNoticeXmlTable elgMedicaidNoticeXmlTable = new ElgMedicaidNoticeXmlTable(conn, testCaseId);
		elgMedicaidNoticeXmlTable.validateRowCountForElgId(eligibilityId, intExpCount);
	}
	
}
