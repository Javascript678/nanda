package stepdefs.db;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import db.ElgMemberTable;
import db.MMIS_Post_Elg_Control_Data_Table;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class MMIS_Post_Elg_Control_Data_TableSteps extends SuperStepDef
{

	
	public MMIS_Post_Elg_Control_Data_TableSteps(Hook hook) {
		super(hook);
	}
	
	/**
	 * @author Vinay
	 * It works With Eligbility Id Stored In temp Data with variable name provided
	 
	 	From MMIS_Post_Elg_Control_Data_Table, Using EligId With Variable As "ElgId_MMIS1_Validation", For Member "1", Store Request XML
	 	
	 */
	@Given("^From MMIS_Post_Elg_Control_Data_Table, Using EligId With Variable As \"(.*?)\", For Member \"(.*?)\", Store Request XML$") 
	public void storeRequestXMLClob(String varibleNameFrElgId, String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memFName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String memLName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		MMIS_Post_Elg_Control_Data_Table mmisPostElgControlDataTable = new db.MMIS_Post_Elg_Control_Data_Table(conn, testCaseId);
		String reqXmlLink = mmisPostElgControlDataTable.storeRequestXMLClob(eligibilityId, memFName, memLName);
		storeTempTestData("CurrentXML_Link", reqXmlLink);
		
	}
	
	/**@author akumari4
	 * 
	 
	 From MMIS_Post_Elg_Control_Data_Table, Using EligId With Variable As "ElgId_MMIS1_Validation",Validate Total MMIS Row Count As "4"
	 
	 */
	@Then("^From MMIS_Post_Elg_Control_Data_Table, Using EligId With Variable As \"(.*?)\",Validate Total MMIS Row Count As \"(.*?)\"$")
	public void validateRowCountForElgId(String varibleNameFrElgId, String expCount) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		int intExpCount = Integer.parseInt(expCount);
		
		MMIS_Post_Elg_Control_Data_Table mmisPostElgControlDataTable = new db.MMIS_Post_Elg_Control_Data_Table(conn, testCaseId);
		mmisPostElgControlDataTable.validateRowCountForElgId(eligibilityId, intExpCount);
	}
	
	/**@author akumari4
	 * 
		From MMIS_Post_Elg_Control_Data_Table,Using EligId With Variable As "ElgId_MMIS1_Validation",For Member "1",Validate Total MMIS Row Count As "2"
		
	
	 */
	@Then("^From MMIS_Post_Elg_Control_Data_Table,Using EligId With Variable As \"(.*?)\",For Member \"(.*?)\",Validate Total MMIS Row Count As \"(.*?)\"$") 
	public void validateRowCountForMember(String varibleNameFrElgId, String memNo, String expCount) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		int intExpCount = Integer.parseInt(expCount);
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memFName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String memLName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		MMIS_Post_Elg_Control_Data_Table mmisPostElgControlDataTable = new db.MMIS_Post_Elg_Control_Data_Table(conn, testCaseId);
		mmisPostElgControlDataTable.validateRowCountForMember(eligibilityId, memFName, memLName, intExpCount);
		
	}
	

	/**
	 * @author Vinay
	 * It works With Eligbility Id Stored In temp Data with variable name provided
	 * Accepted Value for status :- 	WS_CALL_PROCESSED,
	 * 									WS_CALL_IN_PROGRESS
	  
	 	From MMIS_Post_Elg_Control_Data_Table, Using EligId With Variable As "ElgId_MMIS1_Validation", For Member "1", Validate Current Status As "WS_CALL_PROCESSED"
	 	
	 */
	@Given("^From MMIS_Post_Elg_Control_Data_Table, Using EligId With Variable As \"(.*?)\", For Member \"(.*?)\", Validate Current Status As \"(.*?)\"$") 
	public void validateCurrentStatusFieldValue(String varibleNameFrElgId, String memNo, String status) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memFName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String memLName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		MMIS_Post_Elg_Control_Data_Table mmisPostElgControlDataTable = new db.MMIS_Post_Elg_Control_Data_Table(conn, testCaseId);
		mmisPostElgControlDataTable.validateCurrentStatusFieldValue(eligibilityId, memFName, memLName, status);
		
	}
	
	/**
	 * @author Shailza
	 * It works With Eligbility Id Stored In temp Data with variable name provided
	 * Accepted Value for Medicaid Status :- 	NEW,
	 * 											CHANGED,
	 * 											CLOSED
	  
	 	From MMIS_Post_Elg_Control_Data_Table, Using EligId With Variable As "ElgId_MMIS1_Validation", For Member "1", Validate Medicaid Status As "NEW"
	 	
	 */
	@Given("^From MMIS_Post_Elg_Control_Data_Table, Using EligId With Variable As \"(.*?)\", For Member \"(.*?)\", Validate Medicaid Status As \"(.*?)\"$") 
	public void validateMedicaidStatusFieldValue(String varibleNameFrElgId, String memNo, String status) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memFName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String memLName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		MMIS_Post_Elg_Control_Data_Table mmisPostElgControlDataTable = new db.MMIS_Post_Elg_Control_Data_Table(conn, testCaseId);
		mmisPostElgControlDataTable.validateMedicaidStatusFieldValue(eligibilityId, memFName, memLName, status);
		
	}
	
}
