package stepdefs.db;

import cucumber.api.java.en.Given;
import db.ElgMemberDocumentTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class ElgMemDocTableSteps extends SuperStepDef
{

	
	public ElgMemDocTableSteps(Hook hook) {
		super(hook);
	}
	
	/*
	 * @Ritu  
	 * 
	 * From ElgMemDocTable, Expire Citizenship RFIs Time Clock For All Member
	 * 
	*/
	//Ritu
	@Given("^From ElgMemDocTable, Expire Citizenship RFIs Time Clock For All Member$")
	public void expireCitizenshipRFIsForAllMember() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDates(userProfileRefId, "proofOfCitizenship", newDueDate);
		
	}
	
	/*
	 * @Ritu
	 * 
	 * From ElgMemDocTable, Expire Income RFIs Time Clock For All Member
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire Income RFIs Time Clock For All Member$")
	public void expireIncomeRFIsForAllMember() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDates(userProfileRefId, "proofOfIncome", newDueDate);
		
	}  
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire SSN RFIs Time Clock For All Member
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire SSN RFIs Time Clock For All Member$")
	public void expireSSNRFIsForAllMember() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDates(userProfileRefId, "proofOfSSN", newDueDate);
		
	}
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire Residency RFIs Time Clock For All Member
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire Residency RFIs Time Clock For All Member$")
	public void expireResidencyRFIsForAllMember() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDates(userProfileRefId, "proofOfResidency", newDueDate);
		
	}
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire Immigration RFIs Time Clock For All Member
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire Immigration RFIs Time Clock For All Member$")
	public void expireImmigrationRFIsForAllMember() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDates(userProfileRefId, "proofOfImmigration", newDueDate);
		
	}
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire Incarceration RFIs Time Clock For All Member
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire Incarceration RFIs Time Clock For All Member$")
	public void expireIncarcerationRFIsForAllMember() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDates(userProfileRefId, "proofOfIncarceration", newDueDate);
		
	} 
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire TribalMembership RFIs Time Clock For All Member
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire TribalMembership RFIs Time Clock For All Member$")
	public void expireTribalMembershipRFIsForAllMember() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDates(userProfileRefId, "proofOfTribalMembership", newDueDate);
		
	}  
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire NCP RFIs Time Clock For All Member
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire NCP RFIs Time Clock For All Member$")
	public void expireNCPRFIsForAllMember() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDates(userProfileRefId, "proofOfNCP", newDueDate);
		
	} 
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire Incarceration RFIs Time Clock For One Member Using MemberNumber"2"
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire Incarceration RFIs Time Clock For One Member Using MemberNumber\"(.*?)\"$") 
	public void expireIncarcerationRFIsForOneMember(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = evpdData.memsData.get(0).userRefId.toString();
		String appDate = evpdData.memsData.get(0).appCreateDate.toString();
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDate(userProfileRefId,memIndex, "proofOfIncarceration", newDueDate);
		
	}
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire Income RFIs Time Clock For One Member Using MemberNumber"2"
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire Income RFIs Time Clock For One Member Using MemberNumber\"(.*?)\"$") 
	public void expireIncomeRFIsForOneMember(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDate(userProfileRefId,memIndex, "proofOfIncome", newDueDate);
		
	}
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire NCP RFIs Time Clock For One Member Using MemberNumber"2"
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire NCP RFIs Time Clock For One Member Using MemberNumber\"(.*?)\"$") 
	public void expireNCPRFIsForOneMember(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDate(userProfileRefId,memIndex, "proofOfNCP", newDueDate);
		
	}
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire Citizenship RFIs Time Clock For One Member Using MemberNumber"2"
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire Citizenship RFIs Time Clock For One Member Using MemberNumber\"(.*?)\"$") 
	public void expireCitizenshipRFIsForOneMember(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDate(userProfileRefId,memIndex, "proofOfCitizenship", newDueDate);
		
	}
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire SSN RFIs Time Clock For One Member Using MemberNumber"2"
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire SSN RFIs Time Clock For One Member Using MemberNumber\"(.*?)\"$") 
	public void expireSSNRFIsForOneMember(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDate(userProfileRefId,memIndex, "proofOfSSN", newDueDate);
		
	}
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire Residency RFIs Time Clock For One Member Using MemberNumber"2"
	 * 
	 * */
	
	@Given("^From ElgMemDocTable, Expire Residency RFIs Time Clock For One Member Using MemberNumber\"(.*?)\"$") 
	public void expireResidencyRFIsForOneMember(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDate(userProfileRefId,memIndex, "proofOfResidency", newDueDate);
		
	}
	
	/*@Ritu
	 * 
	 * From ElgMemDocTable,Expire Immigration RFIs Time Clock For One Member Using MemberNumber"2"
	 * 
	 * */
	@Given("^From ElgMemDocTable,Expire Immigration RFIs Time Clock For One Member Using MemberNumber\"(.*?)\"$") 
	public void expireImmigrationRFIsForOneMember(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDate(userProfileRefId,memIndex, "proofOfImmigration", newDueDate);
		
	} 

	/*@Ritu
	 * 
	 * From ElgMemDocTable, Expire TribalMembership RFIs Time Clock For One Member Using MemberNumber"2"
	 * 
	 * */
	@Given("^From ElgMemDocTable, Expire TribalMembership RFIs Time Clock For One Member Using MemberNumber\"(.*?)\"$") 
	public void expireTribalMembershipRFIsForOneMember(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:90");
		
		ElgMemberDocumentTable elgMemberDocumentTable = new ElgMemberDocumentTable(conn, testCaseId);
		elgMemberDocumentTable.updateDueDate(userProfileRefId,memIndex, "proofOfTribalMembership", newDueDate);
		
	} 
	
}
