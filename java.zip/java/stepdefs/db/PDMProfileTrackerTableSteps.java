package stepdefs.db;

import cucumber.api.java.en.Given;
import db.PDMProfileTrackerTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class PDMProfileTrackerTableSteps extends SuperStepDef
{


	public PDMProfileTrackerTableSteps(Hook hook) {
		super(hook);
	}

	/*
	 * @Ritika 
	 * 
	 * Expected Status :-
		BY_PASSED_ALL_MEMBER
		BY_PASS_ALL_CCA_NO_ACTIVE_ENROLLMENT
		BY_PASS_HOH_DECEASED
		BY_PASS_IN_PROGRESS_APP_EXIST
		BY_PASS_MASS_HEALTH_AGE_FACTOR
		BY_PASS_OE_LOCK_RAC
		BY_PASS_OE_PROTECTION_END_DATE
		BY_PASS_PENDING_RFI_TIME_CLOCK
		BY_PASS_RENEWAL_INITIATED
		NOT_PROCESSED_HOLD
		NOT_PROCESSED_ON_HOLD
		NOT_PROCESS_HOLD
		PDM_COMP_DONE
		PDM_COMP_ERROR
		PDM_DONE
		PDM_ELIGIBILITY_IDENTIFICATION_ERROR
		PDM_PROCESS_BO_STOPPED
		PDM_PROCESS_STOPPED
		PDM_STOPPED_HOH_DEAD
		RENEWAL_INITIATED
		RRV_REQ_INITIATED


	  From PDMProfileTracker Table,Validate Status As "PDM_DONE"
	 * 
	 */
	//Ritika
	@Given("^From PDMProfileTracker Table,Validate Status As \"(.*?)\"$")
	public void validateStatus(String expStatus) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);

		PDMProfileTrackerTable pdmProfileTracker = new PDMProfileTrackerTable(conn, testCaseId);
		pdmProfileTracker.validateStatus(userProfileRefId, expStatus);

	}
	
	
	/*
	 * @Ritika 
	 * 
	  From PDMProfileTracker Table,Store New EligibilityID
	 * 
	 */
	//Ritika
	@Given("^From PDMProfileTracker Table,Store New EligibilityID$")
	public void getNewElgId() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);

		PDMProfileTrackerTable pdmProfileTracker = new PDMProfileTrackerTable(conn, testCaseId);
		String elgId = pdmProfileTracker.getNewElgId(userProfileRefId);
		storeTempTestData("CurrentEligibilityId", elgId);

	}
	
	/*
     * @Aashita 
      * 
       From PDMProfileTracker Table,Hold the Ids for the Eligibility ID
     * 
      */
	@Given("^From PDMProfileTracker Table,Hold the Ids for the Eligibility ID$")
     public void setPDMStatustoHold() throws Exception {
           String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
           PDMProfileTrackerTable pdmProfileTracker = new PDMProfileTrackerTable(conn, testCaseId);
         pdmProfileTracker.setPDMStatustoHold(userProfileRefId);
}
     
     /*
     * @Aashita 
      * 
       From PDMProfileTracker Table,UnHold the Ids for the Eligibility ID
     * 
      */
     @Given("^From PDMProfileTracker Table,UnHold the Ids for the Eligibility ID$")
     public void setPDMStatustoUnHold() throws Exception {
           String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
           PDMProfileTrackerTable pdmProfileTracker = new PDMProfileTrackerTable(conn, testCaseId);
         pdmProfileTracker.setPDMStatustoUnHold(userProfileRefId);
}

}
