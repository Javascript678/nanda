package stepdefs.db;

import org.json.JSONObject;
import org.junit.Assert;

import appdata.common.SqlCredentials;
import cucumber.api.java.en.Given;
import db.MedRenewalControlTable;
import db.MedRenewalPrelimControlTable;
import db.RenewalElgTrackerTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.HttpsClient;
import utils.TestData;

public class MedRenewalPrelimControlTableSteps extends SuperStepDef{


	public MedRenewalPrelimControlTableSteps(Hook hook) {
		super(hook);
	}

	/** @author: ppinho
	* 
	* Expected Status:
	*	COMPLETED
	*  
	* From MedRenewalPrelimControl Table, Validate Status As "COMPLETED"
	* 
	*/
	@Given("^From MedRenewalPrelimControl Table, Validate Status As \"(.*?)\"$")
	public void validateStatusForMember(String expStatus) throws Exception {
		MedRenewalPrelimControlTable medRenewalPrelimControlTable = new MedRenewalPrelimControlTable(conn, testCaseId);
		medRenewalPrelimControlTable.validateStatus(evpdData.memsData.get(0).userRefId, expStatus);
	}
	
}
