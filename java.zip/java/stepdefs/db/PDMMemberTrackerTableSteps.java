package stepdefs.db;

import cucumber.api.java.en.Given;
import db.PDMMemberTrackerTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class PDMMemberTrackerTableSteps extends SuperStepDef
{


	public PDMMemberTrackerTableSteps(Hook hook) {
		super(hook);
	}

	/*
	 * @Ritika 
	 * 
	  From PDMMemberTracker Table,Validate Status As "READY",For Member As "1"
	 * 
	 */
	//Ritika
	@Given("^From PDMMemberTracker Table,Validate Status As \"(.*?)\",For Member As \"(.*?)\"$")
	public void validateStatus(String expStatus,int memNo) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		int memIndex = memNo - 1;
		PDMMemberTrackerTable pdmMemberTracker = new PDMMemberTrackerTable(conn, testCaseId);
		pdmMemberTracker.validateMemberStatus(userProfileRefId, memIndex, expStatus);

	}
	
	
	
}
