package stepdefs.db;

import cucumber.api.java.en.Given;
import db.PA_AIDRateMappingTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class PAAidRateMappingTableSteps extends SuperStepDef
{

	
	public PAAidRateMappingTableSteps(Hook hook) {
		super(hook);
	}
	
	

	/*@Ritu
	 * 
	 
	 For Invalid Value
	 		From PA_Mapping table, Update PA Aid Cat value as "D42" Where Non PA Aid_Cat Value As "D1"
	
	 For Reverting Value to Original One 
	 	From PA_Mapping table, Update PA Aid Cat value as "D4" Where Non PA Aid_Cat Value As "D1"
	  
	 * */
	@Given("^From PA_Mapping table, Update PA Aid Cat value as \"(.*?)\" Where Non PA Aid_Cat Value As \"(.*?)\"$") 
	public void expireTribalMembershipRFIsForOneMember(String paAidCat ,String nonPaAidCat) throws Exception {
		
		PA_AIDRateMappingTable  paAIDRateMappingTable = new PA_AIDRateMappingTable(conn, testCaseId);
		paAIDRateMappingTable.updatePAAidCat(nonPaAidCat,paAidCat);
		
	} 
	
}
