package stepdefs.db;
import cucumber.api.java.en.Given;
import db.ExchangeConfigAttributeTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ExchangeConfigAttributeTableSteps extends SuperStepDef
{

	
	public ExchangeConfigAttributeTableSteps(Hook hook) {
		super(hook);
	}
	
	/**@author vkuma212
	 
	 From ExchangeConfigAttributeTable, Validate MH Pending ByPass Status As "TRUE"
	 
	 */
	@Given("^From ExchangeConfigAttributeTable, Validate MH Pending ByPass Status As \"(.*?)\"$")
	public void validateMHPendingByPassStatus(String expMHPendByPassStatus) throws Exception {
		ExchangeConfigAttributeTable exchangeConfigAttributeTable = new ExchangeConfigAttributeTable(conn, testCaseId);
		exchangeConfigAttributeTable.validateMHPendingByPassStatus(expMHPendByPassStatus);
	}
	
	/**@author ppinho
	 
	 From ExchangeConfigAttributeTable, Update MH Pending ByPass Status As "TRUE"
	 Note : After this Action , Server Bounce Is required
		 
	 */
	@Given("^From ExchangeConfigAttributeTable, Update MH Pending ByPass Status As \"(.*?)\"$")
	public void updateVHCAndHCRuleActionAsBockForId(String ruleAction) throws Exception {		
		ExchangeConfigAttributeTable exchangeConfigAttributeTable = new ExchangeConfigAttributeTable(conn, testCaseId);
		exchangeConfigAttributeTable.updateMHPendingByPass(ruleAction);
	}

	
	
}
