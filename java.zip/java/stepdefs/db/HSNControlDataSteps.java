package stepdefs.db;

import cucumber.api.java.en.Given;
import db.HSNControlDataTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class HSNControlDataSteps extends SuperStepDef
{

	
	public HSNControlDataSteps(Hook hook) {
		super(hook);
	}
	
	/*
	 * @Ritika 
	 * 
	 * From HSNControlData Table, update Status As "ACTIVE", Start Date As "40", End Date As "20"
	 * 
	*/
	//Ritika
	@Given("^From HSNControlData Table, update Status As \"(.*?)\", Start Date As \"(.*?)\", End Date As \"(.*?)\"$")
	public void expireCitizenshipRFIsForAllMember(String status,String startDate,String endDate) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newStartDate = DateUtil.getPriorDateInDBUpdateFormat1UsingPattern(appDate, DateUtil.UIDatePattern, "00:00:"+startDate);
		String newEndDate = DateUtil.getPriorDateInDBUpdateFormat1UsingPattern(appDate, DateUtil.UIDatePattern, "00:00:"+endDate);
		
		HSNControlDataTable hsnControlDataTable = new HSNControlDataTable(conn, testCaseId);
		hsnControlDataTable.updateStatus(userProfileRefId, status);
		hsnControlDataTable.updateStartDate(userProfileRefId, newStartDate);
		hsnControlDataTable.updateEndDate(userProfileRefId, newEndDate);
		}
	
}
