package stepdefs.db;

import cucumber.api.java.en.Given;
import db.EligibilityTable;
import db.PaTimeClockTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class PaTimeClockTableSteps extends SuperStepDef {

	public PaTimeClockTableSteps(Hook hook) {
		super(hook);
	}

	/**
	 * Ritu
	 
	 From PaTimeClockTable, Update Create, Expiry, Start Date For Member "1"
	 
	 */
	@Given("^From PaTimeClockTable, Update Create, Expiry, Start Date For Member \"(.*?)\"$")
	public void storeElgIdForMMIS1(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		
		
		String  expirationDateValue = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+10);
		String createdDateValue = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+15);
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		PaTimeClockTable paTimeClockTable = new PaTimeClockTable(conn, testCaseId);
		String startDateValue = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+15);;
		
		
		String submissionDate =DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+15);;
		String determinationDate =DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+15);;
		paTimeClockTable.updateStartCreatedExpirationDateUsingUserProfileRefId(userProfileRefId, 
				memIndex, startDateValue, createdDateValue, expirationDateValue);
		
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		eligibilityTable.updateDeterminationAndSubmissionDate(userProfileRefId,submissionDate,determinationDate);
	}
	
}
