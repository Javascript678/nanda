package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;
import cucumber.api.java.en.Given;
import db.EnrlPlanTable;
import db.EnrollmentTable;

public class EnrlPlanTableSteps  extends SuperStepDef {

	
	
	public EnrlPlanTableSteps(Hook hook){
		super(hook);
	}
	
	//Ritu
	//From EnrlPlan Table, Update Enrollment Status Value As Active
	@Given("^From EnrlPlan Table, Update Enrollment Status Value As Active")
	public void planEffectuationSetStatusAsActive() throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String newStatusValue ="ACTIVE";
		String enrollStatusValue="ENROLLED";
		EnrollmentTable enrollmentTable = new EnrollmentTable(conn, testCaseId);
		enrollmentTable.updateStatus(userProfileRefId, newStatusValue); 
		EnrlPlanTable enrlPlanTable = new EnrlPlanTable(conn, testCaseId);
		enrlPlanTable.updateEnrollmentStatus(userProfileRefId, enrollStatusValue, newStatusValue);
		
	}
	
	/**
		From EnrlPlan Table, Update Enrollment Status Value As "Active" When Enrollment Status is set As "ENROLLED"
		
	 * Aashita
	 */
    
    @Given("^From EnrlPlan Table, Update Enrollment Status Value As \"(.*?)\" When Enrollment Status is set As \"(.*?)\"$")
    public void planEffectuationSetStatus(String statusToSet, String enrollStatusVal) throws Exception {
          String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
          EnrollmentTable enrollmentTable = new EnrollmentTable(conn, testCaseId);
          enrollmentTable.updateStatus(userProfileRefId, statusToSet); 
          EnrlPlanTable enrlPlanTable = new EnrlPlanTable(conn, testCaseId);
          enrlPlanTable.updateEnrollmentStatus(userProfileRefId, enrollStatusVal, statusToSet);          
    }

	
}
