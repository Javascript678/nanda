package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import cucumber.api.java.en.Then;
import db.MaHubRequestResponseTable;
import db.SsaMonthlyIncomeInfoTable;


public class SsaMonthlyIncomeInfoSteps extends SuperStepDef {

	public SsaMonthlyIncomeInfoSteps(Hook hook)  {
		super(hook);
	}
	
	// ppinho
	@Then("^From SsaMonthlyIncomeInfo Table, Update Title II Income For Each Member$")
	public void updateTitleIiIncomeForEachMember() throws Throwable {
		SsaMonthlyIncomeInfoTable ssaMonthlyIncomeInfoHistoryTable = new SsaMonthlyIncomeInfoTable(conn, testCaseId);
		MaHubRequestResponseTable maHubRequestResponseTable = new MaHubRequestResponseTable(conn, testCaseId);
		
		String userRefId = evpdData.memsData.get(0).userRefId;
				
		for(int memInd = 0; memInd < evpdData.memCount; memInd++){
			if(initialPrelimData.memsData.get(memInd).hasTitleIiIncome){
				if(initialPrelimData.memsData.get(memInd).rrvSsaTitleIiIncome.contains("ERROR")){
					String[] error = initialPrelimData.memsData.get(memInd).rrvSsaTitleIiIncome.split(":");				
					ssaMonthlyIncomeInfoHistoryTable.ccaRenewalMonthlyIncomeAmtNullUpdateQuery(userRefId, memInd);
					maHubRequestResponseTable.ccaRenewalSsaErrorUpdateQuery(userRefId, memInd, error[1]);
				}else{
					ssaMonthlyIncomeInfoHistoryTable.ccaRenewalMonthlyIncomeAmtUpdateQuery(userRefId, memInd, initialPrelimData.memsData.get(memInd).rrvSsaTitleIiIncome);
				}
			}
		}		
	}
}
