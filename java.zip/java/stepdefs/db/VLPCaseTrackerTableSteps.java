package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;
import cucumber.api.java.en.Then;
import db.VlpCaseTrackerTable;

/**
 * @author Vinay
 **/
public class VLPCaseTrackerTableSteps extends SuperStepDef {


	
	public VLPCaseTrackerTableSteps(Hook hook)  {
		super(hook);
	}
	
	/**Vinay
	 * 
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "1", Validate CaseStatus Column Value AS "RESOLVED"
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "2", Validate CaseStatus Column Value AS "OPEN"
	 
	 */
	@Then("^From VLP Table, For Eligibility With Variable Name As \"(.*?)\", For Member \"(.*?)\", Validate CaseStatus Column Value AS \"(.*?)\"$")
	public void validateCaseStatus(String varibleForElgId, String memNo, String expCaseStatus ) throws Exception {
		String elgId = TestData.getTempTestData(varibleForElgId, featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateCaseStatus(elgId, memIndex, expCaseStatus);
		
	}
	
	/**Vinay
	 * 
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "1", Validate Five Year Bar Applies Column Value AS "N"
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "2", Validate Five Year Bar Applies Column Value AS "Y"
	 
	 */
	@Then("^From VLP Table, For Eligibility With Variable Name As \"(.*?)\", For Member \"(.*?)\", Validate Five Year Bar Applies Column Value AS \"(.*?)\"$")
	public void validateFiveYearBarApplies(String varibleForElgId, String memNo, String expFiveYearBarApplies ) throws Exception {
		String elgId = TestData.getTempTestData(varibleForElgId, featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateFiveYearBarApplies(elgId, memIndex, expFiveYearBarApplies);
		
	}
	
	/**Vinay
	 * 
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "1", Validate Five Year Bar Met Code Column Value AS "N"
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "2", Validate Five Year Bar Met Code Column Value AS "Y"
	 
	 */
	@Then("^From VLP Table, For Eligibility With Variable Name As \"(.*?)\", For Member \"(.*?)\", Validate Five Year Bar Met Code Column Value AS \"(.*?)\"$")
	public void validateFiveYearBarMetCode(String varibleForElgId, String memNo, String expFiveYearBarMetCode ) throws Exception {
		String elgId = TestData.getTempTestData(varibleForElgId, featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateFiveYearBarMetCode(elgId, memIndex, expFiveYearBarMetCode);
		
	}
	
	/**Vinay
	 * 
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "1", Validate Lawful Presence Verified Code Column Value AS "N"
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "2", Validate Lawful Presence Verified Code Column Value AS "Y"
	 
	 */
	@Then("^From VLP Table, For Eligibility With Variable Name As \"(.*?)\", For Member \"(.*?)\", Validate Lawful Presence Verified Code Column Value AS \"(.*?)\"$")
	public void validateLawfulPresVerifiedCode(String varibleForElgId, String memNo, String expLawfulPresVerifiedCode ) throws Exception {
		String elgId = TestData.getTempTestData(varibleForElgId, featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateLawfulPresVerifiedCode(elgId, memIndex, expLawfulPresVerifiedCode);
		
	}
	
	/**Vinay
	 * 
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "1", Validate QualifiedNonCitznCode Column Value AS "N"
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "2", Validate QualifiedNonCitznCode Column Value AS "Y"
	 
	 */
	@Then("^From VLP Table, For Eligibility With Variable Name As \"(.*?)\", For Member \"(.*?)\", Validate QualifiedNonCitznCode Column Value AS \"(.*?)\"$")
	public void validateQualifiedNonCitznCode(String varibleForElgId, String memNo, String expLawfulPresVerifiedCode ) throws Exception {
		String elgId = TestData.getTempTestData(varibleForElgId, featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateQualifiedNonCitznCode(elgId, memIndex, expLawfulPresVerifiedCode);
		
	}
	
	/**Vinay
	 * 
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "1", Validate ElgStatementCode Column Value AS "251"
	 
	 */
	@Then("^From VLP Table, For Eligibility With Variable Name As \"(.*?)\", For Member \"(.*?)\", Validate ElgStatementCode Column Value AS \"(.*?)\"$")
	public void validateElgStatementCode(String varibleForElgId, String memNo, String expElgStatementCode ) throws Exception {
		String elgId = TestData.getTempTestData(varibleForElgId, featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateElgStatementCode(elgId, memIndex, expElgStatementCode);
		
	}
	
	/**Vinay
	 * 
	 From VLP Table, For Eligibility With Variable Name As "ElgId_VLP1_Validation", For Member "1", Validate AgencyAction Column Value AS "INVOKE_CLOSE_CASE"
	 
	 */
	@Then("^From VLP Table, For Eligibility With Variable Name As \"(.*?)\", For Member \"(.*?)\", Validate AgencyAction Column Value AS \"(.*?)\"$")
	public void validateAgencyAction(String varibleForElgId, String memNo, String expAgencyAction ) throws Exception {
		String elgId = TestData.getTempTestData(varibleForElgId, featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateAgencyAction(elgId, memIndex, expAgencyAction);
		
	}
	
	@Then("^From VLP Case Tracker Table, Store Completed Data Into Excel folder$")
	public void storeCompleteDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		VlpCaseTrackerTable VlpCASeTrackerTable1 =new VlpCaseTrackerTable(conn, testCaseId);
		VlpCASeTrackerTable1.storeCompleteDataInExcel(elgId);
	}
	
	@Then("^From VLP Case Tracker Table, Store Hub Request Reponse Data Into Excel folder$")
	public void storeHubRequestReponseDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		VlpCaseTrackerTable VlpCASeTrackerTable1 =new VlpCaseTrackerTable(conn, testCaseId);
		VlpCASeTrackerTable1.storeHubRequestReponseDataInExcel(elgId);
	}

	/**
	 From VLP Table, Validate CaseNumber Column Value AS "1099179078452CR"
	 */
	@Then("^From VLP Table, Validate CASeNumber Column Value AS \"(.*?)\"$")
	public void From_VLP_Table_CaseNumber_Column_Value_AS(String expCASeNumber) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateCaseNumberUsingRefId(userProfileRefId, expCASeNumber);
	}
	
	/**
	 From VLP Table, Validate CASeType Column Value AS "2"
	 */
	@Then("^From VLP Table, Validate CASeType Column Value AS \"(.*?)\"$")
	public void From_VLP_Table_CaseType_Column_Value_AS(String expCASeType) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateCaseTypeUsingRefId(userProfileRefId, expCASeType);
	}
	
	/**
	 From VLP Table, Validate CASeStatus Column Value AS "OPEN"
	 */
	@Then("^From VLP Table, Validate CASeStatus Column Value AS \"(.*?)\"$")
	public void From_VLP_Table_CaseStatus_Column_Value_AS(String expCASeStatus) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateCaseStatusUsingRefId(userProfileRefId, expCASeStatus);
	}
	
	/**
	 From VLP Table, Validate FirstName Column Value AS "MEMgxjev"
	 */
	@Then("^From VLP Table, Validate FirstName Column Value AS \"(.*?)\"$")
	public void From_VLP_Table_FirstName_Column_Value_AS(String expFirstName) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateFirstNameUsingRefId(userProfileRefId, expFirstName);
	}
	
	/**
	 From VLP Table, Validate MiddleName Column Value AS "hlxuf"
	 */
	@Then("^From VLP Table, Validate MiddleName Column Value AS \"(.*?)\"$")
	public void From_VLP_Table_MiddleName_Column_Value_AS(String expMiddleName) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateMiddleNameUsingRefId(userProfileRefId, expMiddleName);
	}
	
	/**
	 From VLP Table, Validate LAStName Column Value AS "ONEnsnidEBK"
	 */
	@Then("^From VLP Table, Validate LAStName Column Value AS \"(.*?)\"$")
	public void From_VLP_Table_LAStName_Column_Value_AS(String expLAStName) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateLastNameUsingRefId(userProfileRefId, expLAStName);
	}
	
	/**
	 From VLP Table, Validate MemberRerfenceId Column Value AS "300001838494"
	 */
	@Then("^From VLP Table, Validate MemberRerfenceId Column Value AS \"(.*?)\"$")
	public void From_VLP_Table_MemberRerfenceId_Column_Value_AS(String expMemberRerfenceId) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		VlpCaseTrackerTable vlpCASeTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCASeTrackerTable.validateMemberRerfenceIdUsingRefId(userProfileRefId, expMemberRerfenceId);
	}
	
	/**
	 From VLP Table, Validate FiveYearBarMetCode Column Value AS ""
	 */
	@Then("^From VLP Table, Validate FiveYearBarMetCode Column Value AS \"(.*?)\"$")
	public void From_VLP_Table_FiveYearBarMetCode_Column_Value_AS(String expFiveYearBarMetCode) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		VlpCaseTrackerTable vlpCaseTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCaseTrackerTable.validateFiveYearBarMetCodeUsingRefId(userProfileRefId, expFiveYearBarMetCode);
	}
	
	/**
	 From VLP Table, Validate GrantDate Column Value AS "1967-28-01 00:00:00 00"
	 */
	@Then("^From VLP Table, Validate GrantDate Column Value AS \"(.*?)\"$")
	public void From_VLP_Table_GrantDate_Column_Value_AS(String expGrantDate) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		VlpCaseTrackerTable vlpCaseTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCaseTrackerTable.validateGrantDateUsingRefId(userProfileRefId, expGrantDate);
	}
    
	/**
	 From VLP Table, Validate AttestedLpStatusVerify Column Value AS "ILP"
	 */
	@Then("^From VLP Table, Validate AttestedLpStatusVerify Column Value AS \"(.*?)\"$")
	public void From_VLP_Table_AttestedLpStatusVerify_Column_Value_AS(String expAttestedLpStatus) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		VlpCaseTrackerTable vlpCaseTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
		vlpCaseTrackerTable.validateAttestedLpStatusUsingRefId(userProfileRefId, expAttestedLpStatus);
	}
	
	
	
	
}
