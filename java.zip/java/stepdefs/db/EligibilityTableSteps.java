package stepdefs.db;

import cucumber.api.java.en.Given;
import db.EligibilityTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class EligibilityTableSteps extends SuperStepDef {

	public EligibilityTableSteps(Hook hook) {
		super(hook);
	}

	/**Vinay 
	
	From EligibilityTable, Store Latest Eligibility Id In Variable "ElgId_NOTICE_Validation"
	 */
	@Given("^From ElgEmberTable, Store Latest Eligibility Id In Variable \"(.*?)\"$")
	public void updateDobForMember(String elgIdVariableName) throws Exception {
	
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		storeTempTestData(elgIdVariableName, elgId);
	}
	
	/**Aashita 
    
    From EligibilityTable, Set Determination Date As "01-NOV-18" and Submission Date As "01-NOV-18"
    */
    @Given("^From EligibilityTable, Set Determination Date As \"(.*?)\" and Submission Date As \"(.*?)\"$")
    public void updateDateForMember(String determinationDate , String submissionDate) throws Exception {
          String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
          EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
          eligibilityTable.updateDeterminationAndSubmissionDate(userProfileRefId, determinationDate, submissionDate);
    }
    
    /**Aashita 

	From EligibilityTable, Set Determination Date And Submission Date As "90" Days Prior from app date
	*/
	@Given("^From EligibilityTable, Set Determination Date And Submission Date As \"(.*?)\" Days Prior from app date$")
		public void updateDetAndSubDateForMember(String EligibilityBeginDatePriorFromToday) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String determinationDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.dbUpdateDatePattern1,  "00:00:"+EligibilityBeginDatePriorFromToday);
		String submissionDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.dbUpdateDatePattern1,  "00:00:"+EligibilityBeginDatePriorFromToday);
		eligibilityTable.updateDeterminationAndSubmissionDate(userProfileRefId, determinationDate, submissionDate);
	}

	
}
