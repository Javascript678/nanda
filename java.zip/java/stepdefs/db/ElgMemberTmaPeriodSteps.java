package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

import java.util.List;

import cucumber.api.java.en.Then;
import db.ElgMemberTable;
import db.ElgMemberTmaPeriodTable;

public class ElgMemberTmaPeriodSteps extends SuperStepDef {	
	
	public ElgMemberTmaPeriodSteps(Hook hook)  {
		super(hook);
	}
			
	/**@author ppinho
	*
	*/ 
	@Then("^From Elg Member TMA Period Table, Using Current Eligibility Member Id, Update End Date$")
	public void validateDORreferralRecordInterfaceTableStatus() throws Throwable {	
		String eligibilityId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:10:00");			
	
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		ElgMemberTmaPeriodTable elgMemberTmaPeriodTable = new ElgMemberTmaPeriodTable(conn, testCaseId);
				
		List<String> elgMemberIds = elgMemberTable.getIdS(eligibilityId);
				
		String listString = String.join(",", elgMemberIds);
				
		String[] elgMemId = listString.split(",");
				
		for(int i = 0; i < elgMemId.length; i++){
			elgMemberTmaPeriodTable.updateEndDateForElgMemId(elgMemId[i], newDueDate);
		}
	}
	
}
