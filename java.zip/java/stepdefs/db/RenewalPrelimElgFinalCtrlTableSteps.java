package stepdefs.db;

import cucumber.api.java.en.Given;
import db.RenewalElgTrackerTable;
import db.RenewalPrelimElgFinalCtrlTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class RenewalPrelimElgFinalCtrlTableSteps extends SuperStepDef {
				
	public RenewalPrelimElgFinalCtrlTableSteps(Hook hook) {
		super(hook);
	}	
	
	/** @author: ppinho
	* 
	* Expected Status:
	*	NOT_PROCESSED
	*	RENEWAL_INITIATED
	*	COMPLETED
	*  
	* From RenewalPrelimElgFinalCtrl Table, Validate Status As "COMPLETED"
	* 
	*/
	@Given("^From RenewalPrelimElgFinalCtrl Table, Validate Status As \"(.*?)\"$")
	public void validateStatus(String expStatus) throws Exception {
		RenewalPrelimElgFinalCtrlTable renewalPrelimElgFinalCtrlTable = new RenewalPrelimElgFinalCtrlTable(conn, testCaseId);
		renewalPrelimElgFinalCtrlTable.validateStatus(evpdData.memsData.get(0).userRefId, expStatus);	
	}
	
	/**@author: ppinho
	* 
	* From RenewalPrelimElgFinalCtrl Table, Run Query To Update Process Id
	* 
	*/
	@Given("^From RenewalPrelimElgFinalCtrl Table, Run Query To Update Renewed On Date$")
	public void initiateCCARenewalProcessIdUpdateQuery() throws Exception {
		RenewalPrelimElgFinalCtrlTable renewalPrelimElgFinalCtrlTable = new RenewalPrelimElgFinalCtrlTable(conn, testCaseId);			
		renewalPrelimElgFinalCtrlTable.ccaRenewalRenewedOnDateUpdateQuery(evpdData.memsData.get(0).userRefId);
	}
	
}
