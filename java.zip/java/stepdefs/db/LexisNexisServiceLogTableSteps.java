package stepdefs.db;

import cucumber.api.java.en.Then;
import db.LexisNexisServiceLogTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class LexisNexisServiceLogTableSteps  extends SuperStepDef{
	/**
	 * @author Vimal
	 *	Step Def for Interaction with Lexis Nexis Table
	 **/
	public LexisNexisServiceLogTableSteps(Hook hook) {
		super(hook);
	}

	//Vimal
	@Then("^From Lexis Nexis Service Log Table, Store Completed Data into Excel folder$")
	public void storeCompleteDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.storeCompleteDataInExcel(elgId);
	}
	
	//Vimal
	@Then("^From Lexis Nexis Service Log Table, Store Hub Request Reponse Data into Excel folder$")
	public void storeHubRequestReponseDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.storeHubRequestReponseDataInExcel(elgId);
	}
	/**Vimal
	   From LexisNexisServiceLog Table, Validate FirstName Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate FirstName Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLogTable_FirstName_Column_Value_As(String expFirstName) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateFirstNameUsingRefId(userProfileRefId, expFirstName);
	}
	/**Vimal
	   From LexisNexisServiceLog Table, Validate MiddleName Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate MiddleName Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_MiddleName_Column_Value_As(String expMiddleName) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateMiddleNameUsingRefId(userProfileRefId, expMiddleName);
		
	}
	/**Vimal
	   From LexisNexisServiceLog Table, Validate LastName Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate LastName Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_LastName_Column_Value_As(String expLastName) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateLastNameUsingRefId(userProfileRefId, expLastName);
	}
	/**Vimal
	   From LexisNexisServiceLog Table, Validate StreetAddressOne Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate StreetAddressOne Column Value as \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_StreetAddress1_Column_Value_as(String expStreetAddress1) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateStreetAddress1UsingRefId(userProfileRefId, expStreetAddress1);
	}
	
	/**Vimal
	   From LexisNexisServiceLog Table, Validate StreetAddressTwo Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate StreetAddressTwo Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_StreetAddress2_Column_Value_As(String expStreetAddress2) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateStreetAddress2UsingRefId(userProfileRefId, expStreetAddress2);
	}
	
	/**Vimal
	   From LexisNexisServiceLog Table, Validate AddressPurposeType Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table AddressPurposeType Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_AddressPurposeType_Column_Value_As(String expAddressPurposeType) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateAddressPurposeTypeUsingRefId(userProfileRefId, expAddressPurposeType);
	}
	
	/**Vimal
	   From LexisNexisServiceLog Table, Validate City Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate City Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_City_Column_Value_As(String expCity) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateCityUsingRefId(userProfileRefId, expCity);
	}
	
	/**Vimal
	   From LexisNexisServiceLog Table, Validate StateCode Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate StateCode Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_StateCode_Column_Value_As(String expStateCode) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateStateCodeUsingRefId(userProfileRefId, expStateCode);
	}
	
	/**Vimal
	   From LexisNexisServiceLog Table, Validate Zip Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate Zip Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_Zip_Column_Value_As(String expZip) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateZipUsingRefId(userProfileRefId, expZip);
		
	}
	
	/**Vimal
	   From LexisNexisServiceLog Table, Validate LexisNexisStatus Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate Lexis NexisStatus Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_Lexis_NexisStatus_Column_Value_As(String expLexisnexisStatus) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateLexisnexisStatusUsingRefId(userProfileRefId, expLexisnexisStatus);
	}
	
	/**Vimal
	   From LexisNexisServiceLog Table, Validate ErrorDesc Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate ErrorDesc Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_ErrorDesc_Column_Value_As(String expErrorDesc) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateErrorDescUsingRefId(userProfileRefId, expErrorDesc);
	}
	
	/**Vimal
	   From LexisNexisServiceLog Table, Validate XMLRequest Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate XMLRequest Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_XMLRequest_Column_Value_As(String expXmlRequest) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateXmlRequestUsingRefId(userProfileRefId, expXmlRequest);
	}
	
	/**Vimal
	   From LexisNexisServiceLog Table, Validate XMLResponse Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate XMLResponse Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_XMLResponse_Column_Value_As(String expXmlResponse) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateXMLResponseUsingRefId(userProfileRefId, expXmlResponse);
	}
	
	/**Vimal
	   From LexisNexisServiceLog Table, Validate LexisNexisVerified Column Value As ""
	 */
	@Then("^From LexisNexisServiceLog Table, Validate LexisNexisVerified Column Value As \"([^\"]*)\"$")
	public void from_LexisNexisServiceLog_Table_LexisNexisVerified_Verified_Column_Value_As(String expLexisnexisVerified) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		LexisNexisServiceLogTable LexisNexisServiceLogTable1 = new LexisNexisServiceLogTable(conn, testCaseId);
		LexisNexisServiceLogTable1.validateLexisnexisVerifiedUsingRefId(userProfileRefId, expLexisnexisVerified);
	}


}
