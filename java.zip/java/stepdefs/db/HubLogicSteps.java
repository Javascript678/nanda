package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

import java.util.HashMap;
import java.util.Map;

import cucumber.api.java.en.Then;
import db.DataSourceRequestLogTable;
import db.DisabilityInfoTable;
import db.ElgMemMecVerificationDataTable;
//import db.ElgMemberIncomeDorTable;
import db.LexisNexisServiceLogTable;
import db.RidpFederalHubResponseTable;
import db.SSNCardTable;
import db.SuperTable;
import db.VlpCaseTrackerTable;

/**
 * 
 * @author Vimal
 *	Step Def for Interaction with VLP Table
 */
public class HubLogicSteps extends SuperStepDef {
	
	public HubLogicSteps(Hook hook)  {
		super(hook);
	}
	
	@Then("^Store HUB Request Response Data in Excel For Manual Validation$")
	public void storeCompleteDataInExcel() throws Throwable {		
		Map<String, String> hohData = (Map<String, String>) testData.get("0");

		Boolean hub_Req_Resp_Logic_Required_In_Excel = hohData.get("hubReqRespLogicRequired").equalsIgnoreCase("TRUE")?true:false;
		
		if(hub_Req_Resp_Logic_Required_In_Excel){			
			String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
			
			LexisNexisServiceLogTable lexisNexisServiceLogTable = new LexisNexisServiceLogTable(conn, testCaseId);
			String lexisNexisServiceLogQuery = lexisNexisServiceLogTable.getSelectAllQuery(elgId);
			
			DataSourceRequestLogTable dataSourceRequestLogTable = new DataSourceRequestLogTable(conn, testCaseId);
			String dataSourceRequestLogQuery = dataSourceRequestLogTable.getSelectAllQuery(elgId);
			
			VlpCaseTrackerTable vLPCaseTrackerTable = new VlpCaseTrackerTable(conn, testCaseId);
			String vLPCaseTrackerTableQuery =  vLPCaseTrackerTable.getSelectAllQuery(elgId);
			
			RidpFederalHubResponseTable ridpFederalHubResponseTable = new RidpFederalHubResponseTable(conn, testCaseId);
			String ridpFederalHubResponseTableQuery  = ridpFederalHubResponseTable.getSelectAllQuery(elgId);
			
			DisabilityInfoTable  disabilityInfoTable = new DisabilityInfoTable(conn, testCaseId);
			String disabilityInfoTableQuery = disabilityInfoTable.getSelectAllQuery(elgId);
			
			/*ElgMemberIncomeDorTable elgMemberIncomeDorTable = new ElgMemberIncomeDorTable(conn, testCaseId);
			String elgMemberIncomeDorTableQuery = elgMemberIncomeDorTable.getSelectAllQuery();*/
			
			SSNCardTable ssnCardTable = new SSNCardTable(conn, testCaseId);
			String ssnCardTableQuery = ssnCardTable.getSelectAllQuery(elgId);
			
			ElgMemMecVerificationDataTable elgMemMecVerificationDataTable = new ElgMemMecVerificationDataTable(conn, testCaseId);
			String elgMemMecVerificationDataTableQuery = elgMemMecVerificationDataTable.getSelectAllQuery(elgId);
			
			Map<String, String> dataQuries = new HashMap<String, String>();
			
			//dataQuries.put("LexisNexisServiceLogTable", lexisNexisServiceLogQuery);
			dataQuries.put("DataSourceRequestLogTable", dataSourceRequestLogQuery);
			//dataQuries.put("VlpCaseTrackerTable", vLPCaseTrackerTableQuery);
			//dataQuries.put("DisabilityInfoTable", disabilityInfoTableQuery);
			//dataQuries.put("ElgMemberIncomeDorTable", elgMemberIncomeDorTableQuery);
			dataQuries.put("SSNCardTable", ssnCardTableQuery);
			dataQuries.put("ElgMemMecVerificationDataTable", elgMemMecVerificationDataTableQuery);
			//dataQuries.put("RidpFederalHubResponseTable", ridpFederalHubResponseTableQuery);
		
			
        	SuperTable superTable = new SuperTable(conn, testCaseId);
        	superTable.storeDBTablesInOneExcel(dataQuries, elgId);
        	
        	String query = "select " + " DSRL.Eligibility_id      as elg_id_DSRL, "
					+ " DSRL.TYPE                as data_type, " 
					+ " DSRL.Status              as data_type_status, "
					+ " EM.ID                    as elg_member_id_EM, " 
					+ " EM.FIRST_NAME            as first_name, "
					+ " EM.MIDDLE_NAME           as middle_name, " 
					+ " EM.LAST_NAME             as last_name, "
					+ " EM.SUFFIX                as suffix, " 
					+ " EM.DATE_OF_BIRTH         as DOB, "
					+ " SC.ID                    as ssn_card_SC, " 
					+ " SC.IS_DEAD               as is_dead, "
					+ " SC.IS_DEATH_VERIFIED     as is_deathverified, " 
					+ " SC.Death_Verification_Date as death_date, "
					+ " SC.DEATH_VERIFICATION_SOURCE as death_source, "
					+ " DI.IS_DISABLED            as is_disable_ID, " 
					+ " DI.DISABILITY_TYPE        as dis_type_DT, "
					+ " DI.DISABILITY_SOURCE      as dis_source_DS, "
					+ " DI.MEDICARE_CVG_START_DATE as med_cvg_start_date, "
					+ " DI.MEDICARE_CVG_END_DATE  as med_cvg_end_date, "
					+ " DI.DISABILITY_EFF_END_DATE as dis_end_date, "
					+ " DI.DISABILITY_EFF_START_DATE as dis_start_date , "
					+ " VLP.CASE_NUMBER              as case_number, " 
					+ " VLP.CASE_TYPE                as case_type, "
					+ " VLP.CASE_STATUS              as case_status, "
					+ " VLP.G845_MAJOR_CD            as G845_major_cd, " 
					+ " VLP.NON_CITIZEN_COA          as non_coa, "
					+ " VLP.FIVE_YEAR_BAR_APPLIES    as five_yr_bar_apply, "
					+ " VLP.FIVE_YEAR_BAR_MET        as five_yr_met, " 
					+ " VLP.GRANT_DATE               as grant_date, "
					+ " VLP.EVALUATE_LP_STATUS       as evaluated_status, "
					+ " VLP.ATTESTED_LP_STATUS       as attested_status, "
					+ " VLP.USER_PROFILE_ID          as profile_id, "
					+ " VLP.ELG_STATEMENT_CODE       as elg_statement_code, "
					+ " VLP.AGENCY_ACTION            as agency_action, "
					+ " IRS.MAGI_AMOUNT              as magi_amount, "
					+ " IRS.Receive_Mode             as receive_Mode, "
					+ " IRS.Taxable_Ssb              as taxable_ssb, "
					+ " FTI.EXPECTED_YEARLY_INCOME   as expected_Yr_Income, "
					+ " FTI.ELG_MEMBER_ID            as elg_member_id, "
					+ " FTI.Fti_Reported_Income      as fti_rep_income, "
					+ " FTI.Tax_Magi_Amount          as tax_magi_amount, "
					+ " FTI.Tax_Socialsecurity_Benefits as tax_SS_Benefits, "
					+ " FTI.Same_As_Current_Income      as same_current_projected, "
					+ " MEC.RESPONSE_CODE               as res_code, "
					+ " MEC.RESPONSE_TEXT               as res_text, " 
					+ " MEC.TDS_DESCRIPTION             as tds_des, "
					+ " MEC.Source_Id                   as source_id, "
					+ " MECCOV.TDS_SOURCE_ID            as tds_source, "
					+ " MECCOV.MEC_EFFECTIVE_DATE       as mec_eff_date, "
					+ " MECCOV.Mec_End_Date             as mec_end_date, "
					+ " HUB.Ssa_Response_Code           as ssa_res_code, "
					+ " HUB.Ssn_Verified            as ssn_verified, "
					+ " HUB.Ssn_Indicator           as ssn_indicator, " 
					+ " HUB.Citizenship_Verified    as cit_veri, "
					+ " HUB.Living_Indicator        as liv_ind, "
					+ " HUB.Incarceration_Verified  as incarc_ver, "
					+ " HUB.MEMBER_REFERENCE_ID     as memb_ref_id, " 
					+ " HUB.SSN                     as ssn, "
					+ " LEXNEX.STREET_ADDRESS1      as strt_add1, " 
					+ " LEXNEX.STREET_ADDRESS2      as strt_add2, "
					+ " LEXNEX.ADDRESS_PURPOSE_TYPE as Add_type, " 
					+ " LEXNEX.CITY                 as city, "
					+ " LEXNEX.STATE_CODE           as state_code, " 
					+ " LEXNEX.ZIP                  as zip, "
					+ " LEXNEX.LEXIS_NEXIS_STATUS   as lexnex_status, " 
					+ " LEXNEX.ERROR_DESC           as error_desc, "
					+ " LEXNEX.RESPONSE_CODE        as res_code, " 
					+ " LEXNEX.RESPONSE_CODE_DESC   as res_code_desc, "
					+ " LEXNEX.XML_REQUEST          as req_xml, " 
					+ " LEXNEX.XML_RESPONSE         as res_xml, "
					+ " LEXNEX.LEXIS_NEXIS_VERIFIED as lexnex_ver, " 
					+ " LEXNEX.IS_APPLIED           as is_applied, "
					+ " RIDP.SERVICE_TYPE           as ser_type, " 
					+ " RIDP.RESPONSE_CODE          as res_code, "
					+ " RIDP.STATUS                 as status "

					+ " from mahx_own.elg_member EM  "

					+ " left join mahx_own.ssn_card     SC " 
					+ " ON EM.ID  = SC.ELG_MEMBER_ID "

					+ " left join mahx_own.disability_info     DI "
					+ " ON EM.MMIS_MEMBER_REFERENCE_ID = DI.MMIS_MEMBER_REFERENCE_ID   "

					+ " left join mahx_own.vlp_case_tracker    VLP "
					+ " ON EM.MEMBER_REFERENCE_ID = VLP.Member_Reference_Id "

					+ " left join mahx_own.IRS_MEMBER_VERIFICATION  IRS "
					+ " ON EM.Member_Reference_Id = IRS.MEM_REF_ID "

					+ " left join mahx_own.elg_member_income_fti    FTI " 
					+ " ON EM.ID = FTI.Elg_Member_Id "

					+ " left join mahx_own.elg_mem_mec_verification_data MEC  "
					+ " ON EM.ID = MEC.Eligibility_Member_Id "

					+ " left join mahx_own.mec_coverage_overlap MECCOV "
					+ " ON EM.ELIGIBILITY_ID = MECCOV.ELIGIBILITY_ID "

					+ " left join mahx_own.ma_hub_request_response HUB "
					+ " ON EM.Member_Reference_Id = HUB.Member_Reference_Id "

					+ " left join mahx_own.lexisnexis_service_log  LEXNEX " 
					+ " ON EM.FIRST_NAME = LEXNEX.FIRST_NAME "

					/*+ " left join mahx_own.elg_member_income_dor INCOMEDOR "
					+ " ON FTI.ID = INCOMEDOR.ELG_MEMBER_INCOME_ID "*/

					+ " left join mahx_own.ridp_federal_hub_response RIDP "
					+ " ON VLP.User_Profile_Id = RIDP.User_Profile_Id    "

					+ " Left join mahx_own.data_source_request_log DSRL "
					+ " ON EM.eligibility_id = DSRL.ELIGIBILITY_ID "

					+ " Where EM.ELIGIBILITY_ID in (" + elgId + ") ";

			superTable.storeDBTableIntoExcel(query, "Hub Service Crux Table");
		}
		
	}
}
	
	
	

