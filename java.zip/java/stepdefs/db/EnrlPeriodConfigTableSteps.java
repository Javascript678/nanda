package stepdefs.db;

import cucumber.api.java.en.Given;

import db.DualTable;

import db.EnrlPeriodConfigTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;


public class EnrlPeriodConfigTableSteps extends SuperStepDef
{
	public EnrlPeriodConfigTableSteps(Hook hook) {
		super(hook);
	}
	
	/**Author: Anubhuti
	 * 
	 * From EnrlPeriodConfig Table, Validate That Currently Its SEP Period
	 * 
	 */
	@Given("^From EnrlPeriodConfig Table, Validate That Currently Its SEP Period$")
	public void validateSEPPeriodExist() throws Throwable 
	{
		DualTable dualtable = new DualTable(conn, testCaseId);
		String appDate = dualtable.getSysDate();
		String appYear = "";
		appDate = DateUtil.getTodaysDateInDBFormat();
		appYear = appDate.split("_")[0];
		
		EnrlPeriodConfigTable enrlPeriodConfigTable = new EnrlPeriodConfigTable(conn, testCaseId);
		enrlPeriodConfigTable.validateSEPPeriodExist(appYear, appDate);
	  
	}

}
