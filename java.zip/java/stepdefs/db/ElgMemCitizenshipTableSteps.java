package stepdefs.db;

import cucumber.api.java.en.Given;
import db.ElgMemberCitizenshipTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class ElgMemCitizenshipTableSteps extends SuperStepDef
{

	
	public ElgMemCitizenshipTableSteps(Hook hook) {
		super(hook);
	}
	
	
	/**
	 * Vinay
		
		From ElgMemCitizenshipTable, Update Status Award Date For Member "1" As "1850" Date Prior From Today
		
	 */
	@Given("^From ElgMemCitizenshipTable, Update Status Award Date For Member \"(.*?)\" As \"(.*?)\" Date Prior From Today$")
	public void expireCitizenshipRFIsForAllMember(String memNo, String datePriorFromToday) throws Exception {
		String userProfileRefId = evpdData.memsData.get(0).userRefId.toString();
		int memIndex = Integer.parseInt(memNo)-1;
		
		String appDate = evpdData.memsData.get(0).appCreateDate.toString();
		String dateValue = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:"+datePriorFromToday);
		
		ElgMemberCitizenshipTable elgMemberCitizenshipTable = new ElgMemberCitizenshipTable(conn, testCaseId);
		elgMemberCitizenshipTable.updateStatusAwardDate(userProfileRefId, memIndex, dateValue);
		
	}
	
	@Given("^From ElgMemCitizenshipTable, Update Status Award Date For Member \"(.*?)\" Date Prior From Today$")
	public void expireCitizenshipRFIsForAllMember(String memNo) throws Exception {
		String userProfileRefId = evpdData.memsData.get(0).userRefId.toString();
		int memIndex = Integer.parseInt(memNo)-1;
		
		String appDate = evpdData.memsData.get(0).appCreateDate.toString();
		String dateValue = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:"+2400);
		
		ElgMemberCitizenshipTable elgMemberCitizenshipTable = new ElgMemberCitizenshipTable(conn, testCaseId);
		elgMemberCitizenshipTable.updateStatusAwardDate(userProfileRefId, memIndex, dateValue);
		
	}
}
