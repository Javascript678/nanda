package stepdefs.db;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.DualTable;
import db.OeElgMemberTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class OeElgMemTableSteps extends SuperStepDef
{

	
	public OeElgMemTableSteps(Hook hook) {
		super(hook);
	}
	
	/**
	 * @author Ritika
	
			From OeElgMember, Update Determination And Submission Date
			|	MemNo	|	StartDatePriorFromToday	|	EndDatePriorFromToday	|
			|	 1		|		1					|		0					|
	 
	 */
	
	@Given("^From OeElgMember, Update Determination And Submission Date$") 
	public void expireIncarcerationRFIsForOneMember(DataTable table) throws Exception {
		List<List<String>> scenarioData = table.raw();
		int memIndex=Integer.parseInt(scenarioData.get(1).get(0))-1;
		
		String proctectStartColumn=scenarioData.get(1).get(1);
		String proctectEndColumn=scenarioData.get(1).get(2);
		
		String currentDate = new DualTable(conn,"").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);
		String proctectStartColumnValue = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+proctectStartColumn);
		String proctectEndColumnValue = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+proctectEndColumn);
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		OeElgMemberTable oeElgMemberTable = new OeElgMemberTable(conn, testCaseId);
		oeElgMemberTable.updateDeterminationAndSubmissionDate( userProfileRefId ,memIndex ,proctectStartColumnValue, proctectEndColumnValue);
		
	}
	
	
}
