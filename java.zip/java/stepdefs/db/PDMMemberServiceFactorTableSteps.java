package stepdefs.db;

import cucumber.api.java.en.Given;
import db.PDMMemberServiceFactorTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class PDMMemberServiceFactorTableSteps extends SuperStepDef
{


	public PDMMemberServiceFactorTableSteps(Hook hook) {
		super(hook);
	}

	/*
	 * @Ritika 
	 * 
		From PDMMemberServiceFactor Table,Validate ServiceStatus For "DECEASED" As "READY",For Member "1"
	 * 
	 */
	//Ritika
	@Given("^From PDMMemberServiceFactor Table,Validate ServiceStatus For \"(.*?)\" As \"(.*?)\",For Member \"(.*?)\"$")
	public void validateStatus(String serviceName,String serviceStatus,int memNo) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		int memIndex = memNo - 1;
		PDMMemberServiceFactorTable pdmMemberServiceFactorTable = new PDMMemberServiceFactorTable(conn, testCaseId);
		pdmMemberServiceFactorTable.validateServiceStatus(userProfileRefId, memIndex, serviceName, serviceStatus);
	}
}
