package stepdefs.db;

import cucumber.api.java.en.Given;
import db.MedRenewalDorControlTable;
import db.PdmElgActionControlTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class PdmElgActionControlTableSteps extends SuperStepDef
{


	public PdmElgActionControlTableSteps(Hook hook) {
		super(hook);
	}

	/*
	 * @Vinay 
	 Expected PDM_ACTION
	 		1	PRELIM_ELIGIBILITY
			2	IMMEDIATE_DETERMINATION_HOH_DEAD
			3	INITIATE_RFI_TIME_CLOCK
			4	REDETERMINE_ELIGIBILITY_ON_TCE
			5	PRELIM_ELIGIBILITY_GENERATE_REPORT

	 * Expected Status
			1	FORCE_BO_STOPPED
			2	NOT_PROCESSED
			3	ERROR
			4	STOPPED
			5	STOPPED_HOH_DEAD
			6	COMPLETED
	

	  
	  From PdmElgActionControl Table, For PdmAction As "INITIATE_RFI_TIME_CLOCK", Validate Status As "NOT_PROCESSED"
	 * 
	 */
	@Given("^From PdmElgActionControl Table, For PdmAction As \"(.*?)\", Validate Status As \"(.*?)\"$")
	public void validateStatus(String pdmAction,String expStatus) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		PdmElgActionControlTable pdmElgActionControlTable = new PdmElgActionControlTable(conn, testCaseId);
		pdmElgActionControlTable.validateStatus(userProfileRefId, pdmAction, expStatus);
	}
	
	/*
	 * @Vinay 
	 Expected PDM_ACTION
	 		1	PRELIM_ELIGIBILITY
			2	IMMEDIATE_DETERMINATION_HOH_DEAD
			3	INITIATE_RFI_TIME_CLOCK
			4	REDETERMINE_ELIGIBILITY_ON_TCE
			5	PRELIM_ELIGIBILITY_GENERATE_REPORT
				  
	  From PdmElgActionControl Table, For PdmAction As "INITIATE_RFI_TIME_CLOCK", Validate Status Reason Value As Blank
	 * 
	 */
	@Given("^From PdmElgActionControl Table, For PdmAction As \"(.*?)\", Validate Status Reason Value As Blank$")
	public void validateStatusReason(String pdmAction) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		PdmElgActionControlTable pdmElgActionControlTable = new PdmElgActionControlTable(conn, testCaseId);
		pdmElgActionControlTable.validateStatusReason(userProfileRefId, pdmAction, "");;
	}
		
}
