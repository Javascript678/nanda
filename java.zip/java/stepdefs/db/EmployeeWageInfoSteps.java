/**
 * 
 */
package stepdefs.db;

import cucumber.api.java.en.Then;
import db.EmployeeWageInfoTable;
import db.IrsResponseMetadataTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

/**
 * @author vverma25
 *Step Def for Interaction with IRS Member Verification Table
 */
public class EmployeeWageInfoSteps extends SuperStepDef {

	public EmployeeWageInfoSteps(Hook hook) {
		super(hook);
		
	}
		
	// ppinho
	@Then("^From EmployeeWageInfo Table, Update DOR Response For Each Member$")
	public void updateDorResponseForEachMember() throws Throwable {
		EmployeeWageInfoTable employeeWageInfoTable = new EmployeeWageInfoTable(conn, testCaseId);
		
		String userRefId = evpdData.memsData.get(0).userRefId;
		
		for(int memInd = 0; memInd < evpdData.memCount; memInd++){			
			if(initialPrelimData.memsData.get(memInd).hasDorResponse){
				if(initialPrelimData.memsData.get(memInd).dorResponse.contains("ERROR")){
					System.out.println(initialPrelimData.memsData.get(memInd).dorResponse);
				}else{
					employeeWageInfoTable.ccaRenewalReportedWagesUpdateQuery(userRefId, memInd, initialPrelimData.memsData.get(memInd).dorResponse);
				}
			}
		}		
	}
}
