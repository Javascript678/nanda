package stepdefs.db;

import cucumber.api.java.en.Given;
import db.PDMMemberServiceInfoTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class PDMMemberServiceInfoTableSteps extends SuperStepDef
{


	public PDMMemberServiceInfoTableSteps(Hook hook) {
		super(hook);
	}

	/*
	 * @Ritika 
	 * 
		From PDMMemberServiceInfo Table,Validate ServiceStatus For "SSA" As "READY",For Member "1"
	 * 
	 */
	//Ritika
	@Given("^From PDMMemberServiceInfo Table,Validate ServiceStatus For \"(.*?)\" As \"(.*?)\",For Member \"(.*?)\"$")
	public void validateStatus(String serviceName,String serviceStatus,int memNo) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		int memIndex = memNo - 1;
		PDMMemberServiceInfoTable pdmMemberServiceInfoTable = new PDMMemberServiceInfoTable(conn, testCaseId);
		pdmMemberServiceInfoTable.validateServiceStatus(userProfileRefId, memIndex, serviceName, serviceStatus);
	}
}
