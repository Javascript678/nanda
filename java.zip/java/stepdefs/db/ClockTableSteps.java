package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;
import cucumber.api.java.en.Then;
import db.ClockTable;
import db.ElgMemberTable;

public class ClockTableSteps extends SuperStepDef {

	
	
	public ClockTableSteps(Hook hook)  {
		super(hook);
	}
			
	/**@author ppinho
	 * 		
		From Clock Table, Using Current EligId, For Member "1,2,3", Expire FTR Time Clock
	
	**/ 
	@Then("^From Clock Table, Using Current EligId, For Member \"(.*?)\", Expire FTR Time Clock$")
	public void validateDORreferralRecordInterfaceTableStatus(String memNos) throws Throwable {
		String[] arrMemNos = memNos.split(",");				
		String eligibilityId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String newDueDate = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:02");		
		
		ClockTable clock = new ClockTable(conn, testCaseId);
		
		for(int mCounter=0; mCounter<arrMemNos.length; mCounter++){
			int memIndex = Integer.parseInt(arrMemNos[mCounter])-1;			
			
			ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
			
			String memFName = elgMemberTable.getFirstName(eligibilityId, memIndex);
			String memLName = elgMemberTable.getLastName(eligibilityId, memIndex);
			
			clock.updateClock(eligibilityId, memFName, memLName, newDueDate);
		}
	}
	
}
