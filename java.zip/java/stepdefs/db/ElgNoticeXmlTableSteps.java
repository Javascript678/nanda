package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;
import cucumber.api.java.en.Then;
import db.ElgNoticeXmlTable;


public class ElgNoticeXmlTableSteps extends SuperStepDef {

	
	
	public ElgNoticeXmlTableSteps(Hook hook)  {
		super(hook);
	}
	
	/**@author vkuma212
		
		From ElgNoticeXml Table, Using EligId With Variable As "ElgId_NOTICE1_Validation", For Notice Type As "ELAPR01", Language As "ENG" And NoticeNo "1", Validate Current Status "COMPLETED"
	
	 */
	@Then("^From ElgNoticeXml Table, Using EligId With Variable As \"(.*?)\", For Notice Type As \"(.*?)\", Language As \"(.*?)\" And NoticeNo \"(.*?)\", Validate Current Status \"(.*?)\"$")
	public void validateStatus(String varibleNameFrElgId, String noticeType, String language, String noticeNo, String expStatus) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		
		int intNoticeNo = Integer.parseInt(noticeNo);
		ElgNoticeXmlTable elgNoticeXmlTable = new ElgNoticeXmlTable(conn, testCaseId);
		elgNoticeXmlTable.validateCurrentStatus(eligibilityId, noticeType, language, intNoticeNo, expStatus);
	}
	
/**@author sshriv16
	
	From ElgNoticeXml Table, Using EligId With Variable As "ElgId_NOTICE1_Validation", For Notice Type As "ELAPR01", Language As "ENG" And NoticeNo "1", Validate Print Type "BR"

 */
	@Then("^From ElgNoticeXml Table, Using EligId With Variable As \"(.*?)\", For Notice Type As \"(.*?)\", Language As \"(.*?)\" And NoticeNo \"(.*?)\", Validate Print Type \"(.*?)\"$")
	public void validatePrintType(String varibleNameFrElgId, String noticeType, String language, String noticeNo, String printType) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		
		int intNoticeNo = Integer.parseInt(noticeNo);
		ElgNoticeXmlTable elgNoticeXmlTable = new ElgNoticeXmlTable(conn, testCaseId);
		elgNoticeXmlTable.validatePrintType(eligibilityId, noticeType, language, intNoticeNo, printType);
	}
	
	/**@author vkuma212
	
	From ElgNoticeXml Table, Using EligId With Variable As "ElgId_NOTICE1_Validation", Validate Total Notice Count As "5"

 */
	@Then("^From ElgNoticeXml Table, Using EligId With Variable As \"(.*?)\", Validate Total Notice Count As \"(.*?)\"$")
	public void validateRowCountForElgId(String varibleNameFrElgId, String expCount) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		int intExpCount = Integer.parseInt(expCount);
		
		ElgNoticeXmlTable elgNoticeXmlTable = new ElgNoticeXmlTable(conn, testCaseId);
		elgNoticeXmlTable.validateRowCountForElgId(eligibilityId, intExpCount);
	}
	

	
}
