package stepdefs.db;

import cucumber.api.java.en.Given;
import db.APTCCalculationControlDataTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class APTCCalculationControlDataTableSteps extends SuperStepDef
{

	
	public APTCCalculationControlDataTableSteps(Hook hook) {
		super(hook);
	}
	
	/*
	 * @Ritika 
	 * 
	 * From APTCCalculationControlData Table, Select ID Using Eligibility ID
	 * 
	*/
	//Ritika
	@Given("^From APTCCalculationControlData Table, Select ID Using Eligibility ID$")
	public void expireCitizenshipRFIsForAllMember(String status,String startDate,String endDate) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		
		APTCCalculationControlDataTable aptcCalculationControlData = new APTCCalculationControlDataTable(conn, testCaseId);
		aptcCalculationControlData.getId(userProfileRefId);
				
		}
	
}
