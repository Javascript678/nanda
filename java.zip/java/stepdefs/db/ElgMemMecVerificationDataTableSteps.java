package stepdefs.db;

import cucumber.api.java.en.Then;
import db.ElgMemMecVerificationDataTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class ElgMemMecVerificationDataTableSteps extends SuperStepDef {

	public ElgMemMecVerificationDataTableSteps(Hook hook) {
		super(hook);
	}
	
	//Vimal
	@Then("^From Elg Mem Mec Verification Data Table, Store Completed Data into Excel folder$")
	public void storeCompleteDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		ElgMemMecVerificationDataTable elgMemMecVerificationDataTable = new ElgMemMecVerificationDataTable(conn,testCaseId);
		elgMemMecVerificationDataTable.storeCompleteDataInExcel(elgId);
	}

	//Vimal
	@Then("^From Elg Mem Mec Verification Data Table, Store Hub Request Reponse Data into Excel folder$")
	public void storeHubRequestReponseDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		
		ElgMemMecVerificationDataTable elgMemMecVerificationDataTable = new ElgMemMecVerificationDataTable(conn,testCaseId);
		elgMemMecVerificationDataTable.storeHubRequestReponseDataInExcel(elgId);
		
	}
	
	/**	Vimal
	   From ElgMemMecVerificationData Table, Validate ResponseCode Column Value As ""
	 */
	@Then("^From ElgMemMecVerificationData Table, Validate ResponseCode Column Value As \"([^\"]*)\"$")
	public void from_ElgMemMecVerificationData_Table_ResponseCode_Column_Value_As(String expResponseCode) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemMecVerificationDataTable elgMemMecVerificationDataTable = new ElgMemMecVerificationDataTable(conn,testCaseId);
		elgMemMecVerificationDataTable.validateResponseCodeUsingRefId(userProfileRefId, expResponseCode, 0);
	}
	
	/**	Vimal
	   From ElgMemMecVerificationData Table, Validate ResponseText Column Value As ""
	 */
	@Then("^From ElgMemMecVerificationData Table, Validate ResponseText Column Value As \"([^\"]*)\"$")
	public void from_ElgMemMecVerificationData_Table_ResponseText_Column_Value_As(String expResponseText) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemMecVerificationDataTable elgMemMecVerificationDataTable = new ElgMemMecVerificationDataTable(conn,testCaseId);
		elgMemMecVerificationDataTable.validateResponseTextUsingRefId(userProfileRefId, expResponseText, 0);
		
	}
	
	/**	Vimal
	   From ElgMemMecVerificationData Table, Validate TDSDescription Column Value As ""
	 */
	@Then("^From ElgMemMecVerificationData Table, Validate TDSDescription Column Value As \"([^\"]*)\"$")
	public void from_ElgMemMecVerificationData_Table_TDSDescription_Column_Value_As(String expTDSDescription) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemMecVerificationDataTable elgMemMecVerificationDataTable = new ElgMemMecVerificationDataTable(conn,testCaseId);
		elgMemMecVerificationDataTable.validateTDSDescriptionUsingRefId(userProfileRefId, expTDSDescription, 0);
	  
	}
	
	/**	Vimal
	   From ElgMemMecVerificationData Table, Validate SourceId Column Value As ""
	 */
	@Then("^From ElgMemMecVerificationData Table, Validate SourceId Column Value As \"([^\"]*)\"$")
	public void from_ElgMemMecVerificationData_Table_SourceId_Column_Value_As(String expSourceId) throws Throwable {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemMecVerificationDataTable elgMemMecVerificationDataTable = new ElgMemMecVerificationDataTable(conn,testCaseId);
		elgMemMecVerificationDataTable.validateSourceIdUsingRefId(userProfileRefId, expSourceId, 0);
	  
	}

}
