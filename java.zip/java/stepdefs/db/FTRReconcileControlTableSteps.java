package stepdefs.db;

import cucumber.api.java.en.Given;
import db.FTRReconcileControlTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class FTRReconcileControlTableSteps extends SuperStepDef
{

	
	public FTRReconcileControlTableSteps(Hook hook) {
		super(hook);
	}
	
	/*
	 * @Ritika 
	 * 
	 From FTRReconcileControl Table, update ProcessId As "9999999999",Updated By "Automation",Status As "NOT_PROCESSED"
	 * 
	*/
	//Ritika
	@Given("^From FTRReconcileControl Table, update ProcessId As \"(.*?)\",Updated By \"(.*?)\",Status As \"(.*?)\"$")
	public void updateProcessUser(String processId,String updatedBy,String status) throws Exception {
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		FTRReconcileControlTable ftrReconcileControl = new FTRReconcileControlTable(conn, testCaseId);
		ftrReconcileControl.updateProcessId(userProfileRefId, processId,status);
		ftrReconcileControl.updateUpdatedBy(userProfileRefId, updatedBy, status);
		
		}
	
	
	/*
	 * @Ritika 
	 * 
	 From FTRReconcileControl Table, update ProcessId As "NULL",And Updated By "NULL"
	 * 
	*/
	
	@Given("^From FTRReconcileControl Table, update ProcessId As \"(.*?)\",And Updated By \"(.*?)\"$")
	public void updateProcUser(String processId,String updatedBy) throws Exception {
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		FTRReconcileControlTable ftrReconcileControl = new FTRReconcileControlTable(conn, testCaseId);
		ftrReconcileControl.updateProcessId(userProfileRefId, processId);
		ftrReconcileControl.updateUpdatedBy(userProfileRefId, processId);
		
		}
}
