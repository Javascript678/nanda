package stepdefs.db;

import cucumber.api.java.en.Given;
import db.MedRenewalTrackerTable;
import db.MedRenewalVlpControlTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class MedRenewalVlpControlTableSteps extends SuperStepDef{
	public MedRenewalVlpControlTableSteps(Hook hook) {
		super(hook);
	}

	/* @author Vinay
	 * 
	   Expected Status
			1	VLP_IN_PROGRESS
			2	VLP_PERSON_UNKOWN
			3	NOT_PROCESSED
			4	VLP_ERROR
			5	ON_HOLD_KAPIL
			6	ERROR
			7	ONHOLD_0509
			8	COMPLETED

	  From MedRenewalVlpControl Table,Validate Status As "VLP_IN_PROGRESS", For Member "1"
	 * 
	 */
	@Given("^From MedRenewalVlpControl Table,Validate Status As \"(.*?)\", For Member \"(.*?)\"$")
	public void validateStatus(String expStatus,String memNo) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		int memIndex = Integer.parseInt(memNo) - 1;
		MedRenewalVlpControlTable medRenewalVlpControlTable = new MedRenewalVlpControlTable(conn, testCaseId);
		medRenewalVlpControlTable.validateStatus(userProfileRefId, memIndex, expStatus);
	}
	
}
