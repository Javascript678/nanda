package stepdefs.db;
import cucumber.api.java.en.Given;
import db.RenewalConfigTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class RenewalConfigTableSteps extends SuperStepDef
{

	
	public RenewalConfigTableSteps(Hook hook) {
		super(hook);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update NEXT_CYCLE_RENEW_DEFAULT_COUNT As "4000"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update NEXT_CYCLE_RENEW_DEFAULT_COUNT As \"(.*?)\"$")
	public void updateConfigTypeNextCycleRenewDefaultCount(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeNextCycleRenewDefaultCount(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update NEXT_CYCLE_RENEW_OVERRIDE_COUNT As "4000"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update NEXT_CYCLE_RENEW_OVERRIDE_COUNT As \"(.*?)\"$")
	public void updateConfigTypeNextCycleRenewOverrideCount(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeNextCycleRenewOverrideCount(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update STREAMLINE_RENEWAL_SNAP_BASED_ENABLE As "true"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update STREAMLINE_RENEWAL_SNAP_BASED_ENABLE As \"(.*?)\"$")
	public void updateConfigTypeStreamlineRenewalSnapBasedEnable(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeStreamlineRenewalSnapBasedEnable(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update STREAMLINE_RENEWAL_SSI_BASED_ENABLE As "true"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update STREAMLINE_RENEWAL_SSI_BASED_ENABLE As \"(.*?)\"$")
	public void updateConfigTypeStreamlineRenewalSsiBasedEnable(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeStreamlineRenewalSsiBasedEnable(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update STREAMLINE_RENEWAL_APPLY_GROUP_CRITERIA As "true"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update STREAMLINE_RENEWAL_APPLY_GROUP_CRITERIA As \"(.*?)\"$")
	public void updateConfigTypeStreamlineRenewalApplyGrpCriteria(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeStreamlineRenewalApplyGrpCriteria(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update MEDICAID_RENEWAL_FILTER_OPEN_RFI As "false"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update MEDICAID_RENEWAL_FILTER_OPEN_RFI As \"(.*?)\"$")
	public void updateConfigTypeMedicaidRenewalFilterOpenRfi(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeMedicaidRenewalFilterOpenRfi(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update STREAMLINE_RENEWAL_APPLY_SSI_CRITERIA As "true"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update STREAMLINE_RENEWAL_APPLY_SSI_CRITERIA As \"(.*?)\"$")
	public void updateConfigTypeStreamlineRenewalApplySsiCriteria(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeStreamlineRenewalApplySsiCriteria(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update STREAMLINED_RENEWAL_FILTER_OPEN_RFI As "true"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update STREAMLINED_RENEWAL_FILTER_OPEN_RFI As \"(.*?)\"$")
	public void updateConfigTypeStreamlineRenewalFilterOpenRfi(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeStreamlineRenewalFilterOpenRfi(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update MEDICAID_RENEWAL_FILTER_PDM_TIMECLOCK As "true"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update MEDICAID_RENEWAL_FILTER_PDM_TIMECLOCK As \"(.*?)\"$")
	public void updateConfigTypeMedicaidRenewalFilterPdmTimeclock(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeMedicaidRenewalFilterPdmTimeclock(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update DAYS_BEFORE_TO_PICK_STREAMLINE As "30"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update DAYS_BEFORE_TO_PICK_STREAMLINE As \"(.*?)\"$")
	public void updateConfigTypeDaysBeforeToPickStreamline(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeDaysBeforeToPickStreamline(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update DAYS_BEFORE_TO_PICK_NORMAL_MH As "0"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update DAYS_BEFORE_TO_PICK_NORMAL_MH As \"(.*?)\"$")
	public void updateConfigTypeDaysBeforeToPickNormalMH(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeDaysBeforeToPickNormalMH(newValue);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update DAYS_BEFORE_TO_PICK_ALL As "true"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update DAYS_BEFORE_TO_PICK_ALL As \"(.*?)\"$")
	public void updateConfigTypeDaysBeforeToPickAll(String newValue) throws Exception {
		RenewalConfigTable renewalConfigTable = new RenewalConfigTable(conn, testCaseId);
		renewalConfigTable.updateConfigTypeDaysBeforeToPickAll(newValue);
	}
	
}
