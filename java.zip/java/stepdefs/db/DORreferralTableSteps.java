package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;
import cucumber.api.java.en.Then;
import db.DOReventTriggersTable;
import db.DORreferralUnitTable;
import db.DORreferralRecordTrackerTable;
import db.DORreferralRecordInterfaceTable;
import db.ElgMemberTable;

public class DORreferralTableSteps extends SuperStepDef {

	
	
	public DORreferralTableSteps(Hook hook)  {
		super(hook);
	}
	
	/**@author ppinho
	 * 	Available Notice_Type :- PROCESSED
		
		From DOReventTriggers Table, Using EligId With Variable As "CurrentEligibilityId", Validate DOR Event Triggers Status As "PROCESSED"
	
	**/ 
	@Then("^From DOReventTriggers Table, Using EligId With Variable As \"(.*?)\", Validate DOR Event Triggers Status As \"(.*?)\"$")
	public void validateDOReventTriggersStatus(String varibleNameFrElgId, String expStatus) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		
		DOReventTriggersTable DOReventTrigger = new DOReventTriggersTable(conn, testCaseId);
		DOReventTrigger.validateStatus(eligibilityId, expStatus);
	}
	
	/**@author ppinho
	 * 	Available Notice_Type :- PROCESSED
		
		From DORreferralUnit Table, Using EligId With Variable As "CurrentEligibilityId", For Member "3", Validate DOR Referral Units Status As "PROCESSED"
	
	**/ 
	@Then("^From DORreferralUnit Table, Using EligId With Variable As \"(.*?)\", For Member \"(.*?)\", Validate DOR Referral Units Status As \"(.*?)\"$")
	public void validateDORreferralUnitStatus(String varibleNameFrElgId, String memNo, String expStatus) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memFName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String memLName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		DORreferralUnitTable DORreferralUnit = new DORreferralUnitTable(conn, testCaseId);
		DORreferralUnit.validateStatus(eligibilityId, memFName, memLName, expStatus);
	}
	
	/**@author ppinho
	 * 	Available Notice_Type :- PROCESSED
		
		From DORreferralRecordTracker Table, Using EligId With Variable As "CurrentEligibilityId", For Member "3", Validate DOR Referral Record Tracker Status As "PROCESSED"
	
	**/ 
	@Then("^From DORreferralRecordTracker Table, Using EligId With Variable As \"(.*?)\", For Member \"(.*?)\", Validate DOR Referral Record Tracker Status As \"(.*?)\"$")
	public void validateDORreferralRecordTrackerStatus(String varibleNameFrElgId, String memNo, String expStatus) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memFName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String memLName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		DORreferralRecordTrackerTable DORreferralRecordTracker = new DORreferralRecordTrackerTable(conn, testCaseId);
		DORreferralRecordTracker.validateStatus(eligibilityId, memFName, memLName, expStatus);
	}
	
	/**@author ppinho
	 * 	Available Notice_Type :- PROCESSED
		
		From DORreferralRecordInterface Table, Using EligId With Variable As "CurrentEligibilityId", For Member "3", Validate DOR Referral Record Interface Table Status As "PROCESSED"
	
	**/ 
	@Then("^From DORreferralRecordInterface Table, Using EligId With Variable As \"(.*?)\", For Member \"(.*?)\", Validate DOR Referral Record Interface Table Status As \"(.*?)\"$")
	public void validateDORreferralRecordInterfaceTableStatus(String varibleNameFrElgId, String memNo, String expStatus) throws Throwable {
		String eligibilityId = TestData.getTempTestData(varibleNameFrElgId, featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memFName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String memLName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		DORreferralRecordInterfaceTable dorReferralRecordInterface = new DORreferralRecordInterfaceTable(conn, testCaseId);
		dorReferralRecordInterface.validateStatus(eligibilityId, memFName, memLName, expStatus);
	}
	
}
