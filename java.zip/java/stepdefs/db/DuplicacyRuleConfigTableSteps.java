package stepdefs.db;
import cucumber.api.java.en.Given;
import db.DuplicacyRuleConfigTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class DuplicacyRuleConfigTableSteps extends SuperStepDef
{

	
	public DuplicacyRuleConfigTableSteps(Hook hook) {
		super(hook);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update VHC And HC Rule As BLOCK For ID "6"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update VHC And HC Rule As BLOCK For ID \"(.*?)\"$")
	public void updateVHCAndHCRuleActionAsBockForId(String id) throws Exception {
		int intId = Integer.parseInt(id);
		
		DuplicacyRuleConfigTable duplicacyRuleConfigTable = new DuplicacyRuleConfigTable(conn, testCaseId);
		duplicacyRuleConfigTable.updateVHCAndHCRuleActionAsBockForId(intId);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update VHC_RULE_ACTION Value As "BLOCK" For ID "6"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update VHC_RULE_ACTION Value As \"(.*?)\" For ID \"(.*?)\"$")
	public void updateVHCAndHCRuleActionAsBockForId(String vhcRuleAction, String id) throws Exception {
		int intId = Integer.parseInt(id);
		
		DuplicacyRuleConfigTable duplicacyRuleConfigTable = new DuplicacyRuleConfigTable(conn, testCaseId);
		duplicacyRuleConfigTable.updateVHCRuleActionForId(vhcRuleAction, intId);
	}
	
	/**@author vkuma212
	 
	 From DuplicacyRuleConfigTable, Update HC_RULE_ACTION Value As "BLOCK" For ID "6"
	 
	 Note : After this Action , Server Bounce Is required
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Update HC_RULE_ACTION Value As \"(.*?)\" For ID \"(.*?)\"$")
	public void updateHCAndHCRuleActionAsBockForId(String hcRuleAction, String id) throws Exception {
		int intId = Integer.parseInt(id);
		
		DuplicacyRuleConfigTable duplicacyRuleConfigTable = new DuplicacyRuleConfigTable(conn, testCaseId);
		duplicacyRuleConfigTable.updateHCRuleActionForId(hcRuleAction, intId);
	}
	
	/*Anubhuti
	 
	 From DuplicacyRuleConfigTable, Validate HC_RULE_ACTION For ID "6" As "WARN"
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Validate HC_RULE_ACTION For ID \"(.*?)\" As \"(.*?)\"$")
	public void getHCRuleActionById(String id, String exphcRule) throws Exception {
		int intId = Integer.parseInt(id);
		
		DuplicacyRuleConfigTable duplicacyRuleConfigTable = new DuplicacyRuleConfigTable(conn, testCaseId);
		duplicacyRuleConfigTable.validateVHCRuleActionById(intId, exphcRule);
	}
	
	/*Anubhuti
	 
	 From DuplicacyRuleConfigTable, Validate VHC_RULE_ACTION For ID "6" As "WARN"
	 From DuplicacyRuleConfigTable, Validate VHC_RULE_ACTION For ID "6" As "BLOCK"
	 
	 */
	@Given("^From DuplicacyRuleConfigTable, Validate VHC_RULE_ACTION For ID \"(.*?)\" As \"(.*?)\"$")
	public void getVHCRuleActionById(String id, String expVHCRule) throws Exception {
		int intId = Integer.parseInt(id);
		
		DuplicacyRuleConfigTable duplicacyRuleConfigTable = new DuplicacyRuleConfigTable(conn, testCaseId);
		duplicacyRuleConfigTable.validateVHCRuleActionById(intId, expVHCRule);
	}
	
}
