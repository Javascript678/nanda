package stepdefs.db;

import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import db.EligibilityTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class ElgMemberTableSteps extends SuperStepDef {

	public ElgMemberTableSteps(Hook hook) {
		super(hook);
	}

	@Given("^From ElgEmberTable, Update DOB For Member \"(.*?)\" Prior From Currrent DOB As \"(.*?)\"$")
	public void updateDobForMember(String memNo, String priorFromTOdayPattern) throws Exception {

		int memIndex = Integer.parseInt(memNo)-1;
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String firstName = elg_MemberTable.getFirstName(elgId, memIndex);
		String lastName = elg_MemberTable.getLastName(elgId, memIndex);
		String dob = elg_MemberTable.getDOB(elgId, memIndex);

		String newDob = DateUtil.getPriorDateInDBFormatUsingPattern(dob, DateUtil.dbDatePattern, priorFromTOdayPattern);
		elg_MemberTable.updateDateOfBirth(elgId, firstName, lastName, newDob);
	}
	
	/*Ritu 
	 * From ElgEmberTable, Update LastName As "AA" For Member "1" 
	 * */
	@Given("^From ElgEmberTable, Update LastName As \"(.*?)\" For Member \"(.*?)\"$")
	public void updateLastNameForMember(String lName, String memNo) throws Exception {

		int memIndex = Integer.parseInt(memNo)-1;
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		elg_MemberTable.updateLastName(elgId, memIndex, lName);
	}
	
		/**Aashita 

	   		From ElgEmberTable, Update MMIS AppDate As "90" Days Prior From Currrent app date
	   */
		@Given("^From ElgEmberTable, Update MMIS AppDate As \"(.*?)\" Days Prior From Currrent app date$")
		public void updateMMISAppDate(String newMMISDateToSetPriorFromToday) throws Exception {
			String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
	
			EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
			String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
			String appDate = TestData.getTempTestData("AppDate", featureFileName);
			String newMMISDateToSet = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.dateFormatDB3, "00:00:"+newMMISDateToSetPriorFromToday);
			ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
			elg_MemberTable.updateMMISdateForElgId(elgId, newMMISDateToSet);
	}
	
}
