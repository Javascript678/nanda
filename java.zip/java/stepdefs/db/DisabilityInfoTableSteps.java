package stepdefs.db;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import db.DisabilityInfoHistoryTable;
import db.DisabilityInfoTable;
import db.MaHubRequestResponseTable;
import db.RrvTdsReqResCtrlTable;


public class DisabilityInfoTableSteps extends SuperStepDef {

	
	
	public DisabilityInfoTableSteps(Hook hook)  {
		super(hook);
	}
	
	//Vimal
	@Then("^From DisabilityInfo Table, Store Completed Data into Excel folder$")
	public void storeCompleteDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		DisabilityInfoTable disabilityInfoTable =new DisabilityInfoTable(conn, testCaseId);
		disabilityInfoTable.storeCompleteDataInExcel(elgId);
	}
	
	//Vimal
	@Then("^From DisabilityInfo Table, Store Hub Request Reponse Data into Excel folder$")
	public void storeHubRequestReponseDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		DisabilityInfoTable disabilityInfoTable =new DisabilityInfoTable(conn, testCaseId);
		disabilityInfoTable.storeHubRequestReponseDataInExcel(elgId);
	}
	
	/**@author Ritu

	DisabilityInfoTable, Make disable one member using memeberNO  "1"
	
	 */
	@Given("^DisabilityInfoTable, Make disable one member using memeberNO  \"(.*?)\"$")
	public void makeAMemberDisable(String memNo) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		int memIndex = Integer.parseInt(memNo)-1;
		String mmisIdColumnValue="NULL";
		String genderColumnvalue="F";
		String isDisableColumnValue="1";
		String disablityTypeColumnValue="BL";
		String disablitySourceColumnValue="MA_21";
		String medicareCVGStartDateColumnValue="NULL";
		String medicareCVGEndDateColumnValue="NULL";
		String disabilityEffStartDateColumnValue=DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:00");
		String disabilityEffEndDateColumnValue="NULL";
		String desDeterminationDateColumnValue=DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:00");
		String isWaivedColumnValue="NULL";
		String disabilityRenewalDateColumnValue=DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:00");
		String createdDateColumnValue=DateUtil.getPriorDateInDBUpdateFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:00");
		String updatedByColumnValue="NULL";
		String updatedDateColumnValue="NULL";
		String personIdColumnValue="NULL";
		String SSNColumnValue="NULL";
		
		DisabilityInfoTable disabilityInfoTable = new DisabilityInfoTable(conn, testCaseId);
		
		disabilityInfoTable.addRowInDisablityTable(userProfileRefId, memIndex, mmisIdColumnValue, genderColumnvalue, isDisableColumnValue, disablityTypeColumnValue, disablitySourceColumnValue, medicareCVGStartDateColumnValue, medicareCVGEndDateColumnValue, disabilityEffStartDateColumnValue, disabilityEffEndDateColumnValue, desDeterminationDateColumnValue, isWaivedColumnValue, disabilityRenewalDateColumnValue, createdDateColumnValue, updatedByColumnValue, updatedDateColumnValue, personIdColumnValue, SSNColumnValue);
		
	}
	
	@Then("^From DisabilityInfo Table, Update Disability Status For Each Member$")
	public void updateDisabilityStatusForEachMember() throws Throwable {
		RrvTdsReqResCtrlTable rrvTdsReqResCtrlTable = new RrvTdsReqResCtrlTable(conn, testCaseId);
		
		MaHubRequestResponseTable maHubRequestResponseTable = new MaHubRequestResponseTable(conn, testCaseId);
		
		String userRefId = evpdData.memsData.get(0).userRefId;
				
		for(int memInd = 0; memInd < evpdData.memCount; memInd++){
			if(initialPrelimData.memsData.get(memInd).hasDisability){				
				if(initialPrelimData.memsData.get(0).rrvSsaDisability.contains("ERROR")){					
					String[] error = initialPrelimData.memsData.get(0).rrvSsaDisability.split(":");
					maHubRequestResponseTable.ccaRenewalSsaErrorUpdateQuery(userRefId, 0, error[1]);
				}else if(initialPrelimData.memsData.get(memInd).rrvSsaDisability.equals("0")){
					rrvTdsReqResCtrlTable.ccaRenewalResXmlDisabilityUpdateQuery(evpdData.memsData.get(0).userRefId, memInd, "true", "false");
				}else if(initialPrelimData.memsData.get(memInd).rrvSsaDisability.equals("1")){
					rrvTdsReqResCtrlTable.ccaRenewalResXmlDisabilityUpdateQuery(evpdData.memsData.get(0).userRefId, memInd, "false", "true");
				}
			}
		}		
	}
}
