/**
 * 
 */
package stepdefs.db;

import cucumber.api.java.en.Then;
import db.ElgMemberIncomeDorTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

/**
 * @author vverma25
 *
 */
public class ElgMemberIncomeDorTableSteps extends SuperStepDef {

	public ElgMemberIncomeDorTableSteps(Hook hook) {
		super(hook);
		// TODO Auto-generated constructor stub
	}
	
	//Vimal
	@Then("^From Elg Member Income Dor Table, Store Completed Data into Excel folder$")
	public void storeCompleteDataInExcel() throws Throwable {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		ElgMemberIncomeDorTable elgMemberIncomeDor = new ElgMemberIncomeDorTable(conn, testCaseId);
		elgMemberIncomeDor.storeCompleteDataInExcel(elgId);
	}

}
