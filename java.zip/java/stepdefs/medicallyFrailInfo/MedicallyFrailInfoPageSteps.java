package stepdefs.medicallyFrailInfo;


import pages.medicallyFrailInfo.MedicallyFrailInfoPage;
import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;



public class MedicallyFrailInfoPageSteps extends SuperStepDef {

public MedicallyFrailInfoPageSteps(Hook hook){
		super(hook);
	}

/*
 * Disability Code: DA,MA,BL
 * From MedicallyFrail Info Page,Select Medically Frail for member "1" As "TRUE" And EffectiveStartdate As""
 * */
@Given("^From MedicallyFrail Info Page,Select Medically Frail for member \"(.*?)\" As \"(.*?)\" and EffectiveStartdate As \"(.*?)\" days prior from app date$")
public void selectDisabilityAndRerun(String memno,String isMedicallyFrailed, String effectiveStartDate) throws Exception {
	String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
	String appDate = TestData.getTempTestData("AppDate", featureFileName);
	 MedicallyFrailInfoPage  medicallyFrailInfoPage= new  MedicallyFrailInfoPage(driver, testCaseId);
	int memIndex=Integer.parseInt(memno)-1;
     ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
     boolean isMedicallyFrail= isMedicallyFrailed.equalsIgnoreCase("TRUE")?true:false;
	 String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
	 String effectiveStartsDate= DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+effectiveStartDate);
      medicallyFrailInfoPage.selectMedicallyFrailAndRerun(name,memIndex, isMedicallyFrail, effectiveStartsDate);
	
}


}
