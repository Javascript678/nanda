package stepdefs.microservice;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;

import appdata.common.MicroserviceRequestData;
import appdata.common.ShellScriptCredentials;
import appdata.common.SqlCredentials;
import appdata.common.TempData;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.EnrollmentTable;
import db.RrvBatchReqCtrlTable;
import db.ShoppingGroupTable;
import enums.BatchJob_Workflow_ID_Mapping;
import mysql.MySQL_Conn_Data;
import shell.ShellScriptRepo;
import utils.HttpsClient;
import utils.TestData;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class MicroserviceSteps extends SuperStepDef{

	public MicroserviceSteps(Hook hook){
		super(hook);
	}
	
	/**@author: ppinho
	 * 
	 *	Using Microservice, Set "column" Equal To "value" For "table" Table In MySQL DB
	 *
	 */
	@Given("^Using Microservice, Set \"(.*?)\" Equal To \"(.*?)\" For \"(.*?)\" Table In MySQL DB$")
	public void saveTempDataInMySQL(String column, String value, String table) throws Exception {
		String ipAddress = globalData.get("Local_IP_Address").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		String dataSet = getTempTestData("DataSet");
		String schema = globalData.get("mysql_schema").trim();

		TempData tempData = new TempData();
		
		tempData.sqlScript = "update " + schema + "." + table + 
							 " set " + table + "." + column + " = '" + value + "'" +
							 " where " + table + ".scenario = '" + featureFileName + "'" +
							 " and " + table + ".mem_id = 'M1'";
				
		HttpsClient httpClient = new HttpsClient();		
		httpClient.updateTempDataMS(ipAddress, username, password, dataSet, TempData.updateTempDataRequest(tempData));
	}
	
	/**@author ppinho
	 *			
	 * Using Microervice Run Batch Job Sequences On Given Environment
	 *		| cvbf        | phase |
	 *		| ccaRenewals | 1     |
	 *
	 */
	@Given("^Using Microservice, Run Batch Job Sequences On Given Environment$")
	public void submitWorkFLow(DataTable table) throws Exception{
		List<List<String>> batchJobData = table.raw();
		
		HttpsClient httpsClient = new HttpsClient();
		
		String batchIpAddress = globalData.get("AWS_Server_Domain").trim();
		String localIpAddress = globalData.get("Local_IP_Address").trim();
		String env = globalData.get("Environment").trim().toLowerCase();
		
		for(int rowIndex = 1; rowIndex < batchJobData.size(); rowIndex++){			
			JSONArray batchJobSequences = new JSONArray(httpsClient.batchJobSequenceMS(localIpAddress, env, batchJobData.get(rowIndex)).split(":"));
			
			for(int i = 0; i < batchJobSequences.length(); i++){
				String workflowID = BatchJob_Workflow_ID_Mapping.getWorkflowId(batchJobSequences.get(i).toString());
				String batchJobWorkRunId = httpsClient.batchJobRunMS(batchIpAddress, env, workflowID);
				
				hook.checkIfTempDataExists();
				storeTempTestData("BatchJobWorkRunId", batchJobWorkRunId);
				
				ensureWorkFlowIsCompletedSuccessfully();
			}
		}
	}
	
	

	
	/*
	public String enrollmentId(String dbColumn, String firstName,String lastName,String elgID,String coverageType) throws Exception {
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		
		SqlCredentials sqlCredentials = TestData.getSqlCredentials(globalData);		
		sqlCredentials.sqlScript ="SELECT *  FROM MAHX_OWN.ENROLLMENT WHERE SHOPPING_GROUP_ID IN(SELECT ID  FROM MAHX_OWN.SHOPPING_GROUP WHERE  COVERAGE_TYPE = '"+coverageType+
				"' AND  SUBSCRIBER_MEMBER_ID IN(SELECT ID  FROM MAHX_OWN.ELG_MEMBER WHERE ELIGIBILITY_ID = "+elgID+"  AND FIRST_NAME = '"+firstName+"' AND LAST_NAME =  '"+lastName+"'))";
		
		System.out.println(sqlCredentials.sqlScript);
		
		sqlCredentials.dbColumn = dbColumn;
		
		
		HttpsClient httpClient = new HttpsClient();		
		JSONObject response = httpClient.runSelectQueryMS(ipAddress, username, password, SqlCredentials.sqlSelectRequestData(sqlCredentials));
		//System.out.println("res " + response.toString());
		JSONArray name = response.getJSONArray("names");
		int index = 0;
		for (index = 0; index < name.length(); index++) {
			if (name.getString(index).equalsIgnoreCase("ID")) {
				break;
			}
		}
		
		String cellValue = null;
		
		if (index < name.length()) {
			
			cellValue = response.getJSONArray("values").getJSONArray(1).getString(index);
			
		}
		System.err.println("dsasda  " + cellValue);
		
		
		return cellValue;	}
	
	*/
	
	public String enrollId(String firstName,String lastName,String elgID,String coverageType) throws Exception
	{
		ShoppingGroupTable shoppingGroupTable=new ShoppingGroupTable(conn, testCaseId);
		String shoppingid=shoppingGroupTable.getId(elgID, firstName, lastName, coverageType);
		//EnrollmentTable enrollmentTable = new EnrollmentTable(conn, testCaseId);
		//String id=enrollmentTable.getId(shoppingid);
		return shoppingid;
		
		
	}
	
	public String getXmlValueForENBNoShoppingSecondRow(String dbColumn, String firstName,String lastName,String elgID,String coverageType) throws Exception {
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		
		SqlCredentials sqlCredentials = TestData.getSqlCredentials(globalData);		
		sqlCredentials.sqlScript ="select * from (select * from(SELECT *  FROM MAHX_OWN.ENRL_XML_INPUT_CTRL WHERE BATCH_XML_CTRL_ID IN(select ID from mahx_own.batch_enrollment_xml_control where action='"+coverageType+
				"' and user_profile_id IN (select user_profile_id from mahx_own.eligibility where id='"+elgID+"'))order by id desc)order by id) where rownum=1";
		
		System.out.println(sqlCredentials.sqlScript);
		
		sqlCredentials.dbColumn = dbColumn;
		
		HttpsClient httpClient = new HttpsClient();		
		String xml = httpClient.runXmlQueryMS(ipAddress, username, password, sqlCredentials.sqlXmlRequestData(sqlCredentials));
		System.out.println("XML is getting fetched correctly as - "+xml);
		return xml;
	}
	
	public String getXmlValueForENBNoShopping(String dbColumn, String firstName,String lastName,String elgID,String coverageType) throws Exception {
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		
		SqlCredentials sqlCredentials = TestData.getSqlCredentials(globalData);		
		sqlCredentials.sqlScript ="SELECT *  FROM MAHX_OWN.ENRL_XML_INPUT_CTRL WHERE BATCH_XML_CTRL_ID IN(select ID from mahx_own.batch_enrollment_xml_control where action='"+coverageType+"' "
				+ "and user_profile_id IN (select user_profile_id from mahx_own.eligibility where id='"+elgID+"'))";
		
		System.out.println(sqlCredentials.sqlScript);
		
		sqlCredentials.dbColumn = dbColumn;
		
		HttpsClient httpClient = new HttpsClient();		
		String xml = httpClient.runXmlQueryMS(ipAddress, username, password, sqlCredentials.sqlXmlRequestData(sqlCredentials));
		System.out.println("XML is getting fetched correctly as - "+xml);
		return xml;
	}
	
	
	public String getXmlValueForENBNoShoppingTopRow(String dbColumn, String firstName,String lastName,String elgID,String coverageType) throws Exception {
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		
		SqlCredentials sqlCredentials = TestData.getSqlCredentials(globalData);		
		sqlCredentials.sqlScript ="select * from(SELECT *  FROM MAHX_OWN.ENRL_XML_INPUT_CTRL WHERE BATCH_XML_CTRL_ID IN(select ID from mahx_own.batch_enrollment_xml_control where action='"+coverageType+
				"' and user_profile_id IN (select user_profile_id from mahx_own.eligibility where id='"+elgID+"'))order by id desc) where rownum=1";
		
		System.out.println(sqlCredentials.sqlScript);
		
		sqlCredentials.dbColumn = dbColumn;
		
		HttpsClient httpClient = new HttpsClient();		
		String xml = httpClient.runXmlQueryMS(ipAddress, username, password, sqlCredentials.sqlXmlRequestData(sqlCredentials));
		System.out.println("XML is getting fetched correctly as - "+xml);
		return xml;
	}
	
	public String getXmlValueForENB(String dbColumn, String firstName,String lastName,String elgID,String coverageType,String action) throws Exception {
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		
		SqlCredentials sqlCredentials = TestData.getSqlCredentials(globalData);		
		sqlCredentials.sqlScript ="SELECT *  FROM MAHX_OWN.ENRL_XML_INPUT_CTRL WHERE BATCH_XML_CTRL_ID IN(SELECT ID  FROM MAHX_OWN.BATCH_ENROLLMENT_XML_CONTROL WHERE ACTION = '"+coverageType
				+"' AND ENROLLMENT_ID IN( SELECT ID  FROM MAHX_OWN.ENROLLMENT WHERE SHOPPING_GROUP_ID IN(SELECT ID  FROM MAHX_OWN.SHOPPING_GROUP WHERE  COVERAGE_TYPE = '"+action+"' AND  SUBSCRIBER_MEMBER_ID IN"
				+ "(SELECT ID  FROM MAHX_OWN.ELG_MEMBER WHERE ELIGIBILITY_ID = "+elgID+ " AND FIRST_NAME = '"+firstName+"' AND LAST_NAME =  '"+lastName+"'))))";
		
		System.out.println(sqlCredentials.sqlScript);
		
		sqlCredentials.dbColumn = dbColumn;
		
		HttpsClient httpClient = new HttpsClient();		
		String xml = httpClient.runXmlQueryMS(ipAddress, username, password, sqlCredentials.sqlXmlRequestData(sqlCredentials));
		System.out.println("XML is getting fetched correctly as - "+xml);
		return xml;
	}


	/**@author Ritika
 	 *
	 */
	@Given("^Using Microservice, Ensure WorkFlow is Completed Successfully$")
	public void ensureWorkFlowIsCompletedSuccessfully() throws Exception{
		String batchJobWorkRunId = getTempTestData("BatchJobWorkRunId");
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		
		HttpsClient httpsClient = new HttpsClient();

		while(true) {
			String currentStatus = httpsClient.batchJobStatusMS(ipAddress, batchJobWorkRunId);
			String completed = "\"COMPLETED\"";

			if(currentStatus.equals(completed)){
				System.out.println("Status is completed");
				break;
			}
			
			Thread.sleep(20000);
		}
	}
	
	 /** @author ppinho
	 * 
	 *  Using Micro Services Check System Date Is "09/04/2019"
	 *  
	 */
	@Given("^Using Microservice, Check System Date Is \"(.*?)\"$")
	public void checkSystemDate(String dateRequested) throws Exception{
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String appServer = envData.get("App_Server");
	
		HttpsClient dateCheck = new HttpsClient();
			
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("MM/dd/yyyy");
		
		String targetDate = sdf2.format(sdf1.parse(dateRequested));		
		
		try{
			if(dateCheck.checkAppServer(ipAddress, appServer).equals(targetDate)){				
				System.out.println("Date has been changed");			
			}
		}catch (Exception e){
			Assert.fail("Date was not changed succefully");
		}
	}
	
	 /** @author ppinho
	 * 
	 *  Using Micro Services Send Request To Change Date To "09/04/2019"
	 */
	@Given("^Using Microservice, Send Request To Change Date To \"(.*?)\"$")
	public void timeTravelRequest(String requestDate) throws Exception {
		JSONArray propertyChangeList = new JSONArray();
		
		String ipAddress = globalData.get("Local_IP_Address").trim();
		String env = globalData.get("Environment").trim().toLowerCase();
		String runId = globalData.get("TimeTravelRunId").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		String batchServer = envData.get("Batch_Server");
		
		MicroserviceRequestData microserviceRequestData = TestData.getTimeTravelData(globalData);
		microserviceRequestData.newDate = requestDate;
		microserviceRequestData.changeServerList = envData.get("Change_Server_List");
		
		HttpsClient httpClient = new HttpsClient();
		
		String batchJobWorkRunId = httpClient.timeTravelRequestMS(ipAddress, env, runId, batchServer, timeTravelRequestData(microserviceRequestData), propertyChangeList, username, password);
		
		hook.checkIfTempDataExists();
		storeTempTestData("BatchJobWorkRunId", batchJobWorkRunId);
	}
	
	/**@author ppinho
	 * 
	 *	Using Micro Services Send Request To Execute Query In MA HIX DB
	 *		| Index | Database | Type   | Query                             | Value |
	 *		| 1		| QA       | Select | select * from mahx_own.elg_member |       |
	 */
	@Given("^Using Microservice, Send Request To Execute Query In MA HIX DB$")
	public void queryExecutionRequest(DataTable table) throws Exception {
		List<List<String>> propertyChangeData = table.raw();
		
		String ipAddress = globalData.get("Local_IP_Address").trim();
		String env = globalData.get("Environment").trim().toLowerCase();
		String runId = globalData.get("TimeTravelRunId").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		String batchServer = envData.get("Batch_Server");
		
		MicroserviceRequestData microserviceRequestData = TestData.getQueryExecutionData(globalData);
		microserviceRequestData.changeServerList = envData.get("Change_Server_List");
		
		HttpsClient httpClient = new HttpsClient();
		
		String batchJobWorkRunId = httpClient.timeTravelRequestMS(ipAddress, env, runId, batchServer, timeTravelRequestData(microserviceRequestData), propertyChangeRequestData(propertyChangeData), username, password);
		
		hook.checkIfTempDataExists();
		storeTempTestData("BatchJobWorkRunId", batchJobWorkRunId);
	}
	
	/**@author ppinho
	 * 
	 *	Using Micro Services Send Request To Set Property Value
	 *		| Index | Server           | File | Property                       | Value |
	 *		| 1		| OS-apsrd3469-dev |      | MH.Pended.bypass               | FALSE |
	 *		| 2		| OS-apsrd3316     |      | MH.AdditionalThreshold.bypass  | FALSE |
	 */
	@Given("^Using Microservice, Send Request To Set Property Value$")
	public void propertyChangeRequest(DataTable table) throws Exception {
		List<List<String>> propertyChangeData = table.raw();
		
		String appDate = null;
		
		String ipAddress = globalData.get("Local_IP_Address").trim();
		String env = globalData.get("Environment").trim().toLowerCase();
		String runId = globalData.get("TimeTravelRunId").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		String batchServer = envData.get("Batch_Server");
		
		MicroserviceRequestData microserviceRequestData = TestData.getPropertyChangeData(globalData);
		microserviceRequestData.changeServerList = envData.get("Change_Server_List");
		
		HttpsClient httpClient = new HttpsClient();
		
		String batchJobWorkRunId = httpClient.timeTravelRequestMS(ipAddress, env, runId, batchServer, timeTravelRequestData(microserviceRequestData), propertyChangeRequestData(propertyChangeData), username, password);
		
		hook.checkIfTempDataExists();
		storeTempTestData("BatchJobWorkRunId", batchJobWorkRunId);
	}
	
	/**@author ppinho
	 * 
	 *	Using Micro Services Send Request To Change Date To "09/04/2019" And Set Property Value
	 *		| Index | Server           | File | Property                       | Value |
	 *		| 1		| OS-apsrd3469-dev |      | MH.Pended.bypass               | FALSE |
	 *		| 2		| OS-apsrd3316     |      | MH.AdditionalThreshold.bypass  | FALSE |
	 */
	@Given("^Using Microservice, Send Request To Change Date To \"(.*?)\" And Set Property Value$")
	public void timeTravelAndPropertyChangeRequest(String requestDate, DataTable table) throws Exception {
		List<List<String>> propertyChangeData = table.raw();
		
		String ipAddress = globalData.get("Local_IP_Address").trim();
		String env = globalData.get("Environment").trim().toLowerCase();
		String runId = globalData.get("TimeTravelRunId").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		String batchServer = envData.get("Batch_Server");
		
		MicroserviceRequestData microserviceRequestData = TestData.getTimeTravelPropertyChangeData(globalData);
		microserviceRequestData.newDate = requestDate;
		microserviceRequestData.changeServerList = envData.get("Change_Server_List");
		
		HttpsClient httpClient = new HttpsClient();
		String batchJobWorkRunId = httpClient.timeTravelRequestMS(ipAddress, env, runId, batchServer, timeTravelRequestData(microserviceRequestData), propertyChangeRequestData(propertyChangeData), username, password);
		
		hook.checkIfTempDataExists();
		storeTempTestData("BatchJobWorkRunId", batchJobWorkRunId);
	}
	
	/**@author: ppinho
	 * 
	 *	Using Micro Services Send Request To Run Select Query On Given Env
	 */
	@Given("^Using Microservice, Send Request To Run Select Query On Given Env$")
	public void runSelectQuery() throws Exception {		
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		
		SqlCredentials sqlCredentials = TestData.getSqlCredentials(globalData);
		sqlCredentials.sqlScript = "select * from mahx_own.elg_member";
		
		HttpsClient httpClient = new HttpsClient();		
		httpClient.runSelectQueryMS(ipAddress, username, password, SqlCredentials.sqlSelectRequestData(sqlCredentials));
	}
	
	/**@author: ppinho
	 * 
	 *	Using Micro Services Send Request To Run Update Query On Given Env
	 *
	 */
	@Given("^Using Microservice, Send Request To Run Update Query On Given Env$")
	public void runUpdateQuery() throws Exception {
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		
		SqlCredentials sqlCredentials = TestData.getSqlCredentials(globalData);		
		sqlCredentials.sqlScript = "update mahx_own.elg_member_citizenship set status_award_date='24-DEC-2013' where elg_member_id in(select id from mahx_own.elg_member where eligibility_id in(292264182))";
		
		HttpsClient httpClient = new HttpsClient();		
		httpClient.runUpdateQueryMS(ipAddress, username, password, SqlCredentials.sqlUpdateRequestData(sqlCredentials));
	}
	
	/**@author: ppinho
	 * 
	 *	Using Micro Services Send Request To Get XML From "XML_REQUEST" On Given Env
	 *
	 */
	@Given("^Using Microservice, Send Request To Get XML From \"(.*?)\" On Given Env$")
	public void getXmlQuery(String dbColumn) throws Exception {
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		
		SqlCredentials sqlCredentials = TestData.getSqlCredentials(globalData);		
		sqlCredentials.sqlScript = "select * from mahx_own.MMIS_POST_ELG_CONTROL_DATA where ELG_MEMBER_ID = 28307542";
		sqlCredentials.dbColumn = dbColumn;
		
		HttpsClient httpClient = new HttpsClient();		
		httpClient.runXmlQueryMS(ipAddress, username, password, SqlCredentials.sqlXmlRequestData(sqlCredentials));
	}
	
	/**@author: ppinho
	 * 
	 *	Using Microservice, Send Request To Run "RrvGeneration" Shell Script On Given Env
	 */
	@Given("^Using Microservice, Send Request To Run \"(.*?)\" Shell Script On Given Env$")
	public void runShellScript(String shellScript) throws Exception {		
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		
		ShellScriptRepo shellScriptRepo = new ShellScriptRepo(conn, testCaseId);
		
		ShellScriptCredentials shellScriptCredentials = TestData.getShellScriptCredentials(globalData, envData);
		shellScriptCredentials.commands = shellScriptRepo.getShellScript(shellScript, evpdData.memsData.get(0).userRefId);
		
		HttpsClient httpClient = new HttpsClient();		
		httpClient.runShellScriptMS(ipAddress, username, password, ShellScriptCredentials.shellScriptRequestData(shellScriptCredentials));
	}
	
	/**@author: ppinho
	 * 
	 *	Using Micro Services Send Request To Get System Date From Given Env
	 *
	 */
	@Given("^Using Microservice, Send Request To Get System Date From Given Env$")
	public void getSysDate() throws Exception {
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String username = globalData.get("username").trim().toLowerCase();
		String password = globalData.get("password").trim();
		
		SqlCredentials sqlCredentials = TestData.getSqlCredentials(globalData);
		
		HttpsClient httpClient = new HttpsClient();		
		httpClient.runSysDateQueryMS(ipAddress, username, password, SqlCredentials.sqlSysDateData(sqlCredentials));
	}
	
	 /** @author: ppinho
	 */
	private String[] timeTravelRequestData(MicroserviceRequestData microserviceRequestData){
		
		String[] timeTravelRequestArr = {microserviceRequestData.templateName,
										 microserviceRequestData.emailServerId,
										 microserviceRequestData.authCredentialId,
										 microserviceRequestData.fromUser,
										 microserviceRequestData.notifyList,
										 microserviceRequestData.approverList,
										 microserviceRequestData.operatorList,
										 microserviceRequestData.gatekeeperList,
										 microserviceRequestData.notificationTemplate,
										 microserviceRequestData.approvalTemplate,
										 microserviceRequestData.changeRequestTemplate,
										 microserviceRequestData.gateKeeperTemplate,
										 microserviceRequestData.newDate,
										 microserviceRequestData.changeServerList};
		
		return timeTravelRequestArr;
	}
	
	 /** @author ppinho
	 */
	private JSONArray propertyChangeRequestData(List<List<String>> propertyChangeData){
		JSONArray propertyChangeListArr = new JSONArray();
		JSONObject propertyChangeItem = new JSONObject();
		
		int rowCount = propertyChangeData.size();
		
		for(int rowIndex = 1; rowIndex < rowCount; rowIndex++){
			try{			
				propertyChangeItem.put("server", propertyChangeData.get(rowIndex).get(1));
				propertyChangeItem.put("file", propertyChangeData.get(rowIndex).get(2));
				propertyChangeItem.put("prop", propertyChangeData.get(rowIndex).get(3));
				propertyChangeItem.put("newValue", propertyChangeData.get(rowIndex).get(4));
				propertyChangeListArr.put(propertyChangeItem);
				
			}catch (JSONException e) {
				e.printStackTrace();
			}				
		}
		
		return propertyChangeListArr;
	}
	
	 /** @author ppinho
	 */
	public String getSystemDate() throws Exception{
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		String appServer = envData.get("App_Server");
	
		HttpsClient date = new HttpsClient();
		String systemDate = date.checkAppServer(ipAddress, appServer);
		
		return systemDate;
	}
	
}
