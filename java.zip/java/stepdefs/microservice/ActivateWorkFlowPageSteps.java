package stepdefs.microservice;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import enums.BatchJob_EnvServerMapping;
import enums.BatchJob_Workflow_ID_Mapping;
import pages.batchJob.ActivateWorkFlowPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ActivateWorkFlowPageSteps extends SuperStepDef{
	
	public ActivateWorkFlowPageSteps(Hook hook){
		super(hook);
	}
	
	@Given("^Go to Active Workflow Page$")
	public void goToWorkFlowActivity() throws Exception {
		
		String ipAddress = globalData.get("AWS_Server_Domain").trim();
		
		System.out.println("Batch Job Server IpAddress to be used is [" + ipAddress + "]");
		ActivateWorkFlowPage activateWorkFlowPage = new ActivateWorkFlowPage(driver, testCaseId);
		activateWorkFlowPage.goToActivateWorkFlowPage(ipAddress);
	}
	
	/**
	 * Accepted Value : 1 BatchJobToRun
	 * @param table
	 * @throws Exception
	 */
	@Given("^From Activet WorkFlow Page, Select Environment and WorkFlow to Run$")
	public void submitWorkFLow(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		String batchJobId = scenarioData.get(1).get(0);
		
		String env = globalData.get("Environment").trim(); //env name in Drop Down to global Prop mapping
		String envDropDownValue = BatchJob_EnvServerMapping.getEnvDropDownValue(env);
		String workFlowDropDownValue = BatchJob_Workflow_ID_Mapping.getWorkflowId(batchJobId);
		
		String serverDropDownValue= BatchJob_EnvServerMapping.getServerDropDownValue(env);
		
		ActivateWorkFlowPage activateWorkFlowPage = new pages.batchJob.ActivateWorkFlowPage(driver, testCaseId);
		int batchJobWorkRunId = activateWorkFlowPage.submitWorkFlow(envDropDownValue, workFlowDropDownValue, serverDropDownValue);
		activateWorkFlowPage.takeScreenshot();
		storeTempTestData("BatchJobWorkRunId", batchJobWorkRunId+"");
	}
	
	/**
	 * Accepted Value : 1 MaxTimeOutInMinute
	 * @param table
	 * @throws Exception
	 */
	@Given("^Ensure WorkFlow is Completed Successfully$")
	public void ensureWorkFlowIsCompletedSuccessfully(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String maxTimeOutInMinute = scenarioData.get(1).get(0);
		
		int intMaxTimeOutInMinute = Integer.parseInt(maxTimeOutInMinute);
		
		String batchJobWorkRunId = getTempTestData("BatchJobWorkRunId");
		int intBatchJobWorkRunId = Integer.parseInt(batchJobWorkRunId);
		
		ActivateWorkFlowPage activateWorkFlowPage = new pages.batchJob.ActivateWorkFlowPage(driver, testCaseId);
		int minuteCounter=0;
		
		while(minuteCounter < intMaxTimeOutInMinute){
			activateWorkFlowPage.refreshActiveWorkFlowPage();
			String currentStatus = activateWorkFlowPage.getRecentWorkFlowStatus(minuteCounter+1,intBatchJobWorkRunId);
			if(currentStatus.equals("COMPLETED")){
				break;
			}
			
			minuteCounter++;
			Thread.sleep(60000);    // Wait For 1 Minute before next round of status check
		}
		
		if(minuteCounter==intMaxTimeOutInMinute){
			throw new Exception("Cound not complete Bach Job in [" + maxTimeOutInMinute + "] Minute");
		}
		
	}
	
	

}
