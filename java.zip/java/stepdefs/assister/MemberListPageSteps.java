package stepdefs.assister;
import cucumber.api.java.en.Given;
import pages.assister.MemberListPage;
import pages.assister.ViewDesignationFormPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class MemberListPageSteps extends SuperStepDef{

	public MemberListPageSteps(Hook hook) {
		super(hook);
	}
	
	/*@Aashita
	 * */
	@Given("^From Assister Protal ,Seach Customer Using Refid$")
	public void submitFormAndProceed() throws Exception{
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		MemberListPage memberListPage = new MemberListPage(driver, testCaseId);
		memberListPage.searchCustomerUsingRefID(userProfileRefId);
	}
	
	/*@ritu
	 * */
	@Given("^From Assister Protal ,Seach Customer Using Refid And Click Eligibility Link$")
	public void searchCustomerUsingRefIDAndClickElgLink() throws Exception{
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		MemberListPage memberListPage = new MemberListPage(driver, testCaseId);
		memberListPage.searchCustomerUsingRefIDAndClickElgLink(userProfileRefId);
	}
	
	
	
	@Given("^From Assister Protal ,Remove Access For Member$")
	public void removeAccessForMember() throws Exception{
		MemberListPage memberListPage = new MemberListPage(driver, testCaseId);
		memberListPage.removeAccessForMember();

	}
	
	@Given("^From Find A Customer Page,Click On ViewDesignationForm And Click On Download Designation Form$")
	public void clickOnViewDesg() throws Exception {
		MemberListPage memberListPage = new MemberListPage(driver, testCaseId);
		memberListPage.clickOnViewDesFormBtn();
		
		ViewDesignationFormPage viewDesignationForm = new ViewDesignationFormPage(driver, testCaseId);
		viewDesignationForm.waitForPageLoaded();
		viewDesignationForm.takeScreenshot();
		viewDesignationForm.ClickOnDwldDesgForm();
	}
	
}

