package stepdefs.assister;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.DualTable;
import db.ElgMemberTable;
import db.EligibilityTable;
import pages.assister.DesignationFormPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.RandomGenerator;
import utils.TestData;
import utils.WordUtil;

public class DesignationFormSteps extends SuperStepDef{

	public DesignationFormSteps(Hook hook) {
		super(hook);
	}
	
	@Given("^EVPD, Fill Designation Form Details$")
	public void fill_Designation_Details() throws Exception {
		DesignationFormPage asssisterDesigPg = new DesignationFormPage(driver, testCaseId);
		
		
		asssisterDesigPg.fill_Designation_Details(evpdData.optumIdData.role, 
				evpdData.memsData.get(0).firstName, 
				evpdData.memsData.get(0).middleName,
				evpdData.memsData.get(0).lastName,
				evpdData.memsData.get(0).dob,
				"SSN",
				evpdData.memsData.get(0).ssn);
		asssisterDesigPg.submitFormAndProceedForNewMember();
	}
	
	/**
	 * Accept DataTable with following value
	 * 1. Role :- NAV, CAC
	 * 2. FirstNameFormat -- STR_YC, END_KED, "","ABCD"
	 * 3. MiddleNameFormat -- STR_YC, END_KED, "","ABCD"
	 * 4. LastNameFormat -- STR_YC, END_KED, "","ABCD"
	 * 5. Age -- 			Any Age Format "35", "35:01", "00:00:30"
	 * 6. SSN FORMAT :- "BLANK", STR_4, END_3
	 * 
	 From Assister Designation Form Page, Fill Designation Form Details For New Member With SSN Details
	  | Role 		|	FirstNameFormat  | MiddleNameFormat  | LastNameFormat  |  Age  		   | SSN FORMAT  |
	  | CAC			| 					 |					 |	 STR_YC 	   |   45  		   |  		     |
	 * @param table
	 * @throws Exception
	 */
	@Given("^From Assister Designation Form Page, Fill Designation Form Details For New Member With SSN Details$")
	public void fill_Designation_Details_for_Assister_Portal(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String role = scenarioData.get(1).get(0);
		String fNameFormat = scenarioData.get(1).get(1);
		String mNameFormat = scenarioData.get(1).get(2);
		String lNameFormat = scenarioData.get(1).get(3);
		String age = scenarioData.get(1).get(4);
		String ssnFormat = scenarioData.get(1).get(5);

		String firstName = RandomGenerator.getRunTimeName("MEM", fNameFormat);
		String middleName = RandomGenerator.getRunTimeName("", mNameFormat);
		String lastName = RandomGenerator.getRunTimeName(WordUtil.getWord(1), lNameFormat);
		
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		String dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, age);
		
		String[] ssnStatus = RandomGenerator.getRunTimeSSN(ssnFormat);
		String ssn = ssnStatus[1];
		DesignationFormPage asssisterDesigPg = new DesignationFormPage(driver, testCaseId);

		asssisterDesigPg.fill_Designation_Details(role, 
				firstName, 
				middleName,
				lastName,
				dob,
				"SSN",
				ssn);
	}
	
	/*Ritu
	
	Complete member Application :
	
	From Assister Designation Form Page, Link the existing member by submitting the Designation form
	|Role	|Memno|
	| CAC	|	1 |
	
	*/
	
	@Given("^From Assister Designation Form Page, Link the existing member by submitting the Designation form$")
	public void fill_Designation_Details_from(DataTable table) throws Exception 
	{
		List<List<String>> scenarioData = table.raw();
		String role = scenarioData.get(1).get(0);
		String memno =scenarioData.get(1).get(1);
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		int memIndex = Integer.parseInt(memno)-1;
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String memFName = elg_MemberTable.getFirstNameUsingUserProfileRefId(userProfileRefId, memIndex);
		String memLName = elg_MemberTable.getLastNameUsingUserProfileRefId(userProfileRefId, memIndex);
		String memMidName = elg_MemberTable.getMiddleNameUsingUserProfileRefId(userProfileRefId, memIndex);
		String age=elg_MemberTable.getDOB(elgId,  memIndex);
		String dob =DateUtil.getDateInUIFormatUsingPattern(age,DateUtil.dbDatePattern);
		DesignationFormPage asssisterDesigPg = new DesignationFormPage(driver, testCaseId);
		
		asssisterDesigPg.fill_Designation_Details(role, 
				memFName, 
				memMidName,
				memLName,
				dob,
				"REFID",
				userProfileRefId
				);
		asssisterDesigPg.submitFormForExistingMember();
	}
	
	@Given("^From Assister Designation Form Page, Validate SSN Is Masked$")
	public void validateUserProfileSSNIsMaskedOnDesgForm() throws Exception{
		DesignationFormPage asssisterDesigPg = new DesignationFormPage(driver, testCaseId);
		asssisterDesigPg.validateUserProfileSSNIsMaskedOnDesgForm();
	}
	
	@Given("^From Assister Designation Form Page, Submit Form And Proceed For New Member$")
	public void submitFormAndProceed() throws Exception{
		DesignationFormPage asssisterDesigPg = new DesignationFormPage(driver, testCaseId);
		asssisterDesigPg.submitFormAndProceedForNewMember();
	}
}
