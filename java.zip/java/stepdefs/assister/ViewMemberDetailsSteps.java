package stepdefs.assister;

import cucumber.api.java.en.And;
import pages.assister.ViewMemberDetailsPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ViewMemberDetailsSteps extends SuperStepDef {

	public ViewMemberDetailsSteps(Hook hook) {
		super(hook);
	}

	// Ritu
	@And("^From ViewMemberDetail Page, Click On Remove Access$")
	public void clickOnRemoveAccess() throws Throwable {

		ViewMemberDetailsPage viewMemberDetailsPage = new ViewMemberDetailsPage(driver, testCaseId);
		viewMemberDetailsPage.ClickOnRemoveAccess();
	}

	// Ritu
	@And("^From ViewMemberDetail Page, Click On ViewProfile$")
	public void clickOnViewProfile() throws Throwable {

		ViewMemberDetailsPage viewMemberDetailsPage = new ViewMemberDetailsPage(driver, testCaseId);
		viewMemberDetailsPage.ClickOnViewProfile();

	}

	// Ritu
	@And("^From ViewMemberDetail Page, Click On ViewEligibility$")
	public void clickOnViewEligibility() throws Throwable {
		ViewMemberDetailsPage viewMemberDetailsPage = new ViewMemberDetailsPage(driver, testCaseId);
		viewMemberDetailsPage.ClickOnViewEligibility();
		viewMemberDetailsPage.ClickOnAgreeBtn();

	}

}
