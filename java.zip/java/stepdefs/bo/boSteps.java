package stepdefs.bo;

import appdata.common.OptumIdData;
import appdata.common.TempData;
import cucumber.api.java.en.Given;
import enums.PortalName;
import pages.accountDashboard.AccountDashboardLandingPage;
import pages.eligibilityResult.ReviewPreliminarySummaryPage;
import pages.login.HomePage;
import pages.login.Portal;
import pages.manageCustomer.FindACustomerPage;
import pages.myEligibility.EligibilityApplicationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.HttpsClient;
import utils.TestData;

/** @author ppinho
 * 
 * Iterate through the Pages within the respective Module of each Step Definition 
 * and complete each Page with the data given in the excel file.
 * 
 */

public class boSteps extends SuperStepDef {
	
	private String ipAddress = globalData.get("Local_IP_Address").trim();
	private String username = globalData.get("username").trim().toLowerCase();
	private String password = globalData.get("password").trim();
	private String schema = globalData.get("mysql_schema").trim();
	
	public boSteps(Hook hook) {
		super(hook);
	}
		
	@Given("^BO, Login To MAHIX Portal$")
	public void login_To_Portal_EVPD() throws Exception {
		Portal portal = new Portal(hook);
		String url = TestData.getURL(PortalName.AGENT.code, envData);		
		OptumIdData optumIdData = TestData.getOptumIdCredentialForAgent(envData);
		portal.goToPortal(browserToUse, url, PortalName.AGENT.code, optumIdData);
	}
	
	@Given("^BO, Find A Customer With UserProfileRefId And Go To Account Dashboard")
	public void evpdSearchRefID() throws Exception {		
		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.agentPageLoadAndClickOnManageCustomerLink();
		
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(evpdData.memsData.get(0).userRefId);
	}
	
	@Given("^BO, Go to Eligibility Application Page And Store Current Eligibility Id$")
	public void goToEligibilityApplicationPageAndStoreCurrentEligibilityId() throws Exception {
		int year = Integer.valueOf(globalData.get("ApplicationCreationYear")) + 1;
		
        AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
        accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
        
        EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
        eligibilityApplicationPage.performActionclickOnEditLink(String.valueOf(year));
        
        evpdData.eligibilityId = eligibilityApplicationPage.getLatestEligibilityId(String.valueOf(year));
        sendTempDateToDb(0);        
	}
			
	@Given("^BO, Go to Current Year Eligibility Result Page$")
	public void goToCurrentYearEligibilityResultPage() throws Exception {
		String year = globalData.get("ApplicationCreationYear");
		
        AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
        accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
        
		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		eligibilityApplicationPage.pageLoadAndClickOnEligibilityDetailsLink(year);	
	}
	
	@Given("^BO, Go to Review Preliminary Summary Page$")
	public void goToReviewPreliminarySummaryPage() throws Exception {
		int year = Integer.valueOf(globalData.get("ApplicationCreationYear")) + 1;
		
        AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
        accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
        
		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);		        
		eligibilityApplicationPage.pageLoadAndClickOnEligibilityReviewSummaryLink(String.valueOf(year));
		
		ReviewPreliminarySummaryPage reviewPreliminarySummaryPage = new ReviewPreliminarySummaryPage(driver, testCaseId);
		evpdData.eligibilityId = reviewPreliminarySummaryPage.getEligibilityId();
		sendTempDateToDb(0);
	}
	
	@Given("^BO, From Current Year Eligibility Result Page Verify New Eligibility Id Was Created$")
	public void verifyNewElgIdCreated() throws Exception {
        AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
        accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();		
	}
	
	@Given("^BO, From Account Dashboard Verify Renewal Was Initiated$")
	public void verifyRenewalWasInitiated() throws Exception {
		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.waitForRenewalInitiated();
		homePages.takeScreenShot();
	}
		
	public void sendTempDateToDb(int memIndex) throws Exception {		
		HttpsClient httpClient = new HttpsClient();		
		TempData tempData = new TempData();
		
		String table = getTempTestData("DataSet") + "_bo";
		
		tempData.sqlScript = "update " + schema + "." + table + 
				 			 " set " + table + ".user_ref_id = '" + evpdData.userProfileRefId + "', " +
				 			 		   table + ".elg_id = '" + evpdData.eligibilityId + "', " +
				 			 		   table + ".environment = '" + globalData.get("Environment") + "', " +
				 			 		   table + ".app_date = '" + evpdData.appDate + "' " +
				 			 " where " + table + ".scenario = '" + featureFileName + "'" +
				 			 " and " + table + ".mem_id = 'M1'";	
		
		httpClient.updateTempDataMS(ipAddress, username, password, getTempTestData("DataSet"), TempData.updateTempDataRequest(tempData));
	}
	
	public void sendDemographicDataToDb(int memIndex) throws Exception {		
		HttpsClient httpClient = new HttpsClient();		
		TempData tempData = new TempData();
		
		String table = getTempTestData("DataSet") + "_bo";
		
		tempData.sqlScript = "update " + schema + "." + table + 
				 			 " set " + table + ".ms_fn = '" + evpdData.memsData.get(memIndex).firstName + "', " +
				 			 		   table + ".ms_mn = '" + evpdData.memsData.get(memIndex).middleName + "', " +
				 			 		   table + ".ms_ln = '" + evpdData.memsData.get(memIndex).lastName + "' " +
				 			 " where " + table + ".scenario = '" + featureFileName + "'" +
				 			 " and " + table + ".mem_id = '" + evpdData.memsData.get(memIndex).memId + "'";	
		
		httpClient.updateTempDataMS(ipAddress, username, password, getTempTestData("DataSet"), TempData.updateTempDataRequest(tempData));
	}
	
	public void sendPdDataToDb(int memInd) throws Exception {		
		HttpsClient httpClient = new HttpsClient();
		TempData tempData = new TempData();
		
		String table = getTempTestData("DataSet") + "_bo";
		String programDetermination = null;
		String aidCat = null;
		
		if(!evpdData.memsData.get(memInd).mhAidCat.isEmpty()){
			aidCat = evpdData.memsData.get(memInd).mhAidCat;				
		}else{
			aidCat = evpdData.memsData.get(memInd).ccaAidCat;
		}
		
		if(!evpdData.memsData.get(memInd).mhAidCat.isEmpty()){
			programDetermination = evpdData.memsData.get(memInd).mhProgramDetermination;		
		}else{
			programDetermination = evpdData.memsData.get(memInd).ccaProgramDetermination + " " + 
								   evpdData.memsData.get(memInd).mhProgramDetermination;
		}
		
		tempData.sqlScript = "update " + schema + "." + table + 
	 			 " set " + table + ".ms_aid_cat = '" + aidCat + "', " +
	 			 		   table + ".ms_program_determination = '" + programDetermination + "' " +
	 			 " where " + table + ".scenario = '" + featureFileName + "'" +
	 			 " and " + table + ".mem_id = '" + evpdData.memsData.get(memInd).memId + "'";	
				
		httpClient.updateTempDataMS(ipAddress, username, password, getTempTestData("DataSet"), TempData.updateTempDataRequest(tempData));
	}
	
}
