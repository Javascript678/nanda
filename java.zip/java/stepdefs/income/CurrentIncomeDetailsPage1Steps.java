package stepdefs.income;
import cucumber.api.java.en.When;
import pages.income.CurrentIncomeDetailsPage1;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class CurrentIncomeDetailsPage1Steps extends SuperStepDef{
	
	public CurrentIncomeDetailsPage1Steps(Hook hook){
		super(hook);
	}
	
	@When("^From Current Income Detils Page 1, Page Load And Click On Save And Continue$")
	public void pageLoadAndClickOnSaveAndContinue() throws Exception{
		
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		currentIncomeDetailsPage1.pageLoadThenClickOnSaveAndContinueBtn();
	}
	
	@When("^From Current Income Detils Page 1, Take Screenshot$")
	public void takeScreenshot() throws Exception{
		
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		currentIncomeDetailsPage1.takeScreenshot();
	}
	
	/**
	 * @author rnegi101
	 From CurrentIncomeDetails Page 1,Validate JOb Income For member "" and Job Income As ""
	 
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate JobIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateJobIncomeForOneMember(String memNo,String jobIncome) throws Exception{
	CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		System.out.println("income "+jobIncome);
		currentIncomeDetailsPage1.validateJobForMember(memIndex,jobIncome);
		
	}

	/**
	 * @author rnegi101
	From CurrentIncomeDetails Page 1,Validate  SelfEmploymentIncome For member "" and Income As ""
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate SelfEmploymentIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateSelfEmploymentForOneMember(String memNo,String selfEmplpymentIncome) throws Exception{
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		currentIncomeDetailsPage1.validateSelfEmployementForMember(memIndex,selfEmplpymentIncome);
		
	}
	
	/**
	 * @author rnegi101
	From CurrentIncomeDetails Page 1, Validate SSBIncome For member "" and Income As ""
	 
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate SSBIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateSSBIncomeForOneMember(String memNo,String SSBIncome) throws Exception{
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
     	int memIndex = Integer.parseInt(memNo)-1;
		currentIncomeDetailsPage1.validateSSBIncomeForMember(memIndex,SSBIncome);
		
	}
	
	/**
	 * @author rnegi101
	 From CurrentIncomeDetails Page 1, Validate AlimonyIncome For member "" and Income As ""
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate AlimonyIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateAlimonyIncomeForOneMember(String memNo,String alimonyReceivedIncome) throws Exception{
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		currentIncomeDetailsPage1.validateAlimonyReceivedIncomeForMember(memIndex,alimonyReceivedIncome);
		
	}
	
	
	/**
	 * @author rnegi101
	 From CurrentIncomeDetails Page 1, Validate CapitalGainsIncome For member "" and Income As ""
	
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate CapitalGainsIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateCapitalGainsIncomeForOneMember(String memNo, String capitalGainsIncome) throws Exception{
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		currentIncomeDetailsPage1.validateCapitalGainsIncomeForMember(memIndex,capitalGainsIncome);
		}
	
	
	
	/**
	 * @author rnegi101
	 "^From CurrentIncomeDetails Page 1, Validate FarmingAndFishingIncome For member "" and Income As ""
	
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate FarmingAndFishingIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateFarmingAndFishingIncomeForOneMember(String memNo,String farmingOrFishingIncome) throws Exception{
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		currentIncomeDetailsPage1.validateFarmingOrFishingIncomeForMember(memIndex,farmingOrFishingIncome);
		
	}
	
	
	/**
	 * @author rnegi101
	 "^From CurrentIncomeDetails Page 1, Validate InterestDividendsIncome For member "" and Income As ""
	
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate InterestDividendsIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateInterestDividendsIncomeForOneMember(String memNo,String interestDividendsIncome ) throws Exception{
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		currentIncomeDetailsPage1.validateInterestDividendsIncomeForMember(memIndex,interestDividendsIncome);	
	}
	
	/**
	 * @author rnegi101
	 From CurrentIncomeDetails Page 1, Validate OtherIncome For member "1" and Income As "10000"
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate OtherIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateOtherIncomeForOneMember(String memNo ,String otherIncome ) throws Exception{
		
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		
		currentIncomeDetailsPage1.validateOtherIncomeForMember(memIndex,otherIncome);
		}
	
	/**
	 * @author rnegi101
	From CurrentIncomeDetails Page 1, Validate RentalAndRoyalityIncome For member "" and Income As ""
	
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate RentalAndRoyalityIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateRentalAndRoyalityIncomeForOneMember(String memNo,String rentalAndRoyalityIncome) throws Exception{
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		
		currentIncomeDetailsPage1.validateRentalAndRoyalityIncomeForMember(memIndex,rentalAndRoyalityIncome);
		}
	
	/**
	 * @author rnegi101
	From CurrentIncomeDetails Page 1, Validate  RetirementOrPensionIncome For member "" and Income As ""
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate RetirementOrPensionIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateRetirementOrPensionIncomeForOneMember(String memNo, String retirementOrPensionIncome ) throws Exception{
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		currentIncomeDetailsPage1.validateRetirementOrPensionIncomeForMember(memIndex,retirementOrPensionIncome);
		
	}
	
	
	/**
	 * @author rnegi101
	 From CurrentIncomeDetails Page 1, Validate  UnemploymentIncome For member "" and Income As ""
	 * @throws Exception
	 */
	@When("^From CurrentIncomeDetails Page 1,Validate UnemploymentIncome For member \"(.*?)\" and Income As \"(.*?)\"$")
	public void validateUnemploymentIncomeForOneMember(String memNo ,String unEmploymentIncome) throws Exception{
	
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		currentIncomeDetailsPage1.validateUnEmploymentIncomeForMember(memIndex,unEmploymentIncome);
		
	}
	
	@When("^From Current Income Detils Page 1, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception{
		
		CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
		currentIncomeDetailsPage1.clickOnSaveAndContinueBtn();
	}
	
	
	
	
	
}
