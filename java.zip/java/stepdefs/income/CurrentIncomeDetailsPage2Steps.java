package stepdefs.income;

import cucumber.api.java.en.When;
import pages.income.CurrentIncomeDetailsPage2;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class CurrentIncomeDetailsPage2Steps extends SuperStepDef{
	
	public CurrentIncomeDetailsPage2Steps(Hook hook){
		super(hook);
	}
	
	@When("^From Current Income Details Page 2, Page Load And Click On Save And Continue$")
	public void pageLoadAndClickOnSaveAndContinue() throws Exception{
		CurrentIncomeDetailsPage2 currentIncomeDetailsPage2  = new CurrentIncomeDetailsPage2(driver, testCaseId);
		currentIncomeDetailsPage2.pageLoadThenClickOnSaveAndContinueBtn();
	}
	
	@When("^From Current Income Details Page 2, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception{
		CurrentIncomeDetailsPage2 currentIncomeDetailsPage2  = new CurrentIncomeDetailsPage2(driver, testCaseId);
		currentIncomeDetailsPage2.clickOnSaveAndContinueBtn();
	}
	
	/**@author vkuma212
	 * 	Accepted Value :- 	1. MemNo :- 1,2,3
	 
	 From Current Income Details Page 2, Select Income Deduction For Member "1" As None
		
	**/
	@When("^From Current Income Details Page 2, Select Income Deduction For Member \"(.*?)\" As None$")
	public void selectMemIncomeDeductionsAsNone(String memNo) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		CurrentIncomeDetailsPage2 currentIncomeDetailsPage2  = new CurrentIncomeDetailsPage2(driver, testCaseId);
		currentIncomeDetailsPage2.selectMemIncomeDeductionsAsNone(memIndex);
	}
	
	/**@author vkuma212
	 * 	Accepted Value :- 	1. MemNo

	 From Current Income Details Page 2, Select Member "1" Has Steady Income As True
		
	**/
	@When("^From Current Income Details Page 2, Select Member \"(.*?)\" Has Steady Income As True")
	public void selectIfMemberHasSteadyIncome(String memNo) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		CurrentIncomeDetailsPage2 currentIncomeDetailsPage2  = new CurrentIncomeDetailsPage2(driver, testCaseId);
		currentIncomeDetailsPage2.selectIfMemberHasSteadyIncome(memIndex, true);
	}
	
	
	/**@author Yamini
	 * 	Accepted Value :- 	1. MemNo

	 From Current Income Details Page 2, Select Member "1" Has Steady Income As False And Amount As \"(.*)\"$"
		
	**/
	@When("^From Current Income Details Page 2, Select Member \"(.*?)\" Has Steady Income As False And Amount As \"(.*)\"$")
	public void selectIfMemberHasSteadyIncomeAsFalse(String memNo,int amount) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		CurrentIncomeDetailsPage2 currentIncomeDetailsPage2  = new CurrentIncomeDetailsPage2(driver, testCaseId);
		currentIncomeDetailsPage2.selectIfMemberHasSteadyIncome(memIndex, false);
		currentIncomeDetailsPage2.enterExpectedMonthlyIncomeForMemberNotHavingSteadyIncome(memIndex,amount);
		
	}
	
	
}
