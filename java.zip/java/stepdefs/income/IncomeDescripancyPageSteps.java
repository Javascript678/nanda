package stepdefs.income;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import pages.income.IncomeDiscrepancyPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class IncomeDescripancyPageSteps extends SuperStepDef{
	
	public IncomeDescripancyPageSteps(Hook hook){
		super(hook);
	}
	
	@When("^From Current Income Page, Handle Income Descriancy If Any For All Members$")
	public void verifyIncomeDescripancyMannually() throws Exception{
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		IncomeDiscrepancyPage incomeDiscrepancyPage = new IncomeDiscrepancyPage(driver, testCaseId);
		for(int mCounter=0; mCounter<memCount; mCounter++){
			if(incomeDiscrepancyPage.isVerifyManualBtnPresent(mCounter)){
				incomeDiscrepancyPage.verifyIncomeDescripancyMannually(mCounter);
			}
		}
		
		
	}
	
	/*
	*@Ritu

	From Income Discrepancies Page, Select Reason "STOPPED_WORKING_AT_JOB" For Member "2" And Click On Verify IncomeDescripancy Mannually
	*/


	@When("^From Income Discrepancies Page, Select Reason \"(.*?)\" For Member \"(.*?)\" And Click On Verify IncomeDescripancy Mannually$")
	       public void selectReasonAndVerifyIncomeDescripancyMannually(String reason ,String memIndex) throws Exception{
	             String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
	             //ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
	             int memCount = Integer.parseInt(memIndex)-1;
	             
	             IncomeDiscrepancyPage incomeDiscrepancyPage = new IncomeDiscrepancyPage(driver, testCaseId);
	                 if(incomeDiscrepancyPage.isVerifyManualBtnPresent(memCount))
	                 {
	                      incomeDiscrepancyPage.selectReasonvAndClickOnVerifyIncomeDescripancyMannually(memCount,reason);
	                           incomeDiscrepancyPage.verifyIncomeDescripancyMannually(memCount);
	                    }
	       
	       
	       }
	
	 @When("^From Current Income Page, Handle Income Descriancy If Any For All Members For SS$")
	   	public void verifyIncomeDescripancyMannuallyForSS() throws Exception{
	   		String totmem = TestData.getTempTestData("MemCount",featureFileName);
	   		int memCount =Integer.parseInt(totmem);
	   		IncomeDiscrepancyPage incomeDiscrepancyPage = new IncomeDiscrepancyPage(driver, testCaseId);
	   		for(int mCounter=0; mCounter<memCount; mCounter++){
	   			if(incomeDiscrepancyPage.isVerifyManualBtnPresent(mCounter)){
	   				incomeDiscrepancyPage.verifyIncomeDescripancyMannually(mCounter);
	   			}
	   		}	
	   	}
	       

	       
	       @When("^From Income Discrepancies Page, Click On Verify IncomeDescripancy Mannually For Member \"(.*?)\"$")
	       public void waitForPageLoadAndClickOnVerifyManually(String memNum) throws Exception
	       {
	             IncomeDiscrepancyPage incomeDiscrepancyPage = new IncomeDiscrepancyPage(driver, testCaseId);
	             int memCount = Integer.parseInt(memNum)-1;
	             incomeDiscrepancyPage.verifyIncomeDescripancyMannually(memCount);
	             
	       }

}
