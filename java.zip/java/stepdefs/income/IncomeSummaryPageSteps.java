package stepdefs.income;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import pages.income.IncomeSummaryPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class IncomeSummaryPageSteps extends SuperStepDef{
	
	public IncomeSummaryPageSteps(Hook hook){
		super(hook);
	}
	
	
	@When("^From Income Summary Page, Page Load And Click On Save And Continue$")
	public void selectIfExpectedIncomeSameAsMentionedForMember() throws Exception{
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		incomeSummaryPage.pageLoadThenClickOnSaveAndContinueBtn();
		
	}
	
	@When("^From Income Summary Page, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception{
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		incomeSummaryPage.takeScreenshot();
		incomeSummaryPage.clickOnSaveAndContinueBtn();
		
	}
	
	/**
	 * @author vkuma212
	 From Income Summary Page, Validate Yearly Job Income For Member
	 | MemNo   | JobIncomeYearly 	|
	 |  1	   |   10000   			|
	 |  2	   |   10200   			|
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate Yearly Job Income For Member$")
	public void validateJobIncomeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String jobIncomeYearly = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateYearlyJobForMember(memIndex, jobIncomeYearly);
		}
	}
	
	/**
	 * @author Ritu
	 From Income Summary Page, Validate CapitalGain Monthly Income For Member
	 | MemNo   | CapitalGainMonthly |
	 |  1	   |   10000   			|
	 |  2	   |   10200   			|
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate CapitalGain Monthly Income For Member$")
	public void validateCapitalGainIncomeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String capitalGainIncmMon = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateMonthlyCapitalGainForMember(memIndex, capitalGainIncmMon);
		}
	}
	
	
	/**
	 * @author Ritu
	 From Income Summary Page, Validate FarmingOrFishing Yearly Income For Member
	 | MemNo   | FarmingOrFishing Yearly|
	 |  1	   |   10000   			    |
	 |  2	   |   10200   			    |
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate FarmingOrFishing Yearly Income For Member$")
	public void validateFarmingOrFishingIncomeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String farmingAndFishingIncmYr = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateYearlyFarmingOrFishingForMember(memIndex, farmingAndFishingIncmYr);
		}
	}
	
	/**
	 * @author Ritu
	 From Income Summary Page, Validate InterestDividends Yearly Income For Member
	 | MemNo   | InterestDividends Yearly|
	 |  1	   |   10000   			|
	 |  2	   |   10200   			|
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate InterestDividends Yearly Income For Member$")
	public void validateInterestDividendsIncomeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String interestDividendsIncmYr = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateYearlyInterestDividendsForMember(memIndex, interestDividendsIncmYr);
		}
	}
	
	
	/**
	 * @author Ritu
	 From Income Summary Page, Validate RentalRoyalty Yearly Income For Member
	 | MemNo   | RentalRoyalty Yearly|
	 |  1	   |   10000   			|
	 |  2	   |   10200   			|
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate RentalRoyalty Yearly Income For Member$")
	public void validateRentalRoyaltyIncomeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String rentalRoyaltyIncmYr = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateYearlyRentalRoyaltyForMember(memIndex, rentalRoyaltyIncmYr);
		}
	}
	
	
	
	/**
	 * @author Ritu
	 From Income Summary Page, Validate SelfEmployment Yearly Income For Member
	 | MemNo   | SelfEmployment Yearly|
	 |  1	   |   10000   			|
	 |  2	   |   10200   			|
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate SelfEmployment Yearly Income For Member$")
	public void validateSelfEmploymentIncomeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String selfEmploymentIncmYr = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateYearlySelfEmploymentForMember(memIndex, selfEmploymentIncmYr);
		}
	}
	
	

	/**
	 * @author Ritu
	 From Income Summary Page, Validate SSB Yearly Income For Member
	 | MemNo   | SSB  Yearly        |          
	 |  1	   |   10000   			|
	 |  2	   |   10200   			|
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate SSB Yearly Income For Member$")
	public void validateSSBIncomeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String ssbIncmYr = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateYearlySSBForMember(memIndex, ssbIncmYr );
		}
	}
	/**
	 * @author Ritu
	 From Income Summary Page, Validate Alimony Yearly Income For Member
	 | MemNo   | Alimony Yearly     |        
	 |  1	   |   10000   			|
	 |  2	   |   10200   			|
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate Alimony Yearly For Member$")
	public void validateAlimonyIncomeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String alimonyIncmYr = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateYearlyAlimonyForMember(memIndex, alimonyIncmYr );
		}
	}
	

	/**
	 * @author Ritu
	 From Income Summary Page, Validate OtherIncome Yearly Income For Member
	 | MemNo   | OtherIncome   Yearly        |          
	 |  1	   |   10000   			|
	 |  2	   |   10200   			|
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate OtherIncome Yearly Income For Member$")
	public void validateOtherIncomeeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String otherIncmYr = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateYearlyOtherIncomeForMember(memIndex, otherIncmYr );
		}
	}
		
	/**
	 * @author Ritu
	 From Income Summary Page, Validate Retirement Yearly Income For Member
	 | MemNo   | Retirement Yearly   |        
	 |  1	   |   10000   			|
	 |  2	   |   10200   			|
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate Retirement Yearly Income For Member$")
	public void validateRetirementIncomeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String retirementIncmYr = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateYearlyRetirementForMember(memIndex, retirementIncmYr );
		}
	}
	
	
	/**
	 * @author Ritu
	 From Income Summary Page, Validate Unemployment Yearly Income For Member
	 | MemNo   | Unemployment Yearly        |         
	 |  1	   |   10000   			|
	 |  2	   |   10200   			|
	 * @throws Exception
	 */
	@When("^From Income Summary Page, Validate Unemployment Yearly Income For Member$")
	public void validateUnemploymentIncomeForMembers(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		for(int rowIndex=1; rowIndex<rowCount; rowIndex++){
			int memIndex = Integer.parseInt(scenarioData.get(rowIndex).get(0))-1;
			String unemploymentIncmYr = scenarioData.get(rowIndex).get(1);
			incomeSummaryPage.validateYearlyUnemploymentForMember(memIndex, unemploymentIncmYr );
		}
	}
	
	
	
}
