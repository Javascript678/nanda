package stepdefs.income;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import pages.income.AnnualIncomePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class AnnualIncomePageSteps extends SuperStepDef{
	
	public AnnualIncomePageSteps(Hook hook){
		super(hook);
	}
	
	/** Vinay
	 * 
	 From Annual Income Page, Select Expected Income Same As Mentioned For All Members
	 
	 */
	@When("^From Annual Income Page, Select Expected Income Same As Mentioned For All Members$")
	public void selectIfExpectedIncomeSameAsMentionedForMember() throws Exception{
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		AnnualIncomePage annualIncomePage = new AnnualIncomePage(driver, testCaseId);
		for(int mCounter=0; mCounter<memCount; mCounter++){
			annualIncomePage.waitForPageLoaded();
			annualIncomePage.selectIfExpectedIncomeSameAsMentionedForMember(mCounter, true);
			annualIncomePage.clickOnSaveAndContinueBtn();
		}
		
		
	}
	
	/**Ritika
	
	From Annual Income Page, Select Expected Income Same As Mentioned For Member "1"
	
	 */
	@When("^From Annual Income Page, Select Expected Income Same As Mentioned For Member \"(.*?)\"$")
	public void selectIfExpectedIncomeSameAsMentionedForMem(String memIndex) throws Exception{
	
		String[] arrMemb = memIndex.split(",");
		AnnualIncomePage annualIncomePage = new AnnualIncomePage(driver, testCaseId);

		for(int mCouter=0;mCouter<arrMemb.length;mCouter++){
			int memNo =  Integer.parseInt(arrMemb[mCouter])-1;
			annualIncomePage.waitForPageLoaded();
			annualIncomePage.selectIfExpectedIncomeSameAsMentionedForMember(memNo, true);
			annualIncomePage.clickOnSaveAndContinueBtn();}

	}

	/**Ritika
	
	From Annual Income Page, Select Expected Income Different For Member "1" With Value As "12000"
	 
	 */
	@When("^From Annual Income Page, Select Expected Income Different For Member \"(.*?)\" With Value As \"(.*?)\"$")
	public void selectIfExpectedIncomeDiffAsMentionedForMem(String memIndex,String income) throws Exception{
		int memNo = Integer.parseInt(memIndex)-1;
		int expIncome = Integer.parseInt(income);
		AnnualIncomePage annualIncomePage = new AnnualIncomePage(driver, testCaseId);
		annualIncomePage.waitForPageLoaded();
		annualIncomePage.selectIfExpectedIncomeSameAsMentionedForMember(memNo, false);
		annualIncomePage.enterExpectedYearlyIncomeForMember(memNo, expIncome);
		annualIncomePage.clickOnSaveAndContinueBtn();
	}
	
	@When("^From Annual Income Page, Select Expected Income Same As Mentioned For All Members For SS$")
	public void selectIfExpectedIncomeSameAsMentionedForMemberForSS() throws Exception{
		String totmem = TestData.getTempTestData("MemCount",featureFileName);
		int memCount =Integer.parseInt(totmem);
		AnnualIncomePage annualIncomePage = new AnnualIncomePage(driver, testCaseId);
		for(int mCounter=0; mCounter<memCount; mCounter++){
			annualIncomePage.waitForPageLoaded();
			annualIncomePage.selectIfExpectedIncomeSameAsMentionedForMember(mCounter, true);
			annualIncomePage.clickOnSaveAndContinueBtn();
		}
		
		
	}
	
	/**@author akumari4
	 
	   From Annual Income Page, Page Load Then Save and Continue
	 */
	@When("^From Annual Income Page, Page Load Then Save and Continue$")
	public void pageLoadThenSaveAndContinue() throws Exception{
		AnnualIncomePage annualIncomePage = new AnnualIncomePage(driver, testCaseId);
		annualIncomePage.waitForPageLoaded();
		annualIncomePage.clickOnSaveAndContinueBtn();
	}
}
