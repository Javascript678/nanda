package stepdefs.income;
import cucumber.api.java.en.When;
import pages.income.IncomeStartPage;
import pages.income.IncomeSummaryPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class IncomePageSteps extends SuperStepDef{
	
	public IncomePageSteps(Hook hook){
		super(hook);
	}
		
	@When("^EVPD, Complete Income Details$")
	public void completIncomeDetails() throws Exception {		
		IncomeStartPage incomeStartPage = new IncomeStartPage(driver, testCaseId);
		incomeStartPage.selectIncomeAndDeductionForMembers(envData.get("Display.sheltered.workshop.question"),evpdData.faReqd, evpdData.memsData);
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		incomeSummaryPage.pageLoadThenClickOnSaveAndContinueBtn(evpdData.faReqd);		
	}
	
	@When("^EVPD, Complete Income Details and Validate On Summary Page$")
	public void completIncomeDetailsAndValidateOnSummaryPage() throws Exception {		
		IncomeStartPage incomeStartPage = new IncomeStartPage(driver, testCaseId);
		incomeStartPage.selectIncomeAndDeductionForMembers(envData.get("Display.sheltered.workshop.question"),evpdData.faReqd, evpdData.memsData);
		
		IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
		incomeSummaryPage.validateIncomeThenClickOnSaveAndContinueBtn(evpdData.faReqd, evpdData.memsData);		
	}
	
	@When("^From Income Start Page, Click On Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		
		IncomeStartPage incomeStartPage = new IncomeStartPage(driver, testCaseId);
		incomeStartPage.pageLoadThenClickOnSaveAndContinueBtn();
		
	}

}
