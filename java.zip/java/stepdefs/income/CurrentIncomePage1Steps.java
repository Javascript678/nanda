package stepdefs.income;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import db.DualTable;
import db.ElgMemberTable;
import enums.IncomeType;
import pages.income.CurrentIncomeDetailsPage1;
import pages.income.CurrentIncomeDetailsPage2;
import pages.income.CurrentIncomePage1;
import pages.income.CurrentIncomePage2;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class CurrentIncomePage1Steps extends SuperStepDef{
	
	public CurrentIncomePage1Steps(Hook hook){
		super(hook);
	}

	/**@author vkuma212
	From Current Income Page 1, Click On Save And Continue
			Note:- One Member at a time
	 */
	@When("^From Current Income Page 1, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception{
		CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
		currentIncomePage1.clickOnSaveAndContinueBtn();
	}
	
	/**@author vkuma212
	From Current Income Page 1, For Member "1" , Page Load And Click On Save And Continue
	 */
	@When("^From Current Income Page 1, For Member \"(.*?)\" , Page Load And Click On Save And Continue$")
	public void pageLoadAndClickOnSaveAndContinue(String memNo) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
		currentIncomePage1.pageLoadAndClickOnSaveAndContinue(memIndex);
	}
	
	
	@When("^From Current Income Page 1, Select Job Income Details For Members For SS$")
	public void completIncomeDetailsForSS(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		String displayShelteredWorkshopQuestion = envData.get("Display.sheltered.workshop.question");
		
		DateFormat df = new SimpleDateFormat("MM/dd/YYYY");
		Date dateobj = new Date();
		String appDate=df.format(dateobj);
		
		String jobIncomeEffectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:30");
		
		
		for(int mCounter=1; mCounter<rowCount; mCounter++){
				
			int memIndex = Integer.parseInt(scenarioData.get(mCounter).get(0))-1;
			Boolean hasSourceOfIncome = scenarioData.get(mCounter).get(1).equalsIgnoreCase("TRUE")?true:false;
			String incomeTypes = scenarioData.get(mCounter).get(2).trim();
			String jobEmployerName=null;
			int jobIncomeAmount=0;
			
			if(incomeTypes.contains(IncomeType.JOB.val)){
				jobEmployerName = scenarioData.get(mCounter).get(3); 
				if(jobEmployerName.equals("")){jobEmployerName = "OPTUM";}
				jobIncomeAmount = Integer.parseInt(scenarioData.get(mCounter).get(4)); 
			}
			String hoursWorked = scenarioData.get(mCounter).get(5).trim();
			if(hoursWorked.equals("")){hoursWorked = "40";}
			int intHoursWorked = Integer.parseInt(hoursWorked);
			
			int incomeSourceIndex =-1;
			CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
			currentIncomePage1.selectIncomeTypeForMember(memIndex, hasSourceOfIncome, incomeTypes);
						
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
			if(incomeTypes.contains(IncomeType.JOB.val)){
				incomeSourceIndex++;
				currentIncomePage2.enterJobEmployerDetailsForMember(displayShelteredWorkshopQuestion,
						memIndex, 
						incomeSourceIndex, 
						"NEW", 
						jobEmployerName, 
						"EMPSTREET", 
						"1", 
						"Boston", 
						"02210", 
						"SUFFOLK", 
						jobIncomeAmount, 
						jobIncomeEffectiveDate, 
						"Yearly", 
						intHoursWorked, 
						true);
				currentIncomePage2.takeScreenshot();
				currentIncomePage2.clickOnSaveAndContinueBtn();
				
				CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
				currentIncomeDetailsPage1.pageLoadThenClickOnSaveAndContinueBtn();
			}
			
			CurrentIncomeDetailsPage2 currentIncomeDetailsPage2  = new CurrentIncomeDetailsPage2(driver, testCaseId);
			currentIncomeDetailsPage2.selectMemIncomeDeductionsAsNone(memIndex);
			currentIncomeDetailsPage2.selectIfMemberHasSteadyIncome(memIndex, true);
			currentIncomeDetailsPage2.clickOnSaveAndContinueBtn();
			
		}
		
		
		
	}

	
	/**
	 * @author vkuma212
	 * @param memNo   :- 1,2,3,4
	 * @param hasSourceOfIncome  :- TRUE, FALSE

		From Current Income Page 1, Select Member "1" Has Source Of Income As "TRUE"
	
	 */
	@When("^From Current Income Page 1, Select Member \"(.*?)\" Has Source Of Income As \"(.*?)\"$")
	public void selectIfMemHasIncome(String memNo, String hasSourceOfIncome) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		boolean trueFalseValue = hasSourceOfIncome.equalsIgnoreCase("TRUE")?true:false;
		
		CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
		currentIncomePage1.selectIfMemHasIncome(memIndex, trueFalseValue);
	}
	
	/**@author vkuma212
	 *  Accepted Income Type seperated by Commas :-
	 *  			JOB,
	 *  			SELF_EMPLOYMENT,
	 *  			SOCIAL_SECURITY_BENEFITS,
	 *  			UNEMPLOYMENT,
	 *  			RETIREMENT,
	 *  			CAPITALGAINS,
	 *  			INVESTMENT_INCOME,
	 *  			RENTAL_OR_ROYALTY_INCOME,
	 * 				FARMING_OR_FISHING_INCOME,
	 * 				ALIMONY_RECEIVED,
	 * 				OTHER_INCOME
	From Current Income Page 1, Form Mem "1" Select Income Types As "JOB,SELF_EMPLOYMENT"
	 */
	@When("^From Current Income Page 1, Form Mem \"(.*?)\" Select Income Types As \"(.*?)\"$")
	public void selectMemIncomeTypes(String memNo, String incomeTypes) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
		currentIncomePage1.selectMemIncomeTypes(memIndex, incomeTypes);
	}
	
	/**
	 * @author vkuma212
	 * @param memNo   :- 1,2,3,4
	 * @param hasSourceOfIncome  :- TRUE, FALSE

		From Current Income Page 1, Validate Page Title is Not Having Name of Member "1"
	
	 */
	@When("^From Current Income Page 1, Validate Page Title is Not Having Name of Member \"(.*?)\"$")
	public void validatePageTitleDontContainsName(String memNo) throws Exception{
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
	     
	     int memIndex = Integer.parseInt(memNo)-1;
	     
	     ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		 String fullName = elgMemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
		 CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
		 currentIncomePage1.validatePageTitleDontContainsName(fullName);
	}
	
	/**
	 *  Accepted Value :- 1. MemNo
	 *  				  2. SourceOfIncome :- TRUE, FALSE
	 *  				  3. IncomeType :- JOB , Currently Only Job and None covered
	 *  				  4 JobEmployerName :- Optum, XYZ,ABC
	 *  				  5. YearlyAmount:-         10000
	 *  				  6. HoursWorked :- Default (40) , 38, 37
	 *  
	 *  From Current Income Page 1, Select Job Income Details For Members
		| MemNo  | SourceOfIncome	| IncomeType	|	JobEmployerName	|	YearlyAmount	| HoursWorked |
		|  1	 |  TRUE			| JOB  		 	| 	Optum			|	79030			|	40		  |
		|  2	 |  FALSE			|   		 	| 					|					|			  |	   
	 * @throws Exception
	 */
	@When("^From Current Income Page 1, Select Job Income Details For Members$")
	public void completIncomeDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		String displayShelteredWorkshopQuestion = envData.get("Display.sheltered.workshop.question");
		
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		
		String jobIncomeEffectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:30");
		
		
		for(int mCounter=1; mCounter<rowCount; mCounter++){
				
			int memIndex = Integer.parseInt(scenarioData.get(mCounter).get(0))-1;
			Boolean hasSourceOfIncome = scenarioData.get(mCounter).get(1).equalsIgnoreCase("TRUE")?true:false;
			String incomeTypes = scenarioData.get(mCounter).get(2).trim();
			String jobEmployerName=null;
			int jobIncomeAmount=0;
			
			if(incomeTypes.contains(IncomeType.JOB.val)){
				jobEmployerName = scenarioData.get(mCounter).get(3); 
				if(jobEmployerName.equals("")){jobEmployerName = "OPTUM";}
				jobIncomeAmount = Integer.parseInt(scenarioData.get(mCounter).get(4)); 
			}
			String hoursWorked = scenarioData.get(mCounter).get(5).trim();
			if(hoursWorked.equals("")){hoursWorked = "40";}
			int intHoursWorked = Integer.parseInt(hoursWorked);
			
			int incomeSourceIndex =-1;
			CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
			currentIncomePage1.selectIncomeTypeForMember(memIndex, hasSourceOfIncome, incomeTypes);
						
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
			if(incomeTypes.contains(IncomeType.JOB.val)){
				incomeSourceIndex++;
				currentIncomePage2.enterJobEmployerDetailsForMember(displayShelteredWorkshopQuestion,
						memIndex, 
						incomeSourceIndex, 
						"NEW", 
						jobEmployerName, 
						"EMPSTREET", 
						"1", 
						"Boston", 
						"02210", 
						"SUFFOLK", 
						jobIncomeAmount, 
						jobIncomeEffectiveDate, 
						"Yearly", 
						intHoursWorked, 
						true);
				currentIncomePage2.takeScreenshot();
				currentIncomePage2.clickOnSaveAndContinueBtn();
				
				CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
				currentIncomeDetailsPage1.pageLoadThenClickOnSaveAndContinueBtn();
			}
			
			CurrentIncomeDetailsPage2 currentIncomeDetailsPage2  = new CurrentIncomeDetailsPage2(driver, testCaseId);
			currentIncomeDetailsPage2.selectMemIncomeDeductionsAsNone(memIndex);
			currentIncomeDetailsPage2.selectIfMemberHasSteadyIncome(memIndex, true);
			currentIncomeDetailsPage2.clickOnSaveAndContinueBtn();
			
		}
		
		
		
	}
	/** Ritu
	From Current Income Page 1, Select Job Income Details For Members
    	| MemNo  | SourceOfIncome  | IncomeType |      JobEmployerName     |      YearlyAmount | HoursWorked |OtherDeduction| DollerAmtInYear|
    	|  1   	|  TRUE            | JOB        |      Optum               |       79030       |      40     |        HN    | 1000           | 
    	|  2   	|  FALSE           |            |                          |                   |             |       		|				 |
	 */
@When("^From Current Income Page 1, Select Job Income Details For Members If Income Deduction For Member As Others$")
public void completIncomeDetailsAndSelectIncomeTypeAsOther(DataTable table) throws Exception{
    List<List<String>> scenarioData = table.raw();
    int rowCount = scenarioData.size();
    
    String displayShelteredWorkshopQuestion = envData.get("Display.sheltered.workshop.question");
    
    String appDate = new DualTable(conn,"").getSysDate();
    appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
    
    String jobIncomeEffectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:30");
    
    String OtherIncomeType= "OTHER_DEDUCTIONS";
    
    
    for(int mCounter=1; mCounter<rowCount; mCounter++){
                  
           int memIndex = Integer.parseInt(scenarioData.get(mCounter).get(0))-1;
           Boolean hasSourceOfIncome = scenarioData.get(mCounter).get(1).equalsIgnoreCase("TRUE")?true:false;
           String incomeTypes = scenarioData.get(mCounter).get(2).trim();
           String OtherDeductionTxt = scenarioData.get(mCounter).get(6).trim();
           String OtherDeductionAmt = scenarioData.get(mCounter).get(7).trim();
           String jobEmployerName=null;
           int jobIncomeAmount=0;
           
           if(incomeTypes.contains(IncomeType.JOB.val)){
                  jobEmployerName = scenarioData.get(mCounter).get(3); 
                  if(jobEmployerName.equals("")){jobEmployerName = "OPTUM";}
                  jobIncomeAmount = Integer.parseInt(scenarioData.get(mCounter).get(4)); 
           }
           String hoursWorked = scenarioData.get(mCounter).get(5).trim();
           if(hoursWorked.equals("")){hoursWorked = "40";}
           int intHoursWorked = Integer.parseInt(hoursWorked);
           
           int incomeSourceIndex =-1;
           CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
           currentIncomePage1.selectIncomeTypeForMember(memIndex, hasSourceOfIncome, incomeTypes);
                               
           CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
           if(incomeTypes.contains(IncomeType.JOB.val)){
                  incomeSourceIndex++;
                  currentIncomePage2.enterJobEmployerDetailsForMember(displayShelteredWorkshopQuestion,
                               memIndex, 
                               incomeSourceIndex, 
                               "NEW", 
                               jobEmployerName, 
                               "EMPSTREET", 
                               "1", 
                               "Boston", 
                               "02210", 
                               "SUFFOLK", 
                               jobIncomeAmount, 
                               jobIncomeEffectiveDate, 
                               "Yearly", 
                               intHoursWorked, 
                               true);
                  currentIncomePage2.takeScreenshot();
                  currentIncomePage2.clickOnSaveAndContinueBtn();
                  
                  CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
                  currentIncomeDetailsPage1.pageLoadThenClickOnSaveAndContinueBtn();
           }
           
           CurrentIncomeDetailsPage2 currentIncomeDetailsPage2  = new CurrentIncomeDetailsPage2(driver, testCaseId);
           currentIncomeDetailsPage2.selectMemIncomeDeductions(memIndex,OtherIncomeType);
           currentIncomeDetailsPage2.enterWhatOtherDeductionDoYouHave(memIndex,OtherDeductionTxt);
           currentIncomeDetailsPage2.enterOtherDeductionAmount( memIndex, OtherDeductionAmt);
           currentIncomeDetailsPage2.selectIfMemberHasSteadyIncome(memIndex, true);
           currentIncomeDetailsPage2.clickOnSaveAndContinueBtn();
           
    	}
    
    /**
     * @Author:Suryam
     * 
     * Use if hub responses that member has other source of income too
     * 
     * From Current Income Page 1, Handle Warning Dialog If Present
     * 
     */

}

    @Given("^From Current Income Page 1, Handle Warning Dialog If Present$")
    public void handleWarningDialogIfPresent() throws Exception {
    	CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
    	currentIncomePage1.handleWarningDialogIfPresent();
    }
         

	
	
	
}
