package stepdefs.income;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import pages.income.CurrentIncomePage2;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class CurrentIncomePage2Steps extends SuperStepDef{
	
	public CurrentIncomePage2Steps(Hook hook){
		super(hook);
	}
	
	@When("^From Current Income Page 2, Page Load Click On Save And Continue$")
	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception{
		
		CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
		currentIncomePage2.pageLoadAndClickOnSaveAndContinueBtn();
	}
	
	@When("^From Current Income Page 2, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception{
		
		CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
		currentIncomePage2.clickOnSaveAndContinueBtn();
	}
	
	@When("^From Current Income Page 2, Take Screenshot$")
	public void takeScreenshot() throws Exception{
		
		CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
		currentIncomePage2.takeScreenshot();
	}
	
	/**
	 * Author :- ppinho
	 * 		To Be used During RAC , to update only Employer Name
		 
	 From Current Income Page 2, For Member "2", Edit Employer Name As "ABC"

	 */
	@When("^From Current Income Page 2, For Member \"(.*?)\", Edit Employer Name As \"(.*?)\"$")
	public void updateEmpName(String memNo, String empName) throws Exception{
			
		int memIndex = Integer.parseInt(memNo)-1;
		
		CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
		currentIncomePage2.clickOnEditEmployerName();
		currentIncomePage2.clickOnPopupOkBtn();
		currentIncomePage2.enterEmployerNameForMember(memIndex, 0, empName);
	}

	/**
	 * Author :- Ritika
	 * 		To Be used During RAC , to update only Income
	 
	 From Current Income Page 2, For Member "2", Update Job Income As "10000"

	 */
	@When("^From Current Income Page 2, For Member \"(.*?)\", Update Job Income As \"(.*?)\"$")
	public void updateIncome(String memNo, String updateInc) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		int updateIncome = Integer.parseInt(updateInc);
		
		CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
		currentIncomePage2.enterJobIncomeAmountForMember(memIndex,0,updateIncome);
		currentIncomePage2.takeScreenshot();
	}
	
	/**
	 * Author :- Vinay
	 
	 From Current Income Page 2, Validate Page Title is Not Having Name of Member "1"

	 */
	@When("^From Current Income Page 2, Validate Page Title is Not Having Name of Member \"(.*?)\"$")
	public void updateIncome(String memNo) throws Exception{
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
	     
	     int memIndex = Integer.parseInt(memNo)-1;
	     
	     ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		 String fullName = elgMemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
		
		CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
		currentIncomePage2.waitForPageLoad(0);
		currentIncomePage2.validatePageTitleDontContainsName(fullName);
	}
	
	/**
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. JobEmployerName :- Optum, ABC, XYZ
	 *  				  4. YearlyAmount:-         10000
	 *  				  5. HoursWorked :- Default (40) , 38, 37
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2, Select Job Income Details For Members
		| MemNo  | IncomeSourceIndex | JobEmployerName	|	YearlyAmount	|HoursWorked |
		|  1	 | 	    0            |     Optum		|	79030			|			 |
	 * @throws Exception
	 */
	
	
	@When("^From Current Income Page 2, Select Job Income Details For Members$")
	public void enterJobEmployerDetailsForMember(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String displayShelteredWorkshopQuestion = envData.get("Display.sheltered.workshop.question");
		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String jobIncomeEffectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:30");
		
		int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
		int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
		String jobEmployerName = scenarioData.get(1).get(2); 
		if(jobEmployerName.equals("")){jobEmployerName = "OPTUM";}
		int jobIncomeAmount = Integer.parseInt(scenarioData.get(1).get(3)); 

		String hoursWorked = scenarioData.get(1).get(4).trim();
		if(hoursWorked.equals("")){hoursWorked = "40";}
		int intHoursWorked = Integer.parseInt(hoursWorked);
		
		CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
		currentIncomePage2.enterJobEmployerDetailsForMember(displayShelteredWorkshopQuestion,
					memIndex, 
					incomeSourceIndex, 
					"NEW", 
					jobEmployerName, 
					"EMPSTREET", 
					"1", 
					"Boston", 
					"02210", 
					"SUFFOLK", 
					jobIncomeAmount, 
					jobIncomeEffectiveDate, 
					"Yearly", 
					intHoursWorked, 
					true);
	}
	
	/**@author sshriv16
     *  Accepted Value :- 1. MemNo
     *                          2.  IncomeSourceIndex =0,1,2
     *                          3. OtherIncomeType :- Canceled_Debts, Court_Awards,Jury_Duty_Pay,Other
     *                          4. ProfitAmountMonthly:-         10000
     *                  Only One Member Value at a time
           
           From Current Income Page 2, Enter Other Job Income Details For Member
           | MemNo  | IncomeSourceIndex | JobEmployerName      |       YearlyAmount |HoursWorked |
           |  1   |         1            |     XYZ             |       5000                |                   |
           
     * @throws Exception
     */
     @When("^From Current Income Page 2, Enter Other Job Income Details For Member$")
     public void completeOtherJobIncomeDetails(DataTable table) throws Exception{
           
           List<List<String>> scenarioData = table.raw();
           String displayShelteredWorkshopQuestion = envData.get("Display.sheltered.workshop.question");
           
           String appDate = TestData.getTempTestData("AppDate", featureFileName);
           String jobIncomeEffectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:30");
           
           int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
           int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
           String jobEmployerName = scenarioData.get(1).get(2); 
           if(jobEmployerName.equals("")){jobEmployerName = "OPTUM";}
           int jobIncomeAmount = Integer.parseInt(scenarioData.get(1).get(3)); 

           String hoursWorked = scenarioData.get(1).get(4).trim();
           if(hoursWorked.equals("")){hoursWorked = "40";}
           int intHoursWorked = Integer.parseInt(hoursWorked);
           
           CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
           currentIncomePage2.clickAddOtherIncomeButton();
            currentIncomePage2.enterJobEmployerDetailsForMember(displayShelteredWorkshopQuestion,
                               memIndex, 
                               incomeSourceIndex, 
                               "NEW", 
                               jobEmployerName, 
                               "EMPSTREET", 
                               "1", 
                               "Boston", 
                               "02210", 
                               "SUFFOLK", 
                               jobIncomeAmount, 
                               jobIncomeEffectiveDate, 
                               "Yearly", 
                               intHoursWorked, 
                               true);
     }

	
	/**@author rnegi101
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. profitLossValue :- Profit, Loss
	 *  				  4. ProfitAmountMonthly:-         10000
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2, Select Self Employment Income Details For Member
		| MemNo  | IncomeSourceIndex | ProfitAmountMonthly		|
		|  1	 | 	    1            |     30000       			|
	 * @throws Exception
	 */
	
	
	@When("^From Current Income Page 2, Select Self Employment Income Details For Member$")
	public void enterSelfEmpEmployerDetailsForMember(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();

		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String selfEmpEffectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:30");
		String selfEmpWorkType="Business";
		int selfEmpHrsPerWeek=40;
		
		int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
		int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
		Boolean isLoss=false;
		int selfEmpProfitAmountMonthly=Integer.parseInt(scenarioData.get(1).get(2));
		
		CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
		currentIncomePage2.enterSelfEmpEmployerDetailsForMember(memIndex,
				incomeSourceIndex,
				isLoss,
				selfEmpWorkType,
				selfEmpProfitAmountMonthly,
				selfEmpEffectiveDate,
				selfEmpHrsPerWeek);
	}

	/**@author rnegi101
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. SSB_Amount :- 3000
	 *  				  4. Frequency:-         Yearly
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2, Select SSB Income Details For Member
		| MemNo  | IncomeSourceIndex | SSB_Amount 		|Frequency		|
		|  1	 | 	    2            |    3000			|    Yearly		|
	 * @throws Exception
	 */
	@When("^From Current Income Page 2, Select SSB Income Details For Member$")
	public void completeSSBIncomeDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
				
		int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
		int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
		int ssbAmt=Integer.parseInt(scenarioData.get(1).get(2));
		String ssbAmountFrequency=scenarioData.get(1).get(3);
						
		CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
		currentIncomePage2.enterSocialSecurityBenefitsDetailsForMember( memIndex,incomeSourceIndex, ssbAmt,ssbAmountFrequency);
	}
	
	/**@author rnegi101
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. Unemp_Amount :- 3000
	 *  				  4. Frequency:-         Yearly
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2, Select Unemployment Income Details For Member
		| MemNo  | IncomeSourceIndex | Unemp_Amount 		|Frequency		|
		|  1	 | 	    4            |    3000				|    Yearly		|
	 * @throws Exception
	 */
	@When("^From Current Income Page 2, Select Unemployment Income Details For Member$")
	public void completeUnemploymentIncomeDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
				
			int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
			int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
			int unEmploymentAmt=Integer.parseInt(scenarioData.get(1).get(2));
			String unEmploymentAmtFrequency=scenarioData.get(1).get(3);
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
			currentIncomePage2.enterUnemploymentDetailsForMember( memIndex,incomeSourceIndex, unEmploymentAmt,unEmploymentAmtFrequency);
		}
	

	/**@author rnegi101
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. Retirement_Amount :- 3000
	 *  				  4. Frequency:-         Yearly
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2, Select Retirement Or Pension Income Details For Member
		| MemNo  | IncomeSourceIndex | Retirement_Amount 	|Frequency		|
		|  1	 | 	    4           |    3000				|    Yearly		|
	 * @throws Exception
	 */
	@When("^From Current Income Page 2, Select Retirement Or Pension Income Details For Member$")
	public void completeRetiermentIncomeDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
				
			int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
			int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
			int retirementAmt=Integer.parseInt(scenarioData.get(1).get(2));
			String retirementAmtFrequency=scenarioData.get(1).get(3);
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
			currentIncomePage2.enterRetirementOrPensionDetailsForMember( memIndex,incomeSourceIndex, retirementAmt,retirementAmtFrequency);
		}
	
	/**@author rnegi101
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. CapitalGainMonthly_Amount:-         10000
	 *  				  4. CapitalGainYealy_AMT :- 3000
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2, Select Capital Gains  Income Details For Member
		| MemNo  | IncomeSourceIndex | CapitalGainMonthly_Amount 	|CapitalGainYealy_AMT	|
		|  1	 | 	    5            |    3000				        |    2000		        |
	 * @throws Exception
	 */
	@When("^From Current Income Page 2, Select Capital Gains Income Details For Member$")
	public void completeCapitalGainsIncomeDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
				
			int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
			int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
			int capitalGainsMonthlyAmt=Integer.parseInt(scenarioData.get(1).get(2));
			int capitalGainsYearlyAmt=Integer.parseInt(scenarioData.get(1).get(3));
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
			currentIncomePage2.enterCapitalGainsDetailsForMember(memIndex,incomeSourceIndex,capitalGainsMonthlyAmt,capitalGainsYearlyAmt);
		}
	
	
	
	/**@author rnegi101
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. InterestAndDividends_Amount:-         10000
	 *  				   4. Frequency :- Yearly
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2, Select Interest, Dividends, or Other Investment Income Details For Member
		| MemNo  | IncomeSourceIndex | InterestAndDividends_Amount 	|Frequency		|
		|  1	 | 	    6            |    3000				        |    Yearly	    |
	 * @throws Exception
	 */
	@When("^From Current Income Page 2, Select Interest, Dividends, or Other Investment Income Details For Member$")
	public void completeInterestAndDividendsIncomeDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
				
			int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
			int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
			int interestAndDividendsAmt=Integer.parseInt(scenarioData.get(1).get(2));
			String interestAndDividendsFrequency=scenarioData.get(1).get(3);
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
			currentIncomePage2.enterInterestDividendsOtherInvestmentDetailsForMember(memIndex,incomeSourceIndex,interestAndDividendsAmt,interestAndDividendsFrequency);
		}
	
	
	
	/**@author rnegi101
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. Rental and Royality_Amount:-         10000
	 *  				  4. Frequency :- Yearly
	 *             5.Amount_Type   : Profit(false) /Loss(TRUE)
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2, Select Rental and Royality Income Details For Member
		| MemNo  | IncomeSourceIndex |Rental and Royality_Amount 	|Frequency		|
		|  1	 | 	    8            |        3000				    |    Yearly	    |
	 * @throws Exception
	 */
	@When("^From Current Income Page 2, Select Rental And Royality Income Details For Member$")
	public void completeRentalAndRoyalityIncomeDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
				
			int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
			int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
			int rentalRoyalityAmt=Integer.parseInt(scenarioData.get(1).get(2));
			String rentalRoyalityFrequency=scenarioData.get(1).get(3);
			boolean AmtTypetrueFalseValue =false;
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
			currentIncomePage2.enterRentalOrRoyaltyDetailsForMember(memIndex,incomeSourceIndex,rentalRoyalityFrequency,AmtTypetrueFalseValue,rentalRoyalityAmt);
		}

	
	/**@author rnegi101
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. ProfitAmount:-         10000
	 *  				  4. Frequency :- Yearly
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2, Select Farming or Fishing Income Details For Member
		| MemNo  | IncomeSourceIndex | 		ProfitAmount	|Frequency |
		|  1	 | 	    9            |       30000          |  Yearly |
	 * @throws Exception
	 */
	
	
	@When("^From Current Income Page 2, Select Farming or Fishing Income Details For Member$")
	public void enterFarmingOrFishingDetailsForMember(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();

		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String fishingFarmingDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:30");
		int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
		int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
		int fishingFarmingAmt=Integer.parseInt(scenarioData.get(1).get(2));
		String fishingFarmingFrequency=scenarioData.get(1).get(3);
		CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
		currentIncomePage2.enterFarmingFishingDetailsForMember(memIndex,incomeSourceIndex,fishingFarmingDate,fishingFarmingAmt,fishingFarmingFrequency);
	}
	
	
	/**@author rnegi101
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. AlimonyReceived_Amount:-         10000
	 *  				  4. Frequency  :- Yearly
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2, Select Alimony Received, Income Details For Member
		| MemNo  | IncomeSourceIndex | AlimonyReceived_Amount 	|Frequency		|
		|  1	 | 	    10            |    3000				    |    Yearly	    |
	 * @throws Exception
	 */
	@When("^From Current Income Page 2,Select Alimony Received Income Details For Member$")
	public void completeAlimonyReceivedIncomeDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
				
			int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
			int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
			int alimonyReceivedAmt=Integer.parseInt(scenarioData.get(1).get(2));
			String alimonyReceivedFrequency=scenarioData.get(1).get(3);
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
			currentIncomePage2.enterAlimonyDetailsForMember(memIndex,incomeSourceIndex,alimonyReceivedAmt,alimonyReceivedFrequency);
		}
	
	
	/**@author rnegi101
	 *  Accepted Value :- 1. MemNo
	 *  				  2.  IncomeSourceIndex =0,1,2
	 *  				  3. OtherIncomeType :- Canceled_Debts, Court_Awards,Jury_Duty_Pay,Other
	 *  				  4. ProfitAmountMonthly:-         10000
	 *  			Only One Member Value at a time
	 *  From Current Income Page 2,Select Other Income Details For Member
		| MemNo  | IncomeSourceIndex |OtherIncomeType   | Other_Amount 	            |Frequency		|
		|  1	 | 	    10            |  Canceled Debts | 3000				        |    Yearly	    |
		
	 * @throws Exception
	 */
	@When("^From Current Income Page 2,Select Other Income Details For Member$")
	public void completeOtherIncomeDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
				
			int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
			int incomeSourceIndex = Integer.parseInt(scenarioData.get(1).get(1));
			String otherIncomeType=scenarioData.get(1).get(2);
			int otherAmt=Integer.parseInt(scenarioData.get(1).get(3));
			String otherFrequency=scenarioData.get(1).get(4);
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
			currentIncomePage2.enterOtherIncomeDetailsForMember(memIndex,incomeSourceIndex,otherAmt,otherFrequency,otherIncomeType);
		}
}
