package stepdefs.common;
import cucumber.api.java.en.And;
import db.DualTable;
import db.ElgMemberTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;

/**
 *  This Page Appears when we click on View All link on Account Dashboard Page
 * @author Vinay Kumar
 *
 */

public class Steps extends SuperStepDef {
	
	public Steps(Hook hook) {
		super(hook);
	}
	
	/**
	 * Store Variable "ElgId_MMIS1_Validation" Value Same As CurrentEligibilityId 	
	 */
	
	@And("^Store Variable \"(.*?)\" Value Same As CurrentEligibilityId")
	public void storeVariableInTempData(String variableName) throws Exception {
		String currentEligibilityId = getTempTestData("CurrentEligibilityId");
		storeTempTestData(variableName, currentEligibilityId);
	}
	
	/**@author akumari4
	 * 
	 * Store Variable "ProfileID_1" Value Same As UserProfileRefId
	 */
	
	@And("^Store Variable \"(.*?)\" Value Same As UserProfileRefId")
	public void storeProfileIDInTempData(String variableName) throws Exception {
		String profileID = getTempTestData("UserProfileRefId");
		storeTempTestData(variableName, profileID);
	}
	
	/**
	 * Store Member "2" First Name Using CurrentEligibilityId
	 */
	
	@And("^Store Member \"(.*?)\" First Name Using CurrentEligibilityId")
	public void storeFirstNameForMember(String memNo) throws Exception {
		String currentEligibilityId = getTempTestData("CurrentEligibilityId");
		int memIndex = Integer.parseInt(memNo) - 1;
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		String firstName = elgMemberTable.getFirstName(currentEligibilityId, memIndex);
		storeTempTestData("Mem_" + memNo + "FirstName", firstName);
	}
	
	/**
	 * Store Member "2" Middle Name Using CurrentEligibilityId
	 */
	
	@And("^Store Member \"(.*?)\" Middle Name Using CurrentEligibilityId")
	public void storeMiddleNameForMember(String memNo) throws Exception {
		String currentEligibilityId = getTempTestData("CurrentEligibilityId");
		int memIndex = Integer.parseInt(memNo) - 1;
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		String middleName = elgMemberTable.getMiddleName(currentEligibilityId, memIndex);
		storeTempTestData("Mem_" + memNo + "MiddleName", middleName);
	}
	
	/**
	 * Store Member "2" Last Name Using CurrentEligibilityId
	 */
	
	@And("^Store Member \"(.*?)\" Last Name Using CurrentEligibilityId")
	public void storeLastNameForMember(String memNo) throws Exception {
		String currentEligibilityId = getTempTestData("CurrentEligibilityId");
		int memIndex = Integer.parseInt(memNo) - 1;
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		String lastName = elgMemberTable.getLastName(currentEligibilityId, memIndex);
		storeTempTestData("Mem_" + memNo + "LastName", lastName);
	}
	
	/**
	 * @author akumari4
	 * 
	 * Store Member "2" Suffix Using CurrentEligibilityId
	 */
	
	@And("^Store Member \"(.*?)\" Suffix Using CurrentEligibilityId")
	public void storeSuffixForMember(String memNo) throws Exception {
		String currentEligibilityId = getTempTestData("CurrentEligibilityId");
		int memIndex = Integer.parseInt(memNo) - 1;
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		String suffix = elgMemberTable.getLastName(currentEligibilityId, memIndex);
		storeTempTestData("Mem_" + memNo + "Suffix", suffix);
	}
	
	/**
	 * Store Member "2" DOB Using CurrentEligibilityId
	 */
	
	@And("^Store Member \"(.*?)\" DOB Using CurrentEligibilityId")
	public void storeDOBForMember(String memNo) throws Exception {
		String currentEligibilityId = getTempTestData("CurrentEligibilityId");
		int memIndex = Integer.parseInt(memNo) - 1;
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		String dob = elgMemberTable.getDOB(currentEligibilityId, memIndex);
		dob = DateUtil.getDateInUIFormatUsingPattern(dob, DateUtil.dbDatePattern);
		storeTempTestData("Mem_" + memNo + "DOB", dob);
	}
	
	/**
	* Store Current Date As RAC_Date
	*/
	
	@And("^Store Current Date As RAC_Date$")
	public void storeCurrentDateAs() throws Exception {
		String currentDate = new DualTable(conn, "").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);
		storeTempTestData("RAC_Date", currentDate);
	}
	
}
