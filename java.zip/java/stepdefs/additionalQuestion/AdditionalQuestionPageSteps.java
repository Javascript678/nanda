package stepdefs.additionalQuestion;
import cucumber.api.java.en.When;
import pages.additionalQuestion.AdditionalQuestionStartPage;
import pages.additionalQuestion.AdditionalQuestionSummaryPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class AdditionalQuestionPageSteps extends SuperStepDef{
	
	public AdditionalQuestionPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^EVPD, Complete Additional Question Details$")
	public void completAdditionalQuestionDetails() throws Exception {		
		AdditionalQuestionStartPage additionalQuestionStartPage = new AdditionalQuestionStartPage(driver, testCaseId);
		additionalQuestionStartPage.evpdEnterAdditionalQuestionsForMembers(evpdData.faReqd, evpdData.whoIsApplying, evpdData.atleastOneMemberAbove18, evpdData.memsData);
		
		AdditionalQuestionSummaryPage AdditionalQuestionSummaryPage = new AdditionalQuestionSummaryPage(driver, testCaseId);
		AdditionalQuestionSummaryPage.pageLoadThenClickOnSaveAndContinueBtn(evpdData.faReqd);
	}
}
