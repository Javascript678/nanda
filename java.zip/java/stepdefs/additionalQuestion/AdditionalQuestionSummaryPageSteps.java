package stepdefs.additionalQuestion;
import cucumber.api.java.en.When;
import pages.additionalQuestion.AdditionalQuestionSummaryPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

/**
 * @author rgupta64
 *
 */
public class AdditionalQuestionSummaryPageSteps extends SuperStepDef{
	
	public AdditionalQuestionSummaryPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Additional Question Summary Page, Page Load And Click On Save And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {

		AdditionalQuestionSummaryPage AdditionalQuestionSummaryPage = new AdditionalQuestionSummaryPage(driver, testCaseId);
		AdditionalQuestionSummaryPage.pageLoadThenClickOnSaveAndContinueBtn();
		
	}
	
	@When("^From Additional Question Summary Page, Take ScreenShot$")
	public void takeScreenshot() throws Exception {

		AdditionalQuestionSummaryPage additionalQuestionSummaryPage = new AdditionalQuestionSummaryPage(driver, testCaseId);
		additionalQuestionSummaryPage.takeScreenshot();
		
	}
	
	//use it when certain validation is required to be done on this page
	@When("^From Additional Question Summary Page, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception {

		AdditionalQuestionSummaryPage additionalQuestionSummaryPage = new AdditionalQuestionSummaryPage(driver, testCaseId);
		additionalQuestionSummaryPage.clickOnSaveAndContinueBtn();
		
	}
	
	/**@author rgupta64
	 * From Additional Question Summary Page, Validate MEC As "NO" And Optional EnrollinHP As "NO" For Member "1"
	 * @throws Exception
	 */
	@When("^From Additional Question Summary Page, Validate MEC As \"(.*?)\" And Optional EnrollinHP As \"(.*?)\" For Member \"(.*?)\"$")
	public void validateThenClickOnSaveAndContinueBtn(String insValue,String insHPValue,String memNo ) throws Exception {

		int memIndex = Integer.parseInt(memNo);
		AdditionalQuestionSummaryPage AdditionalQuestionSummaryPage = new AdditionalQuestionSummaryPage(driver, testCaseId);
		AdditionalQuestionSummaryPage.validateMECForMember(memIndex, insValue);
		AdditionalQuestionSummaryPage.validateEnrollInHPForMember(memIndex, insHPValue);

	}
	
}
