package stepdefs.additionalQuestion;
import cucumber.api.java.en.When;
import pages.additionalQuestion.NCPQuestionPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class NCPQuestionPageSteps extends SuperStepDef{
	
	public NCPQuestionPageSteps(Hook hook){
		super(hook);
	}
	
	/**@author vkuma212
	 * 		Name of Actual Page ON UI is Mass Health Specific Question
	 * 	
	 * 
	 * From NCP Question Page, Complete NCP Questions For Member "1", Considering RFI Required Is "TRUE"
	 * 
	 */
	@When("^From NCP Question Page, Complete NCP Questions For Member \"(.*?)\", Considering RFI Required Is \"(.*?)\"$")
	public void completeNCPQuestion(String memNo, String  strNcpRFIRequired) throws Exception{
		Boolean ncpRFIRequired=strNcpRFIRequired.equalsIgnoreCase("TRUE")?true:false;
		NCPQuestionPage ncpQuestionPage = new NCPQuestionPage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		
		if(ncpRFIRequired){
			ncpQuestionPage.completeNCPQuestion(memIndex, true, true, true, true);
		}else{
			ncpQuestionPage.completeNCPQuestion(memIndex, false, true, false, false);
		}
		
	}
	
	/**@author vkuma212
	 * 		Name of Actual Page ON UI is Mass Health Specific Question
	 * 	
	 * 
	 * From NCP Question Page, Click On Save And Continue
	 * 
	 */
	@When("^From NCP Question Page, Click On Save And Continue$")
	public void completeNCPQuestion() throws Exception{
		NCPQuestionPage ncpQuestionPage = new NCPQuestionPage(driver, testCaseId);
		ncpQuestionPage.clickOnSaveAndContinueBtn();
		
	}

}
