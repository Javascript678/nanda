package stepdefs.additionalQuestion;
import cucumber.api.java.en.When;
import pages.additionalQuestion.AdditionalQuestionStartPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class AdditionalQuestionStartPageSteps extends SuperStepDef{
	
	public AdditionalQuestionStartPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Additional Question Start Page, Click On Save And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {

		AdditionalQuestionStartPage additionalQuestionStartPage = new AdditionalQuestionStartPage(driver, testCaseId);
		additionalQuestionStartPage.pageLoadThenClickOnSaveAndContinueBtn();
		
	}
	

}
