package stepdefs.additionalQuestion;

import cucumber.api.java.en.When;
import db.DualTable;
import db.ElgMemberTable;
import pages.additionalQuestion.HealthInsuranceInfoPage;
import pages.additionalQuestion.OtherInsurancePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class OtherInsurancePageSteps extends SuperStepDef{
	
	public OtherInsurancePageSteps(Hook hook){
		super(hook);
	}
	
	/**@author Ritika
	 * 		Accepted Val :- 
	 * 		MemNo :- 1,2,3
	 * 		OtherHltInsuranceRetiralTypes:-
	 * 				MASS_HEALTH,
	 * 				MEDICARE,
	 * 				PEACE_CORPS,
	 * 				TRICARE,
	 * 				VA_HEALTH_PROGRAM,
	 * 				OTHER
	 
	  From Other Insurance Info Page, Select Other Insurance Type As "MEDICARE", With Effective Date Prior From Today As "10"
		
	 */
	@When("^From Other Insurance Info Page, Select Other Insurance Type As \"(.*?)\", With Effective Date Prior From Today As \"(.*?)\"$")
	public void selectOtherHealthCoverageRdBtnForMember(String otherHltInsuranceRetiralTyps, String effectiveDatePriorFromToday ) throws Exception{
		OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);

		String currentDate = new DualTable(conn,"").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);

		
		String effectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+effectiveDatePriorFromToday);
		if(otherHltInsuranceRetiralTyps.equalsIgnoreCase("MASS_HEALTH")){
			otherInsurancePage.selectOtherHealthInsuranceMixedAsMH();	
		}
		if(otherHltInsuranceRetiralTyps.equalsIgnoreCase("MEDICARE")){
			String medicarePolNo = globalData.get("Member_Medicare_PlanNo");
			otherInsurancePage.selectOtherHealthInsuranceMixedAsMedicare();	
			otherInsurancePage.enterPolicyNoMemIDforMedicare(medicarePolNo);
			otherInsurancePage.enterCoverageStartDateForMedicare(effectiveDate);
		}

		if(otherHltInsuranceRetiralTyps.equalsIgnoreCase("PEACE_CORPS")){
			otherInsurancePage.selectOtherHealthInsuranceMixedAsPeaceCorps();	
			otherInsurancePage.enterCoverageStartDateForPeaceCorps(effectiveDate);
		}

		if(otherHltInsuranceRetiralTyps.equalsIgnoreCase("TRICARE")){
			otherInsurancePage.selectOtherHealthInsuranceMixedAsTricare();
			String tricarePolNo = globalData.get("Member_Tricare_PlanNo");
			otherInsurancePage.enterPolicyNoMemIDforTricare(tricarePolNo);
			otherInsurancePage.enterCoverageStartDateForTricare(effectiveDate);
		}

		if(otherHltInsuranceRetiralTyps.equalsIgnoreCase("VA_HEALTH_PROGRAM")){
			otherInsurancePage.selectOtherHealthInsuranceMixedAsVA();
			otherInsurancePage.enterCoverageStartDateForVA(effectiveDate);
		}

		if(otherHltInsuranceRetiralTyps.equalsIgnoreCase("OTHER")){
			otherInsurancePage.selectOtherHealthInsuranceMixedAsOther();
			String otherPlanName = globalData.get("Member_Other_PlanName");
			String otherPolNo = globalData.get("Member_Other_PlanId");
			otherInsurancePage.enterPlanNameforOther(otherPlanName);
			otherInsurancePage.enterPolicyNoMemIDforOther(otherPolNo);
		}

		otherInsurancePage.clickOnSaveAndContinueBtn();
	}
	
	/*	@Ritu
	From Other Insurance Info Page, Select Insurance Type As None Of The Above
	 */	
	@When("^From Other Insurance Info Page, Select Insurance Type As None Of The Above$")
	public void selectNoneOfTheAboveHealthCoverageChkBoxForMember() throws Exception{
		OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);
		otherInsurancePage.selectOtherHealthInsuranceMixedAsNone();
		otherInsurancePage.clickOnSaveAndContinueBtn();
	}
	
	/**@author abajpai3
	 * Consider None of the Above is already selected , de selct It

    From Other Insurance Info Page, Deselect None Of The Above
    */
     @When("^From Other Insurance Info Page, Deselect None Of The Above$")
    public void deselectOtherHealthInsuranceAsNone() throws Exception{
          OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);
          otherInsurancePage.deselectOtherHealthInsuranceAsNone();
    }
	
	/**@author Ritu

    From Other Insurance Info, Page Load And Click On SaveAndContinue

    */
    @When("^From Other Insurance Info, Page Load And Click On SaveAndContinue$")
    public void pageLoadAndClickOnSaveAndContinue() throws Exception{
          OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);
          otherInsurancePage.pageLoadAndClickOnSaveAndContinueBtn();
    }
    
    /**@author Vinay

    From Other Insurance Info, Validate Page Title is Not Having Name of Member "1"

    */
    @When("^From Other Insurance Info, Validate Page Title is Not Having Name of Member \"(.*?)\"$")
    public void validatePageTitleDontContainsName(String memNo) throws Exception{
    	 String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
	     
	     int memIndex = Integer.parseInt(memNo)-1;
	     
	     ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		 String fullName = elgMemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
         OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);
         otherInsurancePage.validatePageTitleDontContainsName(fullName);
    }

}
