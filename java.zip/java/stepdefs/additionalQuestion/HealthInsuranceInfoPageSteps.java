package stepdefs.additionalQuestion;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import enums.InsurancePolicySource;
import pages.additionalQuestion.EmployerHealthCoverageInfoPage;
import pages.additionalQuestion.HealthInsuranceInfoPage;
import pages.additionalQuestion.MassHealthSpecQuestionPage;
import pages.additionalQuestion.NCPQuestionPage;
import pages.additionalQuestion.OtherInsurancePage;
import pages.additionalQuestion.TaxFilerAndOtherAdditionalQuePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class HealthInsuranceInfoPageSteps extends SuperStepDef{
	
	public HealthInsuranceInfoPageSteps(Hook hook){
		super(hook);
	}
	
	/**@author vkuma212
	 * 		Member No Should be Sequence
	 * 	
	 * From Health Insurance Info Page, Select No Insurance For Members
		| MemNo  | TaxFilerQueAppear | TaxFilerQueAns 	| TaxFilerNOSSNQueAppear | TaxFilerNOSSNAns 	|	NCP_RFI_Que_Appear	| NCP_RFI_Reqd		| MassHealthSpecQueAppear	| MassHealthSpecQueAns	|
		|  1	 |  TRUE			 |    TRUE			|		FALSE			 |  FALSE  		 		| 	TRUE				|  FALSE			|		TRUE				|		TRUE			|
		|  2	 |  FALSE			 |    TRUE			|		FALSE		     |  	  		 	    | 	TRUE				|  TRUE				|		TRUE				|		TRUE			|
		|  3	 |  TRUE			 |    TRUE			|		FALSE		     |  TRUE  		 		| 	FALSE				|  FALSE			|		TRUE				|		TRUE			|
		
	 */
	@When("^From Health Insurance Info Page, Select No Insurance For Members$")
	public void completAdditionalQuestionDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
				
		HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
		OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);
		TaxFilerAndOtherAdditionalQuePage taxFilerAndOtherAdditionalQuePage = new TaxFilerAndOtherAdditionalQuePage(driver, testCaseId);
		NCPQuestionPage ncpQuestionPage = new NCPQuestionPage(driver, testCaseId);
		MassHealthSpecQuestionPage massHealthSpecQuestionPage = new MassHealthSpecQuestionPage(driver, testCaseId);
		
		
		for(int rowCounter=1; rowCounter<rowCount; rowCounter++){
			int memIndex = Integer.parseInt(scenarioData.get(rowCounter).get(0))-1;
			
			healthInsuranceInfoPage.selectNoHealthInsuranceForMember(memIndex);
			healthInsuranceInfoPage.selectNoHRAInfoForMember(memIndex);

			//Boolean taxFilerQuestionReqd=scenarioData.get(rowCounter).get(1).equalsIgnoreCase("TRUE")?true:false;
			//Boolean taxFilerQuestionAns=scenarioData.get(rowCounter).get(2).equalsIgnoreCase("TRUE")?true:false;
			Boolean taxFilerNoSSNQuestionReqd=scenarioData.get(rowCounter).get(3).equalsIgnoreCase("TRUE")?true:false;
			Boolean taxFilerNoSSNQuestionAns=scenarioData.get(rowCounter).get(4).equalsIgnoreCase("TRUE")?true:false;
			Boolean ncpQuestionReqd=scenarioData.get(rowCounter).get(5).equalsIgnoreCase("TRUE")?true:false;
			Boolean ncpRFIRequired=scenarioData.get(rowCounter).get(6).equalsIgnoreCase("TRUE")?true:false;
			Boolean massHealthSpecQuestionReqd=scenarioData.get(rowCounter).get(7).equalsIgnoreCase("TRUE")?true:false;
			Boolean massHealthSpecQuestionAns=scenarioData.get(rowCounter).get(8).equalsIgnoreCase("TRUE")?true:false;
			
			//Commenting because Tax Filer Question moved to Family HH module just before summary page
			/*if(taxFilerQuestionReqd){
				taxFilerAndOtherAdditionalQuePage.completeTaxFilerQuestion(memIndex, taxFilerQuestionAns);
			}*/
			
			if(taxFilerNoSSNQuestionReqd){
				taxFilerAndOtherAdditionalQuePage.evpdCompleteSSNQuestion(memIndex, taxFilerNoSSNQuestionAns);
			}
			
			if(ncpQuestionReqd){
				if(ncpRFIRequired){
					ncpQuestionPage.completeNCPQuestion(memIndex, true, true, true, true);
				}else{
					ncpQuestionPage.completeNCPQuestion(memIndex, false, true, false, false);
				}
			}
			
			if(massHealthSpecQuestionReqd){
				massHealthSpecQuestionPage.completeMassHealthSpecQuestion(memIndex, massHealthSpecQuestionAns);
			}
		}
		
	}
	
	/**@author vkuma212

	 From Health Insurance Info Page, For Member "1", Select Insurance Offered Through Job As "TRUE"

	 */
	@When("^From Health Insurance Info Page, For Member \"(.*?)\", Select Insurance Offered Through Job As \"(.*?)\"$")
	public void selectHealthInsuranceInfoAsNoneForMember(String memNo, String offered ) throws Exception{

		int memIndex = Integer.parseInt(memNo)-1;
		Boolean trueFalseValue = offered.equalsIgnoreCase("TRUE")?true:false;
		HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
		healthInsuranceInfoPage.selectIfOfferedThroughJobForMember(memIndex,trueFalseValue);
	}

	/**@author Ritika

	 From Health Insurance Info Page,Select Insurance as ESI with Employer Name as "OPTUM" For Member "1"

	 */
	@When("^From Health Insurance Info Page,Select Insurance as ESI with Employer Name as \"(.*?)\" For Member \"(.*?)\"$")
	public void selectHealthInsuranceInfoAsESIForMember(String EmpName, String memNo) throws Exception{
		int memIndex=Integer.parseInt(memNo)-1;
		String employerPrimarnyPhoneNo = globalData.get("Member_Employer_Phone_No1");
		String employerSecondaryPhoneNo = globalData.get("Member_Employer_Phone_No2");
		HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
		healthInsuranceInfoPage.selectESIDetailsForMember(memIndex, EmpName, employerPrimarnyPhoneNo, employerSecondaryPhoneNo);
		healthInsuranceInfoPage.clickOnSaveAndContinueBtn();
	}

	/**@author Ritika
	
	Acceptable Insurance Type :- COBRA, RETIREE
	
	 From Health Insurance Info Page, For Member "1" Select Insurance as "COBRA" with Employer Name as "OPTUM"

	 */

	@When("^From Health Insurance Info Page, For Member \"(.*?)\" Select Insurance as \"(.*?)\" with Employer Name as \"(.*?)\"$")
	public void selectHealthInsuranceInfoAsCOBRARetireeForMember(String memNo,String insuranceType ,String EmpName) throws Exception{
		int memIndex=Integer.parseInt(memNo)-1;
		String employerPrimarnyPhoneNo = globalData.get("Member_Employer_Phone_No1");
		String employerSecondaryPhoneNo = globalData.get("Member_Employer_Phone_No2");
		String streetAddress = globalData.get("Member1_M_StreetAddress");
		String city = globalData.get("Member1_M_City");
		String zipCode = globalData.get("Member1_M_ZIP_Code");
		String county = globalData.get("Member1_M_County");

		HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
		healthInsuranceInfoPage.selectIfOfferedThroughJobForMember(memIndex,false);

		if(insuranceType.equals("COBRA"))
		{
			healthInsuranceInfoPage.selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySource.COBRA.uiVal);
		}
		else if(insuranceType.equals("RETIREE"))
		{
			healthInsuranceInfoPage.selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySource.RETIREE_HEALTH_PLAN.uiVal);

		}
		healthInsuranceInfoPage.enterCOBRA_RHI_EmployerNameForMember(memIndex, EmpName);
		healthInsuranceInfoPage.enterCOBRA_RHI_PrimaryAddressStreetForMember(memIndex, streetAddress);
		healthInsuranceInfoPage.enterCOBRA_RHI_PrimaryCityForMember(memIndex, city);
		healthInsuranceInfoPage.enterCOBRA_RHI_PrimaryZipForMember(memIndex, zipCode);
		healthInsuranceInfoPage.selectCOBRA_RHI_PrimaryCountyForMember(memIndex, county);
		healthInsuranceInfoPage.enterCOBRARetireePrimaryPhoneNo(memIndex, employerPrimarnyPhoneNo);
		healthInsuranceInfoPage.enterCOBRARetireeSecondaryPhoneNo(memIndex, employerSecondaryPhoneNo);
		healthInsuranceInfoPage.clickOnSaveAndContinueBtn();

	}

	/**@author Ritika

	Extra Details Required For ESI, COBRA and RETIREE
	
	 From Employer Health Coverage Info Page, Enter All Details
	|MemNo | EnrolledinHP | MemCoveredUnderPolicy | InsExpChanges | MeetMinStd | PlanPremium | PlanPremiumFrequency |
	|	 1 | TRUE         |               2,3     | FALSE         | TRUE	   | 2500        | Yearly			    |


	 */
	@When("^From Employer Health Coverage Info Page, Enter All Details$")
	public void selectEmployerHealthCoverageInfoAs(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String memNo = scenarioData.get(1).get(0);
		String enrolledInHP=scenarioData.get(1).get(1);
		String otherMembersEnrInInsuranceByIndex=scenarioData.get(1).get(2).trim();
		String insExpChange=scenarioData.get(1).get(3);
		String insCoverageAffordable=scenarioData.get(1).get(4);
		String planPremiumCost=scenarioData.get(1).get(5);
		String planPremiumFrequency=scenarioData.get(1).get(6).trim();

		String planName = globalData.get("Member_Employer_HealthPlanName");
		String policyNumber = globalData.get("Member_Employer_HealthPlanNo");
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean enrolledInHPInCoverageYear = enrolledInHP.equalsIgnoreCase("TRUE")?true:false;
		Boolean insuranceExpChange = insExpChange.equalsIgnoreCase("TRUE")?true:false;
		Boolean insuranceCoverageAffordable = insCoverageAffordable.equalsIgnoreCase("TRUE")?true:false;

		EmployerHealthCoverageInfoPage employerHealthCoveragePage = new EmployerHealthCoverageInfoPage(driver, testCaseId);
		employerHealthCoveragePage.selectIfEnrolledInCoverageYearForMember(memIndex, enrolledInHPInCoverageYear);

		if(enrolledInHPInCoverageYear){
			employerHealthCoveragePage.clickOnCoverageStartDateNotKnownChkBxForMember(memIndex);
			employerHealthCoveragePage.enterPlanName(memIndex,planName);
			employerHealthCoveragePage.enterPolicyNo(memIndex, policyNumber);

			String currentEligibilityId = TestData.getTempTestData("CurrentEligibilityId",featureFileName);
			ElgMemberTable elgMem = new ElgMemberTable(conn, currentEligibilityId);
			String otherMembersEnrolled[]  =otherMembersEnrInInsuranceByIndex.split(",");

			if(otherMembersEnrInInsuranceByIndex.equals("NONE"))
			{
				System.out.println("None value is selected");
				//employerHealthCoveragePage.clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove();
			}
			else 
			{	
				employerHealthCoveragePage.clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove();
				for (int i=0;i<otherMembersEnrolled.length;i++)
				{
					int ind = Integer.parseInt(otherMembersEnrolled[i])-1;
					String fullName=elgMem.getFullName(currentEligibilityId, ind);
					employerHealthCoveragePage.clickOnMemberCoveredInPolicyOfMember(fullName);
				}
			}

		}

		employerHealthCoveragePage.selectIfExpectChangeInHealthCoverageForMember(memIndex,insuranceExpChange);
		if(insuranceExpChange){
			employerHealthCoveragePage.clickOnEmployerNoLongerOfferHeathCoverage();
			employerHealthCoveragePage.clickOnCoverageEndDateNotKnownChkBxForMember(memIndex);

		}else{
			employerHealthCoveragePage.selectIfHlthPlanMeetMinimumValueStandardForMember(memIndex, insuranceCoverageAffordable);
			if(insuranceCoverageAffordable){
				employerHealthCoveragePage.enterPlanPremiumCost(planPremiumCost);
				employerHealthCoveragePage.selectPlanPremiumFrequency(planPremiumFrequency);
			}		
			employerHealthCoveragePage.clickOnSaveAndContinueBtn();
		}
	}




	/**@author Ritika
	 * 		Accepted Val :- 
	 * 		MemNo :- 1,2,3

	  From Health Insurance Info Page, Select Other Insurance Type As VETERAN For Member "1"
		
	 */
	@When("^From Health Insurance Info Page, Select Other Insurance Type As VETERAN For Member \"(.*?)\"$")
	public void selectOtherHealthCoverageRdBtnForMember(String memNo ) throws Exception{

		HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		//healthInsuranceInfoPage.selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySource.VETERAN_HEALTH_PROGRAM.code);
		healthInsuranceInfoPage.clickOnSaveAndContinueBtn();
	}
	
	/**@author Ritu
	 * 		Accepted Val :- 
	 * 		MemNo :- 1,2,3

	 From Health Insurance Info Page, Select Other Insurance Type As NONE OF THE ABOVE For Member "1"
		
	 */
	@When("^From Health Insurance Info Page, Select Other Insurance Type As NONE OF THE ABOVE For Member \"(.*?)\"$")
	public void selectOtherHealthCoverageRdBtnAsNoneForMember(String memNo ) throws Exception{

		HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
		int memIndex = Integer.parseInt(memNo)-1;
		//healthInsuranceInfoPage.selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySource.NONE_OF_THE_ABOVE.code);
		healthInsuranceInfoPage.clickOnSaveAndContinueBtn();
	}
	
	/**@author Vinay
	 * 		Accepted Val :- 
	 * 		MemNo :- 1,2,3

	 From Health Insurance Info Page, Validate Page Title is Not Having Name of Member "1"
		
	 */
	@When("^From Health Insurance Info Page, Validate Page Title is Not Having Name of Member \"(.*?)\"$")
	public void validatePageTitleDontContainsName(String memNo ) throws Exception{

		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
	     
	     int memIndex = Integer.parseInt(memNo)-1;
	     
	     ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		 String fullName = elgMemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
		 HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
		 healthInsuranceInfoPage.validatePageTitleDontContainsName(fullName);
	}
	
	/**@author vkuma212
	 * During RAC, From Health Insurance Info Page, Page Load And Continue For Members Already Marked with No Insurance
		| MemNo  | TaxFilerQueAppear | TaxFilerQueAns 	| NCP_RFI_Que_Appear	| NCP_RFI_Reqd		| MassHealthSpecQueAppear	| MassHealthSpecQueAns	|
		|  1	 |  TRUE			 |  FALSE  		 	| 	TRUE				|  FALSE			|		TRUE				|		TRUE			|
		|  2	 |  FALSE			 |  	  		 	| 	TRUE				|  TRUE				|		TRUE				|		TRUE			|
		|  3	 |  TRUE			 |  TRUE  		 	| 	FALSE				|  FALSE			|		TRUE				|		TRUE			|
		
	 */
	@When("^During RAC, From Health Insurance Info Page, Page Load And Continue For Members Already Marked with No Insurance$")
	public void duringRAC_CompletAdditionalQuestionDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
				
		HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
		OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);
		TaxFilerAndOtherAdditionalQuePage taxFilerAndOtherAdditionalQuePage = new TaxFilerAndOtherAdditionalQuePage(driver, testCaseId);
		NCPQuestionPage ncpQuestionPage = new NCPQuestionPage(driver, testCaseId);
		MassHealthSpecQuestionPage massHealthSpecQuestionPage = new MassHealthSpecQuestionPage(driver, testCaseId);
		
		
		for(int rowCounter=1; rowCounter<rowCount; rowCounter++){
			int memIndex = Integer.parseInt(scenarioData.get(rowCounter).get(0))-1;
			
			healthInsuranceInfoPage.selectNoHealthInsuranceForMember(memIndex);
			healthInsuranceInfoPage.selectNoHRAInfoForMember(memIndex);

			Boolean taxFilerQuestionReqd=scenarioData.get(rowCounter).get(1).equalsIgnoreCase("TRUE")?true:false;
			Boolean taxFilerQuestionAns=scenarioData.get(rowCounter).get(2).equalsIgnoreCase("TRUE")?true:false;
			Boolean ncpQuestionReqd=scenarioData.get(rowCounter).get(3).equalsIgnoreCase("TRUE")?true:false;
			Boolean ncpRFIRequired=scenarioData.get(rowCounter).get(4).equalsIgnoreCase("TRUE")?true:false;
			Boolean massHealthSpecQuestionReqd=scenarioData.get(rowCounter).get(5).equalsIgnoreCase("TRUE")?true:false;
			Boolean massHealthSpecQuestionAns=scenarioData.get(rowCounter).get(6).equalsIgnoreCase("TRUE")?true:false;
			
			if(taxFilerQuestionReqd){
				taxFilerAndOtherAdditionalQuePage.evpdCompleteTaxFilerQuestion(memIndex, taxFilerQuestionAns);
			}
			
			if(ncpQuestionReqd){
				if(ncpRFIRequired){
					ncpQuestionPage.completeNCPQuestion(memIndex, true, true, true, true);
				}else{
					ncpQuestionPage.completeNCPQuestion(memIndex, false, true, false, false);
				}
			}
			
			if(massHealthSpecQuestionReqd){
				massHealthSpecQuestionPage.completeMassHealthSpecQuestion(memIndex, massHealthSpecQuestionAns);
			}
		}
		
	}
	
	/**@author Ritika

    From Health Insurance Info Page, Complete NCP Questions With Default Details With NCPRFI As "FALSE" For Member As "2"

    */
    @When("^From Health Insurance Info Page, Complete NCP Questions With Default Details With NCPRFI As \"(.*?)\" For Member As \"(.*?)\"$")
    public void completeNCPAndClickOnSaveAndContinue(String ncpRFIReq,String memNo) throws Exception{
    	NCPQuestionPage ncpQuestionPage = new NCPQuestionPage(driver, testCaseId);
    	Boolean ncpRFIRequired=ncpRFIReq.equalsIgnoreCase("TRUE")?true:false;
    	int memIndex = Integer.parseInt(memNo)-1;
    	if(ncpRFIRequired){
			ncpQuestionPage.completeNCPQuestion(memIndex, true, true, true, true);
		}else{
			ncpQuestionPage.completeNCPQuestion(memIndex, false, true, false, false);
		}
    }
    
	
	/**@author Ritu

    From Health Insurance Info Page, Page Load And Click On SaveAndContinue

    */
    @When("^From Health Insurance Info Page, Page Load And Click On SaveAndContinue$")
    public void pageLoadAndClickOnSaveAndContinue() throws Exception{
          HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
          healthInsuranceInfoPage.pageLoadThenClickOnSaveAndContinueBtn();
    }
    


}
