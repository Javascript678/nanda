package stepdefs.additionalQuestion;
import cucumber.api.java.en.When;
import pages.additionalQuestion.MassHealthSpecQuestionPage;
import pages.additionalQuestion.NCPQuestionPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class MassHealthSpecicQuestioPageSteps extends SuperStepDef{
	
	public MassHealthSpecicQuestioPageSteps(Hook hook){
		super(hook);
	}
	
	/**@author vkuma212
	 * 		Name of Actual Page ON UI is Mass Health Specific Question
	 * 	
	 * 
	 * From MassHealthSpecific Question Page, Answer For Member "1" Value As "TRUE"
	 * 
	 */
	@When("^From MassHealthSpecific Question Page, Answer For Member \"(.*?)\" Value As \"(.*?)\"$")
	public void completeNCPQuestion(String memNo, String  massHealthSpecQuestionAns) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		Boolean bMassHealthSpecQuestionAns = massHealthSpecQuestionAns.equalsIgnoreCase("TRUE")?true:false;
		MassHealthSpecQuestionPage massHealthSpecQuestionPage = new MassHealthSpecQuestionPage(driver, testCaseId);
		massHealthSpecQuestionPage.completeMassHealthSpecQuestion(memIndex, bMassHealthSpecQuestionAns);
	}
	
	// @ppinho
	@When("^From MassHealth Specific Questions Page, Page Load Save and Continue$")
	public void validatePageLoadSaveAndContinue() throws Exception {
		MassHealthSpecQuestionPage massHealthSpecQuestion = new MassHealthSpecQuestionPage(driver, testCaseId);
		massHealthSpecQuestion.pageLoadAndClickOnSaveAndContinueBtn();		
	}
	
	/**@author Ritu

    From MassHealth Specific Questions Page, Page Load And Click On SaveAndContinue

    */
    @When("^From MassHealth Specific Questions Page, Page Load And Click On SaveAndContinue$")
    public void waitForpageLoadAndClickOnSaveAndContinue() throws Exception{
       NCPQuestionPage ncpQuestionPage = new NCPQuestionPage(driver, testCaseId);
         
       ncpQuestionPage.clickOnSaveAndContinueBtn();
    }



}
