package stepdefs.login;

import java.util.List;

import appdata.common.OptumIdData;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import enums.PortalName;
import pages.login.ResetPasswordSecurityQuetionPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class ResetPasswordSecurityAnswerPageSteps extends SuperStepDef {

	public ResetPasswordSecurityAnswerPageSteps(Hook hook) {
		super(hook);
	}

	@Given("^On Reset Password Security Question Page, Enter Security Answer$")
	public void clickOnForgotCredentialLink(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String portal =  scenarioData.get(1).get(0);
		
		List<String> listNames = PortalName.getCodes();
		if( ! listNames.contains(portal)  ){
			throw new Exception("Portal Name is not correct [" + portal + "] Accepted Value " +listNames );
		}
		
		OptumIdData optumIdData = TestData.getOptumIdCredentialForIndividual(envData);
				
		if(portal.equalsIgnoreCase(PortalName.INDIVIDUAL.code)){
			optumIdData = TestData.getOptumIdCredentialForIndividual(envData);
		}else if(portal.equalsIgnoreCase(PortalName.AGENT.code)){
			optumIdData  = TestData.getOptumIdCredentialForAgent(envData);
		}else if(portal.equalsIgnoreCase(PortalName.ASSISTER.code)){
			optumIdData = TestData.getOptumIdCredentialForAssisterCAC(envData);
		}
		
		ResetPasswordSecurityQuetionPage resetPasswordSecurityQuePage = new ResetPasswordSecurityQuetionPage(driver, testCaseId);
		resetPasswordSecurityQuePage.pageLoadAndEnterSecurityAnswer(optumIdData);
	}
	
	
}
