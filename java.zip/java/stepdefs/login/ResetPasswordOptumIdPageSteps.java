package stepdefs.login;

import cucumber.api.java.en.Given;
import pages.login.ResetPasswordOptumIdPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ResetPasswordOptumIdPageSteps extends SuperStepDef {

	public ResetPasswordOptumIdPageSteps(Hook hook) {
		super(hook);
	}

	@Given("^On Reset Password Optum Id Page, Validate Password Is Masked$")
	public void validatePasswordIsMasked() throws Exception{
		ResetPasswordOptumIdPage resetPasswordOptumIdPage = new ResetPasswordOptumIdPage(driver, testCaseId);
		resetPasswordOptumIdPage.pageLoadAndValidatePasswordIsMasked();
	}
	
}
