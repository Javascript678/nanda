package stepdefs.login;

import java.util.List;

import appdata.common.OptumIdData;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import enums.PortalName;
import pages.login.ForgotPasswordPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class ForgotPasswordPageSteps extends SuperStepDef {

	public ForgotPasswordPageSteps(Hook hook) {
		super(hook);
	}

	@Given("^On Forgot Password Page, Enter Email Address Or Optum ID$")
	public void clickOnForgotCredentialLink(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String portal =  scenarioData.get(1).get(0);
		
		List<String> listNames = PortalName.getCodes();
		if( ! listNames.contains(portal)  ){
			throw new Exception("Portal Name is not correct [" + portal + "] Accepted Value " +listNames );
		}
		
		OptumIdData optumIdData = null;
				
		if(portal.equalsIgnoreCase(PortalName.INDIVIDUAL.code)){
			optumIdData = TestData.getOptumIdCredentialForIndividual(envData);
		}else if(portal.equalsIgnoreCase(PortalName.AGENT.code)){
			optumIdData  = TestData.getOptumIdCredentialForAgent(envData);
		}else if(portal.equalsIgnoreCase(PortalName.ASSISTER.code)){
			optumIdData = TestData.getOptumIdCredentialForAssisterCAC(envData);
		}
		
		ForgotPasswordPage forgotPasswordPage = new ForgotPasswordPage(driver, testCaseId);
		forgotPasswordPage.pageLoadAndEnterEmailOrOptumId(optumIdData.optumId);
	}
	
	
}
