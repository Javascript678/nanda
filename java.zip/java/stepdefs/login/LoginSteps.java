package stepdefs.login;

import java.util.List;

import appdata.common.OptumIdData;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import enums.BrowserName;
import enums.PortalName;
import enums.TPLUserType;
import pages.common.CommonPage;
import pages.login.HomePage;
import pages.login.ShareMyOptumIdPage;
import pages.login.SignInWithYourOptumIdPage;
import pages.login.UnrecognizedDevicePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class LoginSteps extends SuperStepDef {

	public LoginSteps(Hook hook) {
		super(hook);
	}
	
	@Given("^Login to MAHIX Individual Portal$")
	public void loginToIndPortal() throws Exception {
		String portal = PortalName.INDIVIDUAL.code;
		String url = TestData.getURL(portal, envData);		
		OptumIdData optumIdData = null;
		
		if(!browserToUse.equalsIgnoreCase(BrowserName.SAUCE_LAB_FF.val) && portal.equalsIgnoreCase(PortalName.INDIVIDUAL.code)){
			optumIdData = TestData.getOptumIdDataToCreateCredentialOnIndividual(globalData);
		}else{
			optumIdData = TestData.getOptumIdCredentialForIndividual(envData);
		}
		goToPortal(browserToUse, url, portal, optumIdData);
	}
	
	@Given("^Login to MAHIX Agent Portal Using BO Credential$")
	public void loginToAgentPortal_BO() throws Exception {
		String portal = PortalName.AGENT.code;
		String url = TestData.getURL(portal, envData);		
		OptumIdData optumIdData = TestData.getOptumIdCredentialForAgent(envData);
		goToPortal(browserToUse, url, portal, optumIdData);
	}
	
	// Added By Paul
	@Given("^Login to MAHIX Agent Portal Using View Only Credential$")
	public void loginToAgentPortal_VO() throws Exception {
		String portal = PortalName.AGENT.code;
		String url = TestData.getURL(portal, envData);		
		OptumIdData optumIdData = TestData.getOptumIdCredentialForAgentViewOnly(envData);
		goToPortal(browserToUse, url, portal, optumIdData);
	}
	
	@Given("^Login to MAHIX Portal Using TPL User$")
	public void loginToAgentPortal_TPL_User() throws Exception {
		String portal = PortalName.AGENT.code;
		String url = TestData.getURL(portal, envData);		
		OptumIdData optumIdData = TestData.getOptumIdCredentialForTPL(envData,TPLUserType.TPL_USER.code);
		goToPortal(browserToUse, url, portal, optumIdData);
	}
	
	@Given("^Login to MAHIX Portal Using TPLSuper User$")
	public void loginToAgentPortal_TPLSuper_User() throws Exception {
		String portal = PortalName.AGENT.code;
		String url = TestData.getURL(portal, envData);		
		OptumIdData optumIdData = TestData.getOptumIdCredentialForTPL(envData,TPLUserType.TPL_SUPER_USER.code);
		goToPortal(browserToUse, url, portal, optumIdData);
	}
	
	@Given("^Login to MAHIX Agent Portal Using CSR Credential$")
	public void loginToAgentPortal_CSR() throws Exception {
		String portal = PortalName.AGENT.code;
		String url = TestData.getURL(portal, envData);		
		OptumIdData optumIdData = TestData.getOptumIdCredentialForAgentUsingCSRUser(envData);
		goToPortal(browserToUse, url, portal, optumIdData);
	}
	
	@Given("^Login to MAHIX Assister Portal Using CAC User$")
	public void loginToAssisterPortal_CAC_User() throws Exception {
		String portal = PortalName.ASSISTER.code;
		String url = TestData.getURL(portal, envData);		
		OptumIdData optumIdData = TestData.getOptumIdCredentialForAssisterCAC(envData);
		goToPortal(browserToUse, url, portal, optumIdData);
	}
	
	@Given("^Login to MAHIX Assister Portal Using NAV User$")
	public void loginToAssisterPortal_NAV_User() throws Exception {
		String portal = PortalName.ASSISTER.code;
		String url = TestData.getURL(portal, envData);		
		OptumIdData optumIdData = TestData.getOptumIdCredentialForAssisterNAV(envData);
		goToPortal(browserToUse, url, portal, optumIdData);
	}
	
	private void goToPortal(String browserToUse, String url, String portal, OptumIdData optumIdData ) throws Exception{
		CommonPage webPage = new CommonPage(driver, testCaseId);
		
		webPage.goTo(url);

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnSignInBtn();
		
		if(! browserToUse.equalsIgnoreCase(BrowserName.SAUCE_LAB_FF.val) && portal.equalsIgnoreCase(PortalName.INDIVIDUAL.code)){
			SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver,
					testCaseId);
			storeTempTestData("IndPortal_EmailId", optumIdData.emailAddress); //newly Created
			signInWithYourOptumIdPage.createOptumIdUsingIndividualPortal(optumIdData);
		}else{
			
			SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver, testCaseId);
			signInWithYourOptumIdPage.completeOptumIdSignIn(portal, optumIdData);
			
			UnrecognizedDevicePage unrecognizedDevicePage = new UnrecognizedDevicePage(driver, testCaseId);
			unrecognizedDevicePage.handleSecurityQuestionIfPresent(optumIdData);
			
			ShareMyOptumIdPage shareMyOptumIdPage = new ShareMyOptumIdPage(driver, testCaseId);
			shareMyOptumIdPage.optionalClickOnShareMyOptumIdAgreeBtn();
		}
				
		homePages.refreshPageToRemoveReaderViewIssueInSauceLab(browserToUse);
	}
	
	@Given("^Go To Portal$")
	public void goToPortal(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String portal =  scenarioData.get(1).get(0);
		
		List<String> listNames = PortalName.getCodes();
		if( ! listNames.contains(portal)  ){
			throw new Exception("Portal Name is not correct [" + portal + "] Accepted Value " +listNames );
		}
		
		String url = TestData.getURL(portal, envData);
		CommonPage webPage = new CommonPage(driver, testCaseId);
		webPage.goTo(url);
	}
}