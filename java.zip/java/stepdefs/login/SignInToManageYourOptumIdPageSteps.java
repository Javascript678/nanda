package stepdefs.login;

import java.util.List;

import appdata.common.OptumIdData;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import enums.PortalName;
import pages.login.SignInToManageYrOptumIdPage;
import pages.login.UnrecognizedDevicePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class SignInToManageYourOptumIdPageSteps extends SuperStepDef {

	public SignInToManageYourOptumIdPageSteps(Hook hook) {
		super(hook);
	}

	@Given("^On Sign In To Manage Your Optum Id Page, Enter Credential$")
	public void clickOnForgotCredentialLink(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String portal =  scenarioData.get(1).get(0);
		
		List<String> listNames = PortalName.getCodes();
		if( ! listNames.contains(portal)  ){
			throw new Exception("Portal Name is not correct [" + portal + "] Accepted Value " +listNames );
		}
		
		OptumIdData optumIdData = TestData.getOptumIdCredentialForIndividual(envData);
				
		if(portal.equalsIgnoreCase(PortalName.INDIVIDUAL.code)){
			optumIdData = TestData.getOptumIdCredentialForIndividual(envData);
		}else if(portal.equalsIgnoreCase(PortalName.AGENT.code)){
			optumIdData  = TestData.getOptumIdCredentialForAgent(envData);
		}else if(portal.equalsIgnoreCase(PortalName.ASSISTER.code)){
			optumIdData = TestData.getOptumIdCredentialForAssisterCAC(envData);
		}
		
		SignInToManageYrOptumIdPage signInToManageYrOptumIdPage = new SignInToManageYrOptumIdPage(driver, testCaseId);
		signInToManageYrOptumIdPage.enterUserNameAndPassword(optumIdData.optumId, optumIdData.password);
		
		UnrecognizedDevicePage unrecognizedDevicePage = new UnrecognizedDevicePage(driver, testCaseId);
		unrecognizedDevicePage.handleSecurityQuestionIfPresent(optumIdData);
		
	}
	
	
}
