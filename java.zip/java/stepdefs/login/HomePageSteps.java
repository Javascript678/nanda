package stepdefs.login;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import enums.PortalName;
import pages.login.HomePage;
import pages.login.PreviewPlansPage;
import pages.shopping.FindAHealthOrDentalPlanPage;
import stepdefs.assister.DesignationFormSteps;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class HomePageSteps extends SuperStepDef {

	public HomePageSteps(Hook hook) {
		super(hook);
	}

	@Given("^From Home Page, Take Screenshot$")
	public void takeScreenshot() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.takeScreenShot();
	}
	
	@Given("^From Home Page, Click On Add A Note No Btn$")
	public void clickOnAddANoteNoBtn() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnAddANoteNoBtn();
	}

	@Given("^From Home Page, Click On Add A Note Yes Btn$")
	public void clickOnAddANoteYesBtn() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnAddANoteYesBtn();
	}

	@Given("^From Home Page, Dismiss Note If Present$")
	public void dismissNoteIfPresent() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.dismissNoteIfPresent();
	}
	
	@Given("^From Home Page, Click on Notes Icon$")
	public void clickNotesIcon() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnNotesIcon();
	}
	
	@Given("^From Home Page, Validate Text displayed under Notes section is \"(.*?)\"$")
	public void validateNoNotesText(String noNotesTxt) throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.validateNoNotesText(noNotesTxt);
	}
	
	@Given("^From Home Page, Under Notes Section Click on Write Note Button")
	public void clickOnWriteNote() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnWriteNoteBtn();
	}
	
	@Given("^From Home Page, Under Notes Section Enter Notes Text As \"(.*?)\"$")
	public void enterNotes(String notesTxt) throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.enterNotesText(notesTxt);
	}
	
	@Given("^From Home Page, Under Notes Section Click on Save Note Button$")
	public void clickSaveNoteBtn() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnSaveNoteBtn();
	}

	@Given("^From Home Page, Go To Manage Customer Page$")
	public void goToManageCustomerPage() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.agentPageLoadAndClickOnManageCustomerLink();
	}

	@Given("^From Home Page, Go To Manage Member Link$")
	public void clickOnManageMembersLink() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnManageMembersLink();
	}

	@Given("^From Home Page, Go To Designation Form Page Using Add New Member Link$")
	public void goToDesignationFormPage() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnAddNewMemberLink();
	}

	@Given("^From Home Page, Go To My Profile Page$")
	public void goToMyProfilePage() throws Exception {
		HomePage homePage = new HomePage(driver, testCaseId);
		homePage.clickOnMyProfileTab();
	}

	@Given("^From Home Page, Go To My Eligibility Page$")
	public void goToMyEligibilityPage() throws Exception {
		HomePage homePage = new HomePage(driver, testCaseId);
		homePage.clickOnMyEligibilityTab();
	}

	@Given("^From Home Page, Go To My MyAppeals Page$")
	public void goToMyMyAppealsPage() throws Exception {
		HomePage homePage = new HomePage(driver, testCaseId);
		homePage.clickOnMyAppealsTab();
	}

	@Given("^From Home Page, Go To My Enrollments Page$")
	public void goToMyEnrollmentsPage() throws Exception {
		HomePage homePage = new HomePage(driver, testCaseId);
		homePage.clickOnMyEnrollmentsTab();
	}

	@Given("^From Home Page, Go To My Assisters Page$")
	public void goToMyAssistersPage() throws Exception {
		HomePage homePage = new HomePage(driver, testCaseId);
		homePage.clickOnMyAssistersTab();
	}

	@Given("^From Home Page, Click On Premium Assistance Tab$")
	public void clickOnPremiumAssistanceTab() throws Exception {
		HomePage homePage = new HomePage(driver, testCaseId);
		homePage.clickOnPremiumAssistanceTab();
	}

	@Given("^From Home Page, Click On View App Summary Tab$")
	public void clickOnViewAppSummaryTabTab() throws Exception {
		HomePage homePage = new HomePage(driver, testCaseId);
		homePage.clickOnViewAppSummaryTabTab();
	}

	@Given("^From Home Page, Click On View Medicaid Household Tab$")
	public void clickOnViewMedicaidHouseholdTab() throws Exception {
		HomePage homePage = new HomePage(driver, testCaseId);
		homePage.clickOnViewMedicaidHouseholdTab();
	}

	@Given("^From Home Page, Click On View Medicaid Notices Tab$")
	public void clickOnViewMedicaidNoticesTab() throws Exception {
		HomePage homePage = new HomePage(driver, testCaseId);
		homePage.clickOnViewMedicaidNoticesTab();
	}

	@Given("^From Home Page, Go To Find A Customer Page$")
	public void goToFindACustomerPage() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnFindACustomerTab();
	}

	@Given("^From Home Page, Go To Find And View Medicaid Notices Page$")
	public void goToFindAndViewMedicaidNotices() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnFindAndViewMedicaidNoticesTab();
	}

	@Given("^From Home Page, Go To View VLP 2 3 Cases Page$")
	public void goToViewVLP2And3CasesTab() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnViewVLP2And3CasesTab();
	}

	@Given("^From Home Page, Click On Sign In Button$")
	public void clickOnSignInButton() throws Exception {
		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnSignInBtn();
	}

	@Given("^Logout From Portal$")
	public void logoOut() throws Exception {
		HomePage homePage = new HomePage(driver, testCaseId);
		homePage.clickOnLogOutBtn();
	}

	@Given("^From Home Page, Go To Create Profile Page$")
	public void fromHomePageGoToCreateProfilePage() throws Exception {
		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.agentPageLoadAndClickOnCreateCustomerProfileLink();
	}

	@Given("^EVPD, From Home Page, Go To Create Profile Page$")
	public void goToCreateProfilePage() throws Exception {
		HomePage homePages = new HomePage(driver, testCaseId);

		if (evpdData.portal.equals(PortalName.AGENT.code)) {
			homePages.agentPageLoadAndClickOnCreateCustomerProfileLink();
		}

		if (evpdData.portal.equals(PortalName.ASSISTER.code)) {
			homePages.clickOnAddNewMemberLink();
			DesignationFormSteps designationFormSteps = new DesignationFormSteps(hook);
			designationFormSteps.fill_Designation_Details();
		}
	}

	@Given("^Complete Anonymous Shopping$")
	public void completeAnonymousShopping() throws Exception {

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnPreviewPlanBtn();

		PreviewPlansPage previewPlansPage = new PreviewPlansPage(driver, testCaseId);
		previewPlansPage.enterPreviewPlanDetails("01002", "01/01/1989");

		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);
		findAHealthOrDentalPlanPage.validateComparePlanDetails();
	}

	@Given("^Click on Plan Finder Tool Button$")
	public void clickOnPlanFinderToolBtn() throws Exception {
		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);
		findAHealthOrDentalPlanPage.clickOnPlanFinderToolBtn();
	}
	
	@Given("^Compare three health plans$")
	public void compareHealthPlans() throws Exception {
		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);
		findAHealthOrDentalPlanPage.validateHealthPlanDetailsForThreePlansOnComparePlanPage();
	}
	
	@Given("^Click on RemoveDrug Button$")
	public void clickOnRemoveDrugBtn() throws Exception {
		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);
		findAHealthOrDentalPlanPage.clickOnRemoveDrugBtn();
	}

	/**
	 * @author rgupta64
	 * @throws Exception
	 *             Enter Preview Plan Details | ZipCode | DOB | PlanType | |
	 *             02114 | 01/01/2002| DENTAL |
	 */
	@Given("^Enter Preview Plan Details$")
	public void completePreviewPlanDetails(DataTable table) throws Exception {
		List<List<String>> scenarioData = table.raw();
		String zipCode = scenarioData.get(1).get(0);
		String dob = scenarioData.get(1).get(1);
		String planType = scenarioData.get(1).get(2);

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnPreviewPlanBtn();
		PreviewPlansPage previewPlansPage = new PreviewPlansPage(driver, testCaseId);
		previewPlansPage.enterPreviewPlan(zipCode, dob, planType);
	}

	@Given("^Enter Details For Anonymous Browsing For Dental Plan$")
	public void completeAnonymousDental() throws Exception {

		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);
		findAHealthOrDentalPlanPage.selectShoppingPlan("Delta Dental");
		findAHealthOrDentalPlanPage.clickOnApplyBtn();
		findAHealthOrDentalPlanPage
				.validatePremiumAmount("Non-Standard: Delta Dental Individual and Family EPO Pediatric Basic", "19.13");
		findAHealthOrDentalPlanPage
				.validatePremiumAmount("Standard Family Low: Delta Dental Individual and Family EPO Value", "22.90");
		findAHealthOrDentalPlanPage.validatePremiumAmount(
				"Standard Family High: Delta Dental Individual and Family EPO Enhanced", "22.90");

	}

	@Given("^Enter Details For Anonymous Browsing For Health Plan$")
	public void completeAnonymousHealth() throws Exception {

		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);

		findAHealthOrDentalPlanPage.verifyTypesofCov();
		findAHealthOrDentalPlanPage.selectShoppingPlan("BMC HealthNet Plan");
		findAHealthOrDentalPlanPage.clickOnApplyBtn();
		findAHealthOrDentalPlanPage.validateAnonymousHealth("Individual", "2,000");
		findAHealthOrDentalPlanPage.validateAnonymousHealth("Family", "4,000");
	}
	
	@Given("^From Home Page, Verify Renewal Was Initiated$")
	public void verifyRenewalWasInitiated() throws Exception {
		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.waitForRenewalInitiated();
		homePages.takeScreenShot();
	}

}
