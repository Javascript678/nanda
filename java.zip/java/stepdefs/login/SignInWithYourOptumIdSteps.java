package stepdefs.login;

import cucumber.api.java.en.Given;
import pages.login.SignInWithYourOptumIdPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class SignInWithYourOptumIdSteps extends SuperStepDef {

	public SignInWithYourOptumIdSteps(Hook hook) {
		super(hook);
	}

	@Given("^On Sign In With Your Optum ID Page, Click On Forgot Credendial Link$")
	public void clickOnForgotCredentialLink() throws Exception{
		SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver, testCaseId);
		signInWithYourOptumIdPage.pageLoadAndClickOnForgotCredendialLink();
	}
	
	@Given("^On Sign In With Your Optum ID Page, Click On Forgot Password Link$")
	public void clickOnForgotPasswordLink() throws Exception{
		SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver, testCaseId);
		signInWithYourOptumIdPage.pageLoadAndClickOnForgotPasswordLink();
	}
	
	@Given("^On Sign In With Your Optum ID Page, Click On Create Optum ID Link$")
	public void clickOnCreateOptumIdLink() throws Exception{
		SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver, testCaseId);
		signInWithYourOptumIdPage.pageLoadAndClickOnCreateOptumIdLink();
	}
	
	@Given("^On Sign In With Your Optum ID Page, Click On Manage Your Optum id Link$")
	public void clickOnManageYourOptumIdLink() throws Exception{
		SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver, testCaseId);
		signInWithYourOptumIdPage.pageLoadAndClickOnManageYourOptumIdLink();
	}
	
	@Given("^On Sign In With Your Optum ID Page, Click On What Is Optum ID Link$")
	public void clickOnWhatIsOptumIdLink() throws Exception{
		SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver, testCaseId);
		signInWithYourOptumIdPage.pageLoadAndClickOnWhatIsOptumIdLink();
	}
	
}
