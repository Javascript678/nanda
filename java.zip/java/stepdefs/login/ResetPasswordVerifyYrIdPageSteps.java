package stepdefs.login;

import cucumber.api.java.en.Given;
import pages.login.ResetPasswordVerifyYrIdPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ResetPasswordVerifyYrIdPageSteps extends SuperStepDef {

	public ResetPasswordVerifyYrIdPageSteps(Hook hook) {
		super(hook);
	}

	@Given("^On Reset Password Verify Your Identity Page, Click on Send Email Radio Button$")
	public void clickOnSendEmailRdBtn() throws Exception{
		ResetPasswordVerifyYrIdPage resetPasswordVerifyYrIdPage = new ResetPasswordVerifyYrIdPage(driver, testCaseId);
		resetPasswordVerifyYrIdPage.pageLoadAndClickOnSendEmailRdBtn();
	}
	
	@Given("^On Reset Password Verify Your Identity Page, Click on Security Answer Reset Radio Button$")
	public void clickOnSecurityAnswerRdBtn() throws Exception{
		ResetPasswordVerifyYrIdPage resetPasswordVerifyYrIdPage = new ResetPasswordVerifyYrIdPage(driver, testCaseId);
		resetPasswordVerifyYrIdPage.pageLoadAndClickOnSecurityAnswerRdBtn();
	}
}
