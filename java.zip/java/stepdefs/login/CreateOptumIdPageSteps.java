package stepdefs.login;

import cucumber.api.java.en.Given;
import pages.login.CreateOptumIdPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class CreateOptumIdPageSteps extends SuperStepDef {

	public CreateOptumIdPageSteps(Hook hook) {
		super(hook);
	}

	@Given("^On Create Optum ID Page, Validate Password Field Is Masked$")
	public void clickOnForgotCredentialLink() throws Exception{
		CreateOptumIdPage createOptumIdPage = new CreateOptumIdPage(driver, testCaseId);
		createOptumIdPage.verifyPasswordFieldIsMasked();
	}
	
	//Amrita
	@Given("^On Create Optum ID Page, Click On Cancel Link$")
	public void clickOnCancelLink() throws Exception{
		CreateOptumIdPage createOptumIdPage = new CreateOptumIdPage(driver, testCaseId);
		createOptumIdPage.clickOnCancelBtn();
	}
	
	
}
