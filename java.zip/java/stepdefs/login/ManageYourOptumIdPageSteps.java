package stepdefs.login;

import cucumber.api.java.en.Given;
import pages.login.ManageYrOptumIdPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ManageYourOptumIdPageSteps extends SuperStepDef {

	public ManageYourOptumIdPageSteps(Hook hook) {
		super(hook);
	}

	@Given("^On Manage Your Optum Id Page, Validate Password Is Masked$")
	public void clickOnForgotCredentialLink() throws Exception{
		ManageYrOptumIdPage manageYrOptumIdPage = new ManageYrOptumIdPage(driver, testCaseId);
		manageYrOptumIdPage.enterPasswordOnSignInInfoTabAndVerifyFieldIsMasked();
		
	}
	
}
