package stepdefs.premiumAssistance;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.DualTable;
import db.ElgMemberTable;
import pages.pa.AddNewPolicyInfoPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

/**
 * 
 * @author Ritika


 *
 */
public class AddNewPolicyInfoPageSteps extends SuperStepDef {

	public AddNewPolicyInfoPageSteps(Hook hook) {
		super(hook);
	}

	/**Ritu
     * 
      From New Policy Info Page, Validate ErrorMsg
      
      * */
     @Given("^From New Policy Info Page, Validate ErrorMsg$")
     public void valiateErrorMsg() throws Exception{
           AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
           addNewPolicyPage.validateErrorMessage();
     }

     
	/**
	 *@author Ritika
  From New Policy Info Page, Enter Employee Sponsored Policy details
  	|MemNo		|  PolicyType	| TierOfCoverage	|     CoverageType	    | BasicBenefitLevel	| EnrolledMH	| MonthlyCost		| EmpContri		|NextPayDatePriorFromToday	|
  	|		1	| 	Medical		|          Family	| 	02 - Major Medical	|         TRUE		|    TRUE		| 		5000	 	| 		3500	| -20  	 					|

	 *
	 */

	@Given("^From New Policy Info Page, Enter Employee Sponsored Policy details$")
	public void AddNewPolicyESIInfoAndCalculatePAAmt(DataTable Table) throws Exception {
		List<List<String>> scenarioData = Table.raw();
		
		int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
		//String insPolSource= scenarioData.get(1).get(1).trim();
		String policyType = scenarioData.get(1).get(1).trim();
		String tierOfCov = scenarioData.get(1).get(2).trim();
		String covType = scenarioData.get(1).get(3).trim();
		Boolean basicBenefitLevel = scenarioData.get(1).get(4).equalsIgnoreCase("TRUE")?true:false;
		Boolean enrollMH = scenarioData.get(1).get(5).equalsIgnoreCase("TRUE")?true:false;
		String monthlyCost = scenarioData.get(1).get(6).trim();
		String empContri = scenarioData.get(1).get(7).trim();
		String nextPayDate = scenarioData.get(1).get(8).trim();
		
		AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
		
		String polNo = "12345678";
		String gpNo = "12345678";
		String currentEligibilityId = TestData.getTempTestData("CurrentEligibilityId",featureFileName);
		
		ElgMemberTable elgMem = new ElgMemberTable(conn, currentEligibilityId);
		
		String policyHolderName = elgMem.getFullName(currentEligibilityId, memIndex);
		
		String currentDate = new DualTable(conn,"").getSysDate();
		
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);
		String nextPaymentDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+nextPayDate);

		addNewPolicyPage.enterEmployeeSponsoredPolicyDetails(policyHolderName, polNo, gpNo, policyType, tierOfCov,covType, basicBenefitLevel, enrollMH,monthlyCost, empContri, nextPaymentDate);
	}


	/**
	 *@author Ritika
  From New Policy Info Page, Enter COBRA/Retiree/Union Policy details
  	|MemNo		|  PolicyType	| TierOfCoverage	|     CoverageType	    | BasicBenefitLevel	| EnrolledMH	| MonthlyCost		| NextPayDatePriorFromToday	|
  	|		1	| 	Medical		|          Family	| 	02 - Major Medical	|         TRUE		|    TRUE		| 		5000	 	| 		 -20  	 					|

	 *
	 */

	@Given("^From New Policy Info Page, Enter COBRA/Retiree/Union Policy details$")
	public void AddNewPolicyCOBRAInfoAndCalculatePAAmt(DataTable Table) throws Exception {
		List<List<String>> scenarioData = Table.raw();
		int memIndex = Integer.parseInt(scenarioData.get(1).get(0))-1;
		//String insPolSource= scenarioData.get(1).get(1).trim();
		String policyType=scenarioData.get(1).get(1).trim();
		String tierOfCov = scenarioData.get(1).get(2).trim();
		String covType = scenarioData.get(1).get(3).trim();
		Boolean basicBenefitLevel =scenarioData.get(1).get(4).equalsIgnoreCase("TRUE")?true:false;
		Boolean enrollMH =scenarioData.get(1).get(5).equalsIgnoreCase("TRUE")?true:false;
		String monthlyCost =  scenarioData.get(1).get(6).trim();
		//String empContri =  scenarioData.get(1).get(7).trim();
		String nextPayDate =  scenarioData.get(1).get(7).trim();
		AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
		String polNo="12345678";
		String gpNo="12345678";
		String polInComName="Other";
		String currentEligibilityId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		ElgMemberTable elgMem = new ElgMemberTable(conn, currentEligibilityId);
		String policyHolderName=elgMem.getFullName(currentEligibilityId, memIndex);
		String currentDate = new DualTable(conn,"").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);
		String nextPaymentDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+nextPayDate);

		addNewPolicyPage.enterCOBRAPolicyDetails(policyHolderName, polNo, gpNo,policyType, tierOfCov,covType, polInComName, polInComName,
				basicBenefitLevel, enrollMH,monthlyCost,  nextPaymentDate);
	}

	/**
	 *@author Ritika

    From New Policy Info Page, Enter Policy Health Insurance Status For Members
	  |MemNo	|  HealthInsStatus										| 
	  |		1	| 	U - Uninsured										|
	  |		2	| 	S - Self Declared									|
	  |		3	| 	Y - Verified by TPL Worker							|
	  |		4	| I - Investigated for the purpose of Premium Assistance|
	 *
	 */

	@Given("^From New Policy Info Page, Enter Policy Health Insurance Status For Members$")
	public void addHealthInsStatusPolicyInfo(DataTable Table) throws Exception
	{
		List<List<String>> scenarioData = Table.raw();
		int memCount=scenarioData.size();
		String currentDate = new DualTable(conn,"").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);
		String policyStartDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+180);

		AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);

		for (int mCounter = 1; mCounter < memCount; mCounter++) {
			int memIndex = Integer.parseInt(scenarioData.get(mCounter).get(0))-1;
			String healthInsuranceStatus= scenarioData.get(mCounter).get(1).trim();
			addNewPolicyPage.selectHeathInsuranceStatus(memIndex, healthInsuranceStatus);
			addNewPolicyPage.enterPolicyStartDate(memIndex, policyStartDate);
		}
	}
	
	/**
	 *@author Ritika

    From New Policy Info Page, Click On Calculate

	 */

	@Given("^From New Policy Info Page, Click On Calculate$")
	public void clickOnCalculate() throws Exception
	{
		AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
		
		addNewPolicyPage.clickOnCalculate();
	}
	
	/**
	 *@author Ritika

    From New Policy Info Page, Validate Calculated PA Amount As "122.0"

	 */

	@Given("^From New Policy Info Page, Validate Calculated PA Amount As \"(.*?)\"$")
	public void clickOnCalculate(String paAmount) throws Exception
	{
		AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
		addNewPolicyPage.waitForPageLoaded();
		addNewPolicyPage.validatePremiumAsstAmount(paAmount);
	}
	
	/**
	 *@author Ritika

    From New Policy Info Page, Handle Pop Up Message

	 */

	@Given("^From New Policy Info Page, Handle Pop Up Message$")
	public void handlePopUp() throws Exception
	{
		AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
		addNewPolicyPage.handlePopUp();
	}
	
	/**
	 *@author Ritika

   From Add New Policy Page, Enter details to override in existing policy
	  |OverrideAmount	   |  PaymentStatus			| OverrideEndDatePriorFromToday |
	  |		2477		   | 	CP - Current Pay	|			-20			  		|

	 *
	 */

	@Given("^From Add New Policy Page, Enter details to override in existing policy$")
	public void overidePolicyInfo(DataTable Table) throws Exception
	{
		List<List<String>> scenarioData = Table.raw();
		String paOverrideAmount = scenarioData.get(1).get(0);
		String paymentStatus = scenarioData.get(1).get(1).trim();
		String endDate =  scenarioData.get(1).get(2).trim();
		String currentDate = new DualTable(conn,"").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);
		String paOverrideAmountEndDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+endDate);
		AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
		addNewPolicyPage.enterPolicyOverrideDetailsAndCalculatePA(paOverrideAmount, paymentStatus, paOverrideAmountEndDate);
	}
	
	/*
     * Ritu
     	Acceptable Value :-
     	PP - Potential Pay
		CP - Current Pay
		NP - No Pay

     	From Add New Policy Page, Set Payment Status As "NP - No Pay"
     	
     * */
     @Given("^From Add New Policy Page, Set Payment Status As \"(.*?)\"$")
     public void overidePolicyInfo(String paymentStatus) throws Exception
     {
           
           AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
           addNewPolicyPage.selectPaymentStatus( paymentStatus);
     }


	//Amrita
	@Given("^From Add New Policy Page, Take Screenshot$")
	public void takeScreenShot() throws Exception
	{
		AddNewPolicyInfoPage addNewPolicyPage = new AddNewPolicyInfoPage(driver, testCaseId);
		addNewPolicyPage.takeScreenshot();
	}
	
}
