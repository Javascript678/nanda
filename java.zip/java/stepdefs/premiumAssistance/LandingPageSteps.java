package stepdefs.premiumAssistance;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import pages.eligibilityResult.MedicaidHHDeterminationPage;
import pages.manageCustomer.FindAndViewMedicaidNoticesPage;
import pages.myEligibility.EligibilityApplicationPage;
import pages.pa.AddAdminPage;
import pages.pa.AddEmployerPage;
import pages.pa.AddNewPolicyInfoPage;
import pages.pa.LandingPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class LandingPageSteps extends SuperStepDef{

	public LandingPageSteps(Hook hook){
		super(hook);
	}

	/**@author Ritika
	 * 
	From Landing Page, Validate PA Investigation Referal Criteria
			|MemNo 			| AidCat 	| TPLStatus 	| AdminClosureReason | MagiFPL 	|
			|	 1 		  	| EK       	|        I     	| N/A          		 | 126.65% 	| 
			|	 4 	  		| N/A    	|        N/A    | 49 - Deceased      | 0% 		| 
	 
	 */

	@Given("^From Landing Page, Validate PA Investigation Referal Criteria$")
	public void validatePremiumAssistanceInvestigationReferalCriteria(DataTable table) throws Exception {
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		String currentEligibilityId = TestData.getTempTestData("CurrentEligibilityId",featureFileName);
		ElgMemberTable elgMem = new ElgMemberTable(conn, currentEligibilityId);

		for(int rowCounter=1; rowCounter<rowCount; rowCounter++){
			int memIndex = Integer.parseInt(scenarioData.get(rowCounter).get(0))-1;
			String name=elgMem.getFullName(currentEligibilityId, memIndex);
			String aidCat=scenarioData.get(rowCounter).get(1);
			String status=scenarioData.get(rowCounter).get(2);
			String adminClosureReason=scenarioData.get(rowCounter).get(3);
			String fpl=scenarioData.get(rowCounter).get(4);

			LandingPage paLandingPage = new LandingPage(driver, testCaseId);
			paLandingPage.validatePremiumAssistanceInvestigationReferalCriteria(name, aidCat, status, adminClosureReason, fpl);
		}
	}

	@Given("^From PA Landing Page, Go to Add New Employer$")
	public void gotoAddNewEmployerPage() throws Exception {
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		paLandingPage.goToAddEmployerScreen();
		
		AddEmployerPage addEmployerPage = new AddEmployerPage(driver, testCaseId);
		addEmployerPage.waitForPageLoaded();
	}


	@Given("^From PA Landing Page, Go to Add New Admin$")
	public void gotoAddNewAdminPage() throws Exception {
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		paLandingPage.goToAddAdminScreen();
		
		AddAdminPage addAdminPage = new AddAdminPage(driver, testCaseId);
		addAdminPage.waitForPageLoaded();
	}

	@Given("^From PA Landing Page, Go to Add New Policy Information$")
	public void gotoAddNewPolicy() throws Exception {
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		paLandingPage.goToAddNewPolicyScreen();
		
		AddNewPolicyInfoPage addNewPolicyInfoPage = new pages.pa.AddNewPolicyInfoPage(driver, testCaseId);
		addNewPolicyInfoPage.waitForPageLoaded();
	}
	
	@Given("^From PA Landing Page Left Tab, Click on Premium Assistance$")
	public void clickOnPremiumAssistanceSelectedTab() throws Exception {
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		paLandingPage.clickOnPremiumAssistanceSelectedTab();
		paLandingPage.waitForPageLoaded();
	}
	
	//Shailza
	@Given("^From PA Landing Page Left Tab, Click on View Application Summary Tab$")
	public void clickOnViewApplicationSummaryTab() throws Exception {
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		paLandingPage.clickOnViewAppSummaryTab();
		eligibilityApplicationPage.waitForPageLoaded();
	}
	
	//Shailza
	@Given("^From PA Landing Page Left Tab, Click on View Medicaid HH Tab$")
	public void clickOnViewMedicaidHHTab() throws Exception {
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		MedicaidHHDeterminationPage medicaidHHDeterminationPage = new MedicaidHHDeterminationPage(driver, testCaseId);
		paLandingPage.clickOnViewMedicaidHHTab();
		medicaidHHDeterminationPage.waitForPageLoaded();
	}
	
	//Shailza
	@Given("^From PA Landing Page Left Tab, Click on View Notices Tab$")
	public void clickOnViewNoticesTab() throws Exception {
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		paLandingPage.clickOnViewMedicaidNoticesTab();
		FindAndViewMedicaidNoticesPage findAndViewMedicaidNoticesPage = new FindAndViewMedicaidNoticesPage(driver, testCaseId);
		findAndViewMedicaidNoticesPage.waitForPageLoaded();
	}
	
	//Amrita
	@Given("^From PA Landing Page, Take Screenshot$")
	public void takeScreenshot() throws Exception{
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		paLandingPage.takeScreenshot();
	}


	/**@author Ritika

	From PA Landing Page, Click On Edit Policy To Perform Overide For Member "1"
	
	 */
	@Given("^From PA Landing Page, Click On Edit Policy To Perform Overide For Member \"(.*?)\"$")
	public void gotoPAPolicyScreenBySuperUser(String memIndex) throws Exception {
		LandingPage paLandingPage = new LandingPage(driver, testCaseId);
		int memNo = Integer.parseInt(memIndex)-1;
		String currentEligibilityId = TestData.getTempTestData("CurrentEligibilityId",featureFileName);
		ElgMemberTable elgMem = new ElgMemberTable(conn, currentEligibilityId);
		String policyHolderName=elgMem.getFirstName(currentEligibilityId, memNo);
		paLandingPage.goToEditToOverridePAOnHealthInsurancePolicyScreen(policyHolderName);
	}
	
	/**@author Ritika

	From Landing Page, Validate Premium Assistance Summary
		|MemNo | PAAmnt 		| PaymentStatus | 
		|	 1 | $ 1380.00      | CP          	| 

	 */

	@Given("^From Landing Page, Validate Premium Assistance Summary$")
	public void validatePA_Amount_Status_Under_PremiumAssistanceSummaryCriteria(DataTable table) throws Exception {
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		String currentEligibilityId = TestData.getTempTestData("CurrentEligibilityId",featureFileName);
		ElgMemberTable elgMem = new ElgMemberTable(conn, currentEligibilityId);

		for(int rowCounter=1; rowCounter<rowCount; rowCounter++){
			int memIndex = Integer.parseInt(scenarioData.get(rowCounter).get(0))-1;
			String policyHolderName=elgMem.getFullName(currentEligibilityId, memIndex);
			String paAmount = scenarioData.get(rowCounter).get(1);
			String pymtStatus = scenarioData.get(rowCounter).get(2);

			LandingPage paLandingPage = new LandingPage(driver, testCaseId);
			paLandingPage.validatePA_Amount_Status_Under_PremiumAssistanceSummary(policyHolderName, paAmount, pymtStatus);
		}
	}
}
