package stepdefs.premiumAssistance;
import cucumber.api.java.en.Given;
import db.DualTable;
import db.ElgMemberTable;
import pages.pa.AddAdminPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

/**
 * 
 * @author Ritika
 *
 */
public class AddNewAdminSteps extends SuperStepDef{
	
	public AddNewAdminSteps(Hook hook){
		super(hook);
	}
	
	/**
	 * 
	 *@author Ritika
	 	From Add New Admin Page, Enter Admin Details For Mem "1" ,With Effective Date Prior From Today As "-20"
	 */
	@Given("^From Add New Admin Page, Enter Admin Details For Mem \"(.*?)\" ,With Effective Date Prior From Today As \"(.*?)\"$")
	public void AddNewEmployerDetails(String memNo,String effDate) throws Exception {
		int memIndex=Integer.parseInt(memNo)-1;
		String currentEligibilityId = TestData.getTempTestData("CurrentEligibilityId",featureFileName);
		ElgMemberTable elgMem = new ElgMemberTable(conn, currentEligibilityId);
		String memberName=elgMem.getFirstName(currentEligibilityId, memIndex)+" "+elgMem.getLastName(currentEligibilityId, memIndex);
		String currentDate = new DualTable(conn,"").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);
		String effectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+effDate);
		String adminName = "Admin";
		String streetAddress = globalData.get("Member1_M_StreetAddress");
		String city = globalData.get("Member1_M_City");
		String zipCode = globalData.get("Member1_M_ZIP_Code");
		String county = globalData.get("Member1_M_County");
		String aptUnitNo = globalData.get("Member1_H_Apt_Unit");
		String phoneNumber = globalData.get("Member_Employer_Phone_No1");
		String contactName="Harry";
		
		AddAdminPage addAdminPage = new AddAdminPage(driver, testCaseId);
		addAdminPage.enterAdminDetails(memberName, adminName, streetAddress, aptUnitNo, city, zipCode, county, contactName, phoneNumber, effectiveDate);
	}
	
	

}
