package stepdefs.premiumAssistance;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import pages.pa.AddEmployerPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class AddNewEmployerSteps extends SuperStepDef{

	public AddNewEmployerSteps(Hook hook){
		super(hook);
	}

	
	/**@author Ritika

	From Add New Employer Details Page, For Member "1" ,Select Employer Name As "Optum" ,And Offered Health Insurance As "TRUE"

	 */
	@When("^From Add New Employer Details Page, For Member \"(.*?)\" ,Select Employer Name As \"(.*?)\" ,And Offered Health Insurance As \"(.*?)\"$")
	public void selectHealthInsuranceInfoAsNoneForMember(String memNo, String employerName, String offHltInsurance ) throws Exception{
		
		int memIndex = Integer.parseInt(memNo)-1;
		String currentEligibilityId = TestData.getTempTestData("CurrentEligibilityId",featureFileName);
		ElgMemberTable elgMem = new ElgMemberTable(conn, currentEligibilityId);
		String employeeName=elgMem.getFullName(currentEligibilityId, memIndex);
		Boolean offHltIns = offHltInsurance.equalsIgnoreCase("TRUE")?true:false;
		
		AddEmployerPage addEmployerPage = new AddEmployerPage(driver, testCaseId);
		addEmployerPage.addEmpDetails(employeeName, employerName, offHltIns);
	}
	
	
	
	/**@author Ritika

	From Add New Employer Details Page, Enter details for Member Access
		|MemNo 			|  AccessStatus 			| 
		|	 1 			|  A - Confirmed Access  	| 
		|	 2 	  		|  P - Potential Access		|
	 
	 */

	@Given("^From Add New Employer Details Page, Enter details for Member Access$")
	public void AddMemAccess(DataTable Table) throws Exception {
		List<List<String>> scenarioData = Table.raw();
		int rowcount = scenarioData.size();
		AddEmployerPage addEmployerPage = new AddEmployerPage(driver, testCaseId);
		
		for (int rowCounter=1;rowCounter<rowcount;rowCounter++)
		{

			int memIndex = Integer.parseInt(scenarioData.get(rowCounter).get(0))-1;
			String accessStatus=scenarioData.get(rowCounter).get(1).trim();
			addEmployerPage.selectAccessStatusForMember(memIndex, accessStatus);

		}
	}
	
	/**@author Ritika

	From Add New Employer Details Page, Click On Save Button
	 */

	@Given("^From Add New Employer Details Page, Click On Save Button$")
	public void clickOnSaveButton() throws Exception {
		AddEmployerPage pa_AddEmployerPage = new AddEmployerPage(driver, testCaseId);
		pa_AddEmployerPage.clickOnSaveButton();
	}
	
	/**@author Ritika

	From Add New Employer Details Page, Click On Alert OK Button
	 */

	@Given("^From Add New Employer Details Page, Click On Alert OK Button$")
	public void clickOnAlertOkButton() throws Exception {
		AddEmployerPage pa_AddEmployerPage = new AddEmployerPage(driver, testCaseId);
		pa_AddEmployerPage.clickOnAlertOkButton();
	}
}