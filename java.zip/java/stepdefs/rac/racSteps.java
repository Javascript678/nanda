package stepdefs.rac;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import modules.evpd.StartYourApplicationModule;
import modules.rac.ReportAChangeModule;
import pages.accountDashboard.AccountDashboardLandingPage;
import pages.login.HomePage;
import pages.login.Portal;
import pages.manageCustomer.FindACustomerPage;
import pages.myEligibility.EligibilityApplicationPage;
import pages.rac.ChangeYourInfoPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.PageHeader;
import utils.TestData;

public class racSteps extends SuperStepDef{
	
	public racSteps(Hook hook){
		super(hook);
	}
	
	@Given("^RAC, Login To MAHIX Portal$")
	public void racLoginToAgentPortalTplUser() throws Exception {
		Portal portal = new Portal(hook);
		portal.goToPortal(browserToUse, racData.url, racData.portal, racData.optumIdData);
	}
	
	@Given("^RAC, Find A Customer With UserProfileRefId And Go To Account Dashboard$")
	public void racFindCustomerWithUserProfileRefId() throws Exception {
		String userProfileRefId = evpdData.memsData.get(0).userRefId;
		String year = globalData.get("ApplicationCreationYear");
		
		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.agentPageLoadAndClickOnManageCustomerLink();
		
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(userProfileRefId);
		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.waitForPageLoaded();
		accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
		
		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		eligibilityApplicationPage.performActionToGoToReportAChangePage(year);
		
		ChangeYourInfoPage changeYourInfo = new ChangeYourInfoPage(driver, testCaseId);
		changeYourInfo.handleWarningDialogIfPresent();
	}
	
	@Given("^RAC, Select Type of Update And Click On Report A Change$")
	public void racClickOnReportAChangeForIncome() throws Exception {
		ChangeYourInfoPage changeYourInfoPage = new ChangeYourInfoPage(driver, testCaseId);
		
		for(int racInd = 0; racInd < racData.count; racInd++){
			try{
				if(racData.memsData.get(racInd).racType.equalsIgnoreCase("ADD_FAMILY")){
					changeYourInfoPage.selectAddFamilyMemRdBtn(true);
				}
				
				if(racData.memsData.get(racInd).racType.equalsIgnoreCase("REMOVE_FAMILY")){
					changeYourInfoPage.selectRemoveFamilyMemRdBtn(true);
				}
				
				if(racData.memsData.get(racInd).racType.equalsIgnoreCase("UPDATE_INCOME")){
					changeYourInfoPage.selectUpdateIncomeRdBtn(true);
				}
				
				if(racData.memsData.get(racInd).racType.equalsIgnoreCase("CHANGE_STATUS")){
					changeYourInfoPage.selectChangeStatusRdBtn(true);
				}
				
				if(racData.memsData.get(racInd).racType.equalsIgnoreCase("CHANGE_ADDR")){
					changeYourInfoPage.selectChangeHomeAddrRdBtn(true);
				}
				
				if(racData.memsData.get(racInd).racType.equalsIgnoreCase("CHANGE_APP_TYPE")){
					changeYourInfoPage.selectChangeAppTypeRdBtn(true);
				}
				
				if(racData.memsData.get(racInd).racType.equalsIgnoreCase("CHANGE_FTR")){
					changeYourInfoPage.selectChangePastTaxCreditRdBtn(true);
				}
			}catch(NullPointerException npe){
				System.out.println("########## House Hold Members ##########");
			}
		}
		
		changeYourInfoPage.clickOnReportChangeBtn();
		changeYourInfoPage.selectAllMembersForUpdate(evpdData.memCount);
	}
	
	@And("^RAC, Complete Report A Change Module$")
	public void completeRACModule() throws Exception {		
		while(true){
			PageHeader pageHeader = new PageHeader(driver, testCaseId);			
			
			String header = pageHeader.getPageHeader();
			
			if(header.isEmpty()){
				break;
			}
			
			ReportAChangeModule reportAChangeModule = new ReportAChangeModule(driver, testCaseId);			
			reportAChangeModule.completeReportAChangeDetails(header, envData.get("Display.sheltered.workshop.question"), evpdData, racData);
		}
	}

}
