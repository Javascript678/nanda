package stepdefs.mail;

import java.io.File;

import cucumber.api.java.en.Given;
import db.DualTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.EmailUtil;
import utils.MSWordUtil;

public class SendMailSteps extends SuperStepDef{
	
	public SendMailSteps(Hook hook){
		super(hook);
	}
	
	/**@author vkuma212

		Send Mail To MOCC Team, with Date Change Request "10" Days From Today
		
	 */
	@Given("^Send Mail To MOCC Team, with Date Change Request \"(.*?)\" Days From Today$")
	public void sendMailToMoccTeamForDateChange(String dateFromToday) throws Exception {

		/*String envName = environment;
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		String newDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:-"+dateFromToday);;
		
		String destinationDir = Hook.testReportFolder + File.separator + testCaseId + File.separator + "DateChangeDoc";
    	
		
		MSWordUtil.createSampleCRFormForDateChange(newDate, envName,  destinationDir);
		
		String fromEmailId = "MA-HIX_OGS_Automation_DL@ds.uhc.com";
		String toEmailIds = "vinay_kumar2@optum.com,ritika_gupta64@optum.com";
		String ccEmailIDs = "ritika_gupta64@optum.com,ritika_gupta644@optum.com";
		String subject = envName+ " env date change request";
		String body = "Hi Mocc Team,\n\nCould you please change the " + envName + " Environment Date as mentioned below in App/DB/Batch Server.\n\nDate Change : "+newDate+" \n\n Thanks and Regards,\n Automation Team";
		String attachFolderName = destinationDir;
		
		EmailUtil.sendMail(fromEmailId, toEmailIds, ccEmailIDs,subject , body, attachFolderName );*/
		
	}
	
	@Given("^Send Mail To MOCC Team With Request To Set Date To \"(.*?)\"$")
	public void sendMailToMoccTeamRequestDateChange(String requestDate) throws Exception {

		/*String envName = environment;
		
		String destinationDir = Hook.testReportFolder + File.separator + testCaseId + File.separator + "DateChangeDoc";    	
		
		MSWordUtil.createSampleCRFormForDateChange(requestDate, envName, destinationDir);
		
		String fromEmailId = "MA-HIX_OGS_Automation_DL@ds.uhc.com";
		String toEmailIds = "MOCC_monitoring@optum.com, trina.naran@optum.com, mahix_dev_support@optum.com";
		String ccEmailIDs = "paul_pinho@optum.com, vinay_kumar2@optum.com, ritika_gupta64@optum.com";
		String subject = envName + " env date change request";
		String body = "Hi Mocc Team,\n\n Could you please change the " + envName + "  Environment Date as mentioned below in App/DB/Batch Server. \n\n Date Change: " + requestDate + " \n\n Thanks and Regards,\n Automation Team";
		String attachFolderName = destinationDir;
		
		EmailUtil.sendMail(fromEmailId, toEmailIds, ccEmailIDs, subject , body, attachFolderName );		
*/	}
}
