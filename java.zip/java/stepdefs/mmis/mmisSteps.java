package stepdefs.mmis;

import java.util.List;

import appdata.common.SqlCredentials;
import appdata.evpd.EVPD_MemData;
import appdata.pa.PA_MemData;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.DualTable;
import db.ElgMemberTable;
import db.MMIS_Post_Elg_Control_Data_Table;
import pages.login.Portal;
import pages.manageCustomer.FindACustomerPage;
import pages.pa.AddNewPolicyInfoPage;
import pages.pa.LandingPage;
import stepdefs.ruleEngine.RuleEngineSteps;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.HttpsClient;
import utils.TestData;
import xml.MMISRequestXML;

public class mmisSteps extends SuperStepDef {
	
	public mmisSteps(Hook hook) {
		super(hook);
	}
	
	/** @author ppinho
	*  
	* MMIS, Validate "RESPONSE_XML_CLOB" In MmisPostElgControlData Table On Given Env
	* 
	*/
	@Given("^MMIS, Validate \"(.*?)\" In MmisPostElgControlData Table On Given Env$")
	public void validateEvpdMmisXml(String column) throws Exception {
  		String ipAddress = globalData.get("AWS_Server_Domain").trim();
  		String username = globalData.get("username").trim().toLowerCase();
  		String password = globalData.get("password").trim();
  		
  		SqlCredentials sqlCredentials = TestData.getSqlCredentials(globalData);		
  		
  		MMIS_Post_Elg_Control_Data_Table mmisPostElgControlData = new MMIS_Post_Elg_Control_Data_Table(conn, featureFileName);
  		
  		for(int memInd = 0; memInd < mmisData.memCount; memInd++){
  			if(mmisData.memsData.get(memInd).mmisInd){
	  	  		sqlCredentials.sqlScript = mmisPostElgControlData.getMemXmlData(evpdData.memsData.get(0).elgId.toString(), evpdData.memsData.get(memInd).firstName, evpdData.memsData.get(memInd).lastName);
	  	  		sqlCredentials.dbColumn = column; 
	  	  		
	  	  		System.out.println(sqlCredentials.sqlScript);
	  	  		System.out.println(sqlCredentials.dbColumn);
	
	  	  		HttpsClient httpClient = new HttpsClient();		
	  	  		String xml = httpClient.runXmlQueryMS(ipAddress, username, password, SqlCredentials.sqlXmlRequestData(sqlCredentials));
	            
	  	  		MMISRequestXML mmisRequestXml = new MMISRequestXML(testCaseId, xml);
	  	  		
	  	  		//mmisRequestXml.validateAppDateFieldValue(evpdData.memsData.get(i).appCreateDate);
	  	  		mmisRequestXml.validateAidCatFieldValue(evpdData.memsData.get(memInd).mhAidCat);
  			}
  		}
	}
}
