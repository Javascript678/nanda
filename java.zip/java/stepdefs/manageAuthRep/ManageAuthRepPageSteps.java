package stepdefs.manageAuthRep;

import pages.manageAuthRep.ARDPage;
import pages.manageAuthRep.ManageAuthRepPage;
import cucumber.api.java.en.Given;
import db.DualTable;
import db.ElgMemberTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class ManageAuthRepPageSteps extends SuperStepDef {
	public ManageAuthRepPageSteps(Hook hook) {
		super(hook);
	}

	@Given("^From Manage Authorized Representative, Click on Enrollment Assister$")
	public void clickOnEnrollmentAssister() throws Exception {
		ManageAuthRepPage manageAuthRepPage = new ManageAuthRepPage(driver, testCaseId);
		manageAuthRepPage.clickOnEnrollmentAssister();

	}

	@Given("^From Enrollment Assister Details Page , Enter ARD Details and Activate$")
	public void enterArdDetails() throws Exception {

		String currentDate = new DualTable(conn, "").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);
		String effectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern,
				"00:00:10");

		String desig = globalData.get("EAD_DESIGNATION");
		String firstName = globalData.get("EAD_FNAME");
		String lastName = globalData.get("EAD_LNAME");
		String streetAddress = globalData.get("EAD_StreetAddress");
		String city = globalData.get("EAD_City");
		String zipCode = globalData.get("EAD_ZIP_Code");
		String county = globalData.get("EAD_County");
		String phoneNumber = globalData.get("EAD_PhoneNo");
		String phoneType = globalData.get("EAD_PhoneType");
		String signature = getHOH_FullName();
		String fromDate = effectiveDate;

		ARDPage ardPage = new ARDPage(driver, testCaseId);
		ardPage.enterArdDetails(desig, firstName, lastName, streetAddress, city, zipCode, county, phoneNumber,
				phoneType, signature, fromDate);

	}

	/*
     * @ritu
     *  Designation Type : Navigator
     *                     CAC
     *                  ARD I
     *                  ARD II
     *                  ARD III
     *                  PSI
     * 
      * From Enrollment Assister Details Page , Enter ARD Details For "2" Memeber Where Designation Type As "ARD I" And StartDate as "10" days prior from app date
     *
     * 
      * */
     
     @Given("^From Enrollment Assister Details Page , Enter ARD Details For \"(.*?)\" Memeber Where Designation Type As \"(.*?)\" And StartDate as \"(.*?)\" days prior from app date$")
     public void enterArdDetailsForMember(String memNo ,String designationType ,String startDate) throws Exception {
			
			String appDate = TestData.getTempTestData("AppDate", featureFileName);
			int memIndex = Integer.parseInt(memNo);
     
           String effectivestartDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+startDate);

           
           String firstName = globalData.get("EAD_FNAME");
           String lastName = globalData.get("EAD_LNAME");
           String streetAddress = globalData.get("EAD_StreetAddress");
           String city = globalData.get("EAD_City");
           String zipCode = globalData.get("EAD_ZIP_Code");
           String county = globalData.get("EAD_County");
           String phoneNumber = globalData.get("EAD_PhoneNo");
           String phoneType = globalData.get("EAD_PhoneType");
           String signature = getHOH_FullName();
           
           

           ARDPage ardPage = new ARDPage(driver, testCaseId);
           
           ardPage.enterArdDetailsForMember(memIndex,designationType, firstName, lastName, streetAddress, city, zipCode, county, phoneNumber,
                         phoneType, signature, effectivestartDate);
     }
     
     
     /*
      * @Ritu 
       * 
       * Designation Type:
      * ARD I
      * ARD II
      * 
       * From Manage Authorized Representative, Click On Manage Button Where Designation Type As "ARD I" And StartDate as "10" days prior from app date
      * 
       * 
       * */
      
      @Given("^From Manage Authorized Representative, Click On Manage Button Where Designation Type As \"(.*?)\" And StartDate as \"(.*?)\" days prior from app date$")
      public void clickOnManageBtn(String desigType,String date) throws Exception {
            ManageAuthRepPage manageAuthRepPage = new ManageAuthRepPage(driver, testCaseId);
            String appDate = TestData.getTempTestData("AppDate", featureFileName);
            String effectivestartDate = DateUtil.getPriorDateInDBFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:"+date);
            
            manageAuthRepPage.clickOnManageBtn(desigType, effectivestartDate );
      }

      
     /*Ritu
      * 
       *  
       *  From Manage Authorized Representative, Click on Deactivate
      *  
       * */
      
      @Given("^From Manage Authorized Representative, Click on Deactivate$")
      public void clickOnDeactivateBtn() throws Exception {
             ARDPage ardPage = new ARDPage(driver, testCaseId);
             ardPage.clickOnDeActivateBtn();

      }

	private String getHOH_FullName() {
		String name = null;
		try {
			String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
			ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
			int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

			if (memCount > 0) {
				name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, 0);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return name;
	}
}
