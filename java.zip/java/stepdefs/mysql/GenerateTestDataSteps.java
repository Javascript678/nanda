package stepdefs.mysql;

import java.util.ArrayList;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.GenerateTestData;

public class GenerateTestDataSteps extends SuperStepDef {
	
	public GenerateTestDataSteps(Hook hook) {
		super(hook);
	}
	
	/** @author ppinho
	 * 
	 * Generate test data for any table listed in the examples
	 * 
	 */

	@Given("^Generate Test Data In MySQL Database$")
	public void generateTestDataInMySQLDatabase(DataTable tables) throws Exception {
		List<String> tableArray = new ArrayList<>();
		
		List<List<String>> tablesToLoad = tables.raw();
		
		for(int i = 1; i < tablesToLoad.size(); i++){
			tableArray.add(tablesToLoad.get(i).get(0).toLowerCase().trim());
		}
		
		GenerateTestData testData = new GenerateTestData();
		
		for(String table : tableArray){
			testData.generateTestData(table);
		}
	}
	
}
