package stepdefs.rfi;
import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import enums.VerifyRFI;
import pages.rfi.RFILandingPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class RFI_LandingPageSteps extends SuperStepDef{
	
	public RFI_LandingPageSteps(Hook hook){
		super(hook);
	}
	
	/**@author akumari4
	   
	    From RFI Landing Page, Go To Immigration RFI Page For Member "1"
	 * @param memNo
	 * @throws Exception
	 */
	@Given("^From RFI Landing Page, Go To Immigration RFI Page For Member \"(.*?)\"$")
	public void clickOnVerifyActiveImmigrationRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("IMM");
		//if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.clickOnVerifyActiveRFIButtonForMember(name, rfiTypeOnUI);
		//}
	}
	
	/**@author akumari4
	 * 
	  From RFI Landing Page, Go To Address RFI Page For Member "1"
	 * @param memNo
	 * @throws Exception
	 */
	@Given("^From RFI Landing Page, Go To Address RFI Page For Member \"(.*?)\"$")
	public void clickOnVerifyActiveAddressRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("ADR");
		//if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.clickOnVerifyActiveRFIButtonForMember(name, rfiTypeOnUI);
		//}
	}
	
	
	/**@author vkuma212
	 
	 From RFI Landing Page, Go To Income RFI Page For Member "1"
	 
	 */
	@Given("^From RFI Landing Page, Go To Income RFI Page For Member \"(.*?)\"$")
	public void clickOnVerifyActiveIncomeRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("INC");
		//if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.clickOnVerifyActiveRFIButtonForMember(name, rfiTypeOnUI);
		//}
	}
	
	/**@author vkuma212
	 
	 From RFI Landing Page, Go To SSN RFI Page For Member "1"
	 
	 */
	@Given("^From RFI Landing Page, Go To SSN RFI Page For Member \"(.*?)\"$")
	public void clickOnVerifyActiveSSNRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("SSN");
		//if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.clickOnVerifyActiveRFIButtonForMember(name, rfiTypeOnUI);
		//}
	}
	
	/**
	 
	 From RFI Landing Page, Go To NCP RFI Page For Member "1"
	 
	 */
	@Given("^From RFI Landing Page, Go To NCP RFI Page For Member \"(.*?)\"$")
	public void clickOnVerifyActiveNCPRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("NCP");
		//if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.clickOnVerifyActiveRFIButtonForMember(name, rfiTypeOnUI);
		//}
	}
	
	/**
	 
	 From RFI Landing Page, Go To Incarceration RFI Page For Member "1"
	 
	 */
	@Given("^From RFI Landing Page, Go To Incarceration RFI Page For Member \"(.*?)\"$")
	public void clickOnVerifyActiveIncarcerationRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("INCAR");
		//if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.clickOnVerifyActiveRFIButtonForMember(name, rfiTypeOnUI);
		//}
	}
	
	/**Aashita
	 
	 From RFI Landing Page, Go To AI/AN RFI Page For Member "1"
	  
	 * @throws Exception
	 */
	@Given("^From RFI Landing Page, Go To AI/AN RFI Page For Member \"(.*?)\"$")
		public void clickOnVerifyActiveAmericanAlaskanRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
	
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("AIAN");
		//if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.clickOnVerifyActiveRFIButtonForMember(name, rfiTypeOnUI);
		//}
	}
	
	/**Ritika
	 
	 From RFI Landing Page, Go To Citizenship Page For Member "1"
	  
	 * @throws Exception
	 */
	@Given("^From RFI Landing Page, Go To Citizenship Page For Member \"(.*?)\"$")
		public void clickOnVerifyActiveCitizenRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
	
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("CIT");
		//if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.clickOnVerifyActiveRFIButtonForMember(name, rfiTypeOnUI);
		//}
	}
	/**@author vkuma212
	 * From RFI Landing Page, Click On Rerun Eligibility
	 */
	@Given("^From RFI Landing Page, Click On Rerun Eligibility$")
	public void clickOnReRunEligibility() throws Exception {
		
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		rfiLandingPage.clickOnReRunEligibility();
	}
	
	/**@author vkuma212
	 * From RFI Landing Page, Click On Confirm Pop Up
	 */
	@Given("^From RFI Landing Page, Click On Confirm Pop Up$")
	public void clickOnConfirmPopup() throws Exception {
		
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		rfiLandingPage.clickOnConfirmPopup();
	}
	
	/**@author vkuma212
	 * From RFI Landing Page, Click On View Unlock Eligibility Btn From Left Menu Slider
	 */
	@Given("^From RFI Landing Page, Click On View Unlock Eligibility Btn From Left Menu Slider$")
	public void clickOnLeftMenuSlider() throws Exception {
		
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		rfiLandingPage.clickOnLeftMenuSlider();
		rfiLandingPage.clickOnViewUnlockEligibilityBtn();
	}
	
	/**@author ppinho
	   
	 * From RFI Landing Page, Go To Immigration RFI Manage Clock Page For Member "1"
	 * @param memNo
	 * @throws Exception
	 */
	@Given("^From RFI Landing Page, Go To Immigration RFI Manage Clock Page For Member \"(.*?)\"$")
	public void clickOnManageClockActiveImmigrationRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
			
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("IMM");
		if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnManageClockForActiveRFIButtonForMember(name, rfiTypeOnUI);
		}
	}	

	/**@author ppinho
	 * 
	  From RFI Landing Page, Go To Address RFI Manage Clock Page For Member "1"
	 * @param memNo
	 * @throws Exception
	 */
	@Given("^From RFI Landing Page, Go To Address RFI Manage Clock Page For Member \"(.*?)\"$")
	public void clickOnVerifymanageClockAddressRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
			
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("ADR");
		if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnManageClockForActiveRFIButtonForMember(name, rfiTypeOnUI);
		}
	}
	
	/**@author ppinho
		 
	 From RFI Landing Page, Go To Income RFI Manage Clock Page For Member "1"
	 
	 */
	@Given("^From RFI Landing Page, Go To Income RFI Manage Clock Page For Member \"(.*?)\"$")
	public void clickOnManageClockActiveIncomeRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("INC");
		if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
				rfiLandingPage.waitForPageLoaded();
				rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
				rfiLandingPage.waitForPageLoaded();
				rfiLandingPage.clickOnManageClockForActiveRFIButtonForMember(name, rfiTypeOnUI);
		}
	}

	/**@author ppinho
		 
	 From RFI Landing Page, Go To SSN RFI Manage Clock Page For Member "1"
		 
	 */
	@Given("^From RFI Landing Page, Go To SSN RFI Manage Clock Page For Member \"(.*?)\"$")
	public void clickOnManageClockActiveSSNRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
			
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("SSN");
		if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnManageClockForActiveRFIButtonForMember(name, rfiTypeOnUI);
		}
	}
					
	/**@author ppinho
		 
	 From RFI Landing Page, Go To NCP RFI Manage Clock Page For Member "1"
		 
	 */
	@Given("^From RFI Landing Page, Go To NCP RFI Manage Clock Page For Member \"(.*?)\"$")
	public void clickOnManageClockActiveNCPRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("NCP");
		if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnManageClockForActiveRFIButtonForMember(name, rfiTypeOnUI);
		}
	}
		
	/**@author ppinho
	 
	 From RFI Landing Page, Go To Incarceration RFI Manage Clock Page For Member "1"
	 
	 */
	@Given("^From RFI Landing Page, Go To Incarceration RFI Manage Clock Page For Member \"(.*?)\"$")
	public void clickOnManageClockActiveIncarcerationRFIButtonForMember(String memNo) throws Exception{
		int intMemNo = Integer.parseInt(memNo);
		int memindex = intMemNo-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, intMemNo-1);
		System.out.println("Clearing RFI for Member " + name);
		RFILandingPage rfiLandingPage = new RFILandingPage(driver, testCaseId);
		String rfiTypeOnUI = VerifyRFI.get_UI_Val("INCAR");
		if(rfiLandingPage.isMemberActiveRFIPresent(name, rfiTypeOnUI)){
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnActiveRFIButtonForMember(browserToUse, name, rfiTypeOnUI,memindex);
			rfiLandingPage.waitForPageLoaded();
			rfiLandingPage.clickOnVerifyActiveRFIButtonForMember(name, rfiTypeOnUI);
		}
	}


}
