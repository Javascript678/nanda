package stepdefs.rfi;
import cucumber.api.java.en.Given;
import pages.rfi.VerifyImmigrationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class VerifyImmigrationPageSteps extends SuperStepDef{
	
	public VerifyImmigrationPageSteps(Hook hook){
		super(hook);
	}
	
	/**
	 
	From Verify Immigration Page, Take ScreenShot
	 
	 */
	@Given("^From Verify Immigration Page, Take ScreenShot$")
	public void takeScreenshot() throws Exception{
		
		VerifyImmigrationPage verifyImmigPage = new VerifyImmigrationPage(driver, testCaseId);
		verifyImmigPage.takeScreenshot();
	}
	/**
	 
	 From Verify Immigration Page, Verify Immigration With Comments As "Verifying Immigration For Member 1" and Then Go Back To RFI Landing Page
	 
	 */
	@Given("^From Verify Immigration Page, Verify Immigration With Comments As \"(.*?)\" and Then Go Back To RFI Landing Page$")
	public void verifyImmigrationAndGoBackToLandingPage(String rfiMessage ) throws Exception{
		VerifyImmigrationPage verifyImmigPage = new VerifyImmigrationPage(driver, testCaseId);
		verifyImmigPage.verifyImmigrationAndGoBackToLandingPage(rfiMessage);
	}
}
