package stepdefs.rfi;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import pages.rfi.UpdateSSNPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.RandomGenerator;
import utils.TestData;

public class UpdateSSNPageSteps extends SuperStepDef{
	
	public UpdateSSNPageSteps(Hook hook){
		super(hook);
	}
	
	/**@author vkuma212
	 
	From Update SSN Page, Take ScreenShot
	 
	 */
	@Given("^From Update SSN Page, Take ScreenShot$")
	public void takeScreenshot() throws Exception{
		
		UpdateSSNPage updateSSNPage = new UpdateSSNPage(driver, testCaseId);
		updateSSNPage.takeScreenshot();
	}
	
	/**@author vkuma212
	 
	 From Update SSN Page, Enter SSN For Members
	 | MemNo    | SSNFormat    |
	 |	1		|			   |
	 |	2		|			   |
	 |	3		|			   |
	 
	 * Accepted Value 1. MemNo :- 1,2,3
	 * 				  2. SSNFormat :- "BLANK", STR_4, END_3
	 * @param table
	 * @throws Exception
	 */
	@Given("^From Update SSN Page, Enter SSN For Members$")
	public void enterSSNForMember(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		UpdateSSNPage updateSSNPage = new UpdateSSNPage(driver, testCaseId);
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		
		for(int rowCounter=1;rowCounter<rowCount;rowCounter++){
			
			String strMemNo = scenarioData.get(rowCounter).get(0);
			String ssnFormat = scenarioData.get(rowCounter).get(1);
			int memIndex = Integer.parseInt(strMemNo)-1;
			String[] ssnStatus = RandomGenerator.getRunTimeSSN(ssnFormat);
			String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
			System.out.println("Clearing RFI for Member " + name);
		
			updateSSNPage.enterSSNForMember(memIndex,ssnStatus[1],name);
		}
	}
	/**@author vkuma212
	 
	 From Update SSN Page, Validate SSN Is Masked For Member "1"
	 
	 */
	@Given("^From Update SSN Page, Validate SSN Is Masked For Member \"(.*?)\"$")
	public void validateSSNIsMasked(String memNo) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		UpdateSSNPage updateSSNPage = new UpdateSSNPage(driver, testCaseId);
		updateSSNPage.validateSSNIsMaskedForMember(memIndex);
		updateSSNPage.validateConfirmationSSNIsMaskedForMember(memIndex);
	}
	
	/**@author vkuma212
	 
	From Update SSN Page, Click On Verify SSN For Selected Members
	 
	 */
	@Given("^From Update SSN Page, Click On Verify SSN For Selected Members$")
	public void clickOnVerifyBtn() throws Exception{
		
		UpdateSSNPage updateSSNPage = new UpdateSSNPage(driver, testCaseId);
		updateSSNPage.clickOnVerifyBtn();
	}
	
	/**@author vkuma212
	 
	From Update SSN Page, Click On SSN Pop Up Verify SSN Yes Btn
	 
	 */
	@Given("^From Update SSN Page, Click On SSN Pop Up Verify SSN Yes Btn$")
	public void clickSSNPopUpVerifySSNYesBtn() throws Exception{
		
		UpdateSSNPage updateSSNPage = new UpdateSSNPage(driver, testCaseId);
		updateSSNPage.clickSSNPopUpVerifySSNYesBtn();
	}
	
	/**@author Ritika
	 
	From Update SSN Page, Click On Back Btn
	 
	 */
	@Given("^From Update SSN Page, Click On Back Btn$")
	public void clickBackBtn() throws Exception{
		
		UpdateSSNPage updateSSNPage = new UpdateSSNPage(driver, testCaseId);
		updateSSNPage.clickOnBackBtn();
	}
	
	/**@author sshriv16
    
    From Update SSN Page, Click On Account Dashboard Button
    
     */
    @Given("^From Update SSN Page, Click On Account Dashboard Button$")
    public void clickAccountDashboardBtn() throws Exception{
          
          UpdateSSNPage updateSSNPage = new UpdateSSNPage(driver, testCaseId);
          updateSSNPage.clickOnAccountDashboardBtn();
    }


}
