package stepdefs.rfi;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import db.DualTable;
import db.ElgMemberTable;
import pages.rfi.NCPVerificationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.RandomGenerator;
import utils.TestData;

public class NCPVerificationPageSteps extends SuperStepDef{
	
	public NCPVerificationPageSteps(Hook hook){
		super(hook);
	}
	
	/**@author sshriv16
	 
	 On NCP Verification Page, Verify Add Button Is Present To Add Parents Before Verifying the RFI For Member "3"
	 
	 */
	@Given("^On NCP Verification Page, Verify Add Button Is Present To Add Parents Before Verifying the RFI For Member \"(.*?)\"$")
	public void verifyAddBtn(String memNo) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
		System.out.println("Verifying Add Button For Member " + name);
	
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.verifyAddBtnIsPresentToAddParents(name);
	}
	
	/**@author vkuma212
	 
	 From NCP Verification Page, Add Parent for Member "2"
	 
	 */
	@Given("^From NCP Verification Page, Add Parent for Member \"(.*?)\"$")
	public void clickOnAddBtn(String memNo) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
		System.out.println("Clearing NCP RFI for Member " + name);
	
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.clickOnAddBtn(name);
	}
	
	/**@author ppinho
	 
	 From NCP Verification Page, View/Edit Parent
	 
	 */
	@Given("^From NCP Verification Page, View/Edit Parent$")
	public void clickOnViewEditBtn() throws Exception{
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.clickOnViewEditBtn();
	}
	
	/**@author ppinho
	 
	 From NCP Verification Page, Verify Parent for Member "2"
	 
	 */
	@Given("^From NCP Verification Page, Verify Parent for Member \"(.*?)\"$")
	public void clickOnVerifyBtn(String memNo) throws Exception{
		int memIndex = Integer.parseInt(memNo)-1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memIndex);
		System.out.println("Clearing NCP RFI for Member " + name);
	
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.clickOnVerifyBtn(name);
	}
	
	/**ppinho
	 * This type of warning appear while verifying NCP RFI.
	 */
	@Given("^From NCP Verification Page, Handle Warning Dialog If Present$")
	public void handleWarningDialogIfPresent() throws Exception {
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.handleWarningDialogIfPresent();
	}
	
	/**@author vkuma212
	 *  Accepted Value :- ChildNo :- 1,2,3
	 * @param table  selectApplyToChildReason :-
	 * 				1. Child adopted by a single parent
					2. This child was a result of sexual abuse or assault
					3. Cooperation is not in the best interest of this child
					4. Adoption of this child is in process
					5. The non-custodial parent of the child is deceased
					6. The non-custodial parent of the child is unknown
					7. Custodial parent of the child is not married to the father and is currently pregnant
					8. None of the above
	
	From NCP Verification Page, Select Reason To Apply to Child "1" As "Child adopted by a single parent"

	 */
	@Given("^From NCP Verification Page, Select Reason To Apply to Child \"(.*?)\" As \"(.*?)\"$")
	public void selectApplyToChild(String childNo, String  applyToChildReason) throws Exception{
		int childIndex = Integer.parseInt(childNo)-1;
		
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.selectApplyToChild(childIndex, applyToChildReason);
		
	}
	
	/**@author ppinho - edited
	 *  Accepted Value :- 1. ChildNo :- 1,2,3
	 *  SSN Fomat :- "BLANK" means any random SSN
	 * 				 STR_3, END_5, NO_JA
			
		From NCP Verification Page, Complete Parent Verification For Child "1"
			
	 */	
	@Given("^From NCP Verification Page, Complete Parent Verification For Child \"(.*?)\"$")
	public void completeParentVerificationDocument(String childNo) throws Exception{		
		int childIndex = Integer.parseInt(childNo)-1;		
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
			
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		
		ncpVerificationPage.completeParentVerification(childIndex, appDate);
		ncpVerificationPage.takeScreenShot();		
	}
	
	/**@author ppinho
	 *  SSN Fomat :- "BLANK" means any random SSN
	 * 				 STR_3, END_5, NO_JA
	 * 
	 *	From NCP Verification Page, Enter SSN As "123456789"
	 *
	 */	
	@Given("^From NCP Verification Page, Enter SSN As \"(.*?)\"$")
	public void enterSSNforChild(String ssnFormat) throws Exception{
		String[] ssnVal = RandomGenerator.getRunTimeSSN(ssnFormat);
			
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.enterSSN(ssnVal[1]);
		ncpVerificationPage.takeScreenShot();		
	}

	
	/**@author vkuma212
	 *  Accepted Value :- 1. ChildNo :- 1,2,3
		
		From NCP Verification Page, Validate SSN Is Masked For Child "1"
		
	 */
	
	@Given("^From NCP Verification Page, Validate SSN Is Masked For Child \"(.*?)\"$")
	public void validateSSNIsMasked(String childNo) throws Exception{		
		int childIndex = Integer.parseInt(childNo)-1;
		
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.takeScreenShot();
		ncpVerificationPage.validateSSNIsMasked(childIndex);
		
	}
	
	/**@author ppinho
	 *	
	 *	From NCP Verification Page, Verify Error Message For Invalid SSN
	 *
	 */
	@Given("^From NCP Verification Page, Verify Error Message For Invalid SSN$")
	public void invalidSSN() throws Exception{		
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.invlidSsnErrorMessage();
		ncpVerificationPage.takeScreenShot();		
	}

	/**@author Paul
	 *  Accepted Value :- 1. ChildNo :- 1,2,3
		
		From NCP Verification Page, Sign Verification Document For Child "1"
		
	 */
	
	@Given("^From NCP Verification Page, Sign Verification Document For Child \"(.*?)\"$")
	public void signForm(String childNo) throws Exception{
		int childIndex = Integer.parseInt(childNo)-1;
		
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);		
		ncpVerificationPage.verifyDocument(childIndex, appDate);		
	}
	
	//@author ppinho
	@Given("^From NCP Verification Page Left Menu, Go to Account Dashboard$")
	public void goToAccountDashboard() throws Exception {
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);	
		ncpVerificationPage.usingLeftMenuClickOnAccountDashboard();
	}
	
	@When("^From NCP Verification Page, Click On Edit Button$")
	public void pageLoadThenClickOnEditBtn() throws Exception {		
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.clickOnEditBtn();
	}
	
	@When("^From NCP Verification Page, Take Screenshot$")
	public void takeScreenshot() throws Exception{
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.takeScreenshot();		
	}
	
	@When("^From NCP Verification Page, Click On Save And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {		
		NCPVerificationPage ncpVerificationPage = new NCPVerificationPage(driver, testCaseId);
		ncpVerificationPage.clickOnSaveBtn();
	}

}
