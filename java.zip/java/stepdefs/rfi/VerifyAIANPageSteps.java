package stepdefs.rfi;
import cucumber.api.java.en.Given;
import pages.rfi.VerifyAIANPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class VerifyAIANPageSteps extends SuperStepDef{
	
	public VerifyAIANPageSteps(Hook hook){
		super(hook);
	}
	
	/**@author vkuma212
	 
	From Verify American Indian Alaska Native Page, Take ScreenShot
	 
	 */
	@Given("^From Verify American Indian Alaska Native Page, Take ScreenShot$")
	public void takeScreenshot() throws Exception{
		
		VerifyAIANPage verifyAIANPage = new VerifyAIANPage(driver, testCaseId);
		verifyAIANPage.takeScreenshot();
	}
	/**
	 
	 From Verify American Indian Alaska Native Page, Verify RFI With Comments As "Verifying AIAN For Member 1" and Then Go Back To RFI Landing Page
	 
	 */
	@Given("^From Verify American Indian Alaska Native Page, Verify RFI With Comments As \"(.*?)\" And Then Go Back To RFI Landing Page$")
	public void verifyAIANRFIAndGoBackToLandingPage(String comments ) throws Exception{
		VerifyAIANPage verifyAIANPage = new VerifyAIANPage(driver, testCaseId);
		verifyAIANPage.verifyAIANRFIAndGoBackToLandingPage(comments);
	}
}
