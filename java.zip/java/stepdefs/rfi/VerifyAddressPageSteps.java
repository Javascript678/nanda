package stepdefs.rfi;
import cucumber.api.java.en.Given;
import pages.rfi.VerifyAddressPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class VerifyAddressPageSteps extends SuperStepDef{
	
	public VerifyAddressPageSteps(Hook hook){
		super(hook);
	}
	
	/**@author vkuma212
	 
	From Verify Address Page, Take ScreenShot
	 
	 */
	@Given("^From Verify Address Page, Take ScreenShot$")
	public void takeScreenshot() throws Exception{
		
		VerifyAddressPage verifyAddressPage = new VerifyAddressPage(driver, testCaseId);
		verifyAddressPage.takeScreenshot();
	}
	
	/**@author vkuma212
	 
	 From Verify Address Page, Verify Address With Comments As "Verifying Address For Member 1" and Then Go Back To RFI Landing Page
	 
	 */
	@Given("^From Verify Address Page, Verify Address With Comments As \"(.*?)\" and Then Go Back To RFI Landing Page$")
	public void verifyAddressRFIAndGoBackToLandingPage(String rfiMessage ) throws Exception{
		VerifyAddressPage verifyAddressPage = new VerifyAddressPage(driver, testCaseId);
		verifyAddressPage.verifyAddressRFIAndGoBackToLandingPage(rfiMessage);
	}
}
