package stepdefs.rfi;
import cucumber.api.java.en.Given;
import pages.rfi.ChangeIncomePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ChangeIncomePageSteps extends SuperStepDef{
	
	public ChangeIncomePageSteps(Hook hook){
		super(hook);
	}
	
	/**
	 
	 From Change Income Page, Verify Income And Go Back To RFI Landing Page
	 
	 */
	@Given("^From Change Income Page, Verify Income And Go Back To RFI Landing Page$")
	public void verifyIncomeAndGoBackToLandingPage( ) throws Exception{
		
		ChangeIncomePage changeIncomePage = new ChangeIncomePage(driver, testCaseId);
		changeIncomePage.verifyIncomeAndGoBackToLandingPage();
	}
	
	/*
	* From Change Income Page, Update income As "30000" And Verify Income Form Member "1" And Go Back To RFI Landing Page
	* */

	@Given("^From Change Income Page, Update income As \"(.*?)\" And Verify Income Form Member \"(.*?)\" And Go Back To RFI Landing Page$")
	public void verifyIncomeAndGoBackToLandingPage(String memNo, String updatedIncome ) throws Exception{

		ChangeIncomePage changeIncomePage = new ChangeIncomePage(driver, testCaseId);
	
		int memIndex= Integer.parseInt(memNo)-1;
	
		changeIncomePage.updateAndVerifyIncomeAndGoBackToLandingPage(memIndex,updatedIncome);
	}
	
	/**
	 ** Suryam
	 
	 From Change Income Page, Verify Income of MFJ where Member1 has income as "TRUE" and Member "2" income as "FALSE" And Go Back To RFI Landing Page
	 
	 TRUE - HAS INCOME
	 FALSE - HAS NO INCOME
	**/
	@Given("^From Change Income Page, Verify Income of MFJ where Member(\\d+) has income as \"([^\"]*)\" and Member(\\d+) has income as \"([^\"]*)\" And Go Back To RFI Landing Page$")
	public void verifyIncomeofMFJAndGoBackToLandingPage(int memOneNo, String memOneIncome, int memTwoNo, String memTwoIncome) throws Exception{
		

		Boolean trueFalseValuememOneIncome = memOneIncome.equalsIgnoreCase("TRUE")?true:false;
		Boolean trueFalseValuememTwoIncome = memTwoIncome.equalsIgnoreCase("TRUE")?true:false;
			
		ChangeIncomePage changeIncomePage = new ChangeIncomePage(driver, testCaseId);
		changeIncomePage.verifyIncomeOfMemeber1(trueFalseValuememOneIncome);
		
		changeIncomePage.verifyIncomeOfMemeber2(trueFalseValuememTwoIncome);
		
	}
}
