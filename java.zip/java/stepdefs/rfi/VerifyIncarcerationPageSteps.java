package stepdefs.rfi;
import cucumber.api.java.en.Given;
import pages.rfi.VerifyIncarcerationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class VerifyIncarcerationPageSteps extends SuperStepDef{
	
	public VerifyIncarcerationPageSteps(Hook hook){
		super(hook);
	}
	
	/**
	 
	From Verify Incarceration Page, Take ScreenShot
	 
	 */
	@Given("^From Verify Incarceration Page, Take ScreenShot$")
	public void takeScreenshot() throws Exception{
		
		VerifyIncarcerationPage verifyIncPage = new VerifyIncarcerationPage(driver, testCaseId);
		verifyIncPage.takeScreenshot();
	}
	/**
	 
	 From Verify Incarceration Page, Verify Incarceration With Comments As "Verifying Incarceration For Member 1" and Then Go Back To RFI Landing Page
	 
	 */
	@Given("^From Verify Incarceration Page, Verify Incarceration With Comments As \"(.*?)\" and Then Go Back To RFI Landing Page$")
	public void verifyIncarcerationRFIAndGoBackToLandingPage(String rfiMessage ) throws Exception{
		VerifyIncarcerationPage verifyIncPage = new VerifyIncarcerationPage(driver, testCaseId);
		verifyIncPage.verifyIncarcerationRFIAndGoBackToLandingPage(rfiMessage);
	}
}
