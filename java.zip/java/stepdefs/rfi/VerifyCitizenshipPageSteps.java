package stepdefs.rfi;
import cucumber.api.java.en.Given;
import pages.rfi.VerifyCitizenshipPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class VerifyCitizenshipPageSteps extends SuperStepDef{
	
	public VerifyCitizenshipPageSteps(Hook hook){
		super(hook);
	}
	
	/**@author vkuma212
	 
	From Verify Citizenship Page, Take ScreenShot
	 
	 */
	@Given("^From Verify Citizenship Page, Take ScreenShot$")
	public void takeScreenshot() throws Exception{
		
		VerifyCitizenshipPage verifyCitizenshipPage = new VerifyCitizenshipPage(driver, testCaseId);
		verifyCitizenshipPage.takeScreenshot();
	}
	/**
	 
	 From Verify Citizenship Page, Verify RFI With Comments As "Verifying Citizenship For Member 1" and Then Go Back To RFI Landing Page
	 
	 */
	@Given("^From Verify Citizenship Page, Verify RFI With Comments As \"(.*?)\" And Then Go Back To RFI Landing Page$")
	public void verifyCitizenshipAndGoBackToLandingPage(String comments ) throws Exception{
		VerifyCitizenshipPage verifyCitizenshipPage = new VerifyCitizenshipPage(driver, testCaseId);
		verifyCitizenshipPage.verifyCitizenshipAndGoBackToLandingPage(comments);
	}
}
