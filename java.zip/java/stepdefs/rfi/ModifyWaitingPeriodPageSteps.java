package stepdefs.rfi;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import pages.rfi.ModifyWaitingPeriodPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ModifyWaitingPeriodPageSteps extends SuperStepDef{
	
	public ModifyWaitingPeriodPageSteps(Hook hook){
		super(hook);
	}
	
	/**@author ppinho
	 * Waiting Period      :- 30, 60, 90
	 
	 From Modify Waiting Period Page, Extend Waiting Period To "30" Days
	 
	 */
	@Given("^From Modify Waiting Period Page, Extend Waiting Period To \"(.*?)\" Days$")
	public void clickOnAddBtn(String extention) throws Exception{
		ModifyWaitingPeriodPage modifyWaitingPeriod = new ModifyWaitingPeriodPage(driver, testCaseId);
		modifyWaitingPeriod.extendWaitingperiod(extention);
	}	
	
	@When("^From Modify Waiting Period Page Left Menu, Go To Account Dashboard$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {		
		ModifyWaitingPeriodPage modifyWaitingPeriod = new ModifyWaitingPeriodPage(driver, testCaseId);
		modifyWaitingPeriod.usingLeftMenuClickOnAccountDashboard();
	}
	
	@When("^From Modify Waiting Period Page, Take Screenshot$")
	public void pageLoadTakeScreenshot() throws Exception {		
		ModifyWaitingPeriodPage modifyWaitingPeriod = new ModifyWaitingPeriodPage(driver, testCaseId);
		modifyWaitingPeriod.takeScreenshot();
	}

}
