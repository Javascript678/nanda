package stepdefs.myEligibility;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import pages.myEligibility.EligibilityApplicationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class EligibilityApplicationPageSteps extends SuperStepDef{
	
	public EligibilityApplicationPageSteps(Hook hook){
		super(hook);
	}
	
	//Amrita
	@Given("^From Eligibility Application Page, Click on Details Link For Latest Eligibility ID$")
	public void clickOnDetailsLink() throws Exception {
		//String appDate = new DualTable(conn,"").getSysDate();
		//appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		
		String year = globalData.get("ApplicationCreationYear");
		
		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		eligibilityApplicationPage.pageLoadAndClickOnEligibilityDetailsLink(year);
		
	}
	
	@Given("^From Eligibility Application Page, Go to Account Dashboard$")
	public void clickOnBackToAccDashboardBtn() throws Exception {

		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		eligibilityApplicationPage.clickOnBackToAccDashboardBtn();
		
	}
	
	//Shailza
    @Given("^From Eligibility Application Page, Click on Edit Link For Latest Eligibility ID$")
    public void clickOnEditLink() throws Exception {
           
           String year = globalData.get("ApplicationCreationYear");
           
           EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
           eligibilityApplicationPage.performActionclickOnEditLink(year);
           
    }

	@Given("^From Eligibility Application Page, Go to Change Your Info Page$")
	public void goToChangeInfoPage() throws Exception {
		/*String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		*/
		
		String year = globalData.get("ApplicationCreationYear");
		
		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		eligibilityApplicationPage.performActionToGoToReportAChangePage(year);
		
	}
	
	/*Paul
	 
	 From Eligibility Application Page, Store CurrentEligibilityId With Same Name
	 
	 */
	@And("^From Eligibility Application Page, Store CurrentEligibilityId With Same Name")
    public void storeLatestEligID() throws Exception{
		  String year = globalData.get("ApplicationCreationYear");
          EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
          eligibilityApplicationPage.expandYrSection(year);
          
          String currentEligibilityId = eligibilityApplicationPage.getLatestEligibilityId(year);
          System.out.println("new id : "+currentEligibilityId);
          storeTempTestData("CurrentEligibilityId", currentEligibilityId);
    }

	
	//Added by Brajesh for ELigibility details run test Defect 18267	
	@Given("^From Eligibility Application Page, Go to Eligibility History and click on Details link one by one$")
	public void goToEligibilityHistoryAndClickAllDetailsLink() throws Exception {

		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		eligibilityApplicationPage.validateAllEligibiliyDetailsLinkInHistoryTab();
		
	}

}
