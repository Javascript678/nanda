package stepdefs.reviewAndSign;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import pages.reviewAndSign.ReviewApplicationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class ReviewApplicationPageSteps extends SuperStepDef{
	
	public ReviewApplicationPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Review Application Page, Page Load And Click On Save And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.pageLoadThenClickOnSaveAndContinueBtn();
	}
	
	@When("^From Review Application Page, Take ScreenShot$")
	public void takeScreenShot() throws Exception {
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.takeScreenShot();
	}
	
	@When("^From Review Application Page, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception {
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.clickOnSaveAndContinueBtn();
	}
	
	@When("^From Review Application Page, Click On Contact Information Tab$")
	public void pageLoadThenClickOnContactInfoTab() throws Exception {
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.pageLoadThenClickOnContactInfoTab();
	}
	
	@When("^From Review Application Page, Click On Family HH Tab$")
	public void pageLoadThenClickFamilyHHTab() throws Exception {
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.pageLoadThenClickFamilyHHTab();
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@When("^From Review Application Page, Click On Tax Filing Status Tab$")
	public void pageLoadThenClickTaxFilingTab() throws Exception {
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.pageLoadThenClickOnTaxFilingStatusTab();
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@When("^From Review Application Page, Click On Family Income Tab$")
	public void pageLoadThenClickFamilyIncomeTab() throws Exception {
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.pageLoadThenClickOnFamilyIncomeTab();
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@When("^From Review Application Page, Click On Additional Information Tab$")
	public void pageLoadThenClickAdditionalInformationTab() throws Exception {
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.pageLoadThenClickOnAdditionalInfoTab();
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@When("^From Review Application Page, Click On MEC Used in PD Tab$")
	public void pageLoadThenClickMECUsedInPDTab() throws Exception {
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.pageLoadThenClickOnMecUsedInPDTab();
	}

	

	/**
	 *  Accepted Value :- 
	 *  | MemNo  | Member Address |
	 	|   1    | HOMEADDR, 123, HCITY, MA, 01002     |
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Contact Info Tab, Validate Address For HOH$")
	public void validateAddressForMemberUnderContactInfoTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			String memNo  = scenarioData.get(rowIndex).get(0);
			String expHOHAddress  = scenarioData.get(rowIndex).get(1);
			int intMemNo = Integer.parseInt(memNo);
			String expHOHAddressValOnUi = "Address: "+expHOHAddress;
		
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateAddressForHOHUnderContactInfoTab(intMemNo, expHOHAddressValOnUi);
		}
	}
	
	/**@author akumari4
	 *  From Review Application Page, Under Contact Info Tab, Validate Email
	 	| MemNo  | Email Address |
	 	|   1    |   a@a.com     |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Contact Info Tab, Validate Email For HOH$")
	public void validateEmailForHOHUnderContactInfoTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			String memNo  = scenarioData.get(rowIndex).get(0);
			String expHOHEmail  = scenarioData.get(rowIndex).get(1);
			int intMemNo = Integer.parseInt(memNo);
			String expHOHEmailValOnUi = "Email: "+expHOHEmail;
		
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateEmailForHOHUnderContactInfoTab(intMemNo, expHOHEmailValOnUi);
		}
	}
	
	/**@author akumari4
	 *  From Review Application Page, Under Contact Info Tab, Validate Phone For HOH
	 	| MemNo  | Phone Number |
	 	|   1    | (857) 555-1234 - HOME    |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Contact Info Tab, Validate Phone For HOH$")
	public void validatePhoneForHOHUnderContactInfoTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			String memNo  = scenarioData.get(rowIndex).get(0);
			String expHOHPhone  = scenarioData.get(rowIndex).get(1);
			int intMemNo = Integer.parseInt(memNo);
			String expHOHPhoneValOnUi = "Phone: "+expHOHPhone;
		
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validatePhoneForHOHUnderContactInfoTab(intMemNo, expHOHPhoneValOnUi);
		}
	}
	
	@When("^From Review Application Page, Under Family HH Tab, Validate SSN Is Masked For All Members$")
	public void validateSSNIsMaskedUnderFamilyHHTab() throws Exception {
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.takeScreenShot();
		
		for(int mCounter=0; mCounter<memCount; mCounter++){
			reviewApplicationPagePage.validateSSNIsMaskedUnderFamilyHHTab(mCounter+1);
		}
		
	}
	
	/**
	 * @author vkuma212
	 * 
	 * From Review Application Page, Under Family HH Tab, Validate Applying For Coverage
	 	| MemNo  | ApplyingForCoverage |
	 	|   1    |   Yes               |
	 	|   2    |   No                |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, Validate Applying For Coverage$")
	public void validateApplyingForCoverageUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String applyingForCovrg = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String applyingForCovrgValOnUi = "Applying for coverage: "+applyingForCovrg;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateApplyingForCoverageForMemberUnderFamilyHHTab(memNo, applyingForCovrgValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Family HH Tab, Validate Address
	 	| MemNo  | Household Address |
	 	|   1    |  HOMEADDR, 123, HCITY, MA, 01002 |
	 	|   2    |  Same as primary applicant |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, Validate Address$")
	public void validateAddressUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String address = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String addressValOnUi = "Address: "+address;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateAddressForMemberUnderFamilyHHTab(memNo, addressValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Family HH Tab, For Member "1", Validate DOB With Age As "30"
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, For Member \"(.*?)\", Validate DOB With Age As \"(.*?)\"$")
	public void validateDOBUnderFamilyHHTab(String memNo,String age) throws Exception{
		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, age);
		String dobValOnUI = "Date of Birth: "+dob;
		
		int memIndex = Integer.parseInt(memNo)-1;
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.validateDOBForMemberUnderFamilyHHTab(memIndex, dobValOnUI);
		}
	
	/**@author akumari4
	 * From Review Application Page, Under Family HH Tab, Validate Citizenship
	 	| MemNo  | Citizenship |
	 	|   1    | Yes |
	 	|   2    | No  |
	 	|   3    | No  |
	 	|   4    | Yes |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, Validate Citizenship$")
	public void validateCitizenshipUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String citizenship = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String citizenshipValOnUi = "Citizenship: "+citizenship;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateCitizenshipForMemberUnderFamilyHHTab(memNo, citizenshipValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Family HH Tab, Validate AIAN Status
	 	| MemNo  | AIAN Status |
	 	|   1    | No |
	 	|   2    | No  |
	 	|   3    | No  |
	 	|   4    | No |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, Validate AIAN Status$")
	public void validateAIANUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String aian = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String aianValOnUi = "American Indian/Alaska Native:"+aian;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateAIANForMemberUnderFamilyHHTab(memNo, aianValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Family HH Tab, Validate Immigration Status
	 	| MemNo  | Immigration Status |
	 	|   2    | Reentry Permit (I-327) |
	 	|   3    | Reentry Permit (I-327)  |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, Validate Immigration Status$")
	public void validateImmigStatusUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String immigStatus = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String immigStatusValOnUi = "Immigration status: "+immigStatus;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateImmigStatusForMemberUnderFamilyHHTab(memNo, immigStatusValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Family HH Tab, Validate Reasonable Accommodation Status
	 	| MemNo | Reasonable Accommodation |
	 	|  1    |     No |
	 	|  2    |     No  |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, Validate Reasonable Accommodation Status$")
	public void validateReasonableAccomStatusUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String accommodationStatus = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String accommodationStatusValOnUi = "Reasonable Accommodations: "+accommodationStatus;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateReasonAccomodationForMemberUnderFamilyHHTab(memNo, accommodationStatusValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Family HH Tab, Validate Special Condition Status
	 	| MemNo | Special Condition |
	 	|  1    |     None |
	 	|  2    |     None |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, Validate Special Condition Status$")
	public void validateSpecialConditionStatusUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String specialConditionStatus = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String specialConditionStatusValOnUi = "Condition(s): "+specialConditionStatus;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateSpecialConditionForMemberUnderFamilyHHTab(memNo, specialConditionStatusValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Family HH Tab, Validate Accommodation Status
	 	| MemNo | Accommodation |
	 	|  1    |     None |
	 	|  2    |     None |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, Validate Accommodation Status$")
	public void validateAccommodationStatusUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String accomodationStatus = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String accomodationStatusValOnUi = "Accommodation(s): "+accomodationStatus;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateAccomodationForMemberUnderFamilyHHTab(memNo, accomodationStatusValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Family HH Tab, Validate Intend To Reside Status
	 	| MemNo | Intend To Reside |
	 	|  1    |     Yes |
	 	|  2    |     Yes |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, Validate Intend To Reside Status$")
	public void validateIntendToResideStatusUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String intendToResideStatus = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String intendToResideStatusValOnUi = "Intend To Reside: "+intendToResideStatus;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateIntendToResideForMemberUnderFamilyHHTab(memNo, intendToResideStatusValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Family HH Tab, Validate Incarcerated Status
	 	| MemNo | Incarcerated |
	 	|  1    |     Yes |
	 	|  2    |     No |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family HH Tab, Validate Incarcerated Status$")
	public void validateIncarceratedStatusUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String incarceratedStatus = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String incarceratedStatusValOnUi = "Incarcerated: "+incarceratedStatus;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateIncarceratedStatusForMemberUnderFamilyHHTab(memNo, incarceratedStatusValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Tax Filing Status Tab, Validate Filing Status
	 	| MemNo | Filing Status |
	 	|  1    |  Tax Filer |
	 	|  2    |  Tax Filer |
	 	|  3    |  Tax Dependent |
	 	|  4    |  Tax Dependent |
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Tax Filing Status Tab, Validate Filing Status$")
	public void validateTaxFilingStatusUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String taxFilingStatus = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String taxFilingStatusValOnUi = "Status: "+taxFilingStatus;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateFilingStatusForMemberUnderFamilyHHTab(memNo, taxFilingStatusValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Tax Filing Status Tab, Validate Filed taxes and reconciled all past APTCs
	 	| MemNo | Taxes & APTC |
	 	|  1    |  N/A |
	 	|  2    |  N/A |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Tax Filing Status Tab, Validate Filed taxes and reconciled all past APTCs$")
	public void validateFiledTaxesAndAPTCUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String filedTaxesAndAPTCStatus = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String filedTaxesAndAPTCStatusValOnUi = "Filed taxes and reconciled all past APTCs?: "+filedTaxesAndAPTCStatus;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateFiledTaxesAndAPTCForMemberUnderFamilyHHTab(memNo, filedTaxesAndAPTCStatusValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Tax Filing Status Tab, Validate Attestation Date
	 	| MemNo | Attestation Date |
	 	|  1    |  N/A |
	 	|  2    |  N/A |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Tax Filing Status Tab, Validate Attestation Date$")
	public void validateAttestationDateUnderFamilyHHTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String attestationDate = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String attestationDateValOnUi = "Attestation Date: "+attestationDate;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateAttestationDateForMemberUnderFamilyHHTab(memNo, attestationDateValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Family Income Tab, Validate Monthly Capital Gain Amount
	 	| MemNo | Capital_Gain_Amount_Monthly 	|
	 	|  1    |  1000							|
	 	|  2    |  122.23						|
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Monthly Capital Gain Amount$")
	public void validateCapitalGainIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expCapitalGain = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expCapitalGainOnUI = "Income Type: Capital Gains $"+expCapitalGain+"/ Monthly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			//reviewApplicationPagePage.validateCapitalGainIncomeForMemberUnderFamilyIncomeTab(memIndex, expCapitalGainOnUI);
		}
	}
	
	/**@author vverma25
	 * From Review Application Page, Under Family Income Tab, Validate Yearly Alimony Received Amount
	 	| MemNo | Alimony_Received_Amount_Yearly |
	 	|  1    |  100							|
	 	|  2    |  100							|
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Yearly Alimony Received Amount$")
	public void validateAlimonyReceivedIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expAlimonyReceived = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expAlimonyReceivedOnUI = "Income Type: Alimony Received $"+expAlimonyReceived+"/ Yearly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);		
			//reviewApplicationPagePage.validateAlimonyIncomeForMemberUnderFamilyIncomeTab(memIndex, expAlimonyReceivedOnUI);
		}
	}
	
	
	/**@author vverma25
	 * From Review Application Page, Under Family Income Tab, Validate Yearly Farming Or Fishing Amount
	 	| MemNo | Farming_Or_Fishing_Amount_Yearly |
	 	|  1    |  100							|
	 	|  2    |  100							|
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Yearly Farming Or Fishing Amount$")
	public void validateFarmingOrFishingIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expFarmingOrFishing = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expFarmingOrFishingOnUI = "Income Type: Farming or Fishing Income $"+expFarmingOrFishing+"/ Yearly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			//reviewApplicationPagePage.validateFarmingOrFishingIncomeForMemberUnderFamilyIncomeTab(memIndex, expFarmingOrFishingOnUI);
		}
	}
	
	/**@author vverma25
	 * From Review Application Page, Under Family Income Tab, Validate Yearly Interest Dividends Amount
	 	| MemNo | Interest_Dividends_Amount_Yearly |
	 	|  1    |  100							|
	 	|  2    |  100							|
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Yearly Interest Dividends Amount$")
	public void validateInterestDividendsIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expInterestDividends = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expInterestDividendsOnUI = "Income Type: Interest, Dividends, or Other Investment Income $"+expInterestDividends+"/ Yearly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			//reviewApplicationPagePage.validateInterestDividendsIncomeForMemberUnderFamilyIncomeTab(memIndex, expInterestDividendsOnUI);
		}
	}
	
	/**@author vverma25
	 * From Review Application Page, Under Family Income Tab, Validate Yearly Job Income Amount
	 	| MemNo | Job_Income_Amount_Yearly |
	 	|  1    |  3000					   |
	 	|  2    |  4000					   |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Yearly Job Income Amount$")
	public void validateJobIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expJobIncome = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expJobIncomeOnUI = "Income Type: Job (Optum) - $"+expJobIncome+"/ Yearly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			//reviewApplicationPagePage.validateJobIncomeForMemberUnderFamilyIncomeTab(memIndex, expJobIncomeOnUI);
		}
	}
	
	/**@author vverma25
	 * From Review Application Page, Under Family Income Tab, Validate Yearly Other Income Amount
	 	| MemNo | Other_Income_Amount_Yearly |
	 	|  1    |  1000					   |
	 	|  2    |  1000					   |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Yearly Other Income Amount$")
	public void validateOtherIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expOtherIncome = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expOtherIncomeOnUI = "Income Type: Other Income (Canceled Debts) - $"+expOtherIncome+"/ Yearly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			//reviewApplicationPagePage.validateOtherIncomeForMemberUnderFamilyIncomeTab(memIndex, expOtherIncomeOnUI);
		}
	}
	
	/**@author vverma25
	 * From Review Application Page, Under Family Income Tab, Validate Yearly Rental Royalty Income Amount
	 	| MemNo | Rental_Royalty_Income_Amount_Yearly |
	 	|  1    |  1000					   |
	 	|  2    |  1000					   |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Yearly Rental Royalty Income Amount$")
	public void validateRentalRoyaltyIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expRentalRoyalty = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expRentalRoyaltyOnUI = "Income Type: Rental or Royalty Income $"+expRentalRoyalty+"/ Yearly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			//reviewApplicationPagePage.validateRentalRoyaltyIncomeForMemberUnderFamilyIncomeTab(memIndex, expRentalRoyaltyOnUI);
		}
	}
	
	/**@author vverma25
	 * From Review Application Page, Under Family Income Tab, Validate Yearly Retirement Income Amount
	 	| MemNo | Retirement_Income_Amount_Yearly |
	 	|  1    |  120					   |
	 	|  2    |  100					   |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Yearly Retirement Income Amount$")
	public void validateRetirementIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expRetirement = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expRetirementOnUI = "Income Type: Retirement or Pension $"+expRetirement+"/ Yearly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			//reviewApplicationPagePage.validateRetirementIncomeForMemberUnderFamilyIncomeTab(memIndex, expRetirementOnUI );
		}
	}
	
	/**@author vverma25
	 * From Review Application Page, Under Family Income Tab, Validate Monthly Self Employment Income Amount
	 	| MemNo | SelfEmployment_Amount_Monthly|
	 	|  1    |  200					   |
	 	|  2    |  100					   |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Monthly Self Employment Income Amount$")
	public void validateSelfEmploymentIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expSelfEmployment = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expSelfEmploymentOnUI = "Income Type: Self-Employment $"+expSelfEmployment+"/ Monthly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			//reviewApplicationPagePage.validateSelfEmploymentIncomeForMemberUnderFamilyIncomeTab(memIndex, expSelfEmploymentOnUI);
		}
	}
	
	
	/**@author vverma25
	 * From Review Application Page, Under Family Income Tab, Validate Yearly SSB Income Amount
	 	| MemNo | SSB_Amount_Yearly |
	 	|  1    |  150				|
	 	|  2    |  100			    |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Yearly SSB Income Amount$")
	public void validateSSBIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expSSBIncome = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expSSBIncomeOnUI = "Income Type: Social Security Benefits $"+expSSBIncome+"/ Yearly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			//reviewApplicationPagePage.validateSSBIncomeForMemberUnderFamilyIncomeTab(memIndex, expSSBIncomeOnUI);
		}
	}
	
	/**@author vverma25
	 * From Review Application Page, Under Family Income Tab, Validate Yearly Unemployment Income Amount
	 	| MemNo | Unemployment_Amount_Yearly |
	 	|  1    |  200				|
	 	|  2    |  100			    |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Family Income Tab, Validate Yearly Unemployment Income Amount$")
	public void validateUnemploymentIncomeForMemberUnderFamilyIncomeTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String expUnemployment = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String expUnemploymentOnUI = "Income Type: Unemployment $"+expUnemployment+"/ Yearly";
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			//reviewApplicationPagePage.validateUnemploymentIncomeForMemberUnderFamilyIncomeTab(memIndex, expUnemploymentOnUI);
		}
	}
	/**@author akumari4
	 * From Review Application Page, Under Additional Information Tab, Validate Has MEC Status
	 	| MemNo | Has MEC |
	 	|  1    |  No |
	 	|  2    |  Yes |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Additional Information Tab, Validate Has MEC Status$")
	public void validateHasMECUnderAdditionalInfoTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String hasMEC = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String hasMECstatusValOnUi = "Has Minimum Essential Coverage (MEC): "+hasMEC;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateHasMECForMemberUnderAdditionalInfoTab(memIndex, hasMECstatusValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Additional Information Tab, Validate Enrolls in ESI Status
	 	| MemNo | Enrolls in ESI |
	 	|  1    |  No |
	 	|  2    |  Yes |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Additional Information Tab, Validate Enrolls in ESI Status$")
	public void validateEnrollsInESIUnderAdditionalInfoTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String enrollsInESI = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String enrollsInESIstatusValOnUi = "Has Option to Enroll in Employer Health Coverage: "+enrollsInESI;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateEnrollsInESICoverageForMemberUnderAdditionalInfoTab(memIndex, enrollsInESIstatusValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under Additional Information Tab, Validate Has Affordable ESI Status
	 	| MemNo | Has Affordable ESI |
	 	|  1    |  No |
	 	|  2    |  Yes |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under Additional Information Tab, Validate Has Affordable ESI Status$")
	public void validateHasESICovrgUnderAdditionalInfoTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String hasAffordableESI = scenarioData.get(rowIndex).get(1).trim();
					
			int memIndex = Integer.parseInt(strMemNo)-1;
			String hasAffordableESIValOnUi = "Has Affordable Employer Sponsored Insurance(ESI): "+hasAffordableESI;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateHasAffordableESIForMemberUnderAdditionalInfoTab(memIndex, hasAffordableESIValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under MEC Used in PD Tab, Validate Has Federal MEC
	 	| MemNo | Has Federal MEC |
	 	|  1    |  No |
	 	|  2    |  No |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under MEC Used in PD Tab, Validate Has Federal MEC$")
	public void validateHasFederalMECUnderAdditionalInfoTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String hasFederalMEC = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String hasFederalMECValOnUi = "Has Federal MEC: "+hasFederalMEC;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateHasFederalMECForMemberUnderMECPDTab(memNo, hasFederalMECValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under MEC Used in PD Tab, Validate Federal MEC Type
	 	| MemNo | Federal MEC Type |
	 	|  1    |  No |
	 	|  2    |  No |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under MEC Used in PD Tab, Validate Federal MEC Type$")
	public void validateFederalMECTypeUnderAdditionalInfoTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String federalMECLabel = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String federalMECTypeValOnUi = "Federal MEC Type: "+federalMECLabel;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateMECTypeForMemberUnderMECPDTab(memNo, federalMECTypeValOnUi);
		}
	}
	
	/**@author akumari4
	 * From Review Application Page, Under MEC Used in PD Tab, Validate Has MMIS MEC
	 	| MemNo | Has MMIS MEC |
	 	|  1    |  No |
	 	|  2    |  No |
	 	
	 * @param table
	 * @throws Exception
	 */
	@When("^From Review Application Page, Under MEC Used in PD Tab, Validate Has MMIS MEC$")
	public void validatehasMMISMECTypeUnderAdditionalInfoTab(DataTable table) throws Exception{
		
		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		
		for(int rowIndex=1;rowIndex<rowCount;rowIndex++){
			
			String strMemNo = scenarioData.get(rowIndex).get(0);
			String hasMMISMECLabel = scenarioData.get(rowIndex).get(1).trim();
					
			int memNo = Integer.parseInt(strMemNo);
			String hasMMISMECValOnUi = "Has MMIS MEC: "+hasMMISMECLabel;
			
			ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
			reviewApplicationPagePage.validateHasMMISMECForMemberUnderMECPDTab(memNo, hasMMISMECValOnUi);
		}
	}
	
	@When("^From Review Application Page, Select App Source As Others And Click On Save And Continue$")
	public void SelectAppSourceAsOtherAndClickOnSaveAndContinueBtn() throws Exception {
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.SelectAppSourceAsOtherAndClickOnSaveAndContinueBtn();
	}
	
	
	

}
