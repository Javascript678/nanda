package stepdefs.reviewAndSign;
import cucumber.api.java.en.When;
import pages.eligibilityResult.CurrentYearEligibilityResultPage;
import pages.reviewAndSign.RightsAndResponsibilityPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class RightAndResponsibilityPageSteps extends SuperStepDef{
	
	public RightAndResponsibilityPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^From Right And Responsibility Page, Complete Default Details$")
	public void completeRightsAndResponsibilityWithDefaultDetails() throws Exception {
		
		RightsAndResponsibilityPage rightsAndResponsibilityPage = new RightsAndResponsibilityPage(driver, testCaseId);
		rightsAndResponsibilityPage.completeRightsAndResponsibilityWithDefaultDetails();
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.waitForPageLoaded();
	}
	
	/*@When("^From Right And Responsibility Page, Provide Reason For Changing The Application Type$")
	public void selectReasonForChangingTheApplicationType() throws Exception {		
		RightsAndResponsibilityPage rightsAndResponsibilityPage = new RightsAndResponsibilityPage(driver, testCaseId);
		rightsAndResponsibilityPage.selectReasonForChangingTheAppType();
	}*/
	
	@When("^From Right And Responsibility Page, Complete Default Details For Responsible Party$")
	public void completeRightsAndResponsibilityWithDefaultDetailsResponsibleParty() throws Exception {
		
		RightsAndResponsibilityPage rightsAndResponsibilityPage = new RightsAndResponsibilityPage(driver, testCaseId);
		rightsAndResponsibilityPage.completeRightsAndResponsibilityWithDefaultDetailsResponsible();;
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.waitForPageLoaded();
	}
	
	//Considering No Change is there in the application, 
	//error message will appear at top and we simply have to click on submit again
	@When("^From Right And Responsibility Page, Complete Default Details During RAC Considering No Change Is Made$")
	public void completeRightsAndResponsibilityWithDefaultDetails_DuringRACWithNoChange() throws Exception {
		
		RightsAndResponsibilityPage rightsAndResponsibilityPage = new RightsAndResponsibilityPage(driver, testCaseId);
		rightsAndResponsibilityPage.completeRightsAndResponsibilityWithDefaultDetails();
		rightsAndResponsibilityPage.clickOnSaveAndContinueBtn();
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.waitForPageLoaded();
	}
	
	/**
	 * 
	 * From Right And Responsibility Page, Complete Details With Applying For Vote As "TRUE"
	 * 
	 */
	
	@When("^From Right And Responsibility Page, Complete Details With Applying For Vote As \"(.*?)\"$")
	public void completeRightsAndResponsibilityWithDefaultDetails(String applyingForVote) throws Exception {
		
		Boolean bApplyingForVote = applyingForVote.equalsIgnoreCase("TRUE")?true:false;
		
		RightsAndResponsibilityPage rightsAndResponsibilityPage = new RightsAndResponsibilityPage(driver, testCaseId);
		rightsAndResponsibilityPage.completeRightsAndResponsibilityWithDetails(bApplyingForVote);
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.waitForPageLoaded();
	}
	
	//Amrita
	@When("^From Right And Responsibility Page, Complete Details for Supressing Notices With Applying For Vote As \"(.*?)\"$")
	public void completeRightsAndResponsibilityWithSupressNoticeandVotingasYes(String applyingForVote) throws Exception {
		
		Boolean bApplyingForVote = applyingForVote.equalsIgnoreCase("TRUE")?true:false;
		
		RightsAndResponsibilityPage rightsAndResponsibilityPage = new RightsAndResponsibilityPage(driver, testCaseId);
		rightsAndResponsibilityPage.completeRightsAndResponsibilityWithSupressNotice(bApplyingForVote);
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.waitForPageLoaded();
	}
	
	@When("^From Right And Responsibility Page, Enter Details For Under 18 HOH$")
	public void completeRightsAndResponsibilityWithDetailsUndr18HoH() throws Exception {
		String firstName= globalData.get("ReposiblePartyFirstName");
		String lastName = globalData.get("ReposiblePartyLastName");
		String relationship = globalData.get("ReposiblePartyRelationShip");
		String dob = globalData.get("ReposiblePartyDateOfBirth");
		String hstreetAddress = globalData.get("ReposiblePartyStreetAddress1");
		String hcity  = globalData.get("ReposiblePartyCity");
		String zipCode = globalData.get("ReposiblePartyZIp");
		String country = globalData.get("ReposiblePartyCounty");
		String phoneNo = globalData.get("ReposiblePartyPhone1");
	
		RightsAndResponsibilityPage rightsAndResponsibilityPage1 = new RightsAndResponsibilityPage(driver, testCaseId);
		rightsAndResponsibilityPage1.completeRightsAndResponsibilityWithUnder18HoH(firstName,lastName,relationship, dob,
		hstreetAddress,  hcity ,  zipCode ,  country , phoneNo );
	
	
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.waitForPageLoaded();
	}
	
	@When("^From Right And Responsibility Page, Enter Details For Under 18 HOH And Validation of Invalid SSN Error$")
	public void completeRightsAndResponsibilityWithDetailsUndr18HoHSSNValidation() throws Exception {
		String firstName= globalData.get("ReposiblePartyFirstName");
		String lastName = globalData.get("ReposiblePartyLastName");
		String relationship = globalData.get("ReposiblePartyRelationShip");
		String dob = globalData.get("ReposiblePartyDateOfBirth");
		String hstreetAddress = globalData.get("ReposiblePartyStreetAddress1");
		String hcity  = globalData.get("ReposiblePartyCity");
		String zipCode = globalData.get("ReposiblePartyZIp");
		String country = globalData.get("ReposiblePartyCounty");
		String phoneNo = globalData.get("ReposiblePartyPhone1");
	
		RightsAndResponsibilityPage rightsAndResponsibilityPage1 = new RightsAndResponsibilityPage(driver, testCaseId);
		rightsAndResponsibilityPage1.completeRightsAndResponsibilityWithUnder18HoHInvalidSSN(firstName,lastName,relationship, dob,
		hstreetAddress,  hcity ,  zipCode ,  country , phoneNo );
	
	
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.waitForPageLoaded();
	}
	
	@When("^From Right And Responsibility Page, Enter Details For Under 18 HOH Who Is Emancipated$")
	public void completeRightsAndResponsibilityWithDetailsUndr18HoHWhoIsEmancipated() throws Exception {
		RightsAndResponsibilityPage rightsAndResponsibilityPage1 = new RightsAndResponsibilityPage(driver, testCaseId);
		rightsAndResponsibilityPage1.completeRightsAndResponsibilityWithDetailsUndr18HoHWhoIsEmancipated();	
	
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.waitForPageLoaded();
	}
	
	@When("^From Right And Responsibility Page, Validate Error Message$")
    public void vaidateErrorMsg() throws Exception {
          
        RightsAndResponsibilityPage rightsAndResponsibilityPage = new RightsAndResponsibilityPage(driver, testCaseId);
        rightsAndResponsibilityPage.validateErrorMessage(); 
          
    }

	
}
