package stepdefs.reviewAndSign;
import cucumber.api.java.en.When;
import pages.eligibilityResult.CurrentYearEligibilityResultPage;
import pages.reviewAndSign.ReviewAndSignPage;
import pages.reviewAndSign.ReviewApplicationPage;
import pages.reviewAndSign.RightsAndResponsibilityPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ReviewAndSignPageSteps extends SuperStepDef{
	
	public ReviewAndSignPageSteps(Hook hook){
		super(hook);
	}
		
	@When("^EVPD, Complete Review And Sign Details$")
	public void completeReviewAndSignDetails() throws Exception {
		
		ReviewAndSignPage reviewAndSignPagePage = new pages.reviewAndSign.ReviewAndSignPage(driver, testCaseId);
		reviewAndSignPagePage.pageLoadThenClickOnSaveAndContinueBtn();
		
		ReviewApplicationPage reviewApplicationPagePage = new ReviewApplicationPage(driver, testCaseId);
		reviewApplicationPagePage.pageLoadThenClickOnSaveAndContinueBtn();
		
		RightsAndResponsibilityPage rightsAndResponsibilityPage = new RightsAndResponsibilityPage(driver, testCaseId);
		rightsAndResponsibilityPage.completeRightsAndResponsibility(evpdData.memsData.get(0), evpdData.rpData);
		
		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.waitForPageLoaded();
	}
	
	@When("^From Review And Sign Page, Click On Save And Continue$")
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		
		ReviewAndSignPage reviewAndSignPagePage = new pages.reviewAndSign.ReviewAndSignPage(driver, testCaseId);
		reviewAndSignPagePage.pageLoadThenClickOnSaveAndContinueBtn();
	}
	

}
