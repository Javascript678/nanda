package stepdefs.shopping;

import java.util.List;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import pages.shopping.ComparePlansPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ComparePlansPageSteps extends SuperStepDef {

	public ComparePlansPageSteps(Hook hook) {
		super(hook);
	}
	
	//#################### Click ON TAB STARTS ################################################
	//
	
	@And("^From Compare Plans Page, Click On Plan Details Tab$")
	public void completeDetails() throws Exception{
		ComparePlansPage comparePlansPage = new ComparePlansPage(driver, testCaseId);
		comparePlansPage.clickOnPlanDetailsTab();
	}
	
	
	//TODO: Do for other Tabs
	//
	//#################### Click ON TAB END ################################################
	
	//#################### Function Under Plan Details Tab STARTS ################################################
	//
	
	/**
	 * @author Brajesh
	 * From Compare Plans Page, Under Plan Details Tab, Validate Max OOP For MedDrug IndividualPlanNameForPlan
		| RAC_Types 		|
		| UPDATE_INCOME 	|
	 */

	@And("^From Compare Plans Page, Under Plan Details Tab, Validate Max OOP For MedDrug IndividualPlanNameForPlan$")
	public void completeDetails(DataTable table) throws Exception{
		List<List<String>> scenarioData = table.raw();
		String expAbc  = scenarioData.get(1).get(0);

		ComparePlansPage comparePlansPage = new ComparePlansPage(driver, testCaseId);
		comparePlansPage.validateMaxOOP_For_MedDrugIndividualPlanNameForPlan_UnderPlanDetailsTab(expAbc);
	}
	
	//
	//#################### Function Under Plan Details Tab ENDS ################################################

}
