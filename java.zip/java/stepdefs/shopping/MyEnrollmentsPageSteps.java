package stepdefs.shopping;

import cucumber.api.java.en.Given;
import pages.shopping.MyEnrollmentPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
/**
 * 
 * @author Paul Pinho
 *
 */
public class MyEnrollmentsPageSteps extends SuperStepDef{
	
	public MyEnrollmentsPageSteps(Hook hook){
		super(hook);
	}
	
	//Ritu
	@Given("^From My Enrollments Page, Take Screenshot$")
    public void takeScreenshot() throws Exception{
          MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver, testCaseId);
          myEnrollmentPage.takeScreenshot();
    }

	
	/**Paul
	 * From My Enrollments Page, Click On Make Payment Button
	 */
	
	@Given("^From My Enrollments Page, Click On Make Payment Button$")
	public void checkMakePaymentButton() throws Exception {
		MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver, testCaseId);
		myEnrollmentPage.clickOnMakeAPaymentButton();
	}
	
	/**Shailza
	 * From My Enrollments Page, Click On Back Button
	 */
	
	@Given("^From My Enrolments Page, Click On Back Button$")
	public void clickBackButton() throws Exception {
		MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver, testCaseId);
		myEnrollmentPage.clickOnBackButton();
	}
	
	//Shailza
	
	/**
	 * From My Enrollments Page, Click On Account Dashboard Button
	 */
		
	@Given("^From My Enrollments Page, Click On Account Dashboard Button$")
	public void clickAccountDashboardButton() throws Exception {
			MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver, testCaseId);
			myEnrollmentPage.clickOnAccountDashboardutton();
	}
	
	
}
