package stepdefs.shopping;

import cucumber.api.java.en.Given;
import pages.shopping.ShopAndEnrollPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ShopAndEnrollmentPageSteps extends SuperStepDef {

	public ShopAndEnrollmentPageSteps(Hook hook) {
		super(hook);
	}

	
	/*
	 * @author vkuma212
	 *
	 *  From Shop And Enrollment Page, Click On Continue
	 */
	
	@Given("^From Shop And Enrollment Page, Click On Continue$")
	public void goToHealthPlanShopingPage() throws Exception {

		ShopAndEnrollPage shopAndEnrollPage = new ShopAndEnrollPage(driver, testCaseId);
		shopAndEnrollPage.pageLoadAndClickOnSaveAndContinue();

	}

}
