package stepdefs.shopping;

import java.util.List;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import pages.shopping.FindPrescriptionDrugsPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class FindPrescriptionDrugsPageSteps extends SuperStepDef {

	public FindPrescriptionDrugsPageSteps(Hook hook) {
		super(hook);
	}
	
	//Amrita
	@Given("^From Prescription & Drugs Page, Click on Continue Button$")
	public void clickContinue() throws Exception{
		FindPrescriptionDrugsPage prescriptionanddrugs = new FindPrescriptionDrugsPage(driver, testCaseId);
		prescriptionanddrugs.clickOnContinue();
	}
	
	@Given("^From Prescription & Drugs Page, Remove Drug From List$")
	public void clickRemove() throws Exception{
		FindPrescriptionDrugsPage prescriptionanddrugs = new FindPrescriptionDrugsPage(driver, testCaseId);
		prescriptionanddrugs.clickOnRemoveBtn();
	}
	
	@Given("^Verify PopUp is displayed on Continue Btn$")
	public void clickContinuePopUp() throws Exception{
		FindPrescriptionDrugsPage prescriptionanddrugs = new FindPrescriptionDrugsPage(driver, testCaseId);
		prescriptionanddrugs.clickOnContinue();
		prescriptionanddrugs.clickOnContinueWarningMsg();
	}
	
	@Given("^Click On No On PopUp is displayed on SkipThisStep Btn$")
	public void clickSkipPopUp() throws Exception{
		FindPrescriptionDrugsPage prescriptionanddrugs = new FindPrescriptionDrugsPage(driver, testCaseId);
		prescriptionanddrugs.clickOnSkipBtn();
		prescriptionanddrugs.clickOnSkipThisStepWarningMsg();
	}
	
	//Amrita
	@Given("^From Prescription & Drugs Page, Validate the UI Elements displayed$")
	public void validateUIElements() throws Exception {

		FindPrescriptionDrugsPage prescriptionanddrugs = new FindPrescriptionDrugsPage(driver, testCaseId);
		prescriptionanddrugs.validateUIElementsOnPrescriptionPage();
	}
	
	/**
	 * 
	 From Prescription & Drugs Page, Add Drug Names And Validate Success Message
	 |		DrugName	|
	 |		ECOZA			|
	 |		COZA			|
	 | 		NIKKI			|
	
	 * @param drugName
	 * @throws Exception
	 */
	
	@Given("^From Prescription & Drugs Page, Add Drug Names And Validate Success Message$")
	public void addDrugAndValidateMsg(DataTable table) throws Exception {

		List<List<String>> scenarioData = table.raw();
		int rowCount = scenarioData.size();
		FindPrescriptionDrugsPage prescriptionanddrugs = new FindPrescriptionDrugsPage(driver, testCaseId);
		
		for (int rowIndex = 1; rowIndex < rowCount; rowIndex++) 
		{
			String drugName = scenarioData.get(rowIndex).get(0);
			prescriptionanddrugs.addDrugsAndValMsg(drugName);
		}
		
	}
	
	
}