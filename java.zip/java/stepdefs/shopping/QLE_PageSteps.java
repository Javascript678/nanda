package stepdefs.shopping;

import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import pages.eligibilityResult.CurrentYearEligibilityResultPage;
import pages.shopping.QualifyingLifeEventPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class QLE_PageSteps extends SuperStepDef {

	public QLE_PageSteps(Hook hook) {
		super(hook);
	}
	
	/**@author akumari4
	 *  QUE 1
	 
	    From QLE Page, Select Lost Health Insurance For Member As FALSE
	
	 */
	@Given("^From QLE Page, Select Lost Health Insurance For Member As FALSE$")
	public void selectQLELostHeathInsuranceValue() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemLoseHIOrExpToLose(false);
				
	}
	
	
	/**@author akumari4
	 * QUE 2
	 
	   From QLE Page, Select Lost Health Insurance When Having MassHealth Previously As FALSE
	 

	 */
	@Given("^From QLE Page, Select Lost Health Insurance When Having MassHealth Previously As FALSE$")
	public void selectQLELostHeathInsuranceValueWithMHPreviously() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemLoseHIOrExpToLoseWithPrevMH(false);
				
	}
	
	/**@author akumari4
	 * QUE 3
	   
	   From QLE Page, Select Member Move To MA For Member As FALSE
	 
	 */
	@Given("^From QLE Page, Select Member Move To MA For Member As FALSE$")
	public void selectQLEMemMoveToMAValue() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemMoveToMA(false);
				
	}
	
	/**@author akumari4
	 * QUE 4
	   
	   From QLE Page, Select Dependant Status Change As FALSE
	 
	 
	 */
	@Given("^From QLE Page, Select Dependant Status Change As FALSE$")
	public void selectQLEDepStatusChangeValue() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemDependentStatusGotChanged(false);
				
	}
	
	/**@author akumari4
	 *  QUE 5
	 
	   From QLE Page, Select Dependant Added Due To Birth Value As FALSE

	 */
	@Given("^From QLE Page, Select Dependant Added Due To Birth Value As FALSE$")
	public void selectQLEDepAddDueToBirth() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemAddedDueToBirth(false);
				
	}
	
	/**@author akumari4
	 * QUE 6 
	   From QLE Page, Select Dependant Added Due To Foster Care Value As FALSE

	 */
	@Given("^From QLE Page, Select Dependant Added Due To Foster Care Value As FALSE$")
	public void selectQLEDepAddDueToFosterCare() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemAddedDueToFosterCare(false);
				
	}
	
	/**@author akumari4
	 *  QUE 7
	 
	   From QLE Page, Select Dependant Change Due To Marriage Value As FALSE

	 */
	@Given("^From QLE Page, Select Dependant Change Due To Marriage Value As FALSE$")
	public void selectQLEDepChngDueToMarriage() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemMarriageStatusGotChanged(false);
				
	}
	
	/**@author akumari4
	 *  QUE 8
	 
	   From QLE Page, Select Member Immigration Change Value As FALSE
	 
	 */
	@Given("^From QLE Page, Select Member Immigration Change Value As FALSE$")
	public void selectQLEMemImmigChange() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemImmStatusGotChanged(false);
				
	}
	
	/**@author akumari4
	 *  QUE 9
	 
	   From QLE Page, Select Member Address Change Value As FALSE

	 */
	@Given("^From QLE Page, Select Member Address Change Value As FALSE$")
	public void selectQLEMemAddressChange() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemAddressGotChanged(false);
				
	}
	
	/**@author akumari4
	 *  QUE 10
	 
	   From QLE Page, Select Member Incarceration Status Change Value As FALSE

	 */
	@Given("^From QLE Page, Select Member Incarceration Status Change Value As FALSE$")
	public void selectQLEMemIncarcerationChange() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemIncarcerationStatusGotChanged(false);
				
	}
	
	/**@author akumari4
	 * QUE 11
	  
	   From QLE Page, Select Member Domestic Abuse Status Change Value As FALSE

	 */
	@Given("^From QLE Page, Select Member Domestic Abuse Status Change Value As FALSE$")
	public void selectQLEMemAbuseStatusChange() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemDomesticAbuseStatusGotChanged(false);
				
	}
	
	/**@author akumari4
	 * 

	 From QLE Page, Enter Lost Health Insurance Details For Member "2"
	 
	 */
	@Given("^From QLE Page, Enter Lost Health Insurance Details For Member \"(.*?)\"$")
	public void completeQLELostHeathInsuranceDetails(String memNo) throws Exception{
		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String coverageEndDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:30");
		int memIndex = Integer.parseInt(memNo)-1;
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.enterMemberHIChangeDetail(memIndex, coverageEndDate);
				
	}
	
	/**
	 * @author akumari4

	 From QLE Page, Select Move to MA Details For Member "1"
	 
	 */
	@Given("^From QLE Page, Select Move to MA Details For Member \"(.*?)\"$")
	public void completeQLEMoveToMADetails(String memNo) throws Exception{
		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String moveToMAdate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:10");
		int memIndex = Integer.parseInt(memNo)-1;
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.enterMemberMoveToMADetail(memIndex, moveToMAdate);
				
	}
	
	/**
	 * @author akumari4

	 From QLE Page, Select Move to MA Details For Member "1"
	 
	 */
	@Given("^From QLE Page, Select Move to MA Details For Member \"(.*?)\" With Previously Having MH$")
	public void completeQLEMoveToMAWithPrevMH(String memNo) throws Exception{
		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String moveToMAdate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:10");
		int memIndex = Integer.parseInt(memNo)-1;
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.enterMemberMoveToMAWithPrevMH(memIndex, moveToMAdate);
				
	}
	
	/**
	 * @author akumari4

	 From QLE Page,  Select Released from Prison Details For Member "1"
	 
	 */
	@Given("^From QLE Page, Select Released from Prison Details For Member \"(.*?)\"$")
	public void completeQLEReleasedFromPrisonDetails(String memNo) throws Exception{
		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String releazedFromJailDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:10");
		int memIndex = Integer.parseInt(memNo)-1;
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.enterMemberIncarcerationChangeDetail(memIndex, releazedFromJailDate);
		}
	
	
	/**@author akumari4
	 * 
	   From QLE Page, Select Member Domestic Abuse Status Change Value As TRUE

	 */
	@Given("^ From QLE Page, Select Member Domestic Abuse Status Change Value As TRUE$")
	public void completeQLEDomesticAbuseDetails() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.enterMemberDomesticAbuseDetails();
		}
	
	
	
	/**
	 * @author Ritika

	 From QLE Page, Select Gain Or Become Dependent For Member "1"
	 
	 */
	@Given("^From QLE Page, Select Gain Or Become Dependent For Member \"(.*?)\"$")
	public void completeQLEDependentChangeDetails(String memNo) throws Exception{
		int memIndex = Integer.parseInt(memNo) - 1;
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		
		String fName = elg_MemberTable.getFirstNameUsingUserProfileRefId(userProfileRefId, memIndex);
		String lName = elg_MemberTable.getLastNameUsingUserProfileRefId(userProfileRefId, memIndex);
		
		String appDate = TestData.getTempTestData("AppDate", featureFileName);
		String fosterDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:10");
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.selectIfAnyMemLoseHIOrExpToLose(false);
		qualifyingLifeEventPage.enterMemberDependentChange(fName, lName, fosterDate);
		qualifyingLifeEventPage.selectIfAnyMemAddressGotChanged(false);
		qualifyingLifeEventPage.selectIfAnyMemIncarcerationStatusGotChanged(false);
		qualifyingLifeEventPage.selectIfAnyMemDomesticAbuseStatusGotChanged(false);
	}
	
	@Given("^From QLE Page, Take Screenshot$")
	public void takeScreenshot() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.takeScreenshot();
		
	}
	
	
	@Given("^From QLE Page, Click On Save And Continue$")
	public void clickOnSaveAndContinueBtn() throws Exception{
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		qualifyingLifeEventPage.takeScreenshot();
		qualifyingLifeEventPage.clickOnSaveAndContinueBtn();

		CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
		currentYearEligibilityResultPage.waitForPageLoaded();
		
	}
	
	
}
