package stepdefs.shopping;

import cucumber.api.java.en.Given;
import pages.shopping.FindProviderAndFacilitiesPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class FindProviderAndFacilitiesPageSteps extends SuperStepDef {

	public FindProviderAndFacilitiesPageSteps(Hook hook) {
		super(hook);
	}
	
	//Amrita
	@Given("^From Provider & Facilities Page, Click on Continue Button$")
	public void clickContinue() throws Exception{
		FindProviderAndFacilitiesPage providerAndFacilitiesPage = new FindProviderAndFacilitiesPage(driver, testCaseId);
		providerAndFacilitiesPage.pageLoadAndClickOnContinue();
	}
	
	//Amrita
	@Given("^From Provider & Facilities Page, Search For Providers Using ZipCode \"(.*?)\"$")
	public void findProvider(String zipcode) throws Exception {

		FindProviderAndFacilitiesPage providerAndFacilitiesPage = new FindProviderAndFacilitiesPage(driver, testCaseId);
		providerAndFacilitiesPage.searchProviderUsingZipcode(zipcode);
	}
	
	//Amrita
		@Given("^From Provider & Facilities Page, Add \"(.*?)\" Providers From the Search List$")
		public void addProvider(int noOfProvidersToAdd) throws Exception {

			FindProviderAndFacilitiesPage providerAndFacilitiesPage = new FindProviderAndFacilitiesPage(driver, testCaseId);
			providerAndFacilitiesPage.addProvider(noOfProvidersToAdd);
		}
		//Amrita
				@Given("^From Provider & Facilities Page, Remove \"(.*?)\" Providers From the Search List$")
				public void removeProvider(int noOfProvidersToRemove) throws Exception {

					FindProviderAndFacilitiesPage providerAndFacilitiesPage = new FindProviderAndFacilitiesPage(driver, testCaseId);
					providerAndFacilitiesPage.deleteProvider(noOfProvidersToRemove);
				}
		//Amrita
		@Given("^From Provider & Facilities Page, Search For Facilities Using ZipCode \"(.*?)\"$")
		public void findFacility(String zipcode) throws Exception {

			FindProviderAndFacilitiesPage providerAndFacilitiesPage = new FindProviderAndFacilitiesPage(driver, testCaseId);
			providerAndFacilitiesPage.searchFacilityUsingZipcode(zipcode);
		}
		
		//Amrita
			@Given("^From Provider & Facilities Page, Add \"(.*?)\" Facilities From the Search List$")
			public void addFacilities(int noOfFacilitiesToAdd) throws Exception {

				FindProviderAndFacilitiesPage providerAndFacilitiesPage = new FindProviderAndFacilitiesPage(driver, testCaseId);
				providerAndFacilitiesPage.addFacility(noOfFacilitiesToAdd);
			}
			//Amrita
			@Given("^From Provider & Facilities Page, Remove \"(.*?)\" Facilities From the Search List$")
			public void removeFacilities(int noOfFacilitiesToRemove) throws Exception {

				FindProviderAndFacilitiesPage providerAndFacilitiesPage = new FindProviderAndFacilitiesPage(driver, testCaseId);
				providerAndFacilitiesPage.deleteFacility(noOfFacilitiesToRemove);
			}
	
		
}
