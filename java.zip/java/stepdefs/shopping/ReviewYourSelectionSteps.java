package stepdefs.shopping;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import pages.shopping.FindPrescriptionDrugsPage;
import pages.shopping.ReviewYourSelectionPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ReviewYourSelectionSteps extends SuperStepDef {

	public ReviewYourSelectionSteps(Hook hook) {
		super(hook);
	}
	

	@Given("^From Review Your Selection Page, Click on AddMoreDrug$")
	public void clickAddMoreDrug() throws Exception{
		ReviewYourSelectionPage reviewYourSelectionPage = new ReviewYourSelectionPage(driver, testCaseId);
		reviewYourSelectionPage.clickOnAddMoreDrugsBtn();
	}
	
	@Given("^From Review Your Selection Page, Click on ShowPlans$")
	public void clickShowPlans() throws Exception{
		ReviewYourSelectionPage reviewYourSelectionPage = new ReviewYourSelectionPage(driver, testCaseId);
		reviewYourSelectionPage.clickOnShowPlanBtn();
	}
	
	@Given("^From Review Your Selection Page, Remove Drug$")
	public void clickRemoveDrug() throws Exception{
		ReviewYourSelectionPage reviewYourSelectionPage = new ReviewYourSelectionPage(driver, testCaseId);
		reviewYourSelectionPage.clickOnDrugChkBx();
		reviewYourSelectionPage.clickOnRemoveBtn();
	}
	
	@Given("^From Review Your Selection Page, Click on SkipAndContinue And Click On No$")
	public void clickSkipAndConBtn() throws Exception{
		ReviewYourSelectionPage reviewYourSelectionPage = new ReviewYourSelectionPage(driver, testCaseId);
		reviewYourSelectionPage.clickOnSkipBtn();
		reviewYourSelectionPage.clickOnSkipThisStepWarningMsg();
	}
	
	

	
	
}