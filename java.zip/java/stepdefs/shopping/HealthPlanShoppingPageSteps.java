package stepdefs.shopping;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import pages.shopping.DentalPlanShopingPage;
import pages.shopping.EnrollPage;
import pages.shopping.FindAHealthOrDentalPlanPage;
import pages.shopping.HealthPlanShopingPage;
import pages.shopping.MyEnrollmentPage;
import pages.shopping.PlanFinderToolPage;
import pages.shopping.ReviewApplicationPage;
import pages.shopping.ReviewShoppingCartPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

import utils.TestData;

public class HealthPlanShoppingPageSteps extends SuperStepDef {

	public HealthPlanShoppingPageSteps(Hook hook) {
		super(hook);
	}

	/*
	 * @author abajpai3
	 *
	 * From Health Plan Shopping Page, Validate Member "2" Is Present In Shopping Group "1"
	 */
	
	@Given("^From Health Plan Shopping Page, Validate Member \"(.*?)\" Is Present In Shopping Group \"(.*?)\"$")
	public void validateGroupMembers(int memberNum, int gpNum) throws Exception {
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, memberNum - 1);
		
		HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
		healthPlanShopingPage.validateMembersInShoppingGroup(gpNum, name);
	}
	
	//Amrita
	@Given("^From Health Plan Shopping Page, Click On Find A Plan Button For Current Year For Shopping Group \"(.*?)\"$")
	public void clickFindPlanForCrntYear(int shpngGrpNum) throws Exception {
		HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
		healthPlanShopingPage.clickOnFindAPlanForShoppingGrp(shpngGrpNum);
	}
	
	/*
     * @author Ritu
        From Health Shopping Plan, Complete Change Shopping
        |   Group               |      HealthPlanName             |  DentalPlanName             |
        |   1                          |      Tufts Health Plan   |      Altus Dental       |
     */
     
     @Given("^From Health Shopping Plan, Complete Change Shopping$")
     public void completeChangeShoppingDetails2(DataTable table) throws Exception{
           List<List<String>> scenarioData = table.raw();
           String gpNo = scenarioData.get(1).get(0);
           int groupSize=Integer.parseInt(gpNo);
           
           String hltPlan =scenarioData.get(1).get(1).trim();
           String dtlPlan =scenarioData.get(1).get(2).trim(); 
     PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
     FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);
     MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver,testCaseId);

     HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
     DentalPlanShopingPage dentalPlanShopingPage = new DentalPlanShopingPage(driver, testCaseId);
     
     for(int i=0; i<groupSize; i++)
     {
           healthPlanShopingPage.clickOnFindAPlanForShoppingGrp(i+1);
           planFinderToolPage.pageLoadAndSkipPlanShopping();
           findAHealthOrDentalPlanPage.selectShoppingPlan(hltPlan);
           findAHealthOrDentalPlanPage.clickOnApplyBtn();
            findAHealthOrDentalPlanPage.findAHealthPlanPageLoadAndClickOnAddToCart(1);
           findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
           findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
           findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
     }
     healthPlanShopingPage.pageLoadAndClickOnContinueBtn();
     
     for(int i=0; i<groupSize; i++)
     {
           dentalPlanShopingPage.clickOnFindAPlanForShoppingGrp(i+1);
           planFinderToolPage.pageLoadAndSkipPlanShopping();
           findAHealthOrDentalPlanPage.selectShoppingPlan(dtlPlan);
           findAHealthOrDentalPlanPage.clickOnApplyBtn();
            findAHealthOrDentalPlanPage.findADentalPlanPageLoadAndClickOnAddToCart(1);
           findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
           findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
           findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
     }
     dentalPlanShopingPage.pageLoadAndClickOnContinueBtn();
     
     ReviewShoppingCartPage reviewShoppingCartPage = new ReviewShoppingCartPage(driver, testCaseId);
     reviewShoppingCartPage.pageLoadAndClickOnSaveAndContinue();

     ReviewApplicationPage reviewApplicationPage = new ReviewApplicationPage(driver, testCaseId);
     reviewApplicationPage.pageLoadAndClickOnSaveAndContinue();

     EnrollPage enrollPage = new EnrollPage(driver, testCaseId);
     enrollPage.enterHohSignAndContinue();

     myEnrollmentPage.verifyPageLoad();
     myEnrollmentPage.takeScreenshot();
    }
     
     /*
     
      * @author Ritu
      * From Health Plan Shopping Page, Click On Create A New Shopping Group
      */
      @Given("^From Health Plan Shopping Page, Click On Create A New Shopping Group$")
      public void completeShoppingDetails() throws Exception{

            HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
            healthPlanShopingPage.clickOnCreateShoppingGroup();
            healthPlanShopingPage.clickOnWarningPopup(); 
            healthPlanShopingPage.takeScreenshot();
      }




      @Given("^From Health Plan Shopping Page, After Clicking Remove Button Validate Warining PopUp And Cancel PopUp$")
      public void validateWarningMsg() throws Exception {
            HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
            healthPlanShopingPage.validateWarningPopBtn();
            healthPlanShopingPage.takeScreenshot();
            healthPlanShopingPage.clickOnCancelWarningPopBtn();
            
      }
      
      @Given("^From Health Plan Shopping Page, Click On Undo Shopping Group Changes$")
      public void clickOnUndoShoppingGroup(int shpngGrpNum) throws Exception {
            HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
            healthPlanShopingPage.clickOnUndoShoppingGroupChangesBtn();
            healthPlanShopingPage.takeScreenshot();
      }

      @Given("^From Health Plan Shopping Page, Validate Member Find A Plan Is Present For Shopping Group \"(.*?)\"$")
      public void validateFindAPlanIsPresntForGroupMembers( int gpNum) throws Exception {
            
            
            HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
            healthPlanShopingPage.validateFindAPlanForCurrentYearForShoopingGrpIsPresent(gpNum);
      }
      
      @Given("^From Health Plan Shopping Page, Click On Remove Button For Shopping Group \"(.*?)\"$")
      public void clickOnRemoveBtnForShoppingGroup(int shpngGrpNum) throws Exception {
            HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
             healthPlanShopingPage.clickOnRemoveExistingPlaForShoppingGrpAndContinue(shpngGrpNum);
      }


}
