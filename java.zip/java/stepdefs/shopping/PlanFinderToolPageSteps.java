package stepdefs.shopping;

import cucumber.api.java.en.Given;
import pages.shopping.PlanFinderToolPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class PlanFinderToolPageSteps extends SuperStepDef {

	public PlanFinderToolPageSteps(Hook hook) {
		super(hook);
	}
	
	//Amrita
	@Given("^From Plan Finder Tool Page, Click On Continue Button$")
	public void clickOnContinueBtn() throws Exception {

		PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
		planFinderToolPage.clickContinue();
	}
		
	/*
	 * @author akumari4
	 *
	 *  From Plan Finder Tool Page, Validate Preferred Providers and Prescriptions are Present
	 */
	
	@Given("^From Plan Finder Tool Page, Select Yes for Plan Help and Validate Preferred Providers and Prescriptions are Present$")
	public void validateProvidersandPrescriptions() throws Exception {

		PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
		planFinderToolPage.validateProvidersAndPrescriptionsIsPresent();

	}
	
	@Given("^From Plan Finder Tool Page, Preferred Providers and Prescriptions Checkbox$")
	public void selectProvidersandPrescriptions() throws Exception {

		PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
		planFinderToolPage.selectProvidersAndPrescriptionsThenContinue();

	}
	
	@Given("^From Plan Finder Tool Page, Select Prescriptions Checkbox and Continue$")
	public void selectPrescriptions() throws Exception {

		PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
		planFinderToolPage.selectPrescriptionsThenContinue();

	}

}
