package stepdefs.qualification;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.DualTable;
import pages.login.HomePage;
import pages.qualification.DoYouQualifyPage;
import pages.qualification.EligibilityResultPage;
import pages.qualification.FamilyDetailsPersonalInfoPage;
import pages.qualification.FamilyDetailsSpecialConditionPage;
import pages.qualification.FamilyDetailsStartPage;
import pages.qualification.IncomeDetailsPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;

public class QualificationPageSteps extends SuperStepDef {

	public QualificationPageSteps(Hook hook) {
		super(hook);
	}

	@Given("^Enter ZipCode and Family Details$")
	public void enterZipCodeAndFamilyDetails(DataTable table) throws Exception{
		String zipCode=null;
		String coverageStrDate;
		String appDate = new DualTable(conn, testCaseId).getSysDate();
		appDate = DateUtil.getTodaysDateInDBFormat();
		
		int dayOfMonth = DateUtil.getDayOfMonth(appDate,DateUtil.dbDatePattern);
		if(dayOfMonth<=23){
			coverageStrDate = DateUtil.getFirstDayOfNextMonth(appDate,DateUtil.dbDatePattern,"MM-dd-yyyy");
		}else{
			coverageStrDate = DateUtil.getFirstDayOfNextToNextMonth(appDate,DateUtil.dbDatePattern,"MM-dd-yyyy");
		}
		
		boolean heplNeededForPaying = true;
		int memCount=0;
		String mem1FName=null;
		String mem1DOB=null;
		String mem1Gender=null;
		String mem1CitizenshipStatus = "U.S. Citizen";
		boolean isMem1LivingInMA = true;
		boolean isMem1Disabled=false;
		boolean isMem1AIAN = false;
		boolean isMem1Incarcerated = false;
		
		String mem2FName=null;
		String mem2DOB=null;
		String mem2Gender=null;
		String mem2CitizenshipStatus = "U.S. Citizen";
		boolean isMem2LivingInMA = true;
		boolean isMem2Disabled=false;
		boolean isMem2AIAN = false;
		boolean isMem2Incarcerated = false;
		
		List<List<String>> scenarioData = table.raw();
		int ColCount = scenarioData.get(0).size();
		
		for(int colCounter=0; colCounter<ColCount ; colCounter++){
			String colName = scenarioData.get(0).get(colCounter);
			String colValue = scenarioData.get(1).get(colCounter);
			switch(colName){
			case "ZipCode":
					zipCode=colValue;
					break;
			case "MemCount":
					memCount=Integer.parseInt(colValue);
					break;
			case "Mem1FName":
					mem1FName=colValue;
					break;
			case "Mem1DOB":
					mem1DOB=colValue;
					break;
			case "Mem1Gender":
					mem1Gender=colValue;
					break;
			case "Mem2FName":
					mem2FName=colValue;
					break;
			case "Mem2DOB":
					mem2DOB=colValue;
					break;
			case "Mem2Gender":
					mem2Gender=colValue;
					break;
			}
		}
		HomePage homePage  =new HomePage(driver, testCaseId);
		homePage.submitYouMayQualifyDetails(zipCode, coverageStrDate, heplNeededForPaying);
		
		DoYouQualifyPage doYouQualifyPage = new DoYouQualifyPage(driver, testCaseId);
		doYouQualifyPage.pageLoadAndClickOnContinue();
		
		FamilyDetailsStartPage familyDetailsStartPage = new FamilyDetailsStartPage(driver, testCaseId);
		familyDetailsStartPage.enterNoOfPeopleInYourHH(memCount);
		
		FamilyDetailsPersonalInfoPage familyDetailsPersonalInfoPage = new FamilyDetailsPersonalInfoPage(driver, testCaseId);
		familyDetailsPersonalInfoPage.enterPersonalInfoForMember(0, mem1FName, mem1DOB, mem1Gender, mem1CitizenshipStatus, isMem1LivingInMA);
		
		FamilyDetailsSpecialConditionPage familyDetailsSpecialConditionPage = new FamilyDetailsSpecialConditionPage(driver, testCaseId);
		familyDetailsSpecialConditionPage.enterSpecialConditionForMember(0, isMem1Disabled, isMem1AIAN, isMem1Incarcerated);
		
		//Personal Info for Second Member
		familyDetailsPersonalInfoPage.enterPersonalInfoForMember(1, mem2FName, mem2DOB, mem2Gender, mem2CitizenshipStatus, isMem2LivingInMA);
		familyDetailsSpecialConditionPage.enterSpecialConditionForMember(1, isMem2Disabled, isMem2AIAN, isMem2Incarcerated);
		
	}
	
	@Given("^Enter Income and Validate Programs$")
	public void enterIncomeAndValidatePrograms(DataTable table) throws Exception{
		String annualHHIncome=null;
		String memProgram = null;
		
		List<List<String>> scenarioData = table.raw();
		int ColCount = scenarioData.get(0).size();
		
		for(int rowCounter=1; rowCounter < 5; rowCounter++){
			for(int colCounter=0; colCounter<ColCount ; colCounter++){
				String colName = scenarioData.get(0).get(colCounter);
				String colValue = scenarioData.get(rowCounter).get(colCounter);
				
				switch(colName){
				case "AnnualIncome":
						annualHHIncome=colValue;
						break;
				case "MemberProgram":
						memProgram=colValue;
						break;
				}
			}
			IncomeDetailsPage incomeDetailsPage = new IncomeDetailsPage(driver, testCaseId);
			incomeDetailsPage.provideAnnualIncomeForHH(annualHHIncome);
			
			EligibilityResultPage eligibilityResultPage = new EligibilityResultPage(driver, testCaseId);
			eligibilityResultPage.pageLoadAndValidateProgramNamesBothMember(memProgram);
			
			HomePage homePage  =new HomePage(driver, testCaseId); 
			homePage.clickOnQualificationStepsIncomeDetailsTab();
		}
		
		
	}
	
}
