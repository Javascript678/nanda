package stepdefs.createOptumId;

import java.util.List;

import appdata.common.OptumIdData;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import enums.BrowserName;
import enums.EnvName;
import enums.PortalName;
import pages.common.CommonPage;
import pages.login.HomePage;
import pages.login.SignInWithYourOptumIdPage;
import pages.profile.CreateProfilePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.BrowserFactory;
import utils.TestData;

public class NewOptumIdPageSteps extends SuperStepDef {

	public NewOptumIdPageSteps(Hook hook) {
		super(hook);
	}

	@Given("^Create Individual Portal Optum Id Using Guerilla Page$")
	public void loginToPortal(DataTable table) throws Exception {

		String browserToUse = globalData.get("BrowserToUse");

		if (browserToUse.equals(BrowserName.SAUCE_LAB_FF.val)) {
			throw new Exception("Gurilla Page Interaction on Sace Lab is not supported right now");
		}

		String portal = PortalName.INDIVIDUAL.code;
		String url = TestData.getURL(portal, envData);

		List<List<String>> scenarioData = table.raw();
		String strOptumIdCount = scenarioData.get(1).get(0);
		int intOptumIdCount = Integer.parseInt(strOptumIdCount);

		for (int optumIdCounter = 0; optumIdCounter < intOptumIdCount; optumIdCounter++) {

			BrowserFactory browserFactory = new BrowserFactory();
			browserFactory.name = browserToUse;

			driver = browserFactory.getBrowser();

			OptumIdData optumIdData = TestData.getOptumIdDataToCreateCredentialOnIndividual(globalData);

			storeTempTestData("IndividualPortal_OptumIdUserName" + optumIdCounter, optumIdData.optumId);

			CommonPage webPage = new CommonPage(driver, testCaseId);
			webPage.goTo(url);

			HomePage homePage = new HomePage(driver, testCaseId);
			homePage.clickOnSignInBtn();

			SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver,
					testCaseId);
			signInWithYourOptumIdPage.createOptumIdUsingIndividualPortal(optumIdData);

			CreateProfilePage createProfilePage = new CreateProfilePage(driver, testCaseId);
			createProfilePage.pageLoadAndTakeScreenShot();

			driver.quit();

		}

	}

	@Given("^Create Individual Portal Optum Id Using Guerilla Page On All Environments$")
	public void loginToPortalOnAllEnvironment(DataTable table) throws Exception {

		List<String> listEnv = EnvName.getNames();
		List<List<String>> scenarioData = table.raw();
		String strOptumIdCount = scenarioData.get(1).get(0);
		int intOptumIdCount = Integer.parseInt(strOptumIdCount);

		String portal = PortalName.INDIVIDUAL.code;
		String browserToUse = globalData.get("BrowserToUse");

		if (browserToUse.equals(BrowserName.SAUCE_LAB_FF.val)) {
			throw new Exception("Gurilla Page Interaction on Sace Lab is not supported right now");
		}

		for (String envName : listEnv) {

			envData = hook.loadEnvironmentData(envName);

			String url = TestData.getURL(portal, envData);

			for (int optumIdCounter = 0; optumIdCounter < intOptumIdCount; optumIdCounter++) {

				try {
					BrowserFactory browserFactory = new BrowserFactory();
					browserFactory.name = browserToUse;

					driver = browserFactory.getBrowser();

					OptumIdData optumIdData = TestData.getOptumIdDataToCreateCredentialOnIndividual(globalData);

					CommonPage webPage = new CommonPage(driver, testCaseId);
					webPage.goTo(url);

					HomePage homePage = new HomePage(driver, testCaseId);
					homePage.clickOnSignInBtn();

					SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver,
							testCaseId);
					signInWithYourOptumIdPage.createOptumIdUsingIndividualPortal(optumIdData);

					storeTempTestData("IndividualPortal_OptumIdUserName_" + envName + "_" + optumIdCounter,
							optumIdData.optumId);

					CreateProfilePage createProfilePage = new CreateProfilePage(driver, testCaseId);
					createProfilePage.pageLoadAndTakeScreenShot();

					driver.quit();
				} catch (Exception e) {
					System.out.println("Could not create Optum Id for Environemnt[" + envName + "] for counter +["
							+ optumIdCounter + "]");
				}

			}

		}

	}

}
