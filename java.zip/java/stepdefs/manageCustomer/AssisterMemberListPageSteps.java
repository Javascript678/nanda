package stepdefs.manageCustomer;

import cucumber.api.java.en.Given;
import pages.manageCustomer.AssisterMemberListPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class AssisterMemberListPageSteps extends SuperStepDef{

	public AssisterMemberListPageSteps(Hook hook) {
		super(hook);
	}
	
	@Given("^From Assister Member List Page, Click On View Profile For User Profile Ref Id Used$")
	public void searchUsingRefIdAndClickOnViewProfile() throws Exception{
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		AssisterMemberListPage assisterMemberListPage = new AssisterMemberListPage(driver, testCaseId);
		assisterMemberListPage.searchUsingRefIdAndClickOnViewProfile(userProfileRefId);
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	@Given("^From Assister Member List Page, Click On View Eligibility For User Profile Ref Id Used$")
	public void searchUsingRefIdAndClickOnViewEligibility() throws Exception{
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		AssisterMemberListPage assisterMemberListPage = new AssisterMemberListPage(driver, testCaseId);
		assisterMemberListPage.searchUsingRefIdAndClickOnViewEligibility(userProfileRefId);
	}
	
	@Given("^From Assister Member List Page, Click On Confirm Pop Up$")
	public void clickOnConfirmPopUp() throws Exception{
		AssisterMemberListPage assisterMemberListPage = new AssisterMemberListPage(driver, testCaseId);
		assisterMemberListPage.clickOnConfirmPopUp();
	}
	
	@Given("^From Assister Member List Page, Click On Agree Pop Up$")
	public void clickOnAgreePopUp() throws Exception{
		AssisterMemberListPage assisterMemberListPage = new AssisterMemberListPage(driver, testCaseId);
		assisterMemberListPage.clickOnAgreePopUp();
	}
	
//Amrita
	@Given("^From Assister Member List Page, Click On Yes Pop Up$")
	public void clickOnYesPopUp() throws Exception{
		AssisterMemberListPage assisterMemberListPage = new AssisterMemberListPage(driver, testCaseId);
		assisterMemberListPage.clickOnConfirmYesPopUp();
	}
	
	//Amrita
		@Given("^From Assister Member List Page, Click on Remove Access For Member \"(.*?)\"$")
		public void clickOnRemoveAccessForMember(String memNo) throws Exception{
			int memindex= Integer.parseInt(memNo)-1;
			AssisterMemberListPage assisterMemberListPage = new AssisterMemberListPage(driver, testCaseId);
			assisterMemberListPage.clickOnRemoveAccessForMember(memindex);
		}
	//Amrita
		@Given("^From Assister Member List Page, Click on View Profile For Member \"(.*?)\"$")
		public void clickOnViewProfileForMember(String memNo) throws Exception{
			 int memindex= Integer.parseInt(memNo)-1;
			 AssisterMemberListPage assisterMemberListPage = new AssisterMemberListPage(driver, testCaseId);
			 assisterMemberListPage.clickOnViewProfileForMember(memindex);
		}
	//Amrita
		@Given("^From Assister Member List Page, Click on View Eligibility For Member \"(.*?)\"$")
		public void clickOnViewEligibilityForMember(String memNo) throws Exception{
			 int memindex= Integer.parseInt(memNo)-1;
			 AssisterMemberListPage assisterMemberListPage = new AssisterMemberListPage(driver, testCaseId);
			 assisterMemberListPage.clickOnViewEligibilityForMember(memindex);
		}
	//Amrita
		@Given("^From Assister Member List Page, Click on View Designation Form For Member \"(.*?)\"$")
		public void clickOnViewDesignationFormForMember(String memNo) throws Exception{
			int memindex= Integer.parseInt(memNo)-1;
			AssisterMemberListPage assisterMemberListPage = new AssisterMemberListPage(driver, testCaseId);
			assisterMemberListPage.clickOnViewDesignationFormForMember(memindex);
		}
		
		//Amrita
		@Given("^From Assister Member List Page, Take Screenshot$")
		public void takeScreenshot() throws Exception{
			
			AssisterMemberListPage assisterMemberListPage = new AssisterMemberListPage(driver, testCaseId);
			assisterMemberListPage.takeScreenshot();
			
		}
	
}
