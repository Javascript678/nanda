package stepdefs.manageCustomer;
import cucumber.api.java.en.Given;
import pages.accountDashboard.AccountDashboardLandingPage;
import pages.manageCustomer.FindACustomerPage;
import pages.pa.LandingPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class FindACustomerSteps extends SuperStepDef{
	
	public FindACustomerSteps(Hook hook){
		super(hook);
	}

	/**
	 * Take User Profile RefId from Temporary file
	 * 
	 */
	@Given("^From Find A Customer Page, Find A Customer With USER PROFILE REF ID And Go To Account Dashboard$")
	public void findACustomerWithRefIdAndGoToAccountDashboard() throws Exception {
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(evpdData.memsData.get(0).userRefId);
		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.waitForPageLoaded();
	}
	

	/**@author akumari4
	 
		From Find A Customer Page, Find A Customer With Profile ID As "ProfileID_2" And Go To Account Dashboard
		
	 */
	@Given("^From Find A Customer Page, Find A Customer With Profile ID As \"(.*?)\" And Go To Account Dashboard$")
	public void findACustomerWithVariableRefIdAndGoToAccountDashboard(String variableForProfileRefID) throws Exception {
		String userProfileRefId = TestData.getTempTestData(variableForProfileRefID, featureFileName);
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(userProfileRefId);
		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.waitForPageLoaded();
		
	}
	
	/**@Ritika
	 *  Take User Profile RefId from Temporary file
	 * 
	 */
	@Given("^From Find A Customer Page, Find A Customer With USER PROFILE REF ID And Go To Premium Assistance Dashboard$")
	public void findAcustomerUsingUserProfileRefIdAndGoToPremiumAssistanceDashBoard() throws Exception {
		//String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		String userProfileRefId = evpdData.memsData.get(0).userRefId;
		
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToPremiumAssistanceDashBoard(userProfileRefId);
		
		LandingPage pa_LandingPage = new LandingPage(driver, testCaseId);
		pa_LandingPage.waitForPageLoaded();
		
	}
	
	/**
	 * @ Author :-Ritu
	 * @throws Exception
	 */
	@Given("^From Find A Customer Page,Find A Customer Using EmailID And DOB And Go To Account Dashboard$")
	public void findACustomerWithEmailIdAndGoToAccountDashboard() throws Exception {
		String emailId = TestData.getTempTestData("IndPortal_EmailId", featureFileName);
		String dob = globalData.get("Profile_DOB");
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingEmailIdAndDOBAndGoToAccountDashBoard(emailId,dob);
		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.waitForPageLoaded();
		
	}
	
	@Given("^EVPD, Find A Customer With USER PROFILE REF ID And Go To Account Dashboard$")
	public void findACustomerWithRefIdAndGoToAccountDashboard_evpd() throws Exception {
		String userProfileRefId = getTempTestData("UserProfileRefId");
		
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(userProfileRefId);
	}
	
	
	//Added by Brajesh for ELigibility details run test Defect 18267
	@Given("^Eli_History_Run, Find A Customer With USER PROFILE REF ID And Go To Account Dashboard$")
	public void findACustomerWithRefIdAndGoToAccountDashboard_EligibitilyHistoryRun() throws Exception {
		FindACustomerPage findACustomerPage = new FindACustomerPage(driver, testCaseId);
		findACustomerPage.findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(globalData.get("UserProfileRefID"));
	}
}
