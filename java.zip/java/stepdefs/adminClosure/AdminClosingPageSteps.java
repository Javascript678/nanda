package stepdefs.adminClosure;

import pages.adminClosing.AdminClosingPage;


import cucumber.api.java.en.Given;
import db.DualTable;
import db.ElgMemberTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class AdminClosingPageSteps extends SuperStepDef{
	
	public AdminClosingPageSteps(Hook hook){
		super(hook);
	}

	/**
	 * Valid Admin Closing Reason:- Valid AdminClosureReason Value From Drop Down 
	 * 						1. "38 - Voluntary Withdrawal"
	 * 						2. "49 - Deceased"
							3. "50 - Whereabouts Unknown"
							4  "58 - Failed to cooperate with Quality Assurance"
							5. "12 - No longer in household"
							6. "33 - Already receiving MassHealth"
							7. "46 - Entered penal institution"
							8. "73 - Member did not enroll in employer sponsored health insurance"
							9. "86 - Failure to pay MH premium"
							10. "S1 - Member is age 65 or older"
							11. "S2 - Receiving benefits in another state but eligible for QHP"
							12. "S3 - Entered penal institution but eligible for QHP"
							13. "S4- Not a resident of Massachusetts but eligible for QHP"
							14. "S6- Entered penal institution based on data match"
							15. "S7 - Deceased based on data match"
							16. "A1 - Failure to respond to data match"
							17. "A2 - Failure to return a Job Update form"
							18. "A3 - Failure to cooperate with a health insurance investigation"
							19. "A5 - Duplicate case"
							20. "A6 - HOH's account is deactivated"
							
	 	From Admin Closing Page, For Member "1", Set Reason As "38 - Voluntary Withdrawal"
	 	
	 */
	@Given("^From Admin Closing Page, For Member \"(.*?)\", Set Reason As \"(.*?)\"$")
	public void selectAdminClosingReason(String memNo, String closureReason) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		String eligibilityId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		String fName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String lName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		AdminClosingPage admclosing = new AdminClosingPage(driver, testCaseId);
		admclosing.selectAdminClosingReason(fName, lName, closureReason);
	}
	
	/**Amrita
	 
	 From Admin Closing Page, For Member "1", Enter Effective Date Prior From Today As "5"
	 
	 */
	@Given("^From Admin Closing Page, For Member \"(.*?)\", Enter Effective Date As Current Date$")
	public void enterAdminClosingEffectDate(String memNo) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		
		String currentDate = new DualTable(conn,"").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		String eligibilityId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		String fName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		String lName = elgMemberTable.getLastName(eligibilityId, memIndex);

		AdminClosingPage admclosing = new AdminClosingPage(driver, testCaseId);
		admclosing.enterAdminClosingEffectDate(fName, lName, currentDate);
	}
	
	@Given("^From Admin Closing Page, For Member \"(.*?)\", Set Reason As \"(.*?)\" For SS$")
	public void selectAdminClosingReasonForSS(String memNo, String closureReason) throws Exception {
		int memInd = Integer.parseInt(memNo);		
		//ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		String eligibilityId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		//String fName = elgMemberTable.getFirstName(eligibilityId, memIndex);
		//String lName = elgMemberTable.getLastName(eligibilityId, memIndex);
		
		String fName = TestData.getTempTestData("Mem_"+memInd+"_FirstName", featureFileName);
  		String lName = TestData.getTempTestData("Mem_"+memInd+"_LastName", featureFileName);  
		
		
		AdminClosingPage admclosing = new AdminClosingPage(driver, testCaseId);
		admclosing.selectAdminClosingReason(fName, lName, closureReason);
	}
	
	/**
	 
	 From Admin Closing Page, For Member "1", Enter Removal Date From Today As "365"
	 
	 */
	
	@Given("^From Admin Closing Page, For Member \"(.*?)\", Enter Removal Date From Today As \"(.*?)\"$")
	public void enterAdminClosingRemovalDate(String memNo, String removalDateFromToday) throws Exception {
		int memberNo = Integer.parseInt(memNo);
		String currentDate = new DualTable(conn,"").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);
		int intRemovalDateFromToday = Integer.parseInt(removalDateFromToday);
		String removalDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+(-intRemovalDateFromToday));
		
		AdminClosingPage admclosing = new AdminClosingPage(driver, testCaseId);
		admclosing.enterAdminClosingRemovalDate(memberNo, removalDate);
	}
	
	/**
	 
	 From Admin Closing Page, Click On Back Button
	 
	 */
	
	@Given("^From Admin Closing Page, Click On Back Button$")
	public void clickOnBackButton() throws Exception {
		AdminClosingPage admclosing = new AdminClosingPage(driver, testCaseId);
		admclosing.clickOnBackButton();
	}
	
	/**
	 
	 From Admin Closing Page, Click On Save Button
	 
	 */
	
	@Given("^From Admin Closing Page, Click On Save Button$")
	public void clickOnSaveBtn() throws Exception {
		AdminClosingPage admclosing = new AdminClosingPage(driver, testCaseId);
		admclosing.clickOnSaveBtn();
	}
	
	/**
	 
	 From Admin Closing Page, Click On Save And ReRunEligibility Button
	 
	 */
	
	@Given("^From Admin Closing Page, Click On Save And ReRunEligibility Button$")
	public void clickOnSaveAndReRunEligibilityBtn() throws Exception {
		AdminClosingPage admclosing = new AdminClosingPage(driver, testCaseId);
		admclosing.clickOnSaveAndReRunEligibilityBtn();
	}

	/**
	 
	 From Admin Closing Page, Click On OK PopUp
	 
	 */
	
	@Given("^From Admin Closing Page, Click On OK PopUp$")
	public void clickOnOkPopup() throws Exception {
		AdminClosingPage admclosing = new AdminClosingPage(driver, testCaseId);
		admclosing.clickOnOkPopup();
	}
	
	/**
	 
	 From Admin Closing Page, Confirm Rerun Eligibility Successful
	 
	 */
	
	@Given("^From Admin Closing Page, Confirm Rerun Eligibility Successful$")
	public void VerifySuccessMessage() throws Exception {
		AdminClosingPage admclosing = new AdminClosingPage(driver, testCaseId);
		admclosing.VerifySuccessMessage();
	}
	
	/**
	 
	 From Admin Closing Page, Take ScreenShot
	 
	 */
	
	@Given("^From Admin Closing Page, Take Screenshot$")
	public void taksScreenShot() throws Exception {
		AdminClosingPage admclosing = new AdminClosingPage(driver, testCaseId);
		admclosing.taksScreenShot();
	}
}
