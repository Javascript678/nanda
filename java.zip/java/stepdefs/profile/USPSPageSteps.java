package stepdefs.profile;

import cucumber.api.java.en.Given;
import enums.TrueFalseValue;
import pages.profile.USPSPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class USPSPageSteps extends SuperStepDef{
	
	public USPSPageSteps(Hook hook){
		super(hook);
	}
	
	/**
	 * Accept DataTable with following value
	 * 1. PortalName -- A,I,AR
	 * 
	 Complete USPS Page Details For Profile For Portal As "A"
	 
	 */
	@Given("^Complete USPS Page Details For Profile For Portal As \"(.*?)\"$")
	public void completeUSPSPageDetailsForProfile(String portalName) throws Exception{
		
		Boolean noHomeAddressReqd = globalData.get("Profile_NoHomeAddressReqd").equalsIgnoreCase("Y")?true:false;
		Boolean individualByPassUsps = envData.get("Individual_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		Boolean agentByPassUsps = envData.get("Agent_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		Boolean assisterByPassUsps = envData.get("Assister_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		
		USPSPage uspsPage = new USPSPage(driver, testCaseId);
		uspsPage.completeUSPSServiceSuggestion(portalName,individualByPassUsps, agentByPassUsps,assisterByPassUsps,noHomeAddressReqd);
	}
	
	/**
	 * Accept DataTable with following value
	 * 1. PortalName -- A,I
	 
	 Complete USPS Page Details For HOH For Portal As "A"
	 
	 */
	@Given("^Complete USPS Page Details For HOH For Portal As \"(.*?)\"$")
	public void completeUSPSPageDetailsForHOH(String portalName) throws Exception{
		
		Boolean noHomeAddressReqd = globalData.get("AccountHolder_NoHomeAddressReqd").equalsIgnoreCase("Y")?true:false;
		Boolean individualByPassUsps = envData.get("Individual_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		Boolean agentByPassUsps = envData.get("Agent_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		Boolean assisterByPassUsps = envData.get("Assister_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		
		USPSPage uspsPage = new USPSPage(driver, testCaseId);
		uspsPage.completeUSPSServiceSuggestion(portalName,individualByPassUsps, agentByPassUsps,assisterByPassUsps,noHomeAddressReqd);
	}
	/**Ritika
	 * * Accept DataTable with following value
	 * 1. PortalName -- A,I
	 * Complete USPS Page Details For Mailing Address For Portal As "A"

	 */
	@Given("^Complete USPS Page Details For Mailing Address For Portal As \"(.*?)\"$")
	public void completeUSPSPageDetailsForHOHMailing(String portalName) throws Exception{
		
		Boolean individualByPassUsps = envData.get("Individual_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		Boolean agentByPassUsps = envData.get("Agent_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		Boolean assisterByPassUsps = envData.get("Assister_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		
		USPSPage uspsPage = new USPSPage(driver, testCaseId);
		uspsPage.completeUSPSServiceSuggestionForMailingAddress(portalName,individualByPassUsps, agentByPassUsps,assisterByPassUsps);
	}
	
	@Given("^EVPD, Complete USPS Page Details$")
	public void evpd_completeUSPSPageDetails() throws Exception {
		USPSPage uspsPage = new USPSPage(driver, testCaseId);
		uspsPage.completeUSPSServiceSuggestion(evpdData.portal, evpdData.serviceData, evpdData.createProfileData.noHomeAddressReqd);
	}
	
}
