package stepdefs.profile;

import cucumber.api.java.en.Given;
import pages.profile.IdProofingPage;
import pages.profile.IdVerificationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class IdProofingAndVerificationPageSteps extends SuperStepDef{
	
	public IdProofingAndVerificationPageSteps(Hook hook){
		super(hook);
	}
	
	@Given("^Complete Id Proofing And Verification$")
	public void completeVerification() throws Exception {
		IdProofingPage idProofingPage = new IdProofingPage(driver, testCaseId);
		idProofingPage.pageLoadThenClickOnSaveAndContinue();
		
		IdVerificationPage idVerificationPage = new IdVerificationPage(driver, testCaseId);
		idVerificationPage.completeIdVerification(
				evpdData.createProfileData.idProofingAns1Index,
				evpdData.createProfileData.idProofingAns2Index,
				evpdData.createProfileData.idProofingAns3Index,
				evpdData.createProfileData.idProofingAns4Index,
				evpdData.createProfileData.idProofingAns5Index);
	}
	
	@Given("^From IdProofingAndVerificationPage, Complete With Default Value$")
	public void completeVerificationWithDefaultValue() throws Exception {
		IdProofingPage idProofingPage = new IdProofingPage(driver, testCaseId);
		idProofingPage.pageLoadThenClickOnSaveAndContinue();
		
		IdVerificationPage idVerificationPage = new IdVerificationPage(driver, testCaseId);
		idVerificationPage.completeIdVerification(1,1,1,1,1);
	}
	
	@Given("^From IdProofingAndVerificationPage, Complete With All Value As None Of the Above$")
	public void completeVerificationWithAllValueAsNoneOftheAbove() throws Exception {
		IdProofingPage idProofingPage = new IdProofingPage(driver, testCaseId);
		idProofingPage.pageLoadThenClickOnSaveAndContinue();
		
		IdVerificationPage idVerificationPage = new IdVerificationPage(driver, testCaseId);
		idVerificationPage.completeIdVerification(4,4,4,4,4);
	}
	
	
	
	
}
