package stepdefs.profile;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import cucumber.api.java.en.Given;
import db.DualTable;
import pages.profile.MyElig_EligAppPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;

public class MyElig_EligAppPageSteps extends SuperStepDef{
	
	public MyElig_EligAppPageSteps(Hook hook){
		super(hook);
	}
	
	@Given("^From My Eligibility, Click On Create Application Button$")
	public void clickOnCreateApplicationBtn() throws Exception {
		String year = globalData.get("ApplicationCreationYear");
		
		MyElig_EligAppPage myElig_EligAppPage = new MyElig_EligAppPage(driver, testCaseId);
		myElig_EligAppPage.clickOnCreateApplicationBtnForGivenYear(year);
		
	}
	
	@Given("^From My Eligibility, Click On Create Application Button For Next Year$")
	public void clickOnCreateApplicationBtnForNext() throws Exception {
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		
		MyElig_EligAppPage myElig_EligAppPage = new MyElig_EligAppPage(driver, testCaseId);
		myElig_EligAppPage.clickOnCreateApplicationBtnForNextYear(appDate);
	}
	
	@Given("^From My Eligibility, Click On Create Application Button For Previous Year$")
	public void clickOnCreateApplicationBtnForPrevious() throws Exception {
		String appDate = new DualTable(conn,"").getSysDate();
		appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		
		MyElig_EligAppPage myElig_EligAppPage = new MyElig_EligAppPage(driver, testCaseId);
		myElig_EligAppPage.clickOnCreateApplicationBtnForPrevYear(appDate);
	}
	
	@Given("^From My Eligibility, Click On Create Application Button For Given System Date Year$")
	public void clickOnCreateApplicationBtnForGivenSystemDateYear() throws Exception {
		//String appDate = new DualTable(conn,"").getSysDate();
		DateFormat df = new SimpleDateFormat("MM/dd/YYYY");
		Date dateobj = new Date();
		 String appDate=df.format(dateobj);
		//appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		
		MyElig_EligAppPage myElig_EligAppPage = new MyElig_EligAppPage(driver, testCaseId);
		myElig_EligAppPage.clickOnCreateApplicationBtn(appDate);
	}
	
}
