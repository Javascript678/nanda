package stepdefs.profile;

import java.util.List;

import cucumber.api.java.en.Given;
import db.DualTable;
import enums.AppTypeName;
import enums.PortalName;
import pages.profile.CreateProfilePage;
import stepdefs.login.HomePageSteps;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.RandomGenerator;

public class CreateProfilePageSteps extends SuperStepDef{
	
	public CreateProfilePageSteps(Hook hook){
		super(hook);
	}
	
	@Given("^From Complete Create Profile page, Validate SSN Is Masked$")
	public void validateSSNIsMasked() throws Exception{
		CreateProfilePage createProfilePage = new CreateProfilePage(driver, testCaseId);
		createProfilePage.validateSSNIsMasked();
	}
	
}
