package stepdefs.profile;

import cucumber.api.java.en.Given;
import pages.profile.MyProfilePage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class MyProfilePageSteps extends SuperStepDef{
	
	public MyProfilePageSteps(Hook hook){
		super(hook);
	}
	
	@Given("^From My Profile Page, Take Screenshot$")
	public void takeScreenshot() throws Exception{
		
		MyProfilePage myProfilePage = new MyProfilePage(driver, testCaseId);
		myProfilePage.takeScreenshot();
		
	}
	
	@Given("^From My Profile Page, Validate SSN Is Masked$")
	public void validateSSNIsMasked() throws Exception{
		
		MyProfilePage myProfilePage = new MyProfilePage(driver, testCaseId);
		myProfilePage.validateUserProfileSSNIsMasked();
		
	}
	
	@Given("^From My Profile Page, Click On View Unlock Elg$")
	public String clickOnViewUnlockElg() throws Exception {		
		MyProfilePage myProfilePage = new MyProfilePage(driver, testCaseId);
		myProfilePage.takescreenshot();
		
		String refID = myProfilePage.getUserProfileRefIdAndClickOnViewUnlockElg();
		return refID;
	
	}
	
	@Given("^From My Profile Page,Validate RIDPServices Warning Message$")
	public void validateRIDP() throws Exception{
		
		MyProfilePage myProfilePage = new MyProfilePage(driver, testCaseId);
		myProfilePage.validateRIDPWarningMsg();
		
	}
	
}
