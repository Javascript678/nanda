package stepdefs.accountDashboard;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import db.ElgMemberTable;
import pages.accountDashboard.EligibilityDetailsMHSummary;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

public class EligibilityDetailsMHSummarySteps extends SuperStepDef{

	List<String> nameList = new ArrayList<String>();
	int memCount = 0;
	int lastMemClicked = 0;
	EligibilityDetailsMHSummary eligibilityDetailsMHSumPage = new EligibilityDetailsMHSummary(driver, testCaseId);
	
	public EligibilityDetailsMHSummarySteps(Hook hook) {
		super(hook);
		this.getMembersName();
	}
	
	
	private void getMembersName()
	{
		try
		{
			String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
			ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
			memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
			
			for(int i=0; i < memCount ; i++)
			{
				String name = elg_MemberTable.getFullNameUsingUserProfileRefId(userProfileRefId, i);
				nameList.add(name);
			}	
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	private void clickOnDropdownBasedOnMember(int memNum, String name) throws Exception
	{
		name = name + " - Data";
		if(lastMemClicked == 0 && memNum !=1)
		{
			eligibilityDetailsMHSumPage.clickOnDropDown(name);
		}
		else if (lastMemClicked != 0 && lastMemClicked !=memNum)
		{
			eligibilityDetailsMHSumPage.clickOnDropDown(name);
		}
	}
	
	
	@Given("^From Eligibilities Page, Take Screenshot$")
    public void takeScreenshot() throws Exception{
          EligibilityDetailsMHSummary eligibilityDetailsMHSumPage = new EligibilityDetailsMHSummary(driver, testCaseId);
          eligibilityDetailsMHSumPage.takeScreenshot();
    }

	
	@Given("^From Eligibilities Page, Click on Medicaid Household Summary$")
	public void gotoMedicaidHouseholdSummary() throws Exception 
	{
		EligibilityDetailsMHSummary eligibilityDetailsMHSumPage = new EligibilityDetailsMHSummary(driver, testCaseId);
		eligibilityDetailsMHSumPage.clickOnMH_SummaryTab();

	}
	
	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value -: Valid age of member 
	 * AgeFormat :- "32","32:01", "00:00:05" 
	 
	  From Eligibility Details Page, Medicaid Household Summary Tab, Validate Date of Birth  
	  |MemNo|   DOB  | 	
	  |  1  |40:00:04|
	  |  2  |02:06:01| 
	  
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Date of Birth$")
	public void validateMHSDob(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String age  = scenarioData.get(rowIndex).get(1);
				
				String appDate = TestData.getTempTestData("AppDate", featureFileName);
				String dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, age);
				
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateDOB(name+" - Data" ,dob);
				lastMemClicked = memNum;
			}
		}
	}
	

	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value-: Yes
	 * 					No
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Verified Disability 
	 |MemNo|Verified Disability| 	
	 |  1  |         no        |
	 |  2  |         no        |
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Verified Disability$")
	public void validateVerifiedDisability(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateVerifiedDisability(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}

	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value :- Yes
	 * 					 No
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Head of HH
	 |MemNo|    Head of HH   | 	
	 |  1  |          yes    |
	 |  2  |          no     |
	 
	* 
	*/
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Head of HH$")
	public void validateHeadOfHouseHold(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateHeadOfHouseHold(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	

	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value -: yes
	 * 					 no
	 * 
	 From Eligibility Details Page, Medicaid Household Summary Tab, HIV Positive
	 |MemNo|HIV Positive| 	
	 |  1  |     no     |
	 |  2  |     no     |
	 
	 * 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, HIV Positive$")
	public void validateHivPossitive(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateHIVPositive(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}

	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value 1.yes
	 * 				  2.no
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Filing Jointly
	 |MemNo|Filing Jointly| 	
	 |  1  |      no      |
	 |  2  |      no      |
	 
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Filing Jointly$")
	public void validateFileJointly(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateFileJointly(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	

	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value:1.yes
	 * 				  2.no
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Receiving DMH Services
	  |MemNo|Receiving DMH Services| 	
	  |  1  |         no           |
	  |  2  |         no           |
	  
	  * 
	  */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Receiving DMH Services$")
	public void validateReceivingDMHServices(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateReceivingDMHServices(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	

	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value:1.yes
	 *  			  2.no
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Claiming Dependents
	 |MemNo|    Claiming Dependents   | 	
     |  1  |             yes          |
	 |  2  |             no           |
	 
	 * 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Claiming Dependents$")
	public void validateClaimingDependents(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateClaimingDependents(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	

	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value -: yes
	 * 					 no
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Former Foster Care
	 |MemNo|Former Foster Care| 	
     |  1  |        no        |
     |  2  |        no        |
     
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Former Foster Care$")
	public void validateFormerFosterCare(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateFormerFosterCare(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	

	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value -: Yes
	 * 					 No
	 
	  From Eligibility Details Page, Medicaid Household Summary Tab, Self Attested Disability
	  |MemNo|Self Attested Disability| 	
	  |  1  |           no           |
	  |  2  |           no           |
	  
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Self Attested Disability$")
	public void validateSelfAttestedDisability(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateSelfAttestedDisability(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	

	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value -:Yes
	 * 					No
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Is Safe Harbor Eligible
	 |MemNo|Is Safe Harbor Eligible| 	
	 |  1  |            no         |
	 |  2  |            no         |
	 
	 * 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Is Safe Harbor Eligible$")
	public void validateIsSafeHarborEligible(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateIsSafeHarborEligible(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	

	/**
	 ** @author abajpai3
	 * Validate for all members
	 * Accepted Value -: Any Valid Aidcat
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Aid Category
	 * |MemNo|Aid Category| 	
	 * |  1  |      1Y    |
	 * |  2  |      93    |
	 * 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Aid Category$")
	public void validateAidCategory(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateAidCategory(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	

	/**
	
	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Is Post Partum Eligible- 
	 *					Yes
	 *					No
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Is Post Partum Eligible
	 |MemNo|Is Post Partum Eligible| 	
	 |  1  |             no        |
	 |  2  |             no        | 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Is Post Partum Eligible$")
	public void validateIsPostPartumEligible(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateIsPostPartumEligible(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}


	/**
	 ** @author abajpai3
	 
	 * Validate for all members
	 * Accepted Value- any Valid Citizenship Immigration Status
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Citizenship Immigration Status
	 |MemNo|Citizenship Immigration Status| 	
	 |  1  |                CIT           |
	 |  2  |                CIT           |
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Citizenship Immigration Status$")
	public void validateCitizenshipImmigrationStatus(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateCitizenshipImmigrationStatus(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}


	/**
	 ** @author abajpai3
	 
	 * Validate for all members
	 * Accepted Value- Yes
	 * 				    No
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Pregnant
	 |MemNo|   Pregnant  | 	
	 |  1  |      no     |
	 |  2  |      no     |
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Pregnant$")
	public void validatePregnant(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validatePregnant(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- yes
	 * 				   no
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Marital Status
	 |MemNo|Marital Status| 	
	 |  1  |       no     | 
	 |  2  |       no     | 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Marital Status$")
	public void validateMaritalStatus(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateMaritalStatus(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- yes
	 * 				   no
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Claimed by Non Custodial Parent
	 |MemNo|Claimed by Non Custodial Parent| 	
	 |  1  |              no               |
	 |  2  |              no               |
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Claimed by Non Custodial Parent$")
	public void validateClaimedbyNonCustodialParent(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateClaimedbyNonCustodialParent(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}



	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Valid Date format- MM/DD/YYYY
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Eligibility Begin Date
	 |MemNo|Eligibility Begin Date| 	
	 |  1  |      08/31/2018      |
	 |  2  |      08/31/2018      |
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Eligibility Begin Date$")
	public void validateEligibilityBeginDate(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateEligibilityBeginDate(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- yes
	 * 				   no
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Other Health Insurance
	 |MemNo|Other Health Insurance| 	
	 |  1  |          no          |
	 |  2  |          no          | 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Other Health Insurance$")
	public void validateOtherHealthInsurance(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateOtherHealthInsurance(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	

	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value-yes
	 * 				  no
	
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Medicaid Child Age
	 |MemNo|Medicaid Child Age| 	
	 |  1  |        no        |
	 |  2  |        yes       |
	 * 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Medicaid Child Age$")
	public void validateMedicaidChildAge(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateMedicaidChildAge(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	

	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- yes
	 * 				   no
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate BCC
	 |MemNo|BCC| 	
	 |  1  | no|
	 |  2  | no|
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate BCC$")
	public void validateBCC(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateBCC(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value-yes
	 * 				  no
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Required To File Taxes
	 |MemNo|Required To File Taxes| 	
	 |  1  |          yes         |
	 |  2  |          no          |
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Required To File Taxes$")
	public void validateRequiredToFileTaxes(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateRequiredToFileTaxes(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Yes
	 * 				   No
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Received Medicaid In Foster Care
	 |MemNo| Received Medicaid In Foster Care | 	
     |  1  |                 no               |
	 |  2  |                 no               |
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Received Medicaid In Foster Care$")
	public void validateReceivedMedicaidInFosterCare(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateReceivedMedicaidInFosterCare(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Yes
	 * 				   No
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Claimed As Dependent
	 |MemNo|Claimed As Dependent| 	
	 |  1  |        no          |
	 |  2  |       yes          | 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Claimed As Dependent$")
	public void validateClaimedAsDependent(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateClaimedAsDependent(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Yes
	 * 				   No
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Born MH Eligible
	 |MemNo|Born MH Eligible| 	
	 |  1  |        no      |
	 |  2  |        no      |
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Born MH Eligible$")
	public void validateBornMHEligible(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateBornMHEligible(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value-Any Valid Medicaid Tax Role
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Medicaid Tax Role
	 |MemNo| Medicaid Tax Role  | 	
	 |  1  |Individual Tax Filer|
	 |  2  | Dependent Of Parent|
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Medicaid Tax Role$")
	public void validateMedicaidTaxRole(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateMedicaidTaxRole(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	 
	 * Validate for all members
	 * Accepted Value- Yes
	 * 				   No
	
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Self Attested Incarceration 
	 |MemNo|Self Attested Incarceration| 	
	 |  1  |            no             |
	 |  2  |            no             |
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Self Attested Incarceration$")
	public void validateSelfAttestedIncarceration(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateSelfAttestedIncarceration(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3

	 * Validate for all members
	 * Accepted Value-Valid Medically Frail Value
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Medically Frail
	 |MemNo|    Medically Frail   | 	
	 |  1  |         --           |
	 |  2  |         --           |
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Medically Frail$")
	public void validateMedicallyFrail(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateMedicallyFrail(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- 1.Date in valid date format
	 * 				   2.N/A	
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Medically Frail Effective Date 
	 |MemNo|Medically Frail Effective Date| 	
     |  1  |             N/A              |
	 |  2  |             N/A              | 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Medically Frail Effective Date$")
	public void validateMedicallyFrailEffectiveDate(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateMedicallyFrailEffectiveDate(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value-Valid TPL Status Value
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate TPL Status
	 |MemNo|TPL Status| 	
   	 |  1  |     P    | 
	 |  2  |     P    |
	 */

	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate TPL Status$")
	public void validateTPLStatus(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateTPLStatus(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- 1.Valid Date value in MM/DD/YYYY format
	 * 				   2.N/A for no date
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate TMA Period End Date
	 |MemNo|TMA Period End Date| 	
	 |  1  |        N/A        |
	 |  2  |        N/A        |
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate TMA Period End Date$")
	public void validateTMAPeriodEndDate(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateTMAPeriodEndDate(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	 
	 * Validate for all members
	 * Accepted Value-Yes
	 * 				  No
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Continued MH Standard Eligibility For Pregnant Women
	 |MemNo|MH Standard Eligibility For Pregnant Women| 	
	 |  1  |                     no                   |
	 |  2  |                     no                   |
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Continued MH Standard Eligibility For Pregnant Women$")
	public void validateContinuedMHStandardEligibilityForPregnantWomen(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateContinuedMHStandardEligibilityForPregnantWomen(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	

	/**
	 ** @author abajpai3
	 
	 * Validate for all members
	 * Accepted Value- 1.Valid date in MM/DD/YYYY format
	 * 				   2. -- for no date
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Pregnancy End Date
	 |MemNo|   Pregnancy End Date  | 	
	 |  1  |           --          |
	 |  2  |           --          | 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Pregnancy End Date$")
	public void validatePregnancyEndDate(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validatePregnancyEndDate(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- yes
	 * 				   no
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate MH Pending Status
	 |MemNo|    MH Pending  | 	
	 |  1  |        no      |
	 |  2  |        no      | 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate MH Pending Status$")
	public void validateMHPending(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateMHPending(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Yes
	 * 				   No
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Second Provisional Restricted
	 |MemNo|Second Provisional Restricted| 	
	 |  1  |              no             |
	 |  2  |              no             |
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Second Provisional Restricted$")
	public void validateSecondProvisionalRestricted(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateSecondProvisionalRestricted(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Applicant Name under ApplicationList
	 |MemNo| 	
	 |  1  |
	 |  2  |
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Applicant Name under ApplicationList$")
	public void validateApplicantName_ApplicationList(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				for(String applName : nameList)
				{
					if(!StringUtils.equals(applName, name))
					{
						eligibilityDetailsMHSumPage.validateApplicantName_ApplicationList(name+" - Data" ,applName);		
					}
				}
								
				lastMemClicked = memNum;
			}
		}
	}
	


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Any valid relationship like  1.Spouse
	 * 				   						        2.Child
	 * 				                                3.Parent
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Relationship Under ApplicationList
	 |MemNo|Relationship| 	
	 |  1  |    Child   |
	 |  2  |    Parent  |
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Relationship Under ApplicationList$")
	public void validateRelationship_ApplicationList(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateRelationship_ApplicationList(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- yes
	 * 				   no
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Lives With Under ApplicationList
	 |MemNo|  Lives With | 	
	 |  1  |     yes     |
	 |  2  |     yes     |
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Lives With Under ApplicationList$")
	public void validateLivesWith_ApplicationList(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateLivesWith_ApplicationList(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}		

	/**
	 ** @author abajpai3
	 
	 * Validate for all members
	 * Accepted Value- yes
	 * 				   no
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Claiming Tax Filer Under ApplicationList
	 |MemNo|  Tax Filer | 	
	 |  1  |     yes    |
	 |  2  |     yes    |
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Claiming Tax Filer Under ApplicationList$")
	public void validateClaimingTaxFiler_ApplicationList(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateClaimingTaxFiler_ApplicationList(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}		


	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Valid age - any numeric value
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Age Under ApplicationList
	 |MemNo|     Age   | 	
	 |  1  |     18    |
	 |  2  |     40    |
	 * 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Age Under ApplicationList$")
	public void validateAge_ApplicationList(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateAge_ApplicationList(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}		

	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- 
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate ApplicantName under SSBDetailsMonthly
	 |MemNo| 	
	 |  1  |
	 |  2  |
	 * 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate ApplicantName under SSBDetailsMonthly$")
	public void validateApplicantName_SSBDetailsMonthly(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				for(String applName : nameList)
				{
					if(!StringUtils.equals(applName, name))
					{
						eligibilityDetailsMHSumPage.validateApplicantName_SSBDetailsMonthly(name+" - Data" ,applName);		
					}
				}
				
				lastMemClicked = memNum;
			}
		}
	}
	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Valid TitleII Income
	 * 				   N/A for No Income
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Current User Attested SSB TitleII Income Under SSBDetailsMonthly
	 |MemNo|User Attested TitleII Income  | 	
	 |  1  |  N/A |
	 |  2  |  N/A |
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Current User Attested SSB TitleII Income Under SSBDetailsMonthly$")
	public void validateCurrentUserAttestedSSBTitleIIIncome_SSBDetailsMonthly(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateCurrentUserAttestedSSBTitleIIIncome_SSBDetailsMonthly(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	
	/**
	 ** @author abajpai3
	 
	 * Validate for all members
	 * Accepted Value-Any Valid SSB
	 * 				  N/A for no value
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate SSB used In Current Program Determination Under SSBDetailsMonthly
	 |MemNo|SSB Used In Current Program  | 	
	 |  1  |  N/A |
	 |  2  |  N/A |	
	 * 
	 */
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate SSB used In Current Program Determination Under SSBDetailsMonthly$")
	public void validateSSBusedInCurrentProgramDetermination_SSBDetailsMonthly(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateSSBusedInCurrentProgramDetermination_SSBDetailsMonthly(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}

	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Any Valid SSB
	 * 				   N/A for no value
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate SSB used In Last Program Determination Under SSBDetailsMonthly
	 |MemNo|SSB Used In Last Program  | 	
	 |  1  |  N/A |
	 |  2  |  N/A |
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate SSB used In Last Program Determination Under SSBDetailsMonthly$")
	public void validateSSBusedInLastProgramDetermination_SSBDetailsMonthly(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateSSBusedInLastProgramDetermination_SSBDetailsMonthly(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	
	
	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value-1.Valid Name for single document
	 * 				  2.Multiple Documentation are passed comma separated like Proof of Income,Proof of Residency for member
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate DocumentType Under RequiredDocumentation
	 |MemNo|Required Document | 	
	 |  1  |Proof of Residency|
	 |  2  |  Proof of Income |
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate DocumentType Under RequiredDocumentation$")
	public void validateDocumentType_RequiredDocumentation(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateDocumentType_RequiredDocumentation(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	
	/**
	 ** @author abajpai3
	 
	 * Validate for all members
	 * Accepted Value- Valid date in MM/DD/YYY format
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Due Date Under RequiredDocumentation
	 |MemNo|Due Date| 	
	 |  1  |      |
	 |  2  |      |
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Due Date Under RequiredDocumentation$")
	public void validateDueDate_RequiredDocumentation(DataTable table) throws Exception 
	{
		
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateDueDate_RequiredDocumentation(name+" - Data" ,scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	
	/**
	 ** @author abajpai3
	 
	 * Validate for all members
	 * Accepted Value- MAGI HH Size- any numeric value
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate MAGI HH Size For Member
	 |MemNo|Magi HH Size| 	
	 |  1  |     2      |
	 |  2  |     2      |
	 * 
	 */
	@When("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate MAGI HH Size For Member$")
	public void validateMAGIHHSizeForMember(DataTable table) throws Exception{
				
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateMAGIHHSize(name, scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	
	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- Tax HH Size- any numeric value
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Tax HH Size For Member
	 |MemNo|Tax HH Size| 	
	 |  1  |     2     |
	 |  2  |     2     |
	 * 
	 */
	
	@When("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Tax HH Size For Member$")
	public void validateTaxHHSize(DataTable table) throws Exception{
				
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateTaxHHSize(name, scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	
	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- member MAGI FPL- any numeric value
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Magi FPL For Member
	 |MemNo|Magi FPL| 	
	 |  1  | 152.86 |
	 |  2  | 152.86 | 
	 * 
	 */
	
	@When("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Magi FPL For Member$")
	public void validateMagiFPL(DataTable table) throws Exception{
				
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateMagiFPL(name, scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}
	
	/**
	 ** @author abajpai3
	
	 * Validate for all members
	 * Accepted Value- member Tax FPL- any numeric value
	 
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Tax FPL For Member
	 |MemNo|Tax FPL| 	
	 |  1  |  160  |
	 |  2  |  160  | 
	 */
	
	@When("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Tax FPL For Member$")
	public void validateTaxFPL(DataTable table) throws Exception
	{
				
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int memNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				String name = nameList.get(memNum-1);
								
				clickOnDropdownBasedOnMember(memNum,name);
				
				eligibilityDetailsMHSumPage.validateTaxFPL(name, scenarioData.get(rowIndex).get(1));
				lastMemClicked = memNum;
			}
		}
	}	
	
	/**
	 ** @author abajpai3
	
	 * Validate for all groups
	 * Accepted Value -Any numeric value
	 * 
	  
	 From Eligibility Details Page, Medicaid Household Summary Tab, Validate Monthly Premium Value For Members
	 |PBFG Group Num|Monthly Premium | 	
	 |       1      |      12.00     |
	 |       2      |                |
	 * 
	 */
	@When("^From Eligibility Details Page, Medicaid Household Summary Tab, Validate Monthly Premium Value For Members$")
	public void validatePBFGMonthlyPremium(DataTable table) throws Exception
	{
				
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int pbfgNo = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				pbfgNo = Integer.parseInt(scenarioData.get(rowIndex).get(0));				
				
				eligibilityDetailsMHSumPage.validatePBFGMonthlyPremium(pbfgNo,scenarioData.get(rowIndex).get(1));				
			}
		}
	}	
}







