package stepdefs.accountDashboard;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import pages.accountDashboard.EligibilityDetailsTaxHHSummary;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class EligibilityDetailsTaxHHSummarySteps extends SuperStepDef 
{
	int lastHHClicked = 0;
	EligibilityDetailsTaxHHSummary eligibilityDetailsTaxHHPage = new EligibilityDetailsTaxHHSummary(driver, testCaseId);
	
	public EligibilityDetailsTaxHHSummarySteps(Hook hook) 
	{
		super(hook);		
	}
	
	
	private void clickOnDropdownBasedOnHH(int hhNum) throws Exception
	{
		String name = "Household "+hhNum;
		if(lastHHClicked == 0 && hhNum !=1)
		{
			eligibilityDetailsTaxHHPage.clickOnDropDown(name);
		}
		else if (lastHHClicked != 0 && lastHHClicked !=hhNum)
		{
			eligibilityDetailsTaxHHPage.clickOnDropDown(name);
		}
	}
	
	
	/**
	 ** @author abajpai3
	 *
	 From Eligibilities Page, Click on Tax Household Summary
	 *
	 */
	
	@Given("^From Eligibilities Page, Click on Tax Household Summary$")
	public void gotoTaxHouseholdSummary() throws Exception 
	{
		
		eligibilityDetailsTaxHHPage.clickOnTaxHH_SummaryTab();

	}
	
	/**
	 ** @author Ritu
	 *
	 From Eligibilities Tax HH Page, Take Screenshot
	 *
	 */
	
	@Given("^From Eligibilities Tax HH Page, Take Screenshot$")
	public void takeScreenshot() throws Exception 
	{
		
		eligibilityDetailsTaxHHPage.takeScreenshot();

	}
	
	/**
	 ** @author abajpai3
	
	 * Validate for any/all HouseHolds
	 * Accepted Value :- HouseHold FPL - any numeric value
	 
	 * From Eligibility Details Page, Tax Household Summary Tab, For Household, Validate FPL Based  on Self Reported Income
	 |HH NUM| FPL |
	 |   1  |160.0|
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Tax Household Summary Tab, For Household, Validate FPL Based  on Self Reported Income$")
	public void validateValidateFplSelfReported(DataTable table) throws Exception 
	{
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int hhNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				hhNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));				
				String hhName = "Household "+hhNum;
				clickOnDropdownBasedOnHH(hhNum);
				
				eligibilityDetailsTaxHHPage.validateFPLBasedOnSelfReportedIncome(hhName ,scenarioData.get(rowIndex).get(1));
				lastHHClicked = hhNum;
			}
		}
	}
	
	/**
	 ** @author abajpai3

	 * Validate for any/all HouseHolds
	 * Accepted Value :- HouseHold FPL - any numeric value
	 
	 Form Eligibility Details Page, Tax Household Summary Tab, For Household, Validate FPL Used To Decide Program Eligibility
	 |HH NUM| FPL |
	 |   1  |160.0|
	 * 
	 */
	@Given("^From Eligibility Details Page, Tax Household Summary Tab, For Household, Validate FPL Used To Decide Program Eligibility$")
	public void validateFplUsedToDecideYourProgramEligibility(DataTable table) throws Exception 
	{
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int hhNum = 0;
						
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				hhNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));				
				String hhName = "Household "+hhNum;
				clickOnDropdownBasedOnHH(hhNum);
				
				eligibilityDetailsTaxHHPage.validateFPLUsedToDecYourProg(hhName ,scenarioData.get(rowIndex).get(1));
				lastHHClicked = hhNum;
			}
		}
	}
	

	/**
	 ** @author abajpai3
	 
	 * Validate for any/all HouseHolds
	 * Accepted Value :- Any Valid Program Eligibility
	 
	 Form Eligibility Details Page, Tax Household Summary Tab, For Household, Validate Program Eligibility Qualify for Programs
	 |HH NUM| MEM NO |      Program Eligibility     |
	 |   1  |    1   |  ConnectorCare Plan Type 2B  |
	 |   1  |    2   | MassHealth Family Assistance |
	 * 
	 */
	
	@Given("^From Eligibility Details Page, Tax Household Summary Tab, For Household, Validate Program Eligibility Qualify for Programs$")
	public void validateProgEligibility(DataTable table) throws Exception 
	{
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int hhNum = 0;
			int memNo = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				hhNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				
				if(StringUtils.isNotBlank(scenarioData.get(rowIndex).get(1)))
				{
					memNo = Integer.parseInt(scenarioData.get(rowIndex).get(1));	
				}
				
				String expString = scenarioData.get(rowIndex).get(2);
				String hhName = "Household "+hhNum;
				clickOnDropdownBasedOnHH(hhNum);
				
				eligibilityDetailsTaxHHPage.validateProgEligibility(hhName ,memNo,expString);
				lastHHClicked = hhNum;
			}
		}
	}
	
	/**
	 ** @author abajpai3
	
	 * Validate for any/all HouseHolds
	 * Accepted Value :- Any Valid RFI
	 
	 Form Eligibility Details Page, Tax Household Summary Tab, For Household, Validate RFIs
	 |HH NUM| MEM NO |         RFI      |
	 |   1  |    1   |Proof of Residency|
	 |   1  |    2   |  Proof of Income |
	 
	 * 
	 */
	@Given("^From Eligibility Details Page, Tax Household Summary Tab, For Household, Validate RFIs$")
	public void validateProgEligProofs(DataTable table) throws Exception 
	{
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int hhNum = 0;
			int memNo = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				hhNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				
				if(StringUtils.isNotBlank(scenarioData.get(rowIndex).get(1)))
				{
					memNo = Integer.parseInt(scenarioData.get(rowIndex).get(1));	
				}
				
				String expString = scenarioData.get(rowIndex).get(2);
				String hhName = "Household "+hhNum;
				clickOnDropdownBasedOnHH(hhNum);
				
				eligibilityDetailsTaxHHPage.validateRFI(hhName ,memNo,expString);
				lastHHClicked = hhNum;
			}
		}
	}
	
	/**
	 ** @author abajpai3
	 
	 * Validate for any/all HouseHolds
	 * Accepted Value :- Any Valid RFI Status
	
	 Form Eligibility Details Page, Tax Household Summary Tab, For Household, Validate RFI Status
	 |HH NUM| MEM NO |Status|
	 |   1  |    1   |Active|
	 |   1  |    2   |Active|
	 * 
	 */
	@Given("^From Eligibility Details Page, Tax Household Summary Tab, For Household, Validate RFI Status$")
	public void validateProgEligStatus(DataTable table) throws Exception 
	{
		List<List<String>> scenarioData = table.raw();
		int tableSize = scenarioData.size();
		
		for (int mCounter = 1; mCounter < tableSize; mCounter++) 
		{
			int rowIndex = mCounter;
			int hhNum = 0;
			int memNo = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				hhNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				
				if(StringUtils.isNotBlank(scenarioData.get(rowIndex).get(1)))
				{
					memNo = Integer.parseInt(scenarioData.get(rowIndex).get(1));	
				}
				
				String expString = scenarioData.get(rowIndex).get(2);
				String hhName = "Household "+hhNum;
				clickOnDropdownBasedOnHH(hhNum);
				
				eligibilityDetailsTaxHHPage.validateRFIStatus(hhName ,memNo,expString);
				lastHHClicked = hhNum;
			}
		}
	}

}
