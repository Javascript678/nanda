package stepdefs.accountDashboard;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import pages.accountDashboard.EligibilityDetailsApplicationSummary;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

/**
 * This Page Appears when we click on View Details link on Eligibilities Page
 * 
 * @author Vinay Kumar
 *
 */

public class EligibilityDetailsApplicationSummarySteps extends SuperStepDef {

	public EligibilityDetailsApplicationSummarySteps(Hook hook) {
		super(hook);
	}
	

	@Given("^From EligibilityDetailsApplication Page, Take Screenshot$")
    public void takeScreenshot() throws Exception{
          EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
          eligibilityDetailsPage.takeScreenshot();
    }

	/**
	 ** @author abajpai3
	 *
	 From Eligibility Details Page, Click On Family and HH Tab
	 *
	 */

	@Given("^From Eligibility Details Page, Click On Family and HH Tab$")
	public void gotoApplicationSummaryHHDetails() throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.pageLoadAndClickOnFamilyHHTab();

	}

	/**
	 ** @author abajpai3
	 *
	 From Eligibility Details Page, Click On Tax Filing Status Tab
	 *
	 */
	
	@Given("^From Eligibility Details Page, Click On Tax Filing Status Tab$")
	public void gotoApplicationSummaryTaxDetails() throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.pageLoadAndClickOnTaxFilingStatusTab();

	}

	/**
	 ** @author abajpai3
	 *
	 From Eligibility Details Page, Click On Family Income Tab
	 *
	 */
	@Given("^From Eligibility Details Page, Click On Family Income Tab$")
	public void gotoApplicationSummaryFamilyIncome() throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.pageLoadAndClickOnFamilyIncomeTab();

	}

	/**
	 ** @author abajpai3
	 *
	 From Eligibility Details Page, Click On Additional Information Tab
	 *
	 */
	@Given("^From Eligibility Details Page, Click On Additional Information Tab$")
	public void gotoApplicationSummaryAdditionalInformationDetails() throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.clickOnAdditionalInformationTab();

	}

	/**
	 ** @author abajpai3
	 *
	 From Eligibility Details Page, Click On MEC Used In PD Tab
	 *
	 */
	@Given("^From Eligibility Details Page, Click On MEC Used In PD Tab$")
	public void gotoApplicationSummaryMEC_PDDetails() throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.clickOnMECUsedInPDTab();

	}

	/**
	 * @author abajpai3
	
	 * Validate Address Email and phone under contact information page
	 * Accepted Value:- 1.Expected Address-Full or Semi Address
	 *          		2.Expected Email should be in valid format- a@a.com
	           
	 Form Eligibility Details Page, Validate data Under Contact Information Tab
	 | Address | Email | Phone |
	 |         |       |       |
	 
	 *        					 
	 */

	@Given("^From Eligibility Details Page, Validate data Under Contact Information Tab$")
	public void goToContactInformationTab(DataTable table) throws Exception {

		List<List<String>> scenarioData = table.raw();
		String address = scenarioData.get(1).get(0);
		String expectedEmail = scenarioData.get(1).get(1);
		String expectedPhone = scenarioData.get(1).get(2);

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateContactAddressUnderContactInfoTab(address);
		eligibilityDetailsPage.validateEmailUnderContactInfoTab(expectedEmail);
		eligibilityDetailsPage.validatePhoneUnderContactInfoTab(expectedPhone);

	}

	/**
	 * @author abajpai3
	 * Validate from the screen shot captured
	 
	 Form Eligibility Details Page, Validate SSN Is Masked For Members
	
	 */
	@Given("^From Eligibility Details Page, Validate SSN Is Masked For Members$")
	public void validateSSNIsMasked() throws Exception {

		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.takeScreenShot();

		for (int mCounter = 0; mCounter < memCount; mCounter++) {
			String actualSSN = eligibilityDetailsPage.getSSNForMember(mCounter + 1);
			System.out.println("actualSSN->" + actualSSN);
		}

	}

	/**
	 * @author abajpai3
	
	 * Validate for Primary applicant only
	 * Accepted Value :- Validate Expected SSN - numeric four digits value
	  
	 Form Eligibility Details Page, Under Family HH Tab, Validate Last Four Digit Of SSN As "6983" For Primary Applicant
	 */
	
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Last Four Digit Of SSN As \"(.*?)\" For Primary Applicant$")
	public void validateSSNUnderFamilyHHTab(String ssnLast4Digit) throws Exception {

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateSSNUnderFamilyHHTab(1, ssnLast4Digit);
	}

	/**
	 ** @author abajpai3
	 
	 * Validate for primary applicant only
	 * Accepted Value -: Validate Expected address - Full address or semi address 
	 
	 Form Eligibility Details Page, Under Family HH Tab, Validate Address As "HOMEADDR, 1234, HCITY, MA, 01002" for Primary Applicant
	 */
	
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Address As \"(.*?)\" for Primary Applicant$")
	public void validateAddressForHouseHold(String address) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateHHAddressUnderFamilyHHTab(1, address);

	}

	/**
	 ** @author abajpai3
	 
	 * Validate for primary applicant only
	 * Accepted Value :- 1. yes
	 *                   2. no 
	 *                   
	 Form Eligibility Details Page, Under Family HH Tab, Validate Applying for Coverage As "Yes" for Primary Applicant
	 */
	
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Applying for Coverage As \"(.*?)\" for Primary Applicant$")
	public void validateCoverageForHouseHold(String coverageApplied) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateApplyingForCoverageUnderFamilyHHTab(1, coverageApplied);

	}

	/**
	 ** @author abajpai3
	
	 * Validate for primary applicant only
	 * Accepted Value
	 * AgeFormat :- "32","32:01", "00:00:05" 
	 
	 Form Eligibility Details Page, Under Family HH Tab, Validate Date Of Birth As "09/10/1978" For Primary Applicant
	 */
	
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Date Of Birth As \"(.*?)\" For Primary Applicant$")
	public void validateDOBForHouseHold(String dob) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateDateOfBirthUnderFamilyHHTab(1, dob);

	}

	/**
	 ** @author abajpai3
	   
	   *Validate for primary applicant only
	   *Accepted Value :- Any valid citizenship/Immigration Status
	   From Eligibility Details Page, Under Family HH Tab, Validate Citizenship As "Yes" For Primary Applicant
	   
	 */
	
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Citizenship As \"(.*?)\" For Primary Applicant$")
	public void validateCitiZenShipForHouseHold(String citizenship) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateCitizenShipUnderFamilyHHTab(1, citizenship);

	}

	/**
	 **@author abajpai3
	
	 * Validate for primary applicant only
	 * Accepted Value :- 1.yes
	 * 					 2.no
	  
	 Form Eligibility Details Page, Under Family HH Tab, Validate AIAN Status As "No" For Primary Applicant
	 */
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate AIAN Status As \"(.*?)\" For Primary Applicant$")
	public void validateAIANStatusForHouseHold(String aian) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateAIANUnderFamilyHHTab(1, aian);

	}

	/**
	 **@author abajpai3
	 
	 *Validate for primary applicant only
	 *Accepted Value :- 1.yes
	 *                  2.no
	                   
	 From Eligibility Details Page, Under Family HH Tab, Validate Reasonable Accommodations As "No" For Primary Applicant
	 */
	
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Reasonable Accommodations As \"(.*?)\" For Primary Applicant$")
	public void validateReasonableAccommodationsForHouseHold(String ReasonableAcmd) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateReasonableAccommodationsUnderFamilyHHTab(1, ReasonableAcmd);

	}

	/**
	 **@author abajpai3
	 
	 *Validate for primary applicant only
	 *Accepted Value :-Expected Valid Condition
	
	 From Eligibility Details Page, Under Family HH Tab, Validate Condition As "None" For Primary Applicant
	 
	 */
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Condition As \"(.*?)\" For Primary Applicant$")
	public void validateConditionForHouseHold(String condition) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateConditionsUnderFamilyHHTab(1, condition);

	}

	/**
	 **@author abajpai3
	 *Validate for primary applicant only
	 *Accepted Value :- Expected valid accommodation
	 
	 From Eligibility Details Page, Under Family HH Tab, Validate Accommodation As "None" For Primary Applicant
	 
	 *
	 */
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Accommodation As \"(.*?)\" For Primary Applicant$")
	public void validateAccommodationForHouseHold(String accommodation) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateAccommodationUnderFamilyHHTab(1, accommodation);

	}

	/**
	 **@author abajpai3
	
	 * *Validate for primary applicant only
	 * Accepted value :-1.yes
	 * 					2.no
	  
	 Form Eligibility Details Page, Under Family HH Tab, Validate Intend To Reside As "Yes" For Primary Applicant
	 */
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Intend To Reside As \"(.*?)\" For Primary Applicant$")
	public void validateIntendToResideForHouseHold(String intendToReside) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateIntendToResideUnderFamilyHHTab(1, intendToReside);

	}

	/**
	 **@author abajpai3
	 
	 **Validate for primary applicant only
	 *Accepted Value :- 1.Yes
	 *					2.No
	
	 And From Eligibility Details Page, Under Family HH Tab, Validate Incarcerated As "No" For Primary Applicant
	 
	 */
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Incarcerated As \"(.*?)\" For Primary Applicant$")
	public void validateIncarceratedForHouseHold(String incarcerated) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateIncarceratedUnderFamilyHHTab(1, incarcerated);

	}

	/**
	 **@author abajpai3
	
	 * *Validate for primary applicant only
	 * Accepted Value :-Any valid immigration status
	 
	 Form Eligibility Details Page, Under Family HH Tab, Validate ImmigrationStatus As "Reentry Permit" For Primary Applicant
	 
	 */
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate ImmigrationStatus As \"(.*?)\" For Primary Applicant$")
	public void validateImmigrationStatusForHouseHold(String immigrationStatus) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		eligibilityDetailsPage.validateIntendToResideUnderFamilyHHTab(1, immigrationStatus);

	}

	/**
	 **@author abajpai3
	
	 *Validate for any/all members except Primary applicant
	 
	 From Eligibility Details Page, Under Family HH Tab, Validate Last Four Digit Of SSN for Members
	 |Mem Num| SSN |
	  |  2    | 2092|
	  
	 */
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Last Four Digit Of SSN for Members$")
	public void validateSSNForMembers(DataTable table) throws Exception {

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(1))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateSSNUnderFamilyHHTab(memNum, scenarioData.get(rowIndex).get(1));
			}

		}
	}

	/**
	 **@author abajpai3
	
	 *Validate for any/all members except Primary applicant
	 
	 Form Eligibility Details Page, Under Family HH Tab, Validate Address for Members
	 |Mem Num|          Address         |
	 |   2   | Same as primary applicant|
	 */
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Address for Members$")
	public void validateAddressForMembers(DataTable table) throws Exception {

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateMemberAddressUnderFamilyHHTab(memNum, scenarioData.get(rowIndex).get(1));
			}

		}
	}

	/**
	 **@author abajpai3
	
	 * Validate for any/all members except Primary applicant
	  
	 Form Eligibility Details Page, Under Family HH Tab, Validate Applying For Coverage for Members
	 |Mem Num|Applying for coverage|
	 |   2   |          Yes        |
	  
	 */
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Applying For Coverage for Members$")
	public void validateHHCoverageForMembers(DataTable table) throws Exception {

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateApplyingForCoverageUnderFamilyHHTab(memNum,
						scenarioData.get(rowIndex).get(1));
			}

		}

	}
	
	/**
	**@author abajpai3
	
	*Validate for any/all members except Primary applicant
	
	From Eligibility Details Page, Under Family HH Tab, Validate Citizenship for Members
	|Mem Num|Citizenship|
	|   2   |   Yes     |
	
	*/
	
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Citizenship for Members$")
	public void validateHHCitizenshipForMembers(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateCitizenShipUnderFamilyHHTab(memNum, scenarioData.get(rowIndex).get(1));
			}

		}
	}

	/**
	**@author abajpai3
	
	*Validate for any/all members except Primary applicant
	
	From Eligibility Details Page, Under Family HH Tab, Validate AI/AN for Members
	|Mem Num|AI/AN|
	|   2   |  No |
	*/
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate AI/AN for Members$")
	public void validateHHAIANForMembers(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateAIANUnderFamilyHHTab(memNum, scenarioData.get(rowIndex).get(1));
			}

		}
	}

	/**
	**@author abajpai3
	
	*Validate for any/all members except Primary applicant
	
	From Eligibility Details Page, Under Family HH Tab, Validate Reasonable Accommodations for Members
	|Mem Num|Reasonable Accommodations|
	|   2   |           No            |
	
	*/
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Reasonable Accommodations for Members$")
	public void validateHHReasonableAccommodationForMembers(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateReasonableAccommodationsUnderFamilyHHTab(memNum,
						scenarioData.get(rowIndex).get(1));
			}

		}
	}

	/**
	**@author abajpai3
	
	*Validate for any/all members except Primary applicant
	
	From Eligibility Details Page, Under Family HH Tab, Validate Condition for Members
	|Mem Num|Condition|
	|   2   |   None  |
	
	*/
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Condition for Members$")
	public void validateHHConditionForMembers(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateConditionsUnderFamilyHHTab(memNum, scenarioData.get(rowIndex).get(1));
			}

		}
	}

	/**
	**@author abajpai3
	
	*Validate for any/all members except Primary applicant
	
	From Eligibility Details Page, Under Family HH Tab, Validate Accommodations for Members
	|Mem Num|Reasonable Accommodations|
	|   2   |           No            |
	
	*/
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Accommodations for Members$")
	public void validateHHAccommodationsForMembers(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateConditionsUnderFamilyHHTab(memNum, scenarioData.get(rowIndex).get(1));
			}

		}
	}

	/**
	**@author abajpai3
	
	*Validate for any/all members except Primary applicant
	
	From Eligibility Details Page, Under Family HH Tab, Validate Intend To Reside for Members
	|Mem Num|IntendToReside|
	|   2   |      Yes     |
	
	*/
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Intend To Reside for Members$")
	public void validateHHIntendToResideForMembers(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateIntendToResideUnderFamilyHHTab(memNum,
						scenarioData.get(rowIndex).get(1));
			}

		}
	}

	/**
	**@author abajpai3
	
	*Validate for any/all members except Primary applicant
	
	From Eligibility Details Page, Under Family HH Tab, Validate Incarcerated Status for Members
	|Mem Num|Incarcerated|
	|   2   |      No    |
	
	*/
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Incarcerated Status for Members$")
	public void validateHHIncarceratedForMembers(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateIncarceratedUnderFamilyHHTab(memNum, scenarioData.get(rowIndex).get(1));
			}

		}
	}
	
	/**
	**@author abajpai3
	
	*Validate for any/all members except Primary applicant
	
	From Eligibility Details Page, Under Family HH Tab, Validate Relationship To for Members
	|Mem Num|Relationship|
	|   2   |    Child   |
	
	*/
	@Given("^From Eligibility Details Page, Under Family HH Tab, Validate Relationship To for Members$")
	public void validateRelationShipTo(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) 
			{
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateRelationShipTo(memNum, scenarioData.get(rowIndex).get(1));
			}

		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members
	
	From Eligibility Details Page, Under Tax Filing Status Tab, Validate Status for Members
	|Mem Num|    Status    |
	|   1   |   Tax Filer  |
	|   2   |Tax Dependent |
	
	*/
	@Given("^From Eligibility Details Page, Under Tax Filing Status Tab, Validate Status for Members$")
	public void validateTaxFilerStatus(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
				eligibilityDetailsPage.validateStatusUnderTaxFilingTab(memNum, scenarioData.get(rowIndex).get(1));

			}
		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members
	
	From Eligibility Details Page, Under Tax Filing Status Tab, Validate Filed taxes and reconciled all past APTCs for Members
	|Mem Num|Filed taxes and reconciled all past APTCs?|
	|   1   |                   N/A                    |
	
	*/
	@Given("^From Eligibility Details Page, Under Tax Filing Status Tab, Validate Filed taxes and reconciled all past APTCs for Members$")
	public void validateFilledTaxesAndReconciledAPTC(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateFiledTaxesANDReconciledAllPastAPTCsUnderTaxFilingTab(memNum,scenarioData.get(rowIndex).get(1));

		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members
	
	From Eligibility Details Page, Under Tax Filing Status Tab, Validate Attestation Date for Members
	|Mem Num|Attestation Date|
	|   1   |       N/A      |
	
	*/
	@Given("^From Eligibility Details Page, Under Tax Filing Status Tab, Validate Attestation Date for Members$")
	public void validateAttestationDate(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateAttestationDateUnderTaxFilingTab(memNum, scenarioData.get(rowIndex).get(1));

		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members
	
	From Eligibility Details Page, Under Family Income Tab, Validate Income Type for Members
	|Mem Num|        Income Type     |
	|   1   |           Job          |
	
	*/
	@Given("^From Eligibility Details Page, Under Family Income Tab, Validate Income Type for Members$")
	public void validateIncomeType(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateIncomeTypeUnderFamilyIncomeTab(memNum, scenarioData.get(rowIndex).get(1));
		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members
	
	From Eligibility Details Page, Under Family Income Tab, Validate Projected Yearly Income for Members
	|Mem Num|Projected Yearly Income|
	|   1   |       $25984.00       |
	|   2   |         $0.00         |
	
	*/
	@Given("^From Eligibility Details Page, Under Family Income Tab, Validate Projected Yearly Income for Members$")
	public void validateProjectedYearlyIncome(DataTable table) throws Exception {

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int rowCount = scenarioData.size();

		for (int mCounter = 1; mCounter < rowCount; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateProjectedIncomeUnderFamilyIncomeTab(memNum,
					scenarioData.get(rowIndex).get(1));
		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members
	
	From Eligibility Details Page, Under Family Income Tab, Validate Self Attested Montly Total Amount for Members
	|Mem Num|Self Attested Monthly Received Amount|
	|   1   |                 2165.33            |
	|   2   |                  0                 |
	
	*/
	@Given("^From Eligibility Details Page, Under Family Income Tab, Validate Self Attested Montly Total Amount for Members$")
	public void validateSelfAttestedMonthlyAmount(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateSelfAttestedTotalAmountReceivedMonthlyUnderFamilyIncomeTab(memNum,
					scenarioData.get(rowIndex).get(1));
		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members
	
	From Eligibility Details Page, Under Family Income Tab, Validate MH FPL based on self reported income for Members
	|Mem Num|MH(FPL) based on self-reported income|
	|   1   |              152.86%                |
	|   2   |              152.86%                |
	
	*/
	@Given("^From Eligibility Details Page, Under Family Income Tab, Validate MH FPL based on self reported income for Members$")
	public void validateFPL(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateMH_FPLBasedOnIncomeUnderFamilyIncomeTab(memNum,
					scenarioData.get(rowIndex).get(1));
		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members
	*
	From Eligibility Details Page, Under Family Income Tab, Validate MH FPL used to decide Program Eligibility for Members
	|Mem Num|MH(FPL) based on self-reported income|
	|   1   |              152.86%                |
	|   2   |              152.86%                |
	
	*/
	@Given("^From Eligibility Details Page, Under Family Income Tab, Validate MH FPL used to decide Program Eligibility for Members$")
	public void validateFPLtoDecideProgramEligibilty(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateMH_FPLtoDecideProgramEligibiltyUnderFamilyIncomeTab(memNum,
					scenarioData.get(rowIndex).get(1));
		}
	}
	
	/**
	**@author abajpai3
	
	*Validate data for any/all members
	
	From Eligibility Details Page, Under Additional Information Tab, Validate HAS MEC for Members
	|Mem Num|Has MEC|
	|   1   |   No  |
	|   2   |   No  |
	
	*/

	@Given("^From Eligibility Details Page, Under Additional Information Tab, Validate HAS MEC for Members$")
	public void validateHAS_MEC(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateHas_MECUnderAdditionalInformationTab(memNum,
					scenarioData.get(rowIndex).get(1));
		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members
	
	From Eligibility Details Page, Under Additional Information Tab, Validate Has Option to Enroll in Employer Health Coverage for Members
	|Mem Num|Has Option to Enroll in Employer Health Coverage|
	|   1   |                     No                         |
	|   2   |                     No                         |
	
	*/
	@Given("^From Eligibility Details Page, Under Additional Information Tab, Validate Has Option to Enroll in Employer Health Coverage for Members$")
	public void validateHAS_OptionToEnrollinHealthCoverage(DataTable table) throws Exception {
		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateHasOptionToEnrollEmployerHealthCoverageUnderAdditionalInformationTab(memNum,
					scenarioData.get(rowIndex).get(1));
		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members

	From Eligibility Details Page, Under Additional Information Tab, Validate Has Affordable Employer Sponsored Insurance ESI for Members
	|Mem Num|Has ESI|
	|   1   |   No  |
	|   2   |   No  |
	
	*/
	@Given("^From Eligibility Details Page, Under Additional Information Tab, Validate Has Affordable Employer Sponsored Insurance ESI for Members$")
	public void validateHAS_ESI(DataTable table) throws Exception {

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateHAS_ESIUnderAdditionalInformationTab(memNum,
					scenarioData.get(rowIndex).get(1));
		}
	}

	/**
	**@author abajpai3
	
	*Validate data for any/all members
	
	From Eligibility Details Page, Under MEC Used In PD Tab, Validate Federal MEC Status for Members
	|Mem Num|Has Federal MEC|
	|   1   |       No      |
	|   2   |       No      |
	
	*/
	@Given("^From Eligibility Details Page, Under MEC Used In PD Tab, Validate Federal MEC Status for Members$")
	public void validateFederalMECStatus(DataTable table) throws Exception {

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateFederalMECUnderMECUsedInPDTab(memNum, scenarioData.get(rowIndex).get(1));
		}
	}

	/**
	**@author abajpai3
	*Validate data for any/all members
	
	From Eligibility Details Page, Under MEC Used In PD Tab, Validate Federal MEC Type for Members
	|Mem Num|Federal MEC Type|
	|   1   |       No      |
	|   2   |       No      |
	
	
	**/
	@Given("^From Eligibility Details Page, Under MEC Used In PD Tab, Validate Federal MEC Type for Members$")
	public void validateFederalMECType(DataTable table) throws Exception {

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);

		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateFederalMECTypeUnderMECUsedInPDTab(memNum, scenarioData.get(rowIndex).get(1));
		}
	}

	/**
	**@author abajpai3'
	*Validate data for any/all members
	
	From Eligibility Details Page, Under MEC Used In PD Tab, Validate MMIS MEC Type for Members
	|Mem Num|MMIS MEC Type|
	|   1   |       No    |
	|   2   |       No    |
	
	
	*/
	@Given("^From Eligibility Details Page, Under MEC Used In PD Tab, Validate MMIS MEC Type for Members$")
	public void validateMMIS_MEC(DataTable table) throws Exception {

		EligibilityDetailsApplicationSummary eligibilityDetailsPage = new EligibilityDetailsApplicationSummary(driver, testCaseId);
		List<List<String>> scenarioData = table.raw();

		int tableSize = scenarioData.size();

		for (int mCounter = 1; mCounter < tableSize; mCounter++) {
			int rowIndex = mCounter;
			int memNum = 0;
			if (StringUtils.isNotBlank(scenarioData.get(rowIndex).get(0))) {
				memNum = Integer.parseInt(scenarioData.get(rowIndex).get(0));
			}

			eligibilityDetailsPage.validateMMISMECForUnderMECUsedInPDTab(memNum, scenarioData.get(rowIndex).get(1));
		}
	}

}
