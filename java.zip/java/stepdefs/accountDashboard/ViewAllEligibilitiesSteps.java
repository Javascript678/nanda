package stepdefs.accountDashboard;

import cucumber.api.java.en.Given;
import pages.accountDashboard.ViewAllEligibilitiesPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

public class ViewAllEligibilitiesSteps extends SuperStepDef{
	
	public ViewAllEligibilitiesSteps(Hook hook){
		super(hook);
	}
	
	/**
	 * @author sshriv16
	 * @throws Exception
	 * 
	 * From View All Eligibilities Page, For Eligibility ID With Variable As "CurrentEligibilityId" Validate Determination Purpose As "Batch expiration redetermination"
	 */
	
	@Given("^From View All Eligibilities Page, For Eligibility ID With Variable As \"(.*?)\" Validate Determination Purpose As \"(.*?)\"$")
	public void validateDeterminationPurpose(String eligibilityID, String purpose) throws Exception{
		ViewAllEligibilitiesPage viewAllEligibilitiesPage = new ViewAllEligibilitiesPage(driver, testCaseId);
		viewAllEligibilitiesPage.validateDeterminationPurpose(eligibilityID, purpose);
	}
	
	
}
