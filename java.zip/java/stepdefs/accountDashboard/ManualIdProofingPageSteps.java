package stepdefs.accountDashboard;
import cucumber.api.java.en.Given;
import pages.accountDashboard.ManualIdProofingPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

/**
 *  This Page Appears when we click on View All link on Account Dashboard Page
 * @author Ritu
 *
 */

public class ManualIdProofingPageSteps extends SuperStepDef{
	
	public ManualIdProofingPageSteps(Hook hook){
		super(hook);
	}
	
	
	@Given("^From Manual ID Proofing Page,Verify Personal Info$")
	public void verifyManualIdProofing() throws Exception{
		ManualIdProofingPage  manualIdProofingPage  = new ManualIdProofingPage (driver, testCaseId);
		manualIdProofingPage.verifyManualIdProofing();
	}
	

}
