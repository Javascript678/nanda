package stepdefs.accountDashboard;
import cucumber.api.java.en.Given;
import pages.accountDashboard.VerifyOldAndNewAddressPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

/**
 *  This Page Appears when we click on View All link on Account Dashboard Page
 * @author Aashita
 *
 */

public class VerifyOldAndNewAddressPageSteps extends SuperStepDef{
	
	public VerifyOldAndNewAddressPageSteps(Hook hook){
		super(hook);
	}
	
	/**
	 * 
	 From Verify Old And New Address Page, verify the address

	 */
	@Given("^From Verify Old And New Address Page, verify the address$")
	public void verifyOldAndNewAddressRFI() throws Exception{
		VerifyOldAndNewAddressPage verifyOldAndNewAddress  = new VerifyOldAndNewAddressPage(driver, testCaseId);
		verifyOldAndNewAddress.verifyOldAndNewAddress();
	}
	

}
