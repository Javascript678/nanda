package stepdefs.accountDashboard;
import cucumber.api.java.en.Given;
import pages.accountDashboard.EligibilitiesPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;


/**
 *  This Page Appears when we click on View All link on Account Dashboard Page
 * @author Ritu
 *
 */

public class DataSourceDetailPageSteps extends SuperStepDef{
	
	public DataSourceDetailPageSteps(Hook hook){
		super(hook);
	}
	
	
	//Ritu
	@Given("^From DataSourceDetail Page, Take Screenshot$")
	public void takeScreenshot() throws Exception{
		EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
		eligibilitiesPage.takeScreenshot();
	}
	
	
	
}
