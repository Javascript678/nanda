package stepdefs.accountDashboard;
import cucumber.api.java.en.Given;
import db.ElgMemberTable;
import pages.accountDashboard.EligibilitiesPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.DateUtil;
import utils.TestData;

/**
 *  This Page Appears when we click on View All link on Account Dashboard Page
 * @author Vinay Kumar
 *
 */

public class EligibilitiesPageSteps extends SuperStepDef{
	
	public EligibilitiesPageSteps(Hook hook){
		super(hook);
	}
	
	//Vinay
	@Given("^From Eligibilities Page, Go To View Details For Latest Eligibilites$")
	public void clickOnViewDetailsDropDownMenu() throws Exception{
		EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
		eligibilitiesPage.pageLoadAndClickOnThreeDotMenuForLatestElg();
		eligibilitiesPage.clickOnViewDetailsDropDownMenu();
	}
	
	//Vinay
	@Given("^From Eligibilities Page, Go To View Data Source Details For Latest Eligibilites$")
	public void clickOnViewDataSourceDetailsDropDownMenu() throws Exception{
		EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
		eligibilitiesPage.pageLoadAndClickOnThreeDotMenuForLatestElg();
		eligibilitiesPage.clickOnViewDataSourceDetailsDropDownMenu();
	}
	
	/*Ritu
     
     From Eligibilities Page, Validate Name Of The User As "Shubhank Garg" For Eligibilites With Variable Name As "ElgId_MMIS2_Validation"
     
     */
     @Given("^From Eligibilities Page, Validate Name Of The User As \"(.*?)\" For Eligibilites With Variable Name As \"(.*?)\"$")
     public void validateUserName(String userName, String eligId) throws Exception{
           String eligibilityId = TestData.getTempTestData(eligId, featureFileName);
           EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
           eligibilitiesPage.validateUserName(userName,eligibilityId);
     }
     
     
     
     
     /*Ritu
     
     From Eligibilities Page, Validate User Type As " " For Eligibilites With Variable Name As "ElgId_MMIS2_Validation"
     
     */
     @Given("^From Eligibilities Page, Validate User Type As \"(.*?)\" For Eligibilites With Variable Name As \"(.*?)\"$")
     public void validateUserType(String userType, String eligId) throws Exception{
           EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
           String eligibilityId = TestData.getTempTestData(eligId, featureFileName);
           eligibilitiesPage.validateTypeOfUser(userType,eligibilityId);
     }
     
     
     
     /*Ritu
     
     From Eligibilities Page, Validate Date For Eligibilites With Variable Name As "ElgId_MMIS2_Validation"
     
     */
     @Given("^From Eligibilities Page, Validate Date For Eligibilites With Variable Name As \"(.*?)\"$")
     public void validateDate( String eligId) throws Exception{
           ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
           EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
           
           String eligibilityId = TestData.getTempTestData(eligId, featureFileName);
           String date = elgMemberTable.getCreationDate(eligibilityId,0);
           String expectedCreationDate =DateUtil.getDateInUIFormatUsingPattern(date,DateUtil.dbDatePattern);
           eligibilitiesPage.validateDateAndTime(expectedCreationDate ,eligibilityId);
     }
     


     /*Ritu
     
     From Eligibilities Page, Validate EligibilityStatus As " " For Eligibilites With Variable Name As "ElgId_MMIS2_Validation"
     
     */
     @Given("^From Eligibilities Page, Validate EligibilityStatus As \"(.*?)\" For Eligibilites With Variable Name As \"(.*?)\"$")
     public void validateEligibilityStatus(String eligibilityStatus, String eligId) throws Exception{
           EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
           String eligibilityId = TestData.getTempTestData(eligId, featureFileName);
           eligibilitiesPage.validateEligibilityStatus(eligibilityStatus,eligibilityId);
     }
     
     
     
     
     /*Ritu

     From Eligibilities Page, Validate Determination As " " For Eligibilites With Variable Name As "ElgId_MMIS2_Validation"
     
     */
     @Given("^From Eligibilities Page, Validate Determination As \"(.*?)\" For Eligibilites With Variable Name As \"(.*?)\"$")
     public void validateDetermination(String determination, String eligId) throws Exception{
           EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
           String eligibilityId = TestData.getTempTestData(eligId, featureFileName);
           eligibilitiesPage.validateDetermination(determination,eligibilityId);
           
     }
     
     
     
     /*Ritu
     
     From Eligibilities Page, Validate OEP As "2019" For Eligibilites With Variable Name As "ElgId_MMIS2_Validation"
     
     */
     @Given("^From Eligibilities Page, Validate OEP As \"(.*?)\" For Eligibilites With Variable Name As \"(.*?)\"$")
     public void validateOEP(String oep, String eligId) throws Exception{
           EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
           String eligibilityId = TestData.getTempTestData(eligId, featureFileName);
           eligibilitiesPage.validateOEP(oep,eligibilityId);
           
     }
     
     
     
     /*Ritu
     
     From Eligibilities Page, Validate ViewDetail Present For Eligibilites With Variable Name As "ElgId_MMIS1_Validation"
     
     */
     @Given("^From Eligibilities Page, Validate ViewDetail Present For Eligibilites With Variable Name As \"(.*?)\"$")
     public void validateViewDetail(String eligId) throws Exception{
           EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
           String eligibilityId = TestData.getTempTestData(eligId, featureFileName);
           eligibilitiesPage.validateViewDetailslink(eligibilityId);
           
     }
     
     
     /*Ritu
     
     From Eligibilities Page, Validate ViewDataSourceDetail Present For Eligibilites With Variable Name As  "ElgId_MMIS1_Validation"
     
     */
     @Given("^From Eligibilities Page, Validate ViewDataSourceDetail Present For Eligibilites With Variable Name As \"(.*?)\"$")
     public void validateViewDataSourceDetail(String eligId) throws Exception{
           EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
           String eligibilityId = TestData.getTempTestData(eligId, featureFileName);
           eligibilitiesPage.validateViewDataSourceDetailslink(eligibilityId);
           
     }
     


     //Ritu
	@Given("^From Eligibilities , Take Screenshot$")
     public void takeScreenshot() throws Exception{
           EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
           eligibilitiesPage.takeScreenshot();
     }
	
	/*Ritu
     * From Eligibilities Page, Click On CheckBox For Eligibilites With Variable Name As "ElgId_MMIS1_Validation"
     */
     @Given("^From Eligibilities Page, Click On CheckBox For Eligibilites With Variable Name As \"(.*?)\"$")
     public void clickOnEligibilityChkBox(String eligIdVariableName) throws Exception{
           EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
           String eligibilityId = TestData.getTempTestData(eligIdVariableName, featureFileName);
           eligibilitiesPage.clickOnChkBoxForEligibility(eligibilityId);
           
     }
     
     /*Ritu
      * From Eligibilities Page, Click On Compare Changes 
      */
      @Given("^From Eligibilities Page, Click On Compare Changes$")
      public void clickOnCompareChanges(String eligId) throws Exception{
            EligibilitiesPage eligibilitiesPage = new EligibilitiesPage(driver, testCaseId);
            eligibilitiesPage.clickOnCompareButton();
            
      }




}
