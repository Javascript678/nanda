package stepdefs.accountDashboard;
import cucumber.api.java.en.Given;
import pages.accountDashboard.AccountDashboardLandingPage;
import pages.login.HomePage;
import pages.manageCustomer.FindACustomerPage;
import pages.myEligibility.EligibilityApplicationPage;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import utils.TestData;

public class AccountDashboardSteps extends SuperStepDef{
	
	public AccountDashboardSteps(Hook hook){
		super(hook);
	}
	
	/**@author vkuma212
	 
	 From Account Dashboard, Take Screenshot
	 
	 */
	@Given("^From Account Dashboard, Take Screenshot$")
	public void takeScreenshot() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.takeScreenshot();
	}
	
	/** @ppinho
	* From Account Dashboard Page, Handle Alert Dialog If Present
	*/
	@Given("^From Account Dashboard Page, Handle Alert Dialog If Present$")
	public void handleWarningDialogIfPresent() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.handleAlertDialogIfPresent();
	}

	@Given("^From Account Dashboard, Go to In Progress Application$")
    public void goToInProgressApplication() throws Exception {       
          AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
          accountDashboardLandingPage.goToInProgressApplication();
    }

	/**@author vkuma212
	 
	 From Account Dashboard, Validate Aid Cat For Member "1" As "M1"
	 
	 */
	@Given("^From Account Dashboard, Validate Aid Cat For Member \"(.*?)\" As \"(.*?)\"$")
	public void validateAidCatForMember(String memNo, String aidCat) throws Exception {
		int memIndex = Integer.parseInt(memNo)-1;
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.validateAidCatForMember(memIndex, aidCat);
	}
	
	//@author vkuma212
	@Given("^From Account Dashboard Left Menu, Go to Eligibility Application Page$")
	public void goToEligibilityApplicationPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Address Change Page$")
	public void goToAddressChangePage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnAddressChange();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Update SSN Page$")
	public void goToUpdateSSNPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnUpdateSSN();
	}
		
	@Given("^From Account Dashboard Left Menu, Go to Disability Info Page$")
	public void goToDisabiityInfoPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnDisabilityInfo();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Medically Frail Info Page$")
	public void goToMedicallyFrailInfoPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnMedicallyFrailInfo();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Manage Authorized Representative Page$")
	public void goToManageAuthorizedRepresentativePage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnManageAuthorizedRepresentative();
	}
	
		
	@Given("^From Account Dashboard Left Menu, Go to Admin Closure Page$")
	public void goToAdminClosurePage() throws Exception {
		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnAdminClosure();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Admin Closure History Page$")
	public void goToAdminClosureHistoryPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnAdministrativeClosingHistory();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to SEP Document Verification$")
	public void goToSEPDocumentVerificationPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnSEPDocumentVerfication();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Override Eligibility Page$")
	public void goToOverrideEligibilityPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnOverrideEligibility();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to VLP Details Page$")
	public void goToVLPDetailsPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnVLPDetails();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Duplicate Dashboard Page$")
	public void goToDuplicateDashboardPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnApplicationLevelDupDashboard();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Manual ID Proofing Page$")
	public void goToManualIdProofingPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnManualIDProofing();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Assister Page$")
	public void goToAssisterPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnAssister();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Invite Client Page$")
	public void goToInviteClientPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnInviteClient();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Medicaid Renewals Page$")
	public void goToMedicaidRenewalsPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnMedicaidRenewals();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Transaction History Page$")
	public void goToTransactionHistoryPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnTransactionHistory();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Retroactive Enrollments Page$")
	public void goToRetroactiveEnrollmentsPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnRetroactiveEnrollment();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Enrollments Page$")
	public void goToEnrollmentsPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnEnrollments();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Admin SEP Details Page$")
	public void goToAdminSEPDetailsPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnAdminSEPDetails();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to View IRS Authorization Page$")
	public void goToViewIRSAuthorizationPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnViewIRSAuthorization();
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Certificate Of Hardship Exemptions Page$")
	public void goToCertificateOfHardshipExemptionsPage() throws Exception {
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnCertificateofHardshipExemptions();
	}
	
	@Given("^From Account Dashboard, Go to RFIs Page$")
	public void goToRFIsPage() throws Exception {		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.pageLoadAndClickOnActiveRFILink();
	}
	
	@Given("^From Account Dashboard, Go to Latest Eligibility View All")
	public void goToLatestEligibilityViewAll() throws Exception {		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.pageLoadAndGoToLatestEligibilityViewAll();
	}
	
	@Given("^From Account Dashboard, Go to Latest Enrollemnt View All")
	public void goToLatestEnrollmentyViewAll() throws Exception {		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.pageLoadAndGoToLatestEnrollmentViewAll();
	}
	
	@Given("^From Account Dashboard Left Menu, Go To Eligibility Application Page And Click On Edit Link$")
    public void clickOnEditLink() throws Exception {
         
           String year = globalData.get("ApplicationCreationYear");
           AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
           accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
           EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
           eligibilityApplicationPage.performActionclickOnEditLink(year);
    }

	@Given("^From Account Dashboard Left Menu, Go to Current Year Eligibility Result Page$")
	public void goToCurrentYearEligibilityResultPage() throws Exception {
		String year = globalData.get("ApplicationCreationYear");
		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
		
		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		eligibilityApplicationPage.pageLoadAndClickOnEligibilityDetailsLink(year);		
	}
	
	@Given("^From Account Dashboard Left Menu, Go to Change Your Info Page$")
	public void goToChangeInfoPage() throws Exception {
		String year = globalData.get("ApplicationCreationYear");
		
		AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
		accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
		
		EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
		eligibilityApplicationPage.performActionToGoToReportAChangePage(year);
		
	}
	
	@Given("^From Account Dashboard Left Menu, Click On Undo Link And Go to Current Year Eligibility Result Page$")
    public void clickOnUndoLink() throws Exception {
          //String appDate = new DualTable(conn,"").getSysDate();
          //appDate = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.dbDatePattern);
		String year = globalData.get("ApplicationCreationYear");
          
          AccountDashboardLandingPage accountDashboardLandingPage = new AccountDashboardLandingPage(driver, testCaseId);
           accountDashboardLandingPage.usingLeftMenuClickOnViewUnlockEligibility();
          EligibilityApplicationPage eligibilityApplicationPage = new EligibilityApplicationPage(driver, testCaseId);
          eligibilityApplicationPage.performActionUndoChangesLink(year);
          eligibilityApplicationPage.pageLoadAndClickOnEligibilityDetailsLink(year);
          
    }

}
