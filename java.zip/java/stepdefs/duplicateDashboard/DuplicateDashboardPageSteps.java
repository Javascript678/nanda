package stepdefs.duplicateDashboard;


import cucumber.api.java.en.When;
import db.ElgMemberTable;
import db.DuplicateMemberTable;
import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;
import pages.duplicateDashboard.DuplicateDashboardPage;
import utils.TestData;



public class DuplicateDashboardPageSteps extends SuperStepDef {

	public DuplicateDashboardPageSteps(Hook hook){
			super(hook);
	}
	
	/**@author Paul
	 * 
	 * 
	  From Duplicate Dashboard Page, Ignore Duplicate For Members "1,2,3,4"
	 *
	 */
	
	@When("^From Duplicate Dashboard Page, Ignore Duplicate For Members \"(.*?)\"$")
	public void selectOverrideDetails(String memNos) throws Exception {
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		String[] arrMemNos = memNos.split(",");
						
		DuplicateDashboardPage duplicateDashboard = new DuplicateDashboardPage (driver, testCaseId);	
		DuplicateMemberTable duplicateMember = new DuplicateMemberTable (conn, testCaseId);
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		for (int mCounter = 0; mCounter < arrMemNos.length; mCounter++) {
			int memIndex = Integer.parseInt(arrMemNos[mCounter]) - 1;
			
			String memFName = elgMemberTable.getFirstName(elgId, memIndex);
			String memLName = elgMemberTable.getLastName(elgId, memIndex);
			
			String id = duplicateMember.getId(elgId, memFName, memLName);
			int rowCount = duplicateMember.getDupMemRowCount(elgId, memFName, memLName);
					
			for(int i = 0; i < rowCount; i++){
				duplicateDashboard.clickOnIgnoreDuplicate(arrMemNos[mCounter], id);
				id = Integer.toString(Integer.parseInt(id) - 1);
			}
		}				
	}
	
	/**@author ppinho
	 * Accepted Value :- MemNo :- 1,2,3,4
	 * 					 Member Overridden   :- Yes, No
	 
	 From Duplicate Dashboard Page, For Member "1", Validate Member Overridden As "Yes"
	 
	 */
	@When("^From Duplicate Dashboard Page, For Member \"(.*?)\", Validate Member Overridden As \"(.*?)\"$")
	public void validateAidCategoryForMember(String memNos, String memOverridden) throws Exception{	
		String elgId = TestData.getTempTestData("CurrentEligibilityId", featureFileName);
		String[] arrMemNos = memNos.split(",");
		
		DuplicateDashboardPage duplicateDashboard = new DuplicateDashboardPage (driver, testCaseId);
		DuplicateMemberTable duplicateMember = new DuplicateMemberTable (conn, testCaseId);
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		
		for (int mCounter = 0; mCounter < arrMemNos.length; mCounter++) {
			int memIndex = Integer.parseInt(arrMemNos[mCounter]) - 1;
			
			String memFName = elgMemberTable.getFirstName(elgId, memIndex);
			String memLName = elgMemberTable.getLastName(elgId, memIndex);
			
			String id = duplicateMember.getId(elgId, memFName, memLName);
			int rowCount = duplicateMember.getDupMemRowCount(elgId, memFName, memLName);			

			for(int i = 0; i < rowCount; i++){
				duplicateDashboard.validateOverridenForMember(arrMemNos[mCounter], id, memOverridden);
				id = Integer.toString(Integer.parseInt(id) - 1);
			}
		}
		
	}
	
	/**@author ppinho
	 
	 From Duplicate Dashboard Page, Click On Rerun Duplicate Check Button
	 
	 */
	@When("^From Duplicate Dashboard Page, Click On Rerun Duplicate Check Button$")
	public void rerunDuplicateCheck() throws Exception{	
		DuplicateDashboardPage duplicateDashboard = new DuplicateDashboardPage (driver, testCaseId);
		duplicateDashboard.clickOnRerunDupCheckBtn();		
	}

}
