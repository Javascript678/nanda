package db;

import java.sql.Connection;

public class DORreferralRecordTrackerTable extends SuperTable {

	private String tableName = "MAHX_OWN.DOR_REFERRAL_RECORD_TRACKER";
	private String tableNameToShowOnUI = "DOR_REFERRAL_RECORD_TRACKER";
	private String idColumnName = "ID";
	private String statusColumnName = "STATUS";
	private String RefUnitIdColumnName = "REF_UNIT_ID";
	
	public DORreferralRecordTrackerTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}	
	
	private String getColumnValue(String refUnitId, String columnName) throws Exception{
		String query = "SELECT * " 
				     + " FROM " + tableName
				     + " WHERE " + RefUnitIdColumnName + " = " + refUnitId;
		return getCellDataFromDB(query, columnName);
	}
	
	public String getId(String RefUnitIdColumnName, String fName, String lName) throws Exception{
		return getColumnValue(RefUnitIdColumnName, idColumnName);
	}
	
	private String getStatus(String elgId, String fName, String lName) throws Exception{
		String elgMemId = new ElgMemberTable(conn, testCaseId).getMemberReferenceId(elgId, fName, lName);
		String id = new DORreferralUnitTable(conn, testCaseId).getId(elgMemId, fName, lName);
		return getColumnValue(id, statusColumnName);
	}
		
	public void validateStatus(String elgId, String fName, String lName, String expStatus) throws Exception{
		String actualStatus = getStatus(elgId, fName, lName);
		validateDBFieldValue(tableNameToShowOnUI, "STATUS", expStatus, actualStatus);
	}

}
