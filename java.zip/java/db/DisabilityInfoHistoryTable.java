package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import utils.DateUtil;

public class DisabilityInfoHistoryTable extends SuperTable {

	private String tableName = "MAHX_OWN.DISABILITY_INFO_HISTORY";
	private String tableNameOnUI = "DISABILITY_INFO_HISTORY";
	private String isDisableColumnName = "IS_DISABLED";
	private String maHubRequestResponseIdColumnName = "MA_HUB_REQUEST_RESPONSE_ID";
	private String mmisMemberReferenceIdColumnName = "MMIS_MEMBER_REFERENCE_ID";
	private String disabilitySourceColumnName = "DISABILITY_SOURCE";
	
	
	public DisabilityInfoHistoryTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getMmisMemberReferenceId(String userProfileRefId, int memIndex, String init) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memIndex);
		
		MaHubRequestResponseTable maHubRequestResponseTable = new MaHubRequestResponseTable(conn, testCaseId);
		String id = maHubRequestResponseTable.getId(elgId, memRefId, init);

		return getMmisMemberReferenceIdColumnValue(id);
	}
	
	public void ccaRenewalDisabilityUpdateQuery(String userProfileRefId, int memInd, String isDisabled) throws Exception {	
		updateIsDisabledColumn(getMmisMemberReferenceId(userProfileRefId, memInd, "CCA_RENEWAL"), isDisabled);
	}
	
	private String getMmisMemberReferenceIdColumnValue(String id) throws Exception {
		String query = "SELECT * " +
					    " FROM " + tableName +
					    " WHERE " + disabilitySourceColumnName + " = 'FDSH_RRV'" +
					    " AND " + maHubRequestResponseIdColumnName + " IN (" + id + ")";

		return getCellDataFromDB(query, mmisMemberReferenceIdColumnName);
	}
	
	public void updateIsDisabledColumn(String mmisMemberReferenceId, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + isDisableColumnName + " = '" + columnValue + "'" + 
					   " WHERE " + mmisMemberReferenceIdColumnName + " IN (" + mmisMemberReferenceId + ")";

		executeQuery(query);
	}
	
}
