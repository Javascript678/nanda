package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class ElgMemberIncomeFtiTable extends SuperTable
{
	
	private String tableName = "MAHX_OWN.ELG_MEMBER_INCOME_FTI";
	private String ftiReportedIncomeColumnName = "FTI_REPORTED_INCOME";
	private String taxMagiAmtColumnName = "TAX_MAGI_AMOUNT ";
	private String taxSSBenifitsColumnName = "TAX_SOCIALSECURITY_BENEFITS";
	private String elgMemberIdColumnName ="ELG_MEMBER_ID ";
	
	public ElgMemberIncomeFtiTable(Connection conn, String testCaseId) 
	{
		super(conn, testCaseId);
	}
	
	public void updateAmount(String elgId, String fName, String lName,String ftiReportedIncomeValue,String taxMagiAmtValue,String taxSSBenifitsColumnValue ) throws Exception {
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemberId = elgMemberTable.getId(elgId ,fName,lName);

		 
			 List<String> columnNames = new ArrayList<String>();
			 List<String> columnValues = new ArrayList<String>();
			 columnNames.add(ftiReportedIncomeColumnName );
			 columnNames.add(taxMagiAmtColumnName );
			 columnNames.add(taxSSBenifitsColumnName);
			 columnValues.add(ftiReportedIncomeValue);
			 columnValues.add(taxMagiAmtValue);
			 columnValues.add(taxSSBenifitsColumnValue);
				
			 updateVarCharColumnValues(elgMemberId , columnNames, columnValues);
		}
	
	
	private void updateVarCharColumnValues(String elgMemberId, List<String> columnNames, List<String> columnValues) throws Exception{
		String query = "UPDATE " 
				+ tableName + " SET ";
		for(int columnCounter=0; columnCounter < columnNames.size(); columnCounter++){
			if(columnCounter==( columnNames.size() - 1 ))
			{
				query = query + columnNames.get(columnCounter) + " = " + columnValues.get(columnCounter)  + " ";
			}else {
				query = query + columnNames.get(columnCounter) + " =  " + columnValues.get(columnCounter)  + "  ,";
			}
			
		}
		query = query + " WHERE "+ elgMemberIdColumnName +" = "+elgMemberId;
		
		executeQuery(query);
	}
	
	
}
