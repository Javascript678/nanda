package db;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import appdata.common.SqlCredentials;
import stepdefs.support.Hook;
import utils.HttpsClient;
import utils.StoreExcelUtil;
import utils.StoreXMLUtil;
import utils.TestReport;

public class SuperTable {
	protected Connection conn;
	protected String testCaseId;
	protected Logger logger;
	private String htmlReportErrorSyntax = "Error on Updating HTML Result for DB Query";

	// public static void main(String[] args) {
	// ResourceBundle rb = ResourceBundle.getBundle("GlobalData");
	// }
	//
	private String globalDataPath = "Test_Data" + File.separator
			+ "GlobalData.properties";

	public SuperTable(Connection conn, String testCaseId) {
		this.conn = conn;
		this.testCaseId = testCaseId;
		logger = Logger.getLogger(testCaseId);
	}
	
	

	public SuperTable() {
		super();
	}



	public void closeConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void executeQuery(String query) throws Exception {
		Properties prop = new Properties();
		FileInputStream inpuput = new FileInputStream(new File(globalDataPath));
		prop.load(inpuput);
		
		String ipAddress = prop.getProperty("AWS_Server_Domain").trim();
		System.out.println(ipAddress);
		String username = prop.getProperty("username").trim().toLowerCase();
		String password = prop.getProperty("password").trim();
		
		SqlCredentials sqlCredentials = new SqlCredentials();
		
		sqlCredentials.dbInstance = "aws-db-generic";
		sqlCredentials.dbCredential = prop.getProperty("DbCredentialId").toLowerCase();
		sqlCredentials.maxRecords = prop.getProperty("MaxRecords").toLowerCase();
		sqlCredentials.sqlScript = null;
		
		sqlCredentials.sqlScript = query;
		logger.info("Executing querry [" + query + "]");
		HttpsClient httpClient = new HttpsClient();		
		httpClient.runUpdateQueryMS(ipAddress, username, password, SqlCredentials.sqlSelectRequestData(sqlCredentials));
		
	}
	
//	public void executeQuery(String query) throws Exception {
//		boolean status = true;
//		try {
//			logger.info("Executing querry [" + query + "]");
//			Statement statement = conn.createStatement();
//			statement.execute(query);
//			statement.close();
//			conn.commit();
//		} catch (Exception e) {
//			status = false;
//
//		}
//
//		if (status == false) {
//			throw new Exception("SQLSyntaxErrorException in query [" + query
//					+ "]");
//		}
//	}
//	
//	/*just to check only noy used*/
//	public static void main(String[] args) throws Exception {
//		
//		SuperTable s = new SuperTable();
//		String query = "select ID from mahx_own.elg_member where eligibility_id= 292236775";
//		
//		s.getCellDataFromDB(query, "ID");		
//		
//	}
	
	public String getCellDataFromDB(String query, String columnName)
			throws Exception {
		
		
		Properties prop = new Properties();
		FileInputStream inpuput = new FileInputStream(new File(globalDataPath));
		prop.load(inpuput);
		
		String ipAddress = prop.getProperty("AWS_Server_Domain").trim();
		System.out.println(ipAddress);
		String username = prop.getProperty("username").trim().toLowerCase();
		String password = prop.getProperty("password").trim();
		
		SqlCredentials sqlCredentials = new SqlCredentials();
		
		sqlCredentials.dbInstance = "aws-db-generic";
		sqlCredentials.dbCredential = prop.getProperty("DbCredentialId").toLowerCase();
		sqlCredentials.maxRecords = prop.getProperty("MaxRecords").toLowerCase();
		sqlCredentials.sqlScript = null;
		
		sqlCredentials.sqlScript = query;
		logger.info("Executing querry [" + query + "]");
		HttpsClient httpClient = new HttpsClient();		
		JSONObject response = httpClient.runSelectQueryMS(ipAddress, username, password, SqlCredentials.sqlSelectRequestData(sqlCredentials));
		//System.out.println("res " + response.toString());
		JSONArray name = response.getJSONArray("names");
		int index = 0;
		for (index = 0; index < name.length(); index++) {
			if (name.getString(index).equalsIgnoreCase(columnName)) {
				break;
			}
		}
		
		String cellValue = null;
		
		if (index < name.length()) {
			
			cellValue = response.getJSONArray("values").getJSONArray(0).getString(index);
			
		}
		System.err.println("dsasda  " + cellValue);
		
		
		return cellValue;

	}

//	public String getCellDataFromDB(String query, String columnName)
//			throws Exception {
//
//		boolean status = true;
//		String cellValue = null;
//
//		try {
//			logger.info("Running querry [" + query + "] and trying to fetch ["
//					+ columnName + "] value");
//			PreparedStatement statement = conn.prepareStatement(query);
//			ResultSet rs = statement.executeQuery(query);
//			while (rs.next()) {
//				cellValue = rs.getString(columnName.toUpperCase());
//			}
//
//		} catch (Exception e) {
//			status = false;
//
//		}
//
//		if (status == false) {
//			throw new Exception("SQLSyntaxErrorException in query [" + query
//					+ "] and ColumnName [" + columnName + "]");
//		}
//
//		return cellValue;
//
//	}

	public String getCellDataFromDB(String query, int rowIndex,
			String columnName) throws Exception {
		Properties prop = new Properties();
		FileInputStream inpuput = new FileInputStream(new File(globalDataPath));
		prop.load(inpuput);
		
		String ipAddress = prop.getProperty("AWS_Server_Domain").trim();
		System.out.println(ipAddress);
		String username = prop.getProperty("username").trim().toLowerCase();
		String password = prop.getProperty("password").trim();
		
		SqlCredentials sqlCredentials = new SqlCredentials();
		
		sqlCredentials.dbInstance = "aws-db-generic";
		sqlCredentials.dbCredential = prop.getProperty("DbCredentialId").toLowerCase();
		sqlCredentials.maxRecords = prop.getProperty("MaxRecords").toLowerCase();
		sqlCredentials.sqlScript = null;
		
		sqlCredentials.sqlScript = query;
		logger.info("Executing querry [" + query + "]");
		HttpsClient httpClient = new HttpsClient();		
		JSONObject response = httpClient.runSelectQueryMS(ipAddress, username, password, SqlCredentials.sqlSelectRequestData(sqlCredentials));
		//System.out.println("res " + response.toString());
		JSONArray name = response.getJSONArray("names");
		int index = 0;
		for (index = 0; index < name.length(); index++) {
			if (name.getString(index).equalsIgnoreCase(columnName)) {
				break;
			}
		}
		
		String cellValue = null;
		
		if (index < name.length()) {
			
			cellValue = response.getJSONArray("values").getJSONArray(rowIndex).getString(index);
			
		}
		System.err.println("dsasda  " + cellValue);
		
		
		return cellValue;
	}
	
	
//	public String getCellDataFromDB(String query, int rowIndex,
//			String columnName) throws Exception {
//		boolean status = true;
//		String cellValue = null;
//
//		try {
//			logger.info("Running querry [" + query + "] and trying to fetch ["
//					+ columnName + "] value from Row No [" + (rowIndex + 1)
//					+ "]");
//			PreparedStatement statement = conn.prepareStatement(query);
//			ResultSet rs = statement.executeQuery(query);
//			for (int rowCounter = 0; rowCounter <= rowIndex; rowCounter++) {
//				rs.next();
//				cellValue = rs.getString(columnName.toUpperCase());
//			}
//		} catch (Exception e) {
//			status = false;
//		}
//		if (status == false) {
//			throw new Exception("SQLSyntaxErrorException in query [" + query
//					+ "] Row No [" + (rowIndex + 1) + "] and ColumnName ["
//					+ columnName + "]");
//		}
//		return cellValue;
//	}

	
	public int getRowCount(String query) throws Exception {
		Properties prop = new Properties();
		FileInputStream inpuput = new FileInputStream(new File(globalDataPath));
		prop.load(inpuput);
		
		String ipAddress = prop.getProperty("AWS_Server_Domain").trim();
		System.out.println(ipAddress);
		String username = prop.getProperty("username").trim().toLowerCase();
		String password = prop.getProperty("password").trim();
		
		SqlCredentials sqlCredentials = new SqlCredentials();
		
		sqlCredentials.dbInstance = "aws-db-generic";
		sqlCredentials.dbCredential = prop.getProperty("DbCredentialId").toLowerCase();
		sqlCredentials.maxRecords = prop.getProperty("MaxRecords").toLowerCase();
		sqlCredentials.sqlScript = null;
		
		sqlCredentials.sqlScript = query;
		logger.info("Executing querry [" + query + "]");
		HttpsClient httpClient = new HttpsClient();		
		JSONObject response = httpClient.runSelectQueryMS(ipAddress, username, password, SqlCredentials.sqlSelectRequestData(sqlCredentials));
		//System.out.println("res " + response.toString());
		
		return response.getJSONArray("values").length();
		
	}
	
//	public int getRowCount(String query) throws Exception {
//		boolean status = true;
//		int rowCounter = 0;
//
//		try {
//			logger.info("Running querry [" + query
//					+ "] and trying to fetch Column Count");
//			PreparedStatement statement = conn.prepareStatement(query);
//			ResultSet rs = statement.executeQuery(query);
//			while (rs.next()) {
//				rowCounter++;
//			}
//		} catch (Exception e) {
//			status = false;
//		}
//		if (status == false) {
//			throw new Exception("SQLSyntaxErrorException in query [" + query
//					+ "] ");
//		}
//		return rowCounter;
//	}

	public ArrayList<String> getColumnDataFromDB(String query, String columnName) throws JSONException, IOException {
		ArrayList<String> columnValues = new ArrayList<String>();
		
		
		Properties prop = new Properties();
		FileInputStream inpuput = new FileInputStream(new File(globalDataPath));
		prop.load(inpuput);
		
		String ipAddress = prop.getProperty("AWS_Server_Domain").trim();
		System.out.println(ipAddress);
		String username = prop.getProperty("username").trim().toLowerCase();
		String password = prop.getProperty("password").trim();
		
		SqlCredentials sqlCredentials = new SqlCredentials();
		
		sqlCredentials.dbInstance = "aws-db-generic";
		sqlCredentials.dbCredential = prop.getProperty("DbCredentialId").toLowerCase();
		sqlCredentials.maxRecords = prop.getProperty("MaxRecords").toLowerCase();
		sqlCredentials.sqlScript = null;
		
		sqlCredentials.sqlScript = query;
		logger.info("Executing querry [" + query + "]");
		HttpsClient httpClient = new HttpsClient();		
		JSONObject response = httpClient.runSelectQueryMS(ipAddress, username, password, SqlCredentials.sqlSelectRequestData(sqlCredentials));
		//System.out.println("res " + response.toString());
		JSONArray name = response.getJSONArray("names");
		int index = 0;
		for (index = 0; index < name.length(); index++) {
			if (name.getString(index).equalsIgnoreCase(columnName)) {
				break;
			}
		}
		
		String cellValue = null;
		
		if (index < name.length()) {
			
//			cellValue = response.getJSONArray("values").getJSONArray(0).getString(index);
			JSONArray values = response.getJSONArray("values");
			for (int i = 0; i < values.length(); i++) {
				
				columnValues.add(values.getJSONArray(i).getString(index));
				
			}
			
		}
		
		
		return columnValues;
	}
	
//	public ArrayList<String> getColumnDataFromDB(String query, String columnName) {
//		ArrayList<String> columnValues = new ArrayList<String>();
//
//		try {
//			PreparedStatement statement = conn.prepareStatement(query);
//			ResultSet rs = statement.executeQuery(query);
//			while (rs.next()) {
//
//				String columnValue = rs.getString(columnName.toUpperCase());
//				columnValues.add(columnValue);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return columnValues;
//	}

	public HashMap<String, ArrayList<String>> getMultiColumnDataFromDB(
			String query, String columnNames[]) throws JSONException, IOException {
		HashMap<String, ArrayList<String>> columnsValues = new HashMap<String, ArrayList<String>>();

		for (int columnCounter = 0; columnCounter < columnNames.length; columnCounter++) {
			String columnName = columnNames[columnCounter];
			ArrayList<String> columnsValue = getColumnDataFromDB(query,
					columnName);
			columnsValues.put(columnName, columnsValue);
		}
		return columnsValues;
	}

	public void storeDBTableIntoExcel(String query, String fileName)
			throws Exception {
		boolean status = true;
		String testReportFolder = Hook.testReportFolder;
		String excelLink = null;
		try {

			logger.info("Storing Excel to File [" + fileName
					+ "] with DB Query [" + query + "]");
			excelLink = StoreExcelUtil.storeExcel(testReportFolder, testCaseId,
					fileName);

			try {
				@SuppressWarnings("resource")
				XSSFWorkbook writeWorkbook = new XSSFWorkbook();
				XSSFSheet sheet = writeWorkbook.createSheet("new sheet");

				Statement stmt = null;
				ResultSet rs = null;

				stmt = conn.createStatement();

				rs = stmt.executeQuery(query);
				ResultSetMetaData rsmd = rs.getMetaData();
				int columnsNumber = rsmd.getColumnCount();
				Row Row1 = sheet.createRow(0);

				for (int col = 0; col < columnsNumber; col++) {
					Cell newpath = Row1.createCell(col);
					newpath.setCellValue(rsmd.getColumnLabel(col + 1));
				}

				boolean recordExists = false;

				while (rs.next()) {

					recordExists = true;
					Row Row = sheet.createRow(rs.getRow());
					for (int col = 0; col < columnsNumber; col++) {
						Cell newpath = Row.createCell(col);

						newpath.setCellValue(rs.getString(col + 1));

					}
					FileOutputStream fileOut = new FileOutputStream(
							testReportFolder + File.separator + testCaseId
									+ File.separator + excelLink);
					writeWorkbook.write(fileOut);
					fileOut.close();

				}
				if (recordExists) {

					TestReport.stepResultInHTML(fileName, testCaseId, "TABLE",
							"StoreExcel", "", "Data Found In Table",
							recordExists, excelLink);
				} else {

					TestReport.stepResultInHTML(fileName, testCaseId, "TABLE",
							"StoreExcel", "", "Data Not Found In Table",
							recordExists, "");
				}
			} catch (IOException e) {

				throw new Exception(htmlReportErrorSyntax
						+ "Unable To [Store Excel] for Table File [" + fileName
						+ "]");
			}
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
			TestReport.stepResultInHTML(fileName, testCaseId, "TABLE",
					"StoreExcel", "", "Data Not Found In Table", status,
					excelLink);

		}
		if (status == false) {
			throw new Exception("Unable To [Store Excel] for Table File ["
					+ fileName + "]");

		}

	}

	public void storeDBTablesInOneExcel(Map<String, String> DB_Queries,
			String elgId) throws Exception {

		String tableName = null;
		String testReportFolder = Hook.testReportFolder;
		String excelLink = StoreExcelUtil.storeExcel(testReportFolder,
				testCaseId, "HubLogicExcel-" + elgId);

		@SuppressWarnings("resource")
		XSSFWorkbook writeWorkbook = new XSSFWorkbook();
		for (Map.Entry<String, String> entry : DB_Queries.entrySet()) {

			tableName = entry.getKey();
			String query = entry.getValue();
			XSSFSheet sheet = writeWorkbook.createSheet(tableName);

			Statement stmt = null;
			ResultSet rs = null;

			stmt = conn.createStatement();

			rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount();
			Row Row1 = sheet.createRow(0);

			for (int col = 0; col < columnsNumber; col++) {
				Cell newpath = Row1.createCell(col);
				newpath.setCellValue(rsmd.getColumnLabel(col + 1));
			}

			boolean recordExists = false;

			while (rs.next()) {

				recordExists = true;
				Row Row = sheet.createRow(rs.getRow());
				for (int col = 0; col < columnsNumber; col++) {
					Cell newpath = Row.createCell(col);

					newpath.setCellValue(rs.getString(col + 1));

				}

			}

			FileOutputStream fileOut = new FileOutputStream(testReportFolder
					+ File.separator + testCaseId + File.separator + excelLink);
			writeWorkbook.write(fileOut);
			fileOut.close();
			logger.info("Stored Database Table into Excel on SheetName ["
					+ tableName + "] with DB Query [" + query + "]");
			if (recordExists) {
				TestReport.stepResultInHTML(tableName, testCaseId, "TABLE",
						"StoreExcel", "", "Database Found in Table",
						recordExists, excelLink);

			} else {

				TestReport.stepResultInHTML(tableName, testCaseId, "TABLE",
						"StoreExcel", "", "Database Not Found in Table",
						recordExists, "");

			}
		}
	}

	protected String storeXml(String tableName, String xmlValue, String fileName)
			throws Exception {
		boolean status = true;

		String testReportFolder = Hook.testReportFolder;
		String xmlLink = "";

		try {
			logger.info("Storing XML with Value [" + xmlValue + "] to File ["
					+ fileName + "]");
			xmlLink = StoreXMLUtil.storeXML(xmlValue, testReportFolder,
					testCaseId, fileName);
		} catch (Exception e) {
			status = false;
		}

		try {
			TestReport.stepResultInHTML(tableName, testCaseId, fileName,
					"StoreXML", "", "", status, xmlLink);
		} catch (IOException e) {
			throw new Exception(htmlReportErrorSyntax
					+ "[Store XML] for Table [" + tableName + "] and File ["
					+ fileName + "]");
		}

		if (status == false) {
			throw new Exception("Unable To [Store XML] for Table [" + tableName
					+ "] and File [" + fileName + "]");
		}

		return testReportFolder + File.separator + testCaseId + File.separator
				+ xmlLink;
	}

	protected void validateDBFieldValue(String tableName, String fieldName,
			String expValue, String actValue) throws Exception {
		boolean status = true;

		if (!expValue.equals(actValue)) {
			status = false;
		}
		try {
			TestReport.stepResultInHTML(tableName, testCaseId, fieldName,
					"ValidateDBField", expValue, actValue, status, "");
		} catch (IOException e) {
			throw new Exception("Step Result in HTML Error for module ["
					+ tableName + "] Field [" + fieldName
					+ "] Expected Value [" + expValue + "] Actual Value ["
					+ actValue + "]");
		}

		if (status == false) {
			throw new Exception("Unable To [ValidateDBField] for Table ["
					+ tableName + "] and Field [" + fieldName
					+ "] Expected Value [" + expValue + "] Actual Value ["
					+ actValue + "]");
		}
	}

}
