package db;

import java.sql.Connection;

/**
 * 
 * @author Ritika
 *
 */

public class FTRReconcileControlTable extends SuperTable {
	private String tableName = "MAHX_OWN.FTR_RECONCILE_CONTROL";
	private String eligibilityIdColumnName = "ELIGIBILITY_ID";
	private String statusColumnName = "STATUS";
	private String processidColumnName = "PROCESS_ID";
	private String updatedbyColumnName = "UPDATED_BY";

	public FTRReconcileControlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public void updateProcessId(String userProfileRefId,String newProcessValue,String newStatusValue)
			throws Exception 
	{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		updateColumnValue(elgId, processidColumnName, newProcessValue, newStatusValue);
	}

	public void updateUpdatedBy(String userProfileRefId,String newUpdatedValue,String newStatusValue)
			throws Exception 
	{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		updateColumnValue(elgId, updatedbyColumnName, newUpdatedValue, newStatusValue);
	}

	


	public void updateProcessId(String userProfileRefId,String newProcessValue)
			throws Exception 
	{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		updateColumnValue(elgId, processidColumnName, newProcessValue);
	}

	public void updateUpdatedBy(String userProfileRefId,String newUpdatedValue)
			throws Exception 
	{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		updateColumnValue(elgId, updatedbyColumnName, newUpdatedValue);
	}

	private void updateColumnValue(String elgId,String columnName,String columnValue,String newStatusValue) throws Exception{
		String query = "UPDATE " + tableName + " SET " +columnName+ "= '"+columnValue+"' WHERE "
				+ eligibilityIdColumnName + " NOT IN (" + elgId +") AND "+statusColumnName + "= '"+ newStatusValue +"'";
		executeQuery(query);       
	}
	
	private void updateColumnValue(String elgId, String columnName, String columnValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "'" + " WHERE "
				+ eligibilityIdColumnName + " = " +elgId ;
		executeQuery(query);

	}

}
