package db;

import java.sql.Connection;

public class ClockTable extends SuperTable {

	private String tableName = "MAHX_OWN.CLOCK";
	private String ownerIdColumnName = "OWNER_ID";
	private String expirationTimeColumnName = "EXPIRATION_TIME";
	
	public ClockTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public void updateClock(String elgId, String fName, String lName, String newDueDate) throws Exception {
		String taxHHid = new ElgMemberTable(conn, testCaseId).getTaxHHid(elgId, fName, lName);
		updateVarCharColumnValue(taxHHid, expirationTimeColumnName, newDueDate);
	}
	
	private void updateVarCharColumnValue(String taxHHid, String columnName, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "'" + " WHERE " + ownerIdColumnName + " = " + taxHHid;
		executeQuery(query);
	}
	
}