package db;

import java.sql.Connection;

/**
 * 
 * @author Vinay
 *
 */
public class ExchangeConfigAttributeTable extends SuperTable {
	private String tableName = "MAHX_OWN.EXCHANGE_CONFIG_ATTRIBUTES";
	private String tableNameOnUI = "EXCHANGE_CONFIG_ATTRIBUTES";
	private String attributeNameColumnName = "ATTRIBUTE_NAME";
	private String attributeValueColumnName = "ATTRIBUTE_VALUE";
	private String mhPendBypassAttrName = "MH.pending.bypass";

	public ExchangeConfigAttributeTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public void updateMHPendingByPass(String newValue) throws Exception {
		updateAttributeValue(mhPendBypassAttrName, newValue);
	}

	public String getMHPendingByPassStatus() throws Exception {
		return getAttributeValue(mhPendBypassAttrName);
	}

	public void validateMHPendingByPassStatus( String expMHPendingByPassStatus) throws Exception {
		expMHPendingByPassStatus = expMHPendingByPassStatus.toLowerCase();
		String actualMHPendingByPassStatus =  getMHPendingByPassStatus().toLowerCase();
		validateDBFieldValue(tableNameOnUI, mhPendBypassAttrName, expMHPendingByPassStatus, actualMHPendingByPassStatus);
	}
	
	
	private void updateAttributeValue(String attributeName , String attrValue) throws Exception {
		String query = "UPDATE " + tableName + " SET ATTRIBUTE_VALUE = '" + attrValue + "'" + " WHERE "
				+ attributeNameColumnName + " = '" + attributeName + "'";
		executeQuery(query);
	}
	
	private String getAttributeValue(String attributeName) throws Exception {
		String query = "SELECT * " + " FROM " + tableName + " WHERE " + attributeNameColumnName + " ='" + attributeName + "'";
		return getCellDataFromDB(query, attributeValueColumnName);
	}

}
