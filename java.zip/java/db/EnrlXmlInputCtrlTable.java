package db;

import java.sql.Connection;
import appdata.evpd.EVPD_MemData;
import java.util.List;

public class EnrlXmlInputCtrlTable extends SuperTable {

	private String tableName = "MAHX_OWN.ENRL_XML_INPUT_CTRL";
	private String idColumnName = "ID";
	private String inputXmlColumnName = "INPUT_XML";
	private String controlNoColumnName = "CONTROL_NO";
	private String currentStatusColumnName = "CURRENT_STATUS";
	private String createdDateColumnName = "CREATED_DATE";
	private String updatedDateColumnName = "UPDATED_DATE";
	private String enrXmlOutputIdColumnName = "ENR_XML_OUTPUT_ID";
	private String batchXmlControlIdColumnName = "BATCH_XML_CTRL_ID";
	private String tableNameToShowOnUI = "ENB_TABLE";

	
	public EnrlXmlInputCtrlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, idColumnName);
	}
	
	public String storeInputXMLMicro(String elgId, String fName, String lName, String coverageType, String action,String xmlValue) throws Exception{
		String xmlLink = storeXml(tableNameToShowOnUI, xmlValue, "ENB_"+ inputXmlColumnName+"_" + elgId+"_"+fName + "_" + lName);
		return xmlLink;
	}
	
	public String getId(String batchXMLCtrlId) throws Exception{
		return getColumnValue(batchXMLCtrlId, idColumnName);
	}
	
	public String getInputXml(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, inputXmlColumnName);
	}
	
	public String storeInputXML(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		String xmlValue = getInputXml(elgId, fName, lName,coverageType,action);
		String xmlLink = storeXml(tableNameToShowOnUI, xmlValue, "ENB_"+ inputXmlColumnName+"_" + elgId+"_"+fName + "_" + lName);
		return xmlLink;
	}
	
	public String getControlNo(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, controlNoColumnName);
	}
	
	public String getCurrentStatus(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, currentStatusColumnName);
	}
	
	public void validateCurrentStatus(String elgId, String fName, String lName, String coverageType, String action, String expCurrentStatus) throws Exception{
		String actualCurrentStatus = getCurrentStatus(elgId, fName, lName, coverageType, action);
		validateDBFieldValue(tableNameToShowOnUI, currentStatusColumnName, expCurrentStatus, actualCurrentStatus);
	}
	
	public String getCreatedDate(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, createdDateColumnName);
	}
	
	  public String getFirstName(int memIndex, List<EVPD_MemData> memsData)
	  {
		  //int memNo=memIndex-1;
		  String firstName=memsData.get(memIndex).firstName;
		  return firstName;
	  }
	  
	  public String getLastName(int memIndex, List<EVPD_MemData> memsData)
	  {
		  //int memNo=memIndex-1;
		  String firstName=memsData.get(memIndex).lastName;
		  return firstName;
	  }
	
	public String getUpdatedDate(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, updatedDateColumnName);
	}
	
	public String getEnrlXmlOutputId(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, enrXmlOutputIdColumnName);
	}
	
	public String storeInputXMLfromDB(String batchXMLCtrlId, String xmlType,String elgId, String coverageType, String action) throws Exception{
		String xmlValue = getInputXML(batchXMLCtrlId, xmlType);
		String xmlLink = storeXml(tableNameToShowOnUI, xmlValue, "ENB_"+ inputXmlColumnName+"_" + elgId);
		return xmlLink;
	}
	
	private String getInputXML(String batchXMLCtrlId, String xmlType) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+batchXmlControlIdColumnName+" = "+batchXMLCtrlId
				+ " AND INPUT_XML LIKE '%" + xmlType + "%'";
				
		return getCellDataFromDB(query,inputXmlColumnName);
	}
	
	
	private String getColumnValue(String elgId, String fName, String lName, String coverageType, String action, String columnName) throws Exception{
		String batchXMLCtrlId = new BatchEnrollmentXmlControlTable(conn,testCaseId).getId(elgId, fName, lName, coverageType, action);
		
		return getColumnValue(batchXMLCtrlId, columnName);
	}
	
	
	private String getColumnValue(String batchXMLCtrlId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+batchXmlControlIdColumnName+" = "+batchXMLCtrlId;
		return getCellDataFromDB(query,columnName);
	}
}
