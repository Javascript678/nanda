package db;

import java.sql.Connection;

/**
 * 
 * @author Vinay
 *
 */
public class ElgMemberCitizenshipTable extends SuperTable {
	private String tableName = "MAHX_OWN.ELG_MEMBER_CITIZENSHIP";
	private String idColumnName = "ID";
	private String elgMemberIdColumnName = "ELG_MEMBER_ID";
	private String statusAwardDateColumnName = "STATUS_AWARD_DATE";

	public ElgMemberCitizenshipTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getIdUsingEligId(String elgId, int memIndex) throws Exception {
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);

		return getColumnValueUsingEligMemberId(elgMemId, idColumnName);
	}
	
	public String getIdUsingEligMemId(String elgMemId) throws Exception {
		return getColumnValueUsingEligMemberId(elgMemId, idColumnName);
	}
	
	public void updateStatusAwardDate(String userProfileRefId, int memIndex, String newValue) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		String id = getIdUsingEligMemId(elgMemId);
		updateVarCharColumnValue(id, statusAwardDateColumnName, newValue);
	}

	private String getColumnValueUsingEligMemberId(String elgMemId, String columnName)
			throws Exception {

		String query = "SELECT * " + " FROM " + tableName + " WHERE " + elgMemberIdColumnName + " =" + elgMemId;
		return getCellDataFromDB(query, columnName);

	}

	private void updateVarCharColumnValue(String id, String columnName, String columnValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "'" + " WHERE "
				+ idColumnName + " = " + id;

		executeQuery(query);

	}

}
