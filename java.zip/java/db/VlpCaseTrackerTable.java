package db;

import java.sql.Connection;

public class VlpCaseTrackerTable extends SuperTable {

	private String tableName = "MAHX_OWN.VLP_CASE_TRACKER";
	private String tableNameOnUI = "VLP_CASE_TRACKER";
	private String caseNumberColumnName = "CASE_NUMBER";
	private String caseTypeColumnName = "CASE_TYPE";
	private String caseStatusColumnName = "CASE_STATUS";
	private String memberFirstNameColumnName = "MEMBER_FIRST_NAME";
	private String memberMiddleNameColumnName = "MEMBER_MIDDLE_NAME";
	private String memberLastNameColumnName = "MEMBER_LAST_NAME";
	private String memberRerfenceIdColumnName = "MEMBER_REFERENCE_ID";
	private String fiveYearBarApplieseColumnName = "FIVE_YEAR_BAR_APPLIES";
	private String fiveYearBarMetCodeColumnName = "FIVE_YEAR_BAR_MET";
	private String lawfulPresVerifiedCodeColumnName = "LAWFUL_PRESENCE_VERIFIED_CODE";
	private String qualifiedNonCitznCodeColumnName = "QUALIFIED_NON_CITIZEN_CODE";
	private String elgStatementCodeColumnName = "ELG_STATEMENT_CODE";
	private String agencyActionColumnName = "AGENCY_ACTION";
	
	private String grantDateColumnName = "GRANT_DATE";
	private String attestedLpStatusColumnName = "ATTESTED_LP_STATUS";
	private String elgIdColumnName = "ELIGIBILITY_ID";

	public VlpCaseTrackerTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);

	}

	//Vinay
	public String getCaseStatusUsingMemRefId(String memRefId) throws Exception {
		return getColumnValueUsingMemRefId(memRefId, caseStatusColumnName);
	}
	
	//Vinay
	public String getFiveYearBarAppliesColumnValueUsingMemRefId(String memRefId) throws Exception {
		return getColumnValueUsingMemRefId(memRefId, fiveYearBarApplieseColumnName);
	}
	
	//Vinay
	public String getFiveYearBarMetCodeColumnValueUsingMemRefId(String memRefId) throws Exception {
		return getColumnValueUsingMemRefId(memRefId, fiveYearBarMetCodeColumnName);
	}
	
	//Vinay
	public String getLawfulPresVerifiedCodeColumnValueUsingMemRefId(String memRefId) throws Exception {
		return getColumnValueUsingMemRefId(memRefId, lawfulPresVerifiedCodeColumnName);
	}
	
	//Vinay
	public String getQualifiedNonCitznCodeColumnNameUsingMemRefId(String memRefId) throws Exception {
		return getColumnValueUsingMemRefId(memRefId, qualifiedNonCitznCodeColumnName);
	}
	
	//Vinay
	public String getElgStatementCodeColumnNameUsingMemRefId(String memRefId) throws Exception {
		return getColumnValueUsingMemRefId(memRefId, elgStatementCodeColumnName);
	}
	
	//Vinay
	public String getAgencyActionColumnNameUsingMemRefId(String memRefId) throws Exception {
		return getColumnValueUsingMemRefId(memRefId, agencyActionColumnName);
	}
	
	//Vinay
	public void validateCaseStatus(String elgId, int memIndex, String expCaseStatus) throws Exception {
		ElgMemberTable ElgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = ElgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		
		String actCaseStatus = getCaseStatusUsingMemRefId(memRefId);
		validateDBFieldValue(tableNameOnUI, caseStatusColumnName, expCaseStatus, actCaseStatus);
	}
	
	//Vinay
	public void validateFiveYearBarApplies(String elgId, int memIndex, String expFiveYearBarApplies) throws Exception {
		ElgMemberTable ElgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = ElgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		
		String actFiveYearBarApplies = getFiveYearBarAppliesColumnValueUsingMemRefId(memRefId);
		validateDBFieldValue(tableNameOnUI, fiveYearBarApplieseColumnName, expFiveYearBarApplies, actFiveYearBarApplies);
	}
	
	//Vinay
	public void validateFiveYearBarMetCode(String elgId, int memIndex, String expFiveYearBarMetCode) throws Exception {
		ElgMemberTable ElgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = ElgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		
		String actFiveYearBarMetCode = getFiveYearBarMetCodeColumnValueUsingMemRefId(memRefId);
		validateDBFieldValue(tableNameOnUI, fiveYearBarMetCodeColumnName, expFiveYearBarMetCode, actFiveYearBarMetCode);
	}
	
	//Vinay
	public void validateLawfulPresVerifiedCode(String elgId, int memIndex, String expLawfullyPresenceVerifiedCode) throws Exception {
		ElgMemberTable ElgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = ElgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		
		String actLawfullyPresenceVerifiedCode = getLawfulPresVerifiedCodeColumnValueUsingMemRefId(memRefId);
		validateDBFieldValue(tableNameOnUI, lawfulPresVerifiedCodeColumnName, expLawfullyPresenceVerifiedCode, actLawfullyPresenceVerifiedCode);
	}
	
	//Vinay
	public void validateQualifiedNonCitznCode(String elgId, int memIndex, String expQualifiedNonCitznCode) throws Exception {
		ElgMemberTable ElgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = ElgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		
		String actCaseStatus = getQualifiedNonCitznCodeColumnNameUsingMemRefId(memRefId);
		validateDBFieldValue(tableNameOnUI, qualifiedNonCitznCodeColumnName, expQualifiedNonCitznCode, actCaseStatus);
	}
	
	//Vinay
	public void validateElgStatementCode(String elgId, int memIndex, String expElgStatementCode) throws Exception {
		ElgMemberTable ElgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = ElgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		
		String actElgStatementCode = getElgStatementCodeColumnNameUsingMemRefId(memRefId);
		validateDBFieldValue(tableNameOnUI, elgStatementCodeColumnName, expElgStatementCode, actElgStatementCode);
	}
	
	//Vinay
	public void validateAgencyAction(String elgId, int memIndex, String expAgencyAction) throws Exception {
		ElgMemberTable ElgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = ElgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		
		String actAgencyAction = getAgencyActionColumnNameUsingMemRefId(memRefId);
		validateDBFieldValue(tableNameOnUI, agencyActionColumnName, expAgencyAction, actAgencyAction);
	}
	
	public String getCaseNumber(String elgId) throws Exception {
		return getColumnValue(elgId, caseNumberColumnName);
	}

	public void validateCaseNumberUsingRefId(String userProfileRefId, String expCaseNumber) throws Exception {

		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		System.out.println("Eligibility Id is:- " + elgId);

		String actCaseNumber = getCaseNumber(elgId);
		validateDBFieldValue(tableNameOnUI, caseNumberColumnName, expCaseNumber, actCaseNumber);
	}

	public String getCaseType(String elgId) throws Exception {
		return getColumnValue(elgId, caseTypeColumnName);
	}

	public void validateCaseTypeUsingRefId(String userProfileRefId, String expCaseType) throws Exception {
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actCaseType = getCaseType(elgId);
		validateDBFieldValue(tableNameOnUI, caseNumberColumnName, expCaseType, actCaseType);

	}
	
	
	
	public String getCaseStatus(String elgId) throws Exception {
		return getColumnValue(elgId, caseStatusColumnName);
	}

	public void validateCaseStatusUsingRefId(String userProfileRefId, String expCaseStatus) throws Exception {
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actCaseStatus = getCaseStatus(elgId);
		validateDBFieldValue(tableNameOnUI, caseStatusColumnName, expCaseStatus, actCaseStatus);

	}

	
	
	public String getFirstName(String elgId) throws Exception {
		return getColumnValue(elgId, memberFirstNameColumnName);
	}

	public void validateFirstNameUsingRefId(String userProfileRefId, String expFirstName) throws Exception {
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actFirstName = getFirstName(elgId);
		validateDBFieldValue(tableNameOnUI, memberFirstNameColumnName, expFirstName, actFirstName);

	}

	public String getMiddleName(String elgId) throws Exception {
		return getColumnValue(elgId, memberMiddleNameColumnName);
	}

	public void validateMiddleNameUsingRefId(String userProfileRefId, String expMiddleName) throws Exception {
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actMiddleName = getMiddleName(elgId);
		validateDBFieldValue(tableNameOnUI, memberMiddleNameColumnName, expMiddleName, actMiddleName);

	}

	public String getLastName(String elgId) throws Exception {
		return getColumnValue(elgId, memberLastNameColumnName);
	}

	public void validateLastNameUsingRefId(String userProfileRefId, String expLastName) throws Exception {
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actLastName = getLastName(elgId);
		validateDBFieldValue(tableNameOnUI, memberLastNameColumnName, expLastName, actLastName);

	}

	public String getMemberRerfenceId(String elgId) throws Exception {
		return getColumnValue(elgId, memberRerfenceIdColumnName);
	}

	public void validateMemberRerfenceIdUsingRefId(String userProfileRefId, String expMemberRerfenceId)
			throws Exception {
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actMemberRerfenceId = getMemberRerfenceId(elgId);
		validateDBFieldValue(tableNameOnUI, memberFirstNameColumnName, expMemberRerfenceId, actMemberRerfenceId);

	}

	public String getFiveYearBarMetCode(String elgId) throws Exception {
		return getColumnValue(elgId, fiveYearBarMetCodeColumnName);
	}

	public void validateFiveYearBarMetCodeUsingRefId(String userProfileRefId, String expFiveYearBarMetCode)
			throws Exception {
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actFiveYearBarMetCode = getFiveYearBarMetCode(elgId);
		validateDBFieldValue(tableNameOnUI, fiveYearBarMetCodeColumnName, expFiveYearBarMetCode, actFiveYearBarMetCode);

	}

	public String getGrantDate(String elgId) throws Exception {
		return getColumnValue(elgId, grantDateColumnName);
	}

	public void validateGrantDateUsingRefId(String userProfileRefId, String expGrantDate) throws Exception {
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actGrantDate = getGrantDate(elgId);
		validateDBFieldValue(tableNameOnUI, grantDateColumnName, expGrantDate, actGrantDate);

	}

	public String getAttestedLpStatus(String elgId) throws Exception {
		return getColumnValue(elgId, attestedLpStatusColumnName);
	}

	public void validateAttestedLpStatusUsingRefId(String userProfileRefId, String expAttestedLpStatus)
			throws Exception {
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actAttestedLpStatus = getAttestedLpStatus(elgId);
		validateDBFieldValue(tableNameOnUI, attestedLpStatusColumnName, expAttestedLpStatus, actAttestedLpStatus);

	}

	public void storeCompleteDataInExcel(String elgId) throws Exception {
		String query = "SELECT * " + " FROM " + tableName + " WHERE " + elgIdColumnName + " = " + elgId;
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}
	
	public String getSelectAllQuery(String elgId) throws Exception {
		
		String query = "SELECT * " + " FROM " + tableName + " WHERE " + elgIdColumnName + " = " + elgId;			
				return query;
			}
	public void storeHubRequestReponseDataInExcel(String elgId) throws Exception {
		String query = "SELECT " +caseNumberColumnName+","+caseTypeColumnName+","+caseStatusColumnName+","+memberFirstNameColumnName+","+memberMiddleNameColumnName+","+memberLastNameColumnName+","+memberRerfenceIdColumnName+","+fiveYearBarMetCodeColumnName+","+grantDateColumnName+","+attestedLpStatusColumnName+" FROM " + tableName + " WHERE " + elgIdColumnName + " = " + elgId;	
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}

	private String getColumnValue(String elgId, String columnName) throws Exception {

		String query = "SELECT * " + " FROM " + tableName + " WHERE " + elgIdColumnName + " = " + elgId;
		return getCellDataFromDB(query, columnName);
	}
	
	private String getColumnValueUsingMemRefId(String memRefId, String columnName) throws Exception {

		String query = "SELECT * " + " FROM " + tableName + " WHERE " + memberRerfenceIdColumnName + " = '" + memRefId + "'";
		String cellVal = getCellDataFromDB(query, columnName);
		
		return cellVal == null ? "":cellVal;
	}

}
