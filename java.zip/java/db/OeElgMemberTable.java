package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Ritu
 *
 */
public class OeElgMemberTable extends SuperTable {
	private String tableName = "MAHX_OWN.OE_ELG_MEMBER";
	private String idColumnName = "ID";
	private String memberReferenceIdColumnName = "MEMBER_REFERENCE_ID";
	private String oleElgIdColumnName = "OE_ELG_ID";
	private String proctectStartColumnName = "PROTECT_START";
	private String proctectEndColumnName = "PROTECT_END ";

	public OeElgMemberTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getIdUsingMemberReferenceId(String memberReferenceId) throws Exception {
		return getColumnValueUsingReferenceId(memberReferenceId, idColumnName);
	}

	public String getIdUsingOeElgId(String userProfileRefId, int memIndex) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		OeEligibilityTable oeEligibilityTable = new OeEligibilityTable(conn, testCaseId);
        String oeEligId = oeEligibilityTable.getIdUsingEligibilityId(elgId);
		return getColumnValueUsingOeEligId(oeEligId, memIndex, idColumnName); 
	}

	private String getColumnValueUsingOeEligId(String id, int memIndex,String columnName) throws Exception {
		String query = "SELECT * " + 
						" FROM " + tableName + 
						" WHERE " + oleElgIdColumnName + " = '" + id + 
						"' ORDER BY " + idColumnName;
		
		return getCellDataFromDB(query, memIndex, columnName);
	}

	private String getColumnValueUsingReferenceId(String memberReferenceId, String columnName) throws Exception {
		String query = "SELECT * " + 
						" FROM " + tableName + 
						" WHERE " + memberReferenceIdColumnName + " = '" + memberReferenceId + "'";
		return getCellDataFromDB(query, columnName);
	}
	
	//created new function
	
	public void updateDeterminationAndSubmissionDate(String userProfileRefId ,int memIndex ,String proctectStartColumnValue,String proctectEndColumnValue) throws Exception{ 
		
		String id = getIdUsingOeElgId(userProfileRefId,memIndex);
		List<String> columnNames = new ArrayList<String>();
		List<String> columnValues = new ArrayList<String>();
		columnNames.add(proctectStartColumnName );
		columnNames.add(proctectEndColumnName);
		columnValues.add(proctectStartColumnValue);
		columnValues.add(proctectEndColumnValue);
		updateVarCharColumnValues(id, columnNames, columnValues);
	}
	private void updateVarCharColumnValues(String id, List<String> columnNames, List<String> columnValues) throws Exception{
		String query = "UPDATE " 
				+ tableName + " SET ";
		for(int columnCounter=0; columnCounter < columnNames.size(); columnCounter++){
			if(columnCounter==( columnNames.size() - 1 )){
				query = query + columnNames.get(columnCounter) + " = '" + columnValues.get(columnCounter)  + "'";
			}else {
				query = query + columnNames.get(columnCounter) + " = '" + columnValues.get(columnCounter)  + "' ,";
			}
			
		}
		query = query + " WHERE "+ idColumnName +" = "+id;
		
		executeQuery(query);
	}
	

}
