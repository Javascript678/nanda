package db;

import java.sql.Connection;

public class PDMMemberServiceFactorTable extends SuperTable {

	private String tableName = "MAHX_OWN.PDM_MEMBER_SERVICE_FACTOR";
	private String serviceNameColumnName="SERVICE_FACTOR_NAME";
	private String serviceStatusColumnName="SERVICE_FACTOR_STATUS";
	private String pdmMemberServiceIdColumnName="PDM_MEMBER_SERVICE_ID";

	public PDMMemberServiceFactorTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public void validateServiceStatus(String userProfileRefId, int memIndex,String serviceName,String expServiceStatus) throws Exception{
		PDMMemberServiceInfoTable pdmMemberServiceInfoTable = new PDMMemberServiceInfoTable(conn, testCaseId);
		String id =pdmMemberServiceInfoTable.getId(userProfileRefId, memIndex);

		String actServiceStatus =getColumnValue(id,serviceName ,serviceStatusColumnName);
		validateDBFieldValue(tableName, serviceStatusColumnName, expServiceStatus, actServiceStatus);
	}

	private String getColumnValue(String pdmMemId,String serviceName,String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+pdmMemberServiceIdColumnName+" = "+pdmMemId+" AND "+serviceNameColumnName+"='"+serviceName+"'";
		return getCellDataFromDB(query, columnName);
	}

}
