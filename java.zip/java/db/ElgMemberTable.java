package db;

import java.sql.Connection;
import java.util.ArrayList;

public class ElgMemberTable extends SuperTable {

	private String tableName = "MAHX_OWN.ELG_MEMBER";
	private String idColumnName = "ID";
	private String elgIdColumnName = "ELIGIBILITY_ID";
	private String firstNameColumnName = "FIRST_NAME";
	private String middleNameColumnName = "MIDDLE_NAME";
	private String lastNameColumnName = "LAST_NAME";
	private String dobColumnName = "DATE_OF_BIRTH";
	private String contactInfoColumnName = "CONTACT_INFO_ID";
	private String memberReferenceIdColumnName = "MEMBER_REFERENCE_ID";
	private String memRefIdColumnName = "MEMBER_REFERENCE_ID";
	private String taxHHidColumnName = "TAX_HOUSEHOLD_ID";
	private String createdDateColumnName = "CREATED_DATE";

	public ElgMemberTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getId(String elgId, String fName, String lName) throws Exception {
		return getColumnValue(elgId, fName, lName, idColumnName);
	}

	public String getId(String elgId, int memIndex) throws Exception {
		return getColumnValue(elgId, memIndex, idColumnName);
	}

	// Paul
	public String getMemberReferenceId(String elgId, String fName, String lName) throws Exception {
		return getColumnValue(elgId, fName, lName, memRefIdColumnName);
	}

	// Paul
	public String getTaxHHid(String elgId, String fName, String lName) throws Exception {
		return getColumnValue(elgId, fName, lName, taxHHidColumnName);
	}

	public String getCreationDate(String elgId, int memIndex) throws Exception {
		return getColumnValue(elgId, memIndex, createdDateColumnName);
	}

	public void updateMMISdateForElgId(String elgId, String newMMISDate) throws Exception {
		updateMMISAppDate(elgId, newMMISDate);
	}

	// Vinay
	public String getMemberReferenceIdUsingMemIndex(String elgId, int memIndex) throws Exception {
		String fName = getFirstName(elgId, memIndex);
		String lName = getLastName(elgId, memIndex);
		return getColumnValue(elgId, fName, lName, memRefIdColumnName);
	}

	public ArrayList<String> getIdS(String elgId) throws Exception {
		return getColumnValues(elgId, idColumnName); // new function created
	}

	public int getMemberCount(String elgId) throws Exception {
		return getRowCountUsingElgId(elgId);
	}

	public int getMemberCountUsingUserProfileRefId(String userProfileRefId) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		return getMemberCount(elgId);
	}

	public String getFirstName(String elgId, int memIndex) throws Exception {
		return getColumnValue(elgId, memIndex, firstNameColumnName);
	}

	public String getFirstNameUsingUserProfileRefId(String userProfileRefId, int memIndex) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		return getFirstName(elgId, memIndex);
	}

	public String getMiddleName(String elgId, int memIndex) throws Exception {
		return getColumnValue(elgId, memIndex, middleNameColumnName);
	}

	public String getMiddleNameUsingUserProfileRefId(String userProfileRefId, int memIndex) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		return getMiddleName(elgId, memIndex);
	}

	public String getLastName(String elgId, int memIndex) throws Exception {
		return getColumnValue(elgId, memIndex, lastNameColumnName);
	}

	public String getLastNameUsingUserProfileRefId(String userProfileRefId, int memIndex) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		return getLastName(elgId, memIndex);
	}

	public String getFullNameUsingUserProfileRefId(String userProfileRefId, int memIndex) throws Exception {
		String fullName = null;
		String fName = getFirstNameUsingUserProfileRefId(userProfileRefId, memIndex);
		String mName = getMiddleNameUsingUserProfileRefId(userProfileRefId, memIndex);
		String lName = getLastNameUsingUserProfileRefId(userProfileRefId, memIndex);
		if (mName == null) {
			fullName = fName + " " + lName;
		} else {
			fullName = fName + " " + mName + " " + lName;
		}
		return fullName;
	}

	public String getFullName(String elgId, int memIndex) throws Exception {
		String fullName = null;
		String fName = getFirstName(elgId, memIndex);
		String mName = getMiddleName(elgId, memIndex);
		String lName = getLastName(elgId, memIndex);
		if (mName == null) {
			fullName = fName + " " + lName;
		} else {
			fullName = fName + " " + mName + " " + lName;
		}
		return fullName;
	}

	public String getMemberReferenceIdUsingElgId(String elgId, int memIndex) throws Exception {
		return getColumnValue(elgId, memIndex, memberReferenceIdColumnName);
	}

	// Shivam
	public String getContactInfoId(String elgId, int memIndex) throws Exception {
		return getColumnValue(elgId, memIndex, contactInfoColumnName);
	}

	public String getDOB(String elgId, int memIndex) throws Exception {
		return getColumnValue(elgId, memIndex, dobColumnName);
	}

	// Ritu :
	public void updateDateOfBirth(String elgId, String fName, String lName, String newDOB) throws Exception {
		updateDOBColumnValue(elgId, fName, lName, newDOB);
	}

	public void updateLastName(String elgId, int memIndex, String UpdatedlName) throws Exception {
		String ElgMemberId = getId(elgId, memIndex);
		updateVarCharColumnValue(ElgMemberId, lastNameColumnName, UpdatedlName);
	}

	private String getColumnValue(String elgId, String fName, String lName, String columnName) throws Exception {
		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + elgIdColumnName + " = " + elgId + 
					   " AND " + firstNameColumnName + " = '" + fName + "'" + 
					   " AND " + lastNameColumnName + " =  '" + lName + "'";
		
		return getCellDataFromDB(query, columnName);
	}

	private void updateDOBColumnValue(String elgId, String fname, String lname, String newDOB) throws Exception {
		String query = "UPDATE " + tableName + 
				   	   " SET DATE_OF_BIRTH = TO_DATE('" + newDOB + "'" + ",'YYYY-MM-DD')" +
				   	   " WHERE " + elgIdColumnName + " = " + elgId + 
				   	   " AND " + firstNameColumnName + "= '" + fname + "'" + 
				   	   " AND "+ lastNameColumnName + "= '" + lname + "'";

		executeQuery(query); // new function for eg age out scenario
	}

	private void updateVarCharColumnValue(String ElgMemberId, String columnName, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + columnName + "= '" + columnValue + 
					   "' WHERE " + idColumnName + " = " + ElgMemberId;
		
		executeQuery(query); // update name
	}

	private String getColumnValue(String elgId, int memIndex, String columnName) throws Exception {
		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + elgIdColumnName + " = " + elgId + " ORDER BY ID";
		
		return getCellDataFromDB(query, memIndex, columnName);
	}

	private ArrayList<String> getColumnValues(String elgId, String columnName) throws Exception {
		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + elgIdColumnName + " = " + elgId;
		
		return getColumnDataFromDB(query, columnName);
	}

	private int getRowCountUsingElgId(String elgId) throws Exception {
		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + elgIdColumnName + " = " + elgId;
		
		return getRowCount(query);
	}

	private void updateMMISAppDate(String elgId, String newMMISdate) throws Exception {
		String query = "UPDATE " + tableName + 
				       " SET MMIS_APP_DATE = TO_DATE('" + newMMISdate + "'" + ",'MM-DD-YYYY')" +
				       " WHERE " + elgIdColumnName + " = " + elgId + "'";
		
		executeQuery(query);
	}

}
