package db;

import java.sql.Connection;

public class PDMMemberTrackerTable extends SuperTable {

	private String tableName = "MAHX_OWN.PDM_MEMBER_TRACKER";
	private String memberStatusColumnName="MEMBER_STATUS";
	private String idColumnName="ID";
	private String memberReferenceIdColumnName="MEMBER_REFERENCE_ID";
	
	public PDMMemberTrackerTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	
	
	public void validateMemberStatus(String userProfileRefId, int memIndex,String expStatus) throws Exception{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn,testCaseId);
		String memId=elgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		String actStatus = getColumnValue(memId, memberStatusColumnName);
		validateDBFieldValue(userProfileRefId, memberStatusColumnName, expStatus, actStatus);
		
	}
	
	public String getId(String userProfileRefId, int memIndex) throws Exception{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn,testCaseId);
		String memId=elgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		String id = getColumnValue(memId, idColumnName);
		return id;
	}
	
	
	private String getColumnValue(String memRefId,String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+memberReferenceIdColumnName+" = "+memRefId;
		return getCellDataFromDB(query, columnName);
	}

}
