package db;

import java.sql.Connection;
import java.util.ArrayList;

/**
 * 
 * @author Vinay
 *
 */
public class RrvTdsReqResCtrlTable extends SuperTable {
	private String tableNameToShowOnReport = "RRV_TDS_REQ_RES_CTRL";
	private String tableName = "MAHX_OWN.RRV_TDS_REQ_RES_CTRL";
	private String idColumnName = "ID";
	private String eligibilityIdColumnName = "ELIGIBILITY_ID";
	private String memRefIdColumnName = "MEM_REF_ID";
	private String statusColumnName = "STATUS";
	private String tdsColumnName = "TDS";
	private String rrvAggrTdsReqCtrlIdColumnName = "RRV_AGGR_TDS_REQ_CTRL_ID";
	private String resXmlColumnName = "RES_XML";

	public RrvTdsReqResCtrlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getId(String userProfileRefId, String tdsValue) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		return getColumnValue(elgId, tdsValue, idColumnName);
	}

	public String getStatus(String userProfileRefId, String tdsValue) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		return getColumnValue(elgId, tdsValue, statusColumnName);
	}

	public ArrayList<String> getRrvAggrTdsReqCtrlId(String userProfileRefId) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		return getColumnDataFromDB(getRrvTdsReqCtrlIdColumnValue(elgId), rrvAggrTdsReqCtrlIdColumnName);
	}

	public void validateStatus(String userProfileRefId, String tdsValue, String expStatus) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		String actualStatus = getColumnValue(elgId, tdsValue, statusColumnName);
		validateDBFieldValue(tableNameToShowOnReport, statusColumnName, expStatus, actualStatus);
	}
	
	public void ccaRenewalResXmlDisabilityUpdateQuery(String userProfileRefId, int memInd, String oldValue,  String newValue) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memInd);		
		
		updateResXmlColumn(elgId, memRefId, oldValue, newValue);
	}

	private String getColumnValue(String elgId, String tdsColumnValue, String columnName) throws Exception {
		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + eligibilityIdColumnName + " = " + elgId + 
					   " AND " + tdsColumnName + " = '" + tdsColumnValue + "'";

		return getCellDataFromDB(query, columnName);
	}
	
	private String getRrvTdsReqCtrlIdColumnValue(String elgId) throws Exception {
		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + eligibilityIdColumnName + " = " + elgId;

		return query;
	}
	
	public void updateResXmlColumn(String elgId, String memRefId, String oldValue,  String newValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + resXmlColumnName + " = replace(res_xml,'\"personDisabledIndicator\":{\"value\":" + oldValue + "}','\"personDisabledIndicator\":{\"value\":" + newValue + "}')" + 
					   " WHERE " + eligibilityIdColumnName + " = " + elgId +
					   " AND " + memRefIdColumnName + " = '" + memRefId + "'";

		executeQuery(query);
	}

}
