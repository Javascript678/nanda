package db;

import java.sql.Connection;

/**
 * 
 * @author Ritu
 *
 */
public class OeEligibilityTable extends SuperTable

{
	private String tableName = "MAHX_OWN.OE_ELIGIBILITY";
	private String idColumnName = "ID";
	private String userProfileIdColumnName = "USER_PROFILE_ID";

	public OeEligibilityTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getIdUsingEligibilityId(String eligId) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String userProfileId =eligibilityTable.getUserProfileId(eligId);
		return getColumnValueUsingUserProfileId(userProfileId, idColumnName);
	}
	

	private String getColumnValueUsingUserProfileId(String id, String columnName) throws Exception {
		String query = "SELECT * " + 
						" FROM " + tableName + 
						" WHERE " + userProfileIdColumnName + " = " + id;
		return getCellDataFromDB(query, columnName);
	}

	private String getColumnValue(String id, String columnName) throws Exception {
		String query = "SELECT * " + 
						" FROM " + tableName + 
						" WHERE " + id + " = " + id;
		return getCellDataFromDB(query, columnName);

	}

}
