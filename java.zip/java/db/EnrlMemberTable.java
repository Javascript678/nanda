package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class EnrlMemberTable extends SuperTable

{

	private String tableName = "MAHX_OWN.ENRL_MEMBER";
	private String idColumnName = "ID";
	private String enrollmentIdColumnName ="ENROLLMENT_ID";  

	
	public EnrlMemberTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public ArrayList<String>getIdsUsingEnrollmentId(String userProfileRefId ,String newStatusValue) throws Exception
	{
		EnrollmentTable enrollmentTable = new  EnrollmentTable(conn, testCaseId);
		 ArrayList<String> enrollmentIds = enrollmentTable.getIDsUsingUserProfileRefId(userProfileRefId ,newStatusValue);	
		return getColumnValuesUsingEnrollmentId(enrollmentIds ,idColumnName);
		 
	}
	
	private String getColumnValue( String enrollmentId ,String idColumnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+enrollmentIdColumnName +" = '"+enrollmentId+"'";
				
		return getCellDataFromDB(query,idColumnName);
	}



private ArrayList<String> getColumnValuesUsingEnrollmentId(List<String> enrollmentIds, String idColumnName)
		throws Exception {
	ArrayList<String>columnValues = new ArrayList<String>();

	for (String enrollmentId : enrollmentIds) {
		String colVal = getColumnValue(enrollmentId,idColumnName);
		columnValues.add(colVal);
	}
	return columnValues;
}

}