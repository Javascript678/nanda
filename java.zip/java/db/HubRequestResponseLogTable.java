package db;

import java.sql.Connection;

public class HubRequestResponseLogTable extends SuperTable {

	private static final String tableNameToShowOnUI = "HUB_REQ_RES_TABLE_LOG";
	private String tableName = "MAHX_OWN.HUB_REQUEST_RESPONSE_LOG";
	private String requestXmlClobColumnName = "XML_REQUEST";
	private String responseXmlClobColumnName = "XML_RESPONSE";
	private String elgIdColumnName = "ELIGIBILITY_ID";
	private String requestTypeColumnName = "REQUEST_TYPE";

	public HubRequestResponseLogTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getRequestXML(String elgId, String requestType) throws Exception {
		return getColumnValue(elgId, requestXmlClobColumnName, requestType);

	}

	public String getResponseXML(String elgId, String requestType) throws Exception {
		return getColumnValue(elgId, responseXmlClobColumnName, requestType);

	}

	public void validateRequestTypeIsGenerated(String requestTypeValue, String elgId) throws Exception {
		int actualCount = getRowCount(requestTypeValue, elgId);
		validateRequestTypeIsGettingGenerated(requestTypeValue, actualCount, elgId);
	}

	public void validateRequestTypeIsNotGenerated(String requestTypeValue, String elgId) throws Exception {
		int actualCount = getRowCount(requestTypeValue, elgId);
		validateRequestTypeIsNotGettingGenerated(requestTypeValue, actualCount, elgId);
	}
	
	public String storeRequestXML(String elgId, String requestType) throws Exception {
		String xmlValue = getRequestXML(elgId, requestType);
		String xmlLink = storeXml(tableNameToShowOnUI, xmlValue, "HUB_" + requestXmlClobColumnName + "_" + elgId);
		return xmlLink;
	}

	public String storeResXML(String elgId, String requestType) throws Exception {
		String xmlValue = getResponseXML(elgId, requestType);
		String xmlLink = storeXml(tableNameToShowOnUI, xmlValue, "HUB_" + responseXmlClobColumnName + "_" + elgId);
		return xmlLink;
	}

	private String getColumnValue(String elgId, String columnName, String requestType) throws Exception {

		String query = "SELECT * " + " FROM " + tableName + " WHERE ELIGIBILITY_ID = '" + elgId + "'" + " AND REQUEST_TYPE = '" + requestType + "'";
		return getCellDataFromDB(query, columnName);
	}

	protected void validateRequestTypeIsGettingGenerated(String myRequestType, int rowCount, String elgibilityId) throws Exception {
		boolean status = false;

		if (rowCount > 0) {
			status = true;
		}
		if (status == false) {
			throw new Exception("Request Type [" + myRequestType + "] is not getting generated for Eligibility ID [" + elgibilityId + "]");
		}
	}

	protected void validateRequestTypeIsNotGettingGenerated(String myRequestType, int rowCount, String elgibilityId) throws Exception {
		boolean status = false;

		if (rowCount == 0) {
			status = true;
		}
		if (status == false) {
			throw new Exception("Request Type [" + myRequestType + "] is getting generated for Eligibility ID [" + elgibilityId + "]");
		}
	}

	private int getRowCount(String requestTypeValue, String elgId) throws Exception {
		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + elgIdColumnName + " = " + elgId + 
					   " AND " + requestTypeColumnName + " = '" + requestTypeValue + "'";

		int numberOfRowsFetched = getRowCount(query);
		return numberOfRowsFetched;
	}
	
}