package db;

import java.sql.Connection;
import java.util.ArrayList;

/**
 * 
 * @author Vinay
 *
 */
public class RrvAggrTdsReqCtrlTable extends SuperTable {
	
	private String tableNameToShowOnReport = "RRV_AGGR_TDS_REQ_CTRL";
	private String tableName = "MAHX_OWN.RRV_AGGR_TDS_REQ_CTRL";
	private String idColumnName = "ID";
	private String rrvBatchReqCtrlIdColumnName = "RRV_BATCH_REQ_CTRL_ID";

	public RrvAggrTdsReqCtrlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public ArrayList<String> getRrvAggrTdsReqCtrlId(String userProfileRefId) throws Exception {
		RrvTdsReqResCtrlTable rrvTdsReqResCtrlTable = new RrvTdsReqResCtrlTable(conn, testCaseId);
		ArrayList<String> idArr = rrvTdsReqResCtrlTable.getRrvAggrTdsReqCtrlId(userProfileRefId);
		
		String ids = null;
		
		for(int i = 0; i < idArr.size(); i++){
			if(i == 0){
				ids = idArr.get(i);
			}else{
				ids = ids + ", " + idArr.get(i);
			}
		}
		
		return getColumnDataFromDB(getRrvAggrTdsReqCtrlIdColumnValue(ids), rrvBatchReqCtrlIdColumnName);
	}
	
	private String getRrvAggrTdsReqCtrlIdColumnValue(String ids) throws Exception {
		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + idColumnName + " IN (" + ids + ")";

		return query;
	}
}
