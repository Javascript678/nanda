package db;

import java.sql.Connection;

/**
 * 
 * @author Paul
 *
 */
public class MedRenewalPrelimControlTable extends SuperTable {

	private static String tableNameToShowOnReport = "MED_RENEWAL_PRELIM_CONTROL";
	private static String tableName = "MAHX_OWN.MED_RENEWAL_PRELIM_CONTROL";
	private static String idColumnName = "ID";
	private static String statusColumnName = "STATUS";
	private static String eligibilityIdColumnName = "ELIGIBILITY_ID";

	public MedRenewalPrelimControlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getStatusColumnValue(String elgId) throws Exception {
		return getColumnValue(elgId, statusColumnName);
	}
	
	public void validateStatus(String userProfileRefId, String expStatus) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		String actualStatus = getStatusColumnValue(elgId);
		validateDBFieldValue(tableNameToShowOnReport, statusColumnName, expStatus, actualStatus);
	}

	private String getColumnValue(String elgId, String columnName) throws Exception {
		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + eligibilityIdColumnName + " = " + elgId;

		return getCellDataFromDB(query, columnName);
	}

}
