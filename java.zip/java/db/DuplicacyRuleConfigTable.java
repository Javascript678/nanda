package db;

import java.sql.Connection;

/**
 * 
 * @author Vinay
 *
 */
public class DuplicacyRuleConfigTable extends SuperTable {
	private String tableName = "MAHX_OWN.DUPLICACY_RULE_CONFIG";
	private String tableNameOnUI = "DUPLICACY_RULE_CONFIG";
	private String idColumnName = "ID";
	private String vhcRUleActionColumnName = "VHC_RULE_ACTION";
	private String hcRUleActionColumnName = "HC_RULE_ACTION";

	public DuplicacyRuleConfigTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public void updateVHCRuleActionForId(String vhcRuleAction, int id) throws Exception {
		updateVarCharColumnValue(id, vhcRUleActionColumnName, vhcRuleAction);
	}
	
	public void updateHCRuleActionForId(String hcRuleAction, int id) throws Exception {
		updateVarCharColumnValue(id, hcRUleActionColumnName, hcRuleAction);
	}
	
	public void updateVHCAndHCRuleActionAsBockForId(int id) throws Exception {
		updateVarCharColumnValue(id, vhcRUleActionColumnName, "BLOCK");
		updateVarCharColumnValue(id, hcRUleActionColumnName, "BLOCK");
	}

	public String getVHCRuleActionById(int id) throws Exception {
		return getColumnValueUsingDuplicacyRuleId(id, vhcRUleActionColumnName);
	}

	public void validateVHCRuleActionById(int id, String expVHCRule) throws Exception {
		String actualVHCRule =  getVHCRuleActionById(id);
		validateDBFieldValue(tableNameOnUI, vhcRUleActionColumnName, expVHCRule, actualVHCRule);
	}
	
	public String getHCRuleActionById(int id) throws Exception {
		return getColumnValueUsingDuplicacyRuleId(id, hcRUleActionColumnName);
	}
	
	public void validateHCRuleActionById(int id, String expHCRule) throws Exception {
		String actualHCRule =  getHCRuleActionById(id);
		validateDBFieldValue(tableNameOnUI, hcRUleActionColumnName, expHCRule, actualHCRule);
	}
	
	private void updateVarCharColumnValue(int id, String columnName, String columnValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "'" + " WHERE "
				+ idColumnName + " = " + id;

		executeQuery(query);

	}
	
	private String getColumnValueUsingDuplicacyRuleId(int id, String columnName) throws Exception {
		String query = "SELECT * " + " FROM " + tableName + " WHERE " + idColumnName + " =" + id;
		return getCellDataFromDB(query, columnName);
	}

}
