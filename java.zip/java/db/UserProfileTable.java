package db;

import java.sql.Connection;

public class UserProfileTable extends SuperTable {

	private String tableName = "MAHX_OWN.USER_PROFILE";
	private String idColumnName = "ID";
	private String userNameColumnName = "USER_NAME";
	private String firstNameColumnName = "FIRST_NAME";
	private String middleNameColumnName = "MIDDLE_NAME";
	private String lastNameColumnName = "LAST_NAME";
	private String dobColumnName = "DATE_OF_BIRTH";
	private String referenceIdColumnName = "REFERENCE_ID";
	
	
	public UserProfileTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getIdUsingReferenceId(String referenceId) throws Exception {
		return getColumnValueUsingReferenceId(referenceId, idColumnName);
	}
	
	public String getUserName(String id) throws Exception {
		return getColumnValue(id, userNameColumnName);
	}
	
	public String getFirstName(String id) throws Exception {
		return getColumnValue(id, firstNameColumnName);
	}
	
	public String getMiddleName(String id) throws Exception {
		return getColumnValue(id, middleNameColumnName);
	}
	
	public String getLastName(String id) throws Exception {
		return getColumnValue(id, lastNameColumnName);
	}
	
	public String getDOB(String id) throws Exception {
		return getColumnValue(id, dobColumnName);
	}
	
	public String getReferenceId(String id) throws Exception {
		return getColumnValue(id, referenceIdColumnName);
	}
	
	public String getReferenceIdUsingElgId(String elgId) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String userProfileId = eligibilityTable.getUserProfileId(elgId);
		return getColumnValue(userProfileId, referenceIdColumnName);
	}
	
	private String getColumnValue(String id, String columnName) throws Exception {
		String query = "SELECT * " 
				+ " FROM " + tableName
				+ " WHERE " + idColumnName + " = " + id;
		return getCellDataFromDB(query,columnName);
	}
	
	private String getColumnValueUsingReferenceId(String referenceId, String columnName) throws Exception {
		String query = "SELECT * " 
				+ " FROM " + tableName
				+ " WHERE " + referenceIdColumnName + " = '" + referenceId + "'";
		return getCellDataFromDB(query, columnName);
	}
	
}
