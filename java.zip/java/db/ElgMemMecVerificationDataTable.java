package db;

import java.sql.Connection;

public class ElgMemMecVerificationDataTable extends SuperTable {

	
	private String tableName = "MAHX_OWN.ELG_MEM_MEC_VERIFICATION_DATA";
	private String tableNameToShowOnUI = "ELG_MEM_MEC_VERIFICATION_DATA";
	private String ResponseCodeColumnName = "RESPONSE_CODE";
	private String ResponseTextColumnName = "RESPONSE_TEXT";
	private String TDSDescriptionColumnName = "TDS_DESCRIPTION";
	private String sourceIdColumnName = "SOURCE_ID";	
	private String elgMemberIdColumnName = "ELIGIBILITY_MEMBER_ID";
	public ElgMemMecVerificationDataTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getResponseCode(String elgId,int elgMemId) throws Exception{
		return getColumnValue(elgId, ResponseCodeColumnName,elgMemId);
	}
	public void validateResponseCodeUsingRefId(String userProfileRefId, String expResponseCode,int memIndex) throws Exception{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId =eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		String actResponseCode = getResponseCode(elgId,memIndex);
		validateDBFieldValue(tableNameToShowOnUI, ResponseCodeColumnName, expResponseCode, actResponseCode);
	}
	
	public String getResponseText(String elgId,int elgMemId) throws Exception{
		return getColumnValue(elgId, ResponseTextColumnName,elgMemId);
	}
	
	public void validateResponseTextUsingRefId(String userProfileRefId, String expResponseText,int memIndex) throws Exception{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId =eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		String actResponseText = getResponseText(elgId,memIndex);
		validateDBFieldValue(tableNameToShowOnUI, ResponseTextColumnName, expResponseText, actResponseText);
	}
	public String getTDSDescription(String elgId,int memIndex) throws Exception{
		return getColumnValue(elgId, TDSDescriptionColumnName,memIndex);
	}
	public void validateTDSDescriptionUsingRefId(String userProfileRefId, String expTDSDescription,int elgMemId) throws Exception{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId =eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		
		String actTDSDescription = getTDSDescription(elgId,elgMemId);
		validateDBFieldValue(tableNameToShowOnUI, TDSDescriptionColumnName, expTDSDescription, actTDSDescription);
	}
	
	public String getSourceId(String elgId,int memIndex) throws Exception{
		return getColumnValue(elgId, sourceIdColumnName,memIndex);
	}
	
	public void validateSourceIdUsingRefId(String userProfileRefId, String expTDSDescription,int memIndex) throws Exception{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId =eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		
		String actTDSDescription = getSourceId(elgId,memIndex);
		validateDBFieldValue(tableNameToShowOnUI, TDSDescriptionColumnName, expTDSDescription, actTDSDescription);
	}
	public void storeCompleteDataInExcel(String elgId) throws Exception {
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCount(elgId);
		
		
		String elgMemIds = "";
		for (int mCounter=0; mCounter < memCount; mCounter++) {
			String elgMemId = elg_MemberTable.getId(elgId, mCounter);
			if(mCounter != memCount-1){
				elgMemIds = elgMemId + ",";
			}else{
				elgMemIds = elgMemId;
			}
		}

		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgMemberIdColumnName+" IN ("+elgMemIds + ")";

		storeDBTableIntoExcel(query, tableNameToShowOnUI + "-" + elgId);
	}
	
	public void storeHubRequestReponseDataInExcel(String elgId) throws Exception {
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCount(elgId);
		
		String elgMemIds = "";
		for (int mCounter=0; mCounter < memCount; mCounter++) {
			String elgMemId = elg_MemberTable.getId(elgId, mCounter);
			if(mCounter != memCount-1){
				elgMemIds = elgMemId + ",";
			}else{
				elgMemIds = elgMemId;
			}
		}
		String query = "SELECT "+ResponseCodeColumnName+","+ResponseTextColumnName+","+TDSDescriptionColumnName+","+sourceIdColumnName+" FROM "+ tableName
				+ " WHERE "+elgMemberIdColumnName+" IN ("+elgMemIds + ")";
		storeDBTableIntoExcel(query, tableNameToShowOnUI + "-" + elgId);
	}
	
	private String getColumnValue(String elgId, String columnName,int memIndex) throws Exception{
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgMemberIdColumnName+" = "+elgMemId;
		return getCellDataFromDB(query,columnName);
	}

public String getSelectAllQuery(String elgId) throws Exception {
		
	ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
	int memCount = elg_MemberTable.getMemberCount(elgId);
	
	
	String elgMemIds = "";
	for (int mCounter=0; mCounter < memCount; mCounter++) {
		String elgMemId = elg_MemberTable.getId(elgId, mCounter);
		if(mCounter != memCount-1){
			elgMemIds = elgMemId + ",";
		}else{
			elgMemIds = elgMemId;
		}
	}

	String query = "SELECT * " 
			+ " FROM "+ tableName
			+ " WHERE "+elgMemberIdColumnName+" IN ("+elgMemIds + ")";

			return query;
		}	
	
}
