package db;

import java.sql.Connection;

import appdata.evpd.EVPD_Data;

/**@author:ppinho
 *
 */
public class RenewalPrelimElgFinalCtrlTable extends SuperTable {
	
	private static String tableNameToShowOnReport = "RENEWAL_PRELIM_ELG_FINAL_CTRL";
	private static String tableName = "MAHX_OWN.RENEWAL_PRELIM_ELG_FINAL_CTRL";
	private static String eligibilityIdColumnName = "ELIGIBILITY_ID";
	private static String renewedOnDateColumnName = "RENEWED_ON_DATE";
	private static String statusColumnName = "STATUS";

	public RenewalPrelimElgFinalCtrlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public void validateStatus(String userProfileRefId, String expStatus) throws Exception {
		RenewalElgTrackerTable renewalElgTrackerTable = new RenewalElgTrackerTable(conn, testCaseId);
		String elgId = renewalElgTrackerTable.getNewElgId(userProfileRefId);

		String actualStatus = getStatusColumnValue(elgId, statusColumnName);
		validateDBFieldValue(tableNameToShowOnReport, statusColumnName, expStatus, actualStatus);
	}
	
	public void ccaRenewalRenewedOnDateUpdateQuery(String userProfileRefId) throws Exception {
		String query = null;
		
		RenewalElgTrackerTable renewalElgTrackerTable = new RenewalElgTrackerTable(conn, testCaseId);
		String elgId = renewalElgTrackerTable.getNewElgId(userProfileRefId);
		
		query = updateRenewedOnDateUpdatedByWhereElgId(elgId);
		executeQuery(query);
	}
	
	private String getStatusColumnValue(String elgId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM " + tableName
				+ " WHERE "+ eligibilityIdColumnName + "= " + elgId;
		
		return getCellDataFromDB(query, columnName);
	}
	
	public static String updateRenewedOnDateUpdatedByWhereElgId(String elgId) throws Exception {
		String query = "UPDATE " + tableName + " " + 
					   "SET " + renewedOnDateColumnName + " = trunc(sysdate - 50) " +
					   "WHERE " + eligibilityIdColumnName + " = " + elgId;

			return query;
	}

}

