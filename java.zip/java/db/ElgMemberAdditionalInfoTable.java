package db;

import java.sql.Connection;

public class ElgMemberAdditionalInfoTable extends SuperTable 
{
	private String tableName = "MAHX_OWN.ELG_MEMBER_ADDITIONAL_INFO ";
	private String postPartumEndDateColumnName = "POSTPARTUM_END_DATE";
	private String elgMemberIdColumnName = "ELG_MEMBER_ID ";
	
	
	public ElgMemberAdditionalInfoTable(Connection conn, String testCaseId)
	{
		super(conn, testCaseId);
	}
	public void updatePostPartuEndDate(String elgId, String fName, String lName, String newPostPartumValue)
			throws Exception {
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemid = elgMemberTable.getId( elgId, fName, lName);
		updateColumnValue(elgMemid , postPartumEndDateColumnName, newPostPartumValue);
	}
	
	
	public void updatePostPartumEndDate(String userProfileRefId, int memIndex, String newPostPartumValue)
			throws Exception 
	{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		
		updateColumnValue(elgMemId , postPartumEndDateColumnName, newPostPartumValue);
	}

	private void updateColumnValue(String elgMemid, String columnName, String columnValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "'" + " WHERE "
				+ elgMemberIdColumnName + " = " + elgMemid;

		executeQuery(query);

	}



}
