package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class EligibilityTable extends SuperTable {

	private String tableName = "MAHX_OWN.ELIGIBILITY";
	private String idColumnName = "ID";
	private String isFinancialAssistanceColumnName = "IS_FINANCIAL_ASSISTANCE";
	private String elgStatusColumnName = "ELIGIBILITY_STATUS";
	private String applyingForColumnName = "APPLYING_FOR";
	private String familyIncomeColumnName = "FAMILY_INCOME";
	private String fplColumnName = "FEDERAL_POVERTY_LEVEL";
	private String csrLevelColumnName = "CSR_LEVEL";
	private String userProfileIdColumnName = "USER_PROFILE_ID";
	private String determinationDateColumnName = "DETERMINATION_DATE";
	private String submissionDateColumnName = "SUBMISSION_DATE";
	
	public EligibilityTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getIdUsingUserProfileRefId(String userProfileRefId) throws Exception{
		UserProfileTable userProfileTable = new UserProfileTable(conn, testCaseId);
		String userProfileId = userProfileTable.getIdUsingReferenceId(userProfileRefId);
		return getColumnValueUsingUserProfileId(userProfileId, idColumnName);
	}
	
	public String getFinancialAssistanceCode(String elgId) throws Exception{
		return getColumnValue(elgId, isFinancialAssistanceColumnName);
	}
	
	public void updateIsFinancialAssistance(String elgId, String newValue) throws Exception{
		updateIntegerColumnValue(elgId, isFinancialAssistanceColumnName, newValue);
	}
	
	public String getElgStatus(String elgId) throws Exception{
		return getColumnValue(elgId, elgStatusColumnName);
	}
	
	public void updateElgStatus(String elgId, String newValue) throws Exception{
		updateVarCharColumnValue(elgId, elgStatusColumnName, newValue);
	}
	
	public String getApplyingForStatus(String elgId) throws Exception{
		return getColumnValue(elgId, applyingForColumnName);
	}
	
	public String getFamilyIncome(String elgId) throws Exception{
		return getColumnValue(elgId, familyIncomeColumnName);
	}
	
	public String getfpl(String elgId) throws Exception{
		return getColumnValue(elgId, fplColumnName);
	}
	
	public String getCsrLevel(String elgId) throws Exception{
		return getColumnValue(elgId, csrLevelColumnName);
	}
	
	public String getUserProfileId(String elgId) throws Exception{
		return getColumnValue(elgId, userProfileIdColumnName);
	}
	
	public String getDeterminationDate(String elgId) throws Exception{
		return getColumnValue(elgId, determinationDateColumnName);
	}
	
	//Ritu
	public void updateDeterminationAndSubmissionDate(String userProfileRefId ,String determinationDate,String submissionDate) throws Exception{ 
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId); 
		List<String> columnNames = new ArrayList<String>();
		List<String> columnValues = new ArrayList<String>();
		columnNames.add(determinationDateColumnName);
		columnNames.add(submissionDateColumnName);
		columnValues.add(determinationDate);
		columnValues.add(submissionDate);
		updateVarCharColumnValues(elgId, columnNames, columnValues);
	}
	
	private String getColumnValue(String id, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+idColumnName+" = "+id;
		return getCellDataFromDB(query,columnName);
	}
	
	private String getColumnValueUsingUserProfileId(String userProfileId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM " + tableName
				+ " WHERE " + userProfileIdColumnName + " = " + userProfileId
				+ " ORDER BY " + idColumnName;
		return getCellDataFromDB(query, columnName);
	}
	
	private void updateIntegerColumnValue(String id, String columnName, String columnValue) throws Exception{
		String query = "UPDATE " 
				+ tableName + " SET " + columnName + " = " + columnValue 
				+ " WHERE "+ idColumnName +" = "+id;
		
		executeQuery(query);
	}
	
	private void updateVarCharColumnValue(String id, String columnName, String columnValue) throws Exception{
		String query = "UPDATE " 
				+ tableName + " SET " + columnName + " = '" + columnValue  + "'"
				+ " WHERE "+ idColumnName +" = "+id;
		
		executeQuery(query);
	}
	
	private void updateVarCharColumnValues(String id, List<String> columnNames, List<String> columnValues) throws Exception{
		String query = "UPDATE " 
				+ tableName + " SET ";
		for(int columnCounter=0; columnCounter < columnNames.size(); columnCounter++){
			if(columnCounter==( columnNames.size() - 1 )){
				query = query + columnNames.get(columnCounter) + " = '" + columnValues.get(columnCounter)  + "'";
			}else {
				query = query + columnNames.get(columnCounter) + " = '" + columnValues.get(columnCounter)  + "' ,";
			}
			
		}
		query = query + " WHERE "+ idColumnName +" = "+id;
		
		executeQuery(query);
	}
	
}
