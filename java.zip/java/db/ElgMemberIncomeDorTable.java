/**
 * 
 */
package db;

import java.sql.Connection;

/**
 * @author vverma25
 *
 */
public class ElgMemberIncomeDorTable extends SuperTable {

	private String tableName = "MAHX_OWN.ELG_MEMBER_INCOME_DOR";
	private String tableNameOnUI = "ELG_MEMBER_INCOME_DOR";


	public ElgMemberIncomeDorTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}



	public void storeCompleteDataInExcel(String elgId) throws Exception {
		
		String query = "SELECT *" 
				+ " FROM "+ tableName
				+ " where rownum <= 20 order by id desc";
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}
	
public String getSelectAllQuery() throws Exception {
		
	String query = "SELECT *" 
			+ " FROM "+ tableName
			+ " where rownum <= 20 order by id desc";
			return query;
		}
	
}
