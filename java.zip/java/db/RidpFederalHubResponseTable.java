package db;

import java.sql.Connection;

public class RidpFederalHubResponseTable extends SuperTable {

	
	private String tableName = "MAHX_OWN.RIDP_FEDERAL_HUB_RESPONSE";
	private String tableName2 = "MAHX_OWN.ELIGIBILITY";
	private String tableNameOnUI = "RIDP_FEDERAL_HUB_RESPONSE";
	private String userProfileIdColumnName = "USER_PROFILE_ID";
	private String serviceTypeColumnName = "SERVICE_TYPE";
	private String responseCodeColumnName = "RESPONSE_CODE";
	private String statusCodeColumnName = "STATUS";
	
	
	public RidpFederalHubResponseTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
		
	}
	public String getUserProfileId(String elgId) throws Exception{
		return getColumnValue(elgId, userProfileIdColumnName);
	}
	public void validateUserProfileIdUsingRefId(String userProfileRefId, String expuserProfileId) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		System.out.println("Eligibility Id is:- "+elgId);
		String actuserProfileId = getUserProfileId(elgId);
		validateDBFieldValue(tableNameOnUI, userProfileIdColumnName, expuserProfileId, actuserProfileId);
	}
	
	public String getServiceType(String elgId) throws Exception{
		return getColumnValue(elgId, serviceTypeColumnName);
	}
	public void validateServiceTypeUsingRefId(String userProfileRefId, String expserviceType) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		String actserviceType = getServiceType(elgId);
		validateDBFieldValue(tableNameOnUI, serviceTypeColumnName, expserviceType, actserviceType);
	}
	
	public String getResponseCode(String elgId) throws Exception{
		EligibilityTable elgTable = new EligibilityTable(conn, elgId);
		String userProfileId = elgTable.getUserProfileId(elgId);
		return getColumnValue(elgId, responseCodeColumnName);
	}
	public void validateResponseCodeUsingRefId(String userProfileRefId, String expresponseCode) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId = EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actresponseCode = getResponseCode(elgId);
		validateDBFieldValue(tableNameOnUI, responseCodeColumnName, expresponseCode, actresponseCode);
	}

	public void storeCompleteDataInExcel(String elgId) throws Exception {
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+userProfileIdColumnName+" IN (SELECT "+userProfileIdColumnName+" FROM "+tableName2+" WHERE ID = "+elgId+")";
       
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}
	
	public void storeHubRequestReponseDataInExcel(String elgId) throws Exception {
		String query = "SELECT "+userProfileIdColumnName+","+serviceTypeColumnName+","+responseCodeColumnName+","+responseCodeColumnName+","+statusCodeColumnName+ 
				" FROM "+ tableName
				+ " WHERE "+userProfileIdColumnName+" IN (SELECT "+userProfileIdColumnName+" FROM "+tableName2+" WHERE ID = "+elgId+")";
		
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}

	
public String getSelectAllQuery(String elgId) throws Exception {
		
	String query = "SELECT * " 
			+ " FROM "+ tableName
			+ " WHERE "+userProfileIdColumnName+" IN (SELECT "+userProfileIdColumnName+" FROM "+tableName2+" WHERE ID = "+elgId+")";
   
					
			return query;
		}
	private String getColumnValue(String elgId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+userProfileIdColumnName+" IN (SELECT "+userProfileIdColumnName+" FROM "+tableName2+" WHERE ID = "+elgId+")";
		return getCellDataFromDB(query,columnName);
	}
	
}
