package db;

import java.sql.Connection;

public class ElgMedicaidNoticeXmlTable extends SuperTable {

	private String tableName = "MAHX_OWN.ELG_MEDICAID_NOTICE_XML";
	private String tableNameToShowOnUI = "ELG_MED_NOTICE_XML_TABLE";
	private String idColumnName = "ID";
	private String elgIdColumnName = "ELG_ID";
	private String statusColumnName = "STATUS";
	private String currentStatusColumnName = "CURRENT_STATUS";
	private String elgMemberIdColumnName = "ELG_MEMBER_ID";
	private String noticeXmlStringColumnName = "NOTICE_XML_STRING";
	private String noticeTypeColumnName = "NOTICE_TYPE";
	private String languageColumnName = "LANG";
	
	public ElgMedicaidNoticeXmlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String elgId, String fName, String lName, String notice_type) throws Exception{
		return getColumnValue(elgId, fName, lName, notice_type, idColumnName);
	}
	
	public int getCount(String elgId) throws Exception{
		return getRowCountUsingElgId(elgId);
	}
	
	public String getElgId(String elgId, String fName, String lName, String notice_type) throws Exception{
		return getColumnValue(elgId, fName, lName, notice_type, elgIdColumnName);
	}
	
	public String getStatus(String elgId, String fName, String lName, String notice_type) throws Exception{
		return getColumnValue(elgId, fName, lName, notice_type, statusColumnName);
	}
	
	public String getStatus(String elgId, String fName, String lName, String notice_type, String language) throws Exception{
		return getColumnValue(elgId, fName, lName, notice_type, language, statusColumnName);
	}
	
	public String getCurrentStatus(String elgId, String fName, String lName, String notice_type, String language) throws Exception{
		return getColumnValue(elgId, fName, lName, notice_type, language, currentStatusColumnName);
	}
	
	public String getNoticeXmlString(String elgId, String fName, String lName, String notice_type) throws Exception{
		return getColumnValue(elgId, fName, lName, notice_type, noticeXmlStringColumnName);
	}
	
	public String storeNoticeXMLString(String elgId, String fName, String lName,String noticeType) throws Exception{
		String xmlValue = getNoticeXmlString(elgId, fName, lName,noticeType);
		String xmlLink = storeXml(tableNameToShowOnUI, xmlValue, "Notice_"+ elgId+"_"+ fName + "_" + lName + "_" + noticeType);
		return xmlLink;
	}
	
	public void validateStatus(String elgId, String fName, String lName, String notice_type, String expStatus) throws Exception{
		String actualStatus = getStatus(elgId, fName, lName, notice_type);
		validateDBFieldValue(tableNameToShowOnUI, "STATUS", expStatus, actualStatus);
	}
	public void validateStatus(String elgId, String fName, String lName, String notice_type, String langauge, String expStatus) throws Exception{
		String actualStatus = getStatus(elgId, fName, lName, notice_type,langauge);
		validateDBFieldValue(tableNameToShowOnUI, elgId+"_"+fName+"_"+lName+" "+notice_type+"_"+langauge+"_"+"STATUS", expStatus, actualStatus);
	}
	
	public void validateCurrentStatus(String elgId, String fName, String lName, String notice_type, String langauge, String expStatus) throws Exception{
		String actualStatus = getCurrentStatus(elgId, fName, lName, notice_type,langauge);
		validateDBFieldValue(tableNameToShowOnUI, elgId+"_"+fName+"_"+lName+" "+notice_type+"_"+langauge+"_"+"CURRENT_STATUS", expStatus, actualStatus);
	}
	public void validateRowCountForElgId(String elgId, int expCount) throws Exception{
		int actualCount = getRowCountUsingElgId(elgId);
		validateDBFieldValue(tableNameToShowOnUI, elgId+"_"+"NoticeCount", expCount+"", actualCount+"");
	}
	
	private String getColumnValue(String elgId, String fName, String lName, String noticeType, String columnName) throws Exception{
		String elgMemId = new ElgMemberTable(conn, testCaseId).getId(elgId, fName, lName);

		return getColumnValue(elgMemId, noticeType, columnName);
	}
	
	private String getColumnValue(String elgId, String fName, String lName, String noticeType, String language, String columnName) throws Exception{
		String elgMemId = new ElgMemberTable(conn, testCaseId).getId(elgId, fName, lName);

		return getColumnValue(elgMemId, noticeType, language,columnName);
	}
	
	private String getColumnValue(String elgMemId, String noticeType, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgMemberIdColumnName+" = "+elgMemId
				+ " AND "+noticeTypeColumnName+" = '"+noticeType + "'";
		return getCellDataFromDB(query,columnName);
	}
	
	private String getColumnValue(String elgMemId, String noticeType, String language, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgMemberIdColumnName+" = "+elgMemId
				+ " AND "+noticeTypeColumnName+" = '"+noticeType + "'"
				+ " AND "+languageColumnName+" = '"+language + "'";
		return getCellDataFromDB(query,columnName);
	}
	
	private int getRowCountUsingElgId(String elgId) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgIdColumnName+" = "+elgId;
		return getRowCount(query);
	}
}
