package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class IrsMemberVerificationTable extends SuperTable {
	
	private String tableName = "MAHX_OWN.IRS_MEMBER_VERIFICATION";
	private String tableNameOnUI = "IRS_MEMBER_VERIFICATION";
	private String idColumnName = "ID";
	private String memberReferenceIdColumnName = "MEM_REF_ID";
	private String magiAmtColumnName = "MAGI_AMOUNT";
	private String taxableSSBColumnName = "TAXABLE_SSB";
	private String receiceModeColumnName = "RECEIVE_MODE";
	private String reqApplicationIdColumnName = "REQ_APPLICATION_ID";
	private String requestInitSourceColumnName = "REQUEST_INIT_SOURCE";

	public IrsMemberVerificationTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String elgId, String memRefId, String init) throws Exception {
		return getIdColumnValue(elgId, memRefId, init);
	}

	public void updateMagiAmtAndTaxableSSBUsingMemRefId(String elgId, int memIndex, String magiAmtValue, String taxableSSBValues) throws Exception {
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memberReferenceId = elgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		List<String> columnNames = new ArrayList<String>();
		List<String> columnValues = new ArrayList<String>();
		columnNames.add(magiAmtColumnName);
		columnNames.add(taxableSSBColumnName);
		columnValues.add(magiAmtValue);
		columnValues.add(taxableSSBValues);

		updateVarCharColumnValues(memberReferenceId, columnNames, columnValues);
	}
	
	public void ccaRenewalMagiAmtUpdateQuery(String userProfileRefId, int memInd, String irsIncome) throws Exception {	
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memInd);
		
		updateMagiAmtColumn(elgId, memRefId, "CCA_RENEWAL", irsIncome);
	}
	
	public void ccaRenewalMagiAmtNullUpdateQuery(String userProfileRefId, int memInd) throws Exception {	
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memInd);
		
		updateMagiAmtNullColumn(elgId, memRefId, "CCA_RENEWAL");
	}
	
	public void ccaRenewalTaxableSSBUpdateQuery(String userProfileRefId, int memInd, String irsSsbIncome) throws Exception {	
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memInd);
		
		updateTaxableSSBColumn(elgId, memRefId, "CCA_RENEWAL", irsSsbIncome);
	}
	
	public void ccaRenewalTaxableSSBNullUpdateQuery(String userProfileRefId, int memInd) throws Exception {	
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memInd);
		
		updateTaxableSSBNullColumn(elgId, memRefId, "CCA_RENEWAL");
	}
	
	private String getIdColumnValue(String elgId, String memRefId, String init) throws Exception {
		String query = "SELECT * " +
					    " FROM " + tableName +
					    " WHERE " + reqApplicationIdColumnName + " = " + elgId +
					    " AND " + requestInitSourceColumnName + " = '" + init + "'" +  
					    " AND " + memberReferenceIdColumnName + " = '" + memRefId + "'";

		return getCellDataFromDB(query, idColumnName);
	}
	
	private void updateVarCharColumnValues(String memberReferenceId, List<String> columnNames, List<String> columnValues) throws Exception {
		String query = "UPDATE " + tableName + " SET ";
		
		for (int columnCounter = 0; columnCounter < columnNames.size(); columnCounter++) {
			if (columnCounter == (columnNames.size() - 1)) {
				query = query + columnNames.get(columnCounter) + " = " + columnValues.get(columnCounter) + " ";
			} else {
				query = query + columnNames.get(columnCounter) + " =  " + columnValues.get(columnCounter) + "  ,";
			}

		}
		
		query = query + " WHERE " + memberReferenceIdColumnName + " = '" + memberReferenceId + "'";

		executeQuery(query);
	}

	public void storeCompleteDataInExcel(String elgId, int memIndex) throws Exception {
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);

		int memCount = elg_MemberTable.getMemberCount(elgId);
		String memberReferenceIds = "";
		
		for (int mCounter = 0; mCounter < memCount; mCounter++) {
			String memberReferenceId = elg_MemberTable.getMemberReferenceIdUsingElgId(elgId, mCounter);
			if (mCounter != memCount - 1) {
				memberReferenceIds = memberReferenceId + ",";
			} else {
				memberReferenceIds = memberReferenceId;
			}
		}

		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + memberReferenceIdColumnName + " IN (" + memberReferenceIds + ")";
		
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}

	public void storeHubRequestReponseDataInExcel(String elgId, int memIndex) throws Exception {
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		
		int memCount = elg_MemberTable.getMemberCount(elgId);
		String memberReferenceIds = "";
		
		for (int mCounter = 0; mCounter < memCount; mCounter++) {
			String memberReferenceId = elg_MemberTable.getMemberReferenceIdUsingElgId(elgId, mCounter);
			if (mCounter != memCount - 1) {
				memberReferenceIds = memberReferenceId + ",";
			} else {
				memberReferenceIds = memberReferenceId;
			}
		}

		String query = "SELECT " + magiAmtColumnName + "," 
								 + memberReferenceIdColumnName + "," 
								 + taxableSSBColumnName + "," 
								 + receiceModeColumnName + 
					   " FROM " + tableName + 
					   " WHERE " + memberReferenceIdColumnName + " IN (" + memberReferenceIds + ")";

		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}

	public String getHubRequestReponseQuery(String elgId) throws Exception {
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);

		int memCount = elg_MemberTable.getMemberCount(elgId);
		String memberReferenceIds = "";
		
		for (int mCounter = 0; mCounter < memCount; mCounter++) {
			String memberReferenceId = elg_MemberTable.getMemberReferenceIdUsingElgId(elgId, mCounter);
			if (mCounter != memCount - 1) {
				memberReferenceIds = memberReferenceId + ",";
			} else {
				memberReferenceIds = memberReferenceId;
			}
		}

		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + memberReferenceIdColumnName + " IN (" + memberReferenceIds + ")";
		
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);

		return query;
	}
	
	public void updateMagiAmtColumn(String elgId, String memRefId, String init, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + magiAmtColumnName + " = '" + columnValue + "'" + 
					   " WHERE " + requestInitSourceColumnName + " = '" + init + "'" +
		   			   " AND " + reqApplicationIdColumnName + " = " + elgId + 
		   			   " AND " + memberReferenceIdColumnName + " =  '" + memRefId + "'";
		
		executeQuery(query);
	}
	
	public void updateMagiAmtNullColumn(String elgId, String memRefId, String init) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + magiAmtColumnName + " = NULL" + 
					   " WHERE " + requestInitSourceColumnName + " = '" + init + "'" +
		   			   " AND " + reqApplicationIdColumnName + " = " + elgId + 
		   			   " AND " + memberReferenceIdColumnName + " =  '" + memRefId + "'";
		
		executeQuery(query);
	}
	
	public void updateTaxableSSBColumn(String elgId, String memRefId, String init, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + taxableSSBColumnName + " = '" + columnValue + "'" + 
					   " WHERE " + requestInitSourceColumnName + " = '" + init + "'" +
		   			   " AND " + reqApplicationIdColumnName + " = " + elgId + 
		   			   " AND " + memberReferenceIdColumnName + " =  '" + memRefId + "'";
		
		executeQuery(query);
	}
	
	public void updateTaxableSSBNullColumn(String elgId, String memRefId, String init) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + taxableSSBColumnName + " = NULL" + 
					   " WHERE " + requestInitSourceColumnName + " = '" + init + "'" +
		   			   " AND " + reqApplicationIdColumnName + " = " + elgId + 
		   			   " AND " + memberReferenceIdColumnName + " =  '" + memRefId + "'";
		
		executeQuery(query);
	}

}
