package db;

import java.sql.Connection;

/**
 * 
 * @author Vinay
 *
 */
public class MedRenewalVlpControlTable extends SuperTable {
	private String tableNameToShowOnReport = "MED_RENEWAL_VLP_CONTROL";
	private String tableName = "MAHX_OWN.MED_RENEWAL_VLP_CONTROL";
	private String idColumnName = "ID";
	private String statusColumnName = "STATUS";
	private String eligibilityIdColumnName = "ELIGIBILITY_ID";
	private String memRefIdColumnName = "MEM_REF_ID";
	//private String xmlRequestColumnName = "XML_REQUEST";
	//private String xmlResponseColumnName = "XML_RESPONSE";
	
	public MedRenewalVlpControlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String userProfileRefId, int memIndex) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);

		return getColumnValue(elgId,memRefId, idColumnName);
	}
	
	public String getStatus(String userProfileRefId, int memIndex) throws Exception {
		String id = getId(userProfileRefId, memIndex);
		return getColumnValue(id, statusColumnName);
	}
	
	public void validateStatus(String userProfileRefId, int memIndex, String expStatus) throws Exception {
		String actualStatus = getStatus(userProfileRefId, memIndex);
		validateDBFieldValue(tableNameToShowOnReport, statusColumnName, expStatus, actualStatus);
	}
	
	private String getColumnValue(String elgId, String memRefId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+memRefIdColumnName+" = '"+memRefId + "'"
				+ " AND "+ eligibilityIdColumnName +"= " + elgId ;
		return getCellDataFromDB(query,columnName);
	}
	
	private String getColumnValue(String id, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+idColumnName+" = "+id;
		return getCellDataFromDB(query,columnName);
	}

}
