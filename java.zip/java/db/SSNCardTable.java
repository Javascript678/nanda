package db;

import java.sql.Connection;

public class SSNCardTable   extends SuperTable
{
	
	private String tableName = "MAHX_OWN.SSN_CARD";
	private String tableNameOnUI = "SSN_CARD";
	private String ssnColumnName = "SSN";
	private String elgMemberIdColumnName = "ELG_MEMBER_ID";
	private String createdByColumnName = "CREATED_BY";
	private String isHavingSSNColumnName = "IS_HAVING_SSN";
	private String firstNameColumnName = "FIRST_NAME";
	private String lastNameColumnName = "LAST_NAME";
	private String noSSNExplanationColumnName = "NO_SSN_EXPLANATION";
	private String isDeadColumnName = "IS_DEAD";
	private String isDeathVerifiedColumnName = "IS_DEATH_VERIFIED";
	private String deathVerificationDateColumnName = "DEATH_VERIFICATION_DATE";
	
	public SSNCardTable(Connection conn, String testCaseId)
	{
		super(conn, testCaseId);
	}
	
	
	public String getEncryptedSSNUsingUserProfileRefId(String userProfileRefId,int memIndex) throws Exception{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		
		return getColumnValuesUsingEligMemberId(elgMemId,ssnColumnName,memIndex);
		
		
	}
	
	public void validateElgMemberIdUsingRefId(String userProfileRefId, String expElgMemberId,int memIndex) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String actElgMemberId = elg_MemberTable.getId(elgId, memIndex);
		
		validateDBFieldValue(tableNameOnUI,elgMemberIdColumnName , expElgMemberId, actElgMemberId);
	}
	
	
	public String getIsHavingSSN(String elgId,int memIndex ) throws Exception{
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		return getColumnValuesUsingEligMemberId(elgMemId, isHavingSSNColumnName,memIndex);
	}
	
	public void validateIsHavingSSNUsingRefId(String userProfileRefId, String expIsHavingSSN,int memIndex) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String actIsHavingSSN = elg_MemberTable.getId(elgId, memIndex);
		validateDBFieldValue(tableNameOnUI, isHavingSSNColumnName, expIsHavingSSN, actIsHavingSSN);
	}
	
	public String getFirstName(String elgId,int memIndex) throws Exception{
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		return getColumnValuesUsingEligMemberId(elgMemId, firstNameColumnName,memIndex);
	}
	
	//Vimal
	public void validateFirstNameUsingRefId(String userProfileRefId, String expFirstName,int memIndex) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String actFirstName = elg_MemberTable.getId(elgId, memIndex);
		validateDBFieldValue(tableNameOnUI, firstNameColumnName, expFirstName, actFirstName);
	}
	public String getLastName(String elgId,int memIndex ) throws Exception{
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		
		return getColumnValuesUsingEligMemberId(elgMemId, lastNameColumnName, memIndex);
	}
	
	//Vimal
	public void validateLastNameUsingRefId(String userProfileRefId, String expLastName,int memIndex) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String actLastName = elg_MemberTable.getId(elgId, memIndex);
		validateDBFieldValue(tableNameOnUI, lastNameColumnName, expLastName, actLastName);
	}
	public String getNoSSNExplanation(String elgId,int memIndex) throws Exception{
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		
		return getColumnValuesUsingEligMemberId(elgMemId, noSSNExplanationColumnName,memIndex);
	}
	
	//Vimal
	public void validateNoSSNExplanationUsingRefId(String userProfileRefId, String expNoSSNExplanation,int memIndex) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String actNoSSNExplanation = elg_MemberTable.getId(elgId, memIndex);
		validateDBFieldValue(tableNameOnUI, noSSNExplanationColumnName, expNoSSNExplanation, actNoSSNExplanation);
	}
	
	public String getIsDead(String elgId,int memIndex ) throws Exception{
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
	
		return getColumnValuesUsingEligMemberId(elgMemId, isDeadColumnName,memIndex );
	}
	
	public void validateIsDeadUsingRefId(String userProfileRefId, String expIsDead,int memIndex) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String actIsDead = elg_MemberTable.getId(elgId, memIndex);
		validateDBFieldValue(tableNameOnUI, isDeadColumnName, expIsDead, actIsDead);
	}
	public String getIsDeadVerified(String elgId,int memIndex) throws Exception{
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		return getColumnValuesUsingEligMemberId(elgMemId, isDeathVerifiedColumnName,memIndex);
	}
	
	//Vimal
	public void validateIsDeadVerifiedUsingRefId(String userProfileRefId, String expIsDeadVerified,int memIndex) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String actIsDeadVerified = elg_MemberTable.getId(elgId, memIndex);
		validateDBFieldValue(tableNameOnUI, isDeathVerifiedColumnName, expIsDeadVerified, actIsDeadVerified);
	}
	
	public String getIsDeadVerificationDate(String elgId,int memIndex) throws Exception{
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		return getColumnValuesUsingEligMemberId(elgMemId, deathVerificationDateColumnName,memIndex);
	}
	
	//Vimal
	public void validateIsDeadVerificationDateUsingRefId(String userProfileRefId, String expIsDeadVerificationDate,int memIndex) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String actIsDeadVerificationDate = elg_MemberTable.getId(elgId, memIndex);
		validateDBFieldValue(tableNameOnUI, deathVerificationDateColumnName, expIsDeadVerificationDate, actIsDeadVerificationDate);
	}	
	
	public String getCreatedByUser(String userProfileRefId,int memIndex) throws Exception{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		
		return getColumnValuesUsingEligMemberId(elgMemId,createdByColumnName,memIndex);
	}
	
	//vimal
	public void storeCompleteDataInExcel(String elgId) throws Exception {
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCount(elgId);
		
		
		String elgMemIds = "";
		for (int mCounter=0; mCounter < memCount; mCounter++) {
			String elgMemId = elg_MemberTable.getId(elgId, mCounter);
			if(mCounter != memCount-1){
				elgMemIds = elgMemId + ",";
			}else{
				elgMemIds = elgMemId;
			}
		}		String query = "SELECT * " + " FROM " + tableName + " WHERE " + elgMemberIdColumnName +" IN ("+elgMemIds + ")";
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}
	//vimal
public String getSelectAllQuery(String elgId) throws Exception {
		
	ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
	int memCount = elg_MemberTable.getMemberCount(elgId);
	
	
	String elgMemIds = "";
	for (int mCounter=0; mCounter < memCount; mCounter++) {
		String elgMemId = elg_MemberTable.getId(elgId, mCounter);
		if(mCounter != memCount-1){
			elgMemIds = elgMemId + ",";
		}else{
			elgMemIds = elgMemId;
		}
	}		String query = "SELECT * " + " FROM " + tableName + " WHERE " + elgMemberIdColumnName +" IN ("+elgMemIds + ")";
				return query;
			}
	//vimal
	public void storeHubRequestReponseDataInExcel(String elgId) throws Exception {
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		int memCount = elg_MemberTable.getMemberCount(elgId);
		
		
		String elgMemIds = "";
		for (int mCounter=0; mCounter < memCount; mCounter++) {
			String elgMemId = elg_MemberTable.getId(elgId, mCounter);
			if(mCounter != memCount-1){
				elgMemIds = elgMemId + ",";
			}else{
				elgMemIds = elgMemId;
			}
		}
		
		String query = "SELECT "+elgMemberIdColumnName+","+isHavingSSNColumnName+","+firstNameColumnName+","+lastNameColumnName+","+noSSNExplanationColumnName+","+isDeadColumnName+","+isDeathVerifiedColumnName+","+deathVerificationDateColumnName+ " FROM " + tableName + " WHERE " + elgMemberIdColumnName +" IN ("+elgMemIds + ")";
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}
	private String  getColumnValuesUsingEligMemberId(String elgId,String ColumnName,int memIndex)throws Exception {
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		
		String query = "SELECT * " + " FROM " + tableName + " WHERE " + elgMemberIdColumnName + " =" + elgMemId;
		return getCellDataFromDB(query,ColumnName);

	}
	
	
	
}


