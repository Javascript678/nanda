package db;

import java.sql.Connection;

/**
 * 
 * @author Vinay
 *
 */
public class PdmElgActionControlTable extends SuperTable {
	private String tableNameToShowOnReport = "PDM_ELG_ACTION_CONTROL";
	private String tableName = "MAHX_OWN.PDM_ELG_ACTION_CONTROL";
	private String idColumnName = "ID";
	private String pdmProfileTrackerIdColumnName = "PDM_PROFILE_TRACKER_ID";
	private String statusColumnName = "STATUS";
	private String statusReasonColumnName = "STATUS_REASON";
	private String pdmActionColumnName = "PDM_ACTION";
	private String prelimEligibilityIdColumnName = "PRELIM_ELIGIBILITY_ID";
	
	public PdmElgActionControlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String userProfileRefId, String pdmAction) throws Exception {
		PDMProfileTrackerTable pdmProfileTrackerTable = new PDMProfileTrackerTable(conn, testCaseId);
		String pdmProfileTrackerId = pdmProfileTrackerTable.getId(userProfileRefId);
		return getColumnValue(pdmProfileTrackerId,pdmAction, idColumnName);
	}
	
	public String getStatus(String userProfileRefId, String pdmAction) throws Exception {
		String id = getId(userProfileRefId, pdmAction);
		return getColumnValue(id, statusColumnName);
	}
	
	public String getStatusReason(String userProfileRefId, String pdmAction) throws Exception {
		String id = getId(userProfileRefId, pdmAction);
		return getColumnValue(id, statusReasonColumnName);
	}
	
	public void validateStatus(String userProfileRefId, String pdmAction, String expStatus) throws Exception {
		String actualStatus = getStatus(userProfileRefId, pdmAction);
		validateDBFieldValue(tableNameToShowOnReport, statusColumnName, expStatus, actualStatus);
	}
	
	public void validateStatusReason(String userProfileRefId, String pdmAction, String expStatusReason) throws Exception {
		String actualStatusReason = getStatusReason(userProfileRefId, pdmAction);
		validateDBFieldValue(tableNameToShowOnReport, statusReasonColumnName, expStatusReason, actualStatusReason);
	}
	
	private String getColumnValue(String pdmProfileTrackerId, String pdmAction, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+pdmProfileTrackerIdColumnName+" = "+pdmProfileTrackerId 
				+ " AND "+ pdmActionColumnName +"= '" + pdmAction + "'" ;
		return getCellDataFromDB(query,columnName);
	}
	
	private String getColumnValue(String id, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+idColumnName+" = "+id; 
		String cellValue = getCellDataFromDB(query,columnName);
		return cellValue==null?"":cellValue;
	}
	

}
