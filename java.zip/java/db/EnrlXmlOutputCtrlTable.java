package db;

import java.sql.Connection;

public class EnrlXmlOutputCtrlTable extends SuperTable {

	private String tableName = "MAHX_OWN.ENRL_XML_OUTPUT_CTRL";
	private String idColumnName = "ID";
	
	public EnrlXmlOutputCtrlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, idColumnName);
	}
	
	
	public String getId(String enrlXmlOutputId) throws Exception{
		return getColumnValue(enrlXmlOutputId, idColumnName);
	}
		
	
	private String getColumnValue(String elgId, String fName, String lName, String coverageType, String action, String columnName) throws Exception{
		String enrlXmlOutputId = new EnrlXmlInputCtrlTable(conn,testCaseId).getEnrlXmlOutputId(elgId, fName, lName, coverageType, action);
		
		return getColumnValue(enrlXmlOutputId, columnName);
	}
	
	private String getColumnValue(String enrlXmlOutputId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+idColumnName+" = "+enrlXmlOutputId;
		return getCellDataFromDB(query,columnName);
	}
}
