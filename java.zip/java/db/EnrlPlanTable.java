package db;

import java.sql.Connection;
import java.util.ArrayList;

//Ritu
public class EnrlPlanTable extends  SuperTable{
	

	private String tableName = "MAHX_OWN.ENRL_PLAN  ";
	private String enrlMemberIdColumnName = "ENRL_MEMBER_ID ";
	private String enrollmentStatusColumnName ="ENROLLMENT_STATUS";  

	public EnrlPlanTable(Connection conn, String testCaseId) 
	{
		super(conn, testCaseId);
	}
	public void updateEnrollmentStatus(String userProfileRefId ,String enrollStatusValue,String newStatusValue) throws Exception
	{
		EnrollmentTable enrollmentTable = new  EnrollmentTable(conn, testCaseId);
		ArrayList<String> enrollmentIds = enrollmentTable.getIDsUsingUserProfileRefId(userProfileRefId ,newStatusValue);	
		for (String enrlMemberId : enrollmentIds) {
			updateStatusColumnValue(enrlMemberId, enrollStatusValue);
		}
	}
	
	private void updateStatusColumnValue(String enrlMemberId, String enrollStatusValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + enrollmentStatusColumnName + " = '" + enrollStatusValue + "'" + " WHERE "
				+ enrlMemberIdColumnName + " = " + enrlMemberId;

		executeQuery(query);

	}

}
