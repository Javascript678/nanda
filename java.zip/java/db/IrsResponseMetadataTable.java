package db;

import java.sql.Connection;

public class IrsResponseMetadataTable extends SuperTable {
	
	private String tableName = "MAHX_OWN.IRS_RESPONSE_METADATA";
	private String tableNameOnUI = "IRS_RESPONSE_METADATA";
	private String responseCodeColumnName = "RESPONSE_CODE";
	private String responseDescriptionColumnName = "RESPONSE_DESCRIPTION";
	private String irsMemVerIdColumnName = "IRS_MEM_VER_ID";

	public IrsResponseMetadataTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public void ccaRenewalResponseCodeDescriptionUpdateQuery(String userProfileRefId, int memInd, String code, String description) throws Exception {	
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memInd);
		
		IrsMemberVerificationTable irsMemberVerificationTable = new IrsMemberVerificationTable(conn, testCaseId);
		String irsMemVerId = irsMemberVerificationTable.getId(elgId, memRefId, "CCA_RENEWAL");
		
		updateMagiAmtColumn(irsMemVerId, code, description);
	}
	
	
	public void updateMagiAmtColumn(String irsMemVerId, String columnValue1, String columnValue2) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + responseCodeColumnName + " = '" + columnValue1 + "'," +
					   			 responseDescriptionColumnName + " = '" + columnValue2 + "'" + 
					   " WHERE " + irsMemVerIdColumnName + " IN (" + irsMemVerId + ")";
		
		executeQuery(query);
	}

}
