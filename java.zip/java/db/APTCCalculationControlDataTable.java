package db;

import java.sql.Connection;

/**
 * 
 * @author Ritika
 *
 */
public class APTCCalculationControlDataTable extends SuperTable {
	private String tableName = "MAHX_OWN.RENEWAL_ELG_TRACKER";
	private String eligibilityIdColumnName = "ELIGIBILITY_ID";
	private String idColumnName = "ID";
	
	public APTCCalculationControlDataTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String userProfileRefId) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		return getColumnValue(elgId, idColumnName);
	}
	
	private String getColumnValue(String elgId,String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+eligibilityIdColumnName+" = "+elgId;
		return getCellDataFromDB(query,columnName);
	}

}
