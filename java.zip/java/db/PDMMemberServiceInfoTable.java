package db;

import java.sql.Connection;

public class PDMMemberServiceInfoTable extends SuperTable {

	private String tableName = "MAHX_OWN.PDM_MEMBER_SERVICE_INFO";
	private String serviceNameColumnName="SERVICE_NAME";
	private String serviceStatusColumnName="SERVICE_STATUS";
	private String pdmMemberTrackerIdColumnName="PDM_MEMBER_TRACKER_ID";
	private String idColumnName="ID";
	
	public PDMMemberServiceInfoTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public void validateServiceStatus(String userProfileRefId, int memIndex,String serviceName,String expServiceStatus) throws Exception{
		PDMMemberTrackerTable pdmMemberTrackerTable = new PDMMemberTrackerTable(conn, testCaseId);
		String id =pdmMemberTrackerTable.getId(userProfileRefId, memIndex);
		String actServiceStatus =getColumnValue(id,serviceName ,serviceStatusColumnName);
		validateDBFieldValue(tableName, serviceStatusColumnName, expServiceStatus, actServiceStatus);
	}

	public String getId(String userProfileRefId, int memIndex) throws Exception
	{
		PDMMemberTrackerTable pdmMemberTrackerTable = new PDMMemberTrackerTable(conn, testCaseId);
		String id =pdmMemberTrackerTable.getId(userProfileRefId, memIndex);
		String pdmId =getColumnValue(id, idColumnName);
		return pdmId;
	}
	
	private String getColumnValue(String pdmMemId,String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+pdmMemberTrackerIdColumnName+" = "+pdmMemId;
		return getCellDataFromDB(query, columnName);
	}
	
	private String getColumnValue(String pdmMemId,String serviceName,String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+pdmMemberTrackerIdColumnName+" = "+pdmMemId+" AND "+serviceNameColumnName+"='"+serviceName+"'";
		return getCellDataFromDB(query, columnName);
	}

}
