package db;

import java.sql.Connection;

/**
 * 
 * @author Vinay
 *
 */
public class DuplicateMemberTable extends SuperTable {
	private String tableName = "MAHX_OWN.DUPLICATE_MEMBER";
	private String elgMemIdColumnName = "ELG_MEMBER_ID";
	private String idColumnName = "ID";
	

	public DuplicateMemberTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getId(String elgId, String fName, String lName) throws Exception{
		String elgMemId = new ElgMemberTable(conn, testCaseId).getId(elgId, fName, lName);
		return getColumnValue(elgMemId, idColumnName);
	}
	
	public int getDupMemRowCount(String elgId, String fName, String lName) throws Exception{
		String elgMemId = new ElgMemberTable(conn, testCaseId).getId(elgId, fName, lName);
		return getRowCountUsingElgId(elgMemId);
	}
	
	private String getColumnValue(String elgMemId, String columnName) throws Exception {
		String query = "SELECT * " + " FROM " + tableName + " WHERE " + elgMemIdColumnName + " = " + elgMemId;
		return getCellDataFromDB(query, columnName);
	}
	
	private int getRowCountUsingElgId(String elgMemId) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE " + elgMemIdColumnName + " = " + elgMemId;
		return getRowCount(query);
	}

}
