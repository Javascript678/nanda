	package db;

import java.sql.Connection;

/**
 * 
 * @author Ritika
 *
 */
public class PDMProfileTrackerTable extends SuperTable {
	private String tableName = "MAHX_OWN.PDM_PROFILE_TRACKER";
	private String oldEligibilityIdColumnName = "OLD_ELIGIBILITY_ID";
	private String newEligibilityIdColumnName = "NEW_ELIGIBILITY_ID";
	private String idColumnName = "ID";
	private String statusColumnName = "STATUS";
	private String rrvProcessIdColumnName = "RRV_PROCESS_ID";
	private String pdmProcessColumnName = "PDM_PROCESS_ID";

	private String valueToHold = "99999";
    private String valueToUnhold ="NULL";

	
	public PDMProfileTrackerTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public void validateStatus(String userProfileRefId,String expStatus) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		String actStatus =getColumnValue(elgId, statusColumnName);
		validateDBFieldValue(elgId, statusColumnName, expStatus, actStatus);
	}
	
	public String getId(String userProfileRefId) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		return getColumnValue(elgId, idColumnName);
	}
	
	public void updateRRVProcessId(String userProfileRefId,String RRVValue) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		updateColumnValue(elgId, rrvProcessIdColumnName, RRVValue);
	}
	
	public String getNewElgId(String userProfileRefId) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		return getColumnValue(elgId, newEligibilityIdColumnName);
	}
	
	

    //Aashita
    public void setPDMStatustoHold(String userProfileRefId) throws Exception {
          EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
          String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
          updatePDMProcessId(elgId ,valueToHold );
    }
    
    //Aashita
    public void setPDMStatustoUnHold(String userProfileRefId) throws Exception {
          EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
          String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
          updatePDMProcessId(elgId ,valueToUnhold );
    }

    //Aashita
    private void updatePDMProcessId(String elgId, String columnValue) throws Exception {

          String query = "UPDATE " + tableName + " SET "+ pdmProcessColumnName +" = "+ columnValue +"  WHERE "
                        + oldEligibilityIdColumnName + " = " +elgId+ " AND  "+ pdmProcessColumnName +" = 'RRV_REQ_INITIATED' AND "+ pdmProcessColumnName +"  = 'NULL'" ;
          executeQuery(query);
    }
	private String getColumnValue(String elgId,String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+oldEligibilityIdColumnName+" = "+elgId;
		return getCellDataFromDB(query,columnName);
	}
	
	private void updateColumnValue(String elgId, String columnName, String columnValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "'" + " WHERE "
				+ oldEligibilityIdColumnName + " = " +elgId ;
		executeQuery(query);

	}
	

}
