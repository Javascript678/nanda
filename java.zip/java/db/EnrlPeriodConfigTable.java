package db;

import java.sql.Connection;
import java.util.ArrayList;

public class EnrlPeriodConfigTable extends SuperTable 
{
	private String tableName = "MAHX_OWN.enrollment_period_config";
	private String tableNameOnUI = "Enrollment_Period_Config";
	private String startDateColumnName = "START_DATE";
	private String endDateColumnName = "END_DATE";
	private String planYearColumnName = "PLAN_YEAR";
	private String idColumnName = "ID";
	private String dbDateFormat ="yyyy-mm-dd";  

	
	public EnrlPeriodConfigTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getColumnValue(String planYear ,String sysdate) throws Exception
	{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+planYearColumnName +" in ('"+planYear+"','"+planYear+1+"')"
				+ " AND to_date('"+sysdate+"','"+dbDateFormat+"') BETWEEN "+startDateColumnName+" AND "+endDateColumnName+"";
		
		
		return getCellDataFromDB(query,idColumnName);
		
	}
	
	public void validateSEPPeriodExist(String planYear ,String sysdate) throws Exception
	{
		String id = getColumnValue(planYear,sysdate);
		validateDBFieldValue(tableNameOnUI, "ID", "", id);
		
	}
}
