package db;

import java.sql.Connection;
import java.util.ArrayList;

/**
 * 
 * @author Vinay
 *
 */
public class RrvBatchReqCtrlTable extends SuperTable {
	
	private String tableNameToShowOnReport = "RRV_BATCH_REQ_CTRL";
	private String tableName = "MAHX_OWN.RRV_BATCH_REQ_CTRL";
	private String idColumnName = "ID";
	private String reqFileNameColumnName = "REQ_FILE_NAME";

	public RrvBatchReqCtrlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getReqFileName(String userProfileRefId) throws Exception {
		RrvAggrTdsReqCtrlTable rrvTdsReqResCtrlTable = new RrvAggrTdsReqCtrlTable(conn, testCaseId);
		ArrayList<String> idArr = rrvTdsReqResCtrlTable.getRrvAggrTdsReqCtrlId(userProfileRefId);
		
		String ids = null;
		
		for(int i = 0; i < idArr.size(); i++){
			if(i == 0){
				ids = idArr.get(i);
			}else{
				ids = ids + ", " + idArr.get(i);
			}
		}
		
		return getColumnValue(ids, reqFileNameColumnName);
	}
	
	private String getColumnValue(String ids, String columnName) throws Exception {
		String query = "SELECT * " + 
				   " FROM " + tableName + 
				   " WHERE " + idColumnName + " IN (" + ids + ")";

		return getCellDataFromDB(query, columnName);
	}
}
