package db;

import java.sql.Connection;

public class ElgNoticeXmlTable extends SuperTable {

	private String tableName = "MAHX_OWN.ELG_NOTICE_XML";
	private String tableNameToShowOnUI = "ELG_CCA_NOTICE_XML_TABLE";
	private String idColumnName = "ID";
	private String elgIdColumnName = "ELG_ID";
	private String currentStatusColumnName = "CURRENT_STATUS";
	private String printTypeColumnName = "PRINT_TYPE";
	private String noticeXmlStringColumnName = "NOTICE_XML_STRING";
	private String noticeTypeColumnName = "NOTICE_TYPE";
	private String langTypeColumnName = "LANG";
	
	public ElgNoticeXmlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public int getCount(String elgId) throws Exception{
		return getRowCountUsingElgId(elgId);
	}
	
	public String getCurrentStatus(String elgId, String notice_type, String language, int noticeNo) throws Exception{
		return getColumnValue(elgId, notice_type, language, noticeNo, currentStatusColumnName);
	}
	
	public String getPrintType(String elgId, String notice_type, String language, int noticeNo) throws Exception{
		return getColumnValue(elgId, notice_type, language, noticeNo, printTypeColumnName);
	}

	public void validateCurrentStatus(String elgId, String notice_type, String language, int noticeNo,  String expCurrentStatus) throws Exception{
		String actualCurrentStatus = getCurrentStatus(elgId, notice_type, language, noticeNo);
		validateDBFieldValue(tableNameToShowOnUI, elgId+"_"+notice_type+"_"+language+"_"+noticeNo+"_"+"CURRENT_STATUS", expCurrentStatus, actualCurrentStatus);
	}
	
	public void validatePrintType(String elgId, String notice_type, String language, int noticeNo,  String expPrintType) throws Exception{
		String actualPrintType = getPrintType(elgId, notice_type, language, noticeNo);
		validateDBFieldValue(tableNameToShowOnUI, elgId+"_"+notice_type+"_"+language+"_"+noticeNo+"_"+"PRINT_TYPE", expPrintType, actualPrintType);
	}
	
	public void validateRowCountForElgId(String elgId, int expCount) throws Exception{
		int actualCount = getRowCountUsingElgId(elgId);
		validateDBFieldValue(tableNameToShowOnUI, elgId+"_"+"NoticeCount", expCount+"", actualCount+"");
	}
	
	private String getColumnValue(String elgId, String notice_type, String language, int noticeNo, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgIdColumnName+" = "+elgId
				+ " AND "+noticeTypeColumnName+" = '"+notice_type + "'"
				+ " AND "+langTypeColumnName+" = '"+language + "'";
		return getCellDataFromDB(query,noticeNo-1,columnName);
	}
	
	private int getRowCountUsingElgId(String elgId) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgIdColumnName+" = "+elgId;
		return getRowCount(query);
	}
}
