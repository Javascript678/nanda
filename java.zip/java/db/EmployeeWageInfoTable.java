package db;

import java.sql.Connection;

public class EmployeeWageInfoTable extends SuperTable {
	
	private String tableName = "MAHX_OWN.EMPLOYEE_WAGE_INFO";
	private String tableNameOnUI = "EMPLOYEE_WAGE_INFO";
	private String idColumnName = "ID";
	private String memDorIncomeIdColumnName = "MEM_DOR_INCOME_ID";
	private String reportedWagesColumnName = "REPORTED_WAGES";
	//

	public EmployeeWageInfoTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public void ccaRenewalReportedWagesUpdateQuery(String userProfileRefId, int memInd, String irsSsbIncome) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memInd);
		
		MemberDorIncomeTable memberDorIncomeTable = new MemberDorIncomeTable(conn, testCaseId);
		String memDorIncomeId = memberDorIncomeTable.getIdColumn(memRefId, "CCA_RENEWAL");	
		
		updateTaxableSSBColumn(memDorIncomeId, irsSsbIncome);
	}
	
	public void ccaRenewalReportedWagesNullUpdateQuery(String userProfileRefId, int memInd) throws Exception {	
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memInd);
		
		MemberDorIncomeTable memberDorIncomeTable = new MemberDorIncomeTable(conn, testCaseId);
		String memDorIncomeId = memberDorIncomeTable.getIdColumn(memRefId, "CCA_RENEWAL");	
		
		updateTaxableSSBNullColumn(memDorIncomeId);
	}
	
	public void updateTaxableSSBColumn(String memDorIncomeId, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + reportedWagesColumnName + " = '" + columnValue + "'" + 
					   " WHERE " + memDorIncomeIdColumnName + " = '" + memDorIncomeId + "'";
		
		executeQuery(query);
	}
	
	public void updateTaxableSSBNullColumn(String memDorIncomeId) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + reportedWagesColumnName + " = NULL" + 
					   " WHERE " + memDorIncomeIdColumnName + " = '" + memDorIncomeId + "'";
		
		executeQuery(query);
	}

}
