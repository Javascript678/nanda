package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Ritu
 *
 */
public class ElgMemberDocumentTable extends SuperTable {
	private String tableName = "MAHX_OWN.ELG_MEMBER_DOCUMENT";
	private String idColumnName = "ID";
	private String elgMemberIdColumnName = "ELG_MEMBER_ID";
	private String documentNameColumnName = "DOCUMENT_CATEGORY";
	private String dueDateColumnName = "DUE_DATE";

	public ElgMemberDocumentTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getIdUsingEligId(String elgId, int memIndex, String docName) throws Exception {
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);

		return getColumnValueUsingEligMemberId(elgMemId, docName, idColumnName);
	}
	
	public String getIdUsingEligMemId(String elgMemId,String docName) throws Exception {
		return getColumnValueUsingEligMemberId(elgMemId, docName, idColumnName);
	}
	
	public String getIdUsingEligId(String elgId, String fName, String lName, String docName) throws Exception {
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, fName, lName);

		return getColumnValueUsingEligMemberId(elgMemId, docName, idColumnName);
	}

	public List<String> getIdsUsingEligId(String elgId, String docName) throws Exception {
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		List<String> elgMemId = elg_MemberTable.getIdS(elgId);

		return getColumnValuesUsingEligMemberId(elgMemId, docName, idColumnName);
	}

	public void updateDueDate(String userProfileRefId, int memIndex, String docName, String newValue) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
		String id = getIdUsingEligMemId(elgMemId, docName);
		updateVarCharColumnValue(id, dueDateColumnName, newValue);
	}

	public void updateDueDates(String userProfileRefId, String docName, String newValue) throws Exception {

		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		List<String> id = getIdsUsingEligId(elgId, docName); // updated
		for (String ids : id) {
			updateVarCharColumnValue(ids, dueDateColumnName, newValue);
		}
	}

	private List<String> getColumnValuesUsingEligMemberId(List<String> elgMemIds, String docName, String columnName)
			throws Exception {
		List<String> columnValues = new ArrayList<String>();

		for (String elgMemId : elgMemIds) {
			String colVal = getColumnValueUsingEligMemberId(elgMemId, docName, columnName);
			columnValues.add(colVal);
		}
		return columnValues;
	}

	private String getColumnValueUsingEligMemberId(String elgMemId, String docName, String columnName)
			throws Exception {

		String query = "SELECT * " + " FROM " + tableName + " WHERE " + elgMemberIdColumnName + " =" + elgMemId
				+ " AND " + documentNameColumnName + "='" + docName + "'";
		return getCellDataFromDB(query, columnName);

	}

	private void updateVarCharColumnValue(String id, String columnName, String columnValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "'" + " WHERE "
				+ idColumnName + " = " + id;

		executeQuery(query);

	}

}
