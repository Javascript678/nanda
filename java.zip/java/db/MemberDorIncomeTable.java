package db;

import java.sql.Connection;
import java.util.ArrayList;

public class MemberDorIncomeTable extends SuperTable {
	
	private String tableName = "MAHX_OWN.MEMBER_DOR_INCOME";
	private String tableNameOnUI = "MEMBER_DOR_INCOME";
	private String idColumnName = "ID";
	private String memRefIdColumnName = "MEM_REF_ID";
	private String requestInitSourceColumnName = "REQUEST_INIT_SOURCE";

	public MemberDorIncomeTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getIdColumn(String memRefId, String init) throws Exception {
		return getIdColumnValue(memRefId, init);
	}
	
	
	private String getIdColumnValue(String memRefId, String init) throws Exception {
		String query = "SELECT * " +
					    " FROM " + tableName +
					    " WHERE " + requestInitSourceColumnName + " = '" + init + "'" +
						" AND " + memRefIdColumnName + " = '" + memRefId + "'";

		return getCellDataFromDB(query, idColumnName);
	}

}
