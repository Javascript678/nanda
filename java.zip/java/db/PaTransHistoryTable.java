package db;

import java.sql.Connection;
import java.util.List;

public class PaTransHistoryTable extends SuperTable {
	
	private String tableName = "MAHX_OWN.PA_TRANS_HISTORY";
	private String userProfileIdColumnName = "USER_PROFILE_ID";
	private String paHtlCvrgIdcolumnName = "PA_HLT_CVRG_ID";
	private String tableNameToShowOnUI = "PaHltCvrgId";
	private String FileName = "PaHltCvrgId";

	public PaTransHistoryTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	/*public List<String> getPaHltCvrgIdsUsingUserRefId(String referenceId) throws Exception {
		UserProfileTable userProfileTab = new UserProfileTable(conn, testCaseId);
		String userProfileId = userProfileTab.getIdUsingReferenceId(referenceId);

		return getColumnValuesUsingUserProfileId(userProfileId, paHtlCvrgIdcolumnName);
	}*/

	public String getPaHltCvrgIdUsingUserRefId(String referenceId) throws Exception {
		UserProfileTable userProfileTab = new UserProfileTable(conn, testCaseId);
		String userProfileId = userProfileTab.getIdUsingReferenceId(referenceId);

		return getColumnValueUsingUserProfileId(userProfileId, paHtlCvrgIdcolumnName);
	}

	/*public List<String> getColumnValuesUsingUserProfileId(String userProfileId, String columnName) {
		String query = "SELECT * " + " FROM " + tableName + " WHERE " + userProfileIdColumnName + " = '" + userProfileId
				+ "'";
		return getColumnDataFromDB(query, columnName);

	}*/

	public String getColumnValueUsingUserProfileId(String userProfileId, String columnName) throws Exception {
		String query = "SELECT * " + " FROM " + tableName + " WHERE " + userProfileIdColumnName + " = '" + userProfileId
				+ "' order by CREATED_DATE desc";
		return getCellDataFromDB(query, columnName);

	}

}
