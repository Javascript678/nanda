
package db;

import java.sql.Connection;

/**
 * @author smishr80
 *
 */
public class AddressTable extends SuperTable {

	private String memberAddressTableName = "mahx_own.address";
	private String idColumnName = "ID";
	private String streetAddress1 = "street_addressline1";
	private String streetAddress2 = "street_addressline2";
	private String city = "city";
	private String stateCode = "state_code";
	private String zip = "zip";

	public AddressTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);

	}

	// Shivam
	public String getAdressUsingRefId(String userProfileRefId, int memIndex) throws Exception {

		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		ContactInfoAddressMPNGTable contactInfoAddressMPNGTable = new ContactInfoAddressMPNGTable(conn, testCaseId);

		String eligId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		String contactInfoId = elgMemberTable.getContactInfoId(eligId, memIndex);
		String addressid = contactInfoAddressMPNGTable.getAddressIdUsingContactInfoId(contactInfoId);
		String streetAdd1 = getColumnValue(addressid, streetAddress1);
		String streetAdd2 = getColumnValue(addressid, streetAddress2);
		String cityAdd = getColumnValue(addressid, city);
		String stateAdd = getColumnValue(addressid, stateCode);
		String zipAdd = getColumnValue(addressid, zip);

		String address = streetAdd1 + " \n" + streetAdd2 + " \n" + cityAdd +  ", " + stateAdd + " " + zipAdd;
		return address;

	}

	//Shivam
	public String getAdressUsingElgId(String eligId, int memIndex) throws Exception {

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		ContactInfoAddressMPNGTable contactInfoAddressMPNGTable = new ContactInfoAddressMPNGTable(conn, testCaseId);

		String contactInfoId = elgMemberTable.getContactInfoId(eligId, memIndex);
		String addressid = contactInfoAddressMPNGTable.getAddressIdUsingContactInfoId(contactInfoId);
		String streetAdd1 = getColumnValue(addressid, streetAddress1);
		String streetAdd2 = getColumnValue(addressid, streetAddress2);
		String cityAdd = getColumnValue(addressid, city);
		String stateAdd = getColumnValue(addressid, stateCode);
		String zipAdd = getColumnValue(addressid, zip);

		String address = streetAdd1 + " \n" + streetAdd2 + " \n" + cityAdd +  ", " + stateAdd + " " + zipAdd;
		return address;

	}

	private String getColumnValue(String addressid, String columnName) throws Exception {
		String query = "SELECT * " + " FROM " + memberAddressTableName + " WHERE " + idColumnName + " = " + addressid;
		return getCellDataFromDB(query, columnName);

	}
}
