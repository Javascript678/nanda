package db;

import java.sql.Connection;

public class DOReventTriggersTable extends SuperTable {

	private String tableName = "MAHX_OWN.DOR_EVENT_TRIGGERS";
	private String tableNameToShowOnUI = "DOR_EVENT_TRIGGERS";
	private String elgIdColumnName = "ELIGIBILITY_ID";
	private String statusColumnName = "STATUS";
	
	public DOReventTriggersTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	private String getColumnValue(String elgId, String columnName) throws Exception{
		String query = "SELECT * " 
				     + " FROM " + tableName
				     + " WHERE " + elgIdColumnName + " = " + elgId;
		return getCellDataFromDB(query,columnName);
	}
	
	public String getStatus(String elgId) throws Exception{
		return getColumnValue(elgId, statusColumnName);
	}	
	
	public void validateStatus(String elgId, String expStatus) throws Exception{
		String actualStatus = getStatus(elgId);
		validateDBFieldValue(tableNameToShowOnUI, "STATUS", expStatus, actualStatus);
	}

}
