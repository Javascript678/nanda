package db;

import java.sql.Connection;

/**
 * 
 * @author Ritika
 *
 */
public class HSNControlDataTable extends SuperTable {
	private String tableName = "MAHX_OWN.HSN_CONTROL_DATA";
	private String eligibilityIdColumnName = "ELIGIBILITY_ID";
	private String statusColumnName = "STATUS";
	private String startDateColumnName = "START_DATE";
	private String endDateColumnName = "END_DATE";

	public HSNControlDataTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public void updateEndDate(String userProfileRefId,String newEndDateValue)
			throws Exception 
	{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		updateColumnValue(elgId , endDateColumnName, newEndDateValue);
	}
	
	public void updateStartDate(String userProfileRefId, String newStartDateValue)
			throws Exception 
	{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		updateColumnValue(elgId , startDateColumnName, newStartDateValue);
	}
	
	public void updateStatus(String userProfileRefId,String newStatusValue)
			throws Exception 
	{
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		updateColumnValue(elgId , statusColumnName, newStatusValue);
	}

	private void updateColumnValue(String elgId, String columnName, String columnValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "'" + " WHERE "
				+ eligibilityIdColumnName + " = " +elgId ;

		executeQuery(query);

	}

}
