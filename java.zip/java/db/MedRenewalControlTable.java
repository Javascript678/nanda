package db;

import java.sql.Connection;

/**
 * 
 * @author Paul
 *
 */
public class MedRenewalControlTable extends SuperTable {

	private static String tableNameToShowOnReport = "MED_RENEWAL_CONTROL";
	private static String tableName = "MAHX_OWN.MED_RENEWAL_CONTROL";
	private static String idColumnName = "ID";
	private static String statusColumnName = "STATUS";
	private static String eligibilityIdColumnName = "ELIGIBILITY_ID";
	private static String medRenewalTrackerColumnName = "MED_RENEWAL_TRACKER_ID";
	private static String medRenewalTdsCallValueColumnName = "MED_RENEWAL_TDS_CALL_VALUE";
	private static String memRefIdColumnName = "MEM_REF_ID";

	public MedRenewalControlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getId(String userProfileRefId, int memIndex) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		MedRenewalTrackerTable medRenewalTracker = new MedRenewalTrackerTable(conn, testCaseId);
		String medRenewalTrackerId = medRenewalTracker.getId(elgId, memIndex);

		return getColumnValue(elgId, medRenewalTrackerId, idColumnName);
	}

	public String getStatus(String userProfileRefId, int memIndex) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		MedRenewalTrackerTable medRenewalTracker = new MedRenewalTrackerTable(conn, testCaseId);
		String medRenewalTrackerId = medRenewalTracker.getId(elgId, memIndex);

		return getColumnValue(elgId, medRenewalTrackerId, statusColumnName);
	}

	public void validateStatus(String userProfileRefId, int memIndex, String expStatus) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memIndex);

		String actualStatus = getColumnValue(elgId, memRefId, statusColumnName);
		validateDBFieldValue(tableNameToShowOnReport, statusColumnName, expStatus, actualStatus);
	}

	public void updateMedRenewalTdsCallValue(String userProfileRefId, int memIndex) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memIndex);

		String medRenewalTdsCallValueColumnValue = "55";

		updateColumnValue(elgId, memRefId, medRenewalTdsCallValueColumnName, medRenewalTdsCallValueColumnValue);
	}

	private String getColumnValue(String elgId, String memRefId, String columnName) throws Exception {
		String query = "SELECT * " + 
					   " FROM " + tableName + 
					   " WHERE " + memRefIdColumnName + " = '" + memRefId + "'" + 
					   " AND " + eligibilityIdColumnName + "= " + elgId;

		return getCellDataFromDB(query, columnName);
	}

	private void updateColumnValue(String elgId, String memRefId, String columnName, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + columnName + "='" + columnValue + "'" + 
					   " WHERE " + memRefIdColumnName + " = '" + memRefId + "'" + 
					   " AND " + eligibilityIdColumnName + "= " + elgId;

		executeQuery(query);
	}

	public static String selectStatusColumn(String elgId) throws Exception {
		String query = "SELECT " + statusColumnName + 
					   " FROM " + tableName + 
					   " WHERE " + eligibilityIdColumnName + " = " + elgId;

		return query;
	}

}
