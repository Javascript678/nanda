package db;

import java.sql.Connection;

/**
 * @author smishr80
 *
 */
public class ContactInfoAddressMPNGTable extends SuperTable{
	
	private String tableName = "mahx_own.CONTACT_INFO_ADDRESS_MPNG";
	private String conInId = "contact_info_id";
	private String addressId  = "address_id";

	public ContactInfoAddressMPNGTable(Connection conn, String testCaseId) {

		super(conn, testCaseId);
		
	}
	

	public String getAddressIdUsingContactInfoId(String contactInfoId) throws Exception {
		
		return getAddressId(contactInfoId,addressId);
	}

	private String getAddressId(String contactInfoId,String addressId) throws Exception{
		String query = "SELECT *" 
				+ " FROM "+ tableName
				+ " WHERE "+conInId+" = "+contactInfoId ;
		return getCellDataFromDB(query,addressId);
	}

}
