package db;

import java.sql.Connection;

/**
 * 
 * @author Vinay
 *
 */
public class RenewalConfigTable extends SuperTable {
	private String tableName = "MAHX_OWN.RENEWAL_CONFIG";
	private String configTypeColumnName = "CONFIG_TYPE";
	private String valueColumnName = "VALUE";

	public RenewalConfigTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public void updateConfigTypeNextCycleRenewDefaultCount(String newVal) throws Exception {
		updateConfigColumnValue("NEXT_CYCLE_RENEW_DEFAULT_COUNT", newVal);
	}
	
	public void updateConfigTypeNextCycleRenewOverrideCount(String newVal) throws Exception {
		updateConfigColumnValue("NEXT_CYCLE_RENEW_OVERRIDE_COUNT", newVal);
	}
	
	public void updateConfigTypeStreamlineRenewalSnapBasedEnable(String newVal) throws Exception {
		updateConfigColumnValue("STREAMLINE_RENEWAL_SNAP_BASED_ENABLE", newVal);
	}
	
	public void updateConfigTypeStreamlineRenewalSsiBasedEnable(String newVal) throws Exception {
		updateConfigColumnValue("STREAMLINE_RENEWAL_SSI_BASED_ENABLE", newVal);
	}
	
	public void updateConfigTypeStreamlineRenewalApplyGrpCriteria(String newVal) throws Exception {
		updateConfigColumnValue("STREAMLINE_RENEWAL_APPLY_GROUP_CRITERIA", newVal);
	}
	
	public void updateConfigTypeMedicaidRenewalFilterOpenRfi(String newVal) throws Exception {
		updateConfigColumnValue("MEDICAID_RENEWAL_FILTER_OPEN_RFI", newVal);
	}
	
	public void updateConfigTypeStreamlineRenewalApplySsiCriteria(String newVal) throws Exception {
		updateConfigColumnValue("STREAMLINE_RENEWAL_APPLY_SSI_CRITERIA", newVal);
	}
	
	public void updateConfigTypeStreamlineRenewalFilterOpenRfi(String newVal) throws Exception {
		updateConfigColumnValue("STREAMLINED_RENEWAL_FILTER_OPEN_RFI", newVal);
	}
	
	
	public void updateConfigTypeMedicaidRenewalFilterPdmTimeclock(String newVal) throws Exception {
		updateConfigColumnValue("MEDICAID_RENEWAL_FILTER_PDM_TIMECLOCK", newVal);
	}
	
	
	public void updateConfigTypeDaysBeforeToPickStreamline(String newVal) throws Exception {
		updateConfigColumnValue("DAYS_BEFORE_TO_PICK_STREAMLINE", newVal);
	}
	
	public void updateConfigTypeDaysBeforeToPickNormalMH(String newVal) throws Exception {
		updateConfigColumnValue("DAYS_BEFORE_TO_PICK_NORMAL_MH", newVal);
	}
	
	public void updateConfigTypeDaysBeforeToPickAll(String newVal) throws Exception {
		updateConfigColumnValue("DAYS_BEFORE_TO_PICK_ALL", newVal);
	}
	
	
	private void updateConfigColumnValue(String configName,String configValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + valueColumnName + " = '" + configValue + "'" + " WHERE "
				+ configTypeColumnName + " = '" + configName + "'";

		executeQuery(query);
	}
}
