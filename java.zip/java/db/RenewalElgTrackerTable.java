package db;

import java.sql.Connection;
import java.util.HashMap;

import appdata.evpd.EVPD_Data;
import mysql.MySQL;
import stepdefs.support.Hook;
import utils.DateUtil;
import utils.TestData;

/**@author:ppinho
 *
 */
public class RenewalElgTrackerTable extends SuperTable {
	
	private static String tableNameToShowOnReport = "RENEWAL_ELG_TRACKER";
	private static String tableName = "MAHX_OWN.RENEWAL_ELG_TRACKER";
	private static String oldEligibilityIdColumnName = "OLD_ELIGIBILITY_ID";
	private static String newEligibilityIdColumnName = "NEW_ELIGIBILITY_ID";
	private static String userProfileIdColumnName = "USER_PROFILE_ID";
	private static String statusColumnName = "STATUS";
	private static String processIdColumnName = "PROCESS_ID";
	private static String updatedByColumnName = "UPDATED_BY";
	private static String planYearColumnName = "PLAN_YEAR";


	public RenewalElgTrackerTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getNewElgId(String userProfileRefId) throws Exception {
		UserProfileTable userProfileTable = new UserProfileTable(conn, testCaseId);
		String userProfileId = userProfileTable.getIdUsingReferenceId(userProfileRefId);

		return getNewElgIdColumnValue(userProfileId, newEligibilityIdColumnName);
	}
	
	public void updateStatus(String userProfileRefId, String newStatusValue) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		String query = updateStatusColumn(elgId, statusColumnName, newStatusValue);
		executeQuery(query);
	}
	
	public void validateStatus(String userProfileRefId, String expStatus) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		String actualStatus = getStatusColumnValue(elgId, statusColumnName);
		validateDBFieldValue(tableNameToShowOnReport, statusColumnName, expStatus, actualStatus);
	}

	public void ccaRenewalHoldElgIdsUpdateQuery(String elgIds, HashMap<String, String> globalData) throws Exception {
		int year = Integer.valueOf(globalData.get("ApplicationCreationYear")) +1;
		String query = updateProcessIdUpdatedByWherePlanYearStatusOldElgId(elgIds, String.valueOf(year));
		executeQuery(query);
	}
	
	public void ccaRenewalProcessIdUpdateQuery(EVPD_Data evpdData) throws Exception {
		String query = null;
		
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(evpdData.memsData.get(0).userRefId);
		
		query = updateProcessIdUpdatedByWhereElgId(elgId);
		executeQuery(query);
	}
	
	private String getNewElgIdColumnValue(String userProfileId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM " + tableName
				+ " WHERE " + userProfileIdColumnName + " = " + userProfileId;
		
		return getCellDataFromDB(query, columnName);
	}
	
	private String getStatusColumnValue(String elgId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM " + tableName
				+ " WHERE "+ oldEligibilityIdColumnName + "= " + elgId;
		
		return getCellDataFromDB(query, columnName);
	}
	
	public static String selectStatusColumn(String elgId) throws Exception {
		String query = "SELECT " + statusColumnName + 
					   " FROM " + tableName +
					   " WHERE " + oldEligibilityIdColumnName + " = " + elgId;

		return query;
	}
	
	public String updateStatusColumn(String elgId, String columnName, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + columnName + " = '" + columnValue + "'" + 
					   " WHERE " + oldEligibilityIdColumnName + " = " + elgId;

		return query;
	}
	
	public static String updateProcessIdUpdatedByWherePlanYearStatusOldElgId(String elgId, String year) throws Exception {
		String query = "UPDATE " + tableName + " " + 
					   "SET " + processIdColumnName + " = '9999', " + 
					   			updatedByColumnName + " = 'CONTACT_QA' " +
					   "WHERE " + planYearColumnName + " = " + year + " " +
					   "AND " + statusColumnName + " = 'NOT_PROCESSED' " +
					   "AND " + oldEligibilityIdColumnName + " NOT IN (" + elgId + ")";

		return query;
		
	}
	
	public static String updateProcessIdUpdatedByWhereElgId(String elgId) throws Exception {
		String query = "UPDATE " + tableName + " " + 
					   "SET " + processIdColumnName + " = NULL, " + 
					   			updatedByColumnName + " = NULL " +
					   "WHERE " + oldEligibilityIdColumnName + " IN (" + elgId + ")";

		return query;
	}

}
