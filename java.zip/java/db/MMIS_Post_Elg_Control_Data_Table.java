package db;

import java.sql.Connection;

public class MMIS_Post_Elg_Control_Data_Table extends SuperTable {

	private String tableName = "MAHX_OWN.MMIS_POST_ELG_CONTROL_DATA";
	private String tableNameToShowOnUI = "MMIS_TABLE";
	private String controlDataIdColumnName = "CONTROL_DATA_ID";
	private String currentStatusColumnName = "CURRENT_STATUS";
	private String medicaidStatusColumnName = "MEDICAID_STATUS";
	private String requestXmlClobColumnName = "REQUEST_XML_CLOB";
	private String responseXmlClobColumnName = "RESPONSE_XML_CLOB";
	private String agencyMemIdColumnName = "AGENCY_MEMBER_ID";
	private String elgMemIdColumnName = "ELG_MEMBER_ID";
	private String elgIdColumnName = "ELIGIBILITY_ID";
	public static String currentStatusFieldValueAsWsProcessed = "WS_CALL_PROCESSED";
	public static String currentStatusFieldValueAsWsInProgress = "WS_CALL_IN_PROGRESS";
	
	public MMIS_Post_Elg_Control_Data_Table(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getControlDataId(String elgId, String fName, String lName) throws Exception{
		return getColumnValue(elgId, fName, lName, controlDataIdColumnName);
	}
	
	public String getCurrentStatus(String elgId, String fName, String lName) throws Exception{
		return getColumnValue(elgId, fName, lName, currentStatusColumnName);
	}
	
	//Shailza
	public String getMedicaidStatus(String elgId, String fName, String lName) throws Exception{
		return getColumnValue(elgId, fName, lName, medicaidStatusColumnName);
	}
	
	public String getRequestXMLClob(String elgId, String fName, String lName) throws Exception{
		return getColumnValue(elgId, fName, lName, requestXmlClobColumnName);
	}
	
	public String getResponseXMLClob(String elgId, String fName, String lName) throws Exception{
		return getColumnValue(elgId, fName, lName, responseXmlClobColumnName);
	}
	
	public String storeRequestXMLClob(String elgId, String fName, String lName) throws Exception{
		String xmlValue = getRequestXMLClob(elgId, fName, lName);
		String xmlLink = storeXml(tableNameToShowOnUI, xmlValue, "MMIS_"+ requestXmlClobColumnName+"_" + elgId+"_"+fName + "_" + lName);
		return xmlLink;
	}
	
	public String storeResponseXMLClob(String elgId, String fName, String lName) throws Exception{
		String xmlValue = getResponseXMLClob(elgId, fName, lName);
		String xmlLink = storeXml(tableNameToShowOnUI, xmlValue, "MMIS_"+ responseXmlClobColumnName+"_" + elgId+"_"+fName + "_" + lName);
		return xmlLink;
	}
	
	private String getColumnValue(String elgId, String fName, String lName, String columnName) throws Exception{		
		String elgMemId = new ElgMemberTable(conn,testCaseId).getId(elgId, fName, lName);
		
		String query = "SELECT * "
				+ " FROM " + tableName
				+ " WHERE ELG_MEMBER_ID = " + elgMemId;
		
		return getCellDataFromDB(query, columnName);
	}
	
	// Amrita
	private int getRowCountForMember(String elgId, String fName, String lName) throws Exception {

		String elgMemId = new ElgMemberTable(conn, testCaseId).getId(elgId, fName, lName);

		String query = "SELECT * " + " FROM " + tableName + " WHERE ELG_MEMBER_ID = " + elgMemId;
		return getRowCount(query);
	}

	// Amrita
	private int getRowCountUsingElgId(String elgId) throws Exception {
		String query = "SELECT * " + " FROM " + tableName + " WHERE " + elgIdColumnName + " = " + elgId;
		return getRowCount(query);
	}

	
	
	public void validateControlDataIdFieldValue(String elgId, String fName, String lName,String expValue) throws Exception{
		String controlDataId = getControlDataId(elgId, fName, lName);
		validateDBFieldValue(controlDataIdColumnName, expValue, controlDataId);
	}
	
	public void validateCurrentStatusFieldValue(String elgId, String fName, String lName,String expValue) throws Exception{
		String currentStatus="";
		try{
			currentStatus = getCurrentStatus(elgId, fName, lName);
		}catch(Exception e){
			throw new Exception("MMIS log could not be found for Eligibility ID [" + elgId + "] FName[" +fName + "] Last Name [" +lName+"]");
		}
		
		validateDBFieldValue(currentStatusColumnName, expValue, currentStatus);
	}
	
	//Shailza
	public void validateMedicaidStatusFieldValue(String elgId, String fName, String lName,String expValue) throws Exception{
		String medicaidStatus="";
		try{
			medicaidStatus = getMedicaidStatus(elgId, fName, lName);
		}catch(Exception e){
			throw new Exception("MMIS log could not be found for Eligibility ID [" + elgId + "] FName[" +fName + "] Last Name [" +lName+"]");
		}
		
		validateDBFieldValue(medicaidStatusColumnName, expValue, medicaidStatus);
	}
	
	
	public void validateDBFieldValue(String fieldName, String expValue, String actValue) throws Exception{
		validateDBFieldValue(tableNameToShowOnUI, fieldName, expValue, actValue);
	}
	
	// Amrita
	public void validateRowCountForElgId(String elgId, int expCount) throws Exception {
		int actualCount = getRowCountUsingElgId(elgId);
		validateDBFieldValue(tableNameToShowOnUI, "STATUS", expCount + "", actualCount + "");
	}

	// Amrita
	public void validateRowCountForMember(String elgId, String memFName, String memLName, int expCount)
			throws Exception {
		int actualCount = getRowCountForMember(elgId, memFName, memLName);
		validateDBFieldValue(tableNameToShowOnUI, "STATUS", expCount + "", actualCount + "");
	}
	
	//Ritu new added	
	public String getAgencyMemberId(String elgId, int memIndex) throws Exception{
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		String elgMemId = elg_MemberTable.getId(elgId, memIndex);
			
		return getColumnValue(elgMemId, agencyMemIdColumnName);
			
	}
	
	private String getColumnValue(String elgMemId,String agencyMemIdColumnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgMemIdColumnName+" = " + elgMemId ;
		
		return getCellDataFromDB(query, agencyMemIdColumnName);
	}
	
	public String getMemXmlData(String elgId, String fName, String lName) {
		String query = "SELECT * " +
					   "FROM MAHX_OWN.MMIS_POST_ELG_CONTROL_DATA " +
					   "WHERE ELG_MEMBER_ID = (SELECT ID " +
                       						  "FROM MAHX_OWN.ELG_MEMBER " +
                       						  "WHERE ELIGIBILITY_ID = " + elgId + " " +
                       						  "AND FIRST_NAME = '" + fName + "' " +
                       						  "AND LAST_NAME = '" + lName + "') ";
		
		return query;
	}
	
}
