package db;

import java.sql.Connection;

public class DORreferralRecordInterfaceTable extends SuperTable {

	private String tableName = "MAHX_OWN.DOR_REFERRAL_RECORD_INTERFACE";
	private String tableNameToShowOnUI = "DOR_REFERRAL_RECORD_INTERFACE";
	private String statusColumnName = "DATA_TRANS_STATUS";
	private String dorRefRecTrackerIdColumnName = "DOR_REFERRAL_RECORD_TRACKER_ID";
	
	public DORreferralRecordInterfaceTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}	
	
	private String getColumnValue(String dorRefRecTrackerId, String columnName) throws Exception{
		String query = "SELECT * " 
				     + " FROM " + tableName
				     + " WHERE " + dorRefRecTrackerIdColumnName + " = " + dorRefRecTrackerId;
		return getCellDataFromDB(query, columnName);
	}
	
	private String getStatus(String elgId, String fName, String lName) throws Exception{
		String elgMemRefId = new ElgMemberTable(conn, testCaseId).getMemberReferenceId(elgId, fName, lName);
		String refUnitId = new DORreferralUnitTable(conn, testCaseId).getId(elgMemRefId, fName, lName);
		String dorRefRecTrackerId = new DORreferralRecordTrackerTable(conn, testCaseId).getId(refUnitId, fName, lName);
		return getColumnValue(dorRefRecTrackerId, statusColumnName);
	}
		
	public void validateStatus(String elgId, String fName, String lName, String expStatus) throws Exception{
		String actualStatus = getStatus(elgId, fName, lName);
		validateDBFieldValue(tableNameToShowOnUI, "STATUS", expStatus, actualStatus);
	}

}
