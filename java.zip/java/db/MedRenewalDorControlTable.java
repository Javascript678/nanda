package db;

import java.sql.Connection;

/**
 * 
 * @author Vinay
 *
 */
public class MedRenewalDorControlTable extends SuperTable {
	
	private String tableNameToShowOnReport = "MED_RENEWAL_DOR_CONTROL";
	private String tableName = "MAHX_OWN.MED_RENEWAL_DOR_CONTROL";
	private String idColumnName = "ID";
	private String statusColumnName = "STATUS";
	private String eligibilityIdColumnName = "ELIGIBILITY_ID";
	private String memRefIdColumnName = "MEM_REF_ID";
	private String xmlResponseColumnName = "XML_RESPONSE";
	
	public MedRenewalDorControlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String userProfileRefId, int memIndex) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);

		return getColumnValue(elgId, memRefId, idColumnName);
	}
	
	public String getStatus(String userProfileRefId, int memIndex) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);

		return getColumnValue(elgId,memRefId, statusColumnName);
	}
	
	public void validateStatus(String userProfileRefId, int memIndex, String expStatus) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);

		String actualStatus = getColumnValue(elgId, memRefId, statusColumnName);
		validateDBFieldValue(tableNameToShowOnReport, statusColumnName, expStatus, actualStatus);
	}
	
	public void updateReponseXML_reportedWages(String userProfileRefId, int memIndex, String reportedWages) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingElgId(elgId, memIndex);
		
		String xmlResponseColumnValue = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
										+ "<ns3:wageReportingMatchResponse xmlns:ns2=\"http://dor.state.ma.us/tax/types/common/v1\" xmlns:ns3=\"http://dor.state.ma.us/wagereporting/types/v1\">"
										+ "<matchRequestEmployeeInfo><employeeTaxId type=\"ssn\">244543444</employeeTaxId><employeeName><employeeLastName>PSingh</employeeLastName>"
										+ "<employeeFirstName>Pharman</employeeFirstName></employeeName></matchRequestEmployeeInfo><matchResult><wageReportingMatch><matchScheme>alpha</matchScheme>"
										+ "<reportingEmployer><employerTaxId type=\"ein\"></employerTaxId><employerName></employerName><employerAddress><employerStreetLine1></employerStreetLine1>"
										+ "<employerStreetLine2></employerStreetLine2><employerCity></employerCity><employerState>MA</employerState><employerPostalCode></employerPostalCode></employerAddress>"
										+ "</reportingEmployer><reportedEmployeeInfo><employeeTaxId type=\"ssn\">244543444</employeeTaxId><employeeName><employeeLastName>PSingh</employeeLastName><employeeFirstName>Pharman</employeeFirstName>"
										+ "</employeeName></reportedEmployeeInfo><reportingPeriod><ns2:year>2015</ns2:year><ns2:quarter>1</ns2:quarter></reportingPeriod>"
										+ "<reportedWages>"+reportedWages+"</reportedWages></wageReportingMatch></matchResult></ns3:wageReportingMatchResponse>";
		updateColumnValue(elgId, memRefId, xmlResponseColumnName, xmlResponseColumnValue);
		
	}
	
	private String getColumnValue(String elgId, String memRefId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+memRefIdColumnName+" = '"+memRefId + "'"
				+ " AND "+ eligibilityIdColumnName +"= " + elgId ;
		return getCellDataFromDB(query,columnName);
	}
	
	private void updateColumnValue(String elgId, String memRefId, String columnName, String columnValue) throws Exception{
		String query = "update " 
				 + tableName +
				 " SET " +columnName+ "='" +columnValue + "'"
				 + " WHERE "+memRefIdColumnName+" = '"+memRefId + "'"
				 + " AND "+ eligibilityIdColumnName +"= " + elgId ;
		
		executeQuery(query);
	}

}
