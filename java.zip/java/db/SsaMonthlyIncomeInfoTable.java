package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import utils.DateUtil;

public class SsaMonthlyIncomeInfoTable extends SuperTable {

	private String tableName = "MAHX_OWN.SSA_MONTHLY_INCOME_INFO";
	private String tableNameOnUI = "SSA_MONTHLY_INCOME_INFO";
	private String idColumnName = "ID";
	private String monthlyIncomeAmtColumnName = "MONTHLY_INCOME_AMT";
	
	
	public SsaMonthlyIncomeInfoTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public void ccaRenewalMonthlyIncomeAmtUpdateQuery(String userProfileRefId, int memInd, String titleIiIncome) throws Exception {		
		SsaTitleIiMonthlyIncomeTable ssaTitleIiMonthlyIncomeTable = new SsaTitleIiMonthlyIncomeTable(conn, testCaseId);
		String monthInfoId = ssaTitleIiMonthlyIncomeTable.getMonthInfoId(userProfileRefId, memInd, "CCA_RENEWAL");		
		updateIsDisabledColumn(monthInfoId, titleIiIncome);
	}
	
	public void ccaRenewalMonthlyIncomeAmtNullUpdateQuery(String userProfileRefId, int memInd) throws Exception {		
		SsaTitleIiMonthlyIncomeTable ssaTitleIiMonthlyIncomeTable = new SsaTitleIiMonthlyIncomeTable(conn, testCaseId);
		String monthInfoId = ssaTitleIiMonthlyIncomeTable.getMonthInfoId(userProfileRefId, memInd, "CCA_RENEWAL");		
		updateIncomeAmtNullColumn(monthInfoId);
	}
	
	public void updateIsDisabledColumn(String monthInfoId, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + monthlyIncomeAmtColumnName + " = '" + columnValue + "'" + 
					   " WHERE " + idColumnName + " IN (" + monthInfoId + ")";

		executeQuery(query);
	}
	
	public void updateIncomeAmtNullColumn(String monthInfoId) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + monthlyIncomeAmtColumnName + " = NULL" + 
					   " WHERE " + idColumnName + " IN (" + monthInfoId + ")";

		executeQuery(query);
	}
	
}
