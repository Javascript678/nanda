package db;

import java.sql.Connection;
import java.util.ArrayList;

public class ElgMemberTmaPeriodTable extends SuperTable {

	private String tableName = "MAHX_OWN.ELG_MEMBER_TMA_PERIOD";
	private String elgMemberIdColumnName="ELG_MEMBER_ID";
	private String endDateColumnName = "END_DATE";
	
	public ElgMemberTmaPeriodTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

    public void updateEndDateForElgMemId(String elgMemberId, String newEndDate) throws Exception{
    	updateEndDate(elgMemberId, endDateColumnName, newEndDate);
    }
	
	public String getElgMemberId(String elgMemberId) throws Exception{
		return getColumnValue(elgMemberId, endDateColumnName);
	}
	
	private void updateEndDate(String elgMemberId, String columnName, String columnValue) throws Exception{
		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "' WHERE " 
					 + elgMemberIdColumnName + " = '" + elgMemberId + "'";
		executeQuery(query);
	}
	
	private String getColumnValue(String elgMemberId, String columnName) throws Exception{
		String query = "SELECT * " 
				     + " FROM " + tableName
				     + " WHERE " + elgMemberIdColumnName + " = '" + elgMemberId + "'";
		return getCellDataFromDB(query, columnName);
	}

}
