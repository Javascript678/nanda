package db;

import java.sql.Connection;

public class DataSourceRequestLogTable extends SuperTable{
	private String tableName = "MAHX_OWN.DATA_SOURCE_REQUEST_LOG";
	private String tableNameOnUI = "DATA_SOURCE_REQUEST_LOG";
	private String memberRerfenceIdColumnName = "MEMBER_REFERENCE_ID";
	private String typeColumnName = "TYPE";
	private String statusColumnName = "STATUS";
	private String elgIdColumnName = "ELIGIBILITY_ID";
	
	public DataSourceRequestLogTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
		
	}

	public String getType(String elgId) throws Exception{
		return getColumnValue(elgId, typeColumnName);
	}
	public void validateTypeUsingRefId(String userProfileRefId, String expType) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		System.out.println("Eligibility Id is:- "+elgId);
		String actType = getType(elgId);
		validateDBFieldValue(tableNameOnUI, typeColumnName, expType, actType);
	}
	
	
	
	public String getStatus(String elgId) throws Exception{
		return getColumnValue(elgId, statusColumnName);
	}
	
	
	public void validateStatusUsingRefId(String userProfileRefId, String expStatus) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		String actStatus = getStatus(elgId);
		validateDBFieldValue(tableNameOnUI, statusColumnName, expStatus, actStatus);
	}

	
	public String getMemberRerfenceId(String elgId) throws Exception{
		return getColumnValue(elgId,memberRerfenceIdColumnName );
	}
	
	public void validateMemberRerfenceIdUsingRefId(String userProfileRefId, String expMemberRerfenceId) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);

		String actMemberRerfenceId = getMemberRerfenceId(elgId);
		validateDBFieldValue(tableNameOnUI, memberRerfenceIdColumnName, expMemberRerfenceId, actMemberRerfenceId);
	}
	
	//vimal
	public void storeCompleteDataInExcel(String elgId) throws Exception {
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgIdColumnName+" = "+elgId;
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}
	
	//vimal
	public String getSelectAllQuery(String elgId) throws Exception {
		
	String query = "SELECT * " 
			+ " FROM "+ tableName
			+ " WHERE "+elgIdColumnName+" = "+elgId;

		return query;
	}

	//vimal
	public void storeHubRequestReponseDataInExcel(String elgId) throws Exception {
		
		String query = "SELECT "+memberRerfenceIdColumnName +","+typeColumnName+","+statusColumnName+
				" FROM "+ tableName
				+ " WHERE "+elgIdColumnName+" = "+elgId;

		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}
	private String getColumnValue(String elgId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgIdColumnName+" = "+elgId;
		return getCellDataFromDB(query,columnName);
	}
	
	
}
