package db;

import java.sql.Connection;

public class LexisNexisServiceLogTable extends SuperTable{

	
	private String tableName = "MAHX_OWN.LEXISNEXIS_SERVICE_LOG";
	private String tableNameOnUI = "LEXISNEXIS_SERVICE_LOG";
	private String firstNameColumnName = "FIRST_NAME";
	private String middleNameColumnName = "MIDDLE_NAME";
	private String lastNameColumnName = "LAST_NAME";
	private String streetAddress1ColumnName =  "STREET_ADDRESS1";
	private String streetAddress2ColumnName =  "STREET_ADDRESS2";
	private String elgIdColumnName = "ELIGIBILITY_ID";
	private String addressPurposeTypeColumnName = "ADDRESS_PURPOSE_TYPE";
	private String cityColumnName ="CITY";
	private String stateCodeColumnName = "STATE_CODE";
	private String zipColumnName ="ZIP";
	private String lexisnexisStatusColumnName = "LEXIS_NEXIS_STATUS";
	private String errorDescColumnName = "ERROR_DESC";
	private String xmlRequestColumnName ="XML_REQUEST";
	private String xmlResponseColumnName ="XML_RESPONSE";
	private String lexisnexisVerifiedColumnName = "LEXIS_NEXIS_VERIFIED";
	
	public LexisNexisServiceLogTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	
	}
	
	public String getFirstName(String elgId) throws Exception{
		return getColumnValue(elgId, firstNameColumnName);
	}
	public void validateFirstNameUsingRefId(String userProfileRefId, String expFirstName) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		System.out.println("Eligibility Id is:- "+elgId);
		String actFirstName = getFirstName(elgId);
		validateDBFieldValue(tableNameOnUI, firstNameColumnName, expFirstName, actFirstName);
	}
	
	public String getMiddleName(String elgId) throws Exception{
		return getColumnValue(elgId, middleNameColumnName);
	}
	public void validateMiddleNameUsingRefId(String userProfileRefId, String expMiddleName) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
		String actMiddleName = getMiddleName(elgId);
		validateDBFieldValue(tableNameOnUI, middleNameColumnName, expMiddleName, actMiddleName);
	}
	
	
	public String getLastName(String elgId) throws Exception{
		return getColumnValue(elgId, lastNameColumnName);
	}
	public void validateLastNameUsingRefId(String userProfileRefId, String expLastName) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actLastName = getLastName(elgId);
		validateDBFieldValue(tableNameOnUI, lastNameColumnName, expLastName, actLastName);
	}
	
	public String getStreetAddress1(String elgId) throws Exception{
		return getColumnValue(elgId, streetAddress1ColumnName);
	}
	public void validateStreetAddress1UsingRefId(String userProfileRefId, String expStreetAddress1) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actStreetAddress1 = getStreetAddress1(elgId);
		validateDBFieldValue(tableNameOnUI, streetAddress1ColumnName, expStreetAddress1, actStreetAddress1);
	}
	public String getStreetAddress2(String elgId) throws Exception{
		return getColumnValue(elgId, streetAddress2ColumnName);
	}
	public void validateStreetAddress2UsingRefId(String userProfileRefId, String expStreetAddress2) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actStreetAddress2 = getStreetAddress2(elgId);
		validateDBFieldValue(tableNameOnUI, streetAddress2ColumnName, expStreetAddress2, actStreetAddress2);
	}
	
	public String getAddressPurposeType(String elgId) throws Exception{
		return getColumnValue(elgId, addressPurposeTypeColumnName);
	}
	public void validateAddressPurposeTypeUsingRefId(String userProfileRefId, String expAddressPurposeType) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actAddressPurposeType = getAddressPurposeType(elgId);
		validateDBFieldValue(tableNameOnUI, addressPurposeTypeColumnName, expAddressPurposeType, actAddressPurposeType);
	}
	
	public String getCity(String elgId) throws Exception{
		return getColumnValue(elgId, cityColumnName);
	}
	public void validateCityUsingRefId(String userProfileRefId, String expCity) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actCity = getCity(elgId);
		validateDBFieldValue(tableNameOnUI, cityColumnName, expCity, actCity);
	}
	
	public String getStateCode(String elgId) throws Exception{
		return getColumnValue(elgId, stateCodeColumnName);
	}
	public void validateStateCodeUsingRefId(String userProfileRefId, String expStateCode) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actStateCode = getStateCode(elgId);
		validateDBFieldValue(tableNameOnUI, stateCodeColumnName, expStateCode, actStateCode);
	}
	
	public String getZip(String elgId) throws Exception{
		return getColumnValue(elgId, zipColumnName);
	}
	public void validateZipUsingRefId(String userProfileRefId, String expZip) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actZip = getZip(elgId);
		validateDBFieldValue(tableNameOnUI, zipColumnName, expZip, actZip);
	}
	
	
	public String getLexisnexisStatus(String elgId) throws Exception{
		return getColumnValue(elgId, lexisnexisStatusColumnName);
	}
	public void validateLexisnexisStatusUsingRefId(String userProfileRefId, String expLexisnexisStatus) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actLexisnexisStatus = getLexisnexisStatus(elgId);
		validateDBFieldValue(tableNameOnUI, lexisnexisStatusColumnName, expLexisnexisStatus, actLexisnexisStatus);
	}
	
	
	
	public String getErrorDesc(String elgId) throws Exception{
		return getColumnValue(elgId, errorDescColumnName);
	}
	public void validateErrorDescUsingRefId(String userProfileRefId, String expErrorDesc) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actErrorDesc = getErrorDesc(elgId);
		validateDBFieldValue(tableNameOnUI, errorDescColumnName, expErrorDesc, actErrorDesc);
	}
	
	public String getXmlRequest(String elgId) throws Exception{
		return getColumnValue(elgId, xmlRequestColumnName);
	}
	public void validateXmlRequestUsingRefId(String userProfileRefId, String expXmlRequest) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actXmlRequest = getXmlRequest(elgId);
		validateDBFieldValue(tableNameOnUI, xmlRequestColumnName, expXmlRequest, actXmlRequest);
	}
	
	public String getXMLResponse(String elgId) throws Exception{
		return getColumnValue(elgId, xmlResponseColumnName);
	}
	public void validateXMLResponseUsingRefId(String userProfileRefId, String expXmlResponse) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actXmlResponse = getXMLResponse(elgId);
		validateDBFieldValue(tableNameOnUI, xmlResponseColumnName, expXmlResponse, actXmlResponse);
	}
	
	
	public String getLexisnexisVerified(String elgId) throws Exception{
		return getColumnValue(elgId, lexisnexisVerifiedColumnName);
	}
	public void validateLexisnexisVerifiedUsingRefId(String userProfileRefId, String expLexisnexisVerified) throws Exception{
		EligibilityTable EligibilityTable1 = new EligibilityTable(conn, testCaseId);
		String elgId =EligibilityTable1.getIdUsingUserProfileRefId(userProfileRefId);
	
		String actLexisnexisVerified = getLexisnexisVerified(elgId);
		validateDBFieldValue(tableNameOnUI, lexisnexisVerifiedColumnName, expLexisnexisVerified, actLexisnexisVerified);
	}
	
	public void storeCompleteDataInExcel(String elgId) throws Exception {
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgIdColumnName+" = "+elgId;
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}
	
	public void storeHubRequestReponseDataInExcel(String elgId) throws Exception {
		
		String query = "SELECT "+firstNameColumnName+","+middleNameColumnName+","+lastNameColumnName+","+streetAddress1ColumnName+","+streetAddress2ColumnName+","+elgIdColumnName+
				addressPurposeTypeColumnName+","+cityColumnName+","+stateCodeColumnName+","+zipColumnName+","+lexisnexisStatusColumnName+","+errorDescColumnName+","+xmlRequestColumnName+","+xmlResponseColumnName+","+lexisnexisVerifiedColumnName+" FROM "+ tableName
				+ " WHERE "+elgIdColumnName+" = "+elgId;
				
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}
	
	
public String getSelectAllQuery(String elgId) throws Exception {
		
	String query = "SELECT * " 
			+ " FROM "+ tableName
			+ " WHERE "+elgIdColumnName+" = "+elgId;
				
		return query;
	}

	private String getColumnValue(String elgId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgIdColumnName+" = "+elgId;
		return getCellDataFromDB(query,columnName);
	}
	

}
