package db;

import java.sql.Connection;

public class DORreferralUnitTable extends SuperTable {

	private String tableName = "MAHX_OWN.DOR_REFERRAL_UNIT";
	private String tableNameToShowOnUI = "DOR_REFERRAL_UNIT";
	private String idColumnName = "ID";
	private String statusColumnName = "STATUS";
	private String childMemRefIdColumnName = "CHILD_MEMBER_REF_ID";
	
	public DORreferralUnitTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}	
	
	private String getColumnValue(String elgMemId, String columnName) throws Exception{
		String query = "SELECT * " 
				     + " FROM " + tableName
				     + " WHERE " + childMemRefIdColumnName + " = " + elgMemId;
		return getCellDataFromDB(query, columnName);
	}
	
	public String getId(String elgMemId, String fName, String lName) throws Exception{
		return getColumnValue(elgMemId, idColumnName);
	}
	
	private String getStatus(String elgId, String fName, String lName) throws Exception{
		String elgMemId = new ElgMemberTable(conn, testCaseId).getMemberReferenceId(elgId, fName, lName);
		return getColumnValue(elgMemId, statusColumnName);
	}
		
	public void validateStatus(String elgId, String fName, String lName, String expStatus) throws Exception{
		String actualStatus = getStatus(elgId, fName, lName);
		validateDBFieldValue(tableNameToShowOnUI, "STATUS", expStatus, actualStatus);
	}

}
