package db;

import java.sql.Connection;

public class BatchEnrollmentXmlControlTable extends SuperTable {

	private String tableName = "MAHX_OWN.BATCH_ENROLLMENT_XML_CONTROL";
	private String idColumnName = "ID";
	private String actionColumnName = "ACTION";
	private String statusReasonDellXmlColumnName = "STATUS_REASON_DELL_XML";
	private String currentStatusColumnName = "CURRENT_STATUS";
	private String statusReasonColumnName = "STATUS_REASON";
	private String enrollmentIdColumnName = "ENROLLMENT_ID";
	private String oldEnrollmentIdColumnName = "OLD_ENROLLMENT_ID";

	
	public BatchEnrollmentXmlControlTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, idColumnName);
	}
	
	public String getId(String enrollmentId, String action) throws Exception{
		return getColumnValue(enrollmentId, action, idColumnName);
	}
	
	public String getAction(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, actionColumnName);
	}
	
	public String getStatusReasonDellXML(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, statusReasonDellXmlColumnName);
	}
	
	public String getCurrentStatus(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, currentStatusColumnName);
	}
	
	public String getStatusReason(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, statusReasonColumnName);
	}
	
	public String getEnrollmentId(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		
		return getColumnValue(elgId, fName, lName, coverageType, action, enrollmentIdColumnName);
	}
	
	public String getOldEnrollmentId(String elgId, String fName, String lName, String coverageType, String action) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, action, oldEnrollmentIdColumnName);
	}
	
	public String getColumnValueforID(String userProfileId, String action,int rowIndex) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE USER_PROFILE_ID = "+userProfileId
				+ " AND ACTION = '" + action + "'";
		return getCellDataFromDB(query, rowIndex, idColumnName);
	}
	
	private String getColumnValue(String elgId, String fName, String lName, String coverageType, String action, String columnName) throws Exception{
		String enrollmentId = new EnrollmentTable(conn,testCaseId).getId(elgId, fName, lName, coverageType);
		return getColumnValue(enrollmentId,action, columnName);
	}
	
	private String getColumnValue(String enrollmentId, String action, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE ENROLLMENT_ID = "+enrollmentId
				+ " AND ACTION = '" + action + "'";
		return getCellDataFromDB(query,columnName);
	}
}
