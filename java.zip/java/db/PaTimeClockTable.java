package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;


/**
 * 
 * @author Ritu
 *
 */
public class PaTimeClockTable extends SuperTable 
{
	private String tableName = "MAHX_OWN.PA_TIMECLOCK";
	private String idColumnName = "ID";
	private String memberReferenceIdColumnName = "MEMBER_REFERENCE_ID";
	private String startDateColumnName="START_TIME";
	private String createdDateColumnName="CREATED_DATE";
    private String expirationDateColumnName="EXPIRATION_DATE";
	
	public PaTimeClockTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	public ArrayList<String> getIdsUsingEligibilityId(String elgId, int memIndex) throws Exception{
		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memberReferenceId = elgMemberTable.getMemberReferenceIdUsingElgId(elgId ,memIndex);
		return getColumnValueUsingMemberReferenceId(memberReferenceId, idColumnName);
	}
	
	public void updateStartCreatedExpirationDate(String elgId,int memIndex,String startDateValue,String createdDateValue,String expirationDateValue) throws Exception{
		 ArrayList<String> ids= getIdsUsingEligibilityId( elgId,memIndex); 
		 for (String id : ids) 
		 {
			 List<String> columnNames = new ArrayList<String>();
			 List<String> columnValues = new ArrayList<String>();
			 columnNames.add(startDateColumnName);
			 columnNames.add(createdDateColumnName);
			 columnNames.add(expirationDateColumnName);
			 columnValues.add(startDateValue);
			 columnValues.add(createdDateValue);
			 columnValues.add(expirationDateValue);
				
			 updateVarCharColumnValues(id, columnNames, columnValues);
		 }	
	}
	
	 public void updateStartCreatedExpirationDateUsingUserProfileRefId(String userProfileRefId,int memIndex,String startDateValue,String createdDateValue,String expirationDateValue) throws Exception{
		 EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		 String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		 
		 updateStartCreatedExpirationDate(elgId, memIndex, startDateValue, createdDateValue, expirationDateValue);
	}
	
	private ArrayList<String> getColumnValueUsingMemberReferenceId( String memberReferenceId, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+memberReferenceIdColumnName+" = '"+memberReferenceId +"' ORDER BY ID";
				
		return getColumnDataFromDB(query,columnName);
	}
	
	private void updateVarCharColumnValues(String id, List<String> columnNames, List<String> columnValues) throws Exception{
		String query = "UPDATE " 
				+ tableName + " SET ";
		for(int columnCounter=0; columnCounter < columnNames.size(); columnCounter++){
			if(columnCounter==( columnNames.size() - 1 )){
				query = query + columnNames.get(columnCounter) + " = '" + columnValues.get(columnCounter)  + "'";
			}else {
				query = query + columnNames.get(columnCounter) + " = '" + columnValues.get(columnCounter)  + "' ,";
			}
			
		}
		query = query + " WHERE "+ idColumnName +" = "+id;
		
		executeQuery(query);
	}
	
}
