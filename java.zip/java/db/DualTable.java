package db;

import java.sql.Connection;

public class DualTable extends SuperTable {

	private String tableName = "DUAL";
	private String sysDateColumnName = "SYSDATE";
	
	public DualTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getSysDate() throws Exception{
		
		String query = "SELECT SYSDATE "
				+ "FROM "+tableName;
		return getCellDataFromDB(query,sysDateColumnName);
	}
	
	public void validateSysDate(String expSysDate) throws Exception{
		
		String query = "SELECT SYSDATE "
				+ "FROM "+tableName;
		String actualSysDate=  getCellDataFromDB(query,sysDateColumnName);
		validateDBFieldValue(tableName, sysDateColumnName, expSysDate, actualSysDate);
	}

}
