package db;

import java.sql.Connection;

public class ShoppingGroupTable extends SuperTable {

	private String tableName = "MAHX_OWN.SHOPPING_GROUP";
	private String idColumnName = "ID";
	private String subscriberMemIdColumnName = "SUBSCRIBER_MEMBER_ID";
	private String coverageTypeColumnName = "COVERAGE_TYPE";
	
	public ShoppingGroupTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String subscriberMemId, String coverageType) throws Exception{
		
		return getColumnValue(subscriberMemId, coverageType, idColumnName);
	}

	public String getId(String elgId, String fName, String lName, String coverageType) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, idColumnName);
	}
	
	private String getColumnValue(String elgId, String fName, String lName, String coverageType, String columnName) throws Exception{
		String elgMemId = new ElgMemberTable(conn,testCaseId).getId(elgId, fName, lName);
		return getColumnValue(elgMemId, coverageType, columnName);
	}
	
	private String getColumnValue(String subscriberElgMemId, String coverageType, String columnName) throws Exception{
		
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+subscriberMemIdColumnName+" = "+subscriberElgMemId
				+ " AND "+coverageTypeColumnName+" = '" + coverageType + "'";
		return getCellDataFromDB(query,columnName);
	}
		
	
}
