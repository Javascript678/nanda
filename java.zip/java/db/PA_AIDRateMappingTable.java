package db;

import java.sql.Connection;

/**
 * 
 * @author Ritu
 *
 */
public class PA_AIDRateMappingTable extends SuperTable {
	private String tableName = "MAHX_OWN.PA_AID_RATE_MAPPING";
	//private String idColumnName = "ID";
	private String paAidCatColumnName = "PA_AID_CAT";
	private String nonPaAidCatColumnName = "NON_PA_AID_CAT";


	public PA_AIDRateMappingTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	
	public void updatePAAidCat( String nonPAAidCatValue, String paAidCatValue) throws Exception {
		
		updateVarCharColumnValue(nonPAAidCatValue, paAidCatValue);
	}

	
	private void updateVarCharColumnValue( String nonPAAidCatValue, String paAidCatValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + paAidCatColumnName + " = '" + paAidCatValue+ "'" + " WHERE "
				+ nonPaAidCatColumnName + " = '" + nonPAAidCatValue +"'";

		executeQuery(query);

	}
	
	//update mahx_own.PA_AID_RATE_MAPPING set PA_AID_CAT ='D42'  where Non_PA_AID_CAT ='D1';

	//update mahx_own.PA_AID_RATE_MAPPING set PA_AID_CAT ='D4'  where Non_PA_AID_CAT ='D1';
	
	

}
