package db;

import java.sql.Connection;
import java.util.ArrayList;

public class EnrollmentTable extends SuperTable {

	private String tableName = "MAHX_OWN.ENROLLMENT";
	private String idColumnName = "ID";
	private String shoppingGrpIdColumnName = "SHOPPING_GROUP_ID";
	private String statusColumnName = "STATUS";
	private String eligIdColumnName = "ELIGIBILITY_ID"; 
	public EnrollmentTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String elgId, String fName, String lName, String coverageType) throws Exception{
		return getColumnValue(elgId, fName, lName, coverageType, idColumnName);
	}
	
	public String getId(String shopping_group_id) throws Exception{
		return getColumnValue(shopping_group_id, idColumnName);
	}
	
	public String getColumnValue(String elgId, String fName, String lName, String coverageType, String columnName) throws Exception{
		String shoppingGrpId = new ShoppingGroupTable(conn,testCaseId).getId(elgId, fName, lName, coverageType);
		return getColumnValue(shoppingGrpId,columnName);
	}
	
	private String getColumnValue(String shopping_group_id, String columnName) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+shoppingGrpIdColumnName+" = "+shopping_group_id;
		return getCellDataFromDB(query,columnName);
	}
	
	// new function for plan effectuation
	public void updateStatus(String userProfileRefId, String newStatusValue) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		updateVarCharColumnValue(elgId, statusColumnName, newStatusValue);
	}
	
	public void updateStatusPDM(String userProfileElgId, String newStatusValue) throws Exception {
		updateVarCharColumnValuePDM(userProfileElgId, statusColumnName, newStatusValue);
	}
	
	private void updateVarCharColumnValue(String elgId, String columnName, String columnValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "'" + " WHERE "
				+ eligIdColumnName + " = " + elgId;

		executeQuery(query);

	}
	
	private void updateVarCharColumnValuePDM(String elgId, String columnName, String columnValue) throws Exception {

		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "'" + " WHERE "
		+ eligIdColumnName + " = " + elgId+"' AND " + columnName +" = 'TRANSITIONAL'";;

		executeQuery(query);
	}

	public ArrayList<String>getIDsUsingUserProfileRefId(String userProfileRefId ,String newStatusValue ) throws Exception
	{
	EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
	String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);	
	return getColumnValueUsingUserProfileRefId(elgId ,newStatusValue,idColumnName);
	
	}

private ArrayList<String> getColumnValueUsingUserProfileRefId( String elgId,String newStatusValue ,String idColumnName) throws Exception{
	String query = "SELECT * " 
			+ " FROM "+ tableName
			+ " WHERE "+eligIdColumnName+" = '"+elgId +"' AND " +statusColumnName +" = '"+ newStatusValue+"'";
			
	return getColumnDataFromDB(query,idColumnName);
}
	
	
}
