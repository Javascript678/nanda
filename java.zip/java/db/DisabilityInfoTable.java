package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import appdata.evpd.EVPD_Data;
import utils.DateUtil;

public class DisabilityInfoTable extends SuperTable {
	
	private String tableName = "MAHX_OWN.DISABILITY_INFO";
	private String tableNameOnUI = "DISABILITY_INFO";
	private String idColumnName = "ID";
	private String mmisIdColumnName = "MMIS_ID";
	private String dobColumnName = "DOB";
	private String genderColumnName = "GENDER";
	private String isDisableColumnName = "IS_DISABLED";
	private String disablityTypeColumnName = "DISABILITY_TYPE";
	private String disablitySourceColumnName = "DISABILITY_SOURCE";
	private String medicareCVGStartDateColumnName = "MEDICARE_CVG_START_DATE";
	private String medicareCVGEndDateColumnName = "MEDICARE_CVG_END_DATE";
	private String disabilityEffStartDateColumnName = "DISABILITY_EFF_START_DATE";
	private String disabilityEffEndDateColumnName = "DISABILITY_EFF_END_DATE";
	private String desDeterminationDateColumnName = "DES_DETERMINATION_DATE";
	private String isWaivedColumnName = "IS_WAIVED";
	private String disabilityRenewalDateColumnName = "DISABILITY_RENEWAL_DATE";
	private String createdByColumnName = "CREATED_BY";
	private String createdDateColumnName = "CREATED_DATE";
	private String updatedByColumnName = "UPDATED_BY";
	private String updatedDateColumnName = "UPDATED_DATE";
	private String lastNameColumnName = "LAST_NAME";
	private String firstNameColumnName = "FIRST_NAME";
	private String middleInitialColumnName = "MIDDLE_INITIAL";
	private String personIdColumnName = "PERSON_ID";
	private String SSNColumnName = "SSN";
	private String mmisMemberReferenceIdColumnName = "MMIS_MEMBER_REFERENCE_ID";
	private String encryptedSSNColumnName = "ENCRYPTED_SSN";

	public DisabilityInfoTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public void addRowInDisablityTable(String userProfileRefId, int memIndex, String mmisIdColumnValue,
			String genderColumnvalue, String isDisableColumnValue, String disablityTypeColumnValue,
			String disablitySourceColumnValue, String medicareCVGStartDateColumnValue,
			String medicareCVGEndDateColumnValue, String disabilityEffStartDateColumnValue,
			String disabilityEffEndDateColumnValue, String desDeterminationDateColumnValue, String isWaivedColumnValue,
			String disabilityRenewalDateColumnValue, String createdDateColumnValue, String updatedByColumnValue,
			String updatedDateColumnValue, String personIdColumnValue, String SSNColumnValue) throws Exception {

		String idColumnValue = getIdMaximumValue();
		SSNCardTable ssnCard = new SSNCardTable(conn, testCaseId);
		String encryptedSSNColumnValue = ssnCard.getEncryptedSSNUsingUserProfileRefId(userProfileRefId, memIndex);
		String createdByColumnValue = ssnCard.getCreatedByUser(userProfileRefId, memIndex);
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);
		ElgMemberTable elgmember = new ElgMemberTable(conn, testCaseId);
		String fnameColumnValue = elgmember.getFirstNameUsingUserProfileRefId(userProfileRefId, memIndex);
		String lnameColumnValue = elgmember.getLastNameUsingUserProfileRefId(userProfileRefId, memIndex);
		String dobColumnValue1 = elgmember.getDOB(elgId, memIndex);
		String dobColumnValue2 = dobColumnValue1.substring(0, 10);
		String dobColumnValue = DateUtil.getPriorDateInDBUpdateFormatUsingPattern(dobColumnValue2, DateUtil.dbDatePattern, "00:00:00");
		String middleNameColumnValue = elgmember.getMiddleName(elgId, memIndex);
		MMIS_Post_Elg_Control_Data_Table mmisPostElgData = new MMIS_Post_Elg_Control_Data_Table(conn, testCaseId);
		String mmisMemberRefIdColumnValue = mmisPostElgData.getAgencyMemberId(elgId, memIndex);

		List<String> columnNames = new ArrayList<String>();
		List<String> columnValues = new ArrayList<String>();
		columnNames.add(idColumnName);
		columnNames.add(mmisIdColumnName);
		columnNames.add(dobColumnName);
		columnNames.add(genderColumnName);
		columnNames.add(isDisableColumnName);
		columnNames.add(disablityTypeColumnName);
		columnNames.add(disablitySourceColumnName);
		columnNames.add(medicareCVGStartDateColumnName);
		columnNames.add(medicareCVGEndDateColumnName);
		columnNames.add(disabilityEffStartDateColumnName);
		columnNames.add(disabilityEffEndDateColumnName);
		columnNames.add(desDeterminationDateColumnName);
		columnNames.add(isWaivedColumnName);
		columnNames.add(disabilityRenewalDateColumnName);
		columnNames.add(createdByColumnName);
		columnNames.add(createdDateColumnName);
		columnNames.add(updatedByColumnName);
		columnNames.add(updatedDateColumnName);
		columnNames.add(lastNameColumnName);
		columnNames.add(firstNameColumnName);
		columnNames.add(middleInitialColumnName);
		columnNames.add(personIdColumnName);
		columnNames.add(SSNColumnName);
		columnNames.add(mmisMemberReferenceIdColumnName);
		columnNames.add(encryptedSSNColumnName);

		// add values
		columnValues.add(idColumnValue);
		columnValues.add(mmisIdColumnValue);
		columnValues.add(dobColumnValue);
		columnValues.add(genderColumnvalue);
		columnValues.add(isDisableColumnValue);
		columnValues.add(disablityTypeColumnValue);
		columnValues.add(disablitySourceColumnValue);
		columnValues.add(medicareCVGStartDateColumnValue);
		columnValues.add(medicareCVGEndDateColumnValue);
		columnValues.add(disabilityEffStartDateColumnValue);
		columnValues.add(disabilityEffEndDateColumnValue);
		columnValues.add(desDeterminationDateColumnValue);
		columnValues.add(isWaivedColumnValue);
		columnValues.add(disabilityRenewalDateColumnValue);
		columnValues.add(createdByColumnValue);
		columnValues.add(createdDateColumnValue);
		columnValues.add(updatedByColumnValue);
		columnValues.add(updatedDateColumnValue);
		columnValues.add(lnameColumnValue);
		columnValues.add(fnameColumnValue);
		columnValues.add(middleNameColumnValue);
		columnValues.add(personIdColumnValue);
		columnValues.add(SSNColumnValue);
		columnValues.add(mmisMemberRefIdColumnValue);
		columnValues.add(encryptedSSNColumnValue);
		InsertVarCharColumnsValues(columnNames, columnValues);

	}

	public String getIdMaximumValue() throws Exception {
		String idvalue = getColumnValue(idColumnName);
		int id = Integer.parseInt(idvalue);
		id = id + 1;
		idvalue = Integer.toString(id);
		return idvalue;
	}
	// select max (id)from mahx_own.disability_info

	// select * from(select id from mahx_own.disability_info order by id Desc)
	// where rownum=1
	private String getColumnValue(String idColumnName) throws Exception {
		String query = "SELECT * From (Select * from " + tableName + " order by id Desc ) where rownum=1";

		return getCellDataFromDB(query, idColumnName);

	}

	private void InsertVarCharColumnsValues(List<String> columnNames, List<String> columnValues) throws Exception {
		String query = "INSERT INTO " + tableName + "(";
		for (int columnCounter = 0; columnCounter < columnNames.size(); columnCounter++) {
			if (columnCounter == (columnNames.size() - 1)) {
				query = query + columnNames.get(columnCounter) + ")Values(";
			} else {
				query = query + columnNames.get(columnCounter) + " , ";
			}

		}

		for (int columnCounter = 0; columnCounter < columnValues.size(); columnCounter++) {

			if (columnCounter == (columnNames.size() - 1)) {
				if ((columnValues.get(columnCounter)).equalsIgnoreCase("NULL")) {
					query = query + " " + columnValues.get(columnCounter) + " )";
				} else {
					query = query + "'" + columnValues.get(columnCounter) + "')";
				}
			} else {
				System.out.println(columnValues.get(columnCounter));

				if ((columnValues.get(columnCounter) == null)
						|| (columnValues.get(columnCounter)).equalsIgnoreCase("NULL")) {
					query = query + " " + columnValues.get(columnCounter) + " ,";
				} else {
					query = query + "'" + columnValues.get(columnCounter) + "' ,";
				}

			}
		}

		executeQuery(query);
	}
	
	public void ccaRenewalDisabilityUpdateQuery(String userProfileRefId, int memInd, String isDisabled) throws Exception {
		DisabilityInfoHistoryTable disabilityInfoHistoryTable = new DisabilityInfoHistoryTable(conn, testCaseId);
		String mmisMemberReferenceId = disabilityInfoHistoryTable.getMmisMemberReferenceId(userProfileRefId, memInd, "CCA_RENEWAL");		
		updateIsDisabledColumn(mmisMemberReferenceId, isDisabled);
	}

	// vimal
	public String getSelectAllQuery(String elgId) throws Exception {
		LexisNexisServiceLogTable lexisNexisServiceLogTable = new LexisNexisServiceLogTable(conn, testCaseId);
		String lName = lexisNexisServiceLogTable.getFirstName(elgId);
		String fName = lexisNexisServiceLogTable.getLastName(elgId);
		String query = "SELECT * FROM " + tableName + 
					   " WHERE " + lastNameColumnName + "=" + lName + 
					   " AND " + firstNameColumnName + "=" + fName + "";
		return query;
	}

	// vimal
	public void storeCompleteDataInExcel(String elgId) throws Exception {
		LexisNexisServiceLogTable lexisNexisServiceLogTable = new LexisNexisServiceLogTable(conn, testCaseId);
		String lName = lexisNexisServiceLogTable.getFirstName(elgId);
		String fName = lexisNexisServiceLogTable.getLastName(elgId);
		String query = "SELECT * FROM " + tableName + 
					   " WHERE " + lastNameColumnName + "=" + lName + 
					   " AND " + firstNameColumnName + "=" + fName + "";
		
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}

	// vimal
	public void storeHubRequestReponseDataInExcel(String elgId) throws Exception {
		LexisNexisServiceLogTable lexisNexisServiceLogTable = new LexisNexisServiceLogTable(conn, testCaseId);
		String lName = lexisNexisServiceLogTable.getFirstName(elgId);
		String fName = lexisNexisServiceLogTable.getLastName(elgId);
		String query = "SELECT" + dobColumnName + "," + disablityTypeColumnName + "," + disablitySourceColumnName + ","
							+ disabilityEffStartDateColumnName + "," + disabilityEffEndDateColumnName + ","
							+ desDeterminationDateColumnName + "," + firstNameColumnName + "," + lastNameColumnName + ","
							+ SSNColumnName + " FROM " + tableName + 
					   " WHERE " + lastNameColumnName + "=" + lName + 
					   " AND " + firstNameColumnName + "=" + fName + "";
		
		storeDBTableIntoExcel(query, tableNameOnUI + "-" + elgId);
	}
	
	public void updateIsDisabledColumn(String mmisMemberReferenceId, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + isDisableColumnName + " = '" + columnValue + "'" + 
					   " WHERE " + mmisMemberReferenceIdColumnName + " IN (" + mmisMemberReferenceId + ")";

		executeQuery(query);
	}

}
