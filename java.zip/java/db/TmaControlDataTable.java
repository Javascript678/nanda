package db;

import java.sql.Connection;
import java.util.ArrayList;

public class TmaControlDataTable extends SuperTable {

	private String tableName = "MAHX_OWN.TMA_CONTROL_DATA";
	private String elgIdColumnName="ELIGIBILITY_ID";
	private String elgMemberIdColumnName="ELG_MEMBER_ID";
	private String tmaPeriodEndDateColumnName = "TMA_PERIOD_END_DATE";
	private String tmaPeriodStartDateColumnName = "TMA_PERIOD_EFFECTIVE_DATE";
	
	public TmaControlDataTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public ArrayList<String> getElgMemberId(String elgId) throws Exception{
		return getElgMemberIds(elgId, elgMemberIdColumnName);
	}
	
	public String getTmaPeriodEffectiveDate(String elgId) throws Exception{
		return getColumnValue(elgId, tmaPeriodStartDateColumnName);
	}

    public void updateEndDateForElgMemId(String eligibilityId, String newEndDate) throws Exception{
    	updateEndDate(eligibilityId, tmaPeriodEndDateColumnName, newEndDate);
    }
	
	private void updateEndDate(String elgMemberId, String columnName, String columnValue) throws Exception{
		String query = "UPDATE " + tableName + " SET " + columnName + " = '" + columnValue + "' WHERE "
					 + elgMemberIdColumnName + " = '" + elgMemberId + "'";

		executeQuery(query);
	}
	
	private ArrayList<String> getElgMemberIds(String elgId, String columnName) throws Exception{
		String query = "SELECT * " 
				     + " FROM " + tableName
				     + " WHERE " + elgIdColumnName + " = '" + elgId + "'";
		return getColumnDataFromDB(query, columnName);
	}
	
	private String getColumnValue(String elgMemberId, String columnName) throws Exception{
		String query = "SELECT * " 
				     + " FROM " + tableName
				     + " WHERE " + elgIdColumnName + " = '" + elgMemberId + "'";
		return getCellDataFromDB(query, columnName);
	}

}
