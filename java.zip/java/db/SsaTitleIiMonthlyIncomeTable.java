package db;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import utils.DateUtil;

public class SsaTitleIiMonthlyIncomeTable extends SuperTable {

	private String tableName = "MAHX_OWN.SSA_TITLE_II_MONTHLY_INCOME";
	private String tableNameOnUI = "SSA_TITLE_II_MONTHLY_INCOME";
	private String monthInfoIdColumnName = "MONTH_INFO_ID";
	private String maHubReqResIdColumnName = "MA_HUB_REQ_RES_ID";
	
	
	public SsaTitleIiMonthlyIncomeTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public String getMonthInfoId(String userProfileRefId, int memIndex, String init) throws Exception {
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memIndex);
		
		MaHubRequestResponseTable mahubRequestResponseTable = new MaHubRequestResponseTable(conn, testCaseId);
		String id = mahubRequestResponseTable.getId(elgId, memRefId, init);

		return getMaHubReqResIdColumnValue(id);
	}
	
	private String getMaHubReqResIdColumnValue(String id) throws Exception {
		String query = "SELECT * " +
					    " FROM " + tableName +
					    " WHERE " + maHubReqResIdColumnName + " IN (" + id + ")";

		return getCellDataFromDB(query, monthInfoIdColumnName);
	}
	
}
