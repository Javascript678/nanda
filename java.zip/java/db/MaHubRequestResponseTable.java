package db;

import java.sql.Connection;

public class MaHubRequestResponseTable extends SuperTable {

	private static final String tableNameToShowOnUI = "MA_HUB_REQUEST_RESPONSE";
	private String tableName = "MAHX_OWN.MA_HUB_REQUEST_RESPONSE";
	private String idColumnName = "ID";
	private String elgIdColumnName = "ELIGIBILITY_ID";
	private String memberReferenceIdColumnName = "MEMBER_REFERENCE_ID";
	private String requestInitSourceColumnName = "REQUEST_INIT_SOURCE";
	private String livingIndicatorColumnName = "LIVING_INDICATOR";
	private String ssaResponseCodeColumnName = "SSA_RESPONSE_CODE";

	public MaHubRequestResponseTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	public String getId(String elgId, String memRefId, String init) throws Exception {
		return getIdColumnValue(elgId, memRefId, init);
	}
	
	public void ccaRenewalDeceasedUpdateQuery(String userProfileRefId, int memInd, String isDeceased) throws Exception {	
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memInd);
		
		updateIsDisabledColumn(elgId, memRefId, "CCA_RENEWAL", isDeceased);
	}
	
	public void ccaRenewalSsaErrorUpdateQuery(String userProfileRefId, int memInd, String errorCode) throws Exception {	
		EligibilityTable eligibilityTable = new EligibilityTable(conn, testCaseId);
		String elgId = eligibilityTable.getIdUsingUserProfileRefId(userProfileRefId);

		ElgMemberTable elgMemberTable = new ElgMemberTable(conn, testCaseId);
		String memRefId = elgMemberTable.getMemberReferenceIdUsingMemIndex(elgId, memInd);
		
		updateSsaResponseCodeColumn(elgId, memRefId, "CCA_RENEWAL", errorCode);
	}
	
	private String getIdColumnValue(String elgId, String memRefId, String init) throws Exception {
		String query = "SELECT * " +
					    " FROM " + tableName +
					    " WHERE " + elgIdColumnName + " = " + elgId +
					    " AND " + requestInitSourceColumnName + " = '" + init + "'" +  
					    " AND " + memberReferenceIdColumnName + " = '" + memRefId + "'";

		return getCellDataFromDB(query, idColumnName);
	}
	
	public void updateIsDisabledColumn(String elgId, String memRefId, String init, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + livingIndicatorColumnName + " = '" + columnValue + "'" + 
					   " WHERE " + elgIdColumnName + " = " + elgId +
					   " AND " + requestInitSourceColumnName + " = '" + init + "'" +  
					   " AND " + memberReferenceIdColumnName + " = '" + memRefId + "'";

		executeQuery(query);
	}
	
	public void updateSsaResponseCodeColumn(String elgId, String memRefId, String init, String columnValue) throws Exception {
		String query = "UPDATE " + tableName + 
					   " SET " + livingIndicatorColumnName + " = 'F', " + 
					   			 ssaResponseCodeColumnName + " = '" + columnValue + "'" +
					   " WHERE " + elgIdColumnName + " = " + elgId +
					   " AND " + requestInitSourceColumnName + " = '" + init + "'" +  
					   " AND " + memberReferenceIdColumnName + " = '" + memRefId + "'";

		executeQuery(query);
	}
	
}