package db;

import java.sql.Connection;

public class ExclusionTrackerTable extends SuperTable {

	private String tableName = "MAHX_OWN.EXCLUSION_TRACKER";
	private String tableNameToShowOnUI = "MAHX_OWN.EXCLUSION_TRACKER";
	private String elgIdColumnName = "ELGIBILITY_ID";
	
	public ExclusionTrackerTable(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}

	public void validateRowCountForElgId(String elgId, int expCount) throws Exception{
		int actualCount = getRowCountUsingElgId(elgId);
		validateDBFieldValue(tableNameToShowOnUI, elgId+"_"+"RowCount", expCount+"", actualCount+"");
	}
	
	private int getRowCountUsingElgId(String elgId) throws Exception{
		String query = "SELECT * " 
				+ " FROM "+ tableName
				+ " WHERE "+elgIdColumnName+" = "+elgId;
		return getRowCount(query);
	}
}
