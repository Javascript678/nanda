package notices;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class PDFDataCheck {
	static String testCaseId;

	// PDF path variable
	static String actualFile;
	static String sampleFile;

	public PDFDataCheck(String testCaseId, String sampleFile, String actualFile) {
		PDFDataCheck.testCaseId = testCaseId;
		PDFDataCheck.sampleFile = sampleFile;
		PDFDataCheck.actualFile = actualFile;
	}

	// New Code-----------
	public static int removeContent(List<String> oriList, List<String> samList) throws Exception {
		File oriFile = new File(actualFile);
		PDDocument oriPdf = PDDocument.load(oriFile);

		File samFile = new File(sampleFile);
		PDDocument samPdf = PDDocument.load(samFile);

		PDFTextStripper stripper = new PDFTextStripper();

		String oriText = stripper.getText(oriPdf);
		String samText = stripper.getText(samPdf);

		int wordCount = 0;

		List<String> sam = new ArrayList<String>();
		List<String> ori = new ArrayList<String>();

		List<String> updatedSam = new ArrayList<String>();
		List<String> updatedOri = new ArrayList<String>();

		Scanner sc = new Scanner(samText);
		while (sc.hasNextLine()) {
			String temp = sc.nextLine();
			if (!temp.equals(" "))
				sam.add(temp.trim());
		}
		System.out.println(sam.size());

		Scanner sc1 = new Scanner(oriText);
		while (sc1.hasNextLine()) {
			String temp = sc1.nextLine();
			if (!temp.equals(" "))
				ori.add(temp.trim());
		}
		System.out.println("OriSize=" + ori.size());

		Iterator<String> it = samList.iterator();
		Iterator<String> it1 = oriList.iterator();

		int i = 0;
		String currOriList = it1.next();

		String currSamList = it.next();
		Iterator<String> it2 = sam.iterator();
		Iterator<String> it3 = ori.iterator();

		Scanner oriScanner = new Scanner(currOriList);
		String currOriWord = oriScanner.next();

		// Sam List
		while (it2.hasNext()) {
			StringBuilder sbs = new StringBuilder();
			StringBuilder sbo = new StringBuilder();

			String currLineS = it2.next();
			String currLineO = it3.next();

			Scanner sc3 = new Scanner(currLineS);
			Scanner sc4 = new Scanner(currLineO);

			System.out.println(currLineS);
			if (currLineS.contains("[" + currSamList + "]")) {
				while (sc3.hasNext()) {
					String tempSam = sc3.next();
					System.out.println(tempSam);
					if (!tempSam.contains("[" + currSamList + "]")) {
						System.out.println("contains [" + currSamList + "]");
						sbs.append(tempSam + " ");
					} else {
						if (it.hasNext())
							currSamList = it.next();
					}
				}
				while (sc4.hasNext()) {
					String tempOri = sc4.next();
					if (!tempOri.contains(currOriWord)) {
						System.out.println("CurrORIWord--------------->>>" + currOriWord);
						sbo.append(tempOri + " ");
					} else {
						if (oriScanner.hasNext()) {
							currOriWord = oriScanner.next();
							System.out.println("CurrORIWord--------------->>>" + currOriWord);
						}

						else {
							if (it1.hasNext())
								currOriList = it1.next();
							oriScanner = new Scanner(currOriList);
							currOriWord = oriScanner.next();
							System.out.println("CurrORIWord--------------->>>" + currOriWord);
						}

					}
				}

			} else {
				while (sc3.hasNext()) {
					sbs.append(sc3.next() + " ");
				}
				while (sc4.hasNext()) {
					sbo.append(sc4.next() + " ");
				}

			}

			updatedOri.add(sbo.toString());
			updatedSam.add(sbs.toString());

		}

		// -----------------------
		it = updatedSam.iterator();

		System.out.println("UDATEDDDDD SAM----------->>>>.>");
		while (it.hasNext()) {
			System.out.println(it.next());

		}

		// ------------------------
		it = updatedOri.iterator();

		System.out.println("UDATEDDDDD ORI----------->>>>.>");
		while (it.hasNext()) {
			System.out.println(it.next());

		}
		System.out.println();

		it = oriList.iterator();
		System.out.println("ORILIST-------------------->>>>.>");
		while (it.hasNext()) {
			System.out.println(it.next());
		}

		return PDFDataCheck.lineDifferenceCheck(updatedSam, updatedOri);

	}

	public static int lineDifferenceCheck(List<String> list1, List<String> list2) throws Exception {

		// List<String> list1 = new ArrayList<String>();
		// List<String> list2 = new ArrayList<String>();
		//
		// Scanner sc=new Scanner(samText);
		// Scanner sc1=new Scanner(oriText);
		//
		// while(sc.hasNext())
		// {
		// String temp=sc.next();
		// if(!temp.equals(" ") && !temp.equals(null))
		// list1.add(temp);
		// }
		//
		// while(sc1.hasNext())
		// {
		// String temp=sc1.next();
		// if(!temp.equals(" ") && !temp.equals(null))
		// list2.add(temp);
		// }

		Iterator<String> it = list1.iterator();
		Iterator<String> it1 = list2.iterator();
		int lineNumber = 0;

		String currSam = it.next();
		String currOri = it1.next();
		List<String> sampleLine = new ArrayList<String>();
		List<String> oriLine = new ArrayList<String>();
		List<String> lineNumbers = new ArrayList<String>();

		System.out.println("\n\nStaticc content\n\n");
		while (it.hasNext() && it1.hasNext()) {
			if (!currSam.equals(currOri)) {
				sampleLine.add(currSam);
				System.out.println("CrrSammmm====================>" + currSam);
				oriLine.add(currOri);
				lineNumbers.add(Integer.toString(lineNumber));
			}
			currSam = it.next();
			currOri = it1.next();
			lineNumber++;

		}
		it = sampleLine.iterator();
		it1 = oriLine.iterator();
		Iterator<String> itt = lineNumbers.iterator();
		int fc = 0;
		while (it.hasNext()) {
			String currExpSam = it.next();
			String currActOri = it1.next();
			String currLineNum = itt.next();

			PDFValidation pDFValidation = new PDFValidation(testCaseId);
			boolean b = pDFValidation.validatePDFFieldValue("SampleNotice_LineNumber-" + currLineNum, "STATIC",
					currExpSam, currActOri);

			if (!b)
				fc++;

		}

		return fc;

	}

	private static int lineNumber(String samText, int wordCount) {
		int lineNumber = 0;
		int currWordCount = 0;
		List<String> sam = new ArrayList<String>();

		Scanner sc = new Scanner(samText);
		while (sc.hasNextLine()) {
			String temp = sc.nextLine();
			if (!temp.equals(" "))
				sam.add(temp.trim());
		}

		Iterator<String> it = sam.iterator();
		while (it.hasNext()) {
			String currLine = it.next();
			lineNumber++;
			Scanner sc1 = new Scanner(currLine);
			while (sc1.hasNext()) {
				sc1.next();
				currWordCount++;
				if (currWordCount == wordCount) {
					return lineNumber;
				}
			}
		}

		return lineNumber;

	}

	public List<String> dynamicPDFMatch(HashMap nme) throws Exception {
		{
			File oriFile = new File(actualFile);
			PDDocument oriPdf = PDDocument.load(oriFile);

			File samFile = new File(sampleFile);
			PDDocument samPdf = PDDocument.load(samFile);
			// File samPdf=new File("b.txt");
			// File oriPdf=new File("a.txt");
			// BufferedReader samText=new BufferedReader(new
			// FileReader(samPdf));
			// BufferedReader oriText=new BufferedReader(new
			// FileReader(oriPdf));

			int wordCount = 0;
			PDFTextStripper stripper = new PDFTextStripper();
			String oriText = stripper.getText(oriPdf);
			String samText = stripper.getText(samPdf);

			List<String> sam = new ArrayList<String>();
			List<String> ori = new ArrayList<String>();

			Scanner sc = new Scanner(samText);
			while (sc.hasNextLine()) {
				String temp = sc.nextLine();
				if (!temp.equals(" "))
					sam.add(temp.trim());
			}
			System.out.println(sam.size());

			Scanner sc1 = new Scanner(oriText);
			while (sc1.hasNextLine()) {
				String temp = sc1.nextLine();
				if (!temp.equals(" "))
					ori.add(temp.trim());
			}
			System.out.println("OriSize=" + ori.size());

			List<String> samList = new ArrayList<String>();
			List<String> oriList = new ArrayList<String>();
			List<Integer> lineNumbers = new ArrayList<Integer>();

			Iterator<String> it = sam.iterator();
			Iterator<String> it1 = ori.iterator();

			int samLineCount = -1;
			while (it.hasNext()) {
				int j = 0;
				String samLine = it.next();
				String oriLine = it1.next();
				samLineCount++;

				System.out.println(samLineCount);
				Scanner scanSamLine = new Scanner(samLine);
				Scanner scanOriLine = new Scanner(oriLine);

				String samWord = scanSamLine.next();
				wordCount++;
				String oriWord = scanOriLine.next();

				int i = 0;

				do {
					if (samWord.equals(oriWord)) {
						System.out.println("Same");
						if (scanSamLine.hasNext()) {
							samWord = scanSamLine.next();
							wordCount++;
						}
						if (scanOriLine.hasNext())
							oriWord = scanOriLine.next();
						j++;

					} else {
						// SamWord contains "["
						if (samWord.contains("[")) {
							lineNumbers.add(lineNumber(samText, wordCount));

							System.out.println("Contains [");
							if (samWord.charAt(samWord.length() - 1) == ',') {
								samList.add(samWord.substring(1, samWord.length() - 2));

							} else {
								samList.add(samWord.substring(1, samWord.length() - 1));
							}

							StringBuilder sbOri = new StringBuilder();

							// If word exists after "]"
							if (scanSamLine.hasNext()) {
								System.out.println("Word after ]");
								samWord = scanSamLine.next();
								wordCount++;

								int y = 0;
								while (!oriWord.equals(samWord)) {
									if (y == 0) {
										sbOri.append(oriWord);
										y = 1;
									}

									else
										sbOri.append(" " + oriWord);

									oriWord = scanOriLine.next();
								}

							}
							// If no word after "]"
							else {
								System.out.println("No word after ]" + i++);
								Scanner scanNextLineSam = new Scanner(sam.get(samLineCount + 1));
								Scanner scanNextLineOri = new Scanner(ori.get(samLineCount + 1));

								String nxtSam = scanNextLineSam.next();
								String nxtOri = scanNextLineOri.next();

								sbOri.append(oriWord);

								while (scanOriLine.hasNext()) {
									oriWord = scanOriLine.next();
									sbOri.append(" " + oriWord);
								}

								if (!nxtSam.contains("[")) {
									System.out.println("Next line Sam not contains [");
									int y = 0;
									while (!nxtSam.equals(nxtOri)) {
										System.out.println("nxtSam nxt Ori not equal");
										if (y == 0) {
											sbOri.append(nxtOri);
											y = 1;
										} else {
											sbOri.append(" " + nxtOri);
										}

										nxtOri = scanNextLineOri.next();
									}

								}

								scanNextLineOri.close();
								scanNextLineSam.close();

							}

							String sbOriString = sbOri.toString();
							if (sbOriString.charAt(sbOriString.length() - 1) == ',') {
								oriList.add(sbOriString.substring(0, sbOriString.length() - 1));
							} else {
								oriList.add(sbOriString);
							}

						}
						// If samWord and OriWord not equal and SamWord doesnt
						// contain "["
						else {
							while (!oriWord.equals(samWord)) {
								System.out.println("No [ and ! equal" + i++);
								oriWord = scanOriLine.next();
							}

						}

					}
				} while (scanSamLine.hasNext());

				// ------->> Extra Loop

				if (j > 0) {
					if (samWord.equals(oriWord)) {
						System.out.println("Same");

					} else {
						// SamWord contains "["
						if (samWord.contains("[")) {
							lineNumbers.add(lineNumber(samText, wordCount));

							System.out.println("Contains [");
							if (samWord.charAt(samWord.length() - 1) == ',') {
								samList.add(samWord.substring(1, samWord.length() - 2));

							} else {
								samList.add(samWord.substring(1, samWord.length() - 1));
							}

							StringBuilder sbOri = new StringBuilder();

							// If word exists after "]"
							if (scanSamLine.hasNext()) {
								System.out.println("Word after ]");
								samWord = scanSamLine.next();
								wordCount++;
								int y = 0;
								while (!oriWord.equals(samWord)) {
									if (y == 0) {
										sbOri.append(oriWord);
										y = 1;
									}

									else
										sbOri.append(" " + oriWord);

									oriWord = scanOriLine.next();
								}

							}
							// If no word after "]"
							else {
								System.out.println("No word after ]" + i++);
								Scanner scanNextLineSam = new Scanner(sam.get(samLineCount + 1));
								Scanner scanNextLineOri = new Scanner(ori.get(samLineCount + 1));

								String nxtSam = scanNextLineSam.next();
								String nxtOri = scanNextLineOri.next();

								sbOri.append(oriWord);

								while (scanOriLine.hasNext()) {
									oriWord = scanOriLine.next();
									sbOri.append(" " + oriWord);
								}

								if (!nxtSam.contains("[")) {
									System.out.println("Next line Sam not contains [");
									int y = 0;
									while (!nxtSam.equals(nxtOri)) {
										System.out.println("nxtSam nxt Ori not equal");
										sbOri.append(" " + nxtOri);

										nxtOri = scanNextLineOri.next();
									}

								}

								scanNextLineOri.close();
								scanNextLineSam.close();

							}
							String sbOriString = sbOri.toString();

							if (sbOriString.charAt(sbOriString.length() - 1) == ',') {
								oriList.add(sbOriString.substring(0, sbOriString.length() - 1));
							} else {
								oriList.add(sbOriString);
							}

						}

					}

				}

				// --------->> Extra Loop Close

				scanOriLine.close();
				scanSamLine.close();
			}

			Iterator<String> itt = samList.iterator();
			Iterator<String> itt1 = oriList.iterator();

			while (itt.hasNext()) {
				System.out.println(itt.next() + " --> " + itt1.next());
			}

			// Create HTML Report----------------------------------------------
			it = samList.iterator();
			it1 = oriList.iterator();
			Iterator<Integer> it3 = lineNumbers.iterator();
			int fc = 0;
			boolean b;
			while (it.hasNext()) {
				String currExpSam = it.next();
				String currActOri = it1.next();
				String currLineNum = Integer.toString(it3.next());

				if (nme.get(currExpSam) != null) {
					PDFValidation pDFValidation = new PDFValidation(testCaseId);
					b = pDFValidation.validatePDFFieldValue("SampleNotice_LineNumber-" + currLineNum, currExpSam,
							nme.get(currExpSam).toString(), currActOri);

				} else {
					PDFValidation pDFValidation = new PDFValidation(testCaseId);
					b = pDFValidation.validatePDFFieldValue("SampleNotice_LineNumber-" + currLineNum, currExpSam,
							"EMPTY", currActOri);

				}

				if (!b)
					fc++;

			}

			fc += PDFDataCheck.removeContent(oriList, samList);

			if (fc > 0) {
				throw new Exception("Content Mismatch");
			}
			return oriList;

		}

	}
}
