package notices;

import java.io.IOException;
import org.apache.log4j.Logger;
import utils.TestReport;

public class PDFValidation {
	protected String testCaseId;
	protected Logger logger;

	public PDFValidation(String testCaseId) {
		this.testCaseId = testCaseId;
		logger = Logger.getLogger(testCaseId);
	}

	public boolean validatePDFFieldValue(String pdfName, String fieldName, String expValue, String actValue) throws Exception{
		boolean status = true;
			if(! expValue.equals(actValue)){
				status =false;
			}
		try {
			TestReport.stepResultInHTML(pdfName, testCaseId, fieldName, "ValidatePDFField", expValue,actValue, status,"");
		} catch (IOException e) {
			throw new Exception("Step Result in HTML Error for module ["+pdfName + "] Field ["+fieldName + "] Expected Value ["+ expValue + "] Actual Value ["+actValue + "]");
		}
		
//		if(status==false){
//			throw new Exception("Unable To [ValidateDBField] for Table ["+pdfName + "] and Field ["+fieldName + "] Expected Value ["+ expValue + "] Actual Value ["+actValue + "]");
//		}
		return status;
	}
	
	
}
