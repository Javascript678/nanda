package modules.rac;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.rac.RAC_Data;
import pages.additionalQuestion.AdditionalQuestionStartPage;
import pages.additionalQuestion.AdditionalQuestionSummaryPage;
import pages.additionalQuestion.EmployerHealthCoverageInfoPage;
import pages.additionalQuestion.HealthInsuranceInfoPage;
import pages.additionalQuestion.MassHealthSpecQuestionPage;
import pages.additionalQuestion.OtherInsurancePage;
import pages.additionalQuestion.TaxFilerAndOtherAdditionalQuePage;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import pages.familyHouseHold.AddressDetailsPage;
import pages.familyHouseHold.CitizenImmigrationStatusPage;
import pages.familyHouseHold.EnterHHMemRelationshipPage;
import pages.familyHouseHold.EthnicityRacePage;
import pages.familyHouseHold.FamilyHHStartPage;
import pages.familyHouseHold.FamilyHHSummaryPage;
import pages.familyHouseHold.IntendToResidePage;
import pages.familyHouseHold.IsAnyOneInJailPage;
import pages.familyHouseHold.MoreAboutThisHHPage;
import pages.familyHouseHold.ParentCaretakerRelativesPage;
import pages.familyHouseHold.PastTaxCreditPage;
import pages.familyHouseHold.PersonalInformationPage;
import pages.familyHouseHold.ReasonableAccomPage;
import pages.familyHouseHold.TellUsAboutHHPage;
import pages.income.AnnualIncomePage;
import pages.income.CurrentIncomeDetailsPage1;
import pages.income.CurrentIncomePage1;
import pages.income.IncomeDiscrepancyPage;
import pages.income.IncomeStartPage;
import pages.income.IncomeSummaryPage;
import pages.profile.IdProofingPage;
import pages.profile.IdVerificationPage;
import pages.profile.MyElig_EligAppPage;
import pages.profile.MyProfilePage;
import pages.startApplication.DoYouWantHelpPayingPage;
import pages.startApplication.HHMemberSummaryPage;
import pages.startApplication.HOHContactInformationPage;
import pages.startApplication.IsSomeOneHelpingPage;
import pages.startApplication.StartAppBeginProcessPage;
import pages.startApplication.StartYourAppPage;
import pages.startApplication.WhoAreYourHHMemberPage;
import utils.PageHeader;

/** @author ppinho
 * 
 * This class contains the methods used to complete the Start Your Application Module
 * 
 */

public class ReportAChangeModule extends CommonPage implements CommonPageOR {
	
	private static final By startYourAppNav = By.xpath("//*[@id='startApplication' and contains(@class, 'selected')]");

	public ReportAChangeModule(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	// ppinho
	private String trimHeader(String header) throws Exception {
		// Trim Header
		if(header.contains("Personal Information")){
			header = "Personal Information";
		}else if(header.contains("Citizenship/Immigration Status")){
			header = "Citizenship/Immigration Status";
		}else if(header.contains("Ethnicity & Race")){
			header = "Ethnicity & Race (optional)";
		}else if(header.contains("Tax Filer & Other Additional Questions")){
			header = "Tax Filer & Other Additional Questions";
		}else if(header.contains("Current Income") && !header.contains("Details")){
			header = "Current Income";
		}else if(header.contains("Current Income Details")){
			header = "Current Income Details";
		}else if(header.contains("Health Insurance Information")){
			header = "Health Insurance Information";
		}else if(header.contains("Employer Health Coverage Information")){
			header = "Employer Health Coverage Information";
		}else if(header.contains("Other Insurance")){
			header = "Other Insurance";
		}else if(header.contains("MassHealth Specific Questions")){
			header = "MassHealth Specific Questions";
		}
		return header;
	}

	// ppinho
	public void completeReportAChangeDetails(String pageHeader, String displayShelteredWorkshopQuestion, EVPD_Data evpdData, RAC_Data racData) throws Exception {
		int memCount = evpdData.memsData.size();
		
		String trimHeader = trimHeader(pageHeader);
		
		switch(trimHeader){
			case "Start Your Application":
				StartYourAppPage startYourAppPage = new StartYourAppPage(driver, testCaseId);
				startYourAppPage.evpdClickOnSaveAndContinueBtn();				

				break;
				
			case "Head of Household Contact Information":
				HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver, testCaseId);
				hohContactInformationPage.racSubmitHOHContactInformation(racData);
				break;
				
			case "Is someone helping you?":
				IsSomeOneHelpingPage someOneHelpingPage = new IsSomeOneHelpingPage(driver, testCaseId);
				someOneHelpingPage.racSelectIfSomeOneHelping(racData.someOneHelping);
				break;
				
			case "Do you need help paying for health coverage?":
				DoYouWantHelpPayingPage doYouNeedHelpPayingPage = new DoYouWantHelpPayingPage(driver, testCaseId);
				doYouNeedHelpPayingPage.racSelectWhoisApplyingAndIfHelpNeede(racData.faReqd);
				break;
				
			case "Who Are Your Household Members?":
				WhoAreYourHHMemberPage whoAreYourHHMemberPage = new WhoAreYourHHMemberPage(driver, testCaseId);
				whoAreYourHHMemberPage.racProvideMembersDetail(racData);
				break;
				
			case "Household Member Summary":
				HHMemberSummaryPage hhMemberSummaryPage = new HHMemberSummaryPage(driver,testCaseId);
				hhMemberSummaryPage.racClickOnSaveAndContinueBtn();
				break;
				
			case "Family & Household":
				FamilyHHStartPage familyHHStartPage = new FamilyHHStartPage(driver, testCaseId);
				familyHHStartPage.evpdClickOnSaveAndContinueBtn();
				break;
				
			case "Tell Us About Your Household":
				TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
				tellUsAboutHHPage.racSelectDetailsForTaxHH(racData.memsData);
				break;
				
			case "Past Tax Credits (Optional)":
				PastTaxCreditPage postTaxCreditPage = new PastTaxCreditPage(driver, testCaseId);
				postTaxCreditPage.racClickOnSaveAndContinueBtn(racData.faReqd, racData.memsData.get(0).filingTaxes);
				break;
				
			case "Parent/Caretaker Relatives":
				ParentCaretakerRelativesPage parentCaretakerRelativesPage = new ParentCaretakerRelativesPage(driver, testCaseId);
				parentCaretakerRelativesPage.racCompleteParentCaretakerInfo(racData.faReqd, racData.memsData);
				break;
				
			case "Personal Information":
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					if(pageHeader.contains(evpdData.memsData.get(memIndex).fullName + " - " + trimHeader)){
						PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
						personalInformationPage.racEnterMemPersonalInfo(memIndex, racData);
						break;
					}
				}
				break;
				
			case "Citizenship/Immigration Status":
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					//if(memIndex == 0 && evpdData.whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
					
					if(pageHeader.contains(evpdData.memsData.get(memIndex).fullName + " - " + trimHeader)){
						CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver, testCaseId);
						citizenImmigrationStatusPage.racSelectImmigartionStatusForMember(memIndex, racData);
						break;
					}
				}
				break;

			case "Ethnicity & Race (optional)":
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					//if(memIndex == 0 && evpdData.whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
					
					if(pageHeader.contains(evpdData.memsData.get(memIndex).fullName + " - " + trimHeader)){
						EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);
						ethnicityRacePage.racSelectEthnicityRaceForMembrs(memIndex, racData);
						break;
					}
				}
				break;
				
			case "Address Details":
				AddressDetailsPage addressDetailsPage = new AddressDetailsPage(driver, testCaseId);
				addressDetailsPage.racEnterAddressDetailsForMembers(racData.whoIsApplying, racData.memsData);
				break;
				
			case "Intend To Reside":
				IntendToResidePage intendToResidePage = new IntendToResidePage(driver, testCaseId);
				intendToResidePage.racSelectMembersIntendToResideOutsideMA(racData.memsData);	
				break;
				
			case "More about this household":
				MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);
				moreAboutThisHHPage.racCompleteMoreAboutHHForMembers(racData.faReqd, racData.whoIsApplying, racData.memsData);
				break;
				
			case "Enter Household Members Relationships":
				EnterHHMemRelationshipPage enterHHMemRelationshipPage = new EnterHHMemRelationshipPage(driver, testCaseId);
				enterHHMemRelationshipPage.racSelectMemsRelationship(racData.memsData);		
				break;
				
			case "Reasonable Accommodation":
				ReasonableAccomPage reasonableAccomPage = new ReasonableAccomPage(driver, testCaseId);
				reasonableAccomPage.racCompleteResonableAccForMembers(racData.memsData);
				break;
				
			case "Is Anyone in Jail or Prison?":
				IsAnyOneInJailPage isAnyOneInJailPage = new IsAnyOneInJailPage(driver, testCaseId);
				isAnyOneInJailPage.racProvideDetailIfAnyMemberInJail(racData.memsData);
				break;
				
			case "Tax Filer & Other Additional Questions":
				TaxFilerAndOtherAdditionalQuePage taxFilerAdditionalQuesPage = new TaxFilerAndOtherAdditionalQuePage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){						
						if(taxFilerAdditionalQuesPage.elgMemChangeAnswerInd(memIndex)){
							taxFilerAdditionalQuesPage.racCompleteTaxFilerQuestion(memIndex, false);
						}else if(taxFilerAdditionalQuesPage.hasSSNInd(memIndex)){
							taxFilerAdditionalQuesPage.racCompleteSSNQuestion(memIndex, false);
						}
					}
				}
				break;
				
			case "Family & Household Summary":
				FamilyHHSummaryPage familyHHSummaryPage = new FamilyHHSummaryPage(driver, testCaseId);
				familyHHSummaryPage.racClickOnSaveAndContinueAndHandleContinueAppIssue();
				break;
				
			case "Income":
				IncomeStartPage incomeStartPage = new IncomeStartPage(driver, testCaseId);
				incomeStartPage.racClickOnSaveAndContinueBtn(evpdData.faReqd);
				break;
				
			case "Current Income":
				CurrentIncomePage1 currentIncomePage = new CurrentIncomePage1(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					if(pageHeader.contains(evpdData.memsData.get(memIndex).fullName + "'s " + trimHeader)){
						currentIncomePage.racCompleteCurrentIncomeForMembers(memIndex, displayShelteredWorkshopQuestion, racData.memsData.get(memIndex));
					}
				}
				break;
				
			case "Current Income Details":
				CurrentIncomeDetailsPage1 currentIncomeDetailsPage = new CurrentIncomeDetailsPage1(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					if(pageHeader.contains(evpdData.memsData.get(memIndex).fullName + "'s " + trimHeader)){
						currentIncomeDetailsPage.racCompleteCurrentIncomeDetailsForMembers(memIndex, racData.memsData.get(memIndex));
					}
				}
				break;
				
			case "Income Discrepancies - Additional Income Questions":
				IncomeDiscrepancyPage incomeDiscrepancyPage = new IncomeDiscrepancyPage(driver, testCaseId);
				
				for(int mCounter = 0; mCounter < memCount; mCounter++){
					if(incomeDiscrepancyPage.isVerifyManualBtnPresent(mCounter)){
						incomeDiscrepancyPage.racVerifyIncomeDescripancyMannually(mCounter);
					}
				}
				break;
				
			case "Annual Income":
				AnnualIncomePage annualIncomePage = new AnnualIncomePage(driver, testCaseId);
				
				for(int mCounter = 0; mCounter < memCount; mCounter++){
					annualIncomePage.racVerifyExpectedAnnualIncomeForMember(mCounter, racData.memsData.get(mCounter));
				}
				break;
				
			case "Income Summary":
				IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
				incomeSummaryPage.racClickOnSaveAndContinueBtn(racData.faReqd);
				break;
				
			case "Additional Questions":
				AdditionalQuestionStartPage additionalQuestionStartPage = new AdditionalQuestionStartPage(driver, testCaseId);
				additionalQuestionStartPage.racClickOnSaveAndContinue(racData.faReqd);
				break;
				
			case "Health Insurance Information":
				HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					//if(memIndex == 0 && evpdData.whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
					
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){
						healthInsuranceInfoPage.racEnterHealthInsuranceInformationForMembers(memIndex, racData);
					}
				}
				break;
				
			case "Employer Health Coverage Information":
				EmployerHealthCoverageInfoPage employerHealthCoverageInfo = new EmployerHealthCoverageInfoPage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					//if(memIndex == 0 && evpdData.whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
					
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){
						employerHealthCoverageInfo.racSelectEmployerHealthCoverageInformationForMember(memIndex, racData);
					}
				}
				break;
				
			case "Other Insurance":
				OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){					
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){
						otherInsurancePage.racEnterOtherInsuranceForMembers(memIndex, racData);
					}
				}
				break;
				
			case "MassHealth Specific Questions":
				MassHealthSpecQuestionPage massHealthSpecQuestion = new MassHealthSpecQuestionPage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){					
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){
						massHealthSpecQuestion.racEnterMassHealthSpecificQuestionsForMembers(memIndex, racData);
					}
				}
				break;
				
			case "Additional Questions Summary":
				AdditionalQuestionSummaryPage additionalQuestionSummary = new AdditionalQuestionSummaryPage(driver, testCaseId);
				additionalQuestionSummary.racClickOnSaveAndContinueBtn(evpdData.faReqd);
				break;
				
			default:
				throw new Exception("Report A Change Module Failed at [" + pageHeader + "]");
		}
	}
	
}
