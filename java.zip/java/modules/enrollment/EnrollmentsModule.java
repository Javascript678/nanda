package modules.enrollment;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.enrollment.Enrollment_Data;
import appdata.evpd.EVPD_Data;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import pages.eligibilityResult.CurrentYearEligibilityResultPage;
import pages.shopping.DentalPlanShopingPage;
import pages.shopping.EnrollPage;
import pages.shopping.FindAHealthOrDentalPlanPage;
import pages.shopping.HealthPlanShopingPage;
import pages.shopping.MyEnrollmentPage;
import pages.shopping.PlanFinderToolPage;
import pages.shopping.QualifyingLifeEventPage;
import pages.shopping.ReviewApplicationPage;
import pages.shopping.ReviewShoppingCartPage;
import pages.shopping.ShopAndEnrollPage;

/** @author ppinho
 * 
 * This class contains the methods used to complete the Start Your Application Module
 * 
 */

public class EnrollmentsModule extends CommonPage implements CommonPageOR {
	
	private static final By canIShopBtn = By.xpath("//div[@id='eligibilityResult']//input[@value='Can I Shop?']");
	
	CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(driver, testCaseId);
	
	public EnrollmentsModule(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public boolean isQLEPresent() throws Exception{
		return isElementPresent(canIShopBtn);
	}

	// ppinho
	public void completeQLEDetails(EVPD_Data evpdData, Enrollment_Data enrollmentData) throws Exception {
		currentYearEligibilityResultPage.gotoQLEPage();
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		
		if(enrollmentData.memsData.get(0).loseHiCoverage){
			for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
				qualifyingLifeEventPage.selectMemberLostCoverage(memIndex);
				qualifyingLifeEventPage.selectMemberLostCoverageDate(memIndex, enrollmentData.appDate);
				qualifyingLifeEventPage.selectNotPayingPremiums(memIndex, enrollmentData.memsData.get(0).notPayingPremiums);
				qualifyingLifeEventPage.selectCanceledHealthInsurance(memIndex, enrollmentData.memsData.get(0).healthInsurance);
			}				
		}else{
			qualifyingLifeEventPage.selectIfAnyMemLoseHIOrExpToLose(enrollmentData.memsData.get(0).loseHiCoverage);
		}
		
		if(enrollmentData.memsData.get(0).gainAdependent){
			if(enrollmentData.memsData.get(0).recentlyMarried){
				qualifyingLifeEventPage.selectIfAnyMemMarriageStatusGotChanged(enrollmentData.memsData.get(0).recentlyMarried);
				
				for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
					qualifyingLifeEventPage.selectMarried(memIndex);
					qualifyingLifeEventPage.selectMarriageDate(memIndex, enrollmentData.appDate);
				}
			}else{
				qualifyingLifeEventPage.selectIfAnyMemMarriageStatusGotChanged(enrollmentData.memsData.get(0).recentlyMarried);
			}
			
			if(enrollmentData.memsData.get(0).birthInHousehold){
				qualifyingLifeEventPage.selectIfAnyMemAddedDueToBirth(enrollmentData.memsData.get(0).birthInHousehold);
				
				for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
					qualifyingLifeEventPage.selectBirth(memIndex);
					qualifyingLifeEventPage.selectDateOfBirth(memIndex, enrollmentData.appDate);
				}
			}else{
				qualifyingLifeEventPage.selectIfAnyMemAddedDueToBirth(enrollmentData.memsData.get(0).birthInHousehold);
			}
			
			if(enrollmentData.memsData.get(0).fosterCare){
				qualifyingLifeEventPage.selectIfAnyMemAddedDueToBirth(enrollmentData.memsData.get(0).fosterCare);
				
				for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
					qualifyingLifeEventPage.selectBirth(memIndex);
					qualifyingLifeEventPage.selectMemAddedDueToFosterCare(evpdData.memsData.get(0).firstName, evpdData.memsData.get(0).lastName);
					qualifyingLifeEventPage.selectFosterMemDate(evpdData.memsData.get(0).firstName, evpdData.memsData.get(0).lastName, enrollmentData.appDate);
				}
			}else{
				qualifyingLifeEventPage.selectIfAnyMemAddedDueToBirth(enrollmentData.memsData.get(0).fosterCare);
			}
		}else{
			qualifyingLifeEventPage.selectIfAnyMemDependentStatusGotChanged(enrollmentData.memsData.get(0).gainAdependent);
		}
		
		if(enrollmentData.memsData.get(0).lawfullyPresentImmigrant){
			qualifyingLifeEventPage.selectIfAnyMemImmStatusGotChanged(enrollmentData.memsData.get(0).lawfullyPresentImmigrant);
			
			for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
				qualifyingLifeEventPage.selectImmigrationStatusGained(memIndex);
				qualifyingLifeEventPage.selectImmigrationChangeDate(memIndex, enrollmentData.appDate);
			}				
		}else{
			qualifyingLifeEventPage.selectIfAnyMemImmStatusGotChanged(enrollmentData.memsData.get(0).lawfullyPresentImmigrant);
		}
		
		if(enrollmentData.memsData.get(0).moveToMass){
			qualifyingLifeEventPage.selectIfAnyMemMoveToMAWithPrevMH(enrollmentData.memsData.get(0).moveToMass);
			
			for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
				qualifyingLifeEventPage.selectMemberMovedMA(memIndex);
				qualifyingLifeEventPage.selectMoveToMa(memIndex, enrollmentData.appDate);
			}				
		}else{
			qualifyingLifeEventPage.selectIfAnyMemMoveToMAWithPrevMH(enrollmentData.memsData.get(0).moveToMass);
		}
		
		if(enrollmentData.memsData.get(0).recentlyReleasedFromPrison){
			qualifyingLifeEventPage.selectIfAnyMemIncarcerationStatusGotChanged(enrollmentData.memsData.get(0).recentlyReleasedFromPrison);
			
			for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
				qualifyingLifeEventPage.selectMemberReleasedFromJail(memIndex);
				qualifyingLifeEventPage.selectMemberReleasedFromJailDate(memIndex, enrollmentData.appDate);
			}				
		}else{
			qualifyingLifeEventPage.selectIfAnyMemIncarcerationStatusGotChanged(enrollmentData.memsData.get(0).recentlyReleasedFromPrison);
		}			
		
		qualifyingLifeEventPage.selectIfAnyMemDomesticAbuseStatusGotChanged(enrollmentData.memsData.get(0).victimDomAbuseAban);
		qualifyingLifeEventPage.takeScreenshot();
		qualifyingLifeEventPage.clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	/*public void completeHealthAndDentalPlanShopping(EVPD_Data evpdData, Enrollment_Data enrollmentData) throws Exception {
		currentYearEligibilityResultPage.gotoFindAPlanPage();

		ShopAndEnrollPage shopAndEnrollPage = new ShopAndEnrollPage(driver, testCaseId);
		shopAndEnrollPage.pageLoadAndClickOnSaveAndContinue();

		PlanFinderToolPage planFinderToolPage = new PlanFinderToolPage(driver, testCaseId);
		FindAHealthOrDentalPlanPage findAHealthOrDentalPlanPage = new FindAHealthOrDentalPlanPage(driver, testCaseId);

		HealthPlanShopingPage healthPlanShopingPage = new HealthPlanShopingPage(driver, testCaseId);
		DentalPlanShopingPage dentalPlanShopingPage = new DentalPlanShopingPage(driver, testCaseId);
		
		int gpHealthPlan = 1;
		
		for(int i = 0; i < evpdData.memCount; i++){
			if(evpdData.memsData.get(i).taxHHMemIndex.equals(1) && enrollmentData.memsData.get(i).subscriber){
				healthPlanShopingPage.clickOnFindAPlanForShoppingGrp(gpHealthPlan++);
				planFinderToolPage.pageLoadAndSkipPlanShopping();
				findAHealthOrDentalPlanPage.findAHealthPlanPageLoadAndClickOnAddToCart(1);
				findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
			}
		}

		healthPlanShopingPage.pageLoadAndClickOnContinueBtn();
		
		int gpDentalPlan = 1;
		
		for(int i = 0; i < evpdData.memCount; i++){
			if(evpdData.memsData.get(i).taxHHMemIndex.equals(1) && enrollmentData.memsData.get(i).subscriber){
				dentalPlanShopingPage.clickOnFindAPlanForShoppingGrp(gpDentalPlan++);
				planFinderToolPage.pageLoadAndSkipPlanShopping();
				findAHealthOrDentalPlanPage.findADentalPlanPageLoadAndClickOnAddToCart(1);
				findAHealthOrDentalPlanPage.handleWarningDialogIfPresent();
			}
		}

		for(int i = 0; i < evpdData.memCount;){
			if(evpdData.memsData.get(i).taxHHMemIndex.equals(1) && enrollmentData.memsData.get(i).subscriber){
				dentalPlanShopingPage.pageLoadAndClickOnContinueBtn();
		
				ReviewShoppingCartPage reviewShoppingCartPage = new ReviewShoppingCartPage(driver, testCaseId);
				reviewShoppingCartPage.pageLoadAndClickOnSaveAndContinue();
		
				ReviewApplicationPage reviewApplicationPage = new ReviewApplicationPage(driver, testCaseId);
				reviewApplicationPage.pageLoadAndClickOnSaveAndContinue();
		
				EnrollPage enrollPage = new EnrollPage(driver, testCaseId);
				enrollPage.enterHohSignAndContinue();
		
				MyEnrollmentPage myEnrollmentPage = new MyEnrollmentPage(driver, testCaseId);
				myEnrollmentPage.verifyPageLoad();
				myEnrollmentPage.takeScreenshot();
			}
			
			break;
		}
	}*/
	
}
