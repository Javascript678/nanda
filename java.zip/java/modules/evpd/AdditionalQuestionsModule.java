package modules.evpd;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import enums.WhoIsApplying;
import pages.additionalQuestion.AdditionalQuestionStartPage;
import pages.additionalQuestion.AdditionalQuestionSummaryPage;
import pages.additionalQuestion.EmployerHealthCoverageInfoPage;
import pages.additionalQuestion.HealthInsuranceInfoPage;
import pages.additionalQuestion.HealthInsuranceInfoPageR19;
import pages.additionalQuestion.HealthReimbursementArrInfoPage;
import pages.additionalQuestion.MassHealthSpecQuestionPage;
import pages.additionalQuestion.NCPQuestionPage;
import pages.additionalQuestion.OtherInsurancePage;
import pages.additionalQuestion.TaxFilerAndOtherAdditionalQuePage;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import pages.familyHouseHold.AddressDetailsPage;
import pages.familyHouseHold.CitizenImmigrationStatusPage;
import pages.familyHouseHold.EnterHHMemRelationshipPage;
import pages.familyHouseHold.EthnicityRacePage;
import pages.familyHouseHold.FamilyHHStartPage;
import pages.familyHouseHold.FamilyHHSummaryPage;
import pages.familyHouseHold.IntendToResidePage;
import pages.familyHouseHold.IsAnyOneInJailPage;
import pages.familyHouseHold.MoreAboutThisHHPage;
import pages.familyHouseHold.ParentCaretakerRelativesPage;
import pages.familyHouseHold.PastTaxCreditPage;
import pages.familyHouseHold.PersonalInformationPage;
import pages.familyHouseHold.ReasonableAccomPage;
import pages.familyHouseHold.TellUsAboutHHPage;
import pages.income.AnnualIncomePage;
import pages.income.CurrentIncomePage1;
import pages.income.IncomeDiscrepancyPage;
import pages.income.IncomeStartPage;
import pages.income.IncomeSummaryPage;

/** @author ppinho
 * 
 * This class contains the methods used to complete the Start Your Application Module
 * 
 */

public class AdditionalQuestionsModule extends CommonPage implements CommonPageOR {
	
	private static final By additionalQuestionsNav = By.xpath("//*[@id='additionalQuestions' and contains(@class, 'selected')]");

	public AdditionalQuestionsModule(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	// ppinho
	public boolean AdditionalQuestionsIndicator() throws Exception {
		Boolean additionalQuestionsInd = null;
		
		if(isElementPresent(additionalQuestionsNav, 5)){
			additionalQuestionsInd = true;
		}else{
			additionalQuestionsInd = false;
		}
		return additionalQuestionsInd;
	}
	
	// ppinho
	private String trimHeader(String header) throws Exception {
		// Trim Header
		if(header.contains("Health Insurance Information")){
			header = "Health Insurance Information";
		}else if(header.contains("Employer Health Coverage Information")){
			header = "Employer Health Coverage Information";
		}if(header.contains("Other Insurance")){
			header = "Other Insurance";
		}if(header.contains("MassHealth Specific Questions")){
			header = "MassHealth Specific Questions";
		}if(header.contains("Health Reimbursement Arrangement Information")){
			header = "Health Reimbursement Arrangement Information";
		}
		return header;
	}

	// ppinho
	public void completeAdditionalQuestionsDetails(String pageHeader, EVPD_Data evpdData) throws Exception {
		int memCount = evpdData.memsData.size();
		
		String trimHeader = trimHeader(pageHeader);
		
		switch(trimHeader){
			case "Additional Questions":
				AdditionalQuestionStartPage additionalQuestionStartPage = new AdditionalQuestionStartPage(driver, testCaseId);
				additionalQuestionStartPage.evpdClickOnSaveAndContinue(evpdData.faReqd);
				break;
				
			case "Health Insurance Information":
				HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){
						healthInsuranceInfoPage.evpdEnterHealthInsuranceInformationForMembers(memIndex, evpdData);
						healthInsuranceInfoPage.clickOnSaveAndContinueBtn();
					}
				}
				break;
				
			case "Health Reimbursement Arrangement Information":
				HealthReimbursementArrInfoPage healthReimbursementArrInfoPage = new HealthReimbursementArrInfoPage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){					
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){
						healthReimbursementArrInfoPage.evpdCompleteHealthReimbursementArrangementInformation(memIndex, evpdData);					
					}
				}
				break;
				
			case "Employer Health Coverage Information":
				EmployerHealthCoverageInfoPage employerHealthCoverageInfo = new EmployerHealthCoverageInfoPage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){					
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){
						employerHealthCoverageInfo.evpdSelectEmployerHealthCoverageInformationForMember(memIndex, evpdData);
					}
				}
				break;
				
			case "Other Insurance":
				OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){					
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){
						otherInsurancePage.evpdEnterOtherInsuranceForMembers(memIndex, evpdData);
					}
				}
				break;
				
			case "MassHealth Specific Questions":
				MassHealthSpecQuestionPage massHealthSpecQuestion = new MassHealthSpecQuestionPage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){					
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){
						massHealthSpecQuestion.evpdEnterMassHealthSpecificQuestionsForMembers(memIndex, evpdData);
					}
				}
				break;
				
			case "Additional Questions Summary":
				AdditionalQuestionSummaryPage additionalQuestionSummary = new AdditionalQuestionSummaryPage(driver, testCaseId);
				additionalQuestionSummary.evpdClickOnSaveAndContinueBtn(evpdData.faReqd);
				break;
					
			default:
				throw new Exception("Additional Questions Module Failed at [" + pageHeader + "]");
		}
	}

}
