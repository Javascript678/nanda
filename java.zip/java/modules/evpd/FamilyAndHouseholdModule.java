package modules.evpd;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import enums.WhoIsApplying;
import pages.additionalQuestion.TaxFilerAndOtherAdditionalQuePage;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import pages.familyHouseHold.AddressDetailsPage;
import pages.familyHouseHold.CitizenImmigrationStatusPage;
import pages.familyHouseHold.EnterHHMemRelationshipPage;
import pages.familyHouseHold.EthnicityRacePage;
import pages.familyHouseHold.FamilyHHStartPage;
import pages.familyHouseHold.FamilyHHSummaryPage;
import pages.familyHouseHold.IntendToResidePage;
import pages.familyHouseHold.IsAnyOneInJailPage;
import pages.familyHouseHold.MoreAboutThisHHPage;
import pages.familyHouseHold.ParentCaretakerRelativesPage;
import pages.familyHouseHold.PastTaxCreditPage;
import pages.familyHouseHold.PersonalInformationPage;
import pages.familyHouseHold.ReasonableAccomPage;
import pages.familyHouseHold.TellUsAboutHHPage;

/** @author ppinho
 * 
 * This class contains the methods used to complete the Start Your Application Module
 * 
 */

public class FamilyAndHouseholdModule extends CommonPage implements CommonPageOR {
	
	private static final By familyAndHouseholdNav = By.xpath("//*[@id='household' and contains(@class, 'selected')]");

	public FamilyAndHouseholdModule(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	// ppinho
	public boolean familyAndHouseholdIndicator() throws Exception {
		Boolean familyAndHouseholdInd = null;
		
		if(isElementPresent(familyAndHouseholdNav, 5)){
			familyAndHouseholdInd = true;
		}else{
			familyAndHouseholdInd = false;
		}
		return familyAndHouseholdInd;
	}
	
	// ppinho
	private String trimHeader(String header) throws Exception {
		// Trim Header
		if(header.contains("Personal Information")){
			header = "Personal Information";
		}else if(header.contains("Citizenship/Immigration Status")){
			header = "Citizenship/Immigration Status";
		}else if(header.contains("Ethnicity & Race")){
			header = "Ethnicity & Race (optional)";
		}else if(header.contains("Tax Filer & Other Additional Questions")){
			header = "Tax Filer & Other Additional Questions";
		}
		return header;
	}

	// ppinho
	public void completeFamilyAndHouseholdDetails(String pageHeader, EVPD_Data evpdData) throws Exception {
		int memCount = evpdData.memsData.size();
		
		String trimHeader = trimHeader(pageHeader);
		
		switch(trimHeader){
			case "Family & Household":
				FamilyHHStartPage familyHHStartPage = new FamilyHHStartPage(driver, testCaseId);
				familyHHStartPage.evpdClickOnSaveAndContinueBtn();
				break;
				
			case "Tell Us About Your Household":
				TellUsAboutHHPage tellUsAboutHHPage = new TellUsAboutHHPage(driver, testCaseId);
				tellUsAboutHHPage.evpdSelectDetailsForTaxHH(evpdData.memsData);
				break;
				
			case "Past Tax Credits (Optional)":
				PastTaxCreditPage postTaxCreditPage = new PastTaxCreditPage(driver, testCaseId);
				postTaxCreditPage.evpdClickOnSaveAndContinueBtn(evpdData.faReqd, evpdData.memsData.get(0).filingTaxes);
				break;
				
			case "Parent/Caretaker Relatives":
				ParentCaretakerRelativesPage parentCaretakerRelativesPage = new ParentCaretakerRelativesPage(driver, testCaseId);
				parentCaretakerRelativesPage.evpdCompleteParentCaretakerInfo(evpdData.faReqd, evpdData.memsData);
				break;
				
			case "Personal Information":
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					if(pageHeader.contains(evpdData.memsData.get(memIndex).fullName + " - " + trimHeader)){
						PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver, testCaseId);
						personalInformationPage.evpdEnterMemPersonalInfo(memIndex, evpdData);
						break;
					}
				}
				break;
				
			case "Citizenship/Immigration Status":
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					//if(memIndex == 0 && evpdData.whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
					
					if(pageHeader.contains(evpdData.memsData.get(memIndex).fullName + " - " + trimHeader)){
						CitizenImmigrationStatusPage citizenImmigrationStatusPage = new CitizenImmigrationStatusPage(driver, testCaseId);
						citizenImmigrationStatusPage.evpdSelectImmigartionStatusForMember(memIndex, evpdData);
						break;
					}
				}
				break;

			case "Ethnicity & Race (optional)":
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					//if(memIndex == 0 && evpdData.whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
					
					if(pageHeader.contains(evpdData.memsData.get(memIndex).fullName + " - " + trimHeader)){
						EthnicityRacePage ethnicityRacePage = new EthnicityRacePage(driver, testCaseId);
						ethnicityRacePage.evpdSelectEthnicityRaceForMembrs(memIndex, evpdData);
						break;
					}
				}
				break;
				
			case "Address Details":
				AddressDetailsPage addressDetailsPage = new AddressDetailsPage(driver, testCaseId);
				addressDetailsPage.evpdEnterAddressDetailsForMembers(evpdData.whoIsApplying, evpdData.memsData);
				break;
				
			case "Intend To Reside":
				IntendToResidePage intendToResidePage = new IntendToResidePage(driver, testCaseId);
				intendToResidePage.evpdSelectMembersIntendToResideOutsideMA(evpdData.memsData);	
				break;
				
			case "More about this household":
				MoreAboutThisHHPage moreAboutThisHHPage = new MoreAboutThisHHPage(driver, testCaseId);
				moreAboutThisHHPage.evpdCompleteMoreAboutHHForMembers(evpdData.faReqd, evpdData.whoIsApplying, evpdData.memsData);
				break;
				
			case "Enter Household Members Relationships":
				EnterHHMemRelationshipPage enterHHMemRelationshipPage = new EnterHHMemRelationshipPage(driver, testCaseId);
				enterHHMemRelationshipPage.evpdSelectMemsRelationship(evpdData.memsData);		
				break;
				
			case "Reasonable Accommodation":
				ReasonableAccomPage reasonableAccomPage = new ReasonableAccomPage(driver, testCaseId);
				reasonableAccomPage.evpdCompleteResonableAccForMembers(evpdData.memsData);
				break;
				
			case "Is Anyone in Jail or Prison?":
				IsAnyOneInJailPage isAnyOneInJailPage = new IsAnyOneInJailPage(driver, testCaseId);
				isAnyOneInJailPage.evpdProvideDetailIfAnyMemberInJail(evpdData.memsData);
				break;
				
			case "Tax Filer & Other Additional Questions":
				TaxFilerAndOtherAdditionalQuePage taxFilerAdditionalQuesPage = new TaxFilerAndOtherAdditionalQuePage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					if(pageHeader.contains(trimHeader + " for " + evpdData.memsData.get(memIndex).fullName)){						
						if(taxFilerAdditionalQuesPage.elgMemChangeAnswerInd(memIndex)){
							taxFilerAdditionalQuesPage.evpdCompleteTaxFilerQuestion(memIndex, false);
						}else if(taxFilerAdditionalQuesPage.hasSSNInd(memIndex)){
							taxFilerAdditionalQuesPage.evpdCompleteSSNQuestion(memIndex, false);
						}
					}
				}
				break;
				
			case "Family & Household Summary":
				FamilyHHSummaryPage familyHHSummaryPage = new FamilyHHSummaryPage(driver, testCaseId);
				familyHHSummaryPage.evpdClickOnSaveAndContinueAndHandleContinueAppIssue();
				break;
				
			default:
				throw new Exception("Family and Household Module Failed at [" + pageHeader + "]");
		}
	}

}
