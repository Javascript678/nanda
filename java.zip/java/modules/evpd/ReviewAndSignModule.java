package modules.evpd;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import pages.additionalQuestion.AdditionalQuestionStartPage;
import pages.additionalQuestion.HealthInsuranceInfoPage;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import pages.reviewAndSign.ChangeIncomePage;
import pages.reviewAndSign.ExpectedResultsPage;
import pages.reviewAndSign.ReviewAndSignPage;
import pages.reviewAndSign.ReviewApplicationPage;
import pages.reviewAndSign.RightsAndResponsibilityPage;
import utils.PageHeader;

/** @author ppinho
 * 
 * This class contains the methods used to complete the Start Your Application Module
 * 
 */

public class ReviewAndSignModule extends CommonPage implements CommonPageOR {
		
	private static final By ReviewAndSignNav = By.xpath("//*[@id='review' and contains(@class, 'selected')]");

	public ReviewAndSignModule(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public String reviewAndSignHeader() throws Exception {
		PageHeader pageHeader = new PageHeader(driver, testCaseId);
		
		String header = pageHeader.getPageHeader();	
		String reviewAndSignHeader = "";
		
		if(header.equalsIgnoreCase("Change Income") ||
		   isElementPresent(ReviewAndSignNav, 5)){
			reviewAndSignHeader = header;
		}
		
		return reviewAndSignHeader;
	}
	
	public void completeAdditionalQuestionsDetails(String pageHeader, EVPD_Data evpdData) throws Exception {
		switch(pageHeader){
			case "Review & Sign":
				ReviewAndSignPage reviewAndSignPage = new pages.reviewAndSign.ReviewAndSignPage(driver, testCaseId);
				reviewAndSignPage.evpdClickOnSaveAndContinueBtn();
				break;
				
			case "Review Application":
				ReviewApplicationPage reviewApplicationPage = new ReviewApplicationPage(driver, testCaseId);
				//reviewApplicationPage.evpdReviewApplicationThenClickOnSaveAndContinueBtn(evpdData);
				reviewApplicationPage.pageLoadThenClickOnSaveAndContinueBtn();
				break;
				
			case "Expected Results":
				ExpectedResultsPage expectedResultsPage = new ExpectedResultsPage(driver, testCaseId);
				expectedResultsPage.evpdValidateExpectedResultsClickOnSaveAndContinueBtn(evpdData);
				break;
				
			case "Change Income":
				ChangeIncomePage changeIncomePage = new ChangeIncomePage(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
					changeIncomePage.evpdVerifyIncomeClickOnSaveAndContinueBtn(memIndex, evpdData.memsData);
				}
				break;
				
			case "Rights and Responsibilities":
				RightsAndResponsibilityPage rightsAndResponsibilityPage = new RightsAndResponsibilityPage(driver, testCaseId);
				rightsAndResponsibilityPage.evpdCompleteRightsAndResponsibility(evpdData.memsData.get(0), evpdData.rpData);
				break;
					
			default:
				throw new Exception("Additional Questions Module Failed at [" + pageHeader + "]");
		}
	}
}
