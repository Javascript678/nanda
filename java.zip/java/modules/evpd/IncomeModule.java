package modules.evpd;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import pages.additionalQuestion.TaxFilerAndOtherAdditionalQuePage;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import pages.familyHouseHold.AddressDetailsPage;
import pages.familyHouseHold.CitizenImmigrationStatusPage;
import pages.familyHouseHold.EnterHHMemRelationshipPage;
import pages.familyHouseHold.EthnicityRacePage;
import pages.familyHouseHold.FamilyHHStartPage;
import pages.familyHouseHold.FamilyHHSummaryPage;
import pages.familyHouseHold.IntendToResidePage;
import pages.familyHouseHold.IsAnyOneInJailPage;
import pages.familyHouseHold.MoreAboutThisHHPage;
import pages.familyHouseHold.ParentCaretakerRelativesPage;
import pages.familyHouseHold.PastTaxCreditPage;
import pages.familyHouseHold.PersonalInformationPage;
import pages.familyHouseHold.ReasonableAccomPage;
import pages.familyHouseHold.TellUsAboutHHPage;
import pages.income.AnnualIncomePage;
import pages.income.CurrentIncomeDetailsPage1;
import pages.income.CurrentIncomePage1;
import pages.income.IncomeDiscrepancyPage;
import pages.income.IncomeStartPage;
import pages.income.IncomeSummaryPage;

/** @author ppinho
 * 
 * This class contains the methods used to complete the Start Your Application Module
 * 
 */

public class IncomeModule extends CommonPage implements CommonPageOR {
	
	private static final By incomeNav = By.xpath("//*[@id='income' and contains(@class, 'selected')]");

	public IncomeModule(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	// ppinho
	public boolean IncomeIndicator() throws Exception {
		Boolean incomeInd = null;
		
		if(isElementPresent(incomeNav, 5)){
			incomeInd = true;
		}else{
			incomeInd = false;
		}
		return incomeInd;
	}
	
	// ppinho
	private String trimHeader(String header) throws Exception {
		// Trim Header
		if(header.contains("Current Income") && !header.contains("Details")){
			header = "Current Income";
		}else if(header.contains("Current Income Details")){
			header = "Current Income Details";
		}
		return header;
	}

	// ppinho
	public void completeIncomeDetails(String pageHeader, String displayShelteredWorkshopQuestion, EVPD_Data evpdData) throws Exception {
		int memCount = evpdData.memsData.size();
		
		String trimHeader = trimHeader(pageHeader);
		
		switch(trimHeader){
			case "Income":
				IncomeStartPage incomeStartPage = new IncomeStartPage(driver, testCaseId);
				incomeStartPage.evpdClickOnSaveAndContinueBtn(evpdData.faReqd);
				break;
				
			case "Current Income":
				CurrentIncomePage1 currentIncomePage = new CurrentIncomePage1(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					if(pageHeader.contains(evpdData.memsData.get(memIndex).fullName + "'s " + trimHeader)){
						currentIncomePage.evpdCompleteCurrentIncomeForMembers(memIndex, displayShelteredWorkshopQuestion, evpdData.memsData.get(memIndex));
					}
				}
				break;
				
			case "Current Income Details":
				CurrentIncomeDetailsPage1 currentIncomeDetailsPage = new CurrentIncomeDetailsPage1(driver, testCaseId);
				
				for(int memIndex = 0; memIndex < memCount; memIndex++){
					if(pageHeader.contains(evpdData.memsData.get(memIndex).fullName + "'s " + trimHeader)){
						currentIncomeDetailsPage.evpdCompleteCurrentIncomeDetailsForMembers(memIndex, evpdData.memsData.get(memIndex));
					}
				}
				break;
				
			case "Income Discrepancies - Additional Income Questions":
				IncomeDiscrepancyPage incomeDiscrepancyPage = new IncomeDiscrepancyPage(driver, testCaseId);
				
				for(int mCounter = 0; mCounter < memCount; mCounter++){
					if(incomeDiscrepancyPage.isVerifyManualBtnPresent(mCounter)){
						incomeDiscrepancyPage.evpdVerifyIncomeDescripancyMannually(mCounter);
					}
				}
				break;
				
			case "Annual Income":
				AnnualIncomePage annualIncomePage = new AnnualIncomePage(driver, testCaseId);
				
				for(int mCounter = 0; mCounter < memCount; mCounter++){
					annualIncomePage.evpdVerifyExpectedAnnualIncomeForMember(mCounter, evpdData.memsData.get(mCounter));
				}
				break;
				
			case "Income Summary":
				IncomeSummaryPage incomeSummaryPage = new IncomeSummaryPage(driver, testCaseId);
				incomeSummaryPage.evpdClickOnSaveAndContinueBtn(evpdData.faReqd);
				break;
				
			default:
				throw new Exception("Income Module Failed at [" + pageHeader + "]");
		}
	}

}
