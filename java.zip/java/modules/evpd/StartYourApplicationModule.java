package modules.evpd;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.rac.RAC_Data;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import pages.profile.IdProofingPage;
import pages.profile.IdVerificationPage;
import pages.profile.MyElig_EligAppPage;
import pages.profile.MyProfilePage;
import pages.startApplication.DoYouWantHelpPayingPage;
import pages.startApplication.HHMemberSummaryPage;
import pages.startApplication.HOHContactInformationPage;
import pages.startApplication.IsSomeOneHelpingPage;
import pages.startApplication.StartAppBeginProcessPage;
import pages.startApplication.StartYourAppPage;
import pages.startApplication.WhoAreYourHHMemberPage;
import utils.PageHeader;

/** @author ppinho
 * 
 * This class contains the methods used to complete the Start Your Application Module
 * 
 */

public class StartYourApplicationModule extends CommonPage implements CommonPageOR {
	
	private static final By startYourAppNav = By.xpath("//*[@id='startApplication' and contains(@class, 'selected')]");

	public StartYourApplicationModule(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	// ppinho
	public String startYourApplicationHeader() throws Exception {
		PageHeader pageHeader = new PageHeader(driver, testCaseId);
		
		// Use getPageHeader method to find the Pager Header and store it in a String
		String header = pageHeader.getPageHeader();		
		String startYourAppHeader = "";
		
		if(header.equalsIgnoreCase("ID Proofing") ||
		   header.equalsIgnoreCase("Identity Verification") ||
		   header.equalsIgnoreCase("My Profile") ||
		   header.equalsIgnoreCase("Eligibility Application") ||
		   header.equalsIgnoreCase("Start Your Application: Begin Process") || 
		   isElementPresent(startYourAppNav, 5)){
			startYourAppHeader = header;
		}
		
		return startYourAppHeader;
	}

	// ppinho
	public void completeStartYourApplicationDetails(String header, EVPD_Data evpdData) throws Exception {
		switch(header){
			case "ID Proofing":
				IdProofingPage idProofingPage = new IdProofingPage(driver, testCaseId);
				idProofingPage.evpdClickOnSaveAndContinue();
				break;
				
			case "Identity Verification":				
				IdVerificationPage idVerificationPage = new IdVerificationPage(driver, testCaseId);
				idVerificationPage.evpdCompleteIdVerification(evpdData);
				
				break;
			
			case "My Profile":
				MyProfilePage myProfilePage = new MyProfilePage(driver, testCaseId);
				
				String userProfileRefId = myProfilePage.evpdGetUserProfileRefId();
				evpdData.userProfileRefId = userProfileRefId;
				
				myProfilePage.evpdClickOnViewUnlockElg();
								
				break;	
		
			case "Eligibility Application":
				MyElig_EligAppPage myElig_EligAppPage = new MyElig_EligAppPage(driver, testCaseId);
				myElig_EligAppPage.clickOnCreateApplicationBtn(evpdData.appDate);
				
				break;
			
			case "Start Your Application: Begin Process":
				StartAppBeginProcessPage startAppBeginProcessPage = new StartAppBeginProcessPage(driver, testCaseId);
				startAppBeginProcessPage.evpdAcceptSaveAndContinue();
				break;
				
			case "Start Your Application":
				StartYourAppPage startYourAppPage = new StartYourAppPage(driver, testCaseId);
				
				String eligibilityId = startYourAppPage.getEligibilityId();
				evpdData.eligibilityId = eligibilityId;
				
				startYourAppPage.evpdClickOnSaveAndContinueBtn();				

				break;
				
			case "Head of Household Contact Information":
				HOHContactInformationPage hohContactInformationPage = new HOHContactInformationPage(driver, testCaseId);
				hohContactInformationPage.evpdSubmitHOHContactInformation(evpdData);
				break;
				
			case "Is someone helping you?":
				IsSomeOneHelpingPage someOneHelpingPage = new IsSomeOneHelpingPage(driver, testCaseId);
				someOneHelpingPage.evpdSelectIfSomeOneHelping(evpdData.someOneHelping);
				break;
				
			case "Do you need help paying for health coverage?":
				DoYouWantHelpPayingPage doYouNeedHelpPayingPage = new DoYouWantHelpPayingPage(driver, testCaseId);
				doYouNeedHelpPayingPage.evpdSelectWhoisApplyingAndIfHelpNeede(evpdData.faReqd);
				break;
				
			case "Who Are Your Household Members?":
				WhoAreYourHHMemberPage whoAreYourHHMemberPage = new WhoAreYourHHMemberPage(driver, testCaseId);
				whoAreYourHHMemberPage.evpdProvideMembersDetail(evpdData);
				break;
				
			case "Household Member Summary":
				HHMemberSummaryPage hhMemberSummaryPage = new HHMemberSummaryPage(driver,testCaseId);
				hhMemberSummaryPage.evpdClickOnSaveAndContinueBtn();
				break;
				
			default:
				throw new Exception("Start Your Application Module Failed at [" + header + "]");
		}
	}
	
}
