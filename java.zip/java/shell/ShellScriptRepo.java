package shell;

import java.sql.Connection;

import db.RrvBatchReqCtrlTable;
import db.SuperTable;

/**
 * 
 * @author ppinho
 *
 */
public class ShellScriptRepo extends SuperTable {
	
	public ShellScriptRepo(Connection conn, String testCaseId) {
		super(conn, testCaseId);
	}
	
	private String getRrvGenerationShellScript(String userRefId) throws Exception {
		RrvBatchReqCtrlTable rrvBatchReqCtrlTable = new RrvBatchReqCtrlTable(conn, testCaseId);
		String file = rrvBatchReqCtrlTable.getReqFileName(userRefId);
		String shellScript = "sh /ma1esb/batch/rrvmockservice/bin/hCtool /ma1esb/hub/rrv/outbound/external/" + file + " 0 /ma1esb/hub/rrv/inbound/external/";
		return shellScript;
	}
	
	public String getShellScript(String shellScriptToRun, String userRefId) throws Exception {
		String shellScript = null;
		
		switch(shellScriptToRun){
			case "RrvGeneration":
				shellScript = getRrvGenerationShellScript(userRefId);
				break;
		}
		
		return shellScript;
	}
}
