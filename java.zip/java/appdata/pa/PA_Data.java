package appdata.pa;

import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import appdata.common.OptumIdData;
import appdata.evpd.ServiceData;
import enums.BatchJob_Workflow_ID_Mapping;
import enums.PA_CoverageTypes;
import enums.PA_PaymentStatus;
import enums.PortalName;
import enums.TPLUserType;
import enums.TrueFalseValue;

import utils.TestData;

public class PA_Data {
	
	public String appDate;
	public String portal;
	public String url;
	
	public OptumIdData optumIdData = new OptumIdData();
	
	public Integer memCount;
	
	public String userProfileRefId = null;
	public String eligibilityId = null;
	
	public List<PA_MemData> memsData = new ArrayList<PA_MemData>();
	
	public ServiceData serviceData = new ServiceData();
	
	@SuppressWarnings("unchecked")
	public PA_Data(HashMap<String, String> envData, HashMap<String, String> globalData, HashMap<String, Object> memData, String runDate) throws Exception {	
		Map<String, String> hohData = new HashMap<String, String>();
		
		appDate = runDate;
		
		hohData = (Map<String, String>) memData.get("0");		
		portal = hohData.get("portal");
		
		List<String> listNames = PortalName.getCodes();
		
		if(!listNames.contains(portal)){
			throw new Exception("Portal Name is not correct [" + portal + "] Accepted Value " + listNames);
		}
		
		url = TestData.getURL(portal, envData);
		
		HashMap<String, String> hohOptumId = (HashMap<String, String>) hohData;
		
		optumIdData = TestData.getOptumIdData(portal, hohOptumId, envData, globalData);		
		
		serviceData = getServiceData(envData);
		
		memCount = memData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			memsData.add(new PA_MemData());
		}
		
		paAddPolicyData(memData);
	
		this.printAddPolicyData();
	}

	@SuppressWarnings("unchecked")
	private void paAddPolicyData(HashMap<String, Object> md) throws Exception {
		for(int memIndex = 0; memIndex < memCount; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			memsData.get(memIndex).paSeqInd = memData.get("seqInd");
			memsData.get(memIndex).policyHolderName = memData.get("policyHolderName");
			memsData.get(memIndex).memId = memData.get("memId");
			memsData.get(memIndex).policySource = memData.get("policySource");
			memsData.get(memIndex).policyType = memData.get("policyType");
			memsData.get(memIndex).tierOfCoverage = memData.get("tierOfCoverage");			
			memsData.get(memIndex).coverageType = memData.get("coverageType");
			
			memsData.get(memIndex).basicBenefitLevel = memData.get("basicBenefitLevel").equalsIgnoreCase("TRUE")?true:false;			
			memsData.get(memIndex).enrolledInMH = memData.get("enrolledMh").equalsIgnoreCase("TRUE")?true:false;
			
			memsData.get(memIndex).monthlyCost = memData.get("monthlyCost");
			
			memsData.get(memIndex).empContribution = memData.get("employerContribution");
			memsData.get(memIndex).nextPayDatePriorFromToday = memData.get("nextPayDatePriorFromToday");
			memsData.get(memIndex).healthInsuranceStatus = memData.get("healthInsStatus");
			memsData.get(memIndex).membersCovered = memData.get("membersCovered");
			
			memsData.get(memIndex).cvrgAmntEmpContributionMoreEqual50 = memData.get("cvrgAmntEmpContributionMoreEqual50");
			memsData.get(memIndex).cvrgAmntEmpContributionLess50 = memData.get("cvrgAmntEmpContributionLess50");
			
			memsData.get(memIndex).tplStatus = memData.get("tplStatus");
			memsData.get(memIndex).adminClosureReason = memData.get("adminClosureReason");
			memsData.get(memIndex).paAmount = memData.get("paAmount");			
			memsData.get(memIndex).paymentStatus = memData.get("paymentStatus");
			
			memsData.get(memIndex).ovrAmnt = memData.get("ovrAmnt");
			memsData.get(memIndex).ovrPaymentStatus = memData.get("ovrPaymentStatus");			
			memsData.get(memIndex).ovrEndDtPriorFromToday = memData.get("ovrEndDtPriorFromToday");
		}
	}
	
	public ServiceData getServiceData(HashMap<String, String> ed) {
		ServiceData service = new ServiceData();
		
		service.individualByPassUsps = ed.get("Individual_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		service.agentByPassUsps = ed.get("Agent_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		service.assisterByPassUsps = ed.get("Assister_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		
		return service;
	}
	
	public void printAddPolicyData() throws Exception {
		Class<?> c = this.getClass();
		Field[] field = c.getDeclaredFields();

		for(int fCounter = 0; fCounter < field.length; fCounter++){	    	   
			String fieldName = field[fCounter].getName();
	    	   
			if(fieldName.equals("optumIdData")){
				optumIdData.printOptumIdData();
			}else if(fieldName.equals("memsData")){
				if(memCount == null) continue;
	    		   
				for(int mCounter = 0; mCounter < memCount; mCounter++){
					System.out.println("############### Add Policy Data ###############");
					memsData.get(mCounter).printMemberData();
				}
			}else if(fieldName.equals("serviceData")){
				serviceData.printServiceData();
			}else{
				Object fieldValue = c.getDeclaredField(fieldName).get(this);
	    		   
				if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float){
					if(fieldValue != null){
						System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
					} 
				}
			}
	    }
	}
}