package appdata.pa;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import appdata.common.AddressData;
import enums.DeductionType;
import enums.InsurancePolicySource;

public class PA_MemData {
	
	public String paSeqInd;
	public String policyHolderName;
	public String memId;	
	public String healthInsuranceStatus;
	public String membersCovered;
	public String policySource;
	public String policyType;
	public String tierOfCoverage;
	
	public String coverageType;
	
	public Boolean basicBenefitLevel;
	public Boolean enrolledInMH;
	
	public String monthlyCost;
	
	public String empContribution;
	public String nextPayDatePriorFromToday;
	
	public String cvrgAmntEmpContributionMoreEqual50;
	public String cvrgAmntEmpContributionLess50;
	
	public String tplStatus;
	public String adminClosureReason;
	public String paAmount;
	public String paymentStatus;
	
	public String ovrAmnt;
	public String ovrPaymentStatus;
	public String ovrEndDtPriorFromToday;
	
	public void printMemberData() throws Exception {	
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

	    for (Integer fCounter = 0; fCounter < field.length; fCounter++){    	   
    	   String fieldName = field[fCounter].getName();
    	   
    	   Object fieldValue = c.getDeclaredField(fieldName).get(this);
    		   
   		   if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float || fieldValue instanceof List ){
    		   if(fieldValue != null ){
    			   System.out.println(fieldName + ": [" + c.getDeclaredField(fieldName).get(this) + "]");  
    		   } 
   		   }
    	}
	}		
}
