package appdata.adminClosure;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import appdata.common.OptumIdData;
import db.DualTable;
import db.ElgMemberTable;
import enums.AdminClosureReason;
import enums.AidCat;
import enums.PortalName;
import enums.ProgEligibility;
import utils.DateUtil;
import utils.TestData;

public class AdminClosure_Data {
	
	public String portal;
	public String url;
	public OptumIdData optumIdData = new OptumIdData();
	public String currentDate;						// From DB
	
	public String userProfileRefId;
	public Integer memCount;
	public String comment;
	public List<AdminClosure_MemData> memsData = new ArrayList<AdminClosure_MemData>();
	
	public AdminClosure_Data(Connection conn, 
			HashMap<String,String> ed, 
			HashMap<String,String> gd, 
			HashMap<String,String> td, 
			String featureFileName,
			String testCaseId) throws Exception{
		
		currentDate = new DualTable(conn,"").getSysDate();
		currentDate = DateUtil.getDateInUIFormatUsingPattern(currentDate, DateUtil.dbDatePattern);

		portal = PortalName.AGENT.code;
		url = TestData.getURL(portal, ed);
		
		optumIdData = TestData.getOptumIdCredentialForAgent(ed);
		
		String userProfileRefId = TestData.getTempTestData("UserProfileRefId", featureFileName);
		ElgMemberTable elg_MemberTable = new ElgMemberTable(conn, testCaseId);
		memCount = elg_MemberTable.getMemberCountUsingUserProfileRefId(userProfileRefId);
		
		for(int mCounter=0; mCounter < memCount ; mCounter++){
			memsData.add(new AdminClosure_MemData());
		}
		
		
		getMemberData("Ms_AdminClosingReasons", td.get("Ms_AdminClosingReasons"));
		getMemberData("Ms_Admin_Closing_Effective_Date_Prior_From_Today_InDays", td.get("Ms_Admin_Closing_Effective_Date_Prior_From_Today_InDays"));
		getMemberData("Ms_Admin_Closing_Removal_Date_Prior_From_Today_InDays", td.get("Ms_Admin_Closing_Removal_Date_Prior_From_Today_InDays"));
		comment = td.get("Comments");
		getMemberData("Ms_AfterAdminClosing_AidCat", td.get("Ms_AfterAdminClosing_AidCat"));
		getMemberData("Ms_AfterAdminClosure_ProgramEligibility", td.get("Ms_AfterAdminClosure_ProgramEligibility"));
		
		printAdminCLosureData();
		
	}
	
	private void getMemberData(String fieldName, String fieldValue) throws Exception {
		if(fieldValue.equals("")) return;
		String arrFieldValue[] =fieldValue.trim().toUpperCase().split("_");

		for(int mCounter=0; mCounter <memCount; mCounter++){
			for(int i=0; i<arrFieldValue.length; i++){
				if(arrFieldValue[i].contains("M"+(mCounter+1)+":")){
					String fieldValueForMember = arrFieldValue[i].replace("M"+(mCounter+1)+":", "");
					switch(fieldName){
					case "Ms_AdminClosingReasons":
						List<String> listAdminclosingCode = AdminClosureReason.getCodes();
											
						if( ! listAdminclosingCode.contains(fieldValueForMember)  ){
							throw new Exception("Ms_AdminClosingReasons"+(mCounter+1)+" is not correct [" + fieldValueForMember + "] Accepted Value " +listAdminclosingCode );
						}
						memsData.get(mCounter).closureReason=AdminClosureReason.getDropDownValue(fieldValueForMember);
						break;
							
					case "Ms_Admin_Closing_Effective_Date_Prior_From_Today_InDays":
						int intAdminClosingEffectiveDatePriorFromTodayInDays =  Integer.parseInt(fieldValueForMember);
						memsData.get(mCounter).closureEffectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+intAdminClosingEffectiveDatePriorFromTodayInDays);
						break;
						
					case "Ms_Admin_Closing_Removal_Date_Prior_From_Today_InDays":
						int intAdminClosingRemovalDatePriorFromTodayInDays =  Integer.parseInt(fieldValueForMember);
						memsData.get(mCounter).closureRemovalDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:"+intAdminClosingRemovalDatePriorFromTodayInDays);
						break;
								
					case "Ms_AfterAdminClosing_AidCat":
						List<String> listAidCat = AidCat.getCodes();
						
						if( ! listAidCat.contains(fieldValueForMember)  ){
							throw new Exception("Aid Cat For Member"+(mCounter+1)+" is not correct [" + fieldValueForMember + "] Accepted Value " +listAidCat );
						}
						memsData.get(mCounter).afterAdminClosureAidCat=fieldValueForMember;
						break;
					
					case "Ms_AfterAdminClosure_ProgramEligibility":
						List<String> listProgEligibility = ProgEligibility.getCodes();
						
						if( ! listProgEligibility.contains(fieldValueForMember)  ){
							throw new Exception("Program Eligibility For Member"+(mCounter+1)+" is not correct [" + fieldValueForMember + "] Accepted Value " +listProgEligibility );
						}
						memsData.get(mCounter).afterAdminClosurePE=ProgEligibility.get_UI_Val(fieldValueForMember);
						break;
						
					}
					break;
				}
			}
			
		}
	}
	
	public void printAdminCLosureData() throws Exception{	
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

       for (Integer fCounter =0; fCounter < field.length; fCounter++){
    	   
    	   String fieldName = field[fCounter].getName();
    	   
    	   if(fieldName.equals("optumIdData")){
    		   optumIdData.printOptumIdData();
    	   }else if(fieldName.equals("memsData")){
    		   int memCount = memsData.size();
    		   for (int mCounter=0; mCounter < memCount; mCounter++) {
    			   System.out.println("############   Admin Closure  Data for Member [" + (mCounter +1) + "]############");
    			   memsData.get(mCounter).printAdminClosureMemData();
    		   }
    	   }else{
    		   Object fieldValue = c.getDeclaredField(fieldName).get(this);
    		   if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float ){
    			   if(fieldValue != null ){
	    			   System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
	    		   } 
    		   }
    	   }
    	}
	}
		
}
