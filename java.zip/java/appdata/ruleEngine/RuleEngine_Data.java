package appdata.ruleEngine;

import java.lang.reflect.Field;
import java.util.List;

public class RuleEngine_Data {
	
	public String Type;
	
	public String FirstName;
	public String LastName;
	
	public boolean Deceased;
	public boolean Incarcerated;
	public boolean AwaitingTrial;
	public boolean ApplyingStatus;
	public boolean LivesInMA;
	public boolean IntendToResideMA;
	
	public int Age;
	
	public double FPL;
	public double MFPL;
	public double TFPL;
	
	public String ImmigrationStatus;
	
	public boolean MedicareViaSelfAttestation;
	public boolean MedicareViaHUB;
	public boolean Disabled;
	public boolean HIV;
	public boolean BCC;
	public boolean Pregnant;
	public boolean Parent;
	public boolean MedicallyFrail;
	public boolean FormerFosterCare;
	public boolean ESI;
	public boolean PeaceCorps;
	public boolean VeteransAffairs;
	public boolean Tricare;
	public boolean Other;
	public boolean TMA;
	public boolean MMISReturns35;
	public boolean MMISReturns02with3;
	public boolean HsnWithin90Days;
	public boolean FilingTaxes;
	public boolean TaxHhMember;
	public boolean FinancialAssistance;
	public boolean IntendToReside;
	
	public String TPLStatus;
	
	public boolean MeetsBasicBenefit;
	public boolean EnrolledPerMHRequest;
	
	public String InsuranceCoverage;
	
	public void printMemberData() throws Exception {	
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

	    for (Integer fCounter = 0; fCounter < field.length; fCounter++){    	   
    	   String fieldName = field[fCounter].getName();

    	   Object fieldValue = c.getDeclaredField(fieldName).get(this);
    		   
    	   if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float || fieldValue instanceof List ){
    		   if(fieldValue != null ){
    			   System.out.println(fieldName + ": [" + c.getDeclaredField(fieldName).get(this) + "]");  
    		   } 
    	   }
    	}
	}		
}
