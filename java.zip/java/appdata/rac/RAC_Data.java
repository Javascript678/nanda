package appdata.rac;

import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import appdata.common.OptumIdData;
import appdata.common.SqlCredentials;
import appdata.evpd.CreateProfileData;
import appdata.evpd.EVPD_MemData;
import appdata.evpd.PBFG_Data;
import appdata.evpd.ResponsiblePartyData;
import appdata.evpd.ServiceData;
import appdata.evpd.TaxHH_Data;
import enums.AidCat;
import enums.AppTypeName;
import enums.IncomeFrequency;
import enums.GenderType;
import enums.IncomeType;
import enums.DeductionType;
import enums.InsuranceFrequency;
import enums.InsurancePolicySource;
import enums.Language;
import enums.PortalName;
import enums.Relationship;
import enums.TrueFalseValue;
import enums.WhoIsApplying;

import utils.DateUtil;
import utils.HttpsClient;
import utils.RandomGenerator;
import utils.TestData;

public class RAC_Data {
	
	public String appDate;
	public String portal;
	public String url;
	
	public OptumIdData optumIdData = new OptumIdData();
	
	public Boolean someOneHelping;
	public String whoIsApplying;
	public Boolean faReqd;
	public Boolean atleastOneMemberAbove18;
	public Integer count = 0;
	public String userProfileRefId = null;
	public String eligibilityId = null;
	
	public CreateProfileData createProfileData = new CreateProfileData();
	public List<RAC_MemData> memsData = new ArrayList<RAC_MemData>();
	public ResponsiblePartyData rpData = new ResponsiblePartyData();
	public TaxHH_Data taxHhData = new TaxHH_Data();
	public Integer pbfgGroupCount;
	public List<PBFG_Data> pbfgData = new ArrayList<PBFG_Data>();
	
	public ServiceData serviceData = new ServiceData();
	
	@SuppressWarnings("unchecked")
	public RAC_Data(HashMap<String, String> envData, HashMap<String, String> globalData, HashMap<String, Object> memData, String runDate) throws Exception {	
		Map<String, String> hohData = new HashMap<String, String>();
		
		appDate = runDate;
	
		hohData = (Map<String, String>) memData.get("0");		
		portal = hohData.get("portal");
		
		List<String> listNames = PortalName.getCodes();
		
		if(!listNames.contains(portal)){
			throw new Exception("Portal Name is not correct [" + portal + "] Accepted Value " + listNames);
		}
		
		url = TestData.getURL(portal, envData);
		
		HashMap<String, String> hohOptumId = (HashMap<String, String>) hohData;
		
		optumIdData = TestData.getOptumIdData(portal, hohOptumId, envData, globalData);
		
		serviceData = getServiceData(envData);
		
		count = memData.size();
		
		for(int mCounter = 0; mCounter < count; mCounter++){
			memsData.add(new RAC_MemData());
		}
		
		createProfileData(envData, globalData, (HashMap<String, String>) hohData);
		startAppData(globalData, (HashMap<String, String>) hohData, memData);
		familyHHTellUsAbtHHData(hohData, memData);
		familyHHPersonalInfoData(memData);
		//familyHHImmStatusData(globalData, testData);
		familyHHParentCareTakerEthnicityRaceOtherAddrIntendData(memData, globalData);
		familyHHMoreAbtHHData(memData, globalData);
		familyHHReasonableAccMemsInPrisonData(memData);
		incomeInsuranceData(memData, globalData);
		reviewAndSignData(memData, globalData);
		//getTax_HHData(memData);
		getHHIncomeData(memData);
		getMedicaidHHData(memData);
		getMemData(memData);
		medicaidHH_PBFG_Data(hohData.get("totalPbfgGroup"), hohData.get("pbfgMonthlyPremium"));
		getRacData(memData);
	
		this.printEVPDData();
	}
	
	private void getRacData(HashMap<String, Object> md) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			getMemberData("RAC_Type", memIndex, memData.get("racType"));
		}
	}
	
	private void getMemData(HashMap<String, Object> md) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			getMemberData("Ms_User_REF_ID", memIndex, memData.get("userRefId"));
			getMemberData("Ms_Eligibility_ID", memIndex, memData.get("elgId"));
			getMemberData("App_Creation_Date", memIndex, memData.get("appDate"));
		}
	}
	
	private void getTax_HHData(HashMap<String, Object> md) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
		//	System.out.println("memIndex"+memData.get("msMemIndex"));
		//	System.out.println("memIndex"+memData.get("msTaxHhIndex"));
		//	System.out.println("memIndex"+memData.get("msTaxHhMemIndex"));
		//	System.out.println("memIndex"+memData.get("msTaxHhPe"));
			
			getMemberData("Ms_Mem_Id", memIndex, memData.get("memId"));
			getMemberData("Ms_Tax_HH_Index", memIndex, memData.get("msTaxHhIndex"));
			getMemberData("Ms_Tax_HH_Mem_Index", memIndex, memData.get("msTaxHhMemIndex"));
			getMemberData("Ms_TaxHH1_PE", memIndex, memData.get("msTaxHhPe"));
		}
	}
	
	private void getMedicaidHHData(HashMap<String, Object> md) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			getMemberData("Ms_MAGI_HH_Size", memIndex, memData.get("msMagiHhSize"));
			getMemberData("Ms_Tax_HH_Size", memIndex, memData.get("msTaxHhSize"));
			getMemberData("Ms_MAGI_FPL", memIndex, memData.get("msMagiFpl"));
			getMemberData("Ms_TAX_FPL", memIndex, memData.get("msTaxFpl"));
			getMemberData("Ms_Aid_Cat", memIndex, memData.get("msAidCat"));
		}
	}
	
	private void medicaidHH_PBFG_Data(String pbfgCount, String pbfgMonthlyPremium) throws Exception {
		if(!pbfgCount.isEmpty()){		
			pbfgGroupCount = Integer.parseInt(pbfgCount);
	
			for(int gCounter = 0; gCounter < pbfgGroupCount; gCounter++){
				pbfgData.add(new PBFG_Data());
				
				if(!pbfgMonthlyPremium.isEmpty()){					
					pbfgData.get(gCounter).monthlyPremiumAmt = pbfgMonthlyPremium;
					break;
				}
			}
		}
	}
	
	private void reviewAndSignData(HashMap<String, Object> md, HashMap<String, String> gd) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){			
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			try{
				if(memsData.get(0).isU19){
					rpData.firstName = gd.get("ReposiblePartyFirstName").toUpperCase();
					rpData.lastName = gd.get("ReposiblePartyLastName").toUpperCase();
					rpData.relationship = gd.get("ReposiblePartyRelationShip");
					rpData.age = Integer.parseInt(gd.get("ReposiblePartyAge"));
					rpData.dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, rpData.age+"");
					
					rpData.homeAddr.streetAddress = gd.get("ReposiblePartyStreetAddress1");
					rpData.homeAddr.city = gd.get("ReposiblePartyCity");
					rpData.homeAddr.zipCode = gd.get("ReposiblePartyZIp");
					rpData.homeAddr.county = gd.get("ReposiblePartyCounty");
					rpData.phoneNo = gd.get("ReposiblePartyPhone1");
				}		
				memsData.get(0).applyingForVoteToday = memData.get("hohApplyForVote").equalsIgnoreCase("TRUE")?true:false;
			}catch(NullPointerException npe){
				System.out.println("Warning!" + npe.getMessage());
			}
		}
	}
	
	private void incomeInsuranceData(HashMap<String, Object> md, HashMap<String, String> gd) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			getIncomeTypeAndAmoutForMembers(IncomeType.JOB.val, memIndex, memData.get("msJobIncome"), gd, appDate);
			getIncomeTypeAndAmoutForMembers(IncomeType.SELF_EMPLOYMENT.val, memIndex, memData.get("msSeIncome"), gd, appDate);
			getIncomeTypeAndAmoutForMembers(IncomeType.SOCIAL_SECURITY_BENEFITS.val, memIndex, memData.get("msSsbIncome"), gd, appDate);
			getIncomeTypeAndAmoutForMembers(IncomeType.UNEMPLOYMENT.val, memIndex, memData.get("msUnemploymentIncome"), gd, appDate);
			getIncomeTypeAndAmoutForMembers(IncomeType.RETIREMENT.val, memIndex, memData.get("msRetirementIncome"), gd, appDate);
			getIncomeTypeAndAmoutForMembers(IncomeType.CAPITALGAINS.val, memIndex, memData.get("msCgIncome"), gd, appDate);
			getIncomeTypeAndAmoutForMembers(IncomeType.INVESTMENT_INCOME.val, memIndex, memData.get("msIiIncome"), gd, appDate);
			getIncomeTypeAndAmoutForMembers(IncomeType.RENTAL_OR_ROYALTY_INCOME.val, memIndex, memData.get("msRentalRiIncome"), gd, appDate);
			getIncomeTypeAndAmoutForMembers(IncomeType.FARMING_OR_FISHING_INCOME.val, memIndex, memData.get("msFishingFarmingIncome"), gd, appDate);
			getIncomeTypeAndAmoutForMembers(IncomeType.ALIMONY_RECEIVED.val, memIndex, memData.get("msAlimonyIncome"), gd, appDate);
			getIncomeTypeAndAmoutForMembers(IncomeType.OTHER_INCOME.val, memIndex, memData.get("msOtherIncome"), gd, appDate);
			totalIncomeAmt(memIndex);
			
			getDeductionTypeAndAmoutForMembers(DeductionType.EDUCATOR_EXPENSE.val, memIndex, memData.get("msEducatorDeductionYearly"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.BUSINESS_EXPENSES_RESERVIST_ARTIST.val, memIndex, memData.get("msBusinessExpensesDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.HEALTH_SAVINGS_ACCOUNT_DEDUCTION.val, memIndex, memData.get("msHealthSavingsDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.MOVING_EXPENSES_RELATED_TO_JOB_CHANGE.val, memIndex, memData.get("msJobChangeDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.DEDUCTIBLE_PART_OF_SELF_EMPLOYMENT_TAX.val, memIndex, memData.get("msSelfEmpTaxDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.CONTRIBUTION_TO_SELF_EMPLOYED_SEP.val, memIndex, memData.get("msContributedSelfEmpDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.SELF_EMPLOYED_HEALTH_INSURANCE_DED.val, memIndex, memData.get("msSelfEmpHealthInsDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.PENALTY_ON_EARLY_WITHDRAWAL.val, memIndex, memData.get("msPenaltyWithdrawDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.ALIMONY_PAID.val, memIndex, memData.get("msAlimonyPaidDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.INDIVIDUAL_RETIREMENT_ACCOUNT_DED.val, memIndex, memData.get("msIndRetirementAmtDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.STUDENT_LOAN_INTEREST_PAID.val, memIndex, memData.get("msStudentLoanDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.HIGHER_EDUCATION.val, memIndex, memData.get("msHighSchoolEducationDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.DOMESTIC_PRODUCTION_DED.val, memIndex, memData.get("msDomProdDed"), gd, appDate);
			getDeductionTypeAndAmoutForMembers(DeductionType.OTHER_DEDUCTIONS.val, memIndex, memData.get("msOtherDed"), gd, appDate);
			totalDeductionAmt(memIndex);
			
			getMemberData("Ms_Income_From_JOB_EmployerName", memIndex, memData.get("msEmployerName"));
			getMemberData("Ms_Income_From_JOB_HrPerWeek", memIndex, memData.get("msHrsWeekly"));
			getMemberData("Ms_Job_Sheltered_Attestation", memIndex, memData.get("msShelteredAttestation"));
			getMemberData("Ms_Deduction_Educator_Yearly", memIndex, memData.get("msEducatorDeductionYearly"));
			getMemberData("Ms_ExpectedYearly_Income_IfDiffr", memIndex, memData.get("msAltExpectedYearlyIncome"));			
	
			getHealthInsuranceForMembers(InsurancePolicySource.ESI.code, memIndex, memData.get("msEsi"), memData.get("msCoveredInHohEsi"), memData.get("esiCoverageAffordable"), memData.get("esiPremiumAmount"), gd);
			getHealthInsuranceForMembers(InsurancePolicySource.COBRA.code, memIndex, memData.get("msCobra"), memData.get("msCoveredInHohCobra"), memData.get("cobraMsCoverageAffordable"), memData.get("cobraPremiumAmount"), gd);
			getHealthInsuranceForMembers(InsurancePolicySource.RETIREE_HEALTH_PLAN.code, memIndex, memData.get("msRetireeHp"), memData.get("msCoveredInHohRhp"), memData.get("rhpMsCoverageAffordable"), memData.get("rhpPremiumAmount"), gd);
	
			getOtherHealthInsuranceForMembers(InsurancePolicySource.VA_HEALTH_PROGRAM.code, memIndex, memData.get("msVaHp"), gd);
			getOtherHealthInsuranceForMembers(InsurancePolicySource.MEDICAID.code, memIndex, memData.get("msWithMh"), gd);
			getOtherHealthInsuranceForMembers(InsurancePolicySource.MEDICARE.code, memIndex, memData.get("msWithMedicare"), gd);
			getOtherHealthInsuranceForMembers(InsurancePolicySource.PEACE_CORPS.code, memIndex, memData.get("msWithPeaceCorps"), gd);
			getOtherHealthInsuranceForMembers(InsurancePolicySource.TRICARE.code, memIndex, memData.get("msWithTricare"), gd);
			getOtherHealthInsuranceForMembers(InsurancePolicySource.VA_HEALTH_PROGRAM.code, memIndex, memData.get("msWithVaHp"), gd);
			getOtherHealthInsuranceForMembers(InsurancePolicySource.OTHER.code, memIndex, memData.get("msWithOther"), gd);
			
			getMemberNumber("Ms_With_NCP_RFI", memIndex, memData.get("msWithNcpRfi"));
		}
	}
	
	// added by ppinho
	private void getHHIncomeData(HashMap<String, Object> md) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));

		    int calculatedHHIncome = (totalIncomeAmt(memIndex) - totalDeductionAmt(memIndex));
			String taxIncomeAmount = (memData.get("msTaxHhIncome")); //updated name by bkumar53
			String magiIncomeAmount = (memData.get("msMagiHhIncome")); //added by bkumar53
			
			if(!taxIncomeAmount.isEmpty()){	
				int jobIncomeAmtForMember = Integer.parseInt(taxIncomeAmount);
				if(jobIncomeAmtForMember == calculatedHHIncome)
				memsData.get(memIndex).hhIncomeAmount = jobIncomeAmtForMember;
				else 
					memsData.get(memIndex).hhIncomeAmount = calculatedHHIncome;
			}	
			//added by bkumar53
			if(!magiIncomeAmount.isEmpty()){		
				int jobMagiIncomeAmtForMember = Integer.parseInt(magiIncomeAmount);
				if(jobMagiIncomeAmtForMember == calculatedHHIncome)
				memsData.get(memIndex).magiHhIncomeAmount = jobMagiIncomeAmtForMember;
				else
					memsData.get(memIndex).magiHhIncomeAmount = calculatedHHIncome;
			}
		}
	}
	
	private void familyHHReasonableAccMemsInPrisonData(HashMap<String, Object> md) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			TestData.getRacReasonableAccomForMembers(memData.get("msReasonableAcc"), memsData);
			
			memsData.get(memIndex).resonableAccNeeded = memsData.get(memIndex).resonableAccType.equals("")?false:true;
			
			if(memData.get("msPrison").equals("")){
				memsData.get(memIndex).isInPrison = false;
			}else{
				memsData.get(memIndex).isInPrison = memData.get("msPrison").equalsIgnoreCase("TRUE")?true:false;
					
				if(memData.get("msAwaitingTrial").equals("")){
					memsData.get(memIndex).awaitingTrial = false;
				}else{
					memsData.get(memIndex).awaitingTrial = memData.get("msAwaitingTrial").equalsIgnoreCase("TRUE")?true:false;
				}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private void familyHHMoreAbtHHData(HashMap<String, Object> md, HashMap<String, String> gd) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			if(memData.get("msDisabled").equals("")){
				memsData.get(memIndex).isDisabled = false;
			}else{
				memsData.get(memIndex).isDisabled = memData.get("msDisabled").equalsIgnoreCase("TRUE")?true:false;
			}
				
			if(memData.get("msAian").equals("")){
				memsData.get(memIndex).isAIAN = false;
			}else{
				memsData.get(memIndex).isAIAN = memData.get("msAian").equalsIgnoreCase("TRUE")?true:false;
					
				if(memsData.get(memIndex).isAIAN){
					memsData.get(memIndex).indoAmericanState = gd.get("MemberIndoAmericanState");
					memsData.get(memIndex).indoAmericanTribe = gd.get("MemberIndoAmericanTribe");
				}
			}
				
			if(memData.get("msPregnant").equals("")){
				memsData.get(memIndex).isPregnant = false;
			}else{
				memsData.get(memIndex).isPregnant = memData.get("msPregnant").equalsIgnoreCase("TRUE")?true:false;
					
				if(memsData.get(memIndex).isPregnant){
					String babyCount = memData.get("pregnantBabyCount");
						
					if(babyCount.equals("")){
						memsData.get(memIndex).prgBabyCount = 1;
					}else{
						memsData.get(memIndex).prgBabyCount = Integer.parseInt(babyCount);
					}
						
					String babyDueDatePriorFromToday = gd.get("PregnantMember_BabyDueDatePriorFromToday");
					memsData.get(memIndex).babyDueDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:" + babyDueDatePriorFromToday);
				}
			}
				
			if(memData.get("msFosterCare").equals("")){
				memsData.get(memIndex).fosterCare = false;
			}else{
				memsData.get(memIndex).fosterCare = memData.get("msFosterCare").equalsIgnoreCase("TRUE")?true:false;
				
				if(memsData.get(memIndex).fosterCare){
					memsData.get(memIndex).fosterCareState = gd.get("MemberFosterCareState");
					memsData.get(memIndex).fosterCareLeftAge = Integer.parseInt(gd.get("MemberFosterCareLeftAge"));
				}
			}
			
			if(memData.get("msBcc").equals("")){
				memsData.get(memIndex).brestCancer = false;
			}else{
				memsData.get(memIndex).brestCancer = memData.get("msBcc").equalsIgnoreCase("TRUE")?true:false;
			}
			
			if(memData.get("msHiv").equals("")){
				memsData.get(memIndex).hivPositive = false;
			}else{
				memsData.get(memIndex).hivPositive = memData.get("msHiv").equalsIgnoreCase("TRUE")?true:false;
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private void familyHHParentCareTakerEthnicityRaceOtherAddrIntendData(HashMap<String, Object> md, HashMap<String, String> gd) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			if(memsData.get(memIndex).claimAnyDependent == null){
				memsData.get(memIndex).claimAnyDependent = false;
				memsData.get(memIndex).claimAnyDependentU19Member = false;
			}else{
				memsData.get(memIndex).dependentU19MembersByIndex = TestData.getRacU19MemberByIndex(memsData.get(memIndex).dependentMembersByIndex, memsData);
				memsData.get(memIndex).claimAnyDependentU19Member = memsData.get(memIndex).dependentU19MembersByIndex.equals("")?false:true;
			}
			
			TestData.getRacEthnicityForMembers(memData.get("msEthnicity"), memsData);
			TestData.getRacRaceForMembers(memData.get("msRace"), memsData);
			
			//if(memIndex != 0 && !memsData.get(memIndex).livingWithM1){
			if(memIndex != 0 && !memsData.get(memIndex).livingWith.get(0)){
				memsData.get(memIndex).homeAddr.streetAddress = gd.get("MemberNotLivingWithHOH_StreetAddress");
				memsData.get(memIndex).homeAddr.city = gd.get("MemberNotLivingWithHOH_City");
				memsData.get(memIndex).homeAddr.zipCode = gd.get("MemberNotLivingWithHOH_Zip");
				memsData.get(memIndex).homeAddr.county = gd.get("MemberNotLivingWithHOH_County");
				memsData.get(memIndex).ousideMAZipCode = gd.get("MemberNotLivingWithHOH_OutsideMA_Zip");
				memsData.get(memIndex).ousideMAZipCounty = gd.get("MemberNotLivingWithHOH_OutsideMA_County");
			}
			
			memsData.get(memIndex).tempLivingOutsideMA = Boolean.parseBoolean(memData.get("msTempOutsideMA"));
			
			if(memData.get("msIntendResideMa").equals("")){
				memsData.get(memIndex).intendToResideMA = true;
			}else{
				memsData.get(memIndex).intendToResideMA = memData.get("msIntendResideMa").equalsIgnoreCase("TRUE")?true:false;
			}
		}
	}

	private void familyHHImmStatusData(int memIndex, HashMap<String, String> gd, HashMap<String, String> md) throws Exception {
		TestData.getRacImmingrationForMembers(memIndex, md.get("msImmStatus"), memsData);
		
		try{
			switch(memsData.get(memIndex).immStatus){
				case "CIT":
					memsData.get(memIndex).isUSCitizen = true;
					memsData.get(memIndex).isNaturalCitizen = false;
					break;
					
				case "CITN":
					memsData.get(memIndex).isUSCitizen = true;
					memsData.get(memIndex).isNaturalCitizen = true;
					break;
					
				case "UND":
					memsData.get(memIndex).isUSCitizen = false;
					memsData.get(memIndex).isVeteran = false;
					break;
					
				case "QLP":
					memsData.get(memIndex).isUSCitizen = false;
					memsData.get(memIndex).alienNumber = gd.get("AlientNumber");
					memsData.get(memIndex).alientNameSameAsAppear = true;
					memsData.get(memIndex).arrivedInUSAfter1996 = true;
					memsData.get(memIndex).immStatusvlpErrorIndex = Integer.parseInt(gd.get("AmerisianIndex"));
					break;
					
				case "NQP":
					memsData.get(memIndex).isUSCitizen = false;
					memsData.get(memIndex).alienNumber = gd.get("AlientNumber");
					memsData.get(memIndex).alientNameSameAsAppear = true;
					memsData.get(memIndex).arrivedInUSAfter1996 = true;
					memsData.get(memIndex).immStatusvlpErrorIndex = Integer.parseInt(gd.get("DACAIndex"));
					break;
					
				case "ILP":
					memsData.get(memIndex).isUSCitizen = false;
					memsData.get(memIndex).alienNumber = gd.get("AlientNumber");
					memsData.get(memIndex).alientNameSameAsAppear = true;
					memsData.get(memIndex).arrivedInUSAfter1996 = true;
					memsData.get(memIndex).immStatusvlpErrorIndex = Integer.parseInt(gd.get("ViasIndex"));
					break;
					
				case "QAB":
					memsData.get(memIndex).isUSCitizen = false;
					memsData.get(memIndex).alienNumber = gd.get("AlientNumber");
					memsData.get(memIndex).alientNameSameAsAppear = true;
					memsData.get(memIndex).arrivedInUSAfter1996 = true;
					memsData.get(memIndex).immStatusvlpErrorIndex = Integer.parseInt(gd.get("LawPermanentResIndex"));
					memsData.get(memIndex).immStatusAwardDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern,  "00:00:30");
					break;
					
			}
		}catch(NullPointerException npe){
			System.out.println("Warning!" + npe.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	private void familyHHPersonalInfoData(HashMap<String, Object> md) throws Exception {
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			String maleMems = memData.get("msGender");
			
			memsData.get(memIndex).gender = maleMems.equalsIgnoreCase("M")?GenderType.MALE.code:GenderType.FEMALE.code;
				
			String ssnFormat = memData.get("msSsn");
			String[] ssnStatus = RandomGenerator.getRunTimeSSN(ssnFormat);
				
			memsData.get(memIndex).hasSSN = ssnStatus[0].equalsIgnoreCase("TRUE")?true:false;
				
			if(memsData.get(memIndex).hasSSN){
				memsData.get(memIndex).ssn = ssnStatus[1];
				memsData.get(memIndex).nameSameAsOnSSN = true;
				memsData.get(memIndex).wantToProvideSSN = true;
			}else{
				memsData.get(memIndex).noSSNReason = ssnStatus[2];
			}
		}
	}
	
	private void getHhCompData(Map<String, String> memData, int memIndex) throws Exception {
		memsData.get(memIndex).isTaxHHMember = true;				
		memsData.get(memIndex).filingTaxes = memData.get("taxHhApplying").equalsIgnoreCase("TRUE")?true:false;
		memsData.get(memIndex).married = memData.get("taxHhMarried").equalsIgnoreCase("TRUE")?true:false;
			
		if(memsData.get(memIndex).married){
			if(memsData.get(memIndex).filingTaxes){
				memsData.get(memIndex).jointTaxFiling = memData.get("taxHhFilingJointly").equalsIgnoreCase("TRUE")?true:false;
			}
			
			memsData.get(memIndex).spouseByIndex = TestData.getMembersByIndex(memData.get("taxHhSpouse"));						
			TestData.racIsMemberLivingWithSpouse(memIndex, Integer.parseInt(memsData.get(memIndex).spouseByIndex), memsData);
		}else{
			memsData.get(memIndex).liveWithSpouse = false;
		}
			
		memsData.get(memIndex).dependentMembersByIndex = TestData.getMembersByIndex(memData.get("taxHhDep"));
		memsData.get(memIndex).claimAnyDependent = memsData.get(memIndex).dependentMembersByIndex.trim().equals("")?false:true;
		memsData.get(memIndex).claimedAsDependentOnSomeOneElse = false;				

		String dependentMember = memsData.get(memIndex).dependentMembersByIndex;
			
		if(memsData.get(memIndex).married == true){  // && memsData.get(memIndex).jointTaxFiling){
			dependentMember += "," + memsData.get(memIndex).spouseByIndex;
		}
		
		for(int m2Counter = 0; m2Counter < count; m2Counter++){
			if(memIndex == m2Counter) continue;
			
			if(dependentMember.contains(Integer.toString(m2Counter))){
				memsData.get(m2Counter).isTaxHHMember = true;						
			}else if(memsData.get(memIndex).isTaxHHMember == null){
				memsData.get(m2Counter).isTaxHHMember = false;
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void familyHHTellUsAbtHHData(Map<String, String> hoh, HashMap<String, Object> md) throws Exception {
		TestData.racMembersNotLivingWithHoH(count, hoh.get("notLivingWithHoh"), memsData);
		
		getTax_HHData(md); // moved to here to load tax HH information being used below
		
		for(int mCounter = 0; mCounter < count; mCounter++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(mCounter));
			
		//	if(memsData.get(mCounter).isTaxHHMember != null)  continue;
			
			if(memsData.get(mCounter).taxHHMemIndex != null){
				getHhCompData(memData, mCounter);
			}
		}
		
		for(int mCounter = 0; mCounter < count; mCounter++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(mCounter));
			
			try{
				if(!memsData.get(mCounter).isTaxHHMember){
					getHhCompData(memData, mCounter);
				}else if(memsData.get(mCounter).isTaxHHMember == null){
					throw new Exception("Member[" + (mCounter + 1) + "] Tell Us Abt  HH Information not available");
				}
			}catch(NullPointerException npe){
				System.out.println("Warning!" + npe.getMessage());
			}
		}
		
		for(int memIndex = 0; memIndex < count; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			String memberRelation = memData.get("msRelation");
			
			int parentCount = 0;
			
			System.out.println(memberRelation);
			
			if(!memberRelation.isEmpty()){
				for(int mCounter = 0; mCounter < count; mCounter++){
					if(memIndex == mCounter) continue;
											
			 		String rel = TestData.getRelationship(memberRelation, memIndex, mCounter);
			 		
			 		if(rel.equals(Relationship.OTHER_UNRELATED.dropDownVal)){
			 			memsData.get(memIndex).relation.add(rel);
			 			memsData.get(memIndex).secondaryRelation.add(TestData.getSecRelationship(memberRelation, memIndex, mCounter));
			 		}else{
				 		memsData.get(memIndex).relation.add(rel);
				 		memsData.get(memIndex).secondaryRelation.add("");
			 		}
					
					/*if(rel.equals(Relationship.CHILD.dropDownVal)){
						memsData.get(memIndex).isParent = true;
					}*/
					
					if(rel.equals(Relationship.PARENT.dropDownVal)){
						parentCount++;
					}
				}
			}else{
				System.out.println("Warning!");
			}
			
			memsData.get(memIndex).parentCount = parentCount;
		}
	}

	@SuppressWarnings("unchecked")
	private void startAppData(HashMap<String, String> gd, HashMap<String, String> hoh, HashMap<String, Object> md) throws Exception {
		familyHHImmStatusData(0, gd, hoh);
		
		memsData.get(0).isHOH = true;
		
		memsData.get(0).firstName = RandomGenerator.getRunTimeName("MEM", hoh.get("msFn")).toUpperCase();
		memsData.get(0).middleName = RandomGenerator.getRunTimeName("", hoh.get("msMn")).toUpperCase();
		memsData.get(0).lastName = RandomGenerator.getRacRunTimeImmStatusName(0, memsData, hoh).toUpperCase();		
		
		if(!memsData.get(0).middleName.isEmpty()){
			memsData.get(0).fullName = memsData.get(0).firstName + " " + memsData.get(0).middleName + " " + memsData.get(0).lastName;
		}else{
			memsData.get(0).fullName = memsData.get(0).firstName + " " + memsData.get(0).lastName;
		}
		
		int ageInYear;
		
		try{
			if(!memsData.get(0).age.isEmpty() || memsData.get(0).age != null){
				memsData.get(0).age = hoh.get("msAge");
				
				if(memsData.get(0).age.contentEquals("0")){
					String ageMem = RandomGenerator.getRandomNumber(25);
					ageMem = "00:00:" + ageMem;
					
					memsData.get(0).dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, ageMem);
				}else{
					memsData.get(0).dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, memsData.get(0).age);
				}
			}
		
			ageInYear = Integer.parseInt(memsData.get(0).age.split(":")[0]);
			
			memsData.get(0).isU10 = ageInYear < 10 ? true:false;
			memsData.get(0).isU18 = ageInYear < 18 ? true:false;
			memsData.get(0).isU19 = ageInYear < 19 ? true:false;
			memsData.get(0).isU21 = ageInYear < 21 ? true:false;
			
			atleastOneMemberAbove18 = false;
		
			if(ageInYear >= 18){
				atleastOneMemberAbove18 = true;
			}		
		}catch(NullPointerException npe){
			System.out.println("Warning!" + npe.getMessage());
		}
		
		memsData.get(0).emailId = gd.get("Member1_EmailAddress");
		memsData.get(0).noHomeAddressReqd = gd.get("AccountHolder_NoHomeAddressReqd").equalsIgnoreCase("Y")?true:false;
		
		if(memsData.get(0).noHomeAddressReqd == false){
			memsData.get(0).homeAddr.streetAddress = gd.get("Member1_H_StreetAddress");
			memsData.get(0).homeAddr.aptUnit = gd.get("Member1_H_Apt_Unit");
			memsData.get(0).homeAddr.city = gd.get("Member1_H_City");
			memsData.get(0).homeAddr.zipCode = gd.get("Member1_H_ZIP_Code");
			memsData.get(0).homeAddr.county = gd.get("Member1_H_County");
		}
		
		if(hoh.get("msLivesInMa").equalsIgnoreCase("")){
			memsData.get(0).livesInMA = true;
		}
		else{
			memsData.get(0).livesInMA = hoh.get("msLivesInMa").equalsIgnoreCase("TRUE")?true:false;
		}
		
		memsData.get(0).liveTemporaryOutsideMA = hoh.get("msTempOutsideMa").equalsIgnoreCase("TRUE")?true:false;
		memsData.get(0).homeAddr.zipCodeTemp = gd.get("Member1_H_ZIP_Code_TEMP");
		memsData.get(0).homeAddr.countyTemp = gd.get("Member1_H_County_TEMP");
		memsData.get(0).mailingAddressSameAsHomeAddress = gd.get("AccountHolder_MailingAddressSameAsHA").equalsIgnoreCase("Y")?true:false;
		
		if(memsData.get(0).mailingAddressSameAsHomeAddress == false){
			memsData.get(0).mailAddr.streetAddress = gd.get("Member1_M_StreetAddress");
			memsData.get(0).mailAddr.aptUnit = gd.get("Member1_M_Apt_Unit");
			memsData.get(0).mailAddr.city = gd.get("Member1_M_City");
			memsData.get(0).mailAddr.zipCode = gd.get("Member1_M_ZIP_Code");
			memsData.get(0).mailAddr.county = gd.get("Member1_M_County");
		}
		
		memsData.get(0).phoneNo = gd.get("Member1_PhoneNo");
		memsData.get(0).secondaryPhoneNo = gd.get("Member1_Secondary_PhoneNo");
		memsData.get(0).spokenLang = hoh.get("spokenLang");
		memsData.get(0).writtenLang = hoh.get("writtenLang");
		
		List<String> listNames = Language.getNames();
		
		someOneHelping = gd.get("Some_One_Helping").equalsIgnoreCase("Y")?true:false;
		whoIsApplying = hoh.get("whoIsApplying");
		
		listNames = WhoIsApplying.getCodes();
		
		faReqd = hoh.get("faReqd").equalsIgnoreCase("TRUE")?true:false;
		
		if(whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)){
			count = count + 1;
			memsData.add(new RAC_MemData());
		}
		
		for(int mCounter = 1; mCounter < count; mCounter++){
			HashMap<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(mCounter));
			familyHHImmStatusData(mCounter, gd, memData);
						
			memsData.get(mCounter).firstName = RandomGenerator.getRunTimeName("MEM", memData.get("msFn")).toUpperCase();
			memsData.get(mCounter).lastName = RandomGenerator.getRacRunTimeImmStatusName(mCounter, memsData, memData).toUpperCase();
			
			memsData.get(mCounter).fullName = memsData.get(mCounter).firstName + " " + memsData.get(mCounter).lastName;
						
			memsData.get(mCounter).age = memData.get("msAge");
			memsData.get(mCounter).applyingForCov = memData.get("msApplyingForCov").equalsIgnoreCase("TRUE")?true:false;
			
			try{
				if(!memsData.get(0).age.isEmpty() || memsData.get(0).age != null){
					memsData.get(mCounter).dob = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, memsData.get(mCounter).age);
					
					ageInYear = Integer.parseInt(memsData.get(mCounter).age.split(":")[0]);
					
					memsData.get(mCounter).isU10 = ageInYear < 10 ? true:false;
					memsData.get(mCounter).isU18 = ageInYear < 18 ? true:false;
					memsData.get(mCounter).isU19 = ageInYear < 19 ? true:false;
					memsData.get(mCounter).isU21 = ageInYear < 21 ? true:false;
					
					if(ageInYear >= 18){
						atleastOneMemberAbove18 = true;
					}
				}
			}catch(NullPointerException npe){
				System.out.println("Warning!" + npe.getMessage());
			}
			
			if(memData.get("msLivesInMa").equalsIgnoreCase("")){
				memsData.get(mCounter).livesInMA = true;
			}else{
				memsData.get(mCounter).livesInMA = memData.get("msLivesInMa").equalsIgnoreCase("TRUE")?true:false;
			}
		}
	}

	private void createProfileData(HashMap<String, String> ed, HashMap<String, String> gd, HashMap<String, String> hoh) throws Exception {
		if(portal.equalsIgnoreCase(PortalName.AGENT.code)){
			createProfileData.firstName = gd.get("OptumId_FirstName").toUpperCase();
			createProfileData.lastName = gd.get("OptumId_LastName").toUpperCase();
			createProfileData.emailAddress = RandomGenerator.getRunTimeOptumId() + "@getnada.com";
		}
		
		createProfileData.middleName = gd.get("OptumId_MiddleName");
		
		createProfileData.dob = gd.get("Profile_DOB");
		createProfileData.ssn = gd.get("Profile_SSN_NO");
		
		createProfileData.noHomeAddressReqd = gd.get("Profile_NoHomeAddressReqd").equalsIgnoreCase("Y")?true:false;
		
		if(!createProfileData.noHomeAddressReqd){
			createProfileData.homeAddr.streetAddress = gd.get("Profile_H_StreetAddress");
			createProfileData.homeAddr.aptUnit = gd.get("Profile_H_Apt_Unit");
			createProfileData.homeAddr.city = gd.get("Profile_H_City");
			createProfileData.homeAddr.zipCode = gd.get("Profile_H_ZIP_Code");
			createProfileData.homeAddr.county = gd.get("Profile_H_County");
		}

		createProfileData.mailingAddressSameAsHomeAddress = gd.get("Profile_MailingAddressSameAsHomeAddress").equalsIgnoreCase("Y")?true:false;
		
		if(!createProfileData.mailingAddressSameAsHomeAddress){
			createProfileData.mailAddr.streetAddress = gd.get("Profile_M_StreetAddress");
			createProfileData.mailAddr.aptUnit = gd.get("Profile_M_Apt_Unit");
			createProfileData.mailAddr.city = gd.get("Profile_M_City");
			createProfileData.mailAddr.zipCode = gd.get("Profile_M_ZIP_Code");
			createProfileData.mailAddr.county = gd.get("Profile_M_County");
		}
		
		createProfileData.phoneNo = gd.get("Profile_PhoneNo");
		createProfileData.secondaryPhoneNo = gd.get("Profile_Secondary_PhoneNo");
		createProfileData.spokenLang = gd.get("Profile_Preferred_SpokenLanguage");
		createProfileData.writtenLang = gd.get("Profile_Preferred_WrittenLanguage");
		
		if(portal.equals(PortalName.AGENT.code)){
			createProfileData.appType = hoh.get("appType");
			List<String> listNames = AppTypeName.getNames();
			
			if(!listNames.contains(createProfileData.appType)){
				throw new Exception("AppType Name is not correct [" + createProfileData.appType + "] Accepted Value " + listNames);
			}
			
			if(createProfileData.appType.equals(AppTypeName.DEFAULT.val)){
				createProfileData.appType = AppTypeName.OTHER.val;
			}
			
			if(createProfileData.appType.equalsIgnoreCase(AppTypeName.PAPER.val)){
				int paperAppReceiveDatePriorFromToday = Integer.parseInt(gd.get("PaperAppReceiveDatePriorFromToday"));
				createProfileData.appReceiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:" + paperAppReceiveDatePriorFromToday);
			}
		}
		
		if(portal.equalsIgnoreCase(PortalName.INDIVIDUAL.code) || portal.equalsIgnoreCase(PortalName.ASSISTER.code)){
				createProfileData.idProofingAns1Index = Integer.parseInt(gd.get("Profile_IdProof_Answer1_Index"));
				createProfileData.idProofingAns2Index = Integer.parseInt(gd.get("Profile_IdProof_Answer2_Index"));
				createProfileData.idProofingAns3Index = Integer.parseInt(gd.get("Profile_IdProof_Answer3_Index"));
				createProfileData.idProofingAns4Index = Integer.parseInt(gd.get("Profile_IdProof_Answer4_Index"));
				createProfileData.idProofingAns5Index = Integer.parseInt(gd.get("Profile_IdProof_Answer5_Index"));
		}		
		createProfileData.profileAccHolder = gd.get("IsProfileAccHolder").equalsIgnoreCase("Y")?true:false;
	}

	@SuppressWarnings("unused")
	private void getMemberData(String fieldName, int memIndex, String fieldValue) throws Exception {
		if(!fieldValue.isEmpty()){
			switch(fieldName){
				case "Ms_TaxHH1_PE":
					taxHhData.memsData.get(memIndex).programEligibility = fieldValue;
					break;
								
				case "Ms_Mem_Id":
					memsData.get(memIndex).memId = fieldValue;
					break;
					
				case "Ms_Tax_HH_Index":
					int taxHHIndexForMember = Integer.parseInt(fieldValue);
					memsData.get(memIndex).taxHHIndex = taxHHIndexForMember;
					break;
					
				case "Ms_Tax_HH_Mem_Index":
					int taxHHMemIndexForMember = Integer.parseInt(fieldValue);
					memsData.get(memIndex).taxHHMemIndex = taxHHMemIndexForMember;
					break;
								
				case "Ms_MAGI_HH_Size":
					int magiHHSizeForMember = Integer.parseInt(fieldValue);
					memsData.get(memIndex).magiHHSize = magiHHSizeForMember;
					break;
								
				case "Ms_Tax_HH_Size":
					int taxHHSizeForMember = Integer.parseInt(fieldValue);
					memsData.get(memIndex).taxHHSize = taxHHSizeForMember;
					break;
								
				case "Ms_MAGI_FPL":
					memsData.get(memIndex).magiFPL = fieldValue;
					break;
						
				case "Ms_TAX_FPL":
					memsData.get(memIndex).taxFPL = fieldValue;
					break;
								
				case "Ms_Aid_Cat":
					List<String> listAidCat = AidCat.getCodes();
							
					if(!listAidCat.contains(fieldValue)){
						throw new Exception("Aid Cat For Member" + (memIndex + 1) + " is not correct [" + fieldValue + "] Accepted Value " + listAidCat);
					}
								
					memsData.get(memIndex).mhAidCat = fieldValue;
					break;
								
				case "Ms_Income_From_JOB_EmployerName":
					memsData.get(memIndex).jobEmployerName = fieldValue;
					break;
								
				case "Ms_Income_From_JOB_HrPerWeek":
					int jobIncomeHrsPerWeek = Integer.parseInt(fieldValue);
					memsData.get(memIndex).jobIncomeHrsPerWeek = jobIncomeHrsPerWeek;
					break;
								
				case "Ms_Job_Sheltered_Attestation":
					memsData.get(memIndex).jobSheltered = fieldValue.equalsIgnoreCase("Y")?true:false;
					break;
								
				case "Ms_ExpectedYearly_Income_IfDiffr":
					int expectedYearlyIncomeAmt = Integer.parseInt(fieldValue);
					memsData.get(memIndex).expectedYearlyIncomeAmtIfDiffr = expectedYearlyIncomeAmt;
					memsData.get(memIndex).expectedYearlyIncomeSameAsCurrent = false;
					break;
								
				case "Ms_With_NCP_RFI":
					memsData.get(memIndex).ncpRfiRequired = true;
					break;
					
				case "Ms_User_REF_ID":
					memsData.get(memIndex).userRefId = fieldValue;
					break;
					
				case "Ms_Eligibility_ID":
					memsData.get(memIndex).elgId = fieldValue;
					break;
					
				case "App_Creation_Date":
					memsData.get(memIndex).appCreateDate = fieldValue;
					break;
				
				case "RAC_Type":
					memsData.get(memIndex).racType = fieldValue;
					break;
			}
		}
	}
	
	private void getMemberNumber(String fieldName, int memIndex, String fieldValue) throws Exception {
		if(!fieldValue.isEmpty()){
			switch(fieldName){					
				case "Ms_With_NCP_RFI":
					memsData.get(memIndex).ncpRfiRequired = true;
					break;
			}
		}		
	}
	
	public void getIncomeTypeAndAmoutForMembers(String sourceName, int memIndex, String incomeAmount, HashMap<String, String> gd, String appDate) throws Exception {
		if(!incomeAmount.isEmpty()){
			switch(sourceName){
				case "JOB":
					String jobIncomeFreqCodeForMember = validateIncomeFrequency(memIndex, incomeAmount);						
								
					int jobIncomeAmtForMember = Integer.parseInt(incomeAmount.replace(jobIncomeFreqCodeForMember, ""));
							
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).jobIncomeAmount = jobIncomeAmtForMember;
					memsData.get(memIndex).jobIncomeFrequency = updateIncomeFrequency(memIndex, jobIncomeFreqCodeForMember);
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex, memsData.get(memIndex).incomeTypes, IncomeType.JOB.val);
								
					memsData.get(memIndex).jobEmployerName = gd.get("Member_Name_of_Employer");
					memsData.get(memIndex).jobEmployerAddr.streetAddress = gd.get("Member_Employer_Address_Street_Add");
					memsData.get(memIndex).jobEmployerAddr.aptUnit = gd.get("Member_Employer_Address_Apt");
					memsData.get(memIndex).jobEmployerAddr.city = gd.get("Member_Employer_Address_City");
					memsData.get(memIndex).jobEmployerAddr.zipCode = gd.get("Member_Employer_Address_ZipCode");
					memsData.get(memIndex).jobEmployerAddr.county = gd.get("Member_Employer_Address_County");
								
					int intMember_Employer_Effective_DatePriorFromToday_InDays = Integer.parseInt(gd.get("Member_Employer_Effective_DatePriorFromToday_InDays"));
								
					memsData.get(memIndex).jobIncomeEffectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:" + intMember_Employer_Effective_DatePriorFromToday_InDays);
					memsData.get(memIndex).jobIncomeHrsPerWeek = Integer.parseInt(gd.get("Member_Income_Hrs_per_Week"));							
					break;						
								
				case "SELF_EMPLOYMENT":
					int seIncomeAmtForMember = Integer.parseInt(incomeAmount.replaceAll("[^0-9]", ""));
						
					memsData.get(memIndex).selfEmpProfitAmountMonthly = seIncomeAmtForMember;
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex,memsData.get(memIndex).incomeTypes, IncomeType.SELF_EMPLOYMENT.val);
					memsData.get(memIndex).selfEmpWorkType = gd.get("Member_Self_Emp_WorkType");
								
					int intMember_Self_Emp_Effective_DatePriorFromToday_InDays = Integer.parseInt(gd.get("Member_Self_Emp_Effective_DatePriorFromToday_InDays"));
								
					memsData.get(memIndex).selfEmpEffectiveDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:" + intMember_Self_Emp_Effective_DatePriorFromToday_InDays);
					memsData.get(memIndex).selfEmpHrsPerWeek = Integer.parseInt(gd.get("Member_Self_Emp_Hrs_per_Week"));							
					break;
								
				case "SOCIAL_SECURITY_BENEFITS":
					String ssbIncomeFreqCodeForMember = validateIncomeFrequency(memIndex, incomeAmount);
					
					int ssbIncomeAmtForMember = Integer.parseInt(incomeAmount.replace(ssbIncomeFreqCodeForMember, ""));
						
					memsData.get(memIndex).ssbAmt = ssbIncomeAmtForMember;
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex, memsData.get(memIndex).incomeTypes, IncomeType.SOCIAL_SECURITY_BENEFITS.val);
					memsData.get(memIndex).ssbAmountFrequency = updateIncomeFrequency(memIndex, ssbIncomeFreqCodeForMember);							
					break;
						
				case "UNEMPLOYMENT":
					String unIncomeFreqCodeForMember = validateIncomeFrequency(memIndex, incomeAmount);
						
					int unIncomeAmtForMember = Integer.parseInt(incomeAmount.replace(unIncomeFreqCodeForMember, ""));
						
					memsData.get(memIndex).UnemploymentAmt = unIncomeAmtForMember;
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex, memsData.get(memIndex).incomeTypes, IncomeType.UNEMPLOYMENT.val);
					memsData.get(memIndex).UnemploymentAmountFrequency = updateIncomeFrequency(memIndex, unIncomeFreqCodeForMember);							
					break;
								
				case "RETIREMENT":
					String reIncomeFreqCodeForMember = validateIncomeFrequency(memIndex, incomeAmount);
					
					int reIncomeAmtForMember = Integer.parseInt(incomeAmount.replace(reIncomeFreqCodeForMember, ""));
						
					memsData.get(memIndex).RetirementAmt = reIncomeAmtForMember;
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex, memsData.get(memIndex).incomeTypes, IncomeType.RETIREMENT.val);
					memsData.get(memIndex).RetirementAmountFrequency = updateIncomeFrequency(memIndex, reIncomeFreqCodeForMember);							
					break;
								
				case "CAPITALGAINS":
					int caIncomeAmtForMember = Integer.parseInt(incomeAmount.replaceAll("[^0-9]", ""));
						
					memsData.get(memIndex).capitalGainsMonthlyAmnt = caIncomeAmtForMember;
					memsData.get(memIndex).capitalGainsYearlyAmnt = caIncomeAmtForMember * 12;
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex, memsData.get(memIndex).incomeTypes, IncomeType.CAPITALGAINS.val);							
					break;						
								
				case "INVESTMENT_INCOME":
					String inIncomeFreqCodeForMember = validateIncomeFrequency(memIndex, incomeAmount);
					
					int inIncomeAmtForMember = Integer.parseInt(incomeAmount.replace(inIncomeFreqCodeForMember, ""));
						
					memsData.get(memIndex).interestAmt = inIncomeAmtForMember;
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex, memsData.get(memIndex).incomeTypes, IncomeType.INVESTMENT_INCOME.val);
					memsData.get(memIndex).interestAmountFrequency = updateIncomeFrequency(memIndex, inIncomeFreqCodeForMember);
					break;
								
				case "RENTAL_OR_ROYALTY_INCOME":
					String roIncomeFreqCodeForMember = validateIncomeFrequency(memIndex, incomeAmount);
						
					int roIncomeAmtForMember = Integer.parseInt(incomeAmount.replaceAll("[^0-9]", ""));
				//	String 	roIncAmtForMember = Double. toString(roIncomeAmtForMember/12);
				//	String 	roIncAmtForMember = roIncomeFreqCodeForMember;
					
					memsData.get(memIndex).royaltyAmtPerMonth = roIncomeAmtForMember;
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex, memsData.get(memIndex).incomeTypes, IncomeType.RENTAL_OR_ROYALTY_INCOME.val);
					memsData.get(memIndex).royaltyAmountFrequency = updateIncomeFrequency(memIndex, roIncomeFreqCodeForMember);							
					break;
								
				case "FARMING_OR_FISHING_INCOME":
					String faIncomeFreqCodeForMember = validateIncomeFrequency(memIndex, incomeAmount);
							
					int faIncomeAmtForMember = Integer.parseInt(incomeAmount.replace(faIncomeFreqCodeForMember, ""));
								
					memsData.get(memIndex).farmingAmount = faIncomeAmtForMember;
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex, memsData.get(memIndex).incomeTypes, IncomeType.FARMING_OR_FISHING_INCOME.val);
					memsData.get(memIndex).farmingAmountFrequency = updateIncomeFrequency(memIndex, faIncomeFreqCodeForMember);
					memsData.get(memIndex).farmingDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:12:00");							
					break;
								
				case "ALIMONY_RECEIVED":
					String alIncomeFreqCodeForMember = validateIncomeFrequency(memIndex, incomeAmount);
						
					int alIncomeAmtForMember = Integer.parseInt(incomeAmount.replace(alIncomeFreqCodeForMember, ""));
								
					memsData.get(memIndex).AlimonyAmt = alIncomeAmtForMember;
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex, memsData.get(memIndex).incomeTypes, IncomeType.ALIMONY_RECEIVED.val);
					memsData.get(memIndex).AlimonyAmountFrequency = updateIncomeFrequency(memIndex, alIncomeFreqCodeForMember);							
					break;
								
				case "OTHER_INCOME":
					String otIncomeFreqCodeForMember = validateIncomeFrequency(memIndex, incomeAmount);
							
					int otIncomeAmtForMember = Integer.parseInt(incomeAmount.replace(otIncomeFreqCodeForMember, ""));
								
					memsData.get(memIndex).otherIncomeAmt = otIncomeAmtForMember;
					memsData.get(memIndex).hasSourceOfIncome = true;
					memsData.get(memIndex).incomeTypes = updateIncomeTypes(memIndex, memsData.get(memIndex).incomeTypes, IncomeType.OTHER_INCOME.val);
					memsData.get(memIndex).otherIncomeAmountFrequency = updateIncomeFrequency(memIndex, otIncomeFreqCodeForMember);
					memsData.get(memIndex).otherIncomeType = gd.get("OtherIncomeType");							
					break;								
			}			
		}
	}

	private String updateIncomeTypes(int mCounter, String currentIncomeTypes, String incomeType) {
		String updatedIncomeTypes;
		
		if(currentIncomeTypes == null){
			updatedIncomeTypes = incomeType;
		}else{
			if(currentIncomeTypes.equals("")){
				updatedIncomeTypes = incomeType;
			}else{
				updatedIncomeTypes = currentIncomeTypes + "," + incomeType;
			}
		}
		return updatedIncomeTypes;
	}
	
	private int totalIncomeAmt(int memIndex){
        int totIncmAmt = 0;
        
        if(memsData.get(memIndex).jobIncomeAmount == null){
        	memsData.get(memIndex).jobIncomeAmount = 0;
        }
        if(memsData.get(memIndex).selfEmpProfitAmountMonthly == null){
        	memsData.get(memIndex).selfEmpProfitAmountMonthly = 0;
        }
        if(memsData.get(memIndex).ssbAmt == null){
        	memsData.get(memIndex).ssbAmt = 0;
        }
        if(memsData.get(memIndex).UnemploymentAmt == null){
        	memsData.get(memIndex).UnemploymentAmt = 0;
        }
        if(memsData.get(memIndex).RetirementAmt == null){
        	memsData.get(memIndex).RetirementAmt = 0;
        }
        if(memsData.get(memIndex).capitalGainsYearlyAmnt == null){
        	memsData.get(memIndex).capitalGainsYearlyAmnt = 0;
        }
        if(memsData.get(memIndex).interestAmt == null){
        	memsData.get(memIndex).interestAmt = 0;
        }
        if(memsData.get(memIndex).royaltyAmtPerMonth == null){
        	memsData.get(memIndex).royaltyAmtPerMonth = 0;
        }
        if(memsData.get(memIndex).farmingAmount == null){
        	memsData.get(memIndex).farmingAmount = 0;
        }
        if(memsData.get(memIndex).AlimonyAmt == null){
        	memsData.get(memIndex).AlimonyAmt = 0;
        }
        if(memsData.get(memIndex).otherIncomeAmt == null){
        	memsData.get(memIndex).otherIncomeAmt = 0;
        }
        totIncmAmt = memsData.get(memIndex).jobIncomeAmount +
        		memsData.get(memIndex).selfEmpProfitAmountMonthly +
        		memsData.get(memIndex).ssbAmt +
        		memsData.get(memIndex).UnemploymentAmt +
        		memsData.get(memIndex).RetirementAmt +
        		memsData.get(memIndex).capitalGainsYearlyAmnt +
        		memsData.get(memIndex).interestAmt +
        		memsData.get(memIndex).royaltyAmtPerMonth +
        		memsData.get(memIndex).farmingAmount +
        		memsData.get(memIndex).AlimonyAmt +
        		memsData.get(memIndex).otherIncomeAmt  ;
        
        return totIncmAmt;
        
	}
	private String updateDeductionTypes(int mCounter, String currentDeductionTypes, String deductionType) {
		String updatedDeductionTypes;
		
		if(currentDeductionTypes == null){
			updatedDeductionTypes = deductionType;
		}else{
			if(currentDeductionTypes.equals("")){
				updatedDeductionTypes = deductionType;
			}else{
				updatedDeductionTypes = currentDeductionTypes + "," + deductionType;
			}
		}
		return updatedDeductionTypes;
	}
	
	public void getDeductionTypeAndAmoutForMembers(String sourceName, int memIndex, String deductionAmount, HashMap<String, String> gd, String appDate) throws Exception {
        if(!deductionAmount.isEmpty()){
        switch(sourceName){
        case "EDUCATOR_EXPENSE":
        memsData.get(memIndex).deductionTypeAsEducatorAmt = deductionAmount.replaceAll("[^0-9]", "");
        memsData.get(memIndex).hasSourceOfDeduction = true;
        memsData.get(memIndex).deductionTypeAsEducator= true;
        memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.EDUCATOR_EXPENSE.val);
        break;
        
        case "BUSINESS_EXPENSES_RESERVIST_ARTIST":
            memsData.get(memIndex).deductionTypeAsBusinessExpAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsBusinessExp= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.BUSINESS_EXPENSES_RESERVIST_ARTIST.val);
            break;
            
        case "HEALTH_SAVINGS_ACCOUNT_DEDUCTION":
            memsData.get(memIndex).deductionTypeAsHealthSavingDedAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsHealthSavingDed= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.HEALTH_SAVINGS_ACCOUNT_DEDUCTION.val);
            break;
            
        case "MOVING_EXPENSES_RELATED_TO_JOB_CHANGE":
            memsData.get(memIndex).deductionTypeAsMoveJobChangeAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsMoveJobChange= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.MOVING_EXPENSES_RELATED_TO_JOB_CHANGE.val);
            break;
            
        case "DEDUCTIBLE_PART_OF_SELF_EMPLOYMENT_TAX":
            memsData.get(memIndex).deductionTypeAsSelfEmployTaxAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsSelfEmployTax= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.DEDUCTIBLE_PART_OF_SELF_EMPLOYMENT_TAX.val);
            break;
            
        case "CONTRIBUTION_TO_SELF_EMPLOYED_SEP":
            memsData.get(memIndex).deductionTypeAsSelfEmploySEPAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsSelfEmploySEP= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.CONTRIBUTION_TO_SELF_EMPLOYED_SEP.val);
            break;
            
        case "SELF_EMPLOYED_HEALTH_INSURANCE_DED":
            memsData.get(memIndex).deductionTypeAsHealthInsDedAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsHealthInsDed= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.SELF_EMPLOYED_HEALTH_INSURANCE_DED.val);
            break;
            
        case "PENALTY_ON_EARLY_WITHDRAWAL":
            memsData.get(memIndex).deductionTypeAsPenaltyEarlywithAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsPenaltyEarlywith= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.PENALTY_ON_EARLY_WITHDRAWAL.val);
            break;
            
        case "ALIMONY_PAID":
            memsData.get(memIndex).deductionTypeAsAlimonyPaidAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsAlimonyPaid= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.ALIMONY_PAID.val);
            break;
            
        case "INDIVIDUAL_RETIREMENT_ACCOUNT_DED":
            memsData.get(memIndex).deductionTypeAsIndRetirementAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsIndRetirement= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.INDIVIDUAL_RETIREMENT_ACCOUNT_DED.val);
            break;
            
        case "STUDENT_LOAN_INTEREST_PAID":
            memsData.get(memIndex).deductionTypeAsStdLoanIntrPaidAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsStdLoanIntrPaid= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.STUDENT_LOAN_INTEREST_PAID.val);
            break;
            
        case "HIGHER_EDUCATION":
            memsData.get(memIndex).deductionTypeAsHigherEduAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsHigherEdu= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.HIGHER_EDUCATION.val);
            break;
            
        case "DOMESTIC_PRODUCTION_DED":
            memsData.get(memIndex).deductionTypeAsDomsProdDedAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsDomsProdDed= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.DOMESTIC_PRODUCTION_DED.val);
            break;
            
        case "OTHER_DEDUCTIONS":
            memsData.get(memIndex).deductionTypeAsOtherAmt = deductionAmount.replaceAll("[^0-9]", "");
            memsData.get(memIndex).hasSourceOfDeduction = true;
            memsData.get(memIndex).deductionTypeAsOther= true;
            memsData.get(memIndex).deductionTypes = updateDeductionTypes(memIndex,memsData.get(memIndex).deductionTypes, DeductionType.OTHER_DEDUCTIONS.val);
            break;
        }
        }
	}
	private int totalDeductionAmt(int memIndex){
        int totDedAmt = 0;
        if(memsData.get(memIndex).deductionTypeAsEducatorAmt == null){
        	memsData.get(memIndex).deductionTypeAsEducatorAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsBusinessExpAmt == null){
        	memsData.get(memIndex).deductionTypeAsBusinessExpAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsHealthSavingDedAmt == null){
        	memsData.get(memIndex).deductionTypeAsHealthSavingDedAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsMoveJobChangeAmt == null){
        	memsData.get(memIndex).deductionTypeAsMoveJobChangeAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsSelfEmployTaxAmt == null){
        	memsData.get(memIndex).deductionTypeAsSelfEmployTaxAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsSelfEmploySEPAmt == null){
        	memsData.get(memIndex).deductionTypeAsSelfEmploySEPAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsHealthInsDedAmt == null){
        	memsData.get(memIndex).deductionTypeAsHealthInsDedAmt ="0";
        }
        if(memsData.get(memIndex).deductionTypeAsPenaltyEarlywithAmt == null){
        	memsData.get(memIndex).deductionTypeAsPenaltyEarlywithAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsAlimonyPaidAmt == null){
        	memsData.get(memIndex).deductionTypeAsAlimonyPaidAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsIndRetirementAmt == null){
        	memsData.get(memIndex).deductionTypeAsIndRetirementAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsStdLoanIntrPaidAmt == null){
        	memsData.get(memIndex).deductionTypeAsStdLoanIntrPaidAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsHigherEduAmt == null){
        	memsData.get(memIndex).deductionTypeAsHigherEduAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsDomsProdDedAmt == null){
        	memsData.get(memIndex).deductionTypeAsDomsProdDedAmt = "0";
        }
        if(memsData.get(memIndex).deductionTypeAsOtherAmt == null){
        	memsData.get(memIndex).deductionTypeAsOtherAmt = "0";
        }
        totDedAmt = Integer.parseInt(memsData.get(memIndex).deductionTypeAsEducatorAmt) +
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsBusinessExpAmt) +
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsHealthSavingDedAmt) +
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsMoveJobChangeAmt) +
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsSelfEmployTaxAmt) +
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsSelfEmploySEPAmt) +
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsHealthInsDedAmt) +
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsPenaltyEarlywithAmt) +
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsAlimonyPaidAmt) +
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsIndRetirementAmt) +
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsStdLoanIntrPaidAmt)+
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsHigherEduAmt)+
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsDomsProdDedAmt)+
        		Integer.parseInt(memsData.get(memIndex).deductionTypeAsOtherAmt);
        
        return totDedAmt;
        }
	
	private String updateIncomeFrequency(int mCounter, String incomeFreqCodeForMember) {
		String frequency = "";

		switch(incomeFreqCodeForMember){
			case "WK":
				frequency = IncomeFrequency.WEEKLY.val;
				break;
				
			case "MN":
				frequency = IncomeFrequency.MONTHLY.val;
				break;
				
			case "QR":
				frequency = IncomeFrequency.QUARTERLY.val;
				break;
				
			case "YR":
				frequency = IncomeFrequency.YEARLY.val;
				break;
				
			case "2W":
				frequency = IncomeFrequency.EVERY_TWO_WEEK.val;
				break;
				
			case "2M":
				frequency = IncomeFrequency.TWICE_A_MONTH.val;
				break;
				
			case "OM":
				frequency = IncomeFrequency.EVERY_OTHER_MONTH.val;
				break;
				
			case "2Y":
				frequency = IncomeFrequency.TWICE_A_YEAR.val;
				break;
				
			case "OT":
				frequency = IncomeFrequency.ONE_TIME_ONLY.val;
				break;
				
			case "SI":
				frequency = IncomeFrequency.SEASONAL_INCOME.val;
				break;					
		}
		return frequency;
	}
	
	private String updateInsuranceFrequency(int mCounter, String insuranceFreqCodeForMember) {
		String frequency = "";

		switch(insuranceFreqCodeForMember){		
			case "WK":
				frequency = InsuranceFrequency.WEEK.val;
				break;
				
			case "2W":
				frequency = InsuranceFrequency.TWO_WEEKS.val;
				break;
				
			case "2M":
				frequency = InsuranceFrequency.TWICE_PER_MONTH.val;
				break;
				
			case "MN":
				frequency = InsuranceFrequency.MONTH.val;
				break;
				
			case "YR":
				frequency = InsuranceFrequency.YEAR.val;
				break;				
		}
		return frequency;
	}

	private String validateIncomeFrequency(int mCounter, String incomeAmtCodeForMember) throws Exception {
		String incomeFreqCodeForMember = incomeAmtCodeForMember.charAt(incomeAmtCodeForMember.length() - 2) + "" + incomeAmtCodeForMember.charAt(incomeAmtCodeForMember.length() - 1) + "";
		
		List<String> listFreqCode = IncomeFrequency.getCodes();
		
		if(!listFreqCode.contains(incomeFreqCodeForMember)){
			throw new Exception("Income Frequency For Member" + (mCounter + 1) + " is not correct [" + incomeFreqCodeForMember + "] Accepted Value " + listFreqCode);
		}
		
		return incomeFreqCodeForMember;
	}

	private String validateInsuranceFrequency(int mCounter, String freqAmtCodeForMember) throws Exception {
		String freqCodeForMember = freqAmtCodeForMember.charAt(freqAmtCodeForMember.length() - 2) + "" + freqAmtCodeForMember.charAt(freqAmtCodeForMember.length() - 1) + "";
		
		List<String> listFreqCode = InsuranceFrequency.getCodes();

		if(!listFreqCode.contains(freqCodeForMember)){
			throw new Exception("Insurance Frequency For Member" + (mCounter + 1) + " is not correct [" + freqCodeForMember + "] Accepted Value " + listFreqCode );
		}
		
		return freqCodeForMember;
	}
	
	public void getOtherHealthInsuranceForMembers(String planType, int memIndex, String memsHP, HashMap<String, String> gd) throws Exception {
		if(!memsHP.isEmpty()){
			int intMember_Employer_Effective_DatePriorFromToday_InDays = Integer.parseInt(gd.get("Member_Employer_Effective_DatePriorFromToday_InDays"));
			int intMember_Employer_Termination_DateFromToday_InDays = Integer.parseInt(gd.get("Member_Employer_Termination_DateFromToday_InDays"));
			
			switch(planType){
				case "VETERAN_HEALTH_PROGRAM":
					if(Boolean.parseBoolean(memsHP)){
						memsData.get(memIndex).enrolledInVeteran = true;
						memsData.get(memIndex).enrolledNoHP = false;
					}else{
						memsData.get(memIndex).enrolledInVeteran = false;
					}
					break;
					
				case "MASS_HEALTH":
					if(Boolean.parseBoolean(memsHP)){
						memsData.get(memIndex).enrolledInMassHealth = true;
						memsData.get(memIndex).enrolledNoHPMixed = false;
					}else{
						memsData.get(memIndex).enrolledInMassHealth = false;
					}
					break;
					
				case "MEDICARE":
					if(Boolean.parseBoolean(memsHP)){
						memsData.get(memIndex).enrolledInMedicare = true;
						memsData.get(memIndex).enrolledNoHPMixed = false;
						memsData.get(memIndex).medicareCovStartDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:" + intMember_Employer_Effective_DatePriorFromToday_InDays);
						memsData.get(memIndex).medicareCovEndDate = DateUtil.getFutureDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:" + intMember_Employer_Termination_DateFromToday_InDays);
					}else{
						memsData.get(memIndex).enrolledInMedicare = false;
					}
					break;
					
				case "PEACE_CORPS":
					if(Boolean.parseBoolean(memsHP)){
						memsData.get(memIndex).enrolledInPeaceCorps = true;
						memsData.get(memIndex).enrolledNoHPMixed = false;
						memsData.get(memIndex).peaceCorpsCovStartDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:" + intMember_Employer_Effective_DatePriorFromToday_InDays);
					}else{
						memsData.get(memIndex).enrolledInPeaceCorps = false;
					}
					break;
					
				case "TRICARE":
					if(Boolean.parseBoolean(memsHP)){
						memsData.get(memIndex).enrolledInTricare = true;
						memsData.get(memIndex).enrolledNoHPMixed = false;
						memsData.get(memIndex).tricareCovStartDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:" + intMember_Employer_Effective_DatePriorFromToday_InDays);
					}else{
						memsData.get(memIndex).enrolledInTricare = false;
					}
					break;
					
				case "VA_HEALTH_PROGRAM":
					if(Boolean.parseBoolean(memsHP)){
						memsData.get(memIndex).enrolledInVaHp = true;
						memsData.get(memIndex).enrolledNoHPMixed = false;
						memsData.get(memIndex).vaCovStartDate = DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "00:00:" + intMember_Employer_Effective_DatePriorFromToday_InDays);
					}else{
						memsData.get(memIndex).enrolledInVaHp = false;
					}
					break;
					
				case "OTHER":
					if(Boolean.parseBoolean(memsHP)){
						memsData.get(memIndex).enrolledInOtherPlan = true;
						memsData.get(memIndex).enrolledNoHPMixed = false;
					}else{
						memsData.get(memIndex).enrolledInOtherPlan = false;
					}
					break;
			}
		}
	}

	public void getHealthInsuranceForMembers(String planType, int memIndex, String memsHP, String memsInHOH_Plan, String memsCoverageAfforadble, String premiumAmnt, HashMap<String, String> gd) throws Exception {
		if(!memsHP.isEmpty()){
			String membersCoveredInHOHPlanByIndex = TestData.getMembersByIndex(memsInHOH_Plan);
			
			if(memIndex == 0){
				memsData.get(memIndex).otherMembersEnrolledInInsuranceByIndex = membersCoveredInHOHPlanByIndex;
			}
			
			switch(planType){
				case "ESI":
					memsData.get(memIndex).enrolledInESI = true;
					memsData.get(memIndex).enrolledNoHP = false;						
					break;
						
				case "COBRA":
					memsData.get(memIndex).enrolledInCOBRA = true;
					memsData.get(memIndex).enrolledNoHP = false;
					memsData.get(memIndex).otherHltInsuranceEmployerName = gd.get("COBRA_HProgram");
					memsData.get(memIndex).otherHltInsuranceEmployerAddr.streetAddress = gd.get("Member_Employer_Address_Street_Add");
					memsData.get(memIndex).otherHltInsuranceEmployerAddr.aptUnit = gd.get("Member_Employer_Address_Apt");
					memsData.get(memIndex).otherHltInsuranceEmployerAddr.city = gd.get("Member_Employer_Address_City");
					memsData.get(memIndex).otherHltInsuranceEmployerAddr.zipCode = gd.get("Member_Employer_Address_ZipCode");
					memsData.get(memIndex).otherHltInsuranceEmployerAddr.county = gd.get("Member_Employer_Address_County");
					break;
						
				case "RETIREE_HEALTH_PLAN":
					memsData.get(memIndex).enrolledInRetiree = true;
					memsData.get(memIndex).enrolledNoHP = false;
					memsData.get(memIndex).otherHltInsuranceEmployerName = gd.get("Retiree_HProgram");
					memsData.get(memIndex).otherHltInsuranceEmployerAddr.streetAddress = gd.get("Member_Employer_Address_Street_Add");
					memsData.get(memIndex).otherHltInsuranceEmployerAddr.aptUnit = gd.get("Member_Employer_Address_Apt");
					memsData.get(memIndex).otherHltInsuranceEmployerAddr.city = gd.get("Member_Employer_Address_City");
					memsData.get(memIndex).otherHltInsuranceEmployerAddr.zipCode = gd.get("Member_Employer_Address_ZipCode");
					memsData.get(memIndex).otherHltInsuranceEmployerAddr.county = gd.get("Member_Employer_Address_County");
					break;
			}
				
			if(!memsCoverageAfforadble.isEmpty()){
				memsData.get(memIndex).insuranceCoverageAffordable = true;
				
				if(!premiumAmnt.isEmpty()){
					String addQuesFreqCodeForMember = validateInsuranceFrequency(memIndex, premiumAmnt);
					
					memsData.get(memIndex).planPremiumCost = premiumAmnt.replace(addQuesFreqCodeForMember, "");
					memsData.get(memIndex).planPremiumFrequency = updateInsuranceFrequency(memIndex, addQuesFreqCodeForMember);
				}				
			}
		}
	}
	
	public ServiceData getServiceData(HashMap<String, String> ed) {
		ServiceData service = new ServiceData();
		
		service.individualByPassUsps = ed.get("Individual_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		service.agentByPassUsps = ed.get("Agent_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		service.assisterByPassUsps = ed.get("Assister_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		
		return service;
	}
	
	public void printEVPDData() throws Exception {
		Class<?> c = this.getClass();
		Field[] field = c.getDeclaredFields();

		for(int fCounter = 0; fCounter < field.length; fCounter++){	    	   
			String fieldName = field[fCounter].getName();
	    	   
			if(fieldName.equals("optumIdData")){
				optumIdData.printOptumIdData();
			}else if(fieldName.equals("createProfileData")){
				createProfileData.printCreateProfileData();
			}else if(fieldName.equals("memsData")){
				if(count == null) continue;
	    		   
				for(int mCounter = 0; mCounter < count; mCounter++){
					System.out.println("############### RAC Data for Member [" + (mCounter + 1) + "] ###############");
					memsData.get(mCounter).printMemberData();
				}
			}else if(fieldName.equals("rpData")){
				rpData.printResponsiblePartyData();
			}else if(fieldName.equals("serviceData")){
				serviceData.printServiceData();
			}else if(fieldName.equals("pbfgData")){
				if(pbfgGroupCount == null) continue;
	    		   
				for(int gCounter = 0; gCounter < pbfgGroupCount; gCounter++){
					System.out.println("############### PBFG Data for Group [" + (gCounter + 1) + "] ###############");
					pbfgData.get(gCounter).printGroupData();
				}
			}else{
				Object fieldValue = c.getDeclaredField(fieldName).get(this);
	    		   
				if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float){
					if(fieldValue != null){
						System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
					} 
				}
			}
	    }
	}
}