package appdata.common;

import java.lang.reflect.Field;

import org.json.JSONException;
import org.json.JSONObject;

public class TempData {
	
	public String sqlScript;

	public void printSqlRequestData() throws Exception{
		System.out.println("############   Temp Data  ############");
		
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

	    for (int fCounter = 0; fCounter < field.length; fCounter++){    	   
	    	String fieldName = field[fCounter].getName();
	    	Object fieldValue = c.getDeclaredField(fieldName).get(this);
	    	
	    	if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float ){
	    		if(fieldValue != null ){
	    			System.out.println(fieldName + ": [" + c.getDeclaredField(fieldName).get(this) + "]");  
	    		} 
	    	}
	    }
	}
	
	 /** @author: ppinho
	 */	
	public static String updateTempDataRequest(TempData tempData){		
		JSONObject json = new JSONObject();
		
		try{			
			json.put("sqlScript", tempData.sqlScript);
		}catch (JSONException e) {
			e.printStackTrace();
		}
		
		return json.toString();
	}
}
