package appdata.common;

import java.lang.reflect.Field;

public class OptumIdData {
	
	public String firstName;
	public String lastName;
	public String emailAddress;
	public Integer yearOfBirth;
	public String dateOfBirth;
	public String optumId;
	public String password;
	
	public String createOptumIdPhoneQue;
	public String createOptumIdFriendQue;
	public String createOptumIdColorQue;
	
	public String createOptumIdAnsForPhone;
	public String createOptumIdAnsForFriend;
	public String createOptumIdAnsForColor;
	
	public String sequrityQuePhoneNoAnswer;
	public String sequrityQueFriendAnswer;
	public String sequrityQueColorAnswer;
	public String sequrityQuePetAnswer;
	public String sequrityQueCountryAnswer;
	public String sequrityQueSportsAnswer;
	
	public String role;

	public void printOptumIdData() throws Exception{
		System.out.println("############### Optum ID Data ###############");	
		
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

       for (int fCounter = 0; fCounter < field.length; fCounter++){    	   
    	   String fieldName = field[fCounter].getName();
    	   Object fieldValue = c.getDeclaredField(fieldName).get(this);
    	   
    	   if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float ){
			   if(fieldValue != null ){
    			   System.out.println(fieldName + ": [" + c.getDeclaredField(fieldName).get(this) + "]");  
    		   } 
		   }
		}
	}
	
}
