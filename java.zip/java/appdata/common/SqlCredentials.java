package appdata.common;

import java.lang.reflect.Field;

import org.json.JSONException;
import org.json.JSONObject;

public class SqlCredentials {
	
	public String dbInstance;
	public String dbCredential;
	public String dbColumn;
	public String maxRecords;
	public String sqlScript;

	public void printSqlRequestData() throws Exception{
		System.out.println("############   SQL Request Data  ############");
		
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

	    for (int fCounter = 0; fCounter < field.length; fCounter++){    	   
	    	String fieldName = field[fCounter].getName();
	    	Object fieldValue = c.getDeclaredField(fieldName).get(this);
	    	
	    	if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float ){
	    		if(fieldValue != null ){
	    			System.out.println(fieldName + ": [" + c.getDeclaredField(fieldName).get(this) + "]");  
	    		} 
	    	}
	    }
	}
	
	 /** @author: ppinho
	 */	
	public static String sqlSelectRequestData(SqlCredentials sql){		
		JSONObject json = new JSONObject();
		
		try{			
			json.put("dbInstance", sql.dbInstance);
			json.put("dbCredential", sql.dbCredential);
			json.put("maxRecords", sql.maxRecords);
			json.put("sqlScript", sql.sqlScript);

		}catch (JSONException e) {
			e.printStackTrace();
		}
		
		return json.toString();
	}
	
	 /** @author: ppinho
	 */	
	public static String sqlUpdateRequestData(SqlCredentials sql){		
		JSONObject json = new JSONObject();
		
		try{			
			json.put("dbInstance", sql.dbInstance);
			json.put("dbCredential", sql.dbCredential);
			json.put("sqlScript", sql.sqlScript);

		}catch (JSONException e) {
			e.printStackTrace();
		}
		
		return json.toString();
	}
	
	 /** @author: ppinho
	 */	
	public static String sqlXmlRequestData(SqlCredentials sql){		
		JSONObject json = new JSONObject();
		
		try{			
			json.put("dbInstance", sql.dbInstance);
			json.put("dbCredential", sql.dbCredential);
			json.put("dbColumn", sql.dbColumn);
			json.put("sqlScript", sql.sqlScript);

		}catch (JSONException e) {
			e.printStackTrace();
		}
		
		return json.toString();
	}
	
	 /** @author: ppinho
	 */	
	public static String sqlSysDateData(SqlCredentials sql){		
		JSONObject json = new JSONObject();
		
		try{			
			json.put("dbInstance", sql.dbInstance);
			json.put("dbCredential", sql.dbCredential);

		}catch (JSONException e) {
			e.printStackTrace();
		}
		
		return json.toString();
	}
	
}
