package appdata.common;

import java.lang.reflect.Field;

public class MicroserviceRequestData {
	public String templateName;
	public String emailServerId;
	public String authCredentialId;
	public String fromUser;
	public String notifyList;
	public String approverList;
	public String operatorList;
	public String gatekeeperList;
	public String notificationTemplate;
	public String approvalTemplate;
	public String changeRequestTemplate;
	public String gateKeeperTemplate;
	public String newDate;
	public String changeServerList;

	public void printMicroserviceData() throws Exception{
		System.out.println("############   Microservice Data  ############");
		
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

	    for (int fCounter =0; fCounter < field.length; fCounter++){    	   
	    	String fieldName = field[fCounter].getName();
	    	Object fieldValue = c.getDeclaredField(fieldName).get(this);
	    	
	    	if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float ){
	    		if(fieldValue != null ){
	    			System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
	    		} 
	    	}
	    }
	}
	
}
