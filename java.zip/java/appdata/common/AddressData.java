package appdata.common;

import java.lang.reflect.Field;

public class AddressData {
	
	public String streetAddress;
	public String aptUnit;
	public String city;
	public String zipCode;
	public String county;
	public String zipCodeTemp;
	public String countyTemp;
		
	public void printAddessData() throws Exception {
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

	    for(int fCounter = 0; fCounter < field.length; fCounter++){
    	   String fieldName = field[fCounter].getName();
    	   { 
			   Object fieldValue = c.getDeclaredField(fieldName).get(this);
		   
			   if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float){
				   if(fieldValue != null ){
				   System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
				   } 
			   }
    	   }
       }		
	}
}
