package appdata.mmis;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MMIS_Data {
	
	public Integer memCount;
	
	public List<MMIS_MemData> memsData = new ArrayList<MMIS_MemData>();
	
	public MMIS_Data(HashMap<String, String> envData, HashMap<String, String> globalData, HashMap<String, Object> memData, String runDate) throws Exception {	
		memCount = memData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			memsData.add(new MMIS_MemData());
		}
		
		mmisData(memData);
		this.printMmisData();
	}

	@SuppressWarnings("unchecked")
	private void mmisData(HashMap<String, Object> md) throws Exception {
		for(int memIndex = 0; memIndex < memCount; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
			
			memsData.get(memIndex).mmisSeqInd = memData.get("seqInd");
			memsData.get(memIndex).memId = memData.get("memId");
			memsData.get(memIndex).mmisInd = memData.get("mmisInd").equalsIgnoreCase("Y")?true:false;
		}
	}
	
	public void printMmisData() throws Exception {
		Class<?> c = this.getClass();
		Field[] field = c.getDeclaredFields();

		for(int fCounter = 0; fCounter < field.length; fCounter++){	    	   
			String fieldName = field[fCounter].getName();
	    	   
			if(fieldName.equals("memsData")){
				if(memCount == null) continue;
	    		   
				for(int mCounter = 0; mCounter < memCount; mCounter++){
					System.out.println("############### MMIS Data ###############");
					memsData.get(mCounter).printMemberData();
				}
			}else{
				Object fieldValue = c.getDeclaredField(fieldName).get(this);
	    		   
				if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float){
					if(fieldValue != null){
						System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
					} 
				}
			}
	    }
	}
}