package appdata.enrollment;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import appdata.common.OptumIdData;
import appdata.evpd.ServiceData;
import enums.PortalName;
import enums.TrueFalseValue;

import utils.TestData;

public class Enrollment_Data {
	
	public String appDate;
	public String portal;
	public String url;
	
	public OptumIdData optumIdData = new OptumIdData();
	
	public Boolean someOneHelping;
	
	public String whoIsApplying;
	
	public Boolean faReqd;
	public Boolean atleastOneMemberAbove18;
	
	public Integer memCount;
	
	public String userProfileRefId = null;
	public String eligibilityId = null;
	
	public List<Enrollment_MemData> memsData = new ArrayList<Enrollment_MemData>();
	
	public ServiceData serviceData = new ServiceData();
	
	@SuppressWarnings("unchecked")
	public Enrollment_Data(HashMap<String, String> envData, HashMap<String, String> globalData, HashMap<String, Object> memData, String runDate) throws Exception {	
		Map<String, String> hohData = new HashMap<String, String>();
		
		appDate = runDate;
		
		hohData = (Map<String, String>) memData.get("0");		
		portal = hohData.get("portal");
		
		List<String> listNames = PortalName.getCodes();
		
		if(!listNames.contains(portal)){
			throw new Exception("Portal Name is not correct [" + portal + "] Accepted Value " + listNames);
		}
		
			
		HashMap<String, String> hohOptumId = (HashMap<String, String>) hohData;
		
		optumIdData = TestData.getOptumIdData(portal, hohOptumId, envData, globalData);		
		url = TestData.getURL(portal, envData);	
		serviceData = getServiceData(envData);		
		memCount = memData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			memsData.add(new Enrollment_MemData());
		}
		
		enrollmentData(memData);
	
		this.printEnrollmentData();
	}

	@SuppressWarnings("unchecked")
	private void enrollmentData(HashMap<String, Object> md) throws Exception {
		for(int memIndex = 0; memIndex < memCount; memIndex++){
			Map<String, String> memData = (HashMap<String, String>) md.get(Integer.toString(memIndex));
				
			memsData.get(memIndex).variant = memData.get("variant");
			memsData.get(memIndex).gpHealthPlan = memData.get("gpHealthPlan");
			memsData.get(memIndex).gpDentalPlan = memData.get("gpDentalPlan");
			
			memsData.get(memIndex).subscriber = memData.get("subscriber");
			memsData.get(memIndex).loseHiCoverage = memData.get("loseHiCoverage").equalsIgnoreCase("TRUE")?true:false;
			memsData.get(memIndex).notPayingPremiums = memData.get("notPayingPremiums").equalsIgnoreCase("TRUE")?true:false;
			memsData.get(memIndex).healthInsurance = memData.get("healthInsurance").equalsIgnoreCase("TRUE")?true:false;
			
			memsData.get(memIndex).gainAdependent = memData.get("gainADependent").equalsIgnoreCase("TRUE")?true:false;
			memsData.get(memIndex).recentlyMarried = memData.get("recentlyMarried").equalsIgnoreCase("TRUE")?true:false;
			memsData.get(memIndex).birthInHousehold = memData.get("birthInHousehold").equalsIgnoreCase("TRUE")?true:false;
			memsData.get(memIndex).fosterCare = memData.get("fosterCare").equalsIgnoreCase("TRUE")?true:false;
			
			memsData.get(memIndex).lawfullyPresentImmigrant = memData.get("lawfullyPresentImmigrant").equalsIgnoreCase("TRUE")?true:false;
			memsData.get(memIndex).moveToMass = memData.get("moveToMass").equalsIgnoreCase("TRUE")?true:false;
			memsData.get(memIndex).recentlyReleasedFromPrison = memData.get("recentlyReleasedFromPrison").equalsIgnoreCase("TRUE")?true:false;
			memsData.get(memIndex).victimDomAbuseAban = memData.get("victimDomAbuseAban").equalsIgnoreCase("TRUE")?true:false;
			
			memsData.get(memIndex).transactionType1 = memData.get("transactionType1");
			memsData.get(memIndex).maintainenceTypeCode1 = memData.get("maintainenceTypeCode1");
			memsData.get(memIndex).maintainenceReasonCode1 = memData.get("maintainenceReasonCode1");
			memsData.get(memIndex).elgBegDateHealth1 = memData.get("elgBeginDateHealth1");
			memsData.get(memIndex).elgEndDateHealth1 = memData.get("elgEndDateHealth1");
			memsData.get(memIndex).elgBegDateDental1 = memData.get("elgBeginDateDental1");
			memsData.get(memIndex).elgEndDateDental1 = memData.get("elgEndDateDental1");
			
			memsData.get(memIndex).transactionType2 = memData.get("transactionType2");
			memsData.get(memIndex).maintainenceTypeCode2 = memData.get("maintainenceTypeCode2");
			memsData.get(memIndex).maintainenceReasonCode2 = memData.get("maintainenceReasonCode2");
			memsData.get(memIndex).elgBegDateHealth2 = memData.get("elgBeginDateHealth2");
			memsData.get(memIndex).elgEndDateHealth2 = memData.get("elgEndDateHealth2");
			memsData.get(memIndex).elgBegDateDental2 = memData.get("elgBeginDateDental2");
			memsData.get(memIndex).elgEndDateDental2 = memData.get("elgEndDateDental2");
			
			memsData.get(memIndex).transactionType3 = memData.get("transactionType3");
			memsData.get(memIndex).maintainenceTypeCode3 = memData.get("maintainenceTypeCode3");
			memsData.get(memIndex).maintainenceReasonCode3 = memData.get("maintainenceReasonCode3");
			memsData.get(memIndex).elgBegDateHealth3 = memData.get("elgBeginDateHealth3");
			memsData.get(memIndex).elgEndDateHealth3 = memData.get("elgEndDateHealth3");
			memsData.get(memIndex).elgBegDateDental3 = memData.get("elgBeginDateDental3");
			memsData.get(memIndex).elgEndDateDental3 = memData.get("elgEndDateDental3");
			
			memsData.get(memIndex).transactionType4 = memData.get("transactionType4");
			memsData.get(memIndex).maintainenceTypeCode4 = memData.get("maintainenceTypeCode4");
			memsData.get(memIndex).maintainenceReasonCode4 = memData.get("maintainenceReasonCode4");
			memsData.get(memIndex).elgBegDateHealth4 = memData.get("elgBeginDateHealth4");
			memsData.get(memIndex).elgEndDateHealth4 = memData.get("elgEndDateHealth4");
			memsData.get(memIndex).elgBegDateDental4 = memData.get("elgBeginDateDental4");
			memsData.get(memIndex).elgEndDateDental4 = memData.get("elgEndDateDental4");
			
			memsData.get(memIndex).transactionType5 = memData.get("transactionType5");
			memsData.get(memIndex).maintainenceTypeCode5 = memData.get("maintainenceTypeCode5");
			memsData.get(memIndex).maintainenceReasonCode5 = memData.get("maintainenceReasonCode5");
			memsData.get(memIndex).elgBegDateHealth5 = memData.get("elgBeginDateHealth5");
			memsData.get(memIndex).elgEndDateHealth5 = memData.get("elgEndDateHealth5");
			memsData.get(memIndex).elgBegDateDental5 = memData.get("elgBeginDateDental5");
			memsData.get(memIndex).elgEndDateDental5 = memData.get("elgEndDateDental5");
			
			memsData.get(memIndex).racdetails1 = memData.get("racdetail1");
			
			memsData.get(memIndex).type1 = memData.get("type1");
			memsData.get(memIndex).type2 = memData.get("type2");
			memsData.get(memIndex).type3 = memData.get("type3");
			memsData.get(memIndex).type4 = memData.get("type4");
			memsData.get(memIndex).type5 = memData.get("type5");
			
			memsData.get(memIndex).qtype1 = memData.get("qtype1");
			memsData.get(memIndex).qtype2 = memData.get("qtype2");
			memsData.get(memIndex).qtype3 = memData.get("qtype3");
			memsData.get(memIndex).qtype4 = memData.get("qtype4");
			memsData.get(memIndex).qtype5 = memData.get("qtype5");
			
		}
	}
	
	public ServiceData getServiceData(HashMap<String, String> ed) {
		ServiceData service = new ServiceData();
		
		service.individualByPassUsps = ed.get("Individual_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		service.agentByPassUsps = ed.get("Agent_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		service.assisterByPassUsps = ed.get("Assister_ByPassUsps").equalsIgnoreCase(TrueFalseValue.TRUE.val)?true:false;
		
		return service;
	}
	
	public void printEnrollmentData() throws Exception {
		Class<?> c = this.getClass();
		Field[] field = c.getDeclaredFields();

		for(int fCounter = 0; fCounter < field.length; fCounter++){	    	   
			String fieldName = field[fCounter].getName();
	    	   
			if(fieldName.equals("optumIdData")){
				optumIdData.printOptumIdData();
			}else if(fieldName.equals("memsData")){
				if(memCount == null) continue;
	    		   
				for(int mCounter = 0; mCounter < memCount; mCounter++){
					System.out.println("############### Enrollment Data for Member [" + (mCounter + 1) + "] ###############");
					memsData.get(mCounter).printMemberData();
				}
			}else if(fieldName.equals("serviceData")){
				serviceData.printServiceData();
			}else{
				Object fieldValue = c.getDeclaredField(fieldName).get(this);
	    		   
				if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float){
					if(fieldValue != null){
						System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
					} 
				}
			}
	    }
	}
}