package appdata.enrollment;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import appdata.common.AddressData;
import enums.DeductionType;
import enums.InsurancePolicySource;

public class Enrollment_MemData {
	
	public String variant;
	public String gpHealthPlan;
	public String gpDentalPlan;
	
	public String subscriber;
	
	public Boolean loseHiCoverage;
	public Boolean notPayingPremiums;
	public Boolean healthInsurance;
	
	public Boolean gainAdependent;
	public Boolean recentlyMarried;
	public Boolean birthInHousehold;
	public Boolean fosterCare;
	
	public Boolean lawfullyPresentImmigrant;
	public Boolean moveToMass;
	public Boolean recentlyReleasedFromPrison;
	public Boolean victimDomAbuseAban;
	
	public String transactionType1;
	public String maintainenceTypeCode1;
	public String maintainenceReasonCode1;
	public String elgBegDateHealth1;
	public String elgEndDateHealth1;
	public String elgBegDateDental1;
	public String elgEndDateDental1;
	
	public String transactionType2;
	public String maintainenceTypeCode2;
	public String maintainenceReasonCode2;
	public String elgBegDateHealth2;
	public String elgEndDateHealth2;
	public String elgBegDateDental2;
	public String elgEndDateDental2;

	public String transactionType3;
	public String maintainenceTypeCode3;
	public String maintainenceReasonCode3;
	public String elgBegDateHealth3;
	public String elgEndDateHealth3;
	public String elgBegDateDental3;
	public String elgEndDateDental3;
	
	
	public String transactionType4;
	public String maintainenceTypeCode4;
	public String maintainenceReasonCode4;
	public String elgBegDateHealth4;
	public String elgEndDateHealth4;
	public String elgBegDateDental4;
	public String elgEndDateDental4;
	
	public String transactionType5;
	public String maintainenceTypeCode5;
	public String maintainenceReasonCode5;
	public String elgBegDateHealth5;
	public String elgEndDateHealth5;
	public String elgBegDateDental5;
	public String elgEndDateDental5;
	
	public String racdetails1;
	
	public String type1;
	public String type2;
	public String type3;
	public String type4;
	public String type5;
	
	public String qtype1;
	public String qtype2;
	public String qtype3;
	public String qtype4;
	public String qtype5;
	
	

	public void printMemberData() throws Exception {	
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

	    for (Integer fCounter = 0; fCounter < field.length; fCounter++){    	   
    	   String fieldName = field[fCounter].getName();
    	   
    	   Object fieldValue = c.getDeclaredField(fieldName).get(this);
    		   
   		   if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float || fieldValue instanceof List ){
    		   if(fieldValue != null ){
    			   System.out.println(fieldName + ": [" + c.getDeclaredField(fieldName).get(this) + "]");  
    		   } 
   		   }
    	}
	}		
}
