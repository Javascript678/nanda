package appdata.evpd;

import java.lang.reflect.Field;
import java.util.List;

import appdata.common.AddressData;

public class ResponsiblePartyData {
	
	public String firstName;
	public String lastName;
	public String relationship;
	public Integer age;
	public String dob;
	public AddressData homeAddr = new AddressData();
	public String phoneNo;							
	
	public void printResponsiblePartyData() throws Exception {	
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();
	    
	    System.out.println("############### Responsible Party Data ###############");
	    
	    for (Integer fCounter = 0; fCounter < field.length; fCounter++){
    	   String fieldName = field[fCounter].getName();
    	   
    	   if(fieldName.equals("homeAddr")){
    		   homeAddr.printAddessData();
    	   }else{ 
        		Object fieldValue = c.getDeclaredField(fieldName).get(this);
        		
        		if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof List ){
        			if(fieldValue != null){
        				System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
        			} 
        		}
    	   }
    	}
	}
		
}
