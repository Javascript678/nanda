package appdata.evpd;

import java.lang.reflect.Field;

import appdata.common.AddressData;

public class CreateProfileData {
	
	public String firstName;
	public String middleName;
	public String lastName;
	public String ssn;
	public String dob;
	public String emailAddress;
	
	public Boolean noHomeAddressReqd;
	public AddressData homeAddr = new AddressData();
	
	public Boolean mailingAddressSameAsHomeAddress;
	public AddressData mailAddr = new AddressData();
	
	public String phoneNo;
	public String secondaryPhoneNo;
	
	public String spokenLang;
	public String writtenLang;
	
	public String appType;
	public String appReceiveDate;
	
	public Integer idProofingAns1Index;
	public Integer idProofingAns2Index;
	public Integer idProofingAns3Index;
	public Integer idProofingAns4Index;
	public Integer idProofingAns5Index;
	
	public Boolean profileAccHolder;		// asked in Start Application page
	
	public void printCreateProfileData() throws Exception{
		System.out.println("############### Create Profile Data ###############");	
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

       for (int fCounter =0; fCounter < field.length; fCounter++){
    	   
    	   String fieldName = field[fCounter].getName();
    	   if(fieldName.equals("homeAddr")){
    		   homeAddr.printAddessData();
    	   }else if(fieldName.equals("mailAddr")){
    		   mailAddr.printAddessData();
    	   }else{ 
    		   Object fieldValue = c.getDeclaredField(fieldName).get(this);
    		   if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float ){
    			   if(fieldValue != null ){
    				   System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
    			   } 
    		   }
		   }
       }		
	}
	
	
}
