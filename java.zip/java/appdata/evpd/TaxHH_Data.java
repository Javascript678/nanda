package appdata.evpd;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class TaxHH_Data {

	public String fplBasedOnSelfReportedIncome;
	public String fplUsedToDecidePE;
	
	public List<TaxHHMem_Data> memsData = new ArrayList<TaxHHMem_Data>();
	
	public void printGroupData() throws Exception{	
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

       for (Integer fCounter =0; fCounter < field.length; fCounter++){
    	   
    	    String fieldName = field[fCounter].getName();
    	    if(fieldName.equals("memsData")){
	    	Integer memCount = memsData.size();
	    	if(memCount == 0 ) continue;
			   for (int mCounter=0; mCounter < memCount; mCounter++) {
				   System.out.println("############   Data for Member [" + (mCounter +1) + "]############");
				   memsData.get(mCounter).printTaxHHMem_Data();
			   }
    		   
	    	}else{
	    		Object fieldValue = c.getDeclaredField(fieldName).get(this);
				   if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float || fieldValue instanceof List ){
					   if(fieldValue != null ){
						   System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
					   } 
				   }
	    	}
    	   }
	}
		
}
