package appdata.evpd;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import appdata.common.AddressData;
import enums.DeductionType;
import enums.InsurancePolicySource;

public class EVPD_MemData {

	public boolean isHOH = false;

	public String firstName;
	public String middleName = null;
	public String lastName;
	public String fullName;
	public String suffix;
	public String age;
	public Boolean isU10;
	public Boolean isU18;
	public Boolean isU19;
	public Boolean isU21;
	public String dob;
	public String emailId;
	public Boolean applyingForCov;

	public Boolean noHomeAddressReqd; // On Account holder Page
	public AddressData homeAddr = new AddressData(); // On Account holder Page
														// and IntendTOReside
														// Outside MA Page

	public Boolean livesInMA;
	public Boolean liveTemporaryOutsideMA;

	public Boolean mailingAddressSameAsHomeAddress; // On Account holder Page
	public AddressData mailAddr = new AddressData(); // On Account holder Page

	public String phoneNo; // On Account holder Page
	public String secondaryPhoneNo; // On Account holder Page

	public String spokenLang;
	public String writtenLang;

	public Boolean isMemberApplying = true;
	public Boolean isTaxHHMember;
	public Boolean filingTaxes;
	public Boolean married;
	public Boolean jointTaxFiling;
	public Boolean liveWithSpouse;
	public String spouseByIndex; // Such as 2
	public String dependentMembersByIndex;
	public Boolean claimAnyDependent;
	public Boolean claimedAsDependentOnSomeOneElse;

	public String gender; // M, F
	public Boolean hasSSN;
	public String ssn;
	public Boolean nameSameAsOnSSN;
	public String noSSNReason;
	public Boolean wantToProvideSSN; // Needed for family only Application

	public String immStatus;
	public Boolean isUSCitizen;
	public Boolean isNaturalCitizen;
	public Boolean isVeteran; // For UND
	public String alienNumber; // For None CIT and None UND
	public Boolean alientNameSameAsAppear;
	public Boolean arrivedInUSAfter1996;
	public Integer immStatusvlpErrorIndex; // QLP: AmerisianIndex, NQP-DACA,
											// ILP-Vias, QAB-LPR
	public String immStatusAwardDate; // For QAB

	public Boolean claimAnyDependentU19Member;
	public String dependentU19MembersByIndex;

	public String ethnicityList;
	public String raceList;

	public Boolean tempLivingOutsideMA;
	public String ousideMAZipCode;
	public String ousideMAZipCounty;

	public Boolean intendToResideMA;

	public Boolean isDisabled;
	public Boolean isAIAN;
	public String indoAmericanState;
	public String indoAmericanTribe;

	public Boolean isPregnant;
	public Integer prgBabyCount;
	public String babyDueDate;

	public Boolean fosterCare;
	public String fosterCareState;
	public Integer fosterCareLeftAge;

	public Boolean brestCancer;
	public Boolean hivPositive;

	public ArrayList<String> relation = new ArrayList<String>();

	public String relationWithM1;
	public String relationWithM2;
	public String relationWithM3;
	public String relationWithM4;
	public String relationWithM5;

	public ArrayList<String> secondaryRelation = new ArrayList<String>();

	public String secondaryRelationWithM1;
	public String secondaryRelationWithM2;
	public String secondaryRelationWithM3;
	public String secondaryRelationWithM4;
	public String secondaryRelationWithM5;

	public Integer parentCount;
	public boolean isParent;

	public ArrayList<Boolean> livingWith = new ArrayList<Boolean>();

	public boolean livingWithM1;
	public boolean livingWithM2;
	public boolean livingWithM3;
	public boolean livingWithM4;
	public boolean livingWithM5;

	public Boolean resonableAccNeeded;
	public String resonableAccType;

	public Boolean isInPrison;
	public Boolean awaitingTrial;

	public Boolean hasSourceOfIncome = false;
	public Integer jobSourceCount = 0;
	public String incomeTypes; // JOB, SELF_EMPLOYMENT, SOCIAL_SECURITY_BENEFITS

	public String jobEmployerName;
	public AddressData jobEmployerAddr = new AddressData();
	public String jobIncomeEffectiveDate;
	public Integer jobIncomeAmount;
	public String jobIncomeFrequency;
	public Integer jobIncomeHrsPerWeek;
	public Boolean jobSheltered = false;

	public String selfEmpWorkType;
	public Double selfEmpProfitAmountMonthly;
	public String selfEmpEffectiveDate;
	public Integer selfEmpHrsPerWeek;
	public Integer selfEmpAmntPerMonth;

	public Integer ssbAmt;
	public String ssbAmountFrequency;

	public Double capitalGainsMonthlyAmnt;
	public Double capitalGainsYearlyAmnt;

	public Integer interestAmt;
	public String interestAmountFrequency;

	public Integer UnemploymentAmt;
	public String UnemploymentAmountFrequency;

	public Integer RetirementAmt;
	public String RetirementSource;
	public String RetirementAmountFrequency;

	public boolean royaltyAmtType;
	public String royaltyAmountFrequency;
	public Integer royaltyAmtPerMonth;

	public String farmingAmountFrequency;
	public Integer farmingAmount;
	public String farmingDate;

	public Integer AlimonyAmt;
	public String AlimonyAmountFrequency;

	public Integer otherIncomeAmt;
	public String otherIncomeAmountFrequency;
	public String otherIncomeType;

	// Aashita
	public Boolean hasSourceOfDeduction = false;
	public String deductionTypes;

	// public Boolean deductionTypeAsNone = true;

	public Boolean deductionTypeAsEducator = false;
	public String deductionTypeAsEducatorAmt;

	public Boolean deductionTypeAsAlimonyPaid = false;
	public String deductionTypeAsAlimonyPaidAmt;

	public Boolean deductionTypeAsStdLoanIntrPaid = false;
	public String deductionTypeAsStdLoanIntrPaidAmt;

	public Boolean deductionTypeAsOther = false;
	public String deductionTypeAsOtherAmt;

	public Boolean deductionTypeAsBusinessExp = false;
	public String deductionTypeAsBusinessExpAmt;

	public Boolean deductionTypeAsHealthSavingDed = false;
	public String deductionTypeAsHealthSavingDedAmt;

	public Boolean deductionTypeAsMoveJobChange = false;
	public String deductionTypeAsMoveJobChangeAmt;

	public Boolean deductionTypeAsSelfEmployTax = false;
	public String deductionTypeAsSelfEmployTaxAmt;

	public Boolean deductionTypeAsSelfEmploySEP = false;
	public String deductionTypeAsSelfEmploySEPAmt;

	public Boolean deductionTypeAsHealthInsDed = false;
	public String deductionTypeAsHealthInsDedAmt;

	public Boolean deductionTypeAsPenaltyEarlywith = false;
	public String deductionTypeAsPenaltyEarlywithAmt;

	public Boolean deductionTypeAsIndRetirement = false;
	public String deductionTypeAsIndRetirementAmt;

	public Boolean deductionTypeAsHigherEdu = false;
	public String deductionTypeAsHigherEduAmt;

	public Boolean deductionTypeAsDomsProdDed = false;
	public String deductionTypeAsDomsProdDedAmt;

	public Boolean expectedYearlyIncomeSameAsCurrent = true;
	public Integer expectedYearlyIncomeAmtIfDiffr;

	// public String otherHltInsuranceRetirementPlans =
	// InsurancePolicySource.NONE_OF_THE_ABOVE.uiVal;
	public String otherHltInsuranceEmployerName;
	public AddressData otherHltInsuranceEmployerAddr = new AddressData();
	public String employerPrimaryPhoneNo = "8576661234";
	public String employerSecondaryPhoneNo = "8576661235";

	public Boolean enrolledInHealthInsurance = false;
	public Boolean offeredInHealthInsurance = false;

	// ESI COBRA RHI Employer Details Start
	public Boolean enrolledInESI = false;
	public Boolean offeredThroughJob = false;
	public Boolean enrolledInHPInCoverageYear = true;
	public String planName = "plan";
	public String policyNumber = "1234";
	public String otherMembersEnrolledInInsuranceByIndex = ""; // Such as "2,3"
	public Boolean insuranceExpChange = false;
	public Boolean insuranceMeetMinVal = false;
	public Boolean insuranceNoLongerOffered = false;
	public Boolean insuranceCanceled = false;
	// public String ESIOfferedPlanNumber;
	public Boolean insuranceCoverageAffordable = false;
	public String planPremiumCost = "1234";
	public String planPremiumFrequency = "Yearly";

	// ESI COBRA RHI Employer Details End
	public Boolean enrolledInCOBRA = false;
	public Boolean enrolledInRetiree = false;
	public Boolean enrolledInVeteran = false;
	// public String otherHltInsuranceMixedPlans =
	// InsurancePolicySource.NONE_OF_THE_ABOVE.uiVal;

	public Boolean enrolledInMassHealth = false;

	public Boolean enrolledInMedicare = false;
	public String medicarePolNo = "1234567";
	public String medicareCovStartDate;
	public String medicareCovEndDate;

	public Boolean enrolledInMedicaid = false;
	public String medicaidPolNo = "1234567";
	public String medicaidCovStartDate;
	public String medicaidCovEndDate;

	public Boolean enrolledInPeaceCorps = false;
	public String peaceCorpsPolNo = "1234567";
	public String peaceCorpsCovStartDate;
	public String peaceCorpsCovEndDate;

	public Boolean enrolledInTricare = false;
	public String tricarePolNo = "1234567";
	public String tricareCovStartDate;
	public String tricareCovEndDate;

	public Boolean enrolledInVaHp = false;
	public String vaPolNo = "1234567";
	public String vaCovStartDate;
	public String vaCovEndDate;

	public Boolean enrolledInOtherPlan = false;
	public String otherPlanName = "plan";
	public String otherPlanPolNo = "1234567";
	public String otherPlanStartDate;
	public String otherPlanEndDate;

	public Boolean healthReimbursementArr = false;
	public Boolean qsehraQulified = false;
	public Boolean ichraQulified = false;
	public Boolean acceptICHRABenefit = false;

	public Boolean enrolledNoHP = true;
	public Boolean enrolledNoHPMixed = true;

	public Boolean rfiInd = true;
	
	public Boolean ncpRfiRequired = false;
	public Boolean applyingForVoteToday;

	public Boolean medicallyFrail = false;
	public Boolean transitionalMedicalAssistance = false;

	public Integer magiHHSize;
	public Integer taxHHSize;
	public Integer taxHHIndex;
	public Integer taxHHMemIndex;
	public String memId;
	public String magiFPL;
	public String taxFPL;
	public Integer hhIncomeAmount;
	public Integer magiHhIncomeAmount; // Added by Brajesh

	public String mhProgramDetermination = "";
	public String mhAidCat = "";

	public String ccaProgramDetermination = "";
	public String ccaAidCat = "";

	public String paProgramDetermination = "";
	public String paAidCat = "";

	public String userRefId;
	public String elgId;
	public String appCreateDate;

	public void printMemberData() throws Exception {
		Class<?> c = this.getClass();
		Field[] field = c.getDeclaredFields();

		for (Integer fCounter = 0; fCounter < field.length; fCounter++) {
			String fieldName = field[fCounter].getName();

			if (fieldName.equals("homeAddr")) {
				homeAddr.printAddessData();
			} else if (fieldName.equals("mailAddr")) {
				mailAddr.printAddessData();
			} else if (fieldName.equals("jobEmployerAddr")) {
				jobEmployerAddr.printAddessData();
			} else {
				Object fieldValue = c.getDeclaredField(fieldName).get(this);

				if (fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean
						|| fieldValue instanceof Float || fieldValue instanceof List) {
					if (fieldValue != null) {
						System.out.println(fieldName + ": [" + c.getDeclaredField(fieldName).get(this) + "]");
					}
				}
			}
		}
	}
}
