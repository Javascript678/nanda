package appdata.evpd;

import java.lang.reflect.Field;
import java.util.List;

public class TaxHHMem_Data {

	public String programEligibility;
	public String proofRequired;
	public String PE_Status;
	
	public void printTaxHHMem_Data() throws Exception{	
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

       for (Integer fCounter =0; fCounter < field.length; fCounter++){
    	   
    	    String fieldName = field[fCounter].getName();
			Object fieldValue = c.getDeclaredField(fieldName).get(this);
			   if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float || fieldValue instanceof List ){
				   if(fieldValue != null ){
					   System.out.println(fieldName + ":  [" + c.getDeclaredField(fieldName).get(this) + "]");  
				   } 
			   }
    	   }
	}
		
}
