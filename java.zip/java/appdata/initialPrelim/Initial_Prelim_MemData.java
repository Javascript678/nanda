package appdata.initialPrelim;

import java.lang.reflect.Field;
import java.util.List;

public class Initial_Prelim_MemData {
	
	public Boolean hasDisability = false;
	public String rrvSsaDisability;
	
	public Boolean hasDeath = false;
	public String rrvSsaDeath;
	
	public Boolean hasTitleIiIncome = false;
	public String rrvSsaTitleIiIncome;
	
	public Boolean hasIrsIncome = false;
	public String rrvIrsIncome;
	
	public Boolean hasIrsSsbIncome = false;
	public String rrvIrsSsbIncome;
	
	public Boolean hasDorResponse = false;
	public String dorResponse;
	
	public String rrvMec;
	
	public void printMemberData() throws Exception {	
		Class<?> c = this.getClass();
	    Field[] field = c.getDeclaredFields();

	    for (Integer fCounter = 0; fCounter < field.length; fCounter++){    	   
    	   String fieldName = field[fCounter].getName();
    	   
    	   Object fieldValue = c.getDeclaredField(fieldName).get(this);
    		   
   		   if(fieldValue instanceof String || fieldValue instanceof Integer || fieldValue instanceof Boolean || fieldValue instanceof Float || fieldValue instanceof List ){
    		   if(fieldValue != null ){
    			   System.out.println(fieldName + ": [" + c.getDeclaredField(fieldName).get(this) + "]");  
    		   } 
   		   }
    	}
	}		
}
