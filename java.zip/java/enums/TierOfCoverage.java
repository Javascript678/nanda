package enums;

import java.util.ArrayList;
import java.util.List;

public enum TierOfCoverage {
	
	BLANK("",""),		// Blank Means Family
	I("I","Individual"),
	F("F","Family"),
	C("C","Couple"),
	D("D","Dual");
	
    public final String code;
    public final String dropDownVal;
    
    private TierOfCoverage(String code,String dropDownVal) {
        this.code = code;
        this.dropDownVal = dropDownVal;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	TierOfCoverage[] arrValues = TierOfCoverage.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownVal(String code) {
    	TierOfCoverage[] arrValues = TierOfCoverage.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){

    		return 	arrValues[i].dropDownVal;
    		}
    	}
    	return null;
    }
}