package enums;

import java.util.ArrayList;
import java.util.List;

public enum Race {
	AMERICAN_INDIAN_OR_ALASKA_NATIVE("AIAN","AMERICAN_INDIAN_OR_ALASKA_NATIVE"),
	ASIAN_INDIAN("AI","ASIAN_INDIAN"),
	AFRICAN_AMERICAN("AA", "AFRICAN_AMERICAN"),
	CHINESE("CH", "CHINESE"),
	FILIPINO("FP", "FILIPINO"),
	GUAMANIAN_OR_CHAMORRO("GC", "GUAMANIAN_OR_CHAMORRO"),
	JAPANESE("JP", "JAPANESE"),
	KOREAN("KR", "KOREAN"),
	Native_Hawaiian("NH", "Native_Hawaiian"),
	OTHER_ASIAN("OA", "OTHER_ASIAN"),
	OTHER_PACIFIC_ISLANDER("OP", "OTHER_PACIFIC_ISLANDER"),
	SAMOAN("SM", "SAMOAN"),
	VIETNAMESE("VT", "VIETNAMESE"),
	WHITE("WH", "WHITE");

	public final String code;
    public final String val;
    
    private Race(String code, String val) {
        this.code = code;
        this.val = val;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	Race[] arrValues = Race.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getVal(String code) {
    	Race[] arrValues = Race.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].val;
    		}
    	}
    	return null;
    }
}