package enums;

import java.util.ArrayList;
import java.util.List;

public enum AgentUserType {

	BLANK(""),			// Blank Means BO User
    BO_USER("BO"),
    CSR_USER("CSR"),
	SSN_ONLY_USER("SSN");
    
    public final String code;
    private AgentUserType(String code) {
        this.code = code;
    }
    public static List<String> getCodes() {
    	List<String> names = new ArrayList<String>();
    	AgentUserType[] arrValues = AgentUserType.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].code);
    	}
    	return names;
    }
}