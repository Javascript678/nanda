package enums;

import java.util.ArrayList;
import java.util.List;

public enum AppTypeName {
    PAPER("Paper"),
    TELEPHONE("Telephone"),
    OTHER("Other"),
    DEFAULT("");
    
    public final String val;
    private AppTypeName(String identifier) {
        this.val = identifier;
    }
    public static List<String> getNames() {
    	List<String> names = new ArrayList<String>();
    	AppTypeName[] arrValues = AppTypeName.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].val);
    	}
    	return names;
    }
}