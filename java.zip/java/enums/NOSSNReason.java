package enums;

import java.util.ArrayList;
import java.util.List;

public enum NOSSNReason {
      
	JUST_APPLIED("JA","Just Applied");
	
	
	public final String code;
    public final String val;
    
    private NOSSNReason(String code, String val) {
        this.code = code;
        this.val = val;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	NOSSNReason[] arrValues = NOSSNReason.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownValue(String code) {
    	NOSSNReason[] arrValues = NOSSNReason.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].val;
    		}
    	}
    	return null;
    }
}