package enums;

import java.util.ArrayList;
import java.util.List;

public enum BrowserName {
    FF("FirefoxBrowser"),
    IE("IEBrowser"),
    CHROME("ChromeBrowser"),
    SAUCE_LAB_FF("SauceLabFF");
    
    public final String val;
    private BrowserName(String val) {
        this.val = val;
    }
    public static List<String> getNames() {
    	List<String> names = new ArrayList<String>();
    	BrowserName[] arrValues = BrowserName.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].val);
    	}
    	return names;
    }
}