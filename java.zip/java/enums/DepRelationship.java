package enums;

import java.util.ArrayList;
import java.util.List;

public enum DepRelationship {
    
	UNCLE_AUNT(1, "UA", "Uncle/Aunt"),
	STEPPARENT(2, "STP", "Stepparent"),
	STEPCHILD(3, "STC", "Stepchild"),
	SIBLING_STEP_SIBLING(4, "SBL", "Sibling/Stepsibling"),
	PARENTS_DOMESTIC_PARTNER(5, "PDP", "Parent's�domestic partner"),
	PARENT(6, "PRT", "Parent"),
	OTHER_UNRELATED(7, "OUR", "Other unrelated"),
	OTHER_RELATIVE(8, "ORL", "Other relative"),
	NEPHEW_NIECE(9, "NN", "Nephew/Niece"),
	GRAND_PARENT(10, "GP","Grandparent"),
	GRAND_CHILD(11, "GC", "Grandchild"),
	DOMESTIC_PARTNER(12, "DP", "Domestic�partner"),
	COUSIN(13, "CSN", "Cousin"),
	CHILD_OF_PARENTS_DOMESTIC_PARTNER(14, "CPD", "Child�of parent's domestic partner"),
	CHILD(15, "CHD", "Child");
	
	public final int index;
	
	public final String code;
    public final String dropDownVal;
    
    private DepRelationship(int index, String code, String dropDownVal) {
    	this.index = index;
        this.code = code;
        this.dropDownVal = dropDownVal;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	DepRelationship[] arrValues = DepRelationship.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownVal(String code) {
    	DepRelationship[] arrValues = DepRelationship.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    			return 	arrValues[i].dropDownVal;
    		}
    	}
    	return null;
    }
    
    public static int getIndex(String code) {
    	DepRelationship[] arrValues = DepRelationship.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    			return 	arrValues[i].index;
    		}
    	}
    	return (Integer) null;
    }
}