package enums;

import java.util.ArrayList;
import java.util.List;

public enum PrimaryProgaramType {
      
	CHIP("CHP","MassHealth Children's Health Insurance Program (CHIP)"),
	HCP("HCP", "Health Connector Plans"),
	MH("MH", "MassHealth"),
	HCP_W_APTC("HVPAPTC", "Health Connector Plans with Advance Premium Tax Credit"),
	CCA("CCA", "ConnectorCare Plans (Advance Premium Tax Credit plus Massachusetts state subsidy)");

	public final String code;
    public final String dropDownVal;
    
    private PrimaryProgaramType(String code, String dropDownVal) {
        this.code = code;
        this.dropDownVal = dropDownVal;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	PrimaryProgaramType[] arrValues = PrimaryProgaramType.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownVal(String code) {
    	PrimaryProgaramType[] arrValues = PrimaryProgaramType.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].dropDownVal;
    		}
    	}
    	return null;
    }
}