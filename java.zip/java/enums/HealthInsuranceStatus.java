package enums;

import java.util.ArrayList;
import java.util.List;

public enum HealthInsuranceStatus {
	
	I("I","I - Investigated for the purpose of Premium Assistance"),
	U("U","U - Uninsured"),
	Y("Y","Y - Verified by TPL Worker"),
	S("S","S - Self Declared");

	
    public final String code;
    public final String dropDownVal;
    
    private HealthInsuranceStatus(String code,String mmisValue) {
        this.code = code;
        this.dropDownVal = mmisValue;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	HealthInsuranceStatus[] arrValues = HealthInsuranceStatus.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownValue(String code) {
    	HealthInsuranceStatus[] values = HealthInsuranceStatus.values();
    	for(int i=0; i< values.length;i++){
    		if(values[i].code.equals(code)){
    			return values[i].dropDownVal;
    		}
    	}
    	return null;
    }
}