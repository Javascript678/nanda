package enums;

import java.util.ArrayList;
import java.util.List;

public enum InsurancePolicySource2 {
	
	ESI("JOB","Current Job"),
	COBRA("COBRA","COBRA"),
	RETIREE_HEALTH_PLAN("RETIREE","Retiree Health Plan"),
	MEDICARE("MEDICARE","Medicare"),
	MEDICAID("MEDICAID","Medicaid"),
	PEACE_CORPS("PCHB","Peace Corps Health Benefits"),
	TRICARE("TRICARE","TRICARE Federal Employees Health Benefit Program"),
	VA_HEALTH_PROGRAM("VAHP","Veterans Affairs (VA) Health Program"),
	OTHER("OTHER", "Other");

	
    public final String code;
    public final String uiVal;
    
    private InsurancePolicySource2(String code, String uiValue) {
        this.code = code;
        this.uiVal = uiValue;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	InsurancePolicySource2[] arrValues = InsurancePolicySource2.values();
    	for(int i = 0; i < arrValues.length; i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getuiValue(String code) {
    	InsurancePolicySource2[] values = InsurancePolicySource2.values();
    	for(int i = 0; i < values.length; i++){
    		if(values[i].code.equals(code)){
    			return values[i].uiVal;
    		}
    	}
    	return null;
    }
}