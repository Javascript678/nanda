package enums;

import java.util.ArrayList;
import java.util.List;

public enum GenderType {
    MALE("M"),
    FEMALE("F");
    
    public final String code;
    private GenderType(String code) {
        this.code = code;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	GenderType[] arrValues = GenderType.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
}