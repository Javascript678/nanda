package enums;

import java.util.ArrayList;
import java.util.List;

public enum ImmStatus {
	
	CIT("CIT","C"),
	CITN("CITN","C"),
	QLP("QLP","M"),
	QAB("QAB","B"),
	ILP("ILP","I"),
	NQP("NQP", "P"),
	UND("UND", "N");
	
    public final String code;
    public final String mmisValue;
    
    private ImmStatus(String code,String mmisValue) {
        this.code = code;
        this.mmisValue = mmisValue;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	ImmStatus[] arrValues = ImmStatus.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getMMISValue(String code) {
    	ImmStatus[] values = ImmStatus.values();
    	for(int i=0; i< values.length;i++){
    		if(values[i].code.equals(code)){
    			return values[i].mmisValue;
    		}
    	}
    	return null;
    }
}