package enums;

import java.util.ArrayList;
import java.util.List;

public enum PA_HealthInsuranceStatus {
	
	U("U", "U - Uninsured"),
	I("I", "I - Investigated for the purpose of Premium Assistance"),
	Y("Y", "Y - Verified by TPL Worker"),
	S("S", "S - Self Declared");
	
	public final String code;
    public final String healthInsuranceStatus;
    
    private PA_HealthInsuranceStatus(String code, String healthInsuranceStatus) {
        this.code = code;
        this.healthInsuranceStatus = healthInsuranceStatus;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	PA_HealthInsuranceStatus[] arrValues = PA_HealthInsuranceStatus.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getHealthInsuranceStatus(String code) {
    	PA_HealthInsuranceStatus[] arrValues = PA_HealthInsuranceStatus.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		if(arrValues[i].code.equals(code)){
    			return 	arrValues[i].healthInsuranceStatus;
    		}
    	}
    	return null;
    }   
}