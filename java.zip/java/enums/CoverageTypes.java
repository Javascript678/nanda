package enums;

import java.util.ArrayList;
import java.util.List;

public enum CoverageTypes {
	
	BLANK("",""),		// Blank Means 02 - Major Medical
	MM("MM","02 - Major Medical"),
	SP("SP","06 - Supplemental Policy"),
	HMO("HMO","11 - Health Maintenance Organization (HMO)"),
	V("V","12 - Vision"),
	DC("DC","13 - Dental Care"),
	MR("MR","56 - HMO-Medicare Risk"),
	PPO("PPO","14 - Preferred Provider Organization (PPO)"),
	PH("PH","17 - Pharmacy - Cost Avoid"),
	H("H","01 - Hospital"),
	MA("MA","04 - Medicare Part A"),
	MB("MB","05 - Medicare Part B"),
	LTC("LTC","08 - Long Term Care"),
	HMOMH("HMOMH","09 - HMO without Mental Health"),
	PHPC("PHPC","18 - Pharmacy - Pay and Chase"),
	CMH("CMH","35 - Commercial Insurance Without Mental Health"),
	HMOR("HMOR","57 - HMO-Medicare Risk (Evercare)"),
	VSN("VSN","63 - Veterans Services (Noncomprehensive)"),
	VSC("VSC","64 - Veterans Services (Comprehensive)"),
	MH("MH","98 - Medicare Hospice"),
	MD("MD","99 - Medicare Part D");
	
	
    public final String code;
    public final String dropDownVal;
    
    private CoverageTypes(String code,String dropDownVal) {
        this.code = code;
        this.dropDownVal = dropDownVal;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	CoverageTypes[] arrValues = CoverageTypes.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownVal(String code) {
    	CoverageTypes[] arrValues = CoverageTypes.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){

    		return 	arrValues[i].dropDownVal;
    		}
    	}
    	return null;
    }
}