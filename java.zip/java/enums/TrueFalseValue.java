package enums;

import java.util.ArrayList;
import java.util.List;

public enum TrueFalseValue {
    TRUE("true"),
    FALSE("false");
	
    public final String val;
    
    private TrueFalseValue(String val) {
        this.val = val;
    }
    public static List<String> getNames() {
    	List<String> names = new ArrayList<String>();
    	TrueFalseValue[] arrValues = TrueFalseValue.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].val);
    	}
    	return names;
    }
}