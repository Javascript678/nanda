package enums;

import java.util.ArrayList;
import java.util.List;

public enum QualifyingLifeEvent {
	DEP_CHANGE("DEP_CHANGE"),
	IMM_CHANGE("IMM_CHANGE"),
	ADDRESS_CHANGE("ADDRESS_CHANGE"),
	INCARCERATION_CHANGE("INCARCERATION_CHANGE"),
	DOM_ABUSE_CHANGE("DOM_ABUSE_CHANGE");

    public final String val;
    private QualifyingLifeEvent(String val) {
        this.val = val;
    }
    public static List<String> getNames() {
    	List<String> names = new ArrayList<String>();
    	QualifyingLifeEvent[] arrValues = QualifyingLifeEvent.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].val);
    	}
    	return names;
    }
}