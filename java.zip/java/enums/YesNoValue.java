package enums;

import java.util.ArrayList;
import java.util.List;

public enum YesNoValue {
    YES("Y"),
    NO("N");
	
    public final String code;
    private YesNoValue(String code) {
        this.code = code;
    }
    public static List<String> getCodes() {
    	List<String> names = new ArrayList<String>();
    	YesNoValue[] arrValues = YesNoValue.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].code);
    	}
    	return names;
    }
}