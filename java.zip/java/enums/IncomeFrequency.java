package enums;

import java.util.ArrayList;
import java.util.List;

public enum IncomeFrequency {
	WEEKLY("WK","Weekly"),
	MONTHLY("MN","Monthly"),
	QUARTERLY("QR","Quarterly"),
	YEARLY("YR","Yearly"),
    EVERY_TWO_WEEK("2W","Every two weeks"),
    TWICE_A_MONTH("2M","Twice a month"),
    EVERY_OTHER_MONTH("OM","Every other month"),
    TWICE_A_YEAR("2Y","Twice a year"),
    ONE_TIME_ONLY("OT","One time only"),
    SEASONAL_INCOME("SI","Seasonal Income");	
	
	public final String code;
    public final String val;
    
    private IncomeFrequency(String code, String val) {
        this.code = code;
        this.val = val;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	
    	IncomeFrequency[] arrValues = IncomeFrequency.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		codes.add(arrValues[i].code);
    	}
    	
    	return codes;
    }
    
    public static String getVal(String code) {
    	IncomeFrequency[] arrValues = IncomeFrequency.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		if(arrValues[i].code.equals(code)){
    			return 	arrValues[i].val;
    		}
    	}
    	
    	return null;
    }
}