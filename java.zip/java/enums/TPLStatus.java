package enums;

import java.util.ArrayList;
import java.util.List;

public enum TPLStatus {
	
	P("P"),
	A("A"),
	I("I"),
	U("U");

	
    public final String code;
    
    private TPLStatus(String code) {
        this.code = code;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	TPLStatus[] arrValues = TPLStatus.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
}