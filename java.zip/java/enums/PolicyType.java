package enums;

import java.util.ArrayList;
import java.util.List;

public enum PolicyType {
	BLANK("",""),		// Blank Means Medical
	M("M","Medical"),
	D("D","Dental"),
	C("C","Catastrophic"),
	V("V","Vision"),
	P("P","Pharmacy");
	
    public final String code;
    public final String dropDownVal;
    
    private PolicyType(String code,String dropDownVal) {
        this.code = code;
        this.dropDownVal = dropDownVal;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	PolicyType[] arrValues = PolicyType.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownVal(String code) {
    	PolicyType[] arrValues = PolicyType.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){

    		return 	arrValues[i].dropDownVal;
    		}
    	}
    	return null;
    }
}