package enums;

import java.util.ArrayList;
import java.util.List;

public enum VerifyRFI {
	
    INCOME("INC","Income"),
    ADDRESS("ADR","Address"),
    IMMIGRATION("IMM","Immigration"),
    SSN("SSN","SSN"),
    INCARCERATION("INCAR","Incarceration"),
    AIAN("AIAN","American Indian OR Alaska Native"),
    CITIZENSHIP("CIT","Citizenship"),
    NCP("NCP","Non-Custodial Parent Form");
    
	public final String code;
    public final String valueOnUI;
    
    private VerifyRFI(String code, String valueOnUI) {
        this.code = code;
        this.valueOnUI = valueOnUI;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	VerifyRFI[] arrValues = VerifyRFI.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String get_UI_Val(String code) {
    	VerifyRFI[] arrValues = VerifyRFI.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].valueOnUI;
    		}
    	}
    	return null;
    }
}