package enums;

import java.util.ArrayList;
import java.util.List;

public enum DepSecondaryRelationship {
    
	FORMER_SPOUSE(1, "FSP", "Former�Spouse"),
	FOSTER_CHILD(2, "FCH", "Foster�child"),
	GUARDIAN(3, "GRD", "Guardian"),
	OTHER_RELATIVE(4, "ORL", "Other relative"),
	UNRELATED(5, "UNR", "Unrelated"),
	WARD(6, "WD", "Ward");

	public final int index;
	
	public final String code;
    public final String dropDownVal;
    
    private DepSecondaryRelationship(int index, String code, String dropDownVal) {
    	this.index = index;
        this.code = code;
        this.dropDownVal = dropDownVal;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	DepSecondaryRelationship[] arrValues = DepSecondaryRelationship.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownVal(String code) {
    	DepSecondaryRelationship[] arrValues = DepSecondaryRelationship.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    			return 	arrValues[i].dropDownVal;
    		}
    	}
    	return null;
    }
    
    public static int getIndex(String code) {
    	DepSecondaryRelationship[] arrValues = DepSecondaryRelationship.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    			return 	arrValues[i].index;
    		}
    	}
    	return (Integer) null;
    }
}