package enums;

import java.util.ArrayList;
import java.util.List;

public enum TestDataSheetName {
	
    EVPD("EVPD"),
    VERIFY_RFI1("Verify_RFI1"),
    VERIFY_RFI2("Verify_RFI2"),
    VERIFY_RFI3("Verify_RFI3"),
    QLE1("QLE1"),
    QLE2("QLE2"),
    QLE3("QLE3"),
    SHOPPING1("Shopping1"),
    SHOPPING2("Shopping2"),
    SHOPPING3("Shopping3"),
    ENB1("ENB1"),
    ENB2("ENB2"),
    ENB3("ENB3"),
    MMIS1("MMIS1"),
    MMIS2("MMIS2"),
    MMIS3("MMIS3"),
    RAC1("RAC1"),
	RAC2("RAC2"),
	RAC3("RAC3"),
	NOTICE1("Notice1"),
	NOTICE2("Notice2"),
	NOTICE3("Notice3"),
	PA_EMPLOYER1("PA_Employer1"),
	PA_EMPLOYER2("PA_Employer2"),
	PA_EMPLOYER3("PA_Employer3"),
	PA_ADMIN1("PA_Admin1"),
	PA_ADMIN2("PA_Admin2"),
	PA_ADMIN3("PA_Admin3"),
	PA_POLICY1("PA_Policy1"),
	PA_POLICY2("PA_Policy2"),
	PA_POLICY3("PA_Policy3"),
	ADM_CLOSURE1("Adm_Closure1"),
	ADM_CLOSURE2("Adm_Closure2"),
	ADM_CLOSURE3("Adm_Closure3"),
	UPDATE_SSN1("UpdateSSN1"),
	UPDATE_SSN2("UpdateSSN2"),
	UPDATE_SSN3("UpdateSSN3");
	
	public final String val;
    
    private TestDataSheetName(String val) {
        this.val = val;
    }
    public static List<String> getNames() {
    	List<String> names = new ArrayList<String>();
    	TestDataSheetName[] arrValues = TestDataSheetName.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].val);
    	}
    	return names;
    }
}