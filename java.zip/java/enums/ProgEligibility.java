package enums;

import java.util.ArrayList;
import java.util.List;

public enum ProgEligibility {
	
	NE("NE", "Not Eligible"),
	MH("MH", "Mass Health"),
	MHCP("MHCP","MassHealth CarePlus");
	
	public final String code;
    public final String valueOnUI;
    
    private ProgEligibility(String code, String valueOnUI) {
        this.code = code;
        this.valueOnUI = valueOnUI;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	ProgEligibility[] arrValues = ProgEligibility.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String get_UI_Val(String code) {
    	ProgEligibility[] arrValues = ProgEligibility.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].valueOnUI;
    		}
    	}
    	return null;
    }
}