package enums;

import java.util.ArrayList;
import java.util.List;

public enum InsuranceFrequency {
	
	WEEK("WK","Week"),
	TWO_WEEKS("2W","2 Weeks"),
	TWICE_PER_MONTH("2M","Twice per month"),
	MONTH("MN","Month"),
	YEAR("YR","Year");
	
	
	public final String code;
    public final String val;
    
    private InsuranceFrequency(String code, String val) {
        this.code = code;
        this.val = val;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	InsuranceFrequency[] arrValues = InsuranceFrequency.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getVal(String code) {
    	InsuranceFrequency[] arrValues = InsuranceFrequency.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].val;
    		}
    	}
    	return null;
    }
}