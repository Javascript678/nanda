package enums;

import java.util.ArrayList;
import java.util.List;

public enum AidCat_Acc_Dashboard {
//    FOURTY_THREE("43"),
//    FOURTY_TWO("42"),
//    EP("EP"),						// PA for 42
//    A1("A1"),
//    A4("A4"),						// PA for A1
      D1("D1","D1 - MassHealth CarePlus"),
//    D4("D4"),						// PA for D1
//    M1("M1"),
//    M4("M4"),						// PA for M1
      L1("L1","L1 - MassHealth Standard"),
//    L4("L4"),						// PA for L1
//    H1("H1"),
//    H4("H4"),						// PA for H1
//    J1("J1"),
//    J4("J4"),						// PA for J1
//    FOURTY_EIGHT("48"),
//    EJ("EJ"),						// PA for 48
      EK("EK","EK - MassHealth Standard"),						// PA for 40 and 48
      FOURTY("40","40 - MassHealth Standard"),
//    AD("AD"),
//    T1("T1"),
//    T4("T4"),						//PA for T1
//    B1("B1"),
      B4("B4","B4 - MassHealth Standard"),						//PA for B1
//    EIGHTEEN("18"),
//    FOURTY_SIX("46"),
//    A9("A9"),						//PA for 46
//    FIFTY("50"),
//    EL("EL"),						//PA for 50
//    EM("EM"),						//PA for 50
//    FIFTY_ONE("51"),
//    EN("EN"),						//PA for 51
//    E1("E1"),
//    E4("E4"),						//PA for E1
//    R1("R1"),
//    R4("R4"),						//PA for R1
      NINETY_THREE("93","93 - MassHealth Family Assistance"),
//    SEVENTY_FIVE("75"),				//PA for 93
//    SEVENTY_EIGHT("78"),			//PA for 93
//    EIGHTY_FOUR("84"),				
      EIGHTY_SIX("86","86 - MassHealth Family Assistance"),				//PA for 84	
//    N1("N1"),
//    NINETY_FIVE("95"),
//    SIXTY_FIVE("65"),				//PA for 95
//    U3("U3"),
//    NINETY("90"),
//    V2("V2"),						//PA for 90
//    Q1("Q1"),
//    AX("AX"),
//    THIRTY_SEVEN("37"),
//    AY("AY"),
//    BA("BA"),
    ONE_X("1X","1X - Temporary Health Safety Net"),
    ONE_Y("1Y","1Y - Temporary Health Safety Net"),
//    Z3("Z3"),
//    Z4("Z4"),
//    AQ("AQ"),
    AP("AP","AP - Health Safety Net Partial"),
    NA("NA","Not Eligible");

	public final String code;
    public final String valueOnUI;
    
    private AidCat_Acc_Dashboard(String code, String valueOnUI) {
        this.code = code;
        this.valueOnUI = valueOnUI;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	AidCat_Acc_Dashboard[] arrValues = AidCat_Acc_Dashboard.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String get_UI_Val(String code) {
    	AidCat_Acc_Dashboard[] arrValues = AidCat_Acc_Dashboard.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].valueOnUI;
    		}
    	}
    	return null;
    }
}