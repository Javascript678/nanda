package enums;

import java.util.ArrayList;
import java.util.List;

public enum Ethnicity {
	PUERTO_RICAN("PR","Puerto_Rican"),
	CUBAN("CB","Cuban"),
	MEXICAN("MX", "Mexican_Mexican American_or_Chicanoa");
	
	public final String code;
    public final String val;
    
    private Ethnicity(String code, String val) {
        this.code = code;
        this.val = val;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	Ethnicity[] arrValues = Ethnicity.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getVal(String code) {
    	Ethnicity[] arrValues = Ethnicity.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].val;
    		}
    	}
    	return null;
    }
}