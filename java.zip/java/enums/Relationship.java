package enums;

import java.util.ArrayList;
import java.util.List;

public enum Relationship {
      
	SELF("SLF","Self"),
	SPOUSE("SP", "Spouse"),
	DOMESTIC_PARTNER("DP", "Domestic partner"),
	CHILD("CHD", "Child"),
	GRAND_CHILD("GC", "Grandchild"),
	PARENT("PRT", "Parent"),
	GRAND_PARENT("GP","Grandparent"),
	SIBLING_STEP_SIBLING("SBL", "Sibling/Stepsibling"),
	UNRELATED("UNR", "Unrelated"),
	CHILD_IN_LAW("CIL", "Child-in-law"),
	COUSIN("CSN", "Cousin"),
	FORMER_SPOUSE("FSP", "Former spouse"),
	FOSTER_CHILD("FCH", "Foster child"),
	FOSTER_PARENT("FPT", "Foster parent"),
	GUARDIAN("GRD", "Guardian"),
	NEPHEW_NIECE("NN", "Nephew/Niece"),
	OTHER_RELATIVE("ORL", "Other relative"),
	OTHER_UNRELATED("OUR", "Other unrelated"),
	PARENT_IN_LAW("PIL", "Parent-in-law"),
	SIBLING_IN_LAW("SIL", "Sibling-in-law"),
	STEPCHILD("STC", "Stepchild"),
	STEPPARENT("STP", "Stepparent"),
	UNCLE_AUNT("UA", "Uncle/Aunt"),
	WARD("WD", "Ward"),
	CHILD_OF_PARENTS_DOMESTIC_PARTNER("CPD", "Child of parent's domestic partner"),
	PARENTS_DOMESTIC_PARTNER("PDP", "Parent's Domestic Partner");

	public final String code;
    public final String dropDownVal;
    
    private Relationship(String code, String dropDownVal) {
        this.code = code;
        this.dropDownVal = dropDownVal;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	Relationship[] arrValues = Relationship.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownVal(String code) {
    	Relationship[] arrValues = Relationship.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].dropDownVal;
    		}
    	}
    	return null;
    }
}