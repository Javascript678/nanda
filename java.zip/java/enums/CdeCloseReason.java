package enums;

import java.util.ArrayList;
import java.util.List;

public enum CdeCloseReason {
    A_SIX("A6"),
    FORTY_EIGHT("48");
	
	public final String code;
	
    private CdeCloseReason(String code) {
        this.code = code;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	CdeCloseReason[] arrValues = CdeCloseReason.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
}