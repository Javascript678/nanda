package enums;

import java.util.ArrayList;
import java.util.List;

public enum RACType {

	ADD_MEMBER("ADD_MEMBER"),
	REMOVE_MEMBER("REMOVE_MEMBER"),
	UPDATE_INCOME("UPDATE_INCOME"),
	CHANGE_STATUS("CHANGE_STATUS"),
	CHANGE_HOME_ADDR("CHANGE_HOME_ADDR"),
	CHANGE_ADDITIONAL_QUE("CHANGE_ADDITIONAL_QUE"),
	CHANGE_APP_TYPE("CHANGE_APP_TYPE"),
	CHANGE_TAX_CREDIT("CHANGE_TAX_CREDIT");

    public final String code;
    private RACType(String code) {
        this.code = code;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	RACType[] arrValues = RACType.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
}