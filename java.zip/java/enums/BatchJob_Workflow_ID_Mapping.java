package enums;

import java.util.ArrayList;
import java.util.List;

public enum BatchJob_Workflow_ID_Mapping {
	
	TSX("Config", "1"),
	COMMON_JOBS("Common", "2"),
	BATCH_40A("Batch40a", "21"),
	BATCH_40B("Batch40b", "23"),
	RRV_GENERATION_PHASE_1("RrvGenerationPhase1", "25"),
	RRV_GENERATION_PHASE_2("RrvGenerationPhase2", "29"),
	RRV_PROCESSING("RrvProcessing", "31"),
	DOR("Dor", "33"),
	PRELIM_COMPARISON("PrelimComparison", "35"),
	PRELIM_PD("PrelimPd", "37"),
	CCA_PRELIM("CcaPrelim", "39"),
	PRELIM_NOTICE("PrelimNotice", "41"),
	APTC("Aptc", "43"),
	FINALIZATION("Finalization", "46"),
	AUTOENROLLMENTS("Autoenrollments", "75"),
	RESEQUENCEQABTOQLP("resequenceQabToQlpJob", "76"),
	BATCH25("Batch25", "82");
	
	public final String code;
    public final String workFlowId;
    
    private BatchJob_Workflow_ID_Mapping(String code, String workFlowId) {
        this.code = code;
        this.workFlowId = workFlowId;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	BatchJob_Workflow_ID_Mapping[] arrValues = BatchJob_Workflow_ID_Mapping.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getWorkflowId(String code) {
    	BatchJob_Workflow_ID_Mapping[] arrValues = BatchJob_Workflow_ID_Mapping.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		if(arrValues[i].code.equals(code)){
    			return 	arrValues[i].workFlowId;
    		}
    	}
    	return null;
    }
    
}
