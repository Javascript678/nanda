package enums;

import java.util.ArrayList;
import java.util.List;

public enum EnvName {
    QA("QA"),
    QA1("QA1"),
    QA2("QA2"),
    QA3("QA3"),
    DEV("DEV"),
    DEV1("DEV1"),
    INT("INT"),
    INT1("INT1"),
    TT3("TT3"),
    TT4("TT4");
    
    public final String val;
    private EnvName(String val) {
        this.val = val;
    }
    public static List<String> getNames() {
    	List<String> names = new ArrayList<String>();
    	EnvName[] arrValues = EnvName.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].val);
    	}
    	return names;
    }
}