package enums;

import java.util.ArrayList;
import java.util.List;

public enum PA_InsurenceCompanyName {
	BLANK(""),		// Blank Means Aetna
	AETNA("Aetna");
	
    public final String code;
    
    private PA_InsurenceCompanyName(String code) {
        this.code = code;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	PA_InsurenceCompanyName[] arrValues = PA_InsurenceCompanyName.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
}