package enums;

import java.util.ArrayList;
import java.util.List;

public enum EmployerAccessStatus {
	
	POTENTIAL("P","P�- Potential Access"),
	CONFIRMED("A","A�- Confirmed Access"),
	NO_ACCESS("N","N�- No Access");

    public final String code;
    public final String dropDownValue;
    
    private EmployerAccessStatus(String code,String dropDownValue) {
        this.code = code;
        this.dropDownValue = dropDownValue;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	EmployerAccessStatus[] arrValues = EmployerAccessStatus.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownValue(String code) {
    	EmployerAccessStatus[] values = EmployerAccessStatus.values();
    	for(int i=0; i< values.length;i++){
    		if(values[i].code.equals(code)){
    			return values[i].dropDownValue;
    		}
    	}
    	return null;
    }
}