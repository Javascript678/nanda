package enums;

import java.util.ArrayList;
import java.util.List;

public enum TPLUserType {

    TPL_USER("T"),
    TPL_SUPER_USER("S");
    
    public final String code;
    
    private TPLUserType(String code) {
        this.code = code;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	
    	TPLUserType[] arrValues = TPLUserType.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
}