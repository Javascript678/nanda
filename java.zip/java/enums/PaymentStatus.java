package enums;

import java.util.ArrayList;
import java.util.List;

public enum PaymentStatus {
	
	PP("PP","PP - Potential Pay"),
	CP("CP","CP - Current Pay"),
	NP("NP","NP - No Pay");
	
    public final String code;
    public final String dropDownVal;
    
    private PaymentStatus(String code,String dropDownVal) {
        this.code = code;
        this.dropDownVal = dropDownVal;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	PaymentStatus[] arrValues = PaymentStatus.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownVal(String code) {
    	PaymentStatus[] arrValues = PaymentStatus.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){

    		return 	arrValues[i].dropDownVal;
    		}
    	}
    	return null;
    }
}