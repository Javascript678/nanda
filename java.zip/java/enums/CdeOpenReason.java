package enums;

import java.util.ArrayList;
import java.util.List;

public enum CdeOpenReason {
    ONE("01");

	public final String code;
    private CdeOpenReason(String code) {
        this.code = code;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	CdeOpenReason[] arrValues = CdeOpenReason.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
}