package enums;

import java.util.ArrayList;
import java.util.List;

public enum ReasonableAcc {
	LARGE_PRINT_PUBLICATION("LP","LARGE_PRINT_PUBLICATION"),
	PUBLICATIONS_IN_BRAILLE("PB","PUBLICATIONS_IN_BRAILLE"),
	PUBLICATION_IN_ELECTRONIC_FORMAT("PE","PUBLICATION_IN_ELECTRONIC_FORMAT"),
	
	AMERICAN_SIGN_LANG_INTERPRETER("ASLI","AMERICAN_SIGN_LANG_INTERPRETER"),
	ASSIST_LISTEN_DEVICE("AL","ASSIST_LISTEN_DEVICE"),
	COMMUNICATION_ACCESS_REAL_TIME_TRANSLATIONS("RT","COMMUNICATION_ACCESS_REAL_TIME_TRANSLATIONS"),
	VIDEO_RELAY_SERVICE("VR","VIDEO_RELAY_SERVICE"),
	TTY("TT", "TTY"),
	OTHER("OT","OTHER");
	
	public final String code;
    public final String val;
    
    private ReasonableAcc(String code, String val) {
        this.code = code;
        this.val = val;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	ReasonableAcc[] arrValues = ReasonableAcc.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getVal(String code) {
    	ReasonableAcc[] arrValues = ReasonableAcc.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].val;
    		}
    	}
    	return null;
    }
}