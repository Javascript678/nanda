package enums;

import java.util.ArrayList;
import java.util.List;

public enum Role {
	
	VIEW_ONLY("VIEW_ONLY"),
	TPL("TPL"),
	SUPER_TPL("SUPER_TPL"),
	CSR("CSR"),
	SUPER_CSR("SUPER_CSR"),
    CAC("CAC"),
    NAV("NAV");
    
    public final String val;
    
    private Role(String val) {
        this.val = val;
    }
    
    public static List<String> getNames() {
    	List<String> names = new ArrayList<String>();
    	
    	Role[] arrValues = Role.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		names.add(arrValues[i].val);
    	}
    	return names;
    }
}