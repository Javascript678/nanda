package enums;

import java.util.ArrayList;
import java.util.List;

public enum DeductionType {
	EDUCATOR_EXPENSE("EE","EDUCATOR_EXPENSE"),
	BUSINESS_EXPENSES_RESERVIST_ARTIST("BE","BUSINESS_EXPENSES_RESERVIST_ARTIST"),
	HEALTH_SAVINGS_ACCOUNT_DEDUCTION("HS","HEALTH_SAVINGS_ACCOUNT_DEDUCTION"),
	MOVING_EXPENSES_RELATED_TO_JOB_CHANGE("ME","MOVING_EXPENSES_RELATED_TO_JOB_CHANGE"),
	DEDUCTIBLE_PART_OF_SELF_EMPLOYMENT_TAX("SE","DEDUCTIBLE_PART_OF_SELF_EMPLOYMENT_TAX"),
	CONTRIBUTION_TO_SELF_EMPLOYED_SEP("CSE","CONTRIBUTION_TO_SELF_EMPLOYED_SEP"),
	SELF_EMPLOYED_HEALTH_INSURANCE_DED("HSE","SELF_EMPLOYED_HEALTH_INSURANCE_DED"),
	PENALTY_ON_EARLY_WITHDRAWAL("PE","PENALTY_ON_EARLY_WITHDRAWAL"),
	ALIMONY_PAID("AP","ALIMONY_PAID"),
	INDIVIDUAL_RETIREMENT_ACCOUNT_DED("IR","INDIVIDUAL_RETIREMENT_ACCOUNT_DED"),
	STUDENT_LOAN_INTEREST_PAID("SL","STUDENT_LOAN_INTEREST_PAID"),
	HIGHER_EDUCATION("HE","HIGHER_EDUCATION"),
	DOMESTIC_PRODUCTION_DED("DPD","DOMESTIC_PRODUCTION_DED"),
	OTHER_DEDUCTIONS("OD","OTHER_DEDUCTIONS"),					// this is removed in R16 
	NONE("NA","NONE");
    
    public final String val;
    private DeductionType(String code,String val) {
        this.val = val;
    }
    public static List<String> getNames() {
    	List<String> names = new ArrayList<String>();
    	DeductionType[] arrValues = DeductionType.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].val);
    	}
    	return names;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	InsuranceFrequency[] arrValues = InsuranceFrequency.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
}