package enums;

import java.util.ArrayList;
import java.util.List;

public enum InsurancePolicySourceR19 {
	
	ESI("ESI","Employee Sponsored"),
	COBRA("COBRA","COBRA"),
	RETIREE_HEALTH_PLAN("RETIREE_HEALTH_PLAN","RETIREE_HEALTH_PLAN"),
	VETERAN_HEALTH_PROGRAM("VETERAN_HEALTH_PROGRAM", "VETERAN_HEALTH_PROGRAM"),
	MASS_HEALTH("MASS_HEALTH","MASS_HEALTH"),
	MEDICARE("MEDICARE","MEDICARE"),
	PEACE_CORPS("PEACE_CORPS","PEACE_CORPS"),
	TRICARE("TRICARE","TRICARE"),
	VA_HEALTH_PROGRAM("VA_HEALTH_PROGRAM","VA_HEALTH_PROGRAM"),
	OTHER("OTHER", "OTHER"),
	NONE_OF_THE_ABOVE("NONE_OF_THE_ABOVE","NONE_OF_THE_ABOVE");

	
    public final String code;
    public final String uiVal;
    
    private InsurancePolicySourceR19(String code,String uiValue) {
        this.code = code;
        this.uiVal = uiValue;
    }
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	InsurancePolicySourceR19[] arrValues = InsurancePolicySourceR19.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getuiValue(String code) {
    	InsurancePolicySourceR19[] values = InsurancePolicySourceR19.values();
    	for(int i=0; i< values.length;i++){
    		if(values[i].code.equals(code)){
    			return values[i].uiVal;
    		}
    	}
    	return null;
    }
}