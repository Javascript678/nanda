package enums;

import java.util.ArrayList;
import java.util.List;

public enum PA_CoverageTypes {

	FIFTY_SIX("56", "56 - HMO-Medicare Risk"),
	TWO("02", "02 - Major Medical"),
	SIX("06", "06 - Supplemental Policy"),
	ELEVEN("11", "11 - Health Maintenance Organization (HMO)"),
	TWELVE("12", "12 - Vision"),
	THIRTEEN("13", "13 - Dental Care"),
	FOURTEEN("14", "14 - Preferred Provider Organization (PPO)"),
	SEVENTEEN("16", "17 - Pharmacy - Cost Avoid"),
	ONE("01", "01 - Hospital"),
	FOUR("04", "04 - Medicare Part A"),
	FIVE("05", "05 - Medicare Part B"),
	EIGHT("08", "08 - Long Term Care"),
	NINE("09", "09 - HMO without Mental Health"),
	EIGHTEEN("18", "18 - Pharmacy - Pay and Chase"),
	THIRTY_FIVE("35", "35 - Commercial Insurance Without Mental Health"),
	FIFTY_SEVEN("57", "57 - HMO-Medicare Risk (Evercare)"),
	SIXTY_THREE("63", "63 - Veterans Services (Noncomprehensive)"),
	SIXTY_FOUR("64", "64 - Veterans Services (Comprehensive)"),
	NINETY_EIGHT("98", "98 - Medicare Hospice"),
	NINETY_NINE("99", "99 - Medicare Part D");
	
	public final String code;
    public final String coverageType;
    
    private PA_CoverageTypes(String code, String coverageType) {
        this.code = code;
        this.coverageType = coverageType;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	PA_CoverageTypes[] arrValues = PA_CoverageTypes.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getCoverageType(String code) {
    	PA_CoverageTypes[] arrValues = PA_CoverageTypes.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		if(arrValues[i].code.equals(code)){
    			return 	arrValues[i].coverageType;
    		}
    	}
    	return null;
    }    
}