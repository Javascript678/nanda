package enums;

import java.util.ArrayList;
import java.util.List;

public enum WhoIsApplying {
	SELF("SELF"),
	FAMILY_ONLY("FAMILY_ONLY"),
	SELF_FAMILY("SELF_FAMILY");

    public final String code;
    private WhoIsApplying(String code) {
        this.code = code;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	WhoIsApplying[] arrValues = WhoIsApplying.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
}