package enums;

import java.util.ArrayList;
import java.util.List;

public enum BatchJob_EnvServerMapping {
	QA("QA","Optum - QA","qa - batch - apsrt1224-qa"),
	QA1("QA1","Optum - QA1","qa1 - batch - apsrt1224-qa1");
	
	public final String code;
    public final String envDropDownValue;
    public final String serverDropDownValue;
    
    private BatchJob_EnvServerMapping(String code, String envDropDownValue, String serverDropDownValue) {
        this.code = code;
        this.envDropDownValue = envDropDownValue;
        this.serverDropDownValue = serverDropDownValue;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	BatchJob_EnvServerMapping[] arrValues = BatchJob_EnvServerMapping.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getEnvDropDownValue(String code) {
    	BatchJob_EnvServerMapping[] arrValues = BatchJob_EnvServerMapping.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].envDropDownValue;
    		}
    	}
    	return null;
    }
    
    public static String getServerDropDownValue(String code) {
    	BatchJob_EnvServerMapping[] arrValues = BatchJob_EnvServerMapping.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].serverDropDownValue;
    		}
    	}
    	return null;
    }
}