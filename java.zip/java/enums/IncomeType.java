package enums;

import java.util.ArrayList;
import java.util.List;

public enum IncomeType {
	JOB("JOB"),
	SELF_EMPLOYMENT("SELF_EMPLOYMENT"),
	SOCIAL_SECURITY_BENEFITS("SOCIAL_SECURITY_BENEFITS"),
	UNEMPLOYMENT("UNEMPLOYMENT"),
	RETIREMENT("RETIREMENT"),
	CAPITALGAINS("CAPITALGAINS"),
	INVESTMENT_INCOME("INVESTMENT_INCOME"),
	RENTAL_OR_ROYALTY_INCOME("RENTAL_OR_ROYALTY_INCOME"),
	FARMING_OR_FISHING_INCOME("FARMING_OR_FISHING_INCOME"),
	ALIMONY_RECEIVED("ALIMONY_RECEIVED"),
	OTHER_INCOME("OTHER_INCOME");
	
    public final String val;
    private IncomeType(String val) {
        this.val = val;
    }
    public static List<String> getNames() {
    	List<String> names = new ArrayList<String>();
    	IncomeType[] arrValues = IncomeType.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].val);
    	}
    	return names;
    }
}