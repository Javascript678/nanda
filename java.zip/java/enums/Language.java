package enums;

import java.util.ArrayList;
import java.util.List;

public enum Language {
    ENGLISH("English"),
    SPANISH("Spanish");
    
    public final String val;
    private Language(String val) {
        this.val = val;
    }
    public static List<String> getNames() {
    	List<String> names = new ArrayList<String>();
    	Language[] arrValues = Language.values();
    	for(int i=0; i< arrValues.length;i++){
    		names.add(arrValues[i].val);
    	}
    	return names;
    }
}