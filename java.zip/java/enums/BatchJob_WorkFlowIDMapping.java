package enums;

import java.util.ArrayList;
import java.util.List;

public enum BatchJob_WorkFlowIDMapping {
	THREE("3","3"),
	SEVEN("7","5"),
	EIGHT("8","6"),
	NINE("9","7"),
	TEN("10","8"),
	ELEVEN("11","9"),
	THIRTEEN("13","10"),
	FOURTEEN("14","11"),
	SEVENTEEN("17","12"),
	EIGHTEEN("18","13"),
	NINETEEN("19","14"),
	TWENTY("20","15"),
	TWENTY_ONE("21","16"),
	TWENTY_TWO_MH("22 MH ONLY","17"),
	TWENTY_TWO_CCA("22 CCA ONLY","18"),
	TWENTY_TWO_MIX("22 MIX ONLY","19"),
	TWENTY_THREE("23","20"),
	TWENTY_FOUR("24","21"),
	TWENTY_FIVE("25","22"),
	TWENTY_SEVEN("27","23"),
	TWENTY_NINE("29","24"),
	THIRTY_ONE("31","25"),
	THIRTY_TWO("32","26"),
	THIRTY_THREE("33","27"),
	THIRTY_FOUR("34","28"),
	THIRTY_SIX("36","29"),
	THIRTY_NINE("37","30"),
	FORTY("38","31"),
	FORTY_ONE("41","32"),
	FORTY_TWO("42","33"),
	FORTY_THREE("43","34"),
	FORTY_FOUR("44","35"),
	FORTY_FIVE("45","36"),
	FORTY_SIX("46","37"),
	FORTY_SEVEN("47","38"),
	FORTY_EIGHT("48","39"),
	FORTY_NINE("49","40"),
	FIFTY("50","41"),
	FIFTY_ONE("51","42"),
	FIFTY_TWO("52","43"),
	FIFTY_THREE("53","44"),
	FIFTY_FOUR("54","45"),
	FIFTY_FIVE("55","46"),
	FIFTY_SIX("56","47"),
	FIFTY_SEVEN("57","48"),
	FIFTY_EIGHT("58","49"),
	FIFTY_NINE("59","50"),
	SIXTY("60","51"),
	SIXTY_ONE("61","52"),
	SIXTY_TWO("62","53"),
	SIXTY_THREE("63","54"),
	SIXTY_FOUR("64","55"),
	SIXTY_FIVE("65","56"),
	SIXTY_SIX("66","57"),
	SIXTY_SEVEN("67","58"),
	SIXTY_EIGHT("68","59"),
	SIXTY_NINE("69","60"),
	SEVENTY("70","61"),
	SEVENTY_ONE("71","62"),
	SEVENTY_TWO("72","63"),
	SEVENTY_THREE("73","64"),
	SEVENTY_FOUR("74","65"),
	SEVENTY_FIVE("75","66"),
	SEVENTY_SIX("76","67"),
	SEVENTY_SEVEN("77","68"),
	SEVENTY_EIGHT("78","69"),
	SEVENTY_NINE("79","70"),
	EIGHTY("80","71"),
	EIGHTY_ONE("81","72"),
	EIGHTY_TWO("82","73"),
	EIGHTY_THREE("83","74"),
	EIGHTY_FOUR("84","75"),
	EIGHTY_SIX("86","76"),
	EIGHTY_SEVEN("87","77"),
	EIGHTY_EIGHT("88","78"),
	EIGHTYNINE("89","80"),
    NINETY("90","81"),
    NINETY_ONE("91","82"),
    NINETY_TWO("92","83"),
    NINETY_THREE("93","84"),
    NINETY_FOUR("94","85"),
    NINETY_FIVE("95","86"),
    NINETY_SIX("96","87"),
    NINETY_SEVEN("97","88"),
    NINETY_EIGHT("98","89"),
    HUNDRED("100","90"),
    ONE_HUNDRED_FOUR("104","91"),
    ONE_HUNDRED_EIGHT("108","92"),
    ONE_HUNDRED_TWENTYONE("121","93"),
    ONE_HUNDRED_TWENTYTWO_CCA("122 CCA_ONLY","94"),  
    ONE_HUNDRED_TWENTYTWO_MH("122 MH ONLY","95"), 
    ONE_HUNDRED_TWENTYTWO_MIX("122 MIX","96"),
    ONE_HUNDRED_TWENTYTHREE("123","97"),
    ONE_HUNDRED_TWENTYFOUR("124","98"),
    ONE_HUNDRED_TWENTYFIVE("125","99"),
    ONE_HUNDRED_TWENTYSIX("126","100"),
    ONE_HUNDRED_TWENTYSEVEN("127","101"),
    ONE_HUNDRED_TWENTYEIGHT("128","102"),
    ONE_HUNDRED_TWENTYNINE("129","103"),
    ONE_HUNDRED_THIRTY("130","104"),
    ONE_HUNDRED_THIRTYONE("131","105"),
    ONE_HUNDRED_THIRTYTWO_HSN_ONETIME_BATCH("132 HSN ONE TIME BATCH","106"),
    ONE_HUNDRED_THIRTYTWO_HSN_TIMEOUT_RECORD("132 HSN TIMED OUT RECORDS","107"),
    ONE_HUNDRED_THIRTYNINE("139","108"),
    ONE_HUNDRED_FORTY("140","109"),
    ONE_HUNDRED_FORTY_ONE("141","110"),
    THREE_HUNDRED_ONE("301","111"),
    RRV_CREATE_TDSJOB("rrvCreateTDSJob","112"),
    RESEQUENCE_QAB_TO_QLP_JOB("resequenceQabToQlpJob","113"),
    INDIVIDUAL_XML_GENERATION_JOB("individualXMLGenerationJob","114"),
    GROUP_XML_GENERATION_JOB("groupXMLGenerationJob","115"),
    FORMULARY_UPDATE("formularyUpdate","116"),
    EXCLUSIONREPD_APPLICATION_REPORT("exclusionRePdApplicationReport","117"),
    BYPASS_APPLICATION_REPORT("byPassApplicationReport","118"),
    RESEQUENCE_PREGNANCY_STATUS_UPATE_JOB("resequencePregnancyStatusUpdateJob","119"),
	DOR_REFERRAL_RECORD_JOB("dorReferralRecordJob","120");
	
	public final String code;
    public final String workFlowDropDownValue;
    
    private BatchJob_WorkFlowIDMapping(String code, String workFlowDropDownValue) {
        this.code = code;
        this.workFlowDropDownValue = workFlowDropDownValue;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	BatchJob_WorkFlowIDMapping[] arrValues = BatchJob_WorkFlowIDMapping.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getWorkFlowDropDownValue(String code) {
    	BatchJob_WorkFlowIDMapping[] arrValues = BatchJob_WorkFlowIDMapping.values();
    	for(int i=0; i< arrValues.length;i++){
    		if(arrValues[i].code.equals(code)){
    		return 	arrValues[i].workFlowDropDownValue;
    		}
    	}
    	return null;
    }
    
}