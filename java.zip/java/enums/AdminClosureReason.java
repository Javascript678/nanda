package enums;

import java.util.ArrayList;
import java.util.List;

public enum AdminClosureReason {
	
	AR38("38","38 - Voluntary Withdrawal"),
	AR49("49","49 - Deceased"),
	AR50("50","50 - Whereabouts Unknown"), 
	AR58("58","58 - Failed to cooperate with Quality Assurance"),
	AR12("12","12 - No longer in household"),
	AR33("33","33 - Already receiving MassHealth"),
	AR46("46","46 - Entered penal institution"), 
	AR73("73","73 - Member did not enroll in employer sponsored health insurance"), 
	AR86("86","86 - Failure to pay MH premium"),
	ARS1("S1","S1 - Member is age 65 or older"), 
	ARS2("S2","S2 - Receiving benefits in another state but eligible for QHP"),
	ARS3("S3","S3 - Entered penal institution but eligible for QHP"), 
	ARS4("S4","S4- Not a resident of Massachusetts but eligible for QHP"), 
	ARS6("S6","S6- Entered penal institution based on data match"), 
	ARS7("S7","S7 - Deceased based on data match"), 
	ARA1("A1","A1 - Failure to respond to data match"), 
	ARA2("A2","A2 - Failure to return a Job Update form"), 
	ARA3("A3","A3 - Failure to cooperate with a health insurance investigation"),
	ARA5("A5","A5 - Duplicate case"), 
	ARA6("A6","A6 - HOH's account is deactivated");
	
    public final String code;
    public final String dropDownValue;
    
    private AdminClosureReason(String code,String mmisValue) {
        this.code = code;
        this.dropDownValue = mmisValue;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	AdminClosureReason[] arrValues = AdminClosureReason.values();
    	for(int i=0; i< arrValues.length;i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String getDropDownValue(String code) {
    	AdminClosureReason[] values = AdminClosureReason.values();
    	for(int i=0; i< values.length;i++){
    		if(values[i].code.equals(code)){
    			return values[i].dropDownValue;
    		}
    	}
    	return null;
    }
}