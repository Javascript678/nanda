package runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Test_Features/aws-batch-job-api.feature",
		glue={"classpath:stepdefs"},
		monochrome = true,
		plugin = {	"html:Test_Report/CucumberReport/aws-batch-job-api/html",
					"json:Test_Report/CucumberReport/aws-batch-job-api/json/result.json",
					"junit:Test_Report/CucumberReport/aws-batch-job-api/junit/result.xml"
				},tags = {"@Job_Sequence_1"}
		)
public class aws_apis{
}