package pages.assister;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Ritika
 *
 */
public class ViewDesignationFormPage extends CommonPage implements CommonPageOR {

	private static final By viewDesignationFormPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'View Designation Form')]");

	private static final By downloadDesgFormBtn = By.xpath("//input[contains(@value,'Download Designation Form')]");

	public ViewDesignationFormPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("ViewDesignationFormPageHeader", viewDesignationFormPageHeader);
	}

	public void ClickOnDwldDesgForm() throws Exception {
		clickOnElement("DownloadDesignationFormBtn", downloadDesgFormBtn);
	}

	public void takeScreenshot() throws Exception {
		takeScreenshot("AssisterDesignationForm");
	}

}
