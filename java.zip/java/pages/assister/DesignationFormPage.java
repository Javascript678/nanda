package pages.assister;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import enums.Role;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class DesignationFormPage extends CommonPage implements CommonPageOR {

	private static final By designationFormPageHeader = By
			.xpath("//h1[contains(text()[normalize-space()],'Designation Form')]");

	private static final By indFirstName = By.id("individualFirstName");
	private static final By indMiddileName = By.id("individualMiddleName");
	private static final By indLastName = By.id("individualLastName");
	private static final By indDob = By.id("individualDob");
	private static final By indUnqCriteriaTypeName = By.id("individualUniqueCriteriaType"); // select
																							// email,ssn,RefID
																							// etc
	private static final By indUnqCriteriaValue = By.id("individualUniqueCriteriaValue");
	private static final By clientAgreeTermCondition = By.id("clientCertificationAccepted");
	
	private static final By assisterFirstNameTxt = By.id("assisterFirstName");
	private static final By assisterMiddleNameTxt = By.id("assisterMiddleName");
	private static final By assisterLastNameTxt = By.id("assisterLastName");
	
	private static final By assisterCACAgreeTermCondition = By.id("assisterCertificationAccepted");
	private static final By assisterNAVAgreeTermCondition = By.id("assisterNavigatorAccepted");
	
	private static final By assisterSignature = By.id("assisterSignature");
	private static final By clientSignature = By.id("clientSignature");
	private static final By indivLocatedText = By.xpath("//p[contains(text(),'The individual you are searching for cannot be located')]");
	private static final By indivLocatedProceed = By.xpath("//span[@class='ui-button-text' and contains(text(),'Proceed')]");
	private static final By indivNotLocatedCancel = By.xpath("//span[@class='ui-button-text' and contains(text(),'Cancel')]");
	private static final By submitBtn = By.id("submitButton");
	
	public DesignationFormPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("DesignationFormPageHeader", designationFormPageHeader);
	}

	public void EnterFirstName(String frstnm) throws Exception {
		enterText("FirstNameTxtBx", indFirstName, frstnm);
	}

	public void EnterMiddleName(String mdlnm) throws Exception {
		enterText("MiddleNameTxtBx", indMiddileName, mdlnm);
	}

	public void EnterLastName(String lstnm) throws Exception {
		enterText("LastNametBx", indLastName, lstnm);
	}

	public void EnterDob(String dob) throws Exception {
		clickOnElement("dob", indDob);
		clearAndTypeAfterWait("DobTxtBx", indDob, dob);
	}

	public void SelectUnqCriteriaTypeName(String UnqCriteriaNm) throws Exception {
		selectDropDownElementByVisibleText("UniqueCriteriaNameSelectBox", indUnqCriteriaTypeName, UnqCriteriaNm);
	}

	public void SelectUnqCriteriaTypeValue(String UnqCriteriaVlu) throws Exception {
		enterText("UniqueCriteriaValueSelectBox", indUnqCriteriaValue, UnqCriteriaVlu);
	}
	
	public String getAssisterFirstName() throws Exception{
		return getElementAttribute(assisterFirstNameTxt, "value");
	}
	
	public String getAssisterMiddleName() throws Exception{
		return getElementAttribute(assisterMiddleNameTxt, "value");
	}
	
	public String getAssisterLastName() throws Exception{
		return getElementAttribute(assisterLastNameTxt, "value");
	}
	
	public void ClickClientAgreeTermChk() throws Exception {
		clickOnElement("ClientAgreeTermChkBx", clientAgreeTermCondition);
	}

	public void ClickAssisterCACAgreeTermChk() throws Exception {
		clickOnElement("AssisterAgreeTermChkBx", assisterCACAgreeTermCondition);
	}

	public void ClickAssisterNavAgreeTermChk() throws Exception{
		clickOnElement("AssisterNavigatorAgreeTermChkBx", assisterNAVAgreeTermCondition);
	}
	
	public void enterAssisterSign(String AssisterSign) throws Exception {
		enterText("AssisterSignatureTxtBx", assisterSignature, AssisterSign);
	}

	public void enterClientSign(String ClientSign) throws Exception {
		enterText("ClientSignatureTxtBx", clientSignature, ClientSign);
	}

	public void verifyIndvLocatedText() throws Exception {
		waitForPresenceOfElementLocatedThenWait("IndivLocatedText", indivLocatedText, 5);
	}
	
	public void ClickIfIndvLocatedProceed() throws Exception {
		clickOnElement("IndividualLocatedProceedBtn", indivLocatedProceed);
	}

	public void ClickIfIndvNotLocatedCancel() throws Exception {
		clickOnElement("IndividualNotLocatedCancelBtn", indivNotLocatedCancel);
	}

	public void ClickOnSubmitForNxtPg() throws Exception {
		clickOnElement("SubmitForNxtPgBtn", submitBtn);
	}
	
	public void takeScreenshot() throws Exception {
		takeScreenshot("AssisterDesignationForm");
	}

	public void fill_Designation_Details(String assisterUser, 
			String firstName, 
			String middleName, 
			String lastName, 
			String dob,
			String uniqueCriteriaType,
			String uniqueCriteriaValue
				) throws Exception {
		waitForPageLoaded();

		EnterFirstName(firstName);
		EnterMiddleName(middleName);
		EnterLastName(lastName);
		EnterDob(dob);
		SelectUnqCriteriaTypeName(uniqueCriteriaType);
		if(uniqueCriteriaType.equals("SSN") 
				|| uniqueCriteriaType.equals("REFID") 
				//Add New Criteria if required.
				){
			SelectUnqCriteriaTypeValue(uniqueCriteriaValue);
		}else{
			throw new Exception("Unique Criteria is not matching . Accpted Value are [SSN, REFID]");
		}
		
		ClickClientAgreeTermChk();
		
		if(assisterUser.equals(Role.CAC.val)){
			ClickAssisterCACAgreeTermChk();
		}else if(assisterUser.equals(Role.NAV.val)){
			ClickAssisterNavAgreeTermChk();
		}
		
		String assisterFName = getAssisterFirstName();
		String assisterMName = getAssisterMiddleName();
		String assisterLName = getAssisterLastName();
		
		String assistersign = "";
		if(assisterMName.equals("")){
			assistersign = assisterFName + " " + assisterLName;
		}else{
			assistersign = assisterFName + " " + assisterMName + " " + assisterLName;
		}
		
		enterAssisterSign(assistersign);
		
		String clientsign = firstName + " " + middleName + " " + lastName;
		enterClientSign(clientsign);
	}
	
	//Ritu
	public void submitFormForExistingMember( ) throws Exception{
		takeScreenshot();
		ClickOnSubmitForNxtPg();
		
	}
	public void submitFormAndProceedForNewMember() throws Exception{
		ClickOnSubmitForNxtPg();
		verifyIndvLocatedText();
		takeScreenshot("IndvLocated");
		ClickIfIndvLocatedProceed();
	}
	
	//Ritika
	public String  getSSN() throws Exception{
		return getElementAttribute("SSNTxt", indUnqCriteriaValue, "value");
	}
	
	public void validateSSNIsMasked() throws Exception{
		By indUnqCriteriaValue = By.name("individualUniqueCriteriaValue");
		validateElementAttribute("SSNTxt", indUnqCriteriaValue, "type", "hidden");
	}
	
	//Ritika
	public void  validateUserProfileSSNIsMaskedOnDesgForm() throws Exception{
		waitForPageLoaded();
		takeScreenshot();
		String ssn = getSSN();
		//validateTextContains("SSNTxt", ssn,"XXX-XX-");
		validateSSNIsMasked();
	}
}
