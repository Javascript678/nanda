package pages.assister;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Ritu Negi
 *
 */
public class ViewMemberDetailsPage extends CommonPage implements CommonPageOR {

	private static final By viewMemberDetailPageHeader = By.xpath("//h1[contains(.,'View Member Details')]");


	private static final By removeAccessBtn=  By.id("removeAccount");
	private static final By viewProfileBtn=  By.id("viewAccount");
	private static final By viewEligibilityBtn=  By.id("viewEligiblity");
	private static final By downloadConsentBtn=  By.xpath("//input[contains(@id,'DownloadConsent')]");
	private static final By agreeBtn=  By.xpath("//span[text()='Agree']");
	private static final By cancelBtn=  By.xpath("//span[text()='Cancel']");
	
	public ViewMemberDetailsPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("ViewMemberDetailPageHeader", viewMemberDetailPageHeader);
	}

	
	public void takeScreenshot() throws Exception {
		takeScreenshot("ViewMemberDetailsPage");
	}
	
	//Ritu
	public void ClickOnRemoveAccess() throws Exception {
		clickOnElement("RemoveAccessBtn", removeAccessBtn);
	}
	
	//Ritu
	public void ClickOnViewProfile() throws Exception {
		clickOnElement("ViewProfileBtn", viewProfileBtn);
	}
	
	//Ritu
	public void ClickOnViewEligibility() throws Exception {
		clickOnElement("ViewEligibilityBtn", viewEligibilityBtn);
	}
	
	//Ritu
	public void ClickOnDownLoadConcent() throws Exception {
		clickOnElement("DownloadConsentBtn", downloadConsentBtn);
	}
	
	//Ritu
	public void ClickOnAgreeBtn() throws Exception {
		clickOnElement("AgreeBtn", agreeBtn);
	}
	
	//Ritu
	public void ClickOnCancelBtnBtn() throws Exception {
		clickOnElement("CancelBtn",cancelBtn);
	}
}
