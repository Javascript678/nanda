package pages.assister;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Ritu 
 *
 */
public class MemberListPage extends CommonPage implements CommonPageOR {

	private static final By memberListPageHeader = By.xpath("//h1[contains(.,'Member List')]");

	private static final By refidTxt = By.id("refId");
	private static final By firstNameTxt = By.id("firstName");
	private static final By dobTxt = By.id("dob");
	private static final By lastNameTxt = By.id("lastName");//  
	private static final By fromRelationShipStartTxt = By.id("relationshipStartDateValue");
	private static final By toRelationShipStartTxt = By.id("relationshipToDateValue");
	private static final By viewProfileTxt=By.xpath("//a[contains(.,'View Profile')]");
	private static final By viewEligibilityTxt=By.xpath("//a[contains(.,'View Eligibility')]");
	private static final By removeAccessTxt=By.xpath("//a[contains(.,'Remove Access')]");
	private static final By viewDesignationFormTxt=By.xpath("//a[contains(.,'Remove Access')]/following-sibling::a[contains(.,'View Designation Form')]");
	private static final By searchBtn = By.id("searchCustomer");
	private static final By agreeBtn=  By.xpath("//span[text()='Agree']");
	private static final By cancelBtn=  By.xpath("//span[text()='Cancel']");
	private static final By yesBtn=  By.xpath("//span[text()='Yes']");
	
	
	
	public MemberListPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("MemberListPageHeader", memberListPageHeader);
	}

	public void enterRefID(String refid) throws Exception {
		enterText("RefIDTxtBx", refidTxt , refid);
	}

	public void EnterFirstName(String fName) throws Exception {
		enterText("FirstNameTxtBx",firstNameTxt  , fName);
	}
	

	public void EnterLastName(String lstnm) throws Exception {
		enterText("LastNametBx",lastNameTxt, lstnm);
	}

	public void EnterDob(String dob) throws Exception {
		clearAndType("DobTxtBx", dobTxt, dob);
	}


	
	public void EnterFromRelationShipStart(String lstnm) throws Exception {
		enterText("FromRelationShipStartTxt",fromRelationShipStartTxt, lstnm);
	}

	public void EnterToRelationShipStart(String dob) throws Exception {
		clearAndType("ToRelationShipStartTxt", toRelationShipStartTxt, dob);
	}
	

	
	public void takeScreenshot() throws Exception {
		takeScreenshot("AssisterDesignationForm");
	}
	
	
	private void clickOnViewProfileLink() throws Exception{
		clickOnElement("ViewProfileBtn",viewProfileTxt);
	}
	private void clickOnViewEligibilityLink() throws Exception{
		clickOnElement("ViewEligibilityTxt",viewEligibilityTxt);
	}
	
	private void clickOnRemoveAccessLink() throws Exception{
		clickOnElement("RemoveAccessTxt",removeAccessTxt);
	}
	
	private void clickOnYesLink() throws Exception{
		clickOnElement("YesBtn",yesBtn);
	}
	
	private void clickOnViewDesignationFormLink() throws Exception{
		clickOnElement("ViewDesignationFormTxt",viewDesignationFormTxt);
	}
	

	private void clickOnSearchBtn() throws Exception{
		clickOnElement("SearchBtn",searchBtn);
	}
	
	public void clickOnAgreeBtn() throws Exception {
		clickOnElement("AgreeBtn", agreeBtn);
	}

	public void clickOnCancelBtnBtn() throws Exception {
		clickOnElement("CancelBtn",cancelBtn);
	}
	
	public void searchCustomerUsingRefID(String refID) throws Exception{
		waitForPageLoaded();
		 enterRefID(refID);
		 clickOnSearchBtn();
	}
	
	public void searchCustomerUsingRefIDAndClickElgLink(String refID) throws Exception{
		searchCustomerUsingRefID(refID);
		 clickOnViewEligibilityLink();
		 clickOnAgreeBtn();	
	}
	
	public void clickOnViewDesFormBtn() throws Exception{
		final By viewDesnFormBtn=By.xpath("//tr[1]//a[contains(.,'Remove Access')]/..//a[contains(.,'View Designation Form')]");
		waitForPageLoaded();
		clickOnElementThenWait("ViewDesignationFormBtn", viewDesnFormBtn, 5);
	}
	
	public void removeAccessForMember() throws Exception{   
		clickOnRemoveAccessLink(); 
		 clickOnYesLink();
	}
}
