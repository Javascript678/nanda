package pages.reviewAndSign;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/** @author ppinho
 * 
 */

public class ReviewAndSignPage extends CommonPage implements CommonPageOR {
	
	private static final By reviewAndSignPageHeader = By.xpath("//p[contains(text(),'Take a few minutes to review the information you gave us')]");
	
	public ReviewAndSignPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("ReviewAndSignPageHeader", reviewAndSignPageHeader);
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void evpdClickOnSaveAndContinueBtn() throws Exception {
		clickOnSaveAndContinueBtn();
	}
}