package pages.reviewAndSign;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import enums.IncomeType;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Ritika Gupta
 *
 */
public class ChangeIncomePage extends CommonPage implements CommonPageOR {

	private static final By changeIncomePageHeader = By.xpath("//h1[contains(text(),'Change Income')]");
	private static final By saveVerifyIncomeButton = By.xpath("//input[@id='saveVerifyIncomeButton']");

	public ChangeIncomePage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("ExpectedResultsPageHeader", changeIncomePageHeader);
	}

	public void selectVerifiedCheckBox(String fullName, int jobInd) throws Exception {
		By verifiedCheckBx = By.xpath("//h2[contains(text(),'" + fullName + "')]/../div//input[@name='eligibilityMemberManualVerifiedIncomeSource[" + jobInd + "].hasReceivedDoc']");
		clickOnElement("VerifiedCheckBx", verifiedCheckBx);
	}
	
	public boolean isWarningDialogPresent() throws Exception{
		return isElementPresent(warningOkButton);
	}
	
	public void clickOnWarningOkButton() throws Exception{
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}
	
	public void handleWarningDialogIfPresent() throws Exception{
		if(isWarningDialogPresent()){
			clickOnWarningOkButton();
		}
	}

	public void clickOnSaveAndVerifyBtn() throws Exception {
		clickOnElementThenWait("SaveAndContinueBtn", saveVerifyIncomeButton, 5);
	}

	public void takeScreenShot() throws Exception {
		takeScreenshot("Expected Results");
	}

	// ppinho
	public void evpdVerifyIncomeClickOnSaveAndContinueBtn(int memIndex, List<EVPD_MemData> memsData) throws Exception {		
		for(int jobInd = 0; jobInd < memsData.get(memIndex).jobSourceCount; jobInd++){
			selectVerifiedCheckBox(memsData.get(memIndex).fullName, jobInd);
		}
		
		takeScreenshot("Expected Results");
		clickOnSaveAndVerifyBtn();
		handleWarningDialogIfPresent();
	}
}
