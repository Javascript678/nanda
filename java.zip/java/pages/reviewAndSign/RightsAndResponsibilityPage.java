package pages.reviewAndSign;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.evpd.ResponsiblePartyData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class RightsAndResponsibilityPage extends CommonPage implements CommonPageOR {
	
	private static final By rightsAndResponPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Rights and Responsibilities')]");
	
	public RightsAndResponsibilityPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("RightsAndResponPageHeader", rightsAndResponPageHeader);
	}
	
	public void clickSigningUnderPenaltyOfPerjuryChkBox() throws Exception {
		By signingUnderPenaltyOfPerjuryChkBox = By.id("agreement.isSigningUnderPenaltyOfPerjury");
		clickOnElement("SigningUnderPenaltyOfPerjuryChkBox", signingUnderPenaltyOfPerjuryChkBox);
	}
	
	public void clickAgreeToUseTaxReturnDataForRenewableCheckBox() throws Exception {
		By agreeToUseTaxReturnDataForRenewableCheckBox = By.id("agreement.isUseTaxReturnDataForRenewal5Year");
		clickOnElement("AgreeToUseTaxReturnDataForRenewableCheckBox", agreeToUseTaxReturnDataForRenewableCheckBox);
	}
	
	public void clickAgreeChkBox() throws Exception {
		By agreeChkBox = By.id("agreement.isAgreeStatements");
		clickOnElement("AgreeChkBox", agreeChkBox);
	}
	
	public void SelectIfMember1IsEmancipated(boolean trueFalseValue) throws Exception {
		By Mem1EmancipatedMinotRdBtn=By.xpath("//input[contains(@name,'isEmancipated') and @value='" + trueFalseValue + "']/../label");
		clickOnElement("Mem1EmancipatedMinotRdBtn" + trueFalseValue, Mem1EmancipatedMinotRdBtn);
	}
	
	public void validateInvalidSSNMsg() throws Exception {
		By ssnErrorMsg = By.xpath("//span[contains(text(),'Enter a valid Social Security Number')]");
		validateElementPresent("InvalidSSNMsg", ssnErrorMsg);
	}
	
	public void enterReposiblePartyFirstName(String fName)throws Exception {
		By ReposiblePartyFirstNameTxt = By.id("responsiblePartyInfo.name.firstName");
		enterText("ReposiblePartyFirstNameTxt", ReposiblePartyFirstNameTxt,fName);
	}
	
	public void enterReposiblePartyLastName(String LName)throws Exception {
		By ReposiblePartyLastNameTxt = By.id("responsiblePartyInfo.name.lastName");
		enterText("ReposiblePartyLastNameTxt", ReposiblePartyLastNameTxt,LName);
	}
	
	public void SelectMember1RelationWithResponsibleParty(String relationship) throws Exception {
		//By reposiblePartyRelationShipDD = By.id("eligibilityMember[0].rpRelationship");
		By reposiblePartyRelationShipDD = By.id("responsiblePartyInfo.rpRelationship");
		if(relationship.contains("Responsible")){
			selectDropDownByValue("ReposiblePartyRelationShipDD", reposiblePartyRelationShipDD, "QD");
		}else{
			selectDropDownElementByVisibleText("ReposiblePartyRelationShipDD", reposiblePartyRelationShipDD, relationship);
		}
	}
	
	public void enterReposiblePartyDOB(String dob)throws Exception {
		By ReposiblePartyDOBTxt = By.id("responsiblePartyInfo.dateOfBirth");
		clearAndTypeAfterWait("ReposiblePartyDOBTxt", ReposiblePartyDOBTxt,dob);
	}
	
	public void enterReposiblePartyStreet(String street)throws Exception { 
		By ReposiblePartyStreetTxt = By.id("responsiblePartyInfo.contactInfo.primaryAddress.streetAddress1");
		clearAndType("ReposiblePartyStreetTxt", ReposiblePartyStreetTxt,street);
	}
	
	public void enterReposiblePartySSN(String SSN)throws Exception {
		By ReposiblePartySSNTxt = By.id("responsiblePartyInfo.ssn");
		clearAndTypeAfterWait("ReposiblePartySSNTxt", ReposiblePartySSNTxt,SSN);
	}
	
	public void enterReposiblePartyCity(String city)throws Exception {
		By ReposiblePartyCityTxt = By.id("responsiblePartyInfo.contactInfo.primaryAddress.city");
		clearAndType("ReposiblePartyCityTxt", ReposiblePartyCityTxt,city);
	}
	
	public void enterReposiblePartyZip(String zip)throws Exception {
		By ReposiblePartyZipTxt = By.id("responsiblePartyInfo.contactInfo.primaryAddress.zip");
		clearAndType("ReposiblePartyZipTxt", ReposiblePartyZipTxt,zip);
	}
	
	public void SelectReposiblePartyCounty(String county) throws Exception {
		By reposiblePartyCountyDD = By.id("responsiblePartyInfo.contactInfo.primaryAddress.county");
		selectByVisibleTextAfterWait("ReposiblePartyCountyDD", reposiblePartyCountyDD, county);
	}
	
	public void enterReposiblePartyPrimaryPhoneNo(String phone)throws Exception {
		By ReposiblePartyPhoneTxt = By.id("responsiblePartyInfo.contactInfo.primaryPhoneNumber_0");
		clearAndTypeAfterWait("ReposiblePartyPhoneTxt", ReposiblePartyPhoneTxt,phone);
	}
	
	public void enterReposiblePartySignature(String fullName)throws Exception {
		By reposiblePartySignatureTxt = By.id("responsibleParty.signature");
		enterText("ReposiblePartySignatureTxt", reposiblePartySignatureTxt,fullName);
	}
	
	public String getHOHSignature()throws Exception {
        By hohSignatureLabel = By.xpath("//div[label[@for='eligibilityMember0.signature']]/div");
        return getElementText(hohSignatureLabel);
	}
	
	public void enterHOHSignature(String fullName)throws Exception {
		By hohSignatureTxt = By.id("eligibilityMember0.signature");
		enterText("ReposiblePartyFullNameTxt", hohSignatureTxt,fullName);
	}
	
	public void enterHOHRespnsibleSignature(String fullName)throws Exception {
		By hohSignatureTxt = By.id("responsibleParty.signature");
		enterText("ReposiblePartyFullNameTxt", hohSignatureTxt,fullName);
	}
	
	public void SelectIfMember1ApplyForVoteToday(boolean trueFalseValue) throws Exception {
        By mem1applyingForVoteTodayRdBtn = By.xpath("//input[@name='agreement.isWillingToRegisterToVote']/../label");
        clickOnElement( "Mem1applyingForVoteTodayRdBtn" + trueFalseValue, mem1applyingForVoteTodayRdBtn );
    }
	
	//Amrita
	public void SelectIfDocsNeedToBeVerified(Boolean bValue) throws Exception {
		By docsToVerifyRdBtn;
		if(bValue == true){
			docsToVerifyRdBtn = By.id("docsAvail1");
		}else{
			docsToVerifyRdBtn = By.id("docsAvail2");
		}
		clickOnElement("DocumentsToVerify"+bValue+"RdBtn",docsToVerifyRdBtn);
	}
	
	//Amrita
	public void SelectIfNoticesNeedToBeSupressed(Boolean bValue) throws Exception {
		By noticesToSupressRdBtn;
		if(bValue == true){
			noticesToSupressRdBtn = By.id("supressNotice1");
		}else{
			noticesToSupressRdBtn = By.id("supressNotice2");
		}
		clickOnElement("NoticesToSupress" + bValue + "RdBtn", noticesToSupressRdBtn);
	}

	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn,5);
	}

	public void completeRightsAndResponsibility(EVPD_MemData mem1Data, ResponsiblePartyData rpData) throws Exception {
		waitForPageLoaded();
		clickSigningUnderPenaltyOfPerjuryChkBox();
		clickAgreeChkBox();
		
		if(mem1Data.isU18){
			SelectIfMember1IsEmancipated(false);
			enterReposiblePartyFirstName(rpData.firstName);
			enterReposiblePartyLastName(rpData.lastName);
			SelectMember1RelationWithResponsibleParty(rpData.relationship);
			enterReposiblePartyDOB(rpData.dob);
			enterReposiblePartyStreet(rpData.homeAddr.streetAddress);
			enterReposiblePartyCity(rpData.homeAddr.city);
			enterReposiblePartyZip(rpData.homeAddr.zipCode);
			SelectReposiblePartyCounty(rpData.homeAddr.county);
			enterReposiblePartyPrimaryPhoneNo(rpData.phoneNo);
			enterReposiblePartySignature(rpData.firstName + " " + rpData.lastName);
		}else{
			String signature = null;
			signature = getHOHSignature();
			enterHOHSignature(signature);
		}
		SelectIfMember1ApplyForVoteToday(mem1Data.applyingForVoteToday);		
		clickOnSaveAndContinueBtn();
	}
	
	public void completeRightsAndResponsibilityWithDefaultDetails() throws Exception {
		waitForPageLoaded();
		clickSigningUnderPenaltyOfPerjuryChkBox();
		clickAgreeChkBox();
		String signature = null;
		signature = getHOHSignature();
		enterHOHSignature(signature);
		SelectIfMember1ApplyForVoteToday(false);
		clickOnSaveAndContinueBtn();
	}
	
	public void completeRightsAndResponsibilityWithDefaultDetailsResponsible() throws Exception {
		waitForPageLoaded(); 
		clickSigningUnderPenaltyOfPerjuryChkBox();
		clickAgreeChkBox();
		String signature = null;
		signature = getHOHSignature();
		enterHOHRespnsibleSignature(signature);
		SelectIfMember1ApplyForVoteToday(false);
		clickOnSaveAndContinueBtn();
	}
	
	public void completeRightsAndResponsibilityWithDetails(Boolean applyingForVote) throws Exception {
		waitForPageLoaded();
		clickSigningUnderPenaltyOfPerjuryChkBox();
		clickAgreeChkBox();
		String signature = null;
		signature = getHOHSignature();
		enterHOHSignature(signature);
		SelectIfMember1ApplyForVoteToday(applyingForVote);
		clickOnSaveAndContinueBtn();
	}
	
	//Amrita
	public void completeRightsAndResponsibilityWithSupressNotice(Boolean applyingForVote) throws Exception {
		waitForPageLoaded();
		clickSigningUnderPenaltyOfPerjuryChkBox();
		clickAgreeChkBox();
		SelectIfDocsNeedToBeVerified(true);
		SelectIfNoticesNeedToBeSupressed(true);
		String signature = null;
		signature = getHOHSignature();
		enterHOHSignature(signature);
		SelectIfMember1ApplyForVoteToday(applyingForVote);
		clickOnSaveAndContinueBtn();
	}
	
	public void completeRightsAndResponsibilityWithUnder18HoH(String firstName, String lastName, String relationship, String dob, String hstreetAddress, String hcity, String zipCode, String country, String phoneNo) throws Exception {
		waitForPageLoaded();
		clickSigningUnderPenaltyOfPerjuryChkBox();
		clickAgreeChkBox();

		SelectIfMember1IsEmancipated(false);
		enterReposiblePartyFirstName(firstName);
		enterReposiblePartyLastName(lastName);
		SelectMember1RelationWithResponsibleParty(relationship);
		enterReposiblePartyDOB(dob);
		enterReposiblePartyStreet(hstreetAddress);
		enterReposiblePartyCity(hcity);
		enterReposiblePartyZip(zipCode);
		SelectReposiblePartyCounty(country);
		enterReposiblePartyPrimaryPhoneNo(phoneNo);
		enterReposiblePartySignature(firstName + " " + lastName);

		SelectIfMember1ApplyForVoteToday(false);
		clickOnSaveAndContinueBtn();
	}
	
	public void completeRightsAndResponsibilityWithUnder18HoHInvalidSSN(String firstName, String lastName, String relationship, String dob, String hstreetAddress, String hcity, String zipCode, String country, String phoneNo) throws Exception {
		waitForPageLoaded();
		clickSigningUnderPenaltyOfPerjuryChkBox();
		clickAgreeChkBox();

		SelectIfMember1IsEmancipated(false);
		enterReposiblePartyFirstName(firstName);
		enterReposiblePartyLastName(lastName);
		SelectMember1RelationWithResponsibleParty(relationship);
		enterReposiblePartyDOB(dob);
		enterReposiblePartyStreet(hstreetAddress);
		enterReposiblePartyCity(hcity);
		enterReposiblePartyZip(zipCode);
		SelectReposiblePartyCounty(country);
		enterReposiblePartySSN("333333333");
		enterReposiblePartyPrimaryPhoneNo(phoneNo);
		takeScreenshot("Invalid SSN");
		validateInvalidSSNMsg();
		enterReposiblePartySSN("266524882");
		
		enterReposiblePartySignature(firstName + " " + lastName);
		SelectIfMember1ApplyForVoteToday(false);
		clickOnSaveAndContinueBtn();
	}

	public void completeRightsAndResponsibilityWithDetailsUndr18HoHWhoIsEmancipated() throws Exception {			
		waitForPageLoaded();
		clickSigningUnderPenaltyOfPerjuryChkBox();
		clickAgreeChkBox();

		SelectIfMember1IsEmancipated(true);
		String signature = null;
		signature = getHOHSignature();
		enterHOHSignature(signature);
		SelectIfMember1ApplyForVoteToday(false);
		clickOnSaveAndContinueBtn();
	}
	
	public void validateErrorMessage() throws Exception {
        By errorMsgLabel = By.id("errorMsg2");
        waitForPageLoaded();  
        String errorMsgTxt="We are unable to process your application at this time. Please try again later.";
        validateTextEquals("ErrorMessage", errorMsgLabel, errorMsgTxt);    
        takeScreenshot();
	}
	
	public void takeScreenshot() throws Exception {
        takeScreenshot("ErrorMSG");
	}

	// ppinho
	public void evpdCompleteRightsAndResponsibility(EVPD_MemData mem1Data, ResponsiblePartyData rpData) throws Exception {
		clickSigningUnderPenaltyOfPerjuryChkBox();
		clickAgreeChkBox();
		
		if(mem1Data.isU18){
			SelectIfMember1IsEmancipated(false);
			enterReposiblePartyFirstName(rpData.firstName);
			enterReposiblePartyLastName(rpData.lastName);
			SelectMember1RelationWithResponsibleParty(rpData.relationship);
			enterReposiblePartyDOB(rpData.dob);
			enterReposiblePartyStreet(rpData.homeAddr.streetAddress);
			enterReposiblePartyCity(rpData.homeAddr.city);
			enterReposiblePartyZip(rpData.homeAddr.zipCode);
			SelectReposiblePartyCounty(rpData.homeAddr.county);
			enterReposiblePartyPrimaryPhoneNo(rpData.phoneNo);
			enterReposiblePartySignature(rpData.firstName + " " + rpData.lastName);
		}else{
			String signature = null;
			signature = getHOHSignature();
			enterHOHSignature(signature);
		}
		
		SelectIfMember1ApplyForVoteToday(mem1Data.applyingForVoteToday);
		clickOnSaveAndContinueBtn();
	}
	
}
