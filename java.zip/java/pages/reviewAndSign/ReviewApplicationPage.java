package pages.reviewAndSign;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import enums.IncomeType;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Ritika Gupta
 *
 */
public class ReviewApplicationPage extends CommonPage implements CommonPageOR {

	private static final By reviewApplicationPageHeader = By.xpath("//p[contains(text(),'You can review your application information below')]");
	private static final By contactInfoTab = By.xpath("//h3[contains(.,'Contact Information')]//button");
	private static final By expandFamilyHouseholdTab = By.xpath("//h3[contains(.,'Family & Household')]//button");
	private static final By taxFilingStatusTab = By.xpath("//h3[contains(.,'Tax Filing Status')]//button");
	private static final By expandFamilyIncomeTab = By.xpath("//h3[contains(.,'Family Income')]//button");
	private static final By additionalInfoTab = By.xpath("//h3[contains(.,'Additional Information')]//button");
	private static final By mecUsedInPDTab = By.xpath("//h3[contains(.,'MEC Used In PD')]//button");
	private static final By appSourceDD = By.id("applicationSource");

	public ReviewApplicationPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("ReviewApplicationPageHeader", reviewApplicationPageHeader);
	}

	public void clickOnContactInfoTab() throws Exception {
		clickOnElement("ContactInfoTab", contactInfoTab);
	}

	public void clickOnFamilyHouseholdTab() throws Exception {
		clickOnElement("ExpandFamilyHouseholdBtn", expandFamilyHouseholdTab);
	}

	public void clickOnTaxFilingStatusTab() throws Exception {
		clickOnElement("TaxFilingStatusTab", taxFilingStatusTab);
	}

	public void clickOnFamilyIncomeTab() throws Exception {
		clickOnElement("ExpandFamilyIncomeBtn", expandFamilyIncomeTab);
	}

	public void clickOnAdditionalInfoTab() throws Exception {
		clickOnElement("AdditionalInfoTab", additionalInfoTab);
	}

	public void clickOnMecUsedInPDTab() throws Exception {
		clickOnElement("MecUsedInPDTab", mecUsedInPDTab);
	}

	public void pageLoadThenClickOnContactInfoTab() throws Exception {
		waitForPageLoaded();
		clickOnContactInfoTab();
	}

	public void pageLoadThenClickFamilyHHTab() throws Exception {
		waitForPageLoaded();
		clickOnFamilyHouseholdTab();
	}

	public void pageLoadThenClickOnTaxFilingStatusTab() throws Exception {
		waitForPageLoaded();
		clickOnTaxFilingStatusTab();
	}

	public void pageLoadThenClickOnFamilyIncomeTab() throws Exception {
		waitForPageLoaded();
		clickOnFamilyIncomeTab();
	}

	public void pageLoadThenClickOnAdditionalInfoTab() throws Exception {
		waitForPageLoaded();
		clickOnAdditionalInfoTab();
	}

	public void pageLoadThenClickOnMecUsedInPDTab() throws Exception {
		waitForPageLoaded();
		clickOnMecUsedInPDTab();
	}

	public void validateAddressForHOHUnderContactInfoTab(int memNo, String expAddress) throws Exception {
		By addressLabelForMember = By.xpath("//h3[contains(.,'Contact Information')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Address:']]");
		validateTextEquals("AddressLabelForHOH", addressLabelForMember, expAddress);
	}

	// Amrita
	public void validateEmailForHOHUnderContactInfoTab(int memNo, String expEmail) throws Exception {
		By emailLabelForMember = By.xpath("//h3[contains(.,'Contact Information')]/following-sibling::div[1]//ul[" + memNo + "]/li[2][strong[text()='Email:']]");
		validateTextEquals("EmailLabelForHOH", emailLabelForMember, expEmail);
	}

	// Amrita
	public void validatePhoneForHOHUnderContactInfoTab(int memNo, String expPhone) throws Exception {
		By phoneLabelForMember = By.xpath("//h3[contains(.,'Contact Information')]/following-sibling::div[1]//ul[" + memNo + "]/li[3][strong[text()='Phone:']]");
		validateTextEquals("PhoneLabelForHOH", phoneLabelForMember, expPhone);
	}

	public String getSSNUnderFamilyHHTab(int memNo) throws Exception {
		By ssnLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Social Security Number:']]");
		String ssnTxt = getElementText("SSN", ssnLabelForMember);
		return ssnTxt;
	}

	public void validateSSNIsMaskedUnderFamilyHHTab(int memNo) throws Exception {
		String ssn = getSSNUnderFamilyHHTab(memNo);
		System.out.println("SSN Fetach From UI for Member " + memNo + "Is [" + ssn + "]");
		// validateTextContains("SSNTxt", ssn,"***");
		// validateTextContains("SSNTxt", ssn,"???");
	}

	// Amrita
	public void validateApplyingForCoverageForMemberUnderFamilyHHTab(int memNo, String expApplyingForCovgVal) throws Exception {
		By applyingForCovrgLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Applying for coverage:']]");
		validateTextEquals("AddressLabelForMember" + memNo, applyingForCovrgLabelForMember, expApplyingForCovgVal);
	}

	// Amrita
	public void validateAddressForMemberUnderFamilyHHTab(int memNo, String expAddressVal) throws Exception {
		By addressLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Address:']]");
		validateTextEquals("AddressLabelForMember" + memNo, addressLabelForMember, expAddressVal);
	}

	// Amrita
	public void validateDOBForMemberUnderFamilyHHTab(int memIndex, String expDOBVal) throws Exception {
		By dobLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + (memIndex + 1) + "]/li[strong[text()='Date of Birth:']]");
		validateTextEquals("DOBLabelForMember" + (memIndex + 1), dobLabelForMember, expDOBVal);
	}

	// Amrita
	public void validateCitizenshipForMemberUnderFamilyHHTab(int memNo, String expCitizenshipVal) throws Exception {
		By citizenshipLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Citizenship: ']]");
		validateTextEquals("CitizenshipLabelForMember" + memNo, citizenshipLabelForMember, expCitizenshipVal);
	}

	// Amrita
	public void validateAIANForMemberUnderFamilyHHTab(int memNo, String expAIANVal) throws Exception {
		By aianLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='American Indian/Alaska Native:']]");
		validateTextEquals("AIANLabelForMember" + memNo, aianLabelForMember, expAIANVal);
	}

	// Amrita
	public void validateImmigStatusForMemberUnderFamilyHHTab(int memNo, String expImmigStatusVal) throws Exception {
		By immigStatusLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Immigration status: ']]");
		validateTextEquals("ImmigStatusLabelForMember" + memNo, immigStatusLabelForMember, expImmigStatusVal);
	}

	// Amrita
	public void validateReasonAccomodationForMemberUnderFamilyHHTab(int memNo, String expAccomodationStatusVal) throws Exception {
		By accomodationStatusLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Reasonable Accommodations:']]");
		validateTextEquals("ReasonableAccomodationLabelForMember" + memNo, accomodationStatusLabelForMember, expAccomodationStatusVal);
	}

	// Amrita
	public void validateSpecialConditionForMemberUnderFamilyHHTab(int memNo, String expConditionStatusVal) throws Exception {
		By conditionStatusLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Condition(s):']]");
		validateTextEquals("ConditionsLabelForMember" + memNo, conditionStatusLabelForMember, expConditionStatusVal);
	}

	// Amrita
	public void validateAccomodationForMemberUnderFamilyHHTab(int memNo, String expaccomodationStatusVal) throws Exception {
		By accomodationStatusLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Accommodation(s):']]");
		validateTextEquals("AccomodationLabelForMember" + memNo, accomodationStatusLabelForMember, expaccomodationStatusVal);
	}

	// Amrita
	public void validateIntendToResideForMemberUnderFamilyHHTab(int memNo, String expIntendToResideStatusVal) throws Exception {
		By IntendToResideStatusLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Intend To Reside:']]");
		validateTextEquals("AccomodationLabelForMember" + memNo, IntendToResideStatusLabelForMember, expIntendToResideStatusVal);
	}

	// Amrita
	public void validateIncarceratedStatusForMemberUnderFamilyHHTab(int memNo, String expIncarceratedStatusVal) throws Exception {
		By incarceratedStatusLabelForMember = By.xpath("//h3[contains(.,'Family & Household')]/following-sibling::div[1]//ul[" + memNo + "]/li[strong[text()='Incarcerated:']]");
		validateTextEquals("IncarceratedLabelForMember" + memNo, incarceratedStatusLabelForMember, expIncarceratedStatusVal);
	}

	// Amrita
	public void validateFilingStatusForMemberUnderFamilyHHTab(int memNo, String expFilingStatusVal) throws Exception {
		By filingStatusLabelForMember = By.xpath("//h3[contains(.,'Tax Filing Status')]/following-sibling::div//div[" + (memNo + 1) + "]/ul/li[strong[text()='Status: ']]");
		validateTextEquals("FilingStatusLabelForMember" + memNo, filingStatusLabelForMember, expFilingStatusVal);
	}

	// Amrita
	public void validateFiledTaxesAndAPTCForMemberUnderFamilyHHTab(int memNo, String expFiledTaxesAndAPTCStatusVal) throws Exception {
		By filedTaxesAndAPTCStatusLabelForMember = By.xpath("//h3[contains(.,'Tax Filing Status')]/following-sibling::div//div[" + (memNo + 1) + "]/ul/li[strong[text()='Filed taxes and reconciled all past APTCs?: ']]");
		validateTextEquals("FiledTaxesAndAPTCStatusLabelForMember" + memNo, filedTaxesAndAPTCStatusLabelForMember, expFiledTaxesAndAPTCStatusVal);
	}

	// Amrita
	public void validateAttestationDateForMemberUnderFamilyHHTab(int memNo, String attestationDateVal) throws Exception {
		By attestationDateLabelForMember = By.xpath("//h3[contains(.,'Tax Filing Status')]/following-sibling::div//div[" + (memNo + 1) + "]/ul/li[strong[text()='Attestation Date: ']]");
		validateTextEquals("AttestationDateLabelForMember" + memNo, attestationDateLabelForMember, attestationDateVal);
	}

	// Ritika
	public void validateCapitalGainIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {
		By capitalGainLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Capital Gain')]");
		validateTextContains((memInd + 1) + "CapitalGain", capitalGainLabel, String.valueOf(memsData.get(memInd).capitalGainsMonthlyAmnt));
	}

	// Ritika
	public void validateFarmingOrFishingIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {		
		By farmingOrFishingLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Farming or Fishing')]");
		validateTextContains((memInd + 1) + "FarmingOrFishing", farmingOrFishingLabel, String.valueOf(memsData.get(memInd).farmingAmount));
	}

	// Ritika
	public void validateInterestDividendsIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {
		By interestDividendsLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Interest, Dividends')]");
		validateTextContains((memInd + 1) + "InterestDividends", interestDividendsLabel, String.valueOf(memsData.get(memInd).interestAmt));
	}

	// Ritika
	public void validateJobIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {
		By jobLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Job')]");
		validateTextContains((memInd + 1) + "Job", jobLabel, String.valueOf(memsData.get(memInd).jobIncomeAmount));
	}

	// Ritika
	public void validateRentalRoyaltyIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {
		By rentalRoyaltyLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Rental or Royalty')]");
		validateTextContains((memInd + 1) + "RentalRoyalty", rentalRoyaltyLabel, String.valueOf(memsData.get(memInd).royaltyAmtPerMonth));
	}

	// Ritika
	public void validateSelfEmploymentIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {
		By selfEmploymentLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Self-Employment')]");
		validateTextContains((memInd + 1) + "selfEmployment", selfEmploymentLabel, String.valueOf(memsData.get(memInd).selfEmpProfitAmountMonthly));
	}

	// Ritika
	public void validateSSBIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {
		By sSBLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Social Security')]");
		validateTextContains((memInd + 1) + "SSB", sSBLabel, String.valueOf(memsData.get(memInd).ssbAmt));
	}

	// Ritika
	public void validateAlimonyIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {
		By alimonyLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Alimony')]");
		validateTextContains((memInd + 1) + "Alimony", alimonyLabel, String.valueOf(memsData.get(memInd).AlimonyAmt));
	}

	// Ritika
	public void validateOtherIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {
		By otherLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Other Income')]");
		validateTextContains((memInd + 1) + "OtherIncome", otherLabel, String.valueOf(memsData.get(memInd).otherIncomeAmt));
	}

	// Ritika
	public void validateRetirementIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {
		By retirementLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Retirement')]");
		validateTextContains((memInd + 1) + "Retirement", retirementLabel, String.valueOf(memsData.get(memInd).RetirementAmt));
	}

	// Ritika
	public void validateUnemploymentIncomeForMemberUnderFamilyIncomeTab(List<EVPD_MemData> memsData, int memInd) throws Exception {
		By unemploymentLabel = By.xpath("//h3[contains(.,'Family Income')]/..//h4['" + memsData.get(memInd).fullName + "']/../ul[" + (memInd + 1) + "]/li[contains(.,'Unemployment')]");
		validateTextContains((memInd + 1) + "Unemployment", unemploymentLabel, String.valueOf(memsData.get(memInd).UnemploymentAmt));
	}

	// Ritika
	public void validateHasMECForMemberUnderAdditionalInfoTab(int memNo, String expHasMECStatusVal) throws Exception {
		By hasMECLabel = By.xpath("//h3[contains(.,'Additional Information')]/following-sibling::div//ul[" + memNo + "]/li[strong[text()='Has Minimum Essential Coverage (MEC):']]");
		validateTextContains("Has MEC Status For Member" + memNo, hasMECLabel, expHasMECStatusVal);
	}

	// Amrita
	public void validateEnrollsInESICoverageForMemberUnderAdditionalInfoTab(int memNo, String expEnrollsInESICoveragestatusVal) throws Exception {
		By enrollsInESICoverageLabel = By.xpath("//h3[contains(.,'Additional Information')]/following-sibling::div//ul[" + memNo + "]/li[strong[text()='Has Option to Enroll in Employer Health Coverage:']]");
		validateTextContains("Has Option to Enroll in Employer Health Coverage for Member" + memNo, enrollsInESICoverageLabel, expEnrollsInESICoveragestatusVal);
	}

	// Amrita
	public void validateHasAffordableESIForMemberUnderAdditionalInfoTab(int memNo, String expHasAffordableESIstatusVal)
			throws Exception {
		By hasAffordableESILabel = By.xpath("//h3[contains(.,'Additional Information')]/following-sibling::div//ul[" + memNo + "]/li[strong[text()='Has Affordable Employer Sponsored Insurance(ESI):']]");
		validateTextContains("Has Affordable ESI for Member" + memNo, hasAffordableESILabel, expHasAffordableESIstatusVal);
	}

	// Amrita
	public void validateHasFederalMECForMemberUnderMECPDTab(int memNo, String exphasFederalMECstatusVal) throws Exception {
		By hasFederalMECLabel = By.xpath("//h3[contains(.,'MEC Used In PD')]/following-sibling::div/div[" + memNo + "]/ul/li[contains(.,'Has Federal MEC:')]");
		validateTextContains("Has Federal MEC For Member" + memNo, hasFederalMECLabel, exphasFederalMECstatusVal);
	}

	// Amrita
	public void validateMECTypeForMemberUnderMECPDTab(int memNo, String expMECTypestatusVal) throws Exception {
		By MECTypeLabel = By.xpath("//h3[contains(.,'MEC Used In PD')]/following-sibling::div/div[" + memNo + "]/ul/li[contains(.,'Federal MEC Type:')]");
		validateTextContains("Federal MEC Type for Member" + memNo, MECTypeLabel, expMECTypestatusVal);
	}

	// Amrita
	public void validateHasMMISMECForMemberUnderMECPDTab(int memNo, String expMMISMECstatusVal) throws Exception {
		By MMISMECLabel = By.xpath("//h3[contains(.,'MEC Used In PD')]/following-sibling::div/div[" + memNo + "]/ul/li[contains(.,'Has MMIS MEC:')]");
		validateTextContains("Has MMIS MEC For Member" + memNo, MMISMECLabel, expMMISMECstatusVal);
	}

	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn, 5);
	}
	
	public void clickOnAdditionalDocumentsProofsBtn() throws Exception {
		By additionalDocumentsProofsBtn = By.xpath("//input[@id='hasDocumentProofs1']/../label");
		clickOnElement("AdditionalDocumentsProofsBtn", additionalDocumentsProofsBtn);
	}

	public void takeScreenShot() throws Exception {
		takeScreenshot("Review Application");
	}

	public void selectAppSourceAsOther() throws Exception {
		selectDropDownElementByVisibleText("AppSource", appSourceDD, "Other");
	}

	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}

	public void SelectAppSourceAsOtherAndClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoaded();
		selectAppSourceAsOther();
		clickOnSaveAndContinueBtn();
	}

	public void validateIncomeThenClickOnSaveAndContinueBtn(boolean faReqd, List<EVPD_MemData> memsData) throws Exception {
		if (faReqd) {
			waitForPageLoaded();
			clickOnFamilyIncomeTab();
			int memCount = memsData.size();
			for (int mCounter = 0; mCounter < memCount; mCounter++) {
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.JOB.val)) {
					validateJobIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.SELF_EMPLOYMENT.val)) {
					validateSelfEmploymentIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.SOCIAL_SECURITY_BENEFITS.val)) {
					validateSSBIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.UNEMPLOYMENT.val)) {
					validateUnemploymentIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.RETIREMENT.val)) {
					validateRetirementIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.CAPITALGAINS.val)) {
					validateCapitalGainIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.INVESTMENT_INCOME.val)) {
					validateInterestDividendsIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.RENTAL_OR_ROYALTY_INCOME.val)) {
					validateRentalRoyaltyIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.FARMING_OR_FISHING_INCOME.val)) {
					validateFarmingOrFishingIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.ALIMONY_RECEIVED.val)) {
					validateAlimonyIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
				if (memsData.get(mCounter).incomeTypes.contains(IncomeType.OTHER_INCOME.val)) {
					validateOtherIncomeForMemberUnderFamilyIncomeTab(memsData, mCounter);
					memsData.get(mCounter).jobSourceCount++;
				}
			}

			takeScreenshot("Summary");
			clickOnSaveAndContinueBtn();
		}
	}

	// ppinho
	public void evpdReviewApplicationThenClickOnSaveAndContinueBtn(EVPD_Data evpdData) throws Exception {
		if(evpdData.faReqd){
			clickOnFamilyIncomeTab();
			
			for(int memInd = 0; memInd < evpdData.memCount; memInd++){
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.JOB.val)){
					validateJobIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.SELF_EMPLOYMENT.val)){
					validateSelfEmploymentIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.SOCIAL_SECURITY_BENEFITS.val)){
					validateSSBIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.UNEMPLOYMENT.val)){
					validateUnemploymentIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.RETIREMENT.val)){
					validateRetirementIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.CAPITALGAINS.val)){
					validateCapitalGainIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.INVESTMENT_INCOME.val)){
					validateInterestDividendsIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.RENTAL_OR_ROYALTY_INCOME.val)){
					validateRentalRoyaltyIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.FARMING_OR_FISHING_INCOME.val)){
					validateFarmingOrFishingIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.ALIMONY_RECEIVED.val)){
					validateAlimonyIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
				if(evpdData.memsData.get(memInd).incomeTypes.contains(IncomeType.OTHER_INCOME.val)){
					validateOtherIncomeForMemberUnderFamilyIncomeTab(evpdData.memsData, memInd);
					evpdData.memsData.get(memInd).jobSourceCount++;
				}
			}
			
			takeScreenshot("Review Application Summary");
			
			for(int memInd = 0; memInd < evpdData.memCount; memInd++){
				if(!evpdData.memsData.get(memInd).rfiInd){
					clickOnAdditionalDocumentsProofsBtn();
					break;
				}
			}
			
			clickOnSaveAndContinueBtn();
		}
	}
}
