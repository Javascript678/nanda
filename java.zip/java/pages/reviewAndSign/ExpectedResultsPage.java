package pages.reviewAndSign;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import enums.IncomeType;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Ritika Gupta
 *
 */
public class ExpectedResultsPage extends CommonPage implements CommonPageOR {

	private static final By expectedResultsPageHeader = By.xpath("//h1[contains(text(),'Expected Results')]");

	public ExpectedResultsPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("ExpectedResultsPageHeader", expectedResultsPageHeader);
	}

	public boolean isIncomeRfiActive() throws Exception {
		By activeIncomeRfi = By.xpath("//tbody//th['Income']/../td[contains(text(), 'Active')]");
		return isElementPresent(activeIncomeRfi);
	}

	public void clickOnChangeUpdateIncomeLink() throws Exception {
		By changeUpdateIncomeLink = By.xpath("//tbody//th['Income']/../td/a");
		clickOnElement("ChangeUpdateIncomeLink", changeUpdateIncomeLink);
	}

	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn, 5);
	}

	public void takeScreenShot() throws Exception {
		takeScreenshot("Expected Results");
	}

	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}

	// ppinho
	public void evpdValidateExpectedResultsClickOnSaveAndContinueBtn(EVPD_Data evpdData) throws Exception {
		if(isIncomeRfiActive()){
			clickOnChangeUpdateIncomeLink();
		}else{
			clickOnSaveAndContinueBtn();
		}
	}
}
