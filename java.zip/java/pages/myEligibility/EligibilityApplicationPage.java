package pages.myEligibility;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import pages.eligibilityResult.CurrentYearEligibilityResultPage;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class EligibilityApplicationPage extends CommonPage implements CommonPageOR {

	private static final By eligibilityAppPageHeader = By
			.xpath("//h1[contains(text()[normalize-space()],'Eligibility Application')]");
	private static final By backToAccDashboardBtn = By.xpath("//input[@value='Back to Account Dashboard']");

	// Added by Brajesh for Eligibility History check defect 18267
	private static final By myEligibilityTab = By.xpath("//div[@id='subNav']//li[2]/a");
	private static final By expandEligibilityHistory = By.id("expandCollapse");
	private static final By elgHistoryTableRow = By.xpath("//div[@id='eligibilityHistoryContainer']//tbody/tr");

	public EligibilityApplicationPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void clickOnBackToAccDashboardBtn() throws Exception {
		clickOnElement("BackToAccDashboardBtn", backToAccDashboardBtn);
	}

	// Added by Brajesh for Eligibility History check defect 18267
	public void clickOnDetailLnkOneByOne(int i) throws Exception {
		By detailAppLnktableUnderEligibilityHistory = By.xpath("//div[@id='eligibilityHistoryContainer']//tbody/tr[" + (i + 1) + "]/td[4]//a");
		clickOnElement("detailLnkEligibilityHistory", detailAppLnktableUnderEligibilityHistory);

	}

	// Added by Brajesh for Eligibility History check defect 18267
	public void clickOnMyEligibilityTab() throws Exception {
		clickOnElement("myEligibilityTab", myEligibilityTab);
		;
	}

	// Added by Brajesh for Eligibility History check defect 18267
	public void clickOnEligibilityHistorySection() throws Exception {
		clickOnElement("expandEligibilityHistory", expandEligibilityHistory);
	}

	// Added by Brajesh for Eligibility History check defect 18267
	public int getEligibilityHistoryTableRowCount() {
		int rowCount = getElementCount(elgHistoryTableRow);
		return rowCount;
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocatedThenWait("EligibilityAppPageHeader", eligibilityAppPageHeader, 10);
	}

	public void expandYrSection(String yr) throws Exception {
		By currentYrSection = By.xpath("//div/span[contains(.,'" + yr + "')]/parent::div");
		String expandCollpse = getElementAttribute("Year" + yr + "Section", currentYrSection, "aria-expanded");
		if (expandCollpse.equalsIgnoreCase("false")) {
			clickOnElement("Year" + yr + "Section", currentYrSection);
		}
	}

	public void clickOnEligibilityDetailsLink(String year) throws Exception {
		final By detailAppLnk = By.xpath("//span[contains(text(),'" + year + "')]//ancestor::div[@class='panel panel-default']/div[2]//table[contains(@id,'eligibilityListTable')]/tbody/tr/td[4]//li/a[contains(text(),'Detail')]");
		clickOnElement("DetailAppLnkForYear" + year, detailAppLnk);
	}

	public void clickOnEligibilityReviewSummaryLink(String year) throws Exception {
		final By detailAppLnk = By.xpath("//span[contains(text(),'" + year + "')]//ancestor::div[@class='panel panel-default']/div[2]//table[contains(@id,'eligibilityListTable')]/tbody/tr/td[4]//li/a[contains(text(),'Review Summary')]");
		clickOnElement("ReviewSummaryAppLnkForYear" + year, detailAppLnk);
	}

	public boolean isEligibilityEditLinkPresent(String year) throws Exception {
		final By editAppLink = By.xpath("//span[contains(text(),'" + year
				+ "')]//ancestor::div[@class='panel panel-default']/div[2]//table[contains(@id,'eligibilityListTable')]/tbody/tr/td[4]//li/a[contains(text(),'Edit Application')]");
		return isElementPresent(editAppLink);
	}

	public void clickOnEditApplicationLink(String year) throws Exception {
		final By editAppLink = By.xpath("//span[contains(text(),'" + year
				+ "')]//ancestor::div[@class='panel panel-default']/div[2]//table[contains(@id,'eligibilityListTable')]/tbody/tr/td[4]//li/a[contains(text(),'Edit Application')]");
		clickOnElement("EditAppLinkForYear" + year, editAppLink);
	}

	public void clickOnEditLink(String year) throws Exception {
		final By editLink = By.xpath("//span[contains(text(),'" + year
				+ "')]//ancestor::div[@class='panel panel-default']/div[2]//table[contains(@id,'eligibilityListTable')]/tbody/tr/td[4]//li/a[contains(text(),'Edit')]");
		clickOnElement("EditLinkForYear" + year, editLink);
	}

	public void performActionclickOnEditLink(String year) throws Exception {
		waitForPageLoaded();
		expandYrSection(year + "");
		clickOnEditLink(year);
	}

	public void clickOnReportAChangeLink(String year) throws Exception {
		final By reportAChangeLink = By.xpath("//span[contains(text(),'" + year
				+ "')]//ancestor::div[@class='panel panel-default']/div[2]//table[contains(@id,'eligibilityListTable')]/tbody/tr/td[4]//li/a[contains(text(),'Report a Change')]");
		waitForPageLoaded();
		expandYrSection(year);
		clickOnElementAfterWait("ReportAChangeLinkForYear" + year, reportAChangeLink, 3);
	}

	public boolean isUndoChangeLinkPresent(String year) throws Exception {
		final By undoChangesLink = By.xpath("//span[contains(text(),'" + year
				+ "')]//ancestor::div[@class='panel panel-default']/div[2]//table[contains(@id,'eligibilityListTable')]/tbody/tr/td[4]//li/a[contains(text(),'Undo Change')]");
		return isElementPresent(undoChangesLink);
	}

	public void clickOnUndoChangeLink(String year) throws Exception {
		final By undoChangesLink = By.xpath("//span[contains(text(),'" + year
				+ "')]//ancestor::div[@class='panel panel-default']/div[2]//table[contains(@id,'eligibilityListTable')]/tbody/tr/td[4]//li/a[contains(text(),'Undo Change')]");
		clickOnElement("UndoChangesLinkForYear" + year, undoChangesLink);
	}

	public String getLatestEligibilityId(String year) throws Exception {
		final By elgIdtxt = By.xpath("//span[contains(text(),'" + year
				+ "')]//ancestor::div[@class='panel panel-default']/div[2]//table[contains(@id,'eligibilityListTable')]/tbody/tr/th[1]");
		return getElementText(elgIdtxt);
	}

	public boolean isAlertPresent() throws Exception {
		return isElementPresent(alertDialog);
	}

	public void clickOnAlertOkBtn() throws Exception {
		clickOnElement("AlertOkButton", alertOkButton);
	}

	public void clickOnAlertCancelBtn() throws Exception {
		clickOnElement("AlertCancelButton", alertCancelButton);
	}

	//
	public void pageLoadAndClickOnEligibilityDetailsLink(String yr) throws Exception {
		waitForPageLoaded();
		expandYrSection(yr + "");
		clickOnEligibilityDetailsLink(yr);
	}

	public void pageLoadAndClickOnEligibilityReviewSummaryLink(String yr) throws Exception {
		waitForPageLoaded();
		expandYrSection(String.valueOf(yr));
		clickOnEligibilityReviewSummaryLink(yr);
	}

	public void performActionToGoToReportAChangePage(String yr) throws Exception {
		waitForPageLoaded();
		expandYrSection(yr + "");
		if (isUndoChangeLinkPresent(yr + "")) {
			clickOnUndoChangeLink(yr + "");
			clickOnAlertOkBtn();
		}

		if (isEligibilityEditLinkPresent(yr + "")) {
			clickOnEditApplicationLink(yr + "");
			clickOnAlertOkBtn();
		}
		clickOnReportAChangeLink(yr + "");
	}

	public void performActionUndoChangesLink(String year) throws Exception {
		waitForPageLoaded();
		expandYrSection(year + "");
		clickOnUndoChangeLink(year);
		clickOnAlertOkBtn();
	}

	// Added by Brajesh for Eligibility History check defect 18267
	public void validateAllEligibiliyDetailsLinkInHistoryTab() throws Exception {
		waitForPageLoaded();

		clickOnEligibilityHistorySection();
		int rowCount = getEligibilityHistoryTableRowCount();
		takeScreenshot("EligibilityHistoryTable");

		for (int rowCounter = 0; rowCounter < rowCount; rowCounter++) {

			clickOnDetailLnkOneByOne(rowCounter);

			CurrentYearEligibilityResultPage currentYearEligibilityResultPage = new CurrentYearEligibilityResultPage(
					driver, testCaseId);
			currentYearEligibilityResultPage.waitForPageLoaded();
			currentYearEligibilityResultPage.clickOnShowMedicaidHHDetailseBtn();
			takeScreenshot("MEDICAID_HH_details_For_Elg_" + (rowCounter + 1));
			clickOnMyEligibilityTab();
			clickOnEligibilityHistorySection();
		}
	}

}
