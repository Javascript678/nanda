package pages.AdminClosingHistory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

public class AdminClosingHistory extends CommonPage implements CommonPageOR {

	public AdminClosingHistory(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private static final By accountDashboardPageHeader = By.id("srAppDetails");
	private LeftMenu leftMenu = new LeftMenu();
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("AccountDashboardPageHeader", accountDashboardPageHeader);
	}
	
	private class LeftMenu{
		private final By leftMenuSlider = By.id("dashboardLeftmenuSlider");
		private final By adminclosingHistoryLink	= By.xpath("//span[text()='Administrative Closing History']");
		
		
		private void clickOnLeftMenuSlider() throws Exception{
			clickOnElement("LeftMenuSlider",leftMenuSlider);
		}
		
		private void clickOnAdminClosingHistoryLink() throws Exception{
			clickOnElement("AdminClosingHistoryLink",adminclosingHistoryLink);
		}
     }
	
	private class AdminClosureHistoryHomePage{
        private final By adminclosinghistoryheader	= By.xpath("//h1[contains(text(),'Administrative Closing History')]");
		
		
		private void waitForPageLoaded() throws Exception{
			waitForPresenceOfElementLocated("AdminClosingHistoryPageHeader", adminclosinghistoryheader);
		}
		
		private void VerifyTableHeadersPresent() throws Exception{
			By membernameheader=By.xpath("//div[@class='table-responsive'and contains(.,'Member(s)')]/table/thead/tr/th[1]");
			By adminclosingstartdateheader=By.xpath("//div[@class='table-responsive'and contains(.,'Start Effective Date')]/table/thead/tr/th[3]");
			By adminclosingreasonheader=By.xpath("//div[@class='table-responsive'and contains(.,'Administrative Closing Reason')]/table/thead/tr/th[5]");
			isElementPresent(membernameheader);
			isElementPresent(adminclosingstartdateheader);
			isElementPresent(adminclosingreasonheader);
				
		}
		
		private void VerifyTableHeaderValues(String MemberName, String AdminClosureDate, String AdminClosureReason) throws Exception{
			By membernamevalue=By.xpath("//div[@class='table-responsive']/table/tbody/tr/th[1]");
			By adminclosingstartdatevalue=By.xpath("//div[@class='table-responsive']/table/tbody/tr/td[2]");
			By adminclosingreasonvalue=By.xpath("//div[@class='table-responsive']/table/tbody/tr/td[4]");
			isElementPresent(membernamevalue);
			isElementPresent(adminclosingstartdatevalue);
			isElementPresent(adminclosingreasonvalue);
			isAttributePresent(membernamevalue, MemberName);
			isAttributePresent(adminclosingstartdatevalue, AdminClosureDate);
			isAttributePresent(adminclosingreasonvalue, AdminClosureReason);
			takeScreenshot("AdminClosingHistoryPage");
		}
		
		
	}
}

