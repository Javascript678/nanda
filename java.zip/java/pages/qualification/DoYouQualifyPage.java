package pages.qualification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class DoYouQualifyPage extends CommonPage implements CommonPageOR{

	private static final By doYouQualifyPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Do You Qualify?')]");
	By continueBtn = By.xpath("//input[contains(@value,'Continue') and @type='submit']");
	
	public DoYouQualifyPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("DoYouQualifyPageHeader", doYouQualifyPageHeader);
	}
	
	
	
	private void clickOnContinueBtn() throws Exception{
		clickOnElement("ContinueBtn", continueBtn);
	}
	
	public void pageLoadAndClickOnContinue() throws Exception{
		waitForPageLoaded();
		clickOnContinueBtn();
	}
}
