package pages.qualification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class FamilyDetailsSpecialConditionPage extends CommonPage implements CommonPageOR{

	private static final By familyDetailsSpclConditionPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Family Details')]");
	private static final By saveAndContinueBtn = By.id("submitWithSave");
	
	public FamilyDetailsSpecialConditionPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("FamilyDtlsSpclConditionPgHeader", familyDetailsSpclConditionPageHeader);
	}
	
	private void selectDisabilityStatusForMember(int memIndex, boolean trueFalseValue) throws Exception {
		By disableRdBtn = By.name("eligibilityMember["+memIndex+"].eligibilityMemberAdditionalInfo.isDisabled");
		selectByValue("Mem"+(memIndex+1)+"DisableRdBtn", disableRdBtn, trueFalseValue+"");
	}
	
	private void selectAIANStatusForMember(int memIndex, boolean trueFalseValue) throws Exception {
		By americanIndianRdBtn = By.name("eligibilityMember["+memIndex+"].eligibilityMemberAdditionalInfo.isAmericanIndian");
		selectByValue("Mem"+(memIndex+1)+"AmericanIndianRdBtn", americanIndianRdBtn, trueFalseValue+"");
	}
	
	private void selectIncarcerationStatusForMember(int memIndex, boolean trueFalseValue) throws Exception {
		By incarcerationRdBtn = By.name("eligibilityMember["+memIndex+"].incarceration.incarcerated");
		selectByValue("Mem"+(memIndex+1)+"IncarcerationRdBtn", incarcerationRdBtn, trueFalseValue+"");
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("ContinueBtn", saveAndContinueBtn);
	}
	
	public void enterSpecialConditionForMember(int memIndex, boolean isDisabled, boolean isAIAN,boolean isIncarcerated) throws Exception{
		waitForPageLoaded();
		selectDisabilityStatusForMember(memIndex, isDisabled);
		selectAIANStatusForMember(memIndex, isAIAN);
		selectIncarcerationStatusForMember(memIndex, isIncarcerated);
		clickOnSaveAndContinueBtn();
	}
}
