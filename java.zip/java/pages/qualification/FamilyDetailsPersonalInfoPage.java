package pages.qualification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class FamilyDetailsPersonalInfoPage extends CommonPage implements CommonPageOR{

	private static final By familyDetailsPersonalInfoPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Family Details')]");
	private static final By saveAndContinueBtn = By.id("submitWithSave");
	
	public FamilyDetailsPersonalInfoPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("FamilyDetailsPersonalInfoPgHeader", familyDetailsPersonalInfoPageHeader);
	}
	
	private void enterFirstNameForMember(int memIndex, String fName) throws Exception {
		By firstNameTxt = By.id("eligibilityMember["+memIndex+"].name.firstName");
		clearAndType("Mem"+(memIndex+1)+"FNameTxt", firstNameTxt, fName);
	}
	
	private void enterDOBForMember(int memIndex, String dob) throws Exception {
		By dobTxt = By.id("eligibilityMember["+memIndex+"].dobNoDay");
		clearAndType("Mem"+(memIndex+1)+"DOBTxt", dobTxt, dob);
	}
	
	private void enterGenderForMember(int memIndex, String gender) throws Exception {
		By genderRdBtn = By.name("eligibilityMember["+memIndex+"].gender");
		selectByValue("Mem"+(memIndex+1)+"GenderRdBtn", genderRdBtn, gender);
	}
	
	/**
	 * Accepted Value 
	 * 		"U.S. Citizen"																0
	 * 		"Legal Permanent Resident for 5 years or more"								1
	 * 		"Legal Permanent Resident for less than 5 years or Employment Authorized"	2
	 * 		"Pending Immigration Status"												3
	 * 		"None of the above"															4
	 * @param memIndex
	 * @param citizenshipStatus
	 * @throws Exception
	 */
	private void enterCitizenshipStatusForMember(int memIndex, String citizenshipStatus) throws Exception {
		By citizenStatusDD = By.id("eligibilityMember["+memIndex+"].citizenshipStatus");
		selectDropDownElementByVisibleText("Mem"+(memIndex+1)+"CitizenStatusDD", citizenStatusDD, citizenshipStatus);
	}
	
	private void selectIfMemberIsLivingInMA(int memIndex, boolean trueFalseValue) throws Exception {
		By livingInMARdBtn = By.name("eligibilityMember["+memIndex+"].isLivingOutside");
		selectByValue("Mem"+(memIndex+1)+"LivingInMARdBtn", livingInMARdBtn, trueFalseValue+"");
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElementThenWait("ContinueBtn", saveAndContinueBtn,4);
	}
	
	public void enterPersonalInfoForMember(int memIndex, String fName, String dob, String gender, String citizenshipStatus, boolean isLivingInMA) throws Exception{
		waitForPageLoaded();
		enterFirstNameForMember(memIndex, fName);
		enterDOBForMember(memIndex, dob);
		enterGenderForMember(memIndex, gender);
		enterCitizenshipStatusForMember(memIndex, citizenshipStatus);
		selectIfMemberIsLivingInMA(memIndex, isLivingInMA);
		clickOnSaveAndContinueBtn();
	}
}
