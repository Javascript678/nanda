package pages.qualification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class EligibilityResultPage extends CommonPage implements CommonPageOR{

	private static final By eligibilityResultPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Eligibility Results')]");
	
	
	public EligibilityResultPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("EligibilityResultPageHeader", eligibilityResultPageHeader);
	}
	
	private void validateProgramNameForMember(int memIndex, String expProgramName) throws Exception{
		By programNameLabel = By.xpath("//table[caption[text()='Program Eligibility']]/tbody["+(memIndex+1)+"]//td//span");
		validateTextContains("Mem"+(memIndex+1)+"ProgramName", programNameLabel, expProgramName);
	}
	
	public void pageLoadAndValidateProgramNamesBothMember(String expProgramName) throws Exception{
		waitForPageLoaded();
		validateProgramNameForMember(0, expProgramName);
		validateProgramNameForMember(1, expProgramName);
		takeScreenshot("MemProgram");
	}
}
