package pages.qualification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class IncomeDetailsPage extends CommonPage implements CommonPageOR{

	private static final By incomeDetailsPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Income Details')]");
	private static final By annualHHIncomeTxt 	= By.id("annual_household_income");
	private static final By saveAndContinueBtn = By.xpath("//input[contains(@value,'Continue') and @type='submit']");
	
	public IncomeDetailsPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("IncomeDetailsPageHeader", incomeDetailsPageHeader);
	}
	
	private void enterAnnualIncomeForHH(String annualIncome) throws Exception {
		clearAndType("AnnualHHIncome", annualHHIncomeTxt, annualIncome);
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("ContinueBtn", saveAndContinueBtn);
	}
	
	public void provideAnnualIncomeForHH(String annualHHIncome) throws Exception{
		waitForPageLoaded();
		enterAnnualIncomeForHH(annualHHIncome);
		takeScreenshot("AnnualHHIncome");
		clickOnSaveAndContinueBtn();
	}
}
