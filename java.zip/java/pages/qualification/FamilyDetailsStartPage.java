package pages.qualification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class FamilyDetailsStartPage extends CommonPage implements CommonPageOR{

	private static final By familyDetailsStartPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Family Details')]");
	private static final By removeMemberBtn = By.xpath("//a[contains(@class,'minusBtnTxt')]");
	private static final By memberCount = By.id("memberCount");
	private static final By addMemberBtn = By.xpath("//a[contains(@class,'plusBtnTxt')]");
	private static final By saveAndContinueBtn = By.id("submitWithSave");
	
	public FamilyDetailsStartPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("FamilyDetailsStartPageHeader", familyDetailsStartPageHeader);
	}
	
	private void clickOnRemoveMemberBtn() throws Exception{
		clickOnElement("RemoveMemberBtn", removeMemberBtn);
	}
	
	private String getMemberCount() throws Exception{
		return getElementText("MemberCount", memberCount);
	}
	
	private void clickOnAddMemberBtn() throws Exception{
		clickOnElement("AddMemberBtn", addMemberBtn);
	}
		
	private void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElementThenWait("ContinueBtn", saveAndContinueBtn,4);
	}
	
	public void enterNoOfPeopleInYourHH(int memCount) throws Exception{
		waitForPageLoaded();
		for(int mCounter=0; mCounter < memCount-1; mCounter++){
			clickOnAddMemberBtn();
		}
		clickOnSaveAndContinueBtn();
	}
}
