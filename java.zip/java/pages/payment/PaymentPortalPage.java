package pages.payment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
/**
 * 
 * @author Paul Pinho
 *
 */
public class PaymentPortalPage extends CommonPage{
	
	
	private static final By paymentPageHeader = By.xpath("//h1[contains(.,'You currently have no current or past Health Connector health or dental plan information on record')]");
	
	public PaymentPortalPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		switchWindow();
		waitForPresenceOfElementLocated("PaymentPageHeader", paymentPageHeader);
	}
	
	
	public void takeScreenshot() throws Exception{
		takeScreenshot("Summary");
	}	
}
