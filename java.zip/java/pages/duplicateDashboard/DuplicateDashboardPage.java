package pages.duplicateDashboard;

import org.openqa.selenium.By;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import org.openqa.selenium.WebDriver;

/**
 * 
 * @author Paul
 *
 */
public class DuplicateDashboardPage extends CommonPage implements CommonPageOR {

	public DuplicateDashboardPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private static final By duplicateDashboardHeader = By.xpath("//h1[contains(text()[normalize-space()],'Duplicate Dashboard')]");

	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("Duplicate Dashboard Header", duplicateDashboardHeader);
	}
	
	private void enterIgnoreDuplicateReason(String id) throws Exception{
		By ignoreDuplicateReasonBtn = By.xpath("//*[@id='reasonNotesBtn_" + id +"']");
		enterText("Ignore Duplicate Reason" , ignoreDuplicateReasonBtn, "Update");
	}
	
	private void clickOnSaveUpdate() throws Exception{
		By saveBtn = By.xpath("//span[contains(text(),'Save')]");
		clickOnElement("Save", saveBtn);	
		refreshCurrentPage();
	}
	
	public void validateOverridenForMember(String memNo, String id, String memOverridden) throws Exception{
		By expandMemBtn = By.xpath("//*[@id='outer-ui-accordion-accordion-header_" + memNo +"']");
		By duplicateMemberTableDD = By.xpath("//*[@id='table_" + id + "']/tbody/tr/td[5]");
		
		String expandCollpse = getElementAttribute("AttributeValue", expandMemBtn, "aria-expanded");
		
		if(expandCollpse.equalsIgnoreCase("false")){
			clickOnElement("Expand Member", expandMemBtn);	
		}
		
		validateTextEquals("Member " + (id) + " Overriden Status", duplicateMemberTableDD, memOverridden);		
	}
	
	// Paul
	public void clickOnIgnoreDuplicate(String memNo, String id) throws Exception{
		By expandMemBtn = By.xpath("//*[@id='outer-ui-accordion-accordion-header_" + memNo +"']");
		By ignoreDuplicateBtn = By.xpath("//*[@id='reasonNotesBtn_" + id +"']");
		
		String expandCollpse = getElementAttribute("AttributeValue", expandMemBtn, "aria-expanded");
		
		if(expandCollpse.equalsIgnoreCase("false")){
			clickOnElement("Expand Member", expandMemBtn);	
		}
		
		clickOnElement("Ignore Duplicate", ignoreDuplicateBtn);
		enterIgnoreDuplicateReason(id);
		clickOnSaveUpdate();
	}
	
	public void clickOnRerunDupCheckBtn() throws Exception{
		By rerunDupCheckDD = By.id("rerunErrorcheck");
		clickOnElement("RerunDupCheck", rerunDupCheckDD);	
	}
	
}
