package pages.rfi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

public class UpdateSSNPage extends CommonPage implements CommonPageOR {

	private static final By SSNRFIHeader= By.xpath("//div[@id='application']//h1[contains(.,'Update SSN')]");
	private static final By commentsTxt = By.id("comment");

	static final By warningOkButton = By.id("popup_ok");
	public UpdateSSNPage(WebDriver driver, String featureName) 
	{
		super(driver,featureName);
	}
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("SSNRFIHeader", SSNRFIHeader);
	}
	
	public void enterComments(String Comments) throws Exception {
		enterText("CommentsTxt" , commentsTxt, Comments);
		}
	
	public void clickOnChkBoxForMembertoVerifySSN(String name) throws Exception{
		By MemberChkBox = By.xpath("//div[@id='membersForSSNUpdate']//tr/th/div/label[contains(.,'"+name+"')]/input");
				
		clickOnElement("MemberChkBox", MemberChkBox);
	}
	
	public void EnterSSNForMember(int memIndex, String ssn) throws Exception{
		By SSNTxtBox = By.id("ssn"+memIndex);				
		enterText("SSNTextBox", SSNTxtBox, ssn);
	}
	
	public String getSSNTxtForMember(int memIndex) throws Exception{
		By SSNTxtBox = By.id("ssn"+memIndex);				
		return getElementAttribute("SSNTxt", SSNTxtBox, "value");
	}
	
	public void validateSSNIsMaskedForMember(int memIndex) throws Exception{
		By ssnTxt = By.name("members["+memIndex+"].ssn");
		String ssn = getSSNTxtForMember(memIndex);	
		validateElementAttribute("SSNTxt", ssnTxt, "type", "hidden");
		System.out.println(ssn);
		//validateTextContains("SSNTxt", ssn, "XXX-XX-");
	}
	
	public String getConfirmationSSNTxtForMember(int memIndex) throws Exception{
		By ConfirmSSNTxtBox = By.id("confirmedSsn"+memIndex);				
		return getElementAttribute("ConfSSNTxt"+memIndex, ConfirmSSNTxtBox, "value");
	}
	
	public void validateConfirmationSSNIsMaskedForMember(int memIndex) throws Exception{
		By confirmSSNTxt = By.name("members["+memIndex+"].confirmedSsn");
		String ssn = getConfirmationSSNTxtForMember(memIndex);
		System.out.println(ssn);
		validateElementAttribute("ConfSSNTxt", confirmSSNTxt, "type", "hidden");
		//validateTextContains("ConfSSNTxt", ssn, "XXX-XX-");
	}
	
	public void EnterSSNForMemberAgainToConfirm(int memIndex, String ssn) throws Exception{
		By ConfirmSSNTxtBox = By.id("confirmedSsn"+memIndex);				
		enterText("ConfirmSSNText"+memIndex, ConfirmSSNTxtBox, ssn);
	}
	
	
	//Below YesORNo should be in 1 or 0 from User
	public void ClickIfSameNameonSSNCardForMember(int memIndex, int YesORNo) throws Exception{
		By SmNmOnSSNRadBttnYes = By.id("members"+memIndex+".ssnSameAsSSCard"+YesORNo);				
		clickOnElement("SmNmOnSSNRadBttnYes", SmNmOnSSNRadBttnYes);
	}



	public void enterDocReceivedDate(int memIndex, String DateRcvd) throws Exception
	{
		By docRcvdDate = By.id("members"+(memIndex+1)+".latestDocRcvdDate");
		enterTextWithoutTab(docRcvdDate, DateRcvd);
	}
	
	public void clickOnVerifyBtn() throws Exception
	{
		By verifyBtn = By.xpath("//input[@id='idVerificationButton']");
		clickOnElement("verifyBtn", verifyBtn);		
	}

	public void clickWarningOkBtn() throws Exception{
		clickOnElement("WarningOkButton", warningOkButton);
	}
	
	public void clickOnBackBtn() throws Exception
	{
		By backBtn = By.xpath("//input[@value='Back']");
		clickOnElement("Backbtn", backBtn);		
	}
	
	public void clickSSNPopUpVerifySSNYesBtn() throws Exception{
		By yesPopUpBtn = By.xpath("//div[@id='openModal']/../div[3]/div/button/span[contains(text(),'Yes')]");
		clickOnElementThenWait("YesPopUpBtn", yesPopUpBtn, 10);		
	}
	
	public void takeScreenshot() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Summary");	
	}
	
	
	public void enterSSNForMember(
			int mCounter,
			String SSNTxt,
			String name
			) throws Exception{
		waitForPageLoaded();
		
		clickOnChkBoxForMembertoVerifySSN(name);
		EnterSSNForMember(mCounter, SSNTxt);
		EnterSSNForMemberAgainToConfirm(mCounter, SSNTxt);
		ClickIfSameNameonSSNCardForMember(mCounter, 1);
		enterComments("Verifying SSN RFI for - "+name);
	}
	
	
	
	
	public void verifySSNRFIAndGoBackToLandingPage(
			int mCounter,
			String SSNTxt,
			String name
			) throws Exception{
		waitForPageLoaded();
		
		clickOnChkBoxForMembertoVerifySSN(name);
		EnterSSNForMember(mCounter, SSNTxt);
		EnterSSNForMemberAgainToConfirm(mCounter, SSNTxt);
		ClickIfSameNameonSSNCardForMember(mCounter, 1);
		enterComments("Verifying SSN RFI for - "+name);
		clickOnVerifyBtn();
		clickSSNPopUpVerifySSNYesBtn();
		Thread.sleep(2000);
		waitForPageLoaded();
		takeScreenshot("SSNRFI");
		clickOnBackBtn();
	
	}
	
	public void clickOnAccountDashboardBtn() throws Exception{
        By accountDashboardBtn = By.xpath(".//*[@id='section_begin']/a[contains(text(),'Account Dashboard')]");
        clickOnElementThenWait("AccountDashboardBtn", accountDashboardBtn, 10);        
  }

}