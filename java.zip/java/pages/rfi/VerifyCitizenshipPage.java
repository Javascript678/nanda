package pages.rfi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

public class VerifyCitizenshipPage extends CommonPage implements CommonPageOR {

	private static final By citizenshipRFIPageHeader = By.xpath("//h1[contains(.,'Verify Citizenship')]");
	private static final By documentReceivedDateTxt = By.name("docRcvdDate");
	private static final By commentsTxt = By.id("comment");
	static final By warningOkButton = By.id("popup_ok");

	public VerifyCitizenshipPage(WebDriver driver, String featureName) {
		super(driver, featureName);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("CitizenshipRFIPageHeader", citizenshipRFIPageHeader);
	}

	public void enterDocumentReceivedDate(String documentReceivedDate) throws Exception {
		enterText("DocumentReceivedDateTxt", documentReceivedDateTxt, documentReceivedDate);
	}

	public void enterComments(String Comments) throws Exception {
		enterText("CommentsTxt", commentsTxt, Comments);
	}

	public void clickOnVerifyBtn() throws Exception {
		By verifyBtn = By.xpath("//input[@value='Verify']");
		clickOnElement("Verifybtn", verifyBtn);
	}

	public void clickOnBackBtn() throws Exception {
		By backBtn = By.xpath("//input[@value='Back']");
		clickOnElement("Backbtn", backBtn);
	}

	public void clickWarningOkBtn() throws Exception {
		clickOnElement("WarningOkButton", warningOkButton);
	}
	
	public void takeScreenshot() throws Exception {
		takeScreenshot("Summary");
	}

	public void verifyCitizenshipAndGoBackToLandingPage(String comments) throws Exception {
		waitForPageLoaded();
		enterComments(comments);
		clickOnVerifyBtn();
		clickWarningOkBtn();
		takeScreenshot();
		clickOnBackBtn();

	}

}
