package pages.rfi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author ppinho
 *
 */
public class ModifyWaitingPeriodPage extends CommonPage implements CommonPageOR {

	public ModifyWaitingPeriodPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private static final By modifyWaitingPeriodPageHeader = By.xpath("//h1[contains(.,'Modify Waiting Period')]");
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ModifyWaitingPeriodPageHeader", modifyWaitingPeriodPageHeader);
	}
	
	public void takeScreenshot() throws Exception{
		takeScreenshot("Summary");
	}
	
	public void clickOnContinueBtn() throws Exception{
		By continueDD = By.xpath("//button/span[contains(text(),'Continue')]");
		clickOnElement("Continue", continueDD);
	}
	
	public void usingLeftMenuClickOnAccountDashboard() throws Exception{
		By AccountDashboardDD = By.id("section_begin");
		clickOnElement("AccountDashboard", AccountDashboardDD);
	}

	public void clickOnModifyWaitingPeriod() throws Exception{
		By modifyWaitingPeriodDD = By.id("clk_EXTEND");
		clickOnElement("ModifyWaitingPeriod", modifyWaitingPeriodDD);		
	}
	
	public void selectHowManyDays(String extention)throws Exception{
		By extentionDD = By.id("clk_extend_by");
		selectDropDownElementByVisibleText("HowManyDaysExtention", extentionDD, extention);
	}
	
	public void clickOnSubmitBtn() throws Exception{
		By submitDD = By.id("modifyClock");
		clickOnElement("Submit", submitDD);		
	}
	
	public void extendWaitingperiod(String extention) throws Exception{
		clickOnModifyWaitingPeriod();
		selectHowManyDays(extention);
		clickOnSubmitBtn();
		clickOnContinueBtn();
	}

}


