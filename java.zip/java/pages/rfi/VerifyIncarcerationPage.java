package pages.rfi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

public class VerifyIncarcerationPage extends CommonPage implements CommonPageOR {

	private static final By IncarcerationRFIHeader = By
			.xpath("//div[@id='application']//h1[contains(.,'Verify Incarceration')]");
	private static final By commentsTxt = By.id("comment");

	static final By warningOkButton = By.id("popup_ok");

	public VerifyIncarcerationPage(WebDriver driver, String featureName) {
		super(driver, featureName);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("IncarcerationRFIHeader", IncarcerationRFIHeader);
	}

	public void enterComments(String Comments) throws Exception {
		enterText("CommentsTxt", commentsTxt, Comments);
	}

	public void clickOnVerifyBtn() throws Exception {
		By verifyBtn = By.xpath("//input[@id='idVerificationButton']");
		clickOnElement("verifyBtn", verifyBtn);
	}

	public void clickWarningOkBtn() throws Exception {
		clickOnElement("WarningOkButton", warningOkButton);
	}

	public void clickOnBackBtn() throws Exception {
		By backBtn = By.xpath("//input[@value='Back']");
		clickOnElement("Backbtn", backBtn);
	}

	public void enterDocReceivedDate(String DateRcvd) throws Exception {
		By docRcvdDate = By.id("docRcvdDate");
		enterTextWithoutTab(docRcvdDate, DateRcvd);
	}
	
	public void takeScreenshot() throws Exception {
		takeScreenshot("Summary");
	}

	public void verifyIncarcerationRFIAndGoBackToLandingPage(String Comments) throws Exception {
		waitForPageLoaded();
		enterComments(Comments);
		clickOnVerifyBtn();
		clickWarningOkBtn();
		takeScreenshot();
		clickOnBackBtn();

	}
}