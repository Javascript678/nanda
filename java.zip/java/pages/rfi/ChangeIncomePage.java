package pages.rfi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class ChangeIncomePage extends CommonPage implements CommonPageOR {

	public ChangeIncomePage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private static final By changeIncomePageHeader = By.xpath("//h1[contains(.,'Change Income')]");
	private static final By incomeBackButton= By.id("backButtonIncome");
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ChangeIncomePageHeader", changeIncomePageHeader);
	}

	public boolean isIncomePresent() throws Exception{
		By verifyIncomeChkBx = By.name("eligibilityMemberManualVerifiedIncomeSource[0].hasReceivedDoc");
		return isElementPresent(verifyIncomeChkBx);		
	}
	
	public void clickOnVerifyIncomeChkBx() throws Exception{
		By verifyIncomeChkBx = By.name("eligibilityMemberManualVerifiedIncomeSource[0].hasReceivedDoc");
		clickOnElement("VerifyIncomeChkBx", verifyIncomeChkBx);		
	}
	
	public void clickOnNoIncomeChkBx() throws Exception{
		By noIncomeChkBx = By.id("noIncome");
		clickOnElement("NoIncomeChkBx", noIncomeChkBx);		
	}
	
	public void clickOnSaveAndVerifyBtn() throws Exception{
		By saveAndVerifyBtn = By.id("saveVerifyIncomeButton");
		clickOnElementThenWait("SaveAndVerifyBtn", saveAndVerifyBtn, 10);		
	}
	
	public void clickOnSaveBtn() throws Exception{
		By saveBtn = By.id("saveIncomeDraftButton");
		clickOnElement("SaveBtn", saveBtn);		
	}
	
	public void clickWarningOkBtn() throws Exception{
		clickOnElement("WarningOkButton", warningOkButton);
	}
	
	public void clickOnBackBtn() throws Exception{
		clickOnElementAfterWait("BackButton", incomeBackButton,10);		
	}
	
	public void takeScreenshot() throws Exception{
		takeScreenshot("Summary");		
	}

	public void verifyIncomeAndGoBackToLandingPage() throws Exception{
		waitForPageLoaded();
		boolean isIncPresent = isIncomePresent();
		if(isIncPresent){
			clickOnVerifyIncomeChkBx();
		}else{
			clickOnNoIncomeChkBx();
		}
		
		takeScreenshot();
		clickOnSaveAndVerifyBtn();
		clickWarningOkBtn();
		
		clickOnBackBtn();
		
	}
	
	public void enterIncome(int memno, String income) throws Exception{
		By incomeTxt = By.name("eligibilityMemberManualVerifiedIncomeSource["+memno+"].amount");
		clearAndType("Mem" + (memno)+"Income",incomeTxt, income); 

	}
	
	public void updateAndVerifyIncomeAndGoBackToLandingPage(int memno, String updatedIncome) throws Exception{
		waitForPageLoaded();
		boolean isIncPresent = isIncomePresent();
		if(isIncPresent){
		enterIncome( memno,updatedIncome);
		clickOnVerifyIncomeChkBx();
		}

		takeScreenshot();
		clickOnSaveAndVerifyBtn();
		clickWarningOkBtn();

		clickOnBackBtn();

	}
	
	public void verifyIncomeOfMemeber1(boolean trueFalseValuememOneIncome )throws Exception{
		waitForPageLoaded();
		
		if(trueFalseValuememOneIncome){
		clickOnVerifyIncomeChkBx();
		takeScreenshot();
		clickOnSaveAndVerifyBtn();
		clickWarningOkBtn();
		}else{
		
			clickOnNoIncomeChkBx();
			takeScreenshot();
			clickOnSaveAndVerifyBtn();
			clickWarningOkBtn();
		}
	}
	
	public void verifyIncomeOfMemeber2(boolean trueFalseValuememTwoIncome) throws Exception{
		waitForPageLoaded();

		if (trueFalseValuememTwoIncome) {
			clickOnVerifyIncomeChkBx();
			takeScreenshot();
			clickOnSaveAndVerifyBtn();
			clickWarningOkBtn();
			takeScreenshot();
			clickOnBackBtn();
		}else{
			clickOnNoIncomeChkBx();
			takeScreenshot();
			clickOnSaveAndVerifyBtn();
			clickWarningOkBtn();
			takeScreenshot();
			clickOnBackBtn();
		}
}
	

}


