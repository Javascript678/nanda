package pages.rfi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

public class VerifyAIANPage extends CommonPage implements CommonPageOR {

	private static final By AIANRFIHeader = By
			.xpath("//div[@id='application']//h1[contains(.,'Verify American Indian/Alaska Native')]");
	private static final By commentsTxt = By.id("comment");

	static final By warningOkButton = By.id("popup_ok");

	public VerifyAIANPage(WebDriver driver, String featureName) {
		super(driver, featureName);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("AIANRFIHeader", AIANRFIHeader);
	}

	public void enterComments(String Comments) throws Exception {
		enterText("CommentsTxt", commentsTxt, Comments);
	}

	public void clickOnVerifyBtn() throws Exception {
		By verifyBtn = By.xpath("//input[@id='idVerificationButton']");
		clickOnElement("verifyBtn", verifyBtn);
	}

	public void clickWarningOkBtn() throws Exception {
		clickOnElement("WarningOkButton", warningOkButton);
	}

	public void clickOnBackBtn() throws Exception {
		By backBtn = By.xpath("//input[@value='Back']");
		clickOnElement("Backbtn", backBtn);
	}
	
	public void takeScreenshot() throws Exception {
		takeScreenshot("AIANRFI");
	}

	public void verifyAIANRFIAndGoBackToLandingPage(String Comments) throws Exception {
		waitForPageLoaded();
		enterComments(Comments);
		clickOnVerifyBtn();
		clickWarningOkBtn();
		takeScreenshot();
		clickOnBackBtn();
	}
}