package pages.rfi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;
import utils.DateUtil;
import utils.RandomGenerator;

/**
 * 
 * @author Ritika Gupta
 *
 */
public class NCPVerificationPage extends CommonPage implements CommonPageOR {

	public NCPVerificationPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private static final By NCPRFIHeader = By.xpath("//h1[contains(.,'Non-Custodial Parent Verification')]");
	By ncpSSNTxt = By.id("ncpSSN");
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("NCPRFIHeader", NCPRFIHeader);
	}
	
	public void takeScreenshot() throws Exception{
		takeScreenshot("Summary");
	}
	
	public boolean isWarningDialogPresent() throws Exception{
		return isElementPresent(warningOkButton);
	}
	
	public void clickOnWarningOkButton() throws Exception{
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}
	
	public void handleWarningDialogIfPresent() throws Exception{
		if(isWarningDialogPresent()){
			clickOnWarningOkButton();
		}
	}
	
	public void usingLeftMenuClickOnAccountDashboard() throws Exception{
		By accountDashboard = By.xpath("//*[@id='subNav']/ol/li/a");
		clickOnElement("AccountDashboard", accountDashboard);
	}

	public void clickOnAddBtn(String name) throws Exception{
		By addLink = By.xpath("//table[@id='customerTable']/tbody/tr[th[contains(text(),'" + name + "')]]//a");
		clickOnElement("AddBtn", addLink);		
	}
	
	public void clickOnViewEditBtn() throws Exception{
		By viewEditLink = By.xpath("//a[contains(.,'View/Edit')]");
		clickOnElement("ViewEditBtn", viewEditLink);		
	}
	
	public void clickOnVerifyBtn(String name) throws Exception{
		By verifyLink = By.xpath("//table[@id='customerTable']/tbody/tr[th[contains(text(),'" + name + "')]]/td[4]/a");
		clickOnElement("VerifyBtn", verifyLink);		
	}

	public void selectApplyToChild(int cutodialChildIndex, String applyToChild)throws Exception{
		By applyToChildDD= By.name("custodials[" + cutodialChildIndex + "].goodCauseInfo");
		selectDropDownElementByVisibleText("ApplyToChildDD", applyToChildDD, applyToChild);
	}

	// updated by ppinho
	public void enterSSN(String ssn)throws Exception{
		clearAndType("NCPSSNTxt", ncpSSNTxt, ssn);
	}
	
	public String getSSN()throws Exception{
		return getElementText("NCPSSNTxt", ncpSSNTxt);
	}
	
	public void validateSSNIsMasked(int custodialChildIndex)throws Exception{
		String ssn = getSSN();
		System.out.println(ssn);
		By ncpSSNTxt = By.name("custodials[" + custodialChildIndex + "].ncpSSN");
		validateElementAttribute("NCPSSNTxt", ncpSSNTxt, "type", "hidden");
	}
	
	public void enterFirstName(int childNo)throws Exception{
		By firstNameTxt = By.name("custodials[" + childNo + "].ncpContactInfo.firstName");
		String firstName = RandomGenerator.getRunTimeName("","");
		enterText("FirstName", firstNameTxt, firstName);
	}
	
	public void enterLastName(int childNo)throws Exception{
		By lastNameTxt = By.name("custodials[" + childNo + "].ncpContactInfo.lastName");
		String lastName = RandomGenerator.getRunTimeName("","");
		enterText("LastName", lastNameTxt, lastName);
	}
	
	public void selectRelationshipToChild(int childNo) throws Exception{
		By relationshipToChildRdBtn = By.name("custodials[" + childNo + "].ncpRelationshipToChild");
		selectByValueUsingJS("relationshipToChild", relationshipToChildRdBtn, "Father");
	}
	
	public void selectGender(int childNo) throws Exception{
		By genderRdBtn = By.name("custodials[" + childNo + "].ncpGender");
		selectByValueUsingJS("gender", genderRdBtn, "M");
	}
	
	public void enterDOB(int childNo, String dob)throws Exception{
		By dobTxt = By.name("custodials[" + childNo + "].ncpDob");
		clearAndTypeAfterWait("DOB", dobTxt, dob);
	}
	
	public void enterDriversLicense(int childNo)throws Exception{
		By driversLicenseTxt = By.name("custodials[" + childNo + "].ncpDLNumber");
		String driversLicense = RandomGenerator.getRunTimeName("","");
		enterText("driversLicense", driversLicenseTxt, driversLicense);
	}
	
	public void enterParentAddress(int childNo)throws Exception{
		By parentAddresseTxt = By.name("custodials[" + childNo + "].ncpContactInfo.primaryAddress.streetAddress1");
		enterText("ParentAddress", parentAddresseTxt, "1 E MAIN ST");
	}
	
	public void enterParentCity(int childNo)throws Exception{
		By parentCityeTxt = By.name("custodials[" + childNo + "].ncpContactInfo.primaryAddress.city");
		enterText("ParentCity", parentCityeTxt, "BOSTON");
	}
	
	public void enterParentZip(int childNo)throws Exception{
		By parentZipeTxt = By.name("custodials[" + childNo + "].ncpContactInfo.primaryAddress.zip");
		clearAndType("ParentCity", parentZipeTxt, "02112");
	}
	
	// added by ppinho
	public void invlidSsnErrorMessage() throws Exception{
		By invalidSsnErrorMsg = By.xpath("//div[@id='errorMsg']//a[contains(text(),'Enter a valid Social Security Number')]");
		waitForPresenceOfElementLocated("InvalidSSNErrorMsg", invalidSsnErrorMsg);
	}

	public void selectCounty(int childNo) throws Exception{
		By countyTxt = By.name("custodials[" + childNo + "].ncpContactInfo.primaryAddress.county");
		selectByVisibleTextAfterWait("CountyDD", countyTxt, "SUFFOLK");
	}
	
	public void enterEmployerName(int childNo)throws Exception{
		By employerNameTxt = By.name("custodials[" + childNo + "].ncpEmpContactInfo.firstName");
		enterText("employerName", employerNameTxt, "ABC INC");
	}
	
	public void enterEmployerAddress(int childNo)throws Exception{
		By employerAddressTxt = By.name("custodials[" + childNo + "].ncpEmpContactInfo.primaryAddress.streetAddress1");
		enterText("EmployerAddress", employerAddressTxt, "2 W MAIN ST");
	}
	
	public void enterEmployerCity(int childNo)throws Exception{
		By employerCityeTxt = By.name("custodials[" + childNo + "].ncpEmpContactInfo.primaryAddress.city");
		enterText("EmployerCity", employerCityeTxt, "BOSTON");
	}
	
	public void enterEmployerZip(int childNo)throws Exception{
		By employerZipTxt = By.name("custodials[" + childNo + "].ncpEmpContactInfo.primaryAddress.zip");
		clearAndType("EmployerCity", employerZipTxt, "02112");
	}
	
	public void selectEmployerCounty(int childNo) throws Exception{
		By employerCountyDD = By.name("custodials[" + childNo + "].ncpEmpContactInfo.primaryAddress.county");
		selectByVisibleTextAfterWait("EmployerCounty", employerCountyDD, "SUFFOLK");
	}
	
	public void enterAgentFirstName(int childNo)throws Exception{
		By agentFirstNameTxt = By.id("custodials"+childNo+".ncpSignFirstName");
		String agentFirstName = RandomGenerator.getRunTimeName("","");
		enterText("AgentFirstName", agentFirstNameTxt, agentFirstName);
	}
	
	public void enterAgentLastName(int childNo)throws Exception{
		By agentLastNameTxt = By.id("custodials" + childNo + ".ncpSignLastName");
		String agentLastName = RandomGenerator.getRunTimeName("","");
		enterText("LastName", agentLastNameTxt, agentLastName);
	}
	
	public void signatureDate(int childNo, String appDate)throws Exception{	
		By signDateTxt = By.id("custodials" + childNo + ".ncpSignDate");
		String date = DateUtil.getDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern);
		clearAndTypeAfterWait("SignDate", signDateTxt, date);
	}
	
	public void clickSignDocBtn(int childNo) throws Exception{
		By verifyBtn = By.name("custodials[" + childNo + "].ncpFormSigned");
		selectByValueUsingJS("VerifyBtn", verifyBtn, true+"");
	}

	public void clickOnSaveBtn() throws Exception{
		By saveBtn = By.id("saveAction");
		clickOnElement("SaveBtn", saveBtn);		
	}
	
	public void clickOnEditBtn() throws Exception{
		By editBtn = By.id("editNCP");
		clickOnElement("EditBtn", editBtn);		
	}
	
	// updated by ppinho
	public void completeParentVerification(int childIndex, String appDate) throws Exception{
		enterFirstName(childIndex);
		enterLastName(childIndex);
		selectRelationshipToChild(childIndex);
		selectGender(childIndex);
		enterDOB(childIndex, DateUtil.getPriorDateInUIFormatUsingPattern(appDate, DateUtil.UIDatePattern, "30"));
		enterSSN(RandomGenerator.getRunTimeSSNNumber());
		enterDriversLicense(childIndex);
		enterParentAddress(childIndex);
		enterParentCity(childIndex);
		enterParentZip(childIndex);
		selectCounty(childIndex);
		enterEmployerName(childIndex);
		enterEmployerAddress(childIndex);
		enterEmployerCity(childIndex);
		enterEmployerZip(childIndex);
		selectEmployerCounty(childIndex);
		
	}

	public void verifyDocument(int childIndex, String appDate) throws Exception{
		clickSignDocBtn(childIndex);
		enterAgentFirstName(childIndex);
		enterAgentLastName(childIndex);
		signatureDate(childIndex, appDate);
	}

	public void takeScreenShot()throws Exception{
		Thread.sleep(1000);
		takeScreenshot("NCP_RFI_Page");
	}
	
	public void verifyAddBtnIsPresentToAddParents(String name) throws Exception{
		By addBtn = By.xpath("//table[@id='customerTable']/tbody/tr[th[contains(text(),'" + name + "')]]//a");
		isElementPresent(addBtn); 
	}
	
	

}


