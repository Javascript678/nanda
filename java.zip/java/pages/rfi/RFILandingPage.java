package pages.rfi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import enums.BrowserName;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class RFILandingPage extends CommonPage implements CommonPageOR {

	public RFILandingPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private static final By rfiPageHeader = By.xpath("//h2[contains(.,'Requests for Information')]");
	private final By leftMenuSlider = By.id("dashboardLeftmenuSlider");
	private final By viewUnlockEligibilityBtn = By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'View / Unlock Eligibility')]");

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("RFIPageHeader", rfiPageHeader);
	}

	public void clickOnLeftMenuSlider() throws Exception {
		clickOnElement("LeftMenuSlider", leftMenuSlider);
	}

	public void clickOnViewUnlockEligibilityBtn() throws Exception {
		clickOnElement("ViewUnlockEligibilityBtn", viewUnlockEligibilityBtn);
	}

	public void clickOnReRunEligibility() throws Exception {
		By reRunElgBtn = By.id("reRunEligibility");
		clickOnElementThenWait("reRunEligibilityBtn", reRunElgBtn, 10);
	}

	public void clickOnConfirmPopup() throws Exception {
		By popupConfirmBtn = By.xpath("//div[contains(@style,'block')]//button/span[text()='Confirm']");
		clickOnElementThenWait("ReRunElgConfirmBtn", popupConfirmBtn, 20);
	}

	public void clickOnCancelPopup() throws Exception {
		clickOnElement("ReRunElgCancelBtn", popupCancelBtn);
	}

	public boolean isMemberActiveRFIPresent(String name, String rfiTypeOnUI) {
		By memberRow = By.xpath("//div[@id='activeRFIsContainer']//tr[th[span[text()='" + name + "']] and td[contains(text(),'" + rfiTypeOnUI + "')]]");
		return isElementPresent(memberRow);
	}

	public void clickOnActiveRFIButtonForMember(String browserToUse, String name, String rfiTypeOnUI, int memindex)
			throws Exception {
		By rfiButton = By.xpath("//div[@id='activeRFIsContainer']//tr[th[span[text()='" + name + "']] and td[contains(text(),'" + rfiTypeOnUI + "')]]//button[contains(@id,'threeDotsMenu')]");
		if (browserToUse.equalsIgnoreCase(BrowserName.SAUCE_LAB_FF.val)) {
			clickOnElementThenWait("RFIButton", rfiButton, 5);
		} else {
			clickOnElement("RFIButton", rfiButton);
			// clickOnElementThenWait("RFIButton", rfiButton,5);
		}
	}

	public void clickOnVerifyActiveRFIButtonForMember(String name, String rfiTypeOnUI) throws Exception {
		By verifyActivateRfiButton = By.xpath("//div[@id='activeRFIsContainer']//span[contains(text(),'" + name + "')]/../../..//td[contains(text(),'" + rfiTypeOnUI + "')]/..//a[contains(text(),'Verify RFI')]");
		clickOnElement("VerifyActiveRFIButton", verifyActivateRfiButton);
	}

	public void clickOnManageClockForActiveRFIButtonForMember(String name, String rfiTypeOnUI) throws Exception {
		By rfiButton = By.xpath("//div[@id='activeRFIsContainer']//tr[th[span[text()='" + name + "']] and td[contains(text(),'" + rfiTypeOnUI + "')]]//ul/li/a[contains(.,'Manage Clock')]");
		clickOnElement("RFIButton", rfiButton);
	}

}
