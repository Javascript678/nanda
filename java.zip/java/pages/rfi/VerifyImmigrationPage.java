package pages.rfi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Ritika Gupta
 *
 */
public class VerifyImmigrationPage extends CommonPage implements CommonPageOR {

	public VerifyImmigrationPage(WebDriver driver, String featureName) {
		super(driver, featureName);
	}

	private static final By IMGRFIHeader = By.xpath("//h1[contains(text()[normalize-space()],'Verify Immigration')]");

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("IMGRFIHeaderr", IMGRFIHeader);
	}

	public void entercomments(String sampleText) throws Exception {
		By commentTxt = By.name("comment");
		enterText("Comments Text Field", commentTxt, sampleText);
	}

	public void saveCommentsLink() throws Exception {
		By saveCommentsVerifyBttn = By.id("saveCommentButton");
		clickOnElement("save Comments field", saveCommentsVerifyBttn);
	}

	public void clickNoInPopUpMsgbox() throws Exception {
		By clickNoInPopupMsg = By.id("popup_cancel");
		clickOnElement("pop up", clickNoInPopupMsg);
	}

	public void clickOnVerifyBtn() throws Exception {
		By verifyBtn = By.xpath("//input[@value='Verify']");
		clickOnElement("Verifybtn", verifyBtn);
	}

	public void clickOnBackBtn() throws Exception {
		By backBtn = By.xpath("//input[@value='Back']");
		clickOnElement("Backbtn", backBtn);
	}

	public void clickWarningOkBtn() throws Exception {
		clickOnElement("WarningOkButton", warningOkButton);
	}

	public void takeScreenshot() throws Exception {
		waitForPageLoaded();
		takeScreenshot("Summary");
	}

	// Amrita
	public void verifyImmigrationAndGoBackToLandingPage(String Comments) throws Exception {
		waitForPageLoaded();
		entercomments(Comments);

		takeScreenshot();

		clickOnVerifyBtn();
		clickWarningOkBtn();
	}

}
