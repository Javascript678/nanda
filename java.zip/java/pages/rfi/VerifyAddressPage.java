package pages.rfi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

public class VerifyAddressPage extends CommonPage implements CommonPageOR {

	private static final By AddressRFIHeader = By.xpath("//div[@id='application']//h1[contains(.,'Verify Address')]");
	private static final By commentsTxt = By.id("comment");

	static final By warningOkButton = By.id("popup_ok");

	public VerifyAddressPage(WebDriver driver, String featureName) {
		super(driver, featureName);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("AddressRFIHeader", AddressRFIHeader);
	}

	public void enterComments(String Comments) throws Exception {
		enterText("CommentsTxt", commentsTxt, Comments);
	}

	public void clickOnVerifyBtn() throws Exception {
		By verifyBtn = By.xpath("//input[@id='idVerificationButton']");
		clickOnElement("verifyBtn", verifyBtn);
	}

	public void clickWarningOkBtn() throws Exception {
		clickOnElement("WarningOkButton", warningOkButton);
	}

	public void clickOnBackBtn() throws Exception {
		By backBtn = By.xpath("//input[@value='Back']");
		clickOnElement("Backbtn", backBtn);
	}

	public void takeScreenshot() throws Exception {
		waitForPageLoaded();
		takeScreenshot("Summary");
	}

	public void verifyAddressRFIAndGoBackToLandingPage(String Comments) throws Exception {
		waitForPageLoaded();
		enterComments(Comments);
		takeScreenshot();
		clickOnVerifyBtn();
		clickWarningOkBtn();
	}
}