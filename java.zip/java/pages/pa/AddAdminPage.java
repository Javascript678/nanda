package pages.pa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class AddAdminPage extends CommonPage implements CommonPageOR {

	private static final By premAsst_AddAdminPageHeader = By.xpath("//h1[contains(text(),'Premium Assistance - Add Administrator')]");
	
	
	public AddAdminPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("PA_AddAdminPageHeader", premAsst_AddAdminPageHeader);
	}
	
	private void selectMemberName(String memberName)throws Exception{
		By paMemberDD= By.id("mem_name");
		selectDropDownElementByVisibleText("paMemberDD",paMemberDD,memberName);
	}

	private void enterAdminName(String adminName)throws Exception{
		By adminNameTxt = By.id("adminName");
		enterText("AdminNameTxt" , adminNameTxt,adminName);
	}
	
	private void enterStreetName(String streetName)throws Exception{
		By streetNameTxt = By.id("address.streetAddress1");
		enterText("StreetNameTxt" , streetNameTxt,streetName);
	}
	
	private void enterAptUnitNumber(String aptUnitNo)throws Exception{
		By aptUnitNoTxt = By.id("address.streetAddress2");
		enterText("AptUnitNoTxt" , aptUnitNoTxt,aptUnitNo);
	}
	
	private void enterCityName(String cityName)throws Exception{
		By cityNameTxt = By.id("address.city");
		enterText("CityNameTxt" , cityNameTxt,cityName);
	}
	
	private void enterZipCode(String zip)throws Exception{
		By zipTxt = By.id("address.zip");
		clearAndType("ZipTxt" , zipTxt,zip);
	}
	
	private void selectCounty(String county)throws Exception{
		By countyDD = By.id("address.county");
		selectByVisibleTextAfterWait("CountyDD" , countyDD,county);
	}
	
	private void enterContactName(String contactName)throws Exception{
		By contactNameTxt = By.id("contactInfo.firstName");
		enterText("ContactNameTxt" , contactNameTxt,contactName);
	}
	
	private void enterPhoneNumber(String phoneNumber)throws Exception{
		By phoneNumberTxt = By.id("contactInfo.primaryPhoneNumber");
		clearAndType("PhoneNumberTxt" , phoneNumberTxt,phoneNumber);
	}
	
	private void enterEffectiveDate(String effDate)throws Exception{
		By effectiveDateTxt = By.id("effectiveStartDate");
		clearAndType("EffectiveDateTxt" , effectiveDateTxt,effDate);
	}
	
	private void clickOnCancelBtn() throws Exception{
		clickOnElement("CancelBtn", cancelBtn);		
	}
	
	private void clickOnSaveBtn() throws Exception{
		clickOnElement("SaveBtn", saveBtn);		
	}
	
	public void enterAdminDetails(String memberName, String adminName, String streetName, String aptUnitNo, String cityName, String zip, String county, String contactName, String phoneNumber, String effDate) throws Exception{
		waitForPageLoaded();
		selectMemberName(memberName);
		enterAdminName(adminName);
		enterStreetName(streetName);
		enterAptUnitNumber(aptUnitNo);
		enterCityName(cityName);
		enterZipCode(zip);
		selectCounty(county);
		enterContactName(contactName);
		enterPhoneNumber(phoneNumber);
		enterEffectiveDate(effDate);
		clickOnSaveBtn();
		
	}
	
	
}
