package pages.pa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Ritika Gupta
 *
 */
public class AddEmployerPage extends CommonPage implements CommonPageOR{

	//UpdateIncomeDialog updateIncomeDialog = new UpdateIncomeDialog();
	
	private static final By addEmployerPageHeader = By.xpath("//h1[contains(.,'Premium Assistance - Add Employer')]");
	
	private static final By employerNameDD = By.name("employerName");
	private static final By streetAddressTxt = By.name("address.streetAddress1");
	private static final By addressCityTxt = By.name("address.city");
	private static final By addressZipTxt = By.name("address.zip");
	private static final By addressCountyDD = By.name("address.county");
	private static final By offerHealthInsuranceRdBtn = By.name("employerOfferHealthInsurance");
	private static final By changePastTaxCreditInfoRdBtn = By.name("ftrOverride");
	
	private static final By reportChangeBtn = By.id("submitButton");
	
	
	public AddEmployerPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("AddEmployerPageHeader", addEmployerPageHeader, 3);
	}

	public void selectEmployeeDropDown(String employeeName)throws Exception{
		By employeeDD =By.xpath("//select[@id='mem_name']/option[contains(.,'"+employeeName+"')]"); //updated xpath 
        enterText("EmployeeName", employeeDD,employeeName);
	}
	
	private void selectEmployerNameDropDown(String employerName)throws Exception{
		enterText("EmployerName", employerNameDD,employerName);
	}
	
	private void enterStreetAddressTxt(String streetAddress) throws Exception{
		enterText("StreetAddress", streetAddressTxt,streetAddress);
	}
	
	private void enterCityTxt(String cityAddress) throws Exception{
		enterText("City", addressCityTxt,cityAddress);
	}
	
	private void enterZipTxt(String zipAddress) throws Exception{
		enterText("Zip", addressZipTxt,zipAddress);
	}
	
	private void selectCountyDropDown(String countAddress)throws Exception{
		enterText("County", addressCountyDD,countAddress);
	}
	
	
	private void selectHealhInsuranceOfferedRdBtn(Boolean trueFalseValue) throws Exception{
		if(trueFalseValue==null) return;
		
		selectByValue("HealthInsuranceOffered", offerHealthInsuranceRdBtn, trueFalseValue+"");
	}
	
	
	public void selectAccessStatusForMember(int memIndex, String accessStatus) throws Exception{
		//if(accessStatus==null) return;
		By memAccessStatusDD =By.id("paESIMemberStatusList["+memIndex+"].esiAccessStatus");
		selectDropDownElementByVisibleText("AccessStatus", memAccessStatusDD, accessStatus);
	}

	public void clickOnSaveButton() throws Exception{
		clickOnElementThenWait("SaveButton", saveBtn, 5);
	}
	
	public void clickOnCancelButton() throws Exception{
		clickOnElementThenWait("CancelButton", cancelBtn, 5);
	}

	public void clickOnAlertOkButton() throws Exception{
		clickOnElementThenWait("AlertOkButton", alertOkButton, 5);
	}
	
	public void clickOnAlertCancelButton() throws Exception{
		clickOnElementThenWait("AlertCancelButton", alertCancelButton, 5);
	}

	public void addEmpDetails(String employeeName, String employerName, boolean trueFalseValue) throws Exception
	{
		waitForPageLoaded();
		selectEmployeeDropDown(employeeName);
		selectEmployerNameDropDown(employerName);
		selectHealhInsuranceOfferedRdBtn(trueFalseValue);
	}
}
