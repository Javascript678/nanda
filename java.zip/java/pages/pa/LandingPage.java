package pages.pa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.pa.PA_Data;
import pages.common.CommonPage;

/**
 * 
 * @author Vinay Kumar
 *
 */

public class LandingPage extends CommonPage {

	private static final By premiumAssisstanceDashboardPageHeader = By.xpath("//h1[contains(.,'Premium Assistance')]");
	private final By employerCoverageAccessTab = By.xpath("//button[@id='label_expand_1']");
	private final By otherHlthInsTab = By.xpath("//button[@id='label_expand_2']");
	private final By healthInsCovrgInfoTab = By.xpath("//button[@id='label_expand_3']");

	private final By addEmployer = By.id("addEmployer");
	private final By addAdministrator	= By.xpath("//input[@value='Add Administrator']");
	private final By addNewPolicyInfo	= By.xpath("//input[@value='Add New Policy Information']");

	public LandingPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("PremiumAssisstanceDashboardPageHeader", premiumAssisstanceDashboardPageHeader);
	}

	public void clickOnPremiumAssistanceSelectedTab() throws Exception { 
		By premiumAssistanceTab = By.id("premiumAssistance");
		clickOnElement("PremiumAssistanceSelectedTab", premiumAssistanceTab);
	}

	//Paul 
	public void clickOnViewApplicationSummarySelectedTab() throws Exception { 
		By ViewApplicationSummaryTab = By.id("myEligiblity");
		clickOnElement("ViewApplicationSummaryTab", ViewApplicationSummaryTab);
	}
	
	public void clickOnViewAppSummaryTab() throws Exception { 
		By viewAppSummarryTab = By.id("myEligiblity");
		clickOnElement("ViewAppSummarryTab", viewAppSummarryTab);
	}

	public void clickOnViewMedicaidHHTab() throws Exception { 
		By viewMedicaidHHTab = By.id("houseHoldResult");
		clickOnElement("ViewMedicaidHHTab", viewMedicaidHHTab);
	}

	public void clickOnViewMedicaidNoticesTab() throws Exception { 
		By viewMedicaidNoticesTab = By.id("notices");
		clickOnElement("ViewMedicaidNoticesTab", viewMedicaidNoticesTab);
	}

	public void clickOnEmployerCoverageAccessTab() throws Exception{
		clickOnElement("EmplyrCovrgAccessTab", employerCoverageAccessTab);
	}

	public void clickOnOtherHlthInsTab() throws Exception{
		clickOnElement("OtherHlthInsTab", otherHlthInsTab);
	}

	public void clickOnHealthInsCovrgInfoTab() throws Exception{
		clickOnElement("HealthInsCovrgInfoTab", healthInsCovrgInfoTab);
	}

	public void clickOnAddEmployer() throws Exception{
		clickOnElement("AddEmployer",addEmployer);
	}

	public void clickOnAddAdministrator() throws Exception{
		clickOnElement("AddAdministrator",addAdministrator);
	}

	public void clickOnAddNewPolicyInfo() throws Exception{
		clickOnElement("AddNewPolicyInfo",addNewPolicyInfo);
	}

	public void clickOnViewEditPolicy(String policyHolderName) throws Exception{
		By paViewEditLink = By.xpath("//div[@id='expand_3']//tr[th[contains(.,'"+policyHolderName+"')]]/td[8]/a");
		clickOnElement("View/Edit linktext",paViewEditLink);
}

	public void validateDOBForMember(String name, String dob) throws Exception{
		if(dob==null) return;
		By dobLabelForMember = By.xpath("//caption[contains(.,'Premium Assistance Investigation Referral Criteria')]/parent::table//tr[th[contains(.,'"+name+"')]]/td[1]");
		validateTextContains("MemDOB", dobLabelForMember, dob);		
	}

	public void validateCoverageForMember(String name, String coverage) throws Exception{
		if(coverage==null) return;
		By coverageForMember = By.xpath("//caption[contains(.,'Premium Assistance Investigation Referral Criteria')]/parent::table//tr[th[contains(.,'"+name+"')]]/td[2]");
		validateTextContains("MemCoverage", coverageForMember, coverage);		
	}

	public void validateAidCategoryForMember(String name, String aidCat) throws Exception{
		if(aidCat==null) return;
		By aidCategoryLabelForMember = By.xpath("//caption[contains(.,'Premium Assistance Investigation Referral Criteria')]/parent::table//tr[th[contains(.,'"+name+"')]]/td[3]");
		validateTextContains("MemAidCategory", aidCategoryLabelForMember, aidCat);		
	}

	public void validateStatusForMember(String name, String status) throws Exception{
		if(status==null) return;
		By statusLabelForMember = By.xpath("//caption[contains(.,'Premium Assistance Investigation Referral Criteria')]/parent::table//tr[th[contains(.,'"+name+"')]]/td[4]");
		validateTextContains("MemStatus", statusLabelForMember, status);		
	}

	public void validateAdminClosureReasonForMember(String name, String adminClosureReason) throws Exception{
		if(adminClosureReason==null) return;
		By adminClosureReasonForMember = By.xpath("//caption[contains(.,'Premium Assistance Investigation Referral Criteria')]/parent::table//tr[th[contains(.,'"+name+"')]]/td[5]");
		validateTextContains("MemStatus", adminClosureReasonForMember, adminClosureReason);		
	}

	public void validateFPLForMember(String name, String fpl) throws Exception{
		if(fpl==null) return;
		By fplLabelForMember = By.xpath("//caption[contains(.,'Premium Assistance Investigation Referral Criteria')]/parent::table//tr[th[contains(.,'"+name+"')]]/td[6]");
		validateTextContains("MemStatus", fplLabelForMember, fpl);		
	}

	public void validateEmployerCoverageAccess_EmployerNameForMember(String name, String employerName) throws Exception{
		By employerNameLabel = By.xpath("//div[@id='expand_1']//tr[th[contains(text(),'"+name+"')]]/td[1]");
		validateTextContains("MemEmployerNameLabel", employerNameLabel, employerName);		
	}

	public void validateEmployerCoverageAccess_OfferCoverageForMember(String name, Boolean offerCoverg) throws Exception{
		By offerCoverageLabel = By.xpath("//div[@id='expand_1']//tr[th[contains(text(),'"+name+"')]]/td[2]");
		validateTextContains("MemOfferCoverageLabel", offerCoverageLabel, offerCoverg+"");		
	}

	public void validateEmployerCoverageAccess_PBFGMemberForMember(String name, String pbfgMember) throws Exception{
		By pbfgMemberLabel = By.xpath("//div[@id='expand_1']//tr[th[contains(text(),'"+name+"')]]/td[3]");
		validateTextContains("MemOfferCoverageLabel", pbfgMemberLabel, pbfgMember);		
	}

	public void validateEmployerCoverageAccess_StatusForMember(String name, String coverageStatus) throws Exception{
		By accessStatusLabel = By.xpath("//div[@id='expand_1']//tr[th[contains(text(),'"+name+"')]]/td[4]");
		validateTextContains("MemAccessStatusLabel", accessStatusLabel, coverageStatus);		
	}

	public void validatePolicyNumberUnderHealthCvrgInfoTable(String policyHolderName, String policyNumber) throws Exception{
		By policyNumberLabel = By.xpath("//div[@id='expand_3']//tr[th[contains(.,'"+policyHolderName+"')]]/td[3]");
		validateTextContains("PolicyNumber_For_"+policyHolderName, policyNumberLabel, policyNumber);		
	}

	public void validateInsuranceStatusForPolicyUnderHealthCvrgInfoTable(String policyHolderName, String insuranceStatus) throws Exception{
		By paInsuranceStatus = By.xpath("//div[@id='expand_3']//tr[th[contains(.,'"+policyHolderName+"')]]/td[6]");
		validateTextContains("Insurance_Status_For_"+policyHolderName, paInsuranceStatus, insuranceStatus);		
	}

	public void validatePaymentStatusForMember_Under_PremiumAssistanceSummary(String policyHolderName, String paymentStatus) throws Exception{
		By paymentStatusLabel = By.xpath("//table[caption[contains(.,'Premium Assistance Summary')]]//tr[th[contains(.,'"+policyHolderName+"')]]/td[4]");
		validateTextEquals("Mem"+(policyHolderName)+"PaymentStatus", paymentStatusLabel, paymentStatus);		
	}

	public void validatePAamountForMember_Under_PremiumAssistanceSummary(String policyHolderName, String paAmount) throws Exception{
		By paAmountLabel = By.xpath("//table[caption[contains(.,'Premium Assistance Summary')]]//th/span[contains(text(), '" + policyHolderName + "')]/../../td/span[@name='assistAmountTD']"); //updated xpath tr[3] by Brajesh
		validateTextEquals("Mem"+(policyHolderName)+"PAamount", paAmountLabel, paAmount);		
	}

	public void validateNextPayDateForMember(String policyHolderName, String paNxtPayDate) throws Exception{
		By paNextPayDate = By.xpath("//table[caption[contains(.,'Premium Assistance Summary')]]//tr[th[contains(.,'"+policyHolderName+"')]]/td[5]");
		validateTextEquals("Next Pay date for Policy Holder Member"+(policyHolderName), paNextPayDate, paNxtPayDate);		
	}
	public void takeScreenshot() throws Exception{
		waitForPageLoaded();
		takeScreenshot("PA Dashboard");
	}

	public void validatePremiumAssistanceInvestigationReferalCriteria(
			String name, 
			String aidCat,
			String status,
			String adminClosureReason,
			String fpl) throws Exception{

		validateAidCategoryForMember(name, aidCat);
		validateStatusForMember(name, status);
		validateAdminClosureReasonForMember(name, adminClosureReason);
		validateFPLForMember(name, fpl);
	}

	public void validateEmployerCoverageAccess(
			String name,
			String employerName,
			Boolean offerCoverg,
			String pbfgMember,
			String coverageStatus) throws Exception{
		validateEmployerCoverageAccess_EmployerNameForMember(name, employerName);
		validateEmployerCoverageAccess_OfferCoverageForMember(name, offerCoverg);
		validateEmployerCoverageAccess_PBFGMemberForMember(name, pbfgMember);
		validateEmployerCoverageAccess_StatusForMember(name, coverageStatus);
	}

	public void validateEmployerCoverageAccess_Status(
			String name,
			String coverageStatus) throws Exception{
		waitForPageLoaded();
		takeScreenshot("AfterEmployerStatus");
		validateEmployerCoverageAccess_StatusForMember(name, coverageStatus);
	}

	public void goToAddEmployerScreen() throws Exception{
		waitForPageLoaded();
		//clickOnEmployerCoverageAccessTab();
		clickOnAddEmployer();
	}

	public void goToAddAdminScreen() throws Exception{
		waitForPageLoaded();
		clickOnOtherHlthInsTab();
		clickOnAddAdministrator();
	}

	public void goToEditToOverridePAOnHealthInsurancePolicyScreen(String policyHolderName) throws Exception{
		waitForPageLoaded();
		clickOnHealthInsCovrgInfoTab();
		clickOnViewEditPolicy(policyHolderName);
	}

	public void goToAddNewPolicyScreen() throws Exception {
		waitForPageLoaded();
		clickOnHealthInsCovrgInfoTab();
		clickOnAddNewPolicyInfo();
	}

	public void validatePA_Amount_Status_Under_PremiumAssistanceSummary(
			String policyHolderName,
			String paAmount,
			String pymtStatus) throws Exception{

		waitForPageLoaded();
		
		if(paAmount.equals("")){
			validatePAamountForMember_Under_PremiumAssistanceSummary(policyHolderName, "");	
		} else{
			validatePAamountForMember_Under_PremiumAssistanceSummary(policyHolderName, "$ " + paAmount);	
		}			
		validatePaymentStatusForMember_Under_PremiumAssistanceSummary(policyHolderName, pymtStatus);
	}
	
	public void paValidatePaSummary(EVPD_Data evpdData, PA_Data paData, int memInd) throws Exception {
		waitForPageLoaded();
		
		if(paData.memsData.get(memInd).paAmount.equals("")){
			validatePAamountForMember_Under_PremiumAssistanceSummary(evpdData.memsData.get(memInd).fullName, "");	
		}else{
			validatePAamountForMember_Under_PremiumAssistanceSummary(evpdData.memsData.get(memInd).fullName, "$ " + paData.memsData.get(memInd).paAmount);	
		}
		
		validatePaymentStatusForMember_Under_PremiumAssistanceSummary(evpdData.memsData.get(memInd).fullName, paData.memsData.get(memInd).paymentStatus);
	}
	
	public void paValidatePremiumAssistanceInvestigationReferalCriteria(EVPD_Data evpdData, PA_Data paData, int memInd) throws Exception {
		validateAidCategoryForMember(evpdData.memsData.get(memInd).fullName, evpdData.memsData.get(memInd).mhAidCat);
		validateStatusForMember(evpdData.memsData.get(memInd).fullName, paData.memsData.get(memInd).tplStatus);
		validateAdminClosureReasonForMember(evpdData.memsData.get(memInd).fullName, paData.memsData.get(memInd).adminClosureReason);
		//validateFPLForMember(evpdData.memsData.get(memInd).fullName, evpdData.memsData.get(memInd).taxFPL);
	}
}


