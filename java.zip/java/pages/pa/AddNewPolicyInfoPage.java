package pages.pa;


import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import appdata.pa.PA_Data;
import db.DualTable;
import enums.PA_CoverageTypes;
import enums.PA_HealthInsuranceStatus;
import enums.PA_PaymentStatus;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import utils.DateUtil;

/**
 * 
 * @author Ritika Gupta
 *
 */
public class AddNewPolicyInfoPage extends CommonPage implements CommonPageOR {

	private static final By PaAddNewPolicyInfoPageHeader = By.xpath("//h1[contains(text(),'Premium Assistance - Add New Policy Information')]");

	public AddNewPolicyInfoPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocatedThenWait("PaAddNewPolicyInfoPageHeader", PaAddNewPolicyInfoPageHeader,5);
	}

	private void selectInsuranceType(String insuranceType) throws Exception {
		By insuranceTypeDD = By.id("insuranceType");
		selectDropDownElementByVisibleText("InsuranceTypeDD", insuranceTypeDD, insuranceType);
	}

	private void selectPolicyHolderName(String policyHolderName) throws Exception {
		By policyHolderNameDD = By.id("pol_holder_name");
		selectDropDownElementByVisibleText("PolicyHolderNameDD", policyHolderNameDD, policyHolderName);
	}

	private void enterPolicyNo(String policyNo) throws Exception {
		By policyNoTxt = By.id("pol_no");
		enterText("PolicyNoTxt", policyNoTxt, policyNo);
	}

	private void enterGroupNo(String groupNo) throws Exception {
		By groupNoTxt = By.id("gr_no");
		enterText("GroupNoTxt", groupNoTxt, groupNo);
	}

	// Brajesh
	private void selectEmployerName(int employerIndex) throws Exception {
		By employerNameDD = By.id("emp_name");
		selectDropDownElementByIndex("employerNameDD", employerNameDD, employerIndex);
	}

	private void selectPolicyType(String policyType) throws Exception {
		By policyTypeDD = By.id("pol_type");
		selectDropDownElementByVisibleText("PolicyTypeDD", policyTypeDD, policyType);
	}

	private void selectTierOfCov(String tierOfCov) throws Exception {
		By tierOfCovDD = By.id("tier_cov");
		selectDropDownElementByVisibleText("TierOfCovDD", tierOfCovDD, tierOfCov);
	}

	private void selectCovTypes(String covTypes) throws Exception {
		By covTypesDD = By.id("coverageTypes");
		selectDropDownElementByVisibleText("CovTypesDD", covTypesDD, covTypes);
	}

	private void enterInsuranceCompanyName(String insCompanyName) throws Exception {
		By carrierCodeTxt = By.name("insuranceCompany");
		enterTextThenPressDoubleTab("InsuranceCompanyTxt", carrierCodeTxt, insCompanyName);
	}

	// Brajesh
	private void enterInsCompanyNmIfOther(String insCompIfOther) throws Exception {
		By InsCompanyNmIfOtherTxt = By.id("insCompName");
			clearAndTypeAfterWait("InsCompanyNmIfOtherTxt", InsCompanyNmIfOtherTxt, insCompIfOther);
	}

	// Brajesh
	private void enterCarrierCodeIfOther(String carrerCodeIfOther) throws Exception {
		By CarrierCodeIfOtherTxt = By.id("carr_code");
		clearAndType("CarrierCodeIfOtherTxt", CarrierCodeIfOtherTxt, carrerCodeIfOther);
	}

	private void enterPlanName(String planName) throws Exception {
		By planNameTxt = By.name("planName");
		enterText("PlanNameTxt", planNameTxt, planName);
	}

	private void selectmeetBasicBenefitLevel(boolean trueFalseValue) throws Exception {
		By meetBasicBenefitLevelRdBtn = By.name("meetBasicBenefitLevel");
		selectByValue("MeetBasicBenefitLevelRdBtn", meetBasicBenefitLevelRdBtn, trueFalseValue + "");
	}

	private void selectenrolledPerMHRequest(boolean trueFalseValue) throws Exception {
		By enrolledPerMHRequestRdBtn = By.name("enrolledPerMHRequest");
		selectByValue("EnrolledPerMHRequestRdBtn", enrolledPerMHRequestRdBtn, trueFalseValue + "");
	}

	private void enterTotalPremiumCost(String totalPremiumCost) throws Exception {
		By totalPremiumCostTxt = By.id("mnth_prem_cost");
		enterTextThenPressDoubleTab("TotalPremiumCostTxt", totalPremiumCostTxt, totalPremiumCost);
	}

	// Brajesh
	private void enterEmployerContribution(String employerContribution) throws Exception { // Brajesh
																							// added
		By employerContributionTxt = By.id("emp_contri");
		enterTextThenPressDoubleTab("EmployerContributionTxt", employerContributionTxt, employerContribution);
	}

	// Brajesh
	public void selectHeathInsuranceStatus(int memIndex, String heathInsuranceStatus) throws Exception {
		By heathInsuranceStatusDD = By.name("listOfPaMemberHealthInsuranceStatusInfo[" + memIndex + "].healthInsuranceStatus");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "HeathInsuranceStatusDD", heathInsuranceStatusDD, heathInsuranceStatus);
	}

	// Brajesh
	public void enterPolicyStartDate(int memIndex, String policyStartDate) throws Exception {
		By policyStartDateTxt = By.name("listOfPaMemberHealthInsuranceStatusInfo[" + memIndex + "].coverageStartDate");
		clearAndType("Mem" + (memIndex + 1) + "policyStartDateTxt", policyStartDateTxt, policyStartDate);
	}

	// Brajesh
	public void enterPolicyEndDate(int memIndex, String policyEndDate) throws Exception {
		By policyEndDateTxt = By.name("listOfPaMemberHealthInsuranceStatusInfo[" + memIndex + "].coverageEndDate");
		clearAndType("Mem" + (memIndex + 1) + "policyEndDateTxt", policyEndDateTxt, policyEndDate);
	}

	public void selectPaymentStatus(String paymentStatus) throws Exception {
		By paymentStatusDD = By.id("pay_status");
		selectDropDownElementByVisibleText("PaymentStatusDD", paymentStatusDD, paymentStatus);
	}

	public void enterNextPaymentDate(String nextPaymentDate) throws Exception {
		By nextPaymentDateTxt = By.id("nextPaymentDate");
		clearAndType("NextPaymentDateDD", nextPaymentDateTxt, nextPaymentDate);
	}

	public void validateReqMemContribution(String reqMemContribution) throws Exception {
		By reqMemContributionTxt = By.id("req_member_contri");
		validateTextContains("ReqMemContributionTxt", reqMemContributionTxt, reqMemContribution);
	}

	public void validatePremiumAsstAmount(String premiumAsstAmount) throws Exception {
		By premiumAsstAmountTxt = By.id("prem_ass_amt");
		String actualPremiumAsstAmount = getElementAttribute(premiumAsstAmountTxt, "value");
		validateTextContains("PremiumAsstAmountTxt", actualPremiumAsstAmount, premiumAsstAmount);
	}

	public void enterPremiumAsstOverrideAmount(String premiumAsstOverrideAmount) throws Exception {
		By premiumAsstOverrideAmountTxt = By.id("paOverride");
		enterText("PremiumAsstOverrideAmountTxt", premiumAsstOverrideAmountTxt, premiumAsstOverrideAmount);
	}

	public void enterPremiumAsstOverrideEndDate(String premiumAsstOverrideEndDate) throws Exception {
		By premiumAsstOverrideEndDateTxt = By.id("paOverrideEndDate");
		clearAndType("PremiumAsstOverrideEndDateTxt", premiumAsstOverrideEndDateTxt, premiumAsstOverrideEndDate);
	}

	public void clickOnCalculate() throws Exception {
		By calculateBtn = By.id("calculateBtn");
		clickOnElementThenWait("CalculateBtn", calculateBtn, 10);
	}
	
	public void clickOnPremiumAssistanceHomePage() throws Exception {
		By premiumAssistanceBtn = By.id("premiumAssistance");
		clickOnElementThenWait("PremiumAssistanceBtn", premiumAssistanceBtn, 10);
	}
	
	public void handlePopUp() throws Exception {
		clickOnElementThenWait("PopUp", popupOkBtn, 10);
	}
	
	public void takeScreenshot() throws Exception {
		takeScreenshot("Summary");
	}

	public void enterEmployeeSponsoredPolicyDetails(
			String policyHolderName, 
			String polNo, 
			String gpNo,
			String policyType, 
			String tierOfCov,
			String covType, 
			boolean basicBenefitLevel, 
			boolean enrollMH,
			String monthlyCost, 
			String empContri, 
			String nextPayDate) throws Exception {

		waitForPageLoaded();
		selectInsuranceType("Employer Sponsored");
		selectPolicyHolderName(policyHolderName);
		enterPolicyNo(polNo);
		enterGroupNo(gpNo);
		selectEmployerName(1);
		selectPolicyType(policyType);
		selectTierOfCov(tierOfCov);
		selectCovTypes(covType);
		enterInsuranceCompanyName("ne"+Keys.TAB+Keys.TAB);
		//enterInsCompanyNmIfOther("Other");
		//enterCarrierCodeIfOther("9892683");
		
		enterPlanName("Plan Name");
		selectmeetBasicBenefitLevel(basicBenefitLevel);
		selectenrolledPerMHRequest(enrollMH);
		enterTotalPremiumCost(monthlyCost);
		enterEmployerContribution(empContri);
		enterNextPaymentDate(nextPayDate);
	}
	
	public void enterCOBRAPolicyDetails(
			String policyHolderName, 
			String polNo, 
			String gpNo,
			String policyType, 
			String tierOfCov,
			String covType, 
			String polInComName, 
			String GpInComNm,
			boolean basicBenefitLevel, 
			boolean enrollMH,
			String monthlyCost, 
			String nextPayDate) throws Exception {

		waitForPageLoaded();
		selectInsuranceType("COBRA/Retiree/Union");
		selectPolicyHolderName(policyHolderName);
		enterPolicyNo(polNo);
		enterGroupNo(gpNo);
		selectPolicyType(policyType);
		selectTierOfCov(tierOfCov);
		selectCovTypes(covType);
		enterInsuranceCompanyName("Other");
		enterInsCompanyNmIfOther("Other");
		enterCarrierCodeIfOther("9892683");
		
		enterPlanName(polInComName);
		selectmeetBasicBenefitLevel(basicBenefitLevel);
		selectenrolledPerMHRequest(enrollMH);
		enterTotalPremiumCost(monthlyCost);
		enterNextPaymentDate(nextPayDate);
	}
		
	public void enterPolicyOverrideDetailsAndCalculatePA(
			String paOverrideAmount, 
			String paymentStatus,
			String paOverrideAmountEndDate)  throws Exception {

		waitForPageLoaded();

		selectPaymentStatus(paymentStatus);
		enterPremiumAsstOverrideAmount(paOverrideAmount);
		enterPremiumAsstOverrideEndDate(paOverrideAmountEndDate);
		
		clickOnCalculate();
		takeScreenshot();
		waitForPageLoaded();
	}
	
	public void paEnterEmployeeSponsoredPolicyDetails(PA_Data paData, int memInd) throws Exception {
		waitForPageLoaded();
		
		Random rnd = new Random();
		
		String polNo = String.valueOf(100000 + rnd.nextInt(900000));
		String gpNo = String.valueOf(100000 + rnd.nextInt(900000));
		
		String currentDate = paData.appDate;
		String nextPaymentDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:" + paData.memsData.get(0).nextPayDatePriorFromToday);
		
		if(paData.memsData.get(memInd).policySource.equalsIgnoreCase("Employer Sponsored")){								
			selectInsuranceType(paData.memsData.get(memInd).policySource);
			selectPolicyHolderName(paData.memsData.get(memInd).policyHolderName);
			enterPolicyNo(polNo);
			enterGroupNo(gpNo);
			selectEmployerName(1);
			selectPolicyType(paData.memsData.get(memInd).policyType);
			selectTierOfCov(paData.memsData.get(memInd).tierOfCoverage);
			selectCovTypes(PA_CoverageTypes.getCoverageType(paData.memsData.get(memInd).coverageType));
			enterInsuranceCompanyName("ne" + Keys.TAB + Keys.TAB);
			//enterInsCompanyNmIfOther("Other");
			//enterCarrierCodeIfOther("9892683");
			
			enterPlanName("Plan Name");
			selectmeetBasicBenefitLevel(paData.memsData.get(memInd).basicBenefitLevel);
			selectenrolledPerMHRequest(paData.memsData.get(memInd).enrolledInMH);
			enterTotalPremiumCost(String.valueOf(paData.memsData.get(memInd).monthlyCost));
			
			String policyStartDate = DateUtil.getPriorDateInUIFormatUsingPattern(currentDate, DateUtil.UIDatePattern, "00:00:" + 180);
			
			String[] memsCov = paData.memsData.get(memInd).membersCovered.split("_");
			
			for(String mem : memsCov){
				int memNo = Integer.parseInt(mem.substring(mem.lastIndexOf("M") + 1)) - 1;				
						
				selectHeathInsuranceStatus(memNo, PA_HealthInsuranceStatus.getHealthInsuranceStatus(paData.memsData.get(memNo).healthInsuranceStatus));
				enterPolicyStartDate(memNo, policyStartDate);
			}
			
			enterEmployerContribution(paData.memsData.get(0).empContribution);
			enterNextPaymentDate(nextPaymentDate);
			
		}else if(paData.memsData.get(memInd).policySource.equalsIgnoreCase("COBRA/Retiree/Union")){
			selectInsuranceType(paData.memsData.get(memInd).policySource);
			selectPolicyHolderName(paData.memsData.get(memInd).policyHolderName);
			enterPolicyNo(polNo);
			enterGroupNo(gpNo);
			selectPolicyType(paData.memsData.get(memInd).policyType);
			selectTierOfCov(paData.memsData.get(memInd).tierOfCoverage);
			selectCovTypes(PA_CoverageTypes.getCoverageType(paData.memsData.get(memInd).coverageType));
			enterInsuranceCompanyName("Other");
			enterInsCompanyNmIfOther("Other");
			enterCarrierCodeIfOther("9892683");
			
			enterPlanName("Other");
			selectmeetBasicBenefitLevel(paData.memsData.get(memInd).basicBenefitLevel);
			selectenrolledPerMHRequest(paData.memsData.get(memInd).enrolledInMH);
			enterTotalPremiumCost(String.valueOf(paData.memsData.get(memInd).monthlyCost));
			enterNextPaymentDate(nextPaymentDate);
		}
		
		clickOnCalculate();
		validatePremiumAsstAmount(paData.memsData.get(memInd).paAmount);
		clickOnPremiumAssistanceHomePage();
	}
	
	public void paEnterPolicyOverrideDetailsAndCalculatePA(PA_Data paData, int memInd)  throws Exception {
		waitForPageLoaded();

		selectPaymentStatus(PA_PaymentStatus.getPaymentStatus(paData.memsData.get(memInd).ovrPaymentStatus));
		enterPremiumAsstOverrideAmount(paData.memsData.get(memInd).ovrAmnt);
		enterPremiumAsstOverrideEndDate(DateUtil.getFutureDateInUIFormatUsingPattern(paData.appDate, DateUtil.UIDatePattern, "00:00:" + paData.memsData.get(memInd).ovrEndDtPriorFromToday));
		
		clickOnCalculate();
		takeScreenshot();
		waitForPageLoaded();
	}
	
	public void validateErrorMessage() throws Exception{
        By errorMsgLabel = By.id("errorMsg2");
        waitForPageLoaded();
        String errorMsgTxt="An error was encountered while calculating the policy. Please try again later.";
        validateTextEquals("ErrorMessage", errorMsgLabel, errorMsgTxt);    
        takeScreenshot();
	}
}
