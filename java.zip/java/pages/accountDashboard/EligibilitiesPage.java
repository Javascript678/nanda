package pages.accountDashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;

/**
 *  This Page Appears when we click on View All link on Account Dashboard Page
 * @author Vinay Kumar
 *
 */
public class EligibilitiesPage extends CommonPage {
	
	private static final By eligibilitiesPageHeader = By.xpath("//h1/strong[text()='Eligibilities']");
	
		
	
	public EligibilitiesPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("EligibilitiesPageHeader", eligibilitiesPageHeader,5);
	}
	
	public void clickOnThreeDotMenuForLatestElg() throws Exception{
		By threeDotMenu = By.id("threeDotsMenu_0");
		clickOnElement("ThreeDotMenuForLatestElg", threeDotMenu);
	}
	
	public void clickOnViewDetailsDropDownMenu() throws Exception{
		By viewDetailsDDMenu = By.xpath("//ul[@class='dropdown-content']//a[contains(text(),'View Details')]");
		clickOnElement("ViewDetailsDDMenu", viewDetailsDDMenu);
	}
	
	public void clickOnViewDataSourceDetailsDropDownMenu() throws Exception{
		By viewDataSourceDetailsDDMenu = By.xpath("//ul[@class='dropdown-content']//a[contains(text(),'View Data Source Details')]");
		clickOnElement("ViewDataSrcDetailsDDMenu", viewDataSourceDetailsDDMenu);
	}
	
	public void pageLoadAndClickOnThreeDotMenuForLatestElg() throws Exception{
		waitForPageLoaded();
		clickOnThreeDotMenuForLatestElg();
	}
	
	/*ritu*/
    
    public void validateUserName( String username,String Eligid) throws Exception{
          By userNameLabel = By.xpath("//form[@id='compareEligibilityForm']//div//table//th[contains(.,'User')]/../../following-sibling::tbody//td[contains(.,'"+Eligid+"')]/following-sibling::td[1]");
          validateTextContains("UserName", userNameLabel, username);         
    }
    
    
    /*ritu*/
    public void validateTypeOfUser( String userType,String Eligid) throws Exception{
          By userTypeLabel = By.xpath("//form[@id='compareEligibilityForm']//div//table//th[contains(.,'User')]/../../following-sibling::tbody//td[contains(.,'"+Eligid+"')]/following-sibling::td[1]/span");
          validateTextContains("UserType", userTypeLabel, userType);         
    }
    
    /*ritu*/
    public void validateDateAndTime( String dateAndTime,String Eligid) throws Exception{
          By dateLabel = By.xpath("//form[@id='compareEligibilityForm']//div[1]//table//th[contains(.,'Date & Time')]/../../following-sibling::tbody//td[contains(.,'"+Eligid+"')]/following-sibling::td[2]");
          validateTextContains("DateAndTime", dateLabel, dateAndTime);             
    }
    
    /*ritu*/
    public void validateEligibilityStatus( String eligibilityStatus,String Eligid) throws Exception{
          By eligibilityStatusLabel = By.xpath("//form[@id='compareEligibilityForm']//div//table//th[contains(.,'Eligibility Status')]/../../following-sibling::tbody//td[contains(.,'"+Eligid+"')]/following-sibling::td[3]");
          validateTextContains("EligibilityStatus", eligibilityStatusLabel, eligibilityStatus);         
    }
    
    /*ritu*/
    public void validateDetermination( String determination,String Eligid) throws Exception{
          By determinationLabel = By.xpath("//form[@id='compareEligibilityForm']//div//table//th[contains(.,'Determination')]/../../following-sibling::tbody//td[contains(.,'"+Eligid+"')]/following-sibling::td[4]");
          validateTextContains("Determination", determinationLabel, determination);       
    }
    
    /*ritu*/
    public void validateOEP( String oep,String Eligid) throws Exception{
          By oepLabel = By.xpath("//form[@id='compareEligibilityForm']//div//table//th[contains(.,'OEP')]/../../following-sibling::tbody//td[contains(.,'"+Eligid+"')]/following-sibling::td[5]");
          validateTextContains("OEP", oepLabel, oep);          
    }
    
    /*ritu*/
    public void validateViewDetailslink(String Eligid) throws Exception{
          By viewDetailslink = By.xpath("//form[@id='compareEligibilityForm']//div//table//th/../../following-sibling::tbody//td[contains(.,'"+Eligid+"')]/following-sibling::td[6]//a[contains(.,'View Details')]");
          isElementPresent(viewDetailslink);             
    }
    
    /*ritu*/
    public void validateViewDataSourceDetailslink(String Eligid) throws Exception{
          By viewDateSourceDetailslink = By.xpath("//form[@id='compareEligibilityForm']//div//table//th/../../following-sibling::tbody//td[contains(.,'"+Eligid+"')]/following-sibling::td[6]//a[contains(.,'View Data Source Details')]");
          isElementPresent(viewDateSourceDetailslink);
    }
    
    /*ritu*/
    public void takeScreenshot() throws Exception{
          
          takeScreenshot("EligibilitiesPage");
    }
    
    //Ritu
    public void clickOnChkBoxForEligibility(String elgId) throws Exception{
        By eligIdchkbox = By.xpath("//input[@name='eligibilityIdSelected' and @value='"+elgId+"'']");
        clickOnElement("EligibilityIdCheckBox", eligIdchkbox);
    }
  
    //Ritu
   public void clickOnCompareButton() throws Exception{
           By compareBtn= By.xpath("//button[@id='compareButtonId']");
           clickOnElement("CompareEligibilitiesBtn",compareBtn);
    }


}
