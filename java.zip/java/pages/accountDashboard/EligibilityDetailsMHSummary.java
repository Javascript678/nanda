package pages.accountDashboard;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;

/**
 *  This Page Appears when we click on View Details link on Eligibilities Page and 
 *  then on Medicaid HouseHold Summary Tab
 * @author Anubhuti
 */

public class EligibilityDetailsMHSummary extends CommonPage {
	
		private static final By eligibilitiesPageHeader = By.xpath("//h1/strong[text()='Eligibility Details']");
	

		public EligibilityDetailsMHSummary(WebDriver driver, String testCaseId) {
			super(driver, testCaseId);
		}

		
		private void waitForPageLoaded() throws Exception{
			waitForPresenceOfElementLocatedThenWait("EligibilyDetailsPgHdr", eligibilitiesPageHeader,5);
		}
		
		public void takeScreenshot() throws Exception{
			waitForPageLoaded();
	        takeScreenshot("EligibilityDetailsMHSummary");
		}
		
		// ####################  Click On TAB START ############################
		//
		public void clickOnMH_SummaryTab() throws Exception {
			By mhsummaryTab = By.xpath("//*[@id='medicaidHouseholdButton']");
			clickOnElement("Medicaid HouseHold Summary", mhsummaryTab);
		}
		
		public void clickOnDropDown(String name) throws Exception {
			By clickOnDropDown = By.xpath("//div[span[contains(text(),'"+name+"')]]");
			waitForPresenceOfElementLocatedThenWait("MemberData", clickOnDropDown ,5);
			clickOnElement("MemberData", clickOnDropDown);
		}
		
		
	  //#############Validation For Member Data STARTED######################
	  //
      ///////Anubhuti
		public void validateDOB(String memberName, String expectedDOB) throws Exception {
			By dobLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[1]/span[2]");
			validateTextContains("DOB -"+memberName, dobLabel, expectedDOB);

		}
		
		public void validateVerifiedDisability(String memberName, String expectedVD) throws Exception {
			By vdLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[2]/span[2]");
			validateTextContains(" Verified Disability -"+memberName, vdLabel, expectedVD);

		}
		
		public void validateHeadOfHouseHold(String memberName, String expectedHOH) throws Exception {
			By hohLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[3]/span[2]");
			validateTextContains("Head Of House Hold?-"+memberName, hohLabel, expectedHOH);

		}
		
		public void validateHIVPositive(String memberName, String expectedHOH) throws Exception {
			By hohLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[4]/span[2]");
			validateTextContains("HOH -"+memberName, hohLabel, expectedHOH);

		}
		
		public void validateFileJointly(String memberName, String expectedFJ) throws Exception {
			By fjLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[5]/span[2]");
			validateTextContains("FilingJointly -"+memberName, fjLabel, expectedFJ);

		}
		
		public void validateReceivingDMHServices(String memberName, String expectedDMH) throws Exception {
			By dmhLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[6]/span[2]");
			validateTextContains("ReceivingDMHServices -"+memberName, dmhLabel, expectedDMH);

		}
		
		public void validateClaimingDependents(String memberName, String expectedDMH) throws Exception {
			By dmhLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[7]/span[2]");
			validateTextContains("ClaimingDepedents -"+memberName, dmhLabel, expectedDMH);

		}
		
		public void validateFormerFosterCare(String memberName, String expectedFFC) throws Exception {
			By ffcLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[8]/span[2]");
			validateTextContains("FormerFosterCare -"+memberName, ffcLabel, expectedFFC);

		}
		
		public void validateSelfAttestedDisability(String memberName, String expectedDisability) throws Exception {
			By disabilityLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[9]/span[2]");
			validateTextContains("FormerFosterCare -"+memberName, disabilityLabel, expectedDisability);

		}
		
		public void validateIsSafeHarborEligible(String memberName, String expectedSafeHarbor) throws Exception {
			By safeHarborLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[10]/span[2]");
			validateTextContains("IsSafeHarborEligible -"+memberName, safeHarborLabel, expectedSafeHarbor);

		}
		
		public void validateAidCategory(String memberName, String expectedAidCategory) throws Exception {
			By aidCategoryLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[11]/span[2]");
			validateTextContains("IsSafeHarborEligible -"+memberName, aidCategoryLabel, expectedAidCategory);

		}
		
		public void validateIsPostPartumEligible(String memberName, String expectedPostPartumEligible) throws Exception {
			By postPartumEligibleLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[12]/span[2]");
			validateTextContains("IsSafeHarborEligible -"+memberName, postPartumEligibleLabel, expectedPostPartumEligible);

		}
		
		public void validateCitizenshipImmigrationStatus(String memberName, String expectedCitizenship) throws Exception {
			By citizenshipLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[13]/span[2]");
			validateTextContains("Citizenship/ImmigrationStatus -"+memberName, citizenshipLabel, expectedCitizenship);

		}
		
		public void validatePregnant(String memberName, String expectedPregnancyStatus) throws Exception {
			By pregnancyStatusLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[14]/span[2]");
			validateTextContains("Is Pregnant -"+memberName, pregnancyStatusLabel, expectedPregnancyStatus);

		}
		
		public void validateMaritalStatus(String memberName, String expectedMaritalStatus) throws Exception {
			By maritalStatusLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[16]/span[2]");
			validateTextContains("Married -"+memberName, maritalStatusLabel, expectedMaritalStatus);

		}
		public void validateClaimedbyNonCustodialParent(String memberName, String expectedClaimedNonCustodialParent) throws Exception {
			By claimedNonCustodialLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[18]/span[2]");
			validateTextContains("Claimed by Non Custodial Parent -"+memberName, claimedNonCustodialLabel, expectedClaimedNonCustodialParent);

		}
		
		public void validateEligibilityBeginDate(String memberName, String expectedEligibilityBeginDate) throws Exception {
			By eligibilityBeginDateLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[19]/span[2]");
			validateTextContains("Eligibility Begin Date -"+memberName, eligibilityBeginDateLabel, expectedEligibilityBeginDate);

		}
		
		public void validateOtherHealthInsurance(String memberName, String expectedOtherHealthInsurance) throws Exception {
			By otherHealthInsuranceLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[20]/span[2]");
			validateTextContains("Other Health Insurance"+memberName, otherHealthInsuranceLabel, expectedOtherHealthInsurance);

		}

		public void validateMedicaidChildAge(String memberName, String expectedMedicaidChildAge) throws Exception {
			By medicaidChildAgeLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[21]/span[2]");
			validateTextContains("MedicaidChildAge" +memberName, medicaidChildAgeLabel, expectedMedicaidChildAge);

		}
		
		public void validateBCC(String memberName, String expectedBCC) throws Exception {
			By bccLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[22]/span[2]");
			validateTextContains("BCC" +memberName, bccLabel, expectedBCC);

		}
		

		public void validateRequiredToFileTaxes(String memberName, String expectedRequiredToFileTaxes) throws Exception {
			By FileTaxesLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[23]/span[2]");
			validateTextContains("Required To File Taxes" +memberName, FileTaxesLabel, expectedRequiredToFileTaxes);

		}
		
		public void validateReceivedMedicaidInFosterCare(String memberName, String expectedReceivedMedicaidInFosterCare) throws Exception {
			By receivedMedicaidInFosterCareLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[24]/span[2]");
			validateTextContains("Received Medicaid In Foster Care" +memberName, receivedMedicaidInFosterCareLabel, expectedReceivedMedicaidInFosterCare);

		}
		

		public void validateClaimedAsDependent(String memberName, String expectedClaimedAsDependent ) throws Exception {
			By claimedAsDependentLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[25]/span[2]");
			validateTextContains("Claimed As Dependent" +memberName, claimedAsDependentLabel, expectedClaimedAsDependent);

		}
		
		public void validateBornMHEligible(String memberName, String expectedBornMHEligible ) throws Exception {
			By bornMHEligibleLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[26]/span[2]");
			validateTextContains("Born MH Eligible" +memberName, bornMHEligibleLabel, expectedBornMHEligible);

		}
		
		public void validateMedicaidTaxRole(String memberName, String expectedMedicaidTaxRole ) throws Exception {
			By medicaidTaxRoleLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[27]/span[2]");
			validateTextContains("Medicaid Tax Role" +memberName, medicaidTaxRoleLabel, expectedMedicaidTaxRole);

		}
		
		public void validateSelfAttestedIncarceration(String memberName, String expectedSelfAttestedIncarceration ) throws Exception {
			By selfAttestedIncarcerationLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[28]/span[2]");
			validateTextContains("Self Attested Incarceration" +memberName, selfAttestedIncarcerationLabel, expectedSelfAttestedIncarceration);

		}
		
		public void validateMedicallyFrail(String memberName, String expectedMedicallyFrail ) throws Exception {
			By medicallyFrailLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[29]/span[2]");
			validateTextContains("Medically Frail" +memberName, medicallyFrailLabel, expectedMedicallyFrail);

		}
		
		public void validateMedicallyFrailEffectiveDate(String memberName, String expectedMedicallyFrailEffectiveDate ) throws Exception {
			By medicallyFrailEffectiveDateLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[30]/span[2]");
			validateTextContains("Medically Frail Effective Date" +memberName, medicallyFrailEffectiveDateLabel, expectedMedicallyFrailEffectiveDate);

		}
		
		public void validateTPLStatus(String memberName, String expectedTPLStatus) throws Exception {
			By tplStatusLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[31]/span[2]");
			validateTextContains("TPL Status" +memberName, tplStatusLabel, expectedTPLStatus);

		}
		
		public void validateTMAPeriodEndDate(String memberName, String expectedTMAPeriodEndDate) throws Exception {
			By tmaPeriodEndDateLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[32]/span[2]");
			validateTextContains("TMA Period End Date" +memberName, tmaPeriodEndDateLabel, expectedTMAPeriodEndDate);

		}
		public void validateContinuedMHStandardEligibilityForPregnantWomen(String memberName, String expectedMHStandardEligibilty) throws Exception {
			By mhStandardEligibiltyLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[33]/span[2]");
			validateTextContains("Continued MassHealth Standard Eligibility for Pregnant Women " +memberName, mhStandardEligibiltyLabel, expectedMHStandardEligibilty);

		}
		
		public void validatePregnancyEndDate(String memberName, String expectedPregnancyEndDate) throws Exception {
			By pregnancyEndDateLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[34]/span[2]");
			validateTextContains("Pregnancy End Date" +memberName, pregnancyEndDateLabel, expectedPregnancyEndDate);

		}
		
		public void validateMHPending(String memberName, String expectedMHPending) throws Exception {
			By mhPendingLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[35]/span[2]");
			validateTextContains("MH Pending" +memberName, mhPendingLabel, expectedMHPending);

		}
		
		public void validateSecondProvisionalRestricted (String memberName, String expectedSecondProvisionalRestricted ) throws Exception {
			By secondProvisionalRestrictedLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/ul/li[36]/span[2]");
			validateTextContains("Second Provisional Restricted" +memberName, secondProvisionalRestrictedLabel, expectedSecondProvisionalRestricted);

		}
		
		
		  //#############Validation For Applicant List STARTED######################
		  //

		public void validateApplicantName_ApplicationList(String memberName, String expectedApplicantName) throws Exception {
			By applicantNameLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div/table/tbody/tr/th/span");
			validateTextContains("Applicant Name -"+memberName, applicantNameLabel, expectedApplicantName);

		}
		public void validateRelationship_ApplicationList(String memberName, String expectedRelationship) throws Exception {
			By relationshipLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div/table/tbody/tr/td[1]");
			validateTextContains("RelationShip -"+memberName, relationshipLabel, expectedRelationship);

		}
		
		public void validateLivesWith_ApplicationList(String memberName, String expectedLivesWith) throws Exception {
			By livesWithLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div/table/tbody/tr/td[2]");
			validateTextContains("Lives With? "+memberName, livesWithLabel, expectedLivesWith);

		}
		
		public void validateClaimingTaxFiler_ApplicationList(String memberName, String expectedTaxFiler) throws Exception {
			By taxFilerLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div/table/tbody/tr/td[3]");
			validateTextContains(" 	Claiming Tax Filer ?"+memberName, taxFilerLabel, expectedTaxFiler);

		}
		public void validateAge_ApplicationList(String memberName, String expectedAge) throws Exception {
			By ageLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div/table/tbody/tr/td[4]");
			validateTextContains("Age"+memberName, ageLabel, expectedAge);

		}
		
		//#############Validation For Applicant List ENDED######################
		//
		
		
		//#################### Validation For MassHealth MAGI Household Size Started ###############
		//

		public void validateMAGIHHSize(String memberName,String magiHHSize) throws Exception
		{
			By magiHHSizeLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[2]/table/tfoot/tr/td[1]");
			validateTextContains("MAGIHH Size for"+memberName, magiHHSizeLabel, magiHHSize);
		}
		
		//#################### Validation For MassHealth MAGI Household Size Ended ###############
		//
		
		
		//#################### Validation For Tax Household Size Started ###############
		//
		
		public void validateTaxHHSize(String memberName, String expectedtaxHHSize) throws Exception{
			By taxHHSizeLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[3]/table/tfoot/tr/td[1]");
			validateTextContains("TaxHH Size for"+memberName ,taxHHSizeLabel, expectedtaxHHSize);		
		}
			
		//#################### Validation For Tax Household Size Ended ###############
		//
		
		
		//#################### Validation For Federal Poverty Level (FPL) Started ################
		//
		
		public void validateMagiFPL(String memberName, String expectedMagiFPL ) throws Exception{
			By magiFPLLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[4]/table/tbody/tr[1]/td[1]");
			validateTextContains("Magi FPL for"+memberName, magiFPLLabel, expectedMagiFPL);		
		}
		
		public void validateTaxFPL(String memberName, String expectedTaxFPL ) throws Exception{
			By taxFPLLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[4]/table/tbody/tr[2]/td");
			validateTextContains("Tax FPL for"+memberName, taxFPLLabel, expectedTaxFPL);		
		}
		
		//#################### Validation For Federal Poverty Level (FPL) Ended ################
		//
		
		
		//##############Validation For Premium Assistance Information STARTED####################
		//
		
		public void validateStatus_PremiumAssitanceInformation(String memberName, String expectedPAStatus) throws Exception{
			By paStatusLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[6]/table/tbody/tr/th[1]");
			validateTextContains("Status Indicator Under Premium Assitance for"+memberName, paStatusLabel, expectedPAStatus);		
		}
		
		public void validateAssistanceAmount_PremiumAssitanceInformation(String memberName, String expectedAssistanceAmount) throws Exception{
			By assistanceAmountLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[6]/table/tbody/tr/th[2]");
			validateTextContains("Assistance Amount Under PremiumAssitance for"+memberName, assistanceAmountLabel, expectedAssistanceAmount);		
		}
		
		public void validateEffectiveDate_PremiumAssitanceInformation(String memberName, String expectedEffectiveDate) throws Exception{
			By effecticeDateLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[6]/table/tbody/tr/th[2]");
			validateTextContains("Effective Date PremiumAssitance for"+memberName, effecticeDateLabel, expectedEffectiveDate);		
		}
		
		
		//##############Validation For Premium Assistance Information ENDED############
		//
		
		//#############Validation For SSBDetailsMonthly STARTED######################
		//
		public void validateApplicantName_SSBDetailsMonthly(String memberName, String expectedApplicantName) throws Exception {
			By applicantNameLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[8]/table/tbody/tr[1]/th/span");
			
			validateTextContains("ApplicantName_SSBDetailsMonthly for"+memberName, applicantNameLabel, expectedApplicantName);

		}
		
		public void validateCurrentUserAttestedSSBTitleIIIncome_SSBDetailsMonthly(String memberName, String expectedTitleIIIncome) throws Exception {
			By title2IncomeLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[8]/table/tbody/tr[1]/td[1]");
			
			validateTextContains("CurrentUserAttestedSSBTitleIIIncome for"+memberName, title2IncomeLabel, expectedTitleIIIncome);

		}
		public void validateSSBusedInCurrentProgramDetermination_SSBDetailsMonthly(String memberName, String expectedSSBInCurrentProgram) throws Exception {
			By ssbInCurrentProgramLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[8]/table/tbody/tr[1]/td[2]");
			
			validateTextContains("SSBusedInCurrentProgramDetermination for"+memberName, ssbInCurrentProgramLabel, expectedSSBInCurrentProgram);

		}
		
		public void validateSSBusedInLastProgramDetermination_SSBDetailsMonthly(String memberName, String expectedSSBInLastProgram) throws Exception {
			By ssbInLastProgramLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[8]/table/tbody/tr[1]/td[3]");
			
			validateTextContains("SSBusedInCurrentProgramDetermination for"+memberName, ssbInLastProgramLabel, expectedSSBInLastProgram);

		}
		

		//#############Validation For SSBDetailsMonthly ENDED######################
		//
		
		
		
		//#############Validation For Required Documentation STARTED######################
		//
		
		public void validateDocumentType_RequiredDocumentation(String memberName, String expectedDocumentType) throws Exception 
		{
			String[] docTypeArray = expectedDocumentType.split(",");
			
			int count = 1;
			for(String docType : docTypeArray)
			{
				By requiredDocumentLabel = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[9]/table/tbody/tr["+count+"]/th");
				validateTextContains("Required Document Type for"+memberName, requiredDocumentLabel, docType);
				count++;											
			}
			

		}
		
		public void validateDueDate_RequiredDocumentation(String memberName, String expectedDueDate) throws Exception {
			By dueDate = By.xpath("//div[span[contains(text(),'"+memberName+"')]]/./following-sibling::div/div[9]/table/tbody/tr[1]/td");
			
			validateTextContains("Due Date for required documentation for"+memberName, dueDate, expectedDueDate);
		}
		
		//#############Validation For Required Documentation ENDED######################		
		//
		
		//#################### Validation For Member Data Ended ################
		
		//#################### Validation For Premium Billing Family Groups Started ################
		
		public void validatePBFGMonthlyPremium(int pbfgNo, String monthlyPremiumAmt) throws Exception{
			By monthlyPremium = By.xpath("//th[text()='PBFG "+pbfgNo+"']/../td[3]");
			validateTextContains("PBFG"+pbfgNo+"MonthlyPremium", monthlyPremium, monthlyPremiumAmt);
		}
		
		//#################### Validation For Premium Billing Family Groups Ended ################
		
		
}


