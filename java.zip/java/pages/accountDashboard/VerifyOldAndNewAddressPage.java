package pages.accountDashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * This Page Appears when we click on View All link on Account Dashboard Page
 * 
 * @author Aashita
 *
 */
public class VerifyOldAndNewAddressPage extends CommonPage implements CommonPageOR {
	private static final By verifyOldNewHeader = By.xpath("//h1[contains(.,'Verify Old Address')]");

	public VerifyOldAndNewAddressPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocatedThenWait("ManualIDProofingHeader", verifyOldNewHeader, 5);
	}

	public void clickOnoldAddressBtn() throws Exception {
		By verifyOldAddBtn = By
				.xpath("//div[@class ='unboldLbl checkbox checkboxBlock']/span/label[contains(.,'Old')]");
		clickOnElement("VerifyButton", verifyOldAddBtn);
	}

	public void clickOnNewAddressBtn() throws Exception {
		By verifyNewAddBtn = By
				.xpath("//div[@class ='unboldLbl checkbox checkboxBlock']/span/label[contains(.,'New')]");
		clickOnElement("VerifyButton", verifyNewAddBtn);
	}

	public void enterTextCommentArea() throws Exception {
		By enterTextComment = By.id("comment");
		enterText("Save comments", enterTextComment, "OK");
	}

	public void clickSavecomments() throws Exception {
		By clickSaveCommentsBtn = By.id("saveButton");
		clickOnElement("Save Comments", clickSaveCommentsBtn);

	}

	public void clickOnWarningPOPUP() throws Exception {
		clickOnElement("WarningPOPUP", warningOkButton);

	}

	public void clickVerifyBtn() throws Exception {
		By clickVerifyBtn = By.id("verifyButton");
		clickOnElement("Verify", clickVerifyBtn);

	}

	public void verifyOldAndNewAddress() throws Exception {
		waitForPageLoaded();
		clickOnoldAddressBtn();
		clickOnNewAddressBtn();
		enterTextCommentArea();
		clickSavecomments();
		clickOnWarningPOPUP();
		clickVerifyBtn();
		clickOnWarningPOPUP();
	}

}
