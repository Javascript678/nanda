package pages.accountDashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;

/**
 *  This Page Appears when we click on View All link on Account Dashboard Page
 * @author Vinay Kumar
 *
 */
public class EligibilitiesDetailsLandingPage extends CommonPage {
	
	private static final By eligibilitiesPageHeader = By.xpath("//h1/strong[text()='Eligibilities']");
	
		
	
	public EligibilitiesDetailsLandingPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("EligibilitiesPageHeader", eligibilitiesPageHeader,5);
	}
	
	public void clickOnThreeDotMenuForLatestElg() throws Exception{
		By threeDotMenu = By.id("threeDotsMenu_0");
		clickOnElement("ThreeDotMenuForLatestElg", threeDotMenu);
	}
	
	public void clickOnViewDetailsDropDownMenu() throws Exception{
		By viewDetailsDDMenu = By.xpath("//ul[@class='dropdown-content']//a[contains(text(),'View Details')]");
		clickOnElement("ViewDetailsDDMenu", viewDetailsDDMenu);
	}
	
	public void clickOnViewDataSourceDetailsDropDownMenu() throws Exception{
		By viewDataSourceDetailsDDMenu = By.xpath("//ul[@class='dropdown-content']//a[contains(text(),'View Data Source Details')]");
		clickOnElement("ViewDataSrcDetailsDDMenu", viewDataSourceDetailsDDMenu);
	}
	
	public void pageLoadAndClickOnThreeDotMenuForLatestElg() throws Exception{
		waitForPageLoaded();
		clickOnThreeDotMenuForLatestElg();
	}
	
	
	
	
}
