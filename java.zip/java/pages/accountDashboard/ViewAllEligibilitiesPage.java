package pages.accountDashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class ViewAllEligibilitiesPage extends CommonPage implements CommonPageOR{
	
	
	public ViewAllEligibilitiesPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void validateDeterminationPurpose(String EligibilityID, String Purpose) throws Exception{
		By determinationPurpose = By.xpath(".//*[@id='compareEligibilityForm']/child::div/child::table/tbody/tr/td[contains(.,'"+EligibilityID+"')]/parent::tr/parent::tbody/tr/td[5]");
		validateTextEquals("Determination Purpose", determinationPurpose, Purpose);
	}
			
}
