package pages.accountDashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 *  This Page Appears when we click on View All link on Account Dashboard Page
 * @author Ritu Negi
 *
 */
public class ManualIdProofingPage extends CommonPage implements CommonPageOR {
	
	private static final By manualIDProofingHeader = By.xpath("//h1[contains(.,'Manual ID Proofing for')]");
	public ManualIdProofingPage(WebDriver driver, String testCaseId)
	{
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception
	{
		waitForPresenceOfElementLocatedThenWait("ManualIDProofingHeader",manualIDProofingHeader,5);
	}
	
	public void clickOnVerifyBtn() throws Exception{
		By verifyBtn = By.id("idVerificationButton");
		clickOnElement("VerifyButton",verifyBtn);
		
	}
	public void clickOnWarningPOPUP() throws Exception{
		clickOnElement("WarningPOPUP",warningOkButton);	
	}
	public void clickOnBackBtn() throws Exception{
		clickOnElement("BackButton",backButton);
		
	}
	public void verifyManualIdProofing() throws Exception{
		waitForPageLoaded();
		clickOnVerifyBtn();
		clickOnWarningPOPUP();
		clickOnBackBtn();
	}
	
	
	
		
}
