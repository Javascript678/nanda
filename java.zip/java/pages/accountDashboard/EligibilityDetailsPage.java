package pages.accountDashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;

/**
 *  This Page Appears when we click on View Details link on Eligibilities Page
 * @author Vinay Kumar
 *
 */
public class EligibilityDetailsPage extends CommonPage {
	
	private static final By eligibilitiesPageHeader = By.xpath("//h1/strong[text()='Eligibility Details']");
	
		
	
	public EligibilityDetailsPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("EligibilyDetailsPgHdr", eligibilitiesPageHeader,5);
	}
	
	// ####################  Click On TAB START ############################
	//
	public void clickOnFamilyHHTab() throws Exception {
		By familyHHTab = By.xpath("//span[text()='Family & Household']");
		clickOnElement("FamilyHHTab", familyHHTab);
	}
	
	public void clickOnContactInformationTab() throws Exception {
		By contactInformationTab = By.xpath("//span[text()='Contact Information']");
		clickOnElement("ContactInformationTab", contactInformationTab);
	}
	
	//TODO : For Other 4 Tab
	//
	// ####################  Click On TAB END ############################
	
	// ####################  Validation For Contact Info Tab START ############################
	////Anubhuti
	public void validateContactAddressUnderContactInfoTab(String expectedContactAddr) throws Exception {
		By contactaddressLabel = By.xpath(
				"//div[span[text()='Contact Information']]/following-sibling::div//ul/li[span[text()='Address']]/span[2]");
		validateTextContains("ContactAddress", contactaddressLabel, expectedContactAddr);

	}

	public void validateEmailUnderContactInfoTab(String expectedEmail) throws Exception {
		By emailLabel = By.xpath(
				"//div[span[text()='Contact Information']]/following-sibling::div//ul/li[span[text()='Email']]/span[2]");
		validateTextContains("ContactEmail", emailLabel, expectedEmail);
	}

	public void validatePhoneUnderContactInfoTab(String expectedPhone) throws Exception {
		By phoneLabel = By.xpath(
				"//div[span[text()='Contact Information']]/following-sibling::div//ul/li[span[text()='Phone']]/span[1]");
		validateTextContains("ContactPhone", phoneLabel, expectedPhone);
	}
	//
	// ####################  Validation For Contact Info Tab END ############################
	
	// ####################  Validation For Family HH Info Tab START ############################
	//
	public void validateSSNUnderFamilyHHTab(int memNo, String expectedSSN) throws Exception {
		By ssnForMember = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo+ "]/li[span[text()='Social Security Number']]/span[2]");
		//validateLast4DigitOfSSN("SSNForMem" + memNo, ssnForMember, expectedSSN);
	}
	public void validateApplyingForCoverageUnderFamilyHHTab(int memNo, String expectedCoverage) throws Exception {
		By coverageLabel = By.xpath(
				"//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[1]/li[span[text()='Applying for coverage']]/span[2]");
		validateTextContains("ApplyingForCoverageFor"+memNo, coverageLabel, expectedCoverage);
	}

	public void validateHHAddressUnderFamilyHHTab(int memNo, String expectedAddress) throws Exception {
		By hhAddressLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Address']]//span[@class='fullEllipsis']/span/span");
		validateTextContains("HouseHoldAddressForMem", hhAddressLabel, expectedAddress);
	}

	public void validateMemberAddressUnderFamilyHHTab(int memNo, String expectedMemAddress) throws Exception {
		By memAddressLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Address']]/span[2]");
		validateTextContains("AddressForMem" + memNo, memAddressLabel, expectedMemAddress);
	}

	public void validateDateOfBirthUnderFamilyHHTab(int memNo, String expectedCoverage) throws Exception {
		By dobLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Date of Birth']]/span[2]");
		validateTextContains("DOBForMem" + memNo, dobLabel, expectedCoverage);
	}

	public void validateCitizenShipUnderFamilyHHTab(int memNo, String expectedCoverage) throws Exception {
		By citizenShipLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Citizenship ']]/span[2]");
		validateTextContains("CitizenshipForMem" + memNo, citizenShipLabel, expectedCoverage);
	}
	
	public void validateAIANUnderFamilyHHTab(int memNo, String expectedAIAN) throws Exception {
		By aianLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='American Indian/Alaska Native']]/span[2]");
		validateTextContains(" American Indian/Alaska NativeForMem" + memNo, aianLabel, expectedAIAN);
	}
	
	public void validateReasonableAccommodationsUnderFamilyHHTab(int memNo, String expectedAIAN) throws Exception {
		By aianLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Reasonable Accommodations ']]/span[2]");
		validateTextContains("ReasonableAccommodationsForMem" + memNo, aianLabel, expectedAIAN);
	}
	
	public void validateConditionsUnderFamilyHHTab(int memNo, String expectedCondition) throws Exception {
		By conditionLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Condition(s)']]/span[2]");
		validateTextContains("ConditionForMem" + memNo, conditionLabel, expectedCondition);
	}
	
	public void validateAccommodationUnderFamilyHHTab(int memNo, String expectedAccommodation) throws Exception {
		By accommodationLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Accommodation(s)']]/span[2]");
		validateTextContains("AccommodationForMem" + memNo, accommodationLabel, expectedAccommodation);
	}
	
	public void validateIntendToResideUnderFamilyHHTab(int memNo, String expectedIntendToReside) throws Exception {
		By intendToResideLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Intend To Reside']]/span[2]");
		validateTextContains("IntendToResideForMem" + memNo, intendToResideLabel, expectedIntendToReside);
	}
	
	public void validateIncarceratedUnderFamilyHHTab(int memNo, String expectedIncarcerated) throws Exception {
		By incarceratedLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Incarcerated']]/span[2]");
		validateTextContains("IncarceratedForMem" + memNo, incarceratedLabel, expectedIncarcerated);
	}
	
	public void validateImmigrationStatusUnderFamilyHHTab(int memNo, String expectedImmigrationStatus) throws Exception {
		By immigrationStatusLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Immigration status ']]/span[2]");
		validateTextContains("ImmigrationStatusForMem" + memNo, immigrationStatusLabel, expectedImmigrationStatus);
	}
	
	public String getSSNForMember(int memNo) throws Exception {
		By ssnForMember = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul["+memNo+"]/li[span[text()='Social Security Number']]/span[2]");
		return getElementText("SSNForMem"+memNo, ssnForMember);
	}
	//
	// ####################  Validation For Family HH Info Tab END ############################
	
	// ####################  Validation For Tax Filing Tab START ############################
	//
	public void validateStatusForTaxFilerUnderTaxFilingTab(int memNo, String expectedTaxStatus) throws Exception {
		By taxStatusLabel = By.xpath("//div[span[text()='Tax Filing Status']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Status ']]/span[2]");
		validateTextContains("StatusForMem" + memNo, taxStatusLabel, expectedTaxStatus);
	}

	public void validateFiledTaxesANDReconciledAllPastAPTCsForTaxFilerUnderTaxFilingTab(int memNo,
			String expectedAPTCStatus) throws Exception {
		By aptcStatusLabel = By.xpath("//div[span[text()='Tax Filing Status']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Filed taxes and reconciled all past APTCs? ']]/span[2]");
		validateTextContains("Filed taxes and reconciled all past APTCs?ForMem" + memNo, aptcStatusLabel,
				expectedAPTCStatus);
	}

	public void validateAttestationDateForTaxFilerUnderTaxFilingTab(int memNo, String expectedattestationDate)
			throws Exception {
		By attestationDateLabel = By.xpath("//div[span[text()='Tax Filing Status']]/following-sibling::div[1]//ul["
				+ memNo + "]/li[span[text()='Attestation Date  ']]/span[2]");
		validateTextContains("Attestation DateForMem" + memNo, attestationDateLabel, expectedattestationDate);
	}

	public void validateStatusForTaxDepedentUnderTaxFilingTab(int memNo, String expectedStatus) throws Exception {
		By statusLabel = By.xpath("//div[span[text()='Tax Filing Status']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Status ']]/span[2]");
		validateTextContains("StatusForMem" + memNo, statusLabel, expectedStatus);
	}
	
	// ####################  Validation For Family Income Tab END ############################
	//
	
	
	
	
	//
	// ####################  Validation For Family Income END ############################
	
	
	public void validateIncomeTypeUnderFamilyIncomeTab(int memNo, String expectedIncomeType) throws Exception {
		By incomeTypeLabel = By.xpath("//div[span[text()='Family Income']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Income Type']]/span[2]");
		validateTextContains("IncomeTypeForMem" + memNo, incomeTypeLabel, expectedIncomeType);
	}
	
	public void validateProjectedIncomeUnderFamilyIncomeTab(int memNo, String expectedProjectedIncome) throws Exception {
		By projectedIncomeLabel = By.xpath("//div[span[text()='Family Income']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()=' Projected Yearly Income ']]/span[2]");
		validateTextContains("ProjectedYearlyIncomeForMem" + memNo, projectedIncomeLabel, expectedProjectedIncome);
	}
	
	public void validateSelfAttestedTotalAmountReceivedMonthlyUnderFamilyIncomeTab(int memNo, String expectedSelfAttestedIncome) throws Exception {
		By selfAttestedIncomeLabel = By.xpath("//div[span[text()='Family Income']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Self Attested Total Amount Received Monthly ']]/span[2]");
		validateTextContains("SelfAttestedTotalAmountReceivedMonthlyForMem" + memNo, selfAttestedIncomeLabel, expectedSelfAttestedIncome);
	}
	
	public void validateMH_FPLBasedOnIncomeUnderFamilyIncomeTab(int memNo, String expectedMHFPL) throws Exception {
		By MHfplLabel = By.xpath("//div[span[text()='Family Income']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()=' MassHealth Federal Poverty Level (FPL) based on your self-reported income']]/span[2]");
		validateTextContains("MH FPLbased on self-reported incomeForMem" + memNo, MHfplLabel, expectedMHFPL);
	}
	
	public void validateMH_FPLtoDecideProgramEligibiltyUnderFamilyIncomeTab(int memNo, String expectedMHFPLEligibility) throws Exception {
		By expectedMHFPLEligibilityLabel = By.xpath("//div[span[text()='Family Income']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()=' MassHealth Federal Poverty Level (FPL) used to decide your Program Eligibility ']]/span[2]");
		validateTextContains("MH FPLbased on self-reported incomeForMem" + memNo, expectedMHFPLEligibilityLabel, expectedMHFPLEligibility);
	}
	
	//
	// ####################  Validation For Tax Filing Tab END ############################
	
	
	// ####################  Validation For MEC Used In PD Tab END ############################
	//
	
	public void validateFederalMECUnderMECUsedInPDTab(int memNo, String expectedFederalMEC) throws Exception {
		By FederalMECLabel = By.xpath("//div[span[text()='Tax Filing Status']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Has Federal MEC']]/span[2]");
		validateTextContains("FederalMECForMem" + memNo, FederalMECLabel, expectedFederalMEC);
	}
	
	public void validateFederalMECTypeUnderMECUsedInPDTab(int memNo, String expectedFederalMEC) throws Exception {
		By FederalMECLabel = By.xpath("//div[span[text()='Tax Filing Status']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Federal MEC Type']]/span[2]");
		validateTextContains("FederalMECTypeForMem" + memNo, FederalMECLabel, expectedFederalMEC);
	}

	public void validateMMISMECForUnderMECUsedInPDTab(int memNo, String expectedMMISMEC) throws Exception {
		By MMISMECLabel = By.xpath("//div[span[text()='Tax Filing Status']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Has MMIS MEC']]/span[2]");
		validateTextContains("MMISMECForMem" + memNo, MMISMECLabel, expectedMMISMEC);
	}
	
	
	
	//
	// ####################  Validation For  MEC Used In PD Tab END ############################
	
	public void takeScreenShot() throws Exception {
		takeScreenshot("EleigibilityDetailsPage");
	}
	
	// ####################  Page Load and Click On TAB START ############################
	//
	public void pageLoadAndClickOnFamilyHHTab() throws Exception {
		waitForPageLoaded();
		clickOnFamilyHHTab();
	}
	
	public void pageLoadAndClickOnContactInformationTab() throws Exception {
		waitForPageLoaded();
		clickOnContactInformationTab();
	}
	
	//TODO: For other 4 TAB
	//
	// ####################  Page Load and Click On TAB END ############################
}
