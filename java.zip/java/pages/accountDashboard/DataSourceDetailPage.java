package pages.accountDashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;

/**
 *  This Page Appears when we click on View All link on Account Dashboard Page
 * @author Ritu Negi
 *
 */
public class DataSourceDetailPage extends CommonPage {
	
	private static final By dataSourceDetailPageHeader = By.xpath("//h1[contains(.,'Data Source Details')]");
	
		
	
	public DataSourceDetailPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("DataSourceDetailPageHeader",  dataSourceDetailPageHeader,5);
	}
	

    public void takeScreenshot() throws Exception{
    	waitForPageLoaded();
		takeScreenshot("EligibilitiesPage");
	}
	
	
	
	
}
