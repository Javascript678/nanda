package pages.accountDashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;

public class EligibilityDetailsTaxHHSummary extends CommonPage
{
	public EligibilityDetailsTaxHHSummary(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void takeScreenshot() throws Exception{
        takeScreenshot("EligibilityDetailsTaxHHSummary");
	}

	public void clickOnDropDown(String name) throws Exception {
		By clickOnDropDown = By.xpath("//*[@id='accordionMemElgRslt']/div[span[contains(text(),'"+name+"')]]/span[1]");
		waitForPresenceOfElementLocatedThenWait("MemberData", clickOnDropDown ,5);
		clickOnElement("MemberData", clickOnDropDown);
	}

	public void clickOnTaxHH_SummaryTab() throws Exception {
		By taxHHsummaryTab = By.xpath("//button[contains(text(),'Tax Household Summary')]");
		clickOnElement("Tax HouseHold Summary", taxHHsummaryTab);
	}
	
	
	public void validateFPLBasedOnSelfReportedIncome(String hhName, String expectedFpl) throws Exception {
		By fplLabel = By.xpath("//*[@id='accordionMemElgRslt']/div[span[contains(text(),'"+hhName+"')]]//following-sibling::div/div/ul/li[span[contains(text(),'Federal Poverty Level (FPL) based on your self-reported income')]]/span[3]");
		validateTextContains("FPL Based On Self Reported Income For"+hhName, fplLabel, expectedFpl);
	}
	
	public void validateFPLUsedToDecYourProg(String hhName,String expectedFpl) throws Exception {
		By fplLabel = By.xpath("//*[@id='accordionMemElgRslt']/div[span[contains(text(),'"+hhName+"')]]//following-sibling::div/div/ul/li[span[contains(text(),'Federal Poverty Level (FPL) used to decide your Program Eligibility')]]/span[2]");
		validateTextContains("FPL Used To Decide Your Program"+hhName, fplLabel, expectedFpl);
	}
	
	public void validateProgEligibility(String hhName,int memNo,String expectedProgramEligibility) throws Exception {
		By progEligibilityLabel = By.xpath("//*[@id='accordionMemElgRslt']/div[span[contains(text(),'"+hhName+"')]]//following-sibling::div/div/div[table/caption[contains(text(),'Program Eligibility')]]/table/tbody["+memNo+"]/tr/td/div/p/span");
		validateTextContains("Program Eligibility For"+hhName+"member"+memNo, progEligibilityLabel, expectedProgramEligibility);
	}
	
	public void validateRFI(String hhName,int memNo,String expectedRFI) throws Exception {
		By rfiLabel = By.xpath("//*[@id='accordionMemElgRslt']/div[span[contains(text(),'"+hhName+"')]]//following-sibling::div/div/div[table/caption[contains(text(),'Program Eligibility')]]/table/tbody["+memNo+"]/tr/td[2]/div");
		validateTextContains("RFI For"+hhName+"member"+memNo, rfiLabel, expectedRFI);
	}
	
	public void validateRFIStatus(String hhName,int memNo,String expectedStatus) throws Exception {
		By rfiStatusLabel = By.xpath("//*[@id='accordionMemElgRslt']/div[span[contains(text(),'"+hhName+"')]]//following-sibling::div/div/div[table/caption[contains(text(),'Program Eligibility')]]/table/tbody["+memNo+"]/tr/td[3]");
		validateTextContains("RFI Status For"+hhName+"member"+memNo, rfiStatusLabel, expectedStatus);
	}
}
