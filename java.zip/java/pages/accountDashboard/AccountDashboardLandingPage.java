package pages.accountDashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Ritu Negi
 *
 */
public class AccountDashboardLandingPage extends CommonPage implements CommonPageOR {
	
	private static final By accountDashboardPageHeader = By.id("srAppDetails");
	private static final By emailTxt = By.xpath("//div[@id='userProfileLeftNav']//li[span[contains(.,'Email Address')]]/div/span");
		
	private LeftMenu leftMenu = new LeftMenu();
	private RFILink rfiLink	= new RFILink();
	
	public AccountDashboardLandingPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("AccountDashboardPageHeader", accountDashboardPageHeader,5);
	}
	
	public void takeScreenshot() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Summary");
	}
	
	public void validateAidCatForMember(int memIndex, String aidCat) throws Exception{
		By row1Label = By.xpath("//table[@id='currentElgTable']/tbody["+(memIndex+1)+"]/tr[1]/th[@class='egnPlan']//span[@class='fullEllipsis']");
		By row2Label = By.xpath("//table[@id='currentElgTable']/tbody["+(memIndex+1)+"]/tr[2]/th[@class='egnPlan']//span[@class='fullEllipsis']");
		if(isElementPresent(row2Label)){
			validateTextContains("AidCatForMem"+(memIndex+1), row2Label, aidCat);
		}else{
			validateTextContains("AidCatForMem"+(memIndex+1), row1Label, aidCat);
		}
		
	}
	
	public void goToLatestEligibilityViewAll() throws Exception{
		By latestEligibilityViewAllLink = By.xpath("//h3[text()='Latest Eligibility']/../a");
		clickOnElement("LatestElgViewAllLink", latestEligibilityViewAllLink);
	}
	
	public void goToLatestEnrollmentViewAll() throws Exception{
		By latestEnrollmentViewAllLink = By.xpath("//h3[text()='Latest Enrollment']/../a");
		clickOnElement("LatestEnrollmentViewAllLink", latestEnrollmentViewAllLink);
	}
		
	
	private class LeftMenu{
		
		private final By leftMenuSlider = By.id("dashboardLeftmenuSlider");
		private final By viewUnlockEligibilityBtn	= By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'View / Unlock Eligibility')]");
		private final By addressChangeBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Address Change')]");
		private final By updateSSNBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Update SSN')]");
		private final By disabilityInfoBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Disability Information')]");
		private final By medicallyFrailInfoBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Medically Frail Information')]");
		private final By manageAuthorizedRepresentativeBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Manage Authorized Representative')]");
		private final By administrativeClosureBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Administrative Closure' )]");
		private final By administrativeClosingHistoryBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Administrative Closing History' )]");
		private final By sepDocumentVerficationBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'SEP Document Verification' )]");
		private final By overrideEligibilityBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Override Eligibility' )]");
		private final By vlpDetailsBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'VLP Details' )]");
		private final By applicationLevelDupDashboardBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Application-Level Duplicate Dashboard' )]");
		private final By manualIDProofingBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Manual ID Proofing' )]");
		private final By assisterBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Assister' )]");
		private final By inviteClientBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Invite Client')]");
		private final By transactionHistoryBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Transaction History' )]");
		//Added by Amrita
		private final By medicaidRenewalsBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Medicaid Renewals' )]");
		private final By enrollmentsBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Enrollments' )]");
		private final By retroactiveEnrollmentBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Retroactive Enrollment' )]");
		private final By adminSEPDetailsBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Admin SEP Details' )]");
		private final By certificateofHardshipExemptionsBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Certificate of Hardship Exemptions' )]");
		private final By appealsBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'Appeals' )]");
		private final By viewIRSAuthorizationBtn =By.xpath("//div[@id='leftMenuDiv']//ul/li//span[contains(text(),'View IRS Authorization' )]");
		
		private void clickOnLeftMenuSlider() throws Exception{
			clickOnElement("LeftMenuSlider",leftMenuSlider);
		}
		
		private void clickOnViewUnlockEligibilityBtn() throws Exception{
			clickOnElement("ViewUnlockEligibilityBtn",viewUnlockEligibilityBtn);
		}
		
		private void clickOnAddressChangeBtn() throws Exception{
			clickOnElement("AddressChangeBtn",addressChangeBtn);
		}
		
		private void clickOnUpdateSSNBtn() throws Exception{
			clickOnElement("UpdateSSNBtn",updateSSNBtn);
		}
		private void clickOnDisabilityInfoBtn() throws Exception{
			clickOnElement("DisabilityInfoBtn",disabilityInfoBtn);
		}
		private void clickOnMedicallyFrailInfoBtn() throws Exception{
			clickOnElement("MedicallyFrailInfoBtn",medicallyFrailInfoBtn);
		}
		private void clickOnManageAuthorizedRepresentativeBtn() throws Exception{
			clickOnElement("ManageAuthorizedRepresentativeBtn",manageAuthorizedRepresentativeBtn);
		}
		private void clickOnAdministrativeClosureBtn() throws Exception{
			clickOnElement("AdministrativeClosureBtn",administrativeClosureBtn);
		}
		private void clickOnAdministrativeClosingHistoryBtn() throws Exception{
			clickOnElement("AdministrativeClosingHistoryBtn",administrativeClosingHistoryBtn);
		}
		private void clickOnSEPDocumentVerficationBtn() throws Exception{
			clickOnElement("SEPDocumentVerficationBtn",sepDocumentVerficationBtn);
		}
		private void clickOnOverrideEligibilityBtn() throws Exception{
			clickOnElement("OverrideEligibilityBtn",overrideEligibilityBtn);
		}
		private void clickOnVLPDetailsBtn() throws Exception{
			clickOnElement("VLPDetailsBtn",vlpDetailsBtn);
		}
		private void clickOnApplicationLevelDupDashboardBtn() throws Exception{
			clickOnElement("ApplicationLevelDuplicateDashboardBtn",applicationLevelDupDashboardBtn);
		}
		private void clickOnManualIDProofingBtn() throws Exception{
			clickOnElement("ManualIDProofingBtn",manualIDProofingBtn);
		}
		private void clickOnAssisterBtn() throws Exception{
			clickOnElement("AssisterBtn",assisterBtn);
		}
		private void clickOnInviteClientBtn() throws Exception{
			clickOnElement("InviteClientBtn",inviteClientBtn);
		}
		private void clickOnTransactionHistoryBtn() throws Exception{
			clickOnElement("TransactionHistoryBtn",transactionHistoryBtn);
		}
		//Added by Amrita
		private void clickOnMedicaidRenewalsBtn() throws Exception{
			clickOnElement("MedicaidRenewalsBtn",medicaidRenewalsBtn);
		}		
		private void clickOnEnrollmentsBtn() throws Exception{
			clickOnElement("EnrollmentsBtn",enrollmentsBtn);
		}
		private void clickOnRetroactiveEnrollmentBtn() throws Exception{
			clickOnElement("RetroactiveEnrollmentBtn",retroactiveEnrollmentBtn);
		}
		private void clickOnAdminSEPDetailsBtn() throws Exception{
			clickOnElement("AdminSEPDetailsBtn",adminSEPDetailsBtn);
		}
		private void clickOnAppealsBtn() throws Exception{
			clickOnElement("AppealsBtn",appealsBtn);
		}
		private void clickOnCertificateofHardshipExemptionsBtn() throws Exception{
			clickOnElement("CertificateofHardshipExemptionsBtn",certificateofHardshipExemptionsBtn);
		}
		private void clickOnViewIRSAuthorizationBtn() throws Exception{
			clickOnElement("ViewIRSAuthorizationBtn",viewIRSAuthorizationBtn);
		}
	}
	
	private class RFILink{
		private final By active = By.xpath("//a[contains(@onclick, 'BO.Dashboard.navigateToRFIScreen')]//ul/li[contains(text()[normalize-space()],'Active')]");
		private final By inactive = By.xpath("//a[contains(@onclick, 'BO.Dashboard.navigateToRFIScreen')]//ul/li[contains(text()[normalize-space()],'Inactive')]");
		private final By expired = By.xpath("//a[contains(@onclick, 'BO.Dashboard.navigateToRFIScreen')]//ul/li[contains(text()[normalize-space()],'Expired')]");
		private final By verified = By.xpath("//a[contains(@onclick, 'BO.Dashboard.navigateToRFIScreen')]//ul/li[contains(text()[normalize-space()],'Verified')]");
		
		private void clickOnActive() throws Exception{
			clickOnElement("ActiveRFILink",active);
		}
		private void clickOnInactive() throws Exception{
			clickOnElement("InactiveRFILink",inactive);
		}
		private void clickOnExpired() throws Exception{
			clickOnElement("ExpiredRFILink",expired);
		}
		private void clickOnVerified() throws Exception{
			clickOnElement("VerifiedRFILink",verified);
		}
	}
	
	
	public void usingLeftMenuClickOnViewUnlockEligibility() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnViewUnlockEligibilityBtn();
	}
	
	public void usingLeftMenuClickOnUpdateSSN() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnUpdateSSNBtn();
	}
	
	public void usingLeftMenuClickOnAdminClosure() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnAdministrativeClosureBtn();
	}
	
	public void usingLeftMenuClickOnAddressChange() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnAddressChangeBtn();   
		
	}
	public void usingLeftMenuClickOnDisabilityInfo() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnDisabilityInfoBtn(); 
		
	}
	public void usingLeftMenuClickOnMedicallyFrailInfo() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnMedicallyFrailInfoBtn(); 
		
	}
	public void usingLeftMenuClickOnManageAuthorizedRepresentative() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnManageAuthorizedRepresentativeBtn(); 
		
	}
	
	
	public void usingLeftMenuClickOnAdministrativeClosingHistory() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnAdministrativeClosingHistoryBtn(); 
		
	}
	
	public void usingLeftMenuClickOnSEPDocumentVerfication() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnSEPDocumentVerficationBtn(); 
		
	}
	
	public void usingLeftMenuClickOnOverrideEligibility() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnOverrideEligibilityBtn(); 
		
	}
	
	public void usingLeftMenuClickOnVLPDetails() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnVLPDetailsBtn(); 
		
	}
	
	public void usingLeftMenuClickOnApplicationLevelDupDashboard() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnApplicationLevelDupDashboardBtn(); 
		
	}
	
	
	public void usingLeftMenuClickOnManualIDProofing() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnManualIDProofingBtn(); 
		
	}
	public void usingLeftMenuClickOnAssister() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnAssisterBtn(); 
		
	}
	public void usingLeftMenuClickOnInviteClient() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnInviteClientBtn(); 
	}
	//Added by Amrita
	public void usingLeftMenuClickOnMedicaidRenewals() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnMedicaidRenewalsBtn();
		
	}
	public void usingLeftMenuClickOnTransactionHistory() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnTransactionHistoryBtn(); 
		
	}
	public void usingLeftMenuClickOnEnrollments() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnEnrollmentsBtn(); 
		
	}
	
	public void usingLeftMenuClickOnRetroactiveEnrollment() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnRetroactiveEnrollmentBtn(); 
		
	}
	public void usingLeftMenuClickOnAdminSEPDetails() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnAdminSEPDetailsBtn(); 
		
	}
	public void usingLeftMenuClickOnAppeals() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnAppealsBtn(); 
		
	}
	public void usingLeftMenuClickOnCertificateofHardshipExemptions() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnCertificateofHardshipExemptionsBtn(); 
		
	}
	public void usingLeftMenuClickOnViewIRSAuthorization() throws Exception{
		//waitForPageLoaded();
		leftMenu.clickOnLeftMenuSlider();
		leftMenu.clickOnViewIRSAuthorizationBtn(); 
		
	}
	

	// ppinho
	public boolean isWarningDialogPresent() throws Exception{
		return isElementPresent(warningOkButton);
	}
	
	// ppinho
	public void clickOnWarningOkButton() throws Exception{
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}
	
	// ppinho
	public void handleAlertDialogIfPresent() throws Exception{
		if(isWarningDialogPresent()){
			clickOnWarningOkButton();
		}		
	}

	// ppinho
	public  String getLatestEmail() throws Exception {
        return getElementText(emailTxt);
    }
	
	public void pageLoadAndClickOnActiveRFILink() throws Exception{
		waitForPageLoaded();
		rfiLink.clickOnActive();
	}
	
	public void pageLoadAndClickOnInActiveRFILink() throws Exception{
		waitForPageLoaded();
		rfiLink.clickOnInactive();
	}
	
	public void pageLoadAndClickOnExpiredFILink() throws Exception{
		waitForPageLoaded();
		rfiLink.clickOnExpired();
	}
	
	public void pageLoadAndClickOnVerifiedRFILink() throws Exception{
		waitForPageLoaded();
		rfiLink.clickOnVerified();
	}
	
	public void pageLoadAndGoToLatestEligibilityViewAll() throws Exception{
		waitForPageLoaded();
		goToLatestEligibilityViewAll();
	}
	
	public void pageLoadAndGoToLatestEnrollmentViewAll() throws Exception{
		waitForPageLoaded();
		goToLatestEnrollmentViewAll();
	}
	
	//Shailza
    public void goToInProgressApplication() throws Exception{
          By inProgressApplication = By.xpath(".//*[@id='appStatusSecs']/a");
          clickOnElement("InProgressApplicationLink", inProgressApplication);
    }

		
}
