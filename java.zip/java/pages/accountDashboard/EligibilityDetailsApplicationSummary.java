package pages.accountDashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;

/**
 *  This Page Appears when we click on View Details link on Eligibilities Page
 * @author Vinay Kumar
 *
 */
public class EligibilityDetailsApplicationSummary extends CommonPage {
	
	private static final By eligibilitiesPageHeader = By.xpath("//h1/strong[text()='Eligibility Details']");
	
		
	
	public EligibilityDetailsApplicationSummary(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("EligibilyDetailsPgHdr", eligibilitiesPageHeader,5);
	}
	
	public void takeScreenshot() throws Exception{
		waitForPageLoaded();
        takeScreenshot("EligibilityDetailsApplicationSummary");
	}
	
	// ####################  Click On TAB START ############################
	//
	public void clickOnFamilyHHTab() throws Exception {
		By familyHHTab = By.xpath("//span[text()='Family & Household']");
		clickOnElement("FamilyHHTab", familyHHTab);
	}
	
	public void clickOnContactInformationTab() throws Exception {
		By contactInformationTab = By.xpath("//span[text()='Contact Information']");
		clickOnElement("ContactInformationTab", contactInformationTab);
	}
	
	public void clickOnTaxFilingStatusTab() throws Exception {
		By taxFilingStatusTab = By.xpath("//span[text()='Tax Filing Status']");
		clickOnElement("TaxFiling StatusTab", taxFilingStatusTab);
	}
	
	public void clickOnFamilyIncomeTab() throws Exception {
		By familyIncomesTab = By.xpath("//span[text()='Family Income']");
		clickOnElement("Family Income Tab", familyIncomesTab);
	}
	
	public void clickOnAdditionalInformationTab() throws Exception {
		By additionalInformationTab = By.xpath("//span[text()='Additional Information']");
		clickOnElement("Family Income Tab", additionalInformationTab);
	}

	public void clickOnMECUsedInPDTab() throws Exception {
		By mecUsedInPDTab = By.xpath("//span[text()='MEC Used In PD']");
		clickOnElement("Family Income Tab", mecUsedInPDTab);
	}
	

	public void clickOnDropDown() throws Exception {
	{
		By firstNameTab = By.xpath("//span[text()='Family & Household']");
			clickOnElement("FamilyHHTab", firstNameTab);
		}
	}

	
	public void pageLoadAndClickOnFamilyHHTab() throws Exception {
		waitForPageLoaded();
		clickOnFamilyHHTab();
	}
	
	public void pageLoadAndClickOnContactInformationTab() throws Exception {
		waitForPageLoaded();
		clickOnContactInformationTab();
	}
	
	public void pageLoadAndClickOnTaxFilingStatusTab() throws Exception {
		waitForPageLoaded();
		clickOnTaxFilingStatusTab();
	}
	
	public void pageLoadAndClickOnFamilyIncomeTab() throws Exception {
		waitForPageLoaded();
		clickOnFamilyIncomeTab();
	}
	//TODO : For Other 4 Tab
	//
	// ####################  Click On TAB END ############################
	
	// ####################  Validation For Contact Info Tab START ############################
	////Anubhuti
	public void validateContactAddressUnderContactInfoTab(String expectedContactAddr) throws Exception {
		By contactaddressLabel = By.xpath(
				"//div[span[text()='Contact Information']]/following-sibling::div//ul/li[span[text()='Address']]/span[2]");
		validateTextContains("ContactAddress", contactaddressLabel, expectedContactAddr);

	}

	public void validateEmailUnderContactInfoTab(String expectedEmail) throws Exception {
		By emailLabel = By.xpath(
				"//div[span[text()='Contact Information']]/following-sibling::div//ul/li[span[text()='Email']]/span[2]");
		validateTextContains("ContactEmail", emailLabel, expectedEmail);
	}

	public void validatePhoneUnderContactInfoTab(String expectedPhone) throws Exception {
		By phoneLabel = By.xpath(
				"//div[span[text()='Contact Information']]/following-sibling::div//ul/li[span[text()='Phone']]");
		validateTextContains("ContactPhone", phoneLabel, expectedPhone);
	}
	//
	// ####################  Validation For Contact Info Tab END ############################
	
	// ####################  Validation For Family HH Info Tab START ############################
	//
	public void validateSSNUnderFamilyHHTab(int memNo, String expectedSSN) throws Exception {
		By ssnForMember = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo+ "]/li[span[text()='Social Security Number']]/span[2]");
		String actualText = getElementText(ssnForMember);
		int lastIndex = actualText.lastIndexOf("-");
		actualText = actualText.substring(lastIndex+1);
		
		validateTextContains("SSNForMem" + memNo, actualText, expectedSSN);
	}
	public void validateApplyingForCoverageUnderFamilyHHTab(int memNo, String expectedCoverage) throws Exception {
		By coverageLabel = By.xpath(
				"//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[1]/li[span[text()='Applying for coverage']]/span[2]");
		validateTextContains("ApplyingForCoverageForMem"+memNo, coverageLabel, expectedCoverage);
	}

	public void validateHHAddressUnderFamilyHHTab(int memNo, String expectedAddress) throws Exception {
		By hhAddressLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Address']]//span[@class='fullEllipsis']/span/span");
		validateTextContains("AddressForMem"+memNo, hhAddressLabel, expectedAddress);
	}

	public void validateMemberAddressUnderFamilyHHTab(int memNo, String expectedMemAddress) throws Exception {
		By memAddressLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Address']]/span[2]");
		validateTextContains("AddressForMem" + memNo, memAddressLabel, expectedMemAddress);
	}

	public void validateDateOfBirthUnderFamilyHHTab(int memNo, String expectedCoverage) throws Exception {
		By dobLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Date of Birth']]/span[2]");
		validateTextContains("DOBForMem" + memNo, dobLabel, expectedCoverage);
	}

	public void validateCitizenShipUnderFamilyHHTab(int memNo, String expectedCoverage) throws Exception {
		By citizenShipLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Citizenship ']]/span[2]");
		validateTextContains("CitizenshipForMem" + memNo, citizenShipLabel, expectedCoverage);
	}
	
	public void validateAIANUnderFamilyHHTab(int memNo, String expectedAIAN) throws Exception {
		By aianLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='American Indian/Alaska Native']]/span[2]");
		validateTextContains(" American Indian/Alaska NativeForMem" + memNo, aianLabel, expectedAIAN);
	}
	
	public void validateReasonableAccommodationsUnderFamilyHHTab(int memNo, String expectedAIAN) throws Exception {
		By aianLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Reasonable Accommodations ']]/span[2]");
		validateTextContains("ReasonableAccommodationsForMem" + memNo, aianLabel, expectedAIAN);
	}
	
	public void validateConditionsUnderFamilyHHTab(int memNo, String expectedCondition) throws Exception {
		By conditionLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Condition(s)']]/span[2]");
		validateTextContains("ConditionForMem" + memNo, conditionLabel, expectedCondition);
	}
	
	public void validateAccommodationUnderFamilyHHTab(int memNo, String expectedAccommodation) throws Exception {
		By accommodationLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Accommodation(s)']]/span[2]");
		validateTextContains("AccommodationForMem" + memNo, accommodationLabel, expectedAccommodation);
	}
	
	public void validateIntendToResideUnderFamilyHHTab(int memNo, String expectedIntendToReside) throws Exception {
		By intendToResideLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Intend To Reside']]/span[2]");
		validateTextContains("IntendToResideForMem" + memNo, intendToResideLabel, expectedIntendToReside);
	}
	
	public void validateIncarceratedUnderFamilyHHTab(int memNo, String expectedIncarcerated) throws Exception {
		By incarceratedLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Incarcerated']]/span[2]");
		validateTextContains("IncarceratedForMem" + memNo, incarceratedLabel, expectedIncarcerated);
	}
	
	public void validateImmigrationStatusUnderFamilyHHTab(int memNo, String expectedImmigrationStatus) throws Exception {
		By immigrationStatusLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Immigration status ']]/span[2]");
		validateTextContains("ImmigrationStatusForMem" + memNo, immigrationStatusLabel, expectedImmigrationStatus);
	}
	
	public String getSSNForMember(int memNo) throws Exception {
		By ssnForMember = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul["+memNo+"]/li[span[text()='Social Security Number']]/span[2]");
		return getElementText("SSNForMem"+memNo, ssnForMember);
	}
	
	public void validateRelationShipTo(int memNo,String expectedRelationship) throws Exception
	{
		By relationshipToLabel = By.xpath("//div[span[text()='Family & Household']]/following-sibling::div[1]//ul["+memNo+"]/li[3]/span");
		validateTextContains("RelationShip" + memNo, relationshipToLabel, expectedRelationship);
	}
	//
	// ####################  Validation For Family HH Info Tab END ############################
	
	
	
	
	// ####################  Validation For Tax Filing Tab START ############################
	//
	public void validateStatusUnderTaxFilingTab(int memNo, String expectedTaxStatus) throws Exception {
		By taxStatusLabel = By.xpath("//div[span[text()='Tax Filing Status']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Status ']]/span[2]");
		validateTextContains("StatusForMem" + memNo, taxStatusLabel, expectedTaxStatus);
	}

	public void validateFiledTaxesANDReconciledAllPastAPTCsUnderTaxFilingTab(int memNo,
			String expectedAPTCStatus) throws Exception {
		By aptcStatusLabel = By.xpath("//div[span[text()='Tax Filing Status']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Filed taxes and reconciled all past APTCs? ']]/span[2]");
		validateTextContains("Filed taxes and reconciled all past APTCs?ForMem" + memNo, aptcStatusLabel,
				expectedAPTCStatus);
	}

	public void validateAttestationDateUnderTaxFilingTab(int memNo, String expectedattestationDate)
			throws Exception {
		By attestationDateLabel = By.xpath("//div[span[text()='Tax Filing Status']]/following-sibling::div[1]//ul["
				+ memNo + "]/li[span[text()='Attestation Date  ']]/span[2]");
		validateTextContains("Attestation DateForMem" + memNo, attestationDateLabel, expectedattestationDate);
	}

	// ####################  Validation For Tax Filing Tab END ############################
	//
	
	
	//
	// ####################  Validation For Family Income START ############################
	
	
	public void validateIncomeTypeUnderFamilyIncomeTab(int memNo, String expectedIncomeType) throws Exception {
		By incomeTypeLabel = By.xpath("//div[span[text()='Family Income']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[contains(text(),'Income Type')]]/span[2]");
		validateTextContains("IncomeTypeForMem" + memNo, incomeTypeLabel, expectedIncomeType);
	}
	
	public void validateProjectedIncomeUnderFamilyIncomeTab(int memNo, String expectedProjectedIncome) throws Exception {
		By projectedIncomeLabel = By.xpath("//div[span[text()='Family Income']]/following-sibling::div//ul[" + memNo
				+ "]/li[span[contains(text(),'Projected Yearly Income')]]/span[2]");
		validateTextContains("ProjectedYearlyIncomeForMem" + memNo, projectedIncomeLabel, expectedProjectedIncome);
	}
	
	public void validateSelfAttestedTotalAmountReceivedMonthlyUnderFamilyIncomeTab(int memNo, String expectedSelfAttestedIncome) throws Exception {
		
		By selfAttestedIncomePremiumInt = By.xpath("//div[span[text()='Family Income']]/following-sibling::div[1]//ul[" + memNo+ "]/li[span[text()='Self Attested Total Amount Received Monthly ']]/span[2]/span[1]");
		
		String premiumInt = getElementText(selfAttestedIncomePremiumInt);
		
		String[] amtArray = premiumInt.split(",");
		
		String concAmt = "";
		
		for(int i=0; i<amtArray.length; i++)
		{
			concAmt = concAmt+amtArray[i];
		}
		
		By selfAttestedIncomePremiumDecimal = By.xpath("//div[span[text()='Family Income']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Self Attested Total Amount Received Monthly ']]/span[2]/sup");
		
		
		String premiumDec = getElementText(selfAttestedIncomePremiumDecimal);
		
		String finalText = "$"+concAmt+"."+premiumDec;
		
		validateTextContains("SelfAttestedTotalAmountReceivedMonthlyForMem" + memNo, finalText, expectedSelfAttestedIncome);
	}
	
	public void validateMH_FPLBasedOnIncomeUnderFamilyIncomeTab(int memNo, String expectedMHFPL) throws Exception {
		By mhfplLabel = By.xpath("//div[span[text()='Family Income']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[contains(text(),'MassHealth Federal Poverty Level (FPL) based on your self-reported income')]]/span[3]");
		validateTextContains("MH FPL based on self-reported incomeForMem" + memNo, mhfplLabel, expectedMHFPL);
	}
	
	public void validateMH_FPLtoDecideProgramEligibiltyUnderFamilyIncomeTab(int memNo, String expectedMHFPLEligibility) throws Exception {
		By mhfplEligibilityLabel = By.xpath("//div[span[text()='Family Income']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[contains(text(),'MassHealth Federal Poverty Level (FPL) used to decide your Program Eligibility')]]/span[2]");
		validateTextContains("MH FPL used to decide program eligibility ForMem" + memNo, mhfplEligibilityLabel, expectedMHFPLEligibility);
	}
	
	
	//
	// ####################  Validation For Family Income Tab END ############################

	
	// ####################  Validation For Additional Info Tab START ############################
	//
	
	public void validateHas_MECUnderAdditionalInformationTab(int memNo, String expectedMECStatus) throws Exception {
		By mecLabel = By.xpath("//div[span[text()='Additional Information']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Has Minimum Essential Coverage (MEC)']]/span[2]");
		validateTextContains("Has Minimum Essential Coverage (MEC) ForMem" + memNo, mecLabel, expectedMECStatus);
	}
	
	public void validateHasOptionToEnrollEmployerHealthCoverageUnderAdditionalInformationTab(int memNo, String expectedOptionToEnrollhealthCoverage) throws Exception {
		By optionToEnrollhealthCoverageLabel = By.xpath("//div[span[text()='Additional Information']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Has Option to Enroll in Employer Health Coverage']]/span[2]");
		validateTextContains("Has Option to Enroll in Employer Health Coverage ForMem" + memNo, optionToEnrollhealthCoverageLabel, expectedOptionToEnrollhealthCoverage);
	}
	
	public void validateHAS_ESIUnderAdditionalInformationTab(int memNo, String expectedESI) throws Exception {
		By esiLabel = By.xpath("//div[span[text()='Additional Information']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Has Affordable Employer Sponsored Insurance(ESI)']]/span[2]");
		validateTextContains("Has Affordable Employer Sponsored Insurance(ESI) ForMem" + memNo, esiLabel, expectedESI);
	}
	
	
	// ####################  Validation For MEC Used In PD Tab START ############################
	//
	
	public void validateFederalMECUnderMECUsedInPDTab(int memNo, String expectedFederalMEC) throws Exception {
		By FederalMECLabel = By.xpath("//div[span[text()='MEC Used In PD']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Has Federal MEC']]/span[2]");
		validateTextContains("FederalMECForMem" + memNo, FederalMECLabel, expectedFederalMEC);
	}
	
	public void validateFederalMECTypeUnderMECUsedInPDTab(int memNo, String expectedFederalMEC) throws Exception {
		By FederalMECLabel = By.xpath("//div[span[text()='MEC Used In PD']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Federal MEC Type']]/span[2]");
		validateTextContains("FederalMECTypeForMem" + memNo, FederalMECLabel, expectedFederalMEC);
	}

	public void validateMMISMECForUnderMECUsedInPDTab(int memNo, String expectedMMISMEC) throws Exception {
		By MMISMECLabel = By.xpath("//div[span[text()='MEC Used In PD']]/following-sibling::div[1]//ul[" + memNo
				+ "]/li[span[text()='Has MMIS MEC']]/span[2]");
		validateTextContains("MMISMECForMem" + memNo, MMISMECLabel, expectedMMISMEC);
	}
	
	
	
	//
	// ####################  Validation For  MEC Used In PD Tab END ############################
	
	public void takeScreenShot() throws Exception {
		takeScreenshot("EleigibilityDetailsPage");
	}
	
	
	
	//TODO: For other 4 TAB
	//
	// ####################  Page Load and Click On TAB END ############################
}
