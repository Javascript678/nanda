package pages.startApplication;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class IsSomeOneHelpingPage extends CommonPage implements CommonPageOR {
	
	private static final By SomeOneHelpngHeader = By.xpath("//h1[contains(.,'Is someone helping you?')]");
	private static final By someOneHelpngRdBtn = By.name("haveRepresentative");
	
	public IsSomeOneHelpingPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("SomeOneHelpngHeader", SomeOneHelpngHeader);
	}
	
	/*
	 * Accepted value :- true, false
	 */
	private void selectSomeOneHelpingRdBtn(boolean helpNeeded) throws Exception { 
		selectByAttributeNameUsingJS("SomeOneHelpngRdBtn" , someOneHelpngRdBtn,"value",helpNeeded+"");
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void selectIfSomeOneHelping(boolean helpNeeded) throws Exception { 
		waitForPageLoaded();
		selectSomeOneHelpingRdBtn(helpNeeded);
		clickOnSaveAndContinueBtn();
	}
	
	public void PageLoadAndClickOnSaveAndContinueBtn() throws Exception { 
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdSelectIfSomeOneHelping(boolean helpNeeded) throws Exception { 
		selectSomeOneHelpingRdBtn(helpNeeded);
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void racSelectIfSomeOneHelping(boolean helpNeeded) throws Exception { 
		selectSomeOneHelpingRdBtn(helpNeeded);
		clickOnSaveAndContinueBtn();
	}
	
}
