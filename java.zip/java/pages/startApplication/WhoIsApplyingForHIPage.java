package pages.startApplication;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class WhoIsApplyingForHIPage extends CommonPage implements CommonPageOR{
	

	private static final By WhoApplyngHlPageHeader = By.xpath("//h1[contains(text(),'Who is Applying for Health Insurance')]");
	
	public WhoIsApplyingForHIPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("WhoApplyngHlPageHeader", WhoApplyngHlPageHeader);
	}
	
	public void enterMemberFirstName(int memberNo, String firstName) throws Exception{
		By memberFirstNameTxt = By.id("eligibilityMember"+(memberNo-1)+".name.firstName");
		enterText("Member"+memberNo+"FirstNameTxt",  memberFirstNameTxt, firstName);
	}
	
	// added by ppinho
	public void editMemberFirstName(int memberNo, String firstName) throws Exception{
		By memberFirstNameTxt = By.id("eligibilityMember"+(memberNo-1)+".name.firstName");
		clearAndType("Member"+memberNo+"LastNameTxt",  memberFirstNameTxt,  firstName);
	}

	
	/**@author akumari4
	*/
	public void enterMemberMiddleName(int memberNo, String middleName) throws Exception{
		By memberMiddleNameTxt = By.id("eligibilityMember"+(memberNo-1)+".name.middleName");
		enterText("Member"+memberNo+"MiddleNameTxt",  memberMiddleNameTxt, middleName);
	}
	public void enterMemberLastName(int memberNo, String lastName) throws Exception{
		By memberLastNameTxt = By.id("eligibilityMember"+(memberNo-1)+".name.lastName");
		enterText("Member"+memberNo+"LastNameTxt",  memberLastNameTxt,  lastName);
	}
	
	public void editMemberLastName(int memberNo, String lastName) throws Exception{
		By memberLastNameTxt = By.id("eligibilityMember"+(memberNo-1)+".name.lastName");
		clearAndType("Member"+memberNo+"LastNameTxt",  memberLastNameTxt,  lastName);
	}
	
	public void enterMemberSuffix(int memberNo, String suffix) throws Exception{
		By memberSuffixDD = By.id("eligibilityMember"+(memberNo-1)+".name.suffix");								
		enterText("Member"+memberNo+"SuffixDD",  memberSuffixDD,  suffix);
	}
	
	public void enterMemberDOB(int memberNo, String dob) throws Exception{
		
		By memberDOBTxt = By.id("eligibilityMember"+(memberNo-1)+".dateOfBirth");
		clearAndType("Member"+memberNo+"DOBTxt",  memberDOBTxt,  dob);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}

	public void pageLoadAndClickOnSaveAndContinue() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void provideMemberDetail(int memberNo, String firstName, String lastName, String dob ) throws Exception{
			enterMemberFirstName(memberNo, firstName);
			enterMemberLastName(memberNo, lastName);
			//enterMemberSuffix(memberNoInRepository, suffix);
			enterMemberDOB(memberNo, dob);
	}
	
	public void provideMemberDetail(int memberNo, String firstName, String middleName, String lastName, String dob ) throws Exception{
		enterMemberFirstName(memberNo, firstName);
		enterMemberLastName(memberNo, lastName);
		//enterMemberSuffix(memberNoInRepository, suffix);
		enterMemberDOB(memberNo, dob);
	}
	
	public void provideMemberDetail(String whoIsApplying, int memberNo, String firstName, String lastName, String dob ) throws Exception{
		if(! whoIsApplying.equals(WhoIsApplying.SELF.code)){
			int memberNoInRepository = 0;
			
			if(whoIsApplying.equalsIgnoreCase(WhoIsApplying.FAMILY_ONLY.code)){
				memberNoInRepository=memberNo-1;
			}else{
				memberNoInRepository=memberNo;
			}
			provideMemberDetail(memberNoInRepository, firstName, lastName, dob);
		}
		
	}

	public void provideMembersDetail(String whoIsApplying, List<EVPD_MemData> memsData) throws Exception {
		waitForPageLoaded();
		Integer memCount = memsData.size();
		
		if( memCount >= 2 || ( memCount >=1 && whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code) ) ){
			for (int mCounter=1; mCounter < memCount ; mCounter++){
				
				provideMemberDetail(
							whoIsApplying, 
							mCounter+1, 
							memsData.get(mCounter).firstName,
							memsData.get(mCounter).lastName,
							memsData.get(mCounter).dob);
			}
		}
		clickOnSaveAndContinueBtn();
	}
	
	/**@author akumari4
	 * 
	 * @throws Exception
	 */
	public void clickOnRemoveMemberBtn(int memNo) throws Exception{
		By memToBeRemoved = By.id("deleteApplicant_"+(memNo-1)+"");
		clickOnElement("Mem"+(memNo)+"RemoveBtn", memToBeRemoved);
		
	}
	
	/**@author akumari4
	 * 
	 * @param memNo
	 * @param removalReasonVal
	 * @throws Exception
	 */
	public void selectRemovalReasonForMember(int memNo,String removalReasonVal) throws Exception{
		By removalReasonDD = By.id("reasonOfRemoval_"+(memNo-1)+"");
		selectDropDownElementByVisibleText("Mem" + (memNo) + "RemovalReasonValue", removalReasonDD, removalReasonVal);
	}
	
	/**@author akumari4
	 * 
	 * @param memNo
	 * @param removalReasonVal
	 * @throws Exception
	 */
	public void selectAddReasonForMember(int memNo,String addReasonVal) throws Exception{
		By addReasonDD = By.id("additionReason_"+(memNo-1)+"");
		selectDropDownElementByVisibleText("Mem" + (memNo) + "AddReasonValue", addReasonDD, addReasonVal); 
	}
	
	public void enterRemovalReasonDate(int memNo,String removalReasonDateVal) throws Exception{
		By removalReasonDateTxtBox = By.id(""+(memNo-1)+"_dateOfRemoval");
		clearAndType("Mem" + (memNo)+"RemovalReasonDate", removalReasonDateTxtBox, removalReasonDateVal);
	}
	
	/**@author akumari4
	 * 
	 * @param memNo
	 * @param addReasonDateVal
	 * @throws Exception
	 */
	public void enterAddReasonDate(int memNo,String addReasonDateVal) throws Exception{
		By addReasonDateTxtBox = By.id("date_add_reason_"+(memNo-1)+"");
		clearAndType("Mem" + (memNo)+"AddReasonDate", addReasonDateTxtBox, addReasonDateVal);
	}
	
	public void selectMemNameChange() throws Exception{
		//By memNameChangeBtn = By.xpath("//input[contains(.,' Changing details for the same person.')]");
		//updated by Paul
		By memNameChangeBtn = By.xpath("//label[contains(text(),'Changing details for the same person')]/input");
		optionalClickOnElement("Name Change For Same Member", memNameChangeBtn);
	}
	
	public void clickOnConfirmPopUp() throws Exception{
		optionalClickOnElement("PopupConfirmBtn", popupConfirmBtn);
	}
	
	// added by ppinho
	public void clickOnConfirmNameChangePopUp() throws Exception{
		By popupContinueBtn = By.xpath("//div[@id='memberNameChangeDialog']/..//div/button/span[contains(text(),'Continue')]");
		clickOnElement("PopupConfirmBtn", popupContinueBtn);
	}

	/**@author Ritu
     * 
      * @param memNo
     * @throws Exception
     */
     public void selectMemLostInsurance(int memNo ,boolean memLostInsuranceYesNOBtnValue) throws Exception{
           By memLostInsuranceYesNOBtn = By.name("eligibilityMember["+(memNo-1)+"].eligibilityMemberAdditionalInfo.notPaidPremium");
           selectByValue("Lost Insurance Status", memLostInsuranceYesNOBtn,memLostInsuranceYesNOBtnValue+"");
     }

	/**@author Ritu
     * 
      * @param memNo
     * @throws Exception
     */
     public void selectMemCancelInsurance(int memNo,boolean memCancelInsuranceValue) throws Exception{
           By memCancelInsuranceBtn = By.name("eligibilityMember["+(memNo-1)+"].eligibilityMemberAdditionalInfo.cancelCoverage");
           selectByValue("Cancel Insurance Status",memCancelInsuranceBtn, memCancelInsuranceValue+"");
     }
	public boolean isWarningDialogPresent() throws Exception{
		return isElementPresent(warningDialogH2);
	}
	
	public void clickOnWarningOkButton() throws Exception{
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}
	
	public void handleWarningDialogIfPresent() throws Exception{
		if(isWarningDialogPresent()){
			clickOnWarningOkButton();
		}
	}

	
	
}
