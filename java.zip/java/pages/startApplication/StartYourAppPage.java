package pages.startApplication;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class StartYourAppPage extends CommonPage implements CommonPageOR {
	
	private static final By startYrAppPageHeader = By.xpath("//h1[text()='Start Your Application']");
	
	public StartYourAppPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("StartYrAppPageHeader", startYrAppPageHeader);
	}
	
	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoaded();
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public String getEligibilityId() throws Exception {
		String url = getCurrentURL();
		String elgId = url.split("=0&id=")[1].split("&")[0];
		return elgId;
	}
	
	// ppinho
	public void evpdClickOnSaveAndContinueBtn() throws Exception {
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
}
