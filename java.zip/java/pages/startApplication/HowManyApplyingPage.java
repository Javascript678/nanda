package pages.startApplication;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class HowManyApplyingPage extends CommonPage implements CommonPageOR{
	
	private static final By howManyApplyPageHeader = By.xpath("//h1[contains(text(),'How Many are Applying for Health Insurance?')]");
	private static final By addMemberBtn = By.className("plusBtnTxt");
	private static final By removeMemberBtn = By.className("minusBtnTxt");
	//private static final By memberCntElmnt = By.id("memberCount");
	
	public HowManyApplyingPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("HowManyApplyPageHeader", howManyApplyPageHeader);
	}
	
	private void clickOnAddMemberBtn() throws Exception{
		clickOnElement("AddMemberBtn", addMemberBtn);
	}
	
	/**
	 * @author akumari4
	 */
	private void clickOnRemoveMemberBtn() throws Exception{
		clickOnElement("RemoveMemberBtn", removeMemberBtn);
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void clickOnWarningOkButton() throws Exception{
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}
	
	/*
	 * Accepted value :- FAMILY_ONLY,SELF_FAMILY,SELF
	 */
	public void provideMemberCount(String whoIsApplying, int memberCount) throws Exception{
		if(! whoIsApplying.equals(WhoIsApplying.SELF.code)){
			int memberCountOnUI = memberCount;
			waitForPageLoaded();
			if( whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)){
				memberCountOnUI=memberCount-1;
			}
			for(int i=0; i< memberCountOnUI-1; i++){
				clickOnAddMemberBtn();
			}
			clickOnSaveAndContinueBtn();
		}
	}
	
	public void selectAddMemberCountOnUI(int addMemberCountOnUI) throws Exception{
			waitForPageLoaded();
			for(int i=1; i<= addMemberCountOnUI; i++){
				clickOnAddMemberBtn();
			}
			clickOnSaveAndContinueBtn();
	}
	
	/**
	 * @author akumari4
	 * @param removeMemberCountOnUI
	 * @throws Exception
	 */
	public void selectRemoveMemberCountOnUI(int removeMemberCountOnUI) throws Exception{
		waitForPageLoaded();
		for(int i=1; i<= removeMemberCountOnUI; i++){
			clickOnRemoveMemberBtn();
		}
		clickOnSaveAndContinueBtn();
}
	
	public void pageLoadAndClickOnSaveAndCOntinue() throws Exception{
			waitForPageLoaded();
			clickOnSaveAndContinueBtn();
	}
}
