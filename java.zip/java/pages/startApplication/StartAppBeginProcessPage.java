package pages.startApplication;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * @author Paul Pinho
 */

public class StartAppBeginProcessPage extends CommonPage implements CommonPageOR {
	
	private static final By startAppBeginPageHeader = By.xpath("//h1[contains(text(),'Start Your Application')  and contains(text(),'Begin Process')]");
	private static final By checkPrivacyTermsServiceChk = By.id("checkPrivacyTermsService");
		
	public StartAppBeginProcessPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("StartAppBeginPageHeader", startAppBeginPageHeader);
	}
	
	private void clickOnCheckPrivacyTermsServiceChkBx() throws Exception {
		waitForPageLoaded();
		clickOnElement("CheckPrivacyTermsServiceChk", checkPrivacyTermsServiceChk);
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void acceptTCAndSaveAndContinue() throws Exception {
		clickOnCheckPrivacyTermsServiceChkBx();
		clickOnSaveAndContinueBtn();
	}
	
	public void dontAcceptTCAndSaveAndContinue() throws Exception{
		if(isAttributePresent(checkPrivacyTermsServiceChk, "checked")){
			clickOnCheckPrivacyTermsServiceChkBx();
		}
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdAcceptSaveAndContinue() throws Exception {
		clickOnElement("CheckPrivacyTermsServiceChk", checkPrivacyTermsServiceChk);
		clickOnSaveAndContinueBtn();
	}
	
}
