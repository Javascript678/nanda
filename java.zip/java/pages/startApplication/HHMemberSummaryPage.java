package pages.startApplication;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class HHMemberSummaryPage extends CommonPage implements CommonPageOR {
	
	private static final By HHMemberSummaryHeader = By.xpath("//h1[contains(text(),'Household Member Summary')]");
	
	public HHMemberSummaryPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocatedThenWait("WhoIsApplyingHISummaryHeader", HHMemberSummaryHeader, 5);
	}
	
	public void validateNameForMember(int memIndex, String expName) throws Exception { 
		By memNameLabel = By.xpath(""); //TODO:
		validateTextEquals("Mem" + (memIndex + 1) + "Name", memNameLabel, expName);
	}
	
	public void validateDOBForMember(int memIndex, String expDOB) throws Exception { 
		By memDOBLabel = By.xpath(""); //TODO:
		validateTextEquals("Mem" + (memIndex + 1) + "DOB", memDOBLabel, expDOB);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception { 
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception { 
		waitForPageLoaded();
		takeScreenshot("Summary");
		clickOnSaveAndContinueBtn();
	}
	
	public void evpdClickOnSaveAndContinueBtn() throws Exception { 
		takeScreenshot("Summary");
		clickOnSaveAndContinueBtn();
	}
	
	public void racClickOnSaveAndContinueBtn() throws Exception { 
		takeScreenshot("Summary");
		clickOnSaveAndContinueBtn();
	}
	
}
