package pages.startApplication;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.rac.RAC_Data;
import enums.PortalName;
import pages.common.CommonPage;
import pages.profile.USPSPage;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class HOHContactInformationPage extends CommonPage {
	
	private static final By hohContactInformationPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Head of Household Contact Information')]");
	
	PersonalInfo personalInfo = new PersonalInfo();	
	HomeAddress homeAddress = new HomeAddress();
	MailingAddress mailingAddress = new MailingAddress();
	ContactPhone contactPhone = new ContactPhone();
	ContactPreference contactPreference = new ContactPreference();

	private static final By primaryContactInfoSaveBtn = By.id("primaryContactInfoNextPage");
			
	public HOHContactInformationPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("HohContactInformationPageHeader", hohContactInformationPageHeader);
	}
	
	private class PersonalInfo {
		
		private final By checkForAccountHolderChk = By.id("eligibilityMember[0].checkAccountHolder");
		private final By firstNameTxt = By.id("eligibilityMember0.name.firstName");
		private final By middleNameTxt = By.id("eligibilityMember0.name.middleName");
		private final By lastNameTxt = By.id("eligibilityMember0.name.lastName");
		private final By suffixDD = By.id("eligibilityMember0.name.suffix");
		private final By emailTxt = By.id("eligibilityMember0.contactInfo.email");
		private final By dobTxt = By.id("eligibilityMember0.dateOfBirth");
		
		private void clickOnAcountHolderChkBox() throws Exception {
			clickOnElement("checkForAccountHolderChk", checkForAccountHolderChk);
		}
		
		private void enterFirstName(String firstName) throws Exception {
			enterText("FirstNameTxt", firstNameTxt, firstName);
		}
		
		private void enterMiddleName(String middleName) throws Exception {
			enterText("MiddleNameTxt", middleNameTxt, middleName);
		}
		
		private void enterLastName(String lastName) throws Exception {
			enterText("LastNameTxt", lastNameTxt, lastName);
		}
		
		private void changeLastName(String lastName) throws Exception {
			clearAndType("LastNameTxt", lastNameTxt, lastName);
		}
		
		private void selectSuffixFromDropDown(String suffix) throws Exception {
			enterText("SuffixDD", suffixDD, suffix);
		}
		private void enterEmailId(String emailId) throws Exception {
			enterText("EmailTxt", emailTxt, emailId);
		}
		private void enterDOB(String dob) throws Exception {
			clearAndTypeAfterWait("DobTxt", dobTxt, dob);
		}
		
		private void changeEmailId(String emailId) throws Exception {
			clearAndType("EmailTxt", emailTxt, emailId);
		}
		
	}
	public void changeLastNameHOH(String lastName) throws Exception {
		personalInfo.changeLastName(lastName);
	}
	
	public void changeEmailAddress(String emailAddress) throws Exception {
		personalInfo.changeEmailId(emailAddress);
	}
	
	private class HomeAddress {
		
		private final By noHomeAddressChkBox = By.id("no_primary_address");
		private final By streetAddr1Txt = By.id("eligibilityMember[0].contactInfo.primaryAddress.streetAddress1");
		private final By AprUnitNoTxt = By.id("eligibilityMember[0].contactInfo.primaryAddress.streetAddress2");
		private final By cityTxt = By.id("eligibilityMember[0].contactInfo.primaryAddress.city");
		private final By zipTxt = By.id("eligibilityMember[0].contactInfo.primaryAddress.zip");
		private final By countyDD = By.id("eligibilityMember[0].contactInfo.primaryAddress.county");
		private final By cityTxtTemp = By.id("eligibilityMember[0].temporaryAddress.city");
		private final By zipTxtTemp = By.id("eligibilityMember[0].temporaryAddress.zip");
		private final By countyDDTemp = By.id("eligibilityMember[0].temporaryAddress.county");
				
		private void clickOnNoHomeAddrReqdCheckBox() throws Exception {
			clickOnElement("NoHomeAddressChkBox", noHomeAddressChkBox);
		}
		
		private void enterStreetAddress(String streetAddress) throws Exception {
			clearAndType("StreetAddr1Txt", streetAddr1Txt, streetAddress);
		}
		
		private void enterAptUnitNumber(String aptUnitNo) throws Exception {
			clearAndType("AprUnitNoTxt", AprUnitNoTxt, aptUnitNo);
		}
		
		private void enterCity(String city) throws Exception {
			clearAndType("CityTxt", cityTxt, city);
		}
				
		private void enterZipCode(String zipCode) throws Exception {
			clearAndTypeAfterWait("ZipTxt", zipTxt, zipCode);
		}
		
		private void selectCounty(String county) throws Exception {
			//selectByVisibleTextAfterWait("CountyDD", countyDD, county);
			selectByIndexAfterWait("CountyDD", countyDD, 1);
		}
		
		private void enterCityTemp(String city) throws Exception {
			clearAndType("CityTxt", cityTxtTemp, city);
		}

		private void enterZipCodeTemp(String zipCode) throws Exception {
			clearAndTypeAfterWait("ZipTxt", zipTxtTemp, zipCode);
		}

		private void selectCountyTemp(String county) throws Exception {
			selectByVisibleTextAfterWait("CountyDD", countyDDTemp, county);
		}

		private void selectLiveTempOutsideMARdBtn(boolean liveTempOutsideMA) throws Exception { 
			By liveTempOutsideMADD = By.xpath("//input[contains(@name,'isLivingOutsideTemporarily') and @value='"+liveTempOutsideMA+"']/../label");
			clickOnElement("LiveTempOutsideMA", liveTempOutsideMADD);
		}
		
	}
	
    private class MailingAddress {
		
    	private final By sameAsHomeAddrChkBox = By.id("mailing_same_as_resident");
		private final By streetAddr1Txt = By.id("eligibilityMember[0].contactInfo.secondaryAddress.streetAddress1");
		private final By aptUnitAddressTxt = By.id("eligibilityMember[0].contactInfo.secondaryAddress.streetAddress2");
		private final By cityTxt = By.id("eligibilityMember[0].contactInfo.secondaryAddress.city");
		private final By zipTxt = By.id("eligibilityMember[0].contactInfo.secondaryAddress.zip");
		private final By countyDD = By.id("eligibilityMember[0].contactInfo.secondaryAddress.county");
				
		private void clickOnSameAsHomeAddressCheckBox() throws Exception {
			clickOnElement("SameAsHomeAddrChkBox", sameAsHomeAddrChkBox);
		}
		
		private void enterStreetAddress(String streetAddress) throws Exception {
			enterText("StreetAddr1Txt", streetAddr1Txt, streetAddress);
		}
		
		private void enterAptUnitNumber(String aptUnitNo) throws Exception {
			enterText("AptUnitAddressTxt", aptUnitAddressTxt, aptUnitNo);
		}
		
		private void enterCity(String city) throws Exception {
			enterText("CityTxt", cityTxt, city);
		}
		
		private void enterZipCode(String zipCode) throws Exception {
			clearAndType("ZipTxt", zipTxt, zipCode);
		}
		
		private void selectCounty(String county) throws Exception {
			selectByVisibleTextAfterWait("CountyDD", countyDD, county);
		}
		
	}

    private class ContactPhone {
    	
    	private final By primaryPhnoTxt = By.id("eligibilityMember0.contactInfo.primaryPhoneNumber_0");
		private final By secondaryPhnoTxt = By.id("eligibilityMember0.contactInfo.secondaryPhoneNumber_0");
		
		private void enterPrimaryPhoneNo(String phoneNo) throws Exception {
			enterText("PrimaryPhnoTxt", primaryPhnoTxt, phoneNo);
		}
		
		private void enterSecondaryPhoneNo(String phoneNo) throws Exception {
			enterText("SecondaryPhnoTxt", secondaryPhnoTxt, phoneNo);
		}
		
    }

    private class ContactPreference {
    	
    	private final By spokenlangDD = By.id("eligibilityMember0.contactInfo.preferredLanguage");
		private final By writtenlangDD = By.id("eligibilityMember0.contactInfo.preferredWrittenLanguage");
		
		private void selectSpokenLanguage(String lang) throws Exception {
			selectDropDownElementByVisibleText("SpokenlangDD", spokenlangDD, lang);
		}
		
		private void selectWrittenLanguage(String lang) throws Exception {
			selectDropDownElementByVisibleText("WrittenlangDD", writtenlangDD, lang);
		}
		
    }
    
    public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElementAfterScreenshot("Summary", primaryContactInfoSaveBtn);
	}
    
    public void clickOnSaveBtn() throws Exception{
		By save = By.id("saveProfileLsc");
		clickOnElement("SaveBtn", save);
	}
	public void enterContactInfo(boolean isProfileAccHolder, String firstName, String lastName, String middleName, String emailId, String dob) throws Exception {
		if(isProfileAccHolder == true){
			personalInfo.clickOnAcountHolderChkBox();
		}else if(isProfileAccHolder == false){
			personalInfo.enterFirstName(firstName);
			personalInfo.enterMiddleName(middleName);
			personalInfo.enterLastName(lastName);
			//personalInfo.selectSuffixFromDropDown(suffix);
			personalInfo.enterDOB(dob);
			personalInfo.enterEmailId(emailId);
		}
	}

	public void enterHomeAddress(boolean noHomeAddressReqd, String streetAddress1, String aptUnitNo, String city, String zip, String county,boolean liveInMA,boolean liveTemporaryOutsideMA,String zipTemp, String countyTemp) throws Exception {
		if(noHomeAddressReqd == true){
			homeAddress.clickOnNoHomeAddrReqdCheckBox();
		}else if(noHomeAddressReqd == false && liveInMA == false && liveTemporaryOutsideMA == true){
			homeAddress.enterStreetAddress(streetAddress1);
			homeAddress.enterAptUnitNumber(aptUnitNo);
			homeAddress.enterCity(city);
			homeAddress.enterZipCode(zipTemp);
			homeAddress.selectCounty(countyTemp);
			homeAddress.selectLiveTempOutsideMARdBtn(true);
			homeAddress.enterCityTemp(city);
			homeAddress.enterZipCodeTemp(zip);
			homeAddress.selectCountyTemp(county);
		}else if(noHomeAddressReqd == false && liveInMA == false && liveTemporaryOutsideMA == false){
			homeAddress.enterStreetAddress(streetAddress1);
			homeAddress.enterAptUnitNumber(aptUnitNo);
			homeAddress.enterCity(city);
			homeAddress.enterZipCode(zipTemp);
			homeAddress.selectCounty(countyTemp);
			homeAddress.selectLiveTempOutsideMARdBtn(false);
		}else if(noHomeAddressReqd == false){
			homeAddress.enterStreetAddress(streetAddress1);
			homeAddress.enterAptUnitNumber(aptUnitNo);
			homeAddress.enterCity(city);
			homeAddress.enterZipCode(zip);
			homeAddress.selectCounty(county);
		}
	}
	
	public void enterMailingAddress(boolean IsMailingAddressSameAsHomeAddress, String streetAddress1, String aptUnitNo, String city, String zip, String county) throws Exception { 
		if(IsMailingAddressSameAsHomeAddress == false){
			mailingAddress.enterStreetAddress(streetAddress1);
			mailingAddress.enterAptUnitNumber(aptUnitNo);
			mailingAddress.enterCity(city);
			mailingAddress.enterZipCode(zip);
			mailingAddress.selectCounty(county);
		}else if(IsMailingAddressSameAsHomeAddress == true){
			mailingAddress.clickOnSameAsHomeAddressCheckBox();
		}
	}
	
	
	public void enterMailingAddressNew(boolean IsMailingAddressSameAsHomeAddress, String email, String zip, String county) throws Exception { 
		if(IsMailingAddressSameAsHomeAddress == false){
			changeEmailAddress(email);
			mailingAddress.enterZipCode(zip);
			mailingAddress.selectCounty(county);
		}else if(IsMailingAddressSameAsHomeAddress == true){
			mailingAddress.clickOnSameAsHomeAddressCheckBox();
		}
	}

	//Ritika
	public void changeMailingAddressRAC(String streetAddress1, String aptUnitNo, String city, String zip, String county) throws Exception { 
		mailingAddress.clickOnSameAsHomeAddressCheckBox();
		mailingAddress.enterStreetAddress(streetAddress1);
		mailingAddress.enterAptUnitNumber(aptUnitNo);
		mailingAddress.enterCity(city);
		mailingAddress.enterZipCode(zip);
		mailingAddress.selectCounty(county);
	}
	
	//Ritu
	public void changeHomeAddressRAC(String streetAddress1, String aptUnitNo, String city,  String county) throws Exception {
       homeAddress.enterStreetAddress(streetAddress1);
       homeAddress.enterAptUnitNumber(aptUnitNo);
       homeAddress.enterCity(city);
       //homeAddress.enterZipCode(zip);
       homeAddress.selectCounty(county);
       mailingAddress.clickOnSameAsHomeAddressCheckBox();
	}
	
	public void enterPhoneNos(String primaryPhone, String seondaryPhone) throws Exception { 
		contactPhone.enterPrimaryPhoneNo(primaryPhone);
		contactPhone.enterSecondaryPhoneNo(seondaryPhone);
	}
	
	public void enterContactPreferences(String spokenLang, String writtenLang) throws Exception { 
		contactPreference.selectSpokenLanguage(spokenLang);
		contactPreference.selectWrittenLanguage(writtenLang);
	}
	
	public void pageLoadAndClickOnSaveAndContinue() throws Exception { 
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void evpdSubmitHOHContactInformation(EVPD_Data evpdData) throws Exception {
		if(!evpdData.portal.equalsIgnoreCase(PortalName.ASSISTER.code)){
			enterContactInfo(evpdData.createProfileData.profileAccHolder,
					evpdData.memsData.get(0).firstName, 
					evpdData.memsData.get(0).lastName,
					evpdData.memsData.get(0).middleName, 
					evpdData.memsData.get(0).emailId, 
					evpdData.memsData.get(0).dob);
	
			enterHomeAddress(evpdData.memsData.get(0).noHomeAddressReqd,
					evpdData.memsData.get(0).homeAddr.streetAddress, 
					evpdData.memsData.get(0).homeAddr.aptUnit,
					evpdData.memsData.get(0).homeAddr.city, 
					evpdData.memsData.get(0).homeAddr.zipCode,
					evpdData.memsData.get(0).homeAddr.county, 
					evpdData.memsData.get(0).livesInMA, 
					evpdData.memsData.get(0).liveTemporaryOutsideMA, 
					evpdData.memsData.get(0).homeAddr.zipCodeTemp,
					evpdData.memsData.get(0).homeAddr.countyTemp);
			
			enterMailingAddress(evpdData.memsData.get(0).mailingAddressSameAsHomeAddress,
					evpdData.memsData.get(0).mailAddr.streetAddress, 
					evpdData.memsData.get(0).mailAddr.aptUnit,
					evpdData.memsData.get(0).mailAddr.city, 
					evpdData.memsData.get(0).mailAddr.zipCode,
					evpdData.memsData.get(0).mailAddr.county);
	
			enterPhoneNos(evpdData.memsData.get(0).phoneNo,
					evpdData.memsData.get(0).secondaryPhoneNo);
			
			enterContactPreferences(evpdData.memsData.get(0).spokenLang,
					evpdData.memsData.get(0).writtenLang);
			
			clickOnSaveAndContinueBtn();
	
			USPSPage uspsPage = new USPSPage(driver, testCaseId);
			
			uspsPage.completeUSPSServiceSuggestion(evpdData.portal, 
					evpdData.serviceData, 
					evpdData.createProfileData.profileAccHolder);
		}else{
			clickOnSaveAndContinueBtn();
		}
	}
	
	public void racSubmitHOHContactInformation(RAC_Data racData) throws Exception {
		if(!racData.portal.equalsIgnoreCase(PortalName.ASSISTER.code)){
			enterContactInfo(racData.createProfileData.profileAccHolder,
					racData.memsData.get(0).firstName, 
					racData.memsData.get(0).lastName,
					racData.memsData.get(0).middleName, 
					racData.memsData.get(0).emailId, 
					racData.memsData.get(0).dob);
	
			enterHomeAddress(racData.memsData.get(0).noHomeAddressReqd,
					racData.memsData.get(0).homeAddr.streetAddress, 
					racData.memsData.get(0).homeAddr.aptUnit,
					racData.memsData.get(0).homeAddr.city, 
					racData.memsData.get(0).homeAddr.zipCode,
					racData.memsData.get(0).homeAddr.county, 
					racData.memsData.get(0).livesInMA, 
					racData.memsData.get(0).liveTemporaryOutsideMA, 
					racData.memsData.get(0).homeAddr.zipCodeTemp,
					racData.memsData.get(0).homeAddr.countyTemp);
			
			enterMailingAddress(racData.memsData.get(0).mailingAddressSameAsHomeAddress,
					racData.memsData.get(0).mailAddr.streetAddress, 
					racData.memsData.get(0).mailAddr.aptUnit,
					racData.memsData.get(0).mailAddr.city, 
					racData.memsData.get(0).mailAddr.zipCode,
					racData.memsData.get(0).mailAddr.county);
	
			enterPhoneNos(racData.memsData.get(0).phoneNo,
					racData.memsData.get(0).secondaryPhoneNo);
			
			enterContactPreferences(racData.memsData.get(0).spokenLang,
					racData.memsData.get(0).writtenLang);
			
			clickOnSaveAndContinueBtn();
	
			USPSPage uspsPage = new USPSPage(driver, testCaseId);
			
			uspsPage.completeUSPSServiceSuggestion(racData.portal, 
					racData.serviceData, 
					racData.createProfileData.profileAccHolder);
		}else{
			clickOnSaveAndContinueBtn();
		}
	}
	
}
