package pages.startApplication;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class DoYouWantHelpPayingPage extends CommonPage implements CommonPageOR {

	private static final By doYouWantHelpPayingPageHeader = By.xpath("//h1[contains(.,'Do you need help paying for health coverage?')]");
	private static final By whoNeedHIGenRdBtn = By.name("applyingFor");
	private static final By wantFinancialHelpRdBtn = By.name("get_financial_assistance");
	
	public DoYouWantHelpPayingPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("DoYouWantHelpPayPageHeader", doYouWantHelpPayingPageHeader);
	}
	
	/*
	 * Accepted value :- FAMILY_ONLY,SELF_FAMILY,SELF
	 */
	
	public void selectWhoNeedHealthInsuranceRdBtn(String whoNeedHI) throws Exception { 
		selectByValue("WhoNeedHIGenRdBtn", whoNeedHIGenRdBtn,  whoNeedHI);
	}
	
	/*
	 * Accepted value :- true, false
	 */
	
	private void selectFinancialHelpNeededRdBtn(boolean financialHelpNeeded) throws Exception { 
		//selectByValue("WantFinancialHelpRdBtn", wantFinancialHelpRdBtn , financialHelpNeeded+"");
		selectByAttributeNameUsingJS("WantFinancialHelpRdBtn" ,wantFinancialHelpRdBtn, "value", financialHelpNeeded+"");
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void selectWhoisApplyingAndIfHelpNeede(boolean financialHelpNeeded) throws Exception {
		selectFinancialHelpNeededRdBtn(financialHelpNeeded);
		clickOnSaveAndContinueBtn();
	}
	
	public boolean isWarningDialogPresent() throws Exception {
		return isElementPresent(warningDialogH2);
	}
	
	public void handleWarningDialogIfPresent() throws Exception {
		if(isWarningDialogPresent()){
			clickOnWarningOkButton();
		}
	}

	public void clickOnWarningOkButton() throws Exception {
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}
	
	public void pageLoadAndClickOnSaveAndContinue() throws Exception {
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdSelectWhoisApplyingAndIfHelpNeede(boolean financialHelpNeeded) throws Exception {
		selectFinancialHelpNeededRdBtn(financialHelpNeeded);
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void racSelectWhoisApplyingAndIfHelpNeede(boolean financialHelpNeeded) throws Exception {
		selectFinancialHelpNeededRdBtn(financialHelpNeeded);
		clickOnSaveAndContinueBtn();
	}
}
