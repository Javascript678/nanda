package pages.profile;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * Author : Vinay Kumar
 * While creating EVPD provide Provide Id verification details.
 */
public class IdVerificationPage extends CommonPage implements CommonPageOR {
	
	private static final By identityVerificationPgHeader = By.xpath("//h1[contains(text(),'Identity Verification')]");
		
	public IdVerificationPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("IdentityVerificationPgHeader", identityVerificationPgHeader);
	}
	
	private void answerIdVerifyQue(int queNo, int ans) throws Exception{
		//By idVerifyAnsRdBtn = By.name("question["+queNo+"].selectedAnswer");
		//selectByValue("IdVerifyAns"+queNo+"RdBtn", idVerifyAnsRdBtn, ans+"");
        By idVerifyAnsRdBtn = By.xpath("//input[@name='question["+queNo+"].selectedAnswer' and @value='"+ans+"']//../label");
        clickOnElement("IdVerifyAns"+queNo+"RdBtn", idVerifyAnsRdBtn);

	}
	
	private boolean isQuestionPresent(int queNo) throws Exception{
		By idVerifyAnsRdBtn = By.name("question["+queNo+"].selectedAnswer");
		return isElementPresent(idVerifyAnsRdBtn);
	}
	
	private void clickOnSaveAndContinue()throws Exception{ 
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	/**
	 * Consider 5th question may appear some times and may not.
	 */
	public void completeIdVerification(int ans1Index, int ans2Index, int ans3Index, int ans4Index, int ans5Index )throws Exception{ 
		waitForPageLoaded();
		
		for(int queCounter=1; queCounter <= 5 ; queCounter++){
			if(queCounter==5){
				if(isQuestionPresent(5)){
					answerIdVerifyQue(5, ans5Index);
				}
			}else{
				answerIdVerifyQue(queCounter, ans1Index);
			}
			
		}
		clickOnSaveAndContinue();
	}
	
	/** @author ppinho
	 * Consider 5th question may appear some times and may not.
	 */
	public void evpdCompleteIdVerification(EVPD_Data evpdData)throws Exception{ 
		for(int queCounter = 1; queCounter <= 5 ; queCounter++){
			if(queCounter == 5 ){
				if(isQuestionPresent(5)){
					answerIdVerifyQue(5, evpdData.createProfileData.idProofingAns5Index);
				}
			}else{
				answerIdVerifyQue(queCounter, evpdData.createProfileData.idProofingAns1Index);
			}
			
		}
		clickOnSaveAndContinue();
		
		MyElig_EligAppPage myElig_EligAppPage = new MyElig_EligAppPage(driver, testCaseId);
		myElig_EligAppPage.evpdClickOnMyProfileBtn();
		
		MyProfilePage myProfilePage = new MyProfilePage(driver, testCaseId);		
		evpdData.userProfileRefId = myProfilePage.evpdGetUserProfileRefId();		
		myProfilePage.clickOnEligibiltyBtn();
	}

}
