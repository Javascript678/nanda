package pages.profile;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import utils.DateUtil;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class MyElig_EligAppPage extends CommonPage {
	
	private static final By myElig_EligAppPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Eligibility Application')]");

	public MyElig_EligAppPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("MyElig_EligAppPageHeader", myElig_EligAppPageHeader);
	}
	
	public void clickOnMyProfileBtn() throws Exception {
		By myProfileBtn = By.xpath("//li[@id='section_begin']/a");
		clickOnElement("MyProfile", myProfileBtn);
	}
	
	private void expandYrSection(String yr) throws Exception{
		By currentYrSection = By.xpath("//div/span[contains(.,'"+yr+"')]/parent::div");
		String expandCollpse = getElementAttribute("Year"+yr+"Section", currentYrSection, "aria-expanded");
		if(expandCollpse.equalsIgnoreCase("false")){
			clickOnElement("Year"+yr+"Section", currentYrSection);	
		}
	}
	
	public void clickOnCreateApplicationBtnForGivenYear(String year) throws Exception{
		expandYrSection(year);
		
		By createApplicationBtn = By.id("CREATE__" + year);
		clickOnElement("CreateApplication"+year+"Btn", createApplicationBtn);
	}
	
	public void clickOnCreateApplicationBtn(String appDate) throws Exception {
		int yr = DateUtil.getFromDate(appDate, 2, "/");
		
		expandYrSection(yr + "");
		
		By createApplicationBtn = By.id("CREATE__" + yr);
		clickOnElement("CreateApplication" + yr + "Btn", createApplicationBtn);
	}
	
	public void clickOnCreateApplicationBtnForNextYear(String appDate) throws Exception{
		int yr = DateUtil.getFromDate(appDate,2, "/");
		
		expandYrSection((yr+1)+"");
		
		By createApplicationBtnForNextYear = By.id("CREATE__" + (yr+1));
		clickOnElement("CreateApplication"+(yr+1)+"Btn", createApplicationBtnForNextYear);
	}
	
	public void clickOnCreateApplicationBtnForPrevYear(String appDate) throws Exception{
		int yr = DateUtil.getFromDate(appDate,2, "/");
		
		expandYrSection((yr-1)+"");
		
		By createApplicationBtnForNextYear = By.id("CREATE__" + (yr-1));
		clickOnElement("CreateApplication"+(yr-1)+"Btn", createApplicationBtnForNextYear);
	}
	
	public void clickOnCreateApplicationBtnExpandSectionIfRequired(String appDate) throws Exception{
		waitForPageLoaded();
		//expandCurrentYrSection(appDate);
		clickOnCreateApplicationBtn(appDate);
	}
	
	public void evpdClickOnMyProfileBtn() throws Exception {
		clickOnMyProfileBtn();
	}
	
}
