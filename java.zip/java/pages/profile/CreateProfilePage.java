package pages.profile;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.CreateProfileData;
import appdata.evpd.EVPD_MemData;
import enums.AppTypeName;
import enums.PortalName;
import pages.common.CommonPage;

/**
 * Author : Vinay Kumar
 * While creating EVPD provide Create Profile details
 */
public class CreateProfilePage extends CommonPage {
	
	PersonalInfo personalInfo = new PersonalInfo();	
	HomeAddress homeAddress = new HomeAddress();
	MailingAddress mailingAddress = new MailingAddress();
	ContactPhone contactPhone = new ContactPhone();
	ContactPreference contactPreference = new ContactPreference();
	
	private static final By createProfilePageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Create Profile')]");
	private static final By agreeChkBox = By.id("check_terms_services");
	//private static final By profileAppSource = By.xpath("//label[@for='otherApp']");
	private static final By profilePaperAppSubDateTxt = By.id("paper_submissionDate");
	private static final By createProfileBtn = By.id("registerSubmit");
	private static final String profile_App_Source_Other = "CSROtherApplication";
	private static final String profile_App_Source_Paper = "CSRPaperApplication";
	private static final String profile_App_Source_Phone = "CSRPhoneApplication";

	public CreateProfilePage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocatedThenWait("CreateProfilePageHeader", createProfilePageHeader,10);
	}
	
	private class PersonalInfo {
		private final By firstNameTxt = By.id("userProfile.firstName");
		private final By middleNameTxt = By.id("userProfile.middleName");
		private final By lastNameTxt = By.id("userProfile.lastName");
		private final By suffixDD = By.id("userProfile.suffix");
		private final By emailTxt = By.name("userProfile.contactInfo.email");
		private final By dobTxt = By.id("dob");
		private final By ssnTxt = By.id("userProfile.ssn");
				
		private void enterFirstName(String firstName) throws Exception {
			enterText("FirstNameTxt", firstNameTxt, firstName);
		}
		
		private void enterMiddleName(String middleName) throws Exception {
			enterText("MiddleNameTxt", middleNameTxt, middleName);
		}
		
		private void enterLastName(String lastName)throws Exception {
			enterText("LastNameTxt", lastNameTxt, lastName);
		}
		
		private void selectSuffixFromDropDown(String suffix)throws Exception {
			enterText("SuffixDD", suffixDD, suffix);
		}
		private void enterEmailId(String emailId)throws Exception {
			enterText("EmailTxt", emailTxt, emailId);
		}
		private void enterDOB(String dob)throws Exception {
			clearAndTypeAfterWait("DobTxt", dobTxt, dob);
		}
		private void enterSSN(String ssn)throws Exception {
			enterText("SSNTxt", ssnTxt, ssn);
		}
		
		private String getSSN()throws Exception {
			return getElementAttribute("SSNTxt", ssnTxt, "value");
		}
		
		private void validateSSNIsMasked()throws Exception {
			By ssnTxt = By.name("userProfile.ssn");
			
			String actualSSNOnUI = getSSN();
			
			//validateTextContains("SSNTxt", actualSSNOnUI, "***-**-");
			//validateTextContains("SSNTxt", actualSSNOnUI, "*****");
			validateElementAttribute("SSNTxt", ssnTxt, "type", "hidden");
		}
	}
	
	private class HomeAddress {
		
		private final By noHomeAddressChkBox = By.id("no_primary_address");
		private final By streetAddr1Txt = By.id("userProfile.contactInfo.primaryAddress.streetAddress1");
		private final By AprUnitNoTxt = By.id("userProfile.contactInfo.primaryAddress.streetAddress2");
		private final By cityTxt = By.id("userProfile.contactInfo.primaryAddress.city");
		private final By zipTxt = By.id("userProfile.contactInfo.primaryAddress.zip");
		private final By countyDD = By.id("userProfile.contactInfo.primaryAddress.county");
				
		private void clickOnNoHomeAddrReqdCheckBox()throws Exception {
			clickOnElement("NoHomeAddressChkBox", noHomeAddressChkBox);
		}
		
		private void enterStreetAddress(String streetAddress)throws Exception {
			enterText("HomeStreetAddrTxt", streetAddr1Txt, streetAddress);
		}
		
		private void enterAptUnitNumber(String aptUnitNo)throws Exception {
			enterText("HomeAprUnitNoTxt", AprUnitNoTxt, aptUnitNo);
		}
		
		private void enterCity(String city)throws Exception {
			enterText("HomeCityTxt", cityTxt, city);
		}
		
		private void enterZipCode(String zipCode)throws Exception {
			clearAndType("HomeZipTxt", zipTxt, zipCode);
		}
		
		private void selectCounty(String county)throws Exception {
			selectByVisibleTextAfterWait("HomeCountyDD", countyDD, county);
		}		
	}
	
    private class MailingAddress {
		
		private final By sameAsHomeAddrChkBox = By.id("mailing_same_as_resident");
		private final By streetAddr1Txt = By.id("userProfile.contactInfo.secondaryAddress.streetAddress1");
		private final By aptUnitAddressTxt = By.id("userProfile.contactInfo.secondaryAddress.streetAddress2");
		private final By cityTxt = By.id("userProfile.contactInfo.secondaryAddress.city");
		private final By zipTxt = By.id("userProfile.contactInfo.secondaryAddress.zip");
		private final By countyDD = By.id("userProfile.contactInfo.secondaryAddress.county");
				
		private void clickOnSameAsHomeAddressCheckBox() throws Exception {
			selectByValue("SameAsHomeAddrChkBox", sameAsHomeAddrChkBox, "true");
		}
		
		private void enterStreetAddress(String streetAddress) throws Exception {
			enterText("MailingStreetAddr1Txt", streetAddr1Txt, streetAddress);
		}
		
		private void enterAptUnitNumber(String aptUnitNo)throws Exception {
			enterText("MailingAptUnitAddressTxt" , aptUnitAddressTxt, aptUnitNo);
		}
		
		private void enterCity(String city) throws Exception {
			enterText("MailingCityTxt", cityTxt, city);
		}
		
		private void enterZipCode(String zipCode) throws Exception {
			clearAndType("MailingZipTxt", zipTxt, zipCode);
		}
		
		private void selectCounty(String county) throws Exception {
			selectByVisibleTextAfterWait("MailingCountyDD", countyDD, county);
		}
	}

    private class ContactPhone {
    	
    	private final By primaryPhnoTxt = By.id("userProfile.contactInfo.primaryPhoneNumber_0");
		private final By secondaryPhnoTxt = By.id("userProfile.contactInfo.secondaryPhoneNumber_0");
		
		private void enterPrimaryPhoneNo(String phoneNo) throws Exception {
			enterText("PrimaryPhnoTxt", primaryPhnoTxt, phoneNo);
		}
		
		private void enterSecondaryPhoneNo(String phoneNo) throws Exception {
			enterText("SecondaryPhnoTxt", secondaryPhnoTxt,phoneNo);
		}
    }

    private class ContactPreference {
    	
    	private final By spokenlangDD = By.id("communicationMode");
		private final By writtenlangDD = By.id("prefWrittenLanguage");
		
		private void selectSpokenLanguage(String lang) throws Exception {
			selectDropDownElementByVisibleText("SpokenlangDD", spokenlangDD, lang);
		}
		
		private void selectWrittenLanguage(String lang) throws Exception {
			selectDropDownElementByVisibleText("WrittenlangDD", writtenlangDD, lang);
		}
    }

    public void clickOnAgreeCheckBox() throws Exception {
		clickOnElement("AgreeChkBox", agreeChkBox);
	}
    
    private void selectAppSource(String appSource) throws Exception {
    	By profileAppSource = By.xpath("//input[@value='" + appSource + "']/../label");
        clickOnElement("ProfileAppSource", profileAppSource);
    }
    
    private void enterPaperAppDueDate(String appReceiveDate) throws Exception {
		clearAndType("ProfilePaperAppSubDateTxt", profilePaperAppSubDateTxt, appReceiveDate);	
	}
    
    public void clickOnCreateProfileBtn() throws Exception {
		clickOnElementAfterScreenshot("CreateProfileBtn", createProfileBtn);
	}
    
    public void enterContactInfo(String portal, String firstName, String middleName, String lastName, String emailId, String dob, String ssn) throws Exception { 
    	waitForPageLoaded();
    	
    	if(portal.equals(PortalName.AGENT.code)){
    		personalInfo.enterFirstName(firstName);
    		personalInfo.enterLastName(lastName);
    		personalInfo.enterEmailId(emailId);
    	}
    	
		personalInfo.enterMiddleName(middleName);
		personalInfo.enterDOB(dob);
		//commenting it becuase Profile (ERIN)SSN Logic is not confirmed
		//personalInfo.enterSSN(ssn);
	}
	
	public void enterHomeAddress(boolean noHomeAddressReqd, String streetAddress, String aptUnitNo, String city, String zipCode, String county) throws Exception { 
		if(noHomeAddressReqd == true){
			homeAddress.clickOnNoHomeAddrReqdCheckBox();
		}else{
			homeAddress.enterStreetAddress(streetAddress);
			homeAddress.enterAptUnitNumber(aptUnitNo);
			homeAddress.enterCity(city);
			homeAddress.enterZipCode(zipCode);
			homeAddress.selectCounty(county);
		}
	}
	
	public void enterMailingAddress(boolean mailingAddressSameAsHomeAddr, String streetAddress, String aptUnitNo, String city, String zipCode, String county) throws Exception { 
		if(mailingAddressSameAsHomeAddr == true){
			mailingAddress.clickOnSameAsHomeAddressCheckBox();
		}else{
			mailingAddress.enterStreetAddress(streetAddress);
			mailingAddress.enterAptUnitNumber(aptUnitNo);
			mailingAddress.enterCity(city);
			mailingAddress.enterZipCode(zipCode);
			mailingAddress.selectCounty(county);
		}
	}
	
	public void enterPhoneNos(String primaryPhone, String secondaryPhone) throws Exception { 
			contactPhone.enterPrimaryPhoneNo(primaryPhone);
			contactPhone.enterSecondaryPhoneNo(secondaryPhone);
	}
	
	public void enterContactPreferences(String spokenLang, String writtenLang)throws Exception {
		contactPreference.selectSpokenLanguage(spokenLang);
		contactPreference.selectWrittenLanguage(writtenLang);
	}

	public void completAppSourceDetail(String portal, String agentPortalAppType, String appReceiveDate) throws Exception { 
		String agentPortalAppTypeValue = "";
		
		if(portal.equalsIgnoreCase(PortalName.AGENT.code)){
			if(agentPortalAppType.equalsIgnoreCase("telephone")){
				agentPortalAppTypeValue=profile_App_Source_Phone;
			}else if(agentPortalAppType.equalsIgnoreCase("paper")){
				agentPortalAppTypeValue=profile_App_Source_Paper;
			}else{
				agentPortalAppTypeValue=profile_App_Source_Other;
			}
			
			selectAppSource(agentPortalAppTypeValue);
			
			if(agentPortalAppType.equalsIgnoreCase(AppTypeName.PAPER.val)){
				enterPaperAppDueDate(appReceiveDate);
			}
		}
	}
	
	public void completeCreateProfilePageDetails(String portal, CreateProfileData createProfileData, EVPD_MemData hohData) throws Exception { 
		if(portal.equals(PortalName.ASSISTER.code)){
			enterHomeAddress(hohData.noHomeAddressReqd, hohData.homeAddr.streetAddress, hohData.homeAddr.aptUnit, hohData.homeAddr.city, hohData.homeAddr.zipCode, hohData.homeAddr.county);
			enterMailingAddress(hohData.mailingAddressSameAsHomeAddress, hohData.mailAddr.streetAddress, hohData.mailAddr.aptUnit, hohData.mailAddr.city, hohData.mailAddr.zipCode, hohData.mailAddr.county);
			enterPhoneNos(hohData.phoneNo, hohData.secondaryPhoneNo);
			enterContactPreferences(hohData.spokenLang, hohData.writtenLang);
			clickOnAgreeCheckBox();
			clickOnCreateProfileBtn();
		}else{
			enterContactInfo(portal, createProfileData.firstName, createProfileData.middleName, createProfileData.lastName, createProfileData.emailAddress, createProfileData.dob, createProfileData.ssn);		
			enterHomeAddress(createProfileData.noHomeAddressReqd, createProfileData.homeAddr.streetAddress, createProfileData.homeAddr.aptUnit, createProfileData.homeAddr.city, createProfileData.homeAddr.zipCode, createProfileData.homeAddr.county);
			enterMailingAddress(createProfileData.mailingAddressSameAsHomeAddress, createProfileData.mailAddr.streetAddress, createProfileData.mailAddr.aptUnit, createProfileData.mailAddr.city, createProfileData.mailAddr.zipCode, createProfileData.mailAddr.county);
			enterPhoneNos(createProfileData.phoneNo, createProfileData.secondaryPhoneNo);
			enterContactPreferences(createProfileData.spokenLang, createProfileData.writtenLang);
			clickOnAgreeCheckBox();
			completAppSourceDetail(portal, createProfileData.appType, createProfileData.appReceiveDate);
			clickOnCreateProfileBtn();
		}
	}
	
	public void enterCreateProfilePageDetails(String portal, CreateProfileData createProfileData, EVPD_MemData hohData) throws Exception {
		CreateProfilePage createProfilePage = new CreateProfilePage(driver, testCaseId);
		createProfilePage.completeCreateProfilePageDetails(portal, createProfileData, hohData);
	}
	
	public void pageLoadAndTakeScreenShot() throws Exception {
		waitForPageLoaded();
		takeScreenshot("CreateProfile");
	}
	
	public void validateSSNIsMasked() throws Exception {
		waitForPageLoaded();
		takeScreenshot("CreateProfilePage");
		personalInfo.validateSSNIsMasked();
	}
}
