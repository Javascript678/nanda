package pages.profile;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * Author : Vinay Kumar
 * While creating EVPD provide Simply skip Id Proofing Page
 */
public class IdProofingPage extends CommonPage implements CommonPageOR {
	
	private static final By idProofingPageHeader = By.xpath("//h1[contains(text(),'ID Proofing')]");
		
	public IdProofingPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("IdProofingPageHeader", idProofingPageHeader);
	}
	
	private void clickOnSaveAndContinue()throws Exception{ 
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void pageLoadThenClickOnSaveAndContinue()throws Exception{ 
		waitForPageLoaded();
		clickOnSaveAndContinue();
	}
	
	// Paul
	public void evpdClickOnSaveAndContinue()throws Exception {
		clickOnSaveAndContinue();
	}
}
