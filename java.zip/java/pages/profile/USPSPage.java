package pages.profile;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.ServiceData;
import enums.PortalName;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */

public class USPSPage extends CommonPage implements CommonPageOR {
	
	private static final By uspsHomeAddressRDBtn = By.id("enteredHomeAddress");
	private static final By uspsMailingAddressRDBtn = By.id("enteredMailingAddress");
			
	public USPSPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void clickOnHomeAddressEntered() throws Exception { 
		//clickOnElement("USPSHomeAddressRDBtn" , uspsHomeAddressRDBtn);
		//selectByValueUsingJS("USPSHomeAddressRDBtn" , uspsHomeAddressRDBtn,"true");
		selectByAttributeNameUsingJS("USPSHomeAddressRDBtn", uspsHomeAddressRDBtn, "name", "homAddress");
	}
	
	private void clickOnMailingAddressEntered() throws Exception { 
		//clickOnElement("USPSMailingAddressRDBtn" , uspsMailingAddressRDBtn);
		//clickOnElementUsingJS(uspsMailingAddressRDBtn);
		selectByAttributeNameUsingJS("USPSMailingAddressRDBtn", uspsMailingAddressRDBtn, "name", "mailingAddress");
	}
	
	private void clickOnOKButton() throws Exception { 
		clickOnElement("OKButton", oKButton);
	}
	
	public void completeUSPSServiceSuggestion(String portal, ServiceData service ,boolean noHomeAddressReqd) throws Exception { 
		completeUSPSServiceSuggestion(portal, 
				service.individualByPassUsps, 
				service.agentByPassUsps, 
				service.assisterByPassUsps, 
				noHomeAddressReqd);		
	}
	
	public void completeUSPSServiceSuggestion(String portal, 
			Boolean individualByPassUsps,
			Boolean agentByPassUsps,
			Boolean assisterByPassUsps,
			Boolean noHomeAddressReqd) throws Exception { 
		
		Boolean byPassUsps = null;
		
		if(portal.equals(PortalName.INDIVIDUAL.code)){
			byPassUsps = individualByPassUsps;
		}else if(portal.equals(PortalName.AGENT.code)){
			byPassUsps = agentByPassUsps;
		}if(portal.equals(PortalName.ASSISTER.code)){
			byPassUsps = assisterByPassUsps;
		}
		
		if(byPassUsps == false){
			if(noHomeAddressReqd == false){
				clickOnHomeAddressEntered();
			}
			clickOnMailingAddressEntered();
			clickOnOKButton();
		}
		
	}
	
	public void completeUSPSServiceSuggestionForMailingAddress(String portal, 
			Boolean individualByPassUsps,
			Boolean agentByPassUsps,
			Boolean assisterByPassUsps) throws Exception {
		
		Boolean byPassUsps = null;
		
		if(portal.equals(PortalName.INDIVIDUAL.code)){
			byPassUsps = individualByPassUsps;
		}else if(portal.equals(PortalName.AGENT.code)){
			byPassUsps = agentByPassUsps;
		}if(portal.equals(PortalName.ASSISTER.code)){
			byPassUsps = assisterByPassUsps;
		}
		
		if(byPassUsps == false){
			clickOnMailingAddressEntered();
			clickOnOKButton();
		}
	}
	
}
