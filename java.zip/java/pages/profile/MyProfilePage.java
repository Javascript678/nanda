package pages.profile;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class MyProfilePage extends CommonPage {
	
	private static final By myProfilePageHeader = By.xpath("//h1[contains(text()[normalize-space()],'My Profile')]");
	private static final By eligibiltyBtn = By.xpath("//li[@id='section_basicinfo']/a");
	private static final By viewUnlockEligibiltyBtn = By.id("myEligibilityBtn");
	private static final By backToAccountDashboardBtn = By.xpath("//input[@value='Back to Account Dashboard']");
	private static final By ridpWarningPOPUP =By.xpath("//span[contains(.,'Warning')]");
	private static final By refIdTxt = By.id("reference_Id");
	
	public MyProfilePage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("MyProfilePageHeader", myProfilePageHeader,2);
	}
	
	public void clickOnEligibiltyBtn() throws Exception{ 
		clickOnElement("EligibiltyBtn", eligibiltyBtn);
	}
	
	public void clickOnViewUnlockEligibilityBtn() throws Exception{ 
		clickOnElement("ViewUnlockEligibiiltyBtn", viewUnlockEligibiltyBtn);
	}
	
	public String  getUserProfileRefId() throws Exception{ 
		//return getElementAttribute("RefIdTxt", refIdTxt,"placeholder");
		return getElementAttributeWhenDisabled("RefID", "id", "reference_Id", "placeholder");
}
	
	public String  getUserProfileSSN() throws Exception{ 
		return getElementAttributeWhenDisabled("SSNTxt", "id", "ssn","value");
	}
	
	public void  validateUserProfileSSNIsMasked() throws Exception{ 
		String ssn = getUserProfileSSN();
		validateTextContains("SSNTxt", ssn,"***");
	}
	
	public void clickOnBackToAccountDashboardBtn() throws Exception{ 
		clickOnElement("BackToAccountDashboardBtn", backToAccountDashboardBtn);
	}
	
	public void takeScreenshot() throws Exception {
		waitForPageLoaded();
		takeScreenshot("Summary");
	}
	
	public String  pageLoadAndGetUserProfileRefId() throws Exception{
		waitForPageLoaded();
		takeScreenshot();
		return getUserProfileRefId();
	}
	
	public String getUserProfileRefIdAndClickOnViewUnlockElg() throws Exception{
		String refId = null;
		waitForPageLoaded();
		refId = getUserProfileRefId();
		takeScreenshot();
		clickOnViewUnlockEligibilityBtn();
		return refId;
	}
	
	public void pageLoadAndClickOnViewUnlockElg() throws Exception{
		waitForPageLoaded();
		clickOnViewUnlockEligibilityBtn();
	}
	
	//Ritu
	public void validateRIDPWarningMsg() throws Exception{ 
		waitForPresenceOfElementLocatedThenWait("RIDPWarningPOPUP", ridpWarningPOPUP,2);
	}

	public void takescreenshot() throws Exception{ 
		takeScreenshot("RefID");
	}
	
	public void evpdClickOnViewUnlockElg() throws Exception {
		clickOnViewUnlockEligibilityBtn();
	}
	
	// ppinho
	public String evpdGetUserProfileRefId() throws Exception {
		takeScreenshot();
		return getUserProfileRefId();
	}
	
}
