package pages.retroEnrollment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Amrita
 *
 */
public class RetroEnrollmentPage extends CommonPage implements CommonPageOR {

	public RetroEnrollmentPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private static final By retroEnrollmentPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Retro')]");

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("RetroEnrollmentPageHeader", retroEnrollmentPageHeader);
	}

	// Amrita
	public void selectPlanYear(String planYear) throws Exception {
		By planYearDD = By.id("retroFilter.selectedPlanYear");
		selectDropDownElementByVisibleText("PlanYearDD", planYearDD, planYear);
	}

	// Amrita
	public void selectPlanType(String planType) throws Exception {
		By planTypeDD = By.id("retroFilter.selectedCoverageType");
		selectDropDownElementByVisibleText("PlanTypeDD", planTypeDD, planType);
	}

	public void selectSubscriber(String subscriber) throws Exception {
		By subscriberDD = By.id("retroFilter.selectedSubscriberId");
		selectDropDownElementByVisibleText("SubscriberDD", subscriberDD, subscriber);
	}

	public void clickOnSearch() throws Exception {
		By searchBtn = By.id("retroApplyFilter");
		clickOnElement("SearchBtn", searchBtn);
	}

	public void clickOnMemberAllChkBx() throws Exception {
		By memberAllChkBx = By.name("allMemberCheckBox");
		clickOnElement("MemberAllChkBx", memberAllChkBx);
	}

	public void clickOnVoidBtn() throws Exception {
		By voidBtn = By.xpath("//button[contains(.,'Void')]");
		clickOnElement("VoidBtn", voidBtn);
	}

	public void enterComments(int memIndex, String comments) throws Exception {
		By commentsTxt = By.id("activePlan[" + memIndex + "].retroEnrollComments");
		clickOnElement("CommentsBox", commentsTxt);
		clearAndType("CommentsTxt", commentsTxt, comments);
	}

	public void clickOnConfirmBtn() throws Exception {
		By confirmBtn = By.id("activePlan[0].activeVoidConfirm");
		clickOnElement("ConfirmBtn", confirmBtn);
	}

	public void clickOnReviewSummaryBtn() throws Exception {
		By reviewSummaryBtn = By.id("reviewSummary");
		clickOnElement("ReviewSummaryBtn", reviewSummaryBtn);
	}

	public void clickOnContinueChangesBtn() throws Exception {
		By continueChangesBtn = By.id("continueChanges");
		clickOnElement("ContinueChangesBtn", continueChangesBtn);
	}

	public void clickOnApplyChangesBtn() throws Exception {
		By applyChangesBtn = By.id("applyAllChangesFormButton");
		clickOnElement("ApplyChangesBtn", applyChangesBtn);
	}

	// Amrita
	public void takseScreenShot() throws Exception {
		waitForPageLoaded();
		takeScreenshot("Summary");
	}

	public boolean isWarningDialogPresent() throws Exception {
		return isElementPresent(warningDialogH2);
	}

	public void clickOnWarningOkButton() throws Exception {
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}

	// Amrita
	public void handleWarningDialogIfPresent() throws Exception {
		if (isWarningDialogPresent()) {
			clickOnWarningOkButton();
		}
	}

	public void performRetroVoid(int memIndex, String cmnts) throws Exception {
		RetroEnrollmentPage retroenroll = new RetroEnrollmentPage(driver, testCaseId);
		retroenroll.waitForPageLoaded();
		retroenroll.clickOnMemberAllChkBx();
		retroenroll.clickOnVoidBtn();
		retroenroll.enterComments(memIndex, cmnts);
		retroenroll.clickOnConfirmBtn();
		retroenroll.clickOnReviewSummaryBtn();
		retroenroll.waitForPageLoaded();
		retroenroll.clickOnApplyChangesBtn();
		retroenroll.waitForPageLoaded();
		retroenroll.takseScreenShot();
	}

	// Paul
	public String getSubscriber(String memNo) throws Exception {
		By subscriber = By.xpath("//*[@id='currentElgTable']/tbody[" + memNo + "]/tr[1]/th[1]/div/span");
		return getElementText(subscriber);
	}

	// Paul
	private void selectActiveMembersToOverride(int memIndex, Boolean override) throws Exception {
		By memOverrideCheckBox = By.id("activePlan[0].member[" + memIndex + "].activeCheckbox");

		if (override.equals(true)) {
			clickOnElement("OverrideCheckBox", memOverrideCheckBox);
		}
	}

	// Paul
	public void selectActiveMemberIfTrue(int memIndex, Boolean override) throws Exception {
		selectActiveMembersToOverride(memIndex, override);
	}

	// Paul
	private void clickOnActivePlanChangeEffectiveDateBtn() throws Exception {
		By ChangeEffectiveDateBtn = By.xpath("//*[@id='activePlan[0].activeChangeEffDateButton']");
		clickOnElement("Change Effective Date", ChangeEffectiveDateBtn);
	}

	// Paul
	private void clickOnActivePlanChangeStartDateBtn() throws Exception {
		By changeStartDateBtn = By.xpath("//*[@id='activePlan[0].activeChangeStartDate']");
		clickOnElement("Change Start Date", changeStartDateBtn);
	}

	// Paul
	private void clickOnActivePlanChangeEndDateBtn() throws Exception {
		By changeEndDateBtn = By.xpath("//*[@id='activePlan[0].activeChangeEndDate']");
		clickOnElement("Change End Date", changeEndDateBtn);
	}

	// Paul
	private void submitNewActivePlanDate(String submissionDate) throws Exception {
		By submissionDateTxt = By.xpath("//*[@id='activePlan[0].retroChangeEffectiveDate']");
		clearAndTypeAfterWait("Submit New Date", submissionDateTxt, submissionDate);
	}

	// Paul
	private void enterActivePlanComments(String comments) throws Exception {
		By commentsTxt = By.name("comments");
		enterText("CommentsTxt", commentsTxt, comments);
	}

	// Paul
	private void clickOnActivePlanConfirmBtn() throws Exception {
		By confirmBtn = By.xpath("//*[@id='activePlan[0].activeChangeEffDateConfirm']");
		clickOnElement("ConfirmBtn", confirmBtn);
	}

	// Paul
	public void validateActivePlanStartDate(String actualActivePlanStartDate) throws Exception {
		By actualActivePlanStartDateDD = By.xpath("//*[@id='label_expand_1']/span[2]/span");
		validateTextContains("Terminated End Date", actualActivePlanStartDateDD, actualActivePlanStartDate);
	}

	// Paul
	public void openTerminatedPlans() throws Exception {
		By terminatedPlans = By.xpath("//*[@id='label_expand_2']");
		clickOnElement("TerminatedPlans", terminatedPlans);
	}

	// Paul
	private void selectTerminatedMembersToOverride(int memIndex, Boolean override) throws Exception {
		By memOverrideCheckBox = By.id("terminatedPlan[0].member[" + memIndex + "].terminatedCheckbox");

		if (override.equals(true)) {
			clickOnElement("OverrideCheckBox", memOverrideCheckBox);
		}
	}

	// Paul
	public void selectTerminatedMemberIfTrue(int memIndex, Boolean override) throws Exception {
		selectTerminatedMembersToOverride(memIndex, override);
	}

	// Paul
	private void clickOnTerminatedPlanChangeEffectiveDateBtn() throws Exception {
		By ChangeEffectiveDateBtn = By.xpath("//*[@id='terminatedPlan[0].terminatedChangeEffDateButton']");
		clickOnElement("Change Effective Date", ChangeEffectiveDateBtn);
	}

	// Paul
	private void clickOnTerminatedPlanChangeStartDateBtn() throws Exception {
		By changeStartDateBtn = By.xpath("//*[@id='terminatedPlan[0].terminatedChangeStartDate']");
		clickOnElement("Change Start Date", changeStartDateBtn);
	}

	// Paul
	private void clickOnTerminatedPlanChangeEndDateBtn() throws Exception {
		By changeEndDateBtn = By.xpath("//*[@id='terminatedPlan[0].terminatedChangeEndDate']");
		clickOnElement("Change End Date", changeEndDateBtn);
	}

	// Paul
	private void submitNewTerminatedPlanDate(String submissionDate) throws Exception {
		By submissionDateTxt = By.xpath("//*[@id='terminatedPlan[0].retroChangeEffectiveDate']");
		clearAndTypeAfterWait("Submit New Date", submissionDateTxt, submissionDate);
	}

	// Paul
	private void enterTerminatedPlanComments(String comments) throws Exception {
		By commentsTxt = By.xpath("//*[@id='terminatedPlan[0].retroChangeEffectiveDateComments']");
		enterText("CommentsTxt", commentsTxt, comments);
	}

	// Paul
	private void clickOnTerminatedPlanConfirmBtn() throws Exception {
		By confirmBtn = By.xpath("//*[@id='terminatedPlan[0].terminatedChangeEffDateConfirm']");
		clickOnElement("ConfirmBtn", confirmBtn);
	}

	// Paul
	public void validateTerminatedPlanEndDate(String actualTerminatedPlanEndDate) throws Exception {
		By actualTerminatedEndDateDD = By.xpath("//*[@id='label_expand_2']/span[2]/span");
		validateTextContains("Terminated End Date", actualTerminatedEndDateDD, actualTerminatedPlanEndDate);
	}

	// Paul
	public void searchForActivePlans(String subscriber, String planYear, String planType) throws Exception {
		waitForPageLoaded();
		selectSubscriber(subscriber);
		selectPlanYear(planYear);
		selectPlanType(planType);
		clickOnSearch();
	}

	// Paul
	public void changeActivePlanStartDateForSelectedMember(String startDate) throws Exception {
		clickOnActivePlanChangeEffectiveDateBtn();
		clickOnActivePlanChangeStartDateBtn();
		submitNewActivePlanDate(startDate);
		enterActivePlanComments("Updated Active Plan Start Date");
		clickOnActivePlanConfirmBtn();
	}

	// Paul
	public void changeActivePlanEndDateForSelectedMember(String endDate) throws Exception {
		clickOnActivePlanChangeEffectiveDateBtn();
		clickOnActivePlanChangeEndDateBtn();
		submitNewActivePlanDate(endDate);
		enterActivePlanComments("Updated Active Plan End Date");
		clickOnActivePlanConfirmBtn();
	}

	// Paul
	public void changeTerminatedPlanStartDateForSelectedMember(String startDate) throws Exception {
		clickOnTerminatedPlanChangeEffectiveDateBtn();
		clickOnTerminatedPlanChangeStartDateBtn();
		submitNewTerminatedPlanDate(startDate);
		enterTerminatedPlanComments("Updated Terminated Plan Start Date");
		clickOnTerminatedPlanConfirmBtn();
		clickOnContinueChangesBtn();
		clickOnApplyChangesBtn();
	}

	// Paul
	public void changeTerminatedPlanEndDateForSelectedMember(String endDate) throws Exception {
		clickOnTerminatedPlanChangeEffectiveDateBtn();
		clickOnTerminatedPlanChangeEndDateBtn();
		submitNewTerminatedPlanDate(endDate);
		enterTerminatedPlanComments("Updated Terminated Plan End Date");
		clickOnTerminatedPlanConfirmBtn();
		clickOnContinueChangesBtn();
		clickOnApplyChangesBtn();
	}

}
