package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class FindAHealthOrDentalPlanPage extends CommonPage implements CommonPageOR{
	
	private static final By comparePlansBtn = By.xpath("//input[contains(@class,'viewComparison')]");
	private static final By sortPlanDD = By.id("sort_plans");
	private static final By goBtn = By.id("applysortfilterbutton");
	private static final By nextBtn = By.id("submitWithSave_1");
	private static final By applyBtn = By.id("applyFilter");
	
	private static final By backBtn = By.xpath("//input[contains(@class,'secondaryButton') and @value='Back']");
	private static final By applyForCoverageBtn = By.xpath("//input[contains(@class,'primaryButton') and @value='Apply for Coverage']");
	private static final String planRowXpath = "//table[@id='QuotesTable']/tbody/tr[contains(@class,'detailsContainer')]";
	

	private static final By planFinderTool = By.xpath("//input[@value='Plan Finder Tool']");
	private static final By removeDrug = By.xpath("//div[contains(@id,'drugDetail')][1]//button[contains(@id,'drugRemove')]");
	
	
	public FindAHealthOrDentalPlanPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void clickOnComparePlansBtn() throws Exception{
		clickOnElement("ComparePlansBtn", comparePlansBtn);
	}
	
	public void clickOnRemoveDrugBtn() throws Exception{
		clickOnElement("RemoveDrugBtn", removeDrug);
	}
	/**
	 * Accepted Value :- 
	 * 1.	"Monthly Premium - High to Low",
	 * 2.	"Monthly Premium - Low to High",
	 * 3. 	"Annual Deductible - High to Low",
	 * 4.	"Annual Deductible - Low to High"
	 * @param sortBy
	 * @throws Exception
	 */
	private void sortPlansBy(String sortBy) throws Exception{
		selectDropDownElementByVisibleText("SortPlan", sortPlanDD, sortBy);
	}
	
	private void clickOnGoBtn() throws Exception{
		clickOnElement("GoBtn", goBtn);
	}
	
	private void clickOnNextBtn() throws Exception{
		clickOnElement("NextBtn", nextBtn);
	}
	
	private void clickOnBackBtn() throws Exception{
		clickOnElement("BackBtn", backBtn);
	}
	
	private void clickOnApplyForCoverageBtn() throws Exception{
		clickOnElement("ApplyForCoverageBtn", applyForCoverageBtn);
	}
	
	private String getMonthlyPremiumForPlan(int planNo) throws Exception{
		By monthlyPremiumLabel = By.xpath(planRowXpath+"["+planNo+"]//span[@class='planPremiumInt']");
		return getElementText(monthlyPremiumLabel);
	}
	
	private String getPlanNameForPlan(int planNo) throws Exception{
		By planNameLabel = By.xpath(planRowXpath+"["+planNo+"]//div[contains(@class,'comparePlanSection')]/div[contains(@class,'boldTxt')]");
		return getElementText(planNameLabel);
	}
	
	public void validatePremiumAmount(String planName,String expValue) throws Exception{
		By premiumAmountTxt=By.xpath("//div[contains(text(),'"+planName+"')]/../../..//span[@class='currency inlineLabel displaypremium']");
		validateTextContains(planName, premiumAmountTxt, expValue);
		takeScreenshot("AnonymousBrowsingHealth");
	}
	
	//working with common method getPlanNameForPlan
	private String getHealthPlanNameForPlan(int planNo) throws Exception{
		By planNameLabel = By.xpath(planRowXpath+"["+planNo+"]//div[contains(@class,'comparePlanSection')]/div[contains(@class,'boldTxt')]");
		return getElementText(planNameLabel);
	}
	
	//working with common method getPlanNameForPlan
	private String getDentalPlanNameForPlan(int planNo) throws Exception{
		By planNameLabel = By.xpath(planRowXpath+"["+planNo+"]//a[contains(@class,'planDetails underLinetext')]");
		return getElementText(planNameLabel);
	}
	
	public void selectShoppingPlan(String planName) throws Exception{
	
		By planNameLabel 	=By.xpath("//input[@type='checkbox' and @value='"+planName+"']/../label");
		clickOnElement(planName, planNameLabel);
	}

	public void clickOnApplyBtn() throws Exception{
		clickOnElement("ApplyBtn", applyBtn);
	}
	
	public void clickOnPlanFinderToolBtn() throws Exception{
		clickOnElement("PlanFinderToolBtn", planFinderTool);
	}
	
	private void clickOnSelectToCompareForPlan(int planNo) throws Exception{
		By selectToCompareChkBx = By.xpath("//table[@id='QuotesTable']/tbody/tr[contains(@class,'greyPanelRow')]["+planNo+"]//input[@type='checkbox']");
		clickOnElement("Plan"+planNo + "SelectToCompareChkBx", selectToCompareChkBx);
	}
	
	private void clickOnAddToCartForPlan(int planNo) throws Exception{
		By addToCartBtn = By.xpath("//table[@id='QuotesTable']/tbody/tr["+planNo+"]//input[@value='Add To Cart']");
		clickOnElementThenWait("Plan"+planNo+"AddToCartBtn", addToCartBtn, 5);
	}
	
	
	
	public void verifyTypesofCov() throws Exception{
		By silverCov =By.xpath("//input[@value='SILVER' and @aria-checked='false']");
		By platinumCov =By.xpath("//input[@value='PLATINUM' and @aria-checked='false']");
		By bronzeCov =By.xpath("//input[@value='BRONZE' and @aria-checked='false']");
		By goldCov =By.xpath("//input[@value='GOLD' and @aria-checked='false']");
		
		validateElementPresent("SilverCoverage", silverCov);
		validateElementPresent("PlatinumCoverage", platinumCov);
		validateElementPresent("BronzeCoverage", bronzeCov);
		validateElementPresent("GoldCoverage", goldCov);
		takeScreenshot("AnonymousBrowsingHealth");
	}
	
	public void validateAnonymousHealth(String plan ,String amount) throws Exception{
		By deductible = By.xpath("//div[contains(@class,'annualDed dataWrappe')]//span[contains(.,'"+plan+"')]/..//span[contains(.,'2,000')]");
	
		validateElementPresent(plan,deductible);
	}

	private void clickOnRemoveFromCartForPlan(int planNo) throws Exception{
		By removeFromCartBtn = By.xpath("//table[@id='QuotesTable']/tbody/tr["+planNo+"]//input[@value='Remove']");
		clickOnElementThenWait("Plan"+planNo+"RemoveFromCartBtn", removeFromCartBtn, 5);
	}
	
	public boolean isWarningDialogPresent() throws Exception{
		return isElementPresent(warningOkButton);
	}
	
	public void clickOnWarningOkButton() throws Exception{
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}
	
	public void handleWarningDialogIfPresent() throws Exception{
		if(isWarningDialogPresent()){
			clickOnWarningOkButton();
		}
	}
	
	public void findAHealthPlanPageLoadAndClickOnAddToCart(int planNo) throws Exception{
		FindAHealthPlanPage findAHealthPlanPage = new FindAHealthPlanPage(driver, testCaseId);
		findAHealthPlanPage.waitForPageLoaded();
		clickOnAddToCartForPlan(planNo);
	}
	
	public void findADentalPlanPageLoadAndClickOnAddToCart(int planNo) throws Exception{
		FindADentalPlanPage findADentalPlanPage = new FindADentalPlanPage(driver, testCaseId);
		findADentalPlanPage.waitForPageLoaded();
		clickOnAddToCartForPlan(planNo);
	}
	
	public void findAHealthPlanPageLoadAndClickOnRemoveFromCartBtn() throws Exception{
		FindAHealthPlanPage findAHealthPlanPage = new FindAHealthPlanPage(driver, testCaseId);
		findAHealthPlanPage.waitForPageLoaded();
		clickOnRemoveFromCartForPlan(1);
	}
	
	public void findADentalPlanPageLoadAndClickOnRemoveFromCartBtn() throws Exception{
		FindADentalPlanPage findADentalPlanPage = new FindADentalPlanPage(driver, testCaseId);
		findADentalPlanPage.waitForPageLoaded();
		clickOnRemoveFromCartForPlan(1);
	}
	
	public void validateComparePlanDetails() throws Exception{
		validateHealthPlanDetailsOnComparePlanPage();
		clickOnNextBtn();
		validateDentalPlanDetailsOnComparePlanPage();
	}
	
	private void validateHealthPlanDetailsOnComparePlanPage() throws Exception{
		FindAHealthPlanPage findAHealthPlanPage = new FindAHealthPlanPage(driver, testCaseId);
		findAHealthPlanPage.waitForPageLoaded();
		String plan1MonthlyPremium = getMonthlyPremiumForPlan(1);
		String plan2MonthlyPremium = getMonthlyPremiumForPlan(2);
		
		String plan1Name = getPlanNameForPlan(1);
		String plan2Name = getPlanNameForPlan(2);
		//Taking substring because some plan names are trims after 40 letters.
		if(plan1Name.length() > 40){
			plan1Name = plan1Name.substring(0, 39);
		}
		if(plan2Name.length() > 40){
			plan2Name = plan2Name.substring(0, 39);
		}
		
		clickOnSelectToCompareForPlan(1);
		clickOnSelectToCompareForPlan(2);
		takeScreenshot("FindAHealthPlan");
		clickOnComparePlansBtn();
		
		ComparePlansPage comparePlansPage = new ComparePlansPage(driver, testCaseId);
		comparePlansPage.waitForPageLoaded();
		comparePlansPage.validateDetailsForPlan(1, plan1Name, plan1MonthlyPremium);
		comparePlansPage.validateDetailsForPlan(2, plan2Name, plan2MonthlyPremium);
		takeScreenshot("CompareHealthPlan");
		comparePlansPage.clickOnBackToPlanListBtn();
	}
	
	public void validateHealthPlanDetailsForThreePlansOnComparePlanPage() throws Exception{
		FindAHealthPlanPage findAHealthPlanPage = new FindAHealthPlanPage(driver, testCaseId);
		findAHealthPlanPage.waitForPageLoaded();
		String plan1MonthlyPremium = getMonthlyPremiumForPlan(1);
		String plan2MonthlyPremium = getMonthlyPremiumForPlan(2);
		String plan3MonthlyPremium = getMonthlyPremiumForPlan(3);
		
		String plan1Name = getPlanNameForPlan(1);
		String plan2Name = getPlanNameForPlan(2);
		String plan3Name = getPlanNameForPlan(3);
		//Taking substring because some plan names are trims after 40 letters.
		if(plan1Name.length() > 40){
			plan1Name = plan1Name.substring(0, 39);
		}
		if(plan2Name.length() > 40){
			plan2Name = plan2Name.substring(0, 39);
		}
		if(plan3Name.length() > 40){
			plan3Name = plan3Name.substring(0, 39);
		}
		
		clickOnSelectToCompareForPlan(1);
		clickOnSelectToCompareForPlan(2);
		clickOnSelectToCompareForPlan(3);
		takeScreenshot("FindAHealthPlan");
		clickOnComparePlansBtn();
		
		ComparePlansPage comparePlansPage = new ComparePlansPage(driver, testCaseId);
		comparePlansPage.waitForPageLoaded();
		comparePlansPage.validateDetailsForPlan(1, plan1Name, plan1MonthlyPremium);
		comparePlansPage.validateDetailsForPlan(2, plan2Name, plan2MonthlyPremium);
		comparePlansPage.validateDetailsForPlan(3, plan3Name, plan3MonthlyPremium);
		takeScreenshot("CompareHealthPlan");
		comparePlansPage.clickOnBackToPlanListBtn();
	}
	
	
	private void validateDentalPlanDetailsOnComparePlanPage() throws Exception{
		FindADentalPlanPage findADentalPlanPage = new FindADentalPlanPage(driver, testCaseId);
		findADentalPlanPage.waitForPageLoaded();
		String plan1MonthlyPremium = getMonthlyPremiumForPlan(1);
		String plan2MonthlyPremium = getMonthlyPremiumForPlan(2);

		String plan1Name = getPlanNameForPlan(1);
		String plan2Name = getPlanNameForPlan(2);
		
		//Taking substring because some plan names are trims after 40 letters.
		if(plan1Name.length() > 40){
			plan1Name = plan1Name.substring(0, 39);
		}
		if(plan2Name.length() > 40){
			plan2Name = plan2Name.substring(0, 39);
		}
		
		clickOnSelectToCompareForPlan(1);
		clickOnSelectToCompareForPlan(2);
		takeScreenshot("FindADentalPlan");
		clickOnComparePlansBtn();
		
		ComparePlansPage comparePlansPage = new ComparePlansPage(driver, testCaseId);
		comparePlansPage.waitForPageLoaded();
		comparePlansPage.validateDetailsForPlan(1, plan1Name, plan1MonthlyPremium);
		comparePlansPage.validateDetailsForPlan(2, plan2Name, plan2MonthlyPremium);
		takeScreenshot("CompareDentalPlan");
		comparePlansPage.clickOnBackToPlanListBtn();
	}
}
