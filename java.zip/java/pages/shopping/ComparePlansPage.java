package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class ComparePlansPage extends CommonPage{
	
	private static final By comparePlansPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Compare plans')]");
	private static final By backToPlanListBtn = By.xpath("//input[@value='Back to Plan List']");
	
	
	public ComparePlansPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ComparePlansPageHeader", comparePlansPageHeader);
	}
	
	public void clickOnBackToPlanListBtn() throws Exception{
		clickOnElement("BackToPlanListBtn", backToPlanListBtn);
	}
	
	//#################### Click ON TAB STARTS ################################################
	//
	public void clickOnPlanDetailsTab() throws Exception{
		By planDetailsTab = By.xpath("//button[contains(text(),'Plan Details')]");
		clickOnElement("PlanDetailsTab", planDetailsTab);
	}
	
	//TODO: Do for other Tabs
	//
	//#################### Click ON TAB END ################################################
	
	//#################### Function Under Plan Details Tab STARTS ################################################
	//
	public void validateMaxOOP_For_MedDrugIndividualPlanNameForPlan_UnderPlanDetailsTab(String expAbc) throws Exception{
		By abcLabel = By.xpath("//h2[button[button[contains(text(),'Plan Details')]]]/following-sibling::div[1]//div[text()='Maximum Out of Pocket for Medical and Drug EHB Benefits (Total) - Individual']/ancestor::tr/td[1]/div");
		validateTextEquals("abcLabel", abcLabel, expAbc);
	}
	
	// TODO: FOr other Fields
	// 
	//#################### Function Under Plan Details Tab END ################################################
	
	private void validatePlanNameForPlan(int planNo, String expPlanName) throws Exception{
		By planNameLabel = By.id("planTitleHead_"+planNo);
		validateTextContains("Plan"+planNo+"Name", planNameLabel, expPlanName);
	}
	
	private void validateMonthlyPremiumForPlan(int planNo, String monthlyPremium) throws Exception{
		By monthlyPremiumLabel = By.xpath("//div[@id='quotes']//li["+planNo+"]//span[@class='premiumInt']");
		validateTextContains("Plan"+planNo+"MonthlyPremium", monthlyPremiumLabel, monthlyPremium);
	}
	
	public void validateDetailsForPlan(int planNo, String expPlanName, String monthlyPremium) throws Exception{
		validatePlanNameForPlan(planNo, expPlanName);
		validateMonthlyPremiumForPlan(planNo, monthlyPremium);
	}
	
}
