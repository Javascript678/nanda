package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class PlanFinderToolPage extends CommonPage{
	
	private static final By planFinderToolPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Plan Finder Tool')]");
	private static final By helpFindingAPlanAsYesBtn = By.id("c_eligibility_benefits_0");
	private static final By helpFindingAPlanAsNoBtn = By.xpath("//label[@for='c_eligibility_benefits_1']");
	private static final By preferredProviders= By.name("providerFlow");
	private static final By preferredPrescription= By.name("formularyFlow");
	private static final By continueBtn = By.xpath("//input[@value='Continue']");
	

	
	public PlanFinderToolPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("PlanFinderToolPageHeader", planFinderToolPageHeader);
	}
	
	public void takeScreenshot() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Plan Finder Tool Page");
	}
	
	private void clickOnHelpFindingAPlanAsYesBtn() throws Exception{
		clickOnElement("HelpFindingAPlanAsYesBtn", helpFindingAPlanAsYesBtn);
	}
	
	private void validatePreferredProvidersIsPresent() throws Exception{
		waitForPresenceOfElementLocated("Preferred Providers Present",preferredProviders);
	}
	
	private void validatePreferredPrescriptionsIsPresent() throws Exception{
		waitForPresenceOfElementLocated("Preferred Prescriptions Present",preferredPrescription);
	}
	
	private void selectPreferredProviders() throws Exception{
		clickOnElement("My Preferred Providers and Facilities", preferredProviders);
	}
	
	private void selectPreferredPrescription() throws Exception{
		clickOnElement("My Preferred Prescription Drugs", preferredPrescription);
	}
	
	private void clickOnHelpFindingAPlanAsNoBtn() throws Exception{
		clickOnElementThenWait("HelpFindingAPlanAsNoBtn", helpFindingAPlanAsNoBtn, 2);
	}
	
	private void clickOnContinueBtn() throws Exception{
		clickOnElementThenWait("ContinueBtn", continueBtn, 5);
	}
	
	public void clickContinue() throws Exception{
		waitForPageLoaded();
		clickOnContinueBtn();
	}
	
	public void pageLoadAndSkipPlanShopping() throws Exception{
		waitForPageLoaded();
		clickOnHelpFindingAPlanAsNoBtn();
		clickOnContinueBtn();
	}
	
	public void validateProvidersAndPrescriptionsIsPresent() throws Exception{
		waitForPageLoaded();
		clickOnHelpFindingAPlanAsYesBtn();
		validatePreferredProvidersIsPresent();
		validatePreferredPrescriptionsIsPresent();
		takeScreenshot();
	}
	
	public void selectProvidersAndPrescriptionsThenContinue() throws Exception{
		waitForPageLoaded();
		clickOnHelpFindingAPlanAsYesBtn();
		selectPreferredProviders();
		selectPreferredPrescription();
		takeScreenshot();
		clickOnContinueBtn();
	}
	
	public void selectPrescriptionsThenContinue() throws Exception{
		waitForPageLoaded();
		clickOnHelpFindingAPlanAsYesBtn();
		selectPreferredPrescription();
		takeScreenshot();
		clickOnContinueBtn();
	}
	
	
}
