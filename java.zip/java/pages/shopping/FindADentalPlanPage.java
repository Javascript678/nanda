package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class FindADentalPlanPage extends CommonPage{
	
	private static final By findADentalPlanPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Find a Dental Plan')]");
	
	public FindADentalPlanPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("FindADentalPlanPageHeader", findADentalPlanPageHeader);
	}
	
}
