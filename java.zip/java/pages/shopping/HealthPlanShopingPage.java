package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class HealthPlanShopingPage extends CommonPage implements CommonPageOR{
	
	private static final By healthPlanShoppingPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Health Plan Shopping')]");
	private static final By continueBtn = By.id("planSelectionContinue");
	private static final By backBtn = By.id("planSelectionPrevious");
	private static final By crateShoppingGroupBtn = By.id("reEvaluate");
    private static final By undoShoppingGroupChangesBtn = By.id("undoShoppingGroup");

	
	public HealthPlanShopingPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("HealthPlanShoppingPageHeader", healthPlanShoppingPageHeader);
	}
	
	public void takeScreenshot() throws Exception{
		takeScreenshot("Summary");
	}
	
	private void clickOnFindAPlanForCurrentYearForShoopingGrp(int shoppingGrpNo) throws Exception{
		By findAPlanForCurrentYear = By.id("btnFindPlan_"+ shoppingGrpNo);
		clickOnElement("ShpGrp"+shoppingGrpNo+"_FindAHltPlanForCurrentYear", findAPlanForCurrentYear);
	}
	
	private void clickOnRemoveExistingPlanForShoopingGrp(int shoppingGrpNo) throws Exception{
		By removeExistingPlan = By.xpath("//div[contains(@id,'memberContainer')]["+shoppingGrpNo+"]//table[contains(@class,'planNonTable ')]//td[@class='lastCol']//a");
		clickOnElementThenWait("ShpGrp"+shoppingGrpNo+"_RemoveExistingPlan", removeExistingPlan,3);
	}
	
	private boolean isThereAnyExistingPlanForShoopingGrp(int shoppingGrpNo) throws Exception{
		By removeExistingPlan = By.xpath("//div[contains(@id,'memberContainer')]["+shoppingGrpNo+"]//table[contains(@class,'planNonTable ')]//td[@class='lastCol']//a");
		return isElementPresent(removeExistingPlan,3);
	}
	
	public void validateMembersInShoppingGroup(int shoppingGrpNo,String expectedMember) throws Exception{
        By shoppingGrpMemberNameLabel = By.xpath("//*[@id='healthPlan_"+shoppingGrpNo+"']//following-sibling::div[1]");
        validateTextContains("Shopping GRP_"+shoppingGrpNo, shoppingGrpMemberNameLabel, expectedMember);
    }
	
	//Ritu 
	public void validateFindAPlanForCurrentYearForShoopingGrpIsPresent(int shoppingGrpNo) throws Exception{
		By findAPlanForCurrentYear = By.id("btnFindPlan_"+ shoppingGrpNo);
		validateElementPresent("ShpGrp"+shoppingGrpNo+"_FindAHltPlanForCurrentYear", findAPlanForCurrentYear);
	}
		
	private void clickOnContinueBtn() throws Exception{
		clickOnElement("ContinueBtn", continueBtn);
	}
	
	private void clickOnBackBtn() throws Exception{
		clickOnElement("BackBtn", backBtn);
	}
	
	private void clickOnCreateShoppingGroupBtn() throws Exception{
        clickOnElement("CreateShoppingGroupBtn", crateShoppingGroupBtn);
	}
  
	public void clickOnUndoShoppingGroupChangesBtn() throws Exception{
        clickOnElement("UndoShoppingGroupChangesBtn", undoShoppingGroupChangesBtn);
	}
	private void  clickOnWarningPopBtn() throws Exception{
        clickOnElement("WarningPopUp",warningOkButton);
	}
  
	public void  clickOnCancelWarningPopBtn() throws Exception{
        clickOnElement("CancelWaringPopUp ",alertCancelButton );
	}
  
	public void  validateWarningPopBtn() throws Exception{
        validateElementPresent("WarningPopUp",warningOkButton);
	}

	public void clickOnCreateShoppingGroup() throws Exception{
        waitForPageLoaded();
        clickOnCreateShoppingGroupBtn();
	}
  
  public void clickOnUndoShoppingGroupChanges() throws Exception{
        waitForPageLoaded();
        clickOnCreateShoppingGroupBtn();
  	}
  public void clickOnWarningPopup() throws Exception{
        waitForPageLoaded();
        clickOnWarningPopBtn();
  	}

	public void clickOnFindAPlanForShoppingGrp(int shoppingGrpNo) throws Exception{
		waitForPageLoaded();
		if(isThereAnyExistingPlanForShoopingGrp(shoppingGrpNo)){
			clickOnRemoveExistingPlanForShoopingGrp(shoppingGrpNo);
		}
		clickOnFindAPlanForCurrentYearForShoopingGrp(shoppingGrpNo);
	}
	
	public void clickOnRemoveExistingPlaForShoppingGrpAndContinue(int shoppingGrpNo) throws Exception{
		waitForPageLoaded();
		clickOnRemoveExistingPlanForShoopingGrp(shoppingGrpNo);
		clickOnContinueBtn();
	}
	
	public void pageLoadAndClickOnContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnContinueBtn();
	}
	
	
}
