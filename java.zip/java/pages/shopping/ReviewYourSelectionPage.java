package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//import com.gargoylesoftware.htmlunit.javascript.host.Element;

import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class ReviewYourSelectionPage extends CommonPage implements CommonPageOR{
	
	private static final By reviewYourSelectionPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Review Your Selection')]");
	private static final By addMoreDrugsBtn = By.xpath("//button[contains(.,'Add More Drugs')]");
	private static final By drugChkBox = By.xpath("//table[@id='formularyList']/tbody/tr[1]//input[@type='checkbox']");
	private static final By removeBtn = By.xpath("//button[contains(.,'Remove')]");
	private static final By skipThisStepBtn = By.xpath("//a[contains(.,'Skip this Step')]");
	private static final By showPlansBtn = By.xpath("//button[contains(.,'Show Plans')]");
	
	
	public ReviewYourSelectionPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ReviewYourSelectionPageHeader", reviewYourSelectionPageHeader);
	}
	
	public void clickOnContinueWarningMsg() throws Exception{
		clickOnElementThenWait("ContinueWarningMsg", warningOkButton, 5);
	}
	
	public void clickOnSkipThisStepWarningMsg() throws Exception{
		clickOnElementThenWait("SkipThisStepWarningMsg", popupNoBtn, 5);
	}
	
	public void clickOnRemoveBtn() throws Exception{
		clickOnElement("RemoveDrugBtn", removeBtn);
	}
	
	public void clickOnShowPlanBtn() throws Exception{
		clickOnElement("ShowPlansBtn", showPlansBtn);
	}
	
	public void clickOnDrugChkBx() throws Exception{
		clickOnElement("DrugCheckBox", drugChkBox);
	}
	
	public void takeScreenshot(String text) throws Exception{
		waitForPageLoaded();
		takeScreenshot(text);
	}
	
	
	
	public void clickOnSkipBtn() throws Exception{
		clickOnElement("SkipThisStepBtn", skipThisStepBtn);
	}
	
	private void clickOnBackBtn() throws Exception{
		clickOnElement("BackBtn", backBtn);
	}
	
	public void clickOnAddMoreDrugsBtn() throws Exception{
		clickOnElementThenWait("AddBtn", addMoreDrugsBtn,3);
	}

}
	
	