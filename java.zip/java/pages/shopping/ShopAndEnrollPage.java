package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class ShopAndEnrollPage extends CommonPage{
	
	private static final By shopAndEnrollPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Shop & Enroll')]");
	private static final By continueBtn = By.id("findPlan");
	
	public ShopAndEnrollPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ShopAndEnrollPageHeader", shopAndEnrollPageHeader);
	}
	
	
	private void clickOnContinueBtn() throws Exception{
		clickOnElement("ContinueBtn", continueBtn);
	}
	
	public void pageLoadAndClickOnSaveAndContinue() throws Exception{
		waitForPageLoaded();
		clickOnContinueBtn();
	}
	
	
}
