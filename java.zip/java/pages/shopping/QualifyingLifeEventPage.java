package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.enrollment.Enrollment_Data;
import appdata.evpd.EVPD_Data;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class QualifyingLifeEventPage extends CommonPage implements CommonPageOR {

	private static final By QLEPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Qualifying Life Events')]");

	public QualifyingLifeEventPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocatedThenWait("QLEPageHeader", QLEPageHeader, 5);
	}

	public void selectIfAnyMemMoveToMA(boolean truFalseValue) throws Exception {
		By memMoveToMARdBtn = By.xpath("//input[@type='radio' and @value='"+truFalseValue+"' and @class='addressChange required']/../label");
		clickOnElement("MoveToMARdBtn"+truFalseValue, memMoveToMARdBtn);
	}

	public void selectIfAnyMemMoveToMAWithPrevMH(boolean truFalseValue) throws Exception {
		By memMoveToMAWithMHPreviouslyRdBtn = By.xpath("//input[@name='elgModification.addressChangeInHh' and @value='" + truFalseValue + "']/../label");
		clickOnElement("MoveToMARdBtn", memMoveToMAWithMHPreviouslyRdBtn);
	}
	
	public void selectMemberMovedMA(int memIndex) throws Exception {
		By memberMovedMAChkBx = By.name("elgModification.elgMemberModifications[" + memIndex + "].memberMovedMA");
		clickOnElement("Mem" + (memIndex) + "MemberMovedMA", memberMovedMAChkBx);
	}
	
	public void selectMoveToMa(int memIndex, String date) throws Exception {
		By moveToMaDtTxt = By.name("elgModification.elgMemberModifications[" + memIndex + "].moveToMaDt");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "MoveToMa", moveToMaDtTxt, date);
	}

	public void selectIfAnyMemLoseHIOrExpToLoseWithPrevMH(boolean truFalseValue) throws Exception {
		By loseHIWithMHPreviouslyRdBtn = By.xpath("//input[@name='elgModification.heathCovChangeInHhDynamic' and @value='" + truFalseValue + "']/../label");
		clickOnElement("LoseHIWithPrevMHRdBtn", loseHIWithMHPreviouslyRdBtn);
	}
	
	public void selectIfAnyMemLoseHIOrExpToLose(boolean truFalseValue) throws Exception {
		By loseHIRdBtn = By.xpath("//input[@name='elgModification.heathCovChangeInHh' and @value='" + truFalseValue + "']/../label");
		clickOnElement("LoseHIRdBtn", loseHIRdBtn);
	}

	public void selectMemberLostCoverage(int memIndex) throws Exception {
		By memLostCoverageChkBx = By.name("elgModification.elgMemberModifications[" + memIndex + "].lostOtherCoverage");
		clickOnElement("Mem" + (memIndex + 1) + "LostCoverageChkBx", memLostCoverageChkBx);
	}

	public void selectMemberLostCoverageDate(int memIndex, String date) throws Exception {
		By memLostCoverageEndDateTxt = By.name("elgModification.elgMemberModifications[" + memIndex + "].hltCoverageEndDate");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "LostCoverageEndDateTxt", memLostCoverageEndDateTxt, date);
	}
	
	public void selectNotPayingPremiums(int memIndex, boolean truFalseValue) throws Exception {
		By notPayingPremiumsBtn = By.xpath("//input[@name='elgModification.elgMemberModifications[" + memIndex + "].notPaidPremium' and @value='" + truFalseValue + "']/../label");
		clickOnElement("NotPayingPremiumsBtn", notPayingPremiumsBtn);
	}
	
	public void selectCanceledHealthInsurance(int memIndex, boolean truFalseValue) throws Exception {
		By canceledHealthInsuranceBtn = By.xpath("//input[@name='elgModification.elgMemberModifications[" + memIndex + "].cancelCoverage' and @value='" + truFalseValue + "']/../label");
		clickOnElement("CanceledHealthInsurance", canceledHealthInsuranceBtn);
	}

	public void selectIfAnyMemDependentStatusGotChanged(boolean truFalseValue) throws Exception {
		By dependentChangeRdBtn = By.xpath("//input[@name='elgModification.dependentChangeInHh' and @value='" + truFalseValue + "']/../label");
		clickOnElement("DependentChangeRdBtn", dependentChangeRdBtn);
	}

	public void selectIfAnyMemMarriageStatusGotChanged(boolean truFalseValue) throws Exception {
		By marriageChangeRdBtn = By.xpath("//input[@name='elgModification.marriageInHh' and @value='" + truFalseValue + "']/../label");
		clickOnElement("MarriageChangeRdBtn", marriageChangeRdBtn);
	}
		
	public void selectMarried(int memIndex) throws Exception {
		By marriedChkBx = By.name("elgModification.elgMemberModifications[" + memIndex + "].married");
		clickOnElement("Mem" + (memIndex) + "MarriedChkBx", marriedChkBx);
	}
	
	public void selectMarriageDate(int memIndex, String date) throws Exception {
		By marriageDateTxt = By.name("elgModification.elgMemberModifications[" + memIndex + "].dateOfMarriage");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "MarriageDateTxt", marriageDateTxt, date);
	}

	public void selectIfAnyMemAddedDueToBirth(boolean truFalseValue) throws Exception {
		By memAddedDueToBirthRdBtn = By.xpath("//input[@name='elgModification.birthInHh' and @value='" + truFalseValue + "']/../label");
		clickOnElement("MemAddedDueToBirthRdBtn", memAddedDueToBirthRdBtn);
	}
	
	public void selectBirth(int memIndex) throws Exception {
		By birthChkBx = By.name("elgModification.elgMemberModifications[" + memIndex + "].birth");
		clickOnElement("Mem" + (memIndex) + "BirthChkBx", birthChkBx);
	}
	
	public void selectDateOfBirth(int memIndex, String date) throws Exception {
		By dateOfBirthTxt = By.name("elgModification.elgMemberModifications[" + memIndex + "].dateOfBirth");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "DateOfBirthTxt", dateOfBirthTxt, date);
	}

	public void selectIfAnyMemAddedDueToFosterCare(boolean truFalseValue) throws Exception {
		By memAddedDueToFosterCareRdBtn = By.xpath("//input[@name='elgModification.fosterCareInHh' and @value='" + truFalseValue + "']/../label");
		clickOnElement("MemAddedDueToFosterCareRdBtn", memAddedDueToFosterCareRdBtn);
	}

	public void selectMemAddedDueToFosterCare(String fName, String lName) throws Exception {
		By memCheckBox = By.xpath("//div[contains(@id,'fosterCareInHh')]//label[contains(text(), '" + fName + "') and contains(text(), '" + lName + "')]/../input[contains(@id,'fosterCareCheckBox')]");
		clickOnElement("FosterChangeMemCheckBx", memCheckBox);
	}

	public void selectFosterMemDate(String fName, String lName, String date) throws Exception {
		By fosterCareDateTxt = By.xpath("//label[contains(text(),'" + fName + "') and contains(text(),'" + lName + "')]/following::div[contains(@id,'fosterCare')]/following::input[contains(@id,'fosterCareDate') and @type='tel']");
		clearAndTypeAfterWait("FosterCareDateTxt", fosterCareDateTxt, date);
	}

	public void selectIfAnyMemImmStatusGotChanged(boolean truFalseValue) throws Exception { 
		By immigrationChangeRdBtn = By.xpath("//input[@name='elgModification.immigrationChangeInHh' and @value='" + truFalseValue + "']/../label");
		clickOnElement("ImmigrationChangeRdBtn", immigrationChangeRdBtn);
	}
	
	public void selectImmigrationStatusGained(int memIndex) throws Exception {
		By immigrationStatusGainedChkBx = By.name("elgModification.elgMemberModifications[" + memIndex + "].immigrationChange");
		clickOnElement("Mem" + (memIndex) + "ImmigrationStatusGained", immigrationStatusGainedChkBx);
	}
	
	public void selectImmigrationChangeDate(int memIndex, String date) throws Exception {
		By immigrationChangeDtTxt = By.name("elgModification.elgMemberModifications[" + memIndex + "].immigrationChangeDt");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "ImmigrationChangeDtTxt", immigrationChangeDtTxt, date);
	}

	public void selectIfAnyMemAddressGotChanged(boolean truFalseValue) throws Exception {
		By addressChangeRdBtn = By.xpath("//input[@name='elgModification.addressChangeInHh' and @value='" + truFalseValue + "']/../label");
		clickOnElement("AddressChangeRdBtn", addressChangeRdBtn);
	}

	public void selectMemberMovedToMA(int memIndex) throws Exception {
		By memMovedToMAChkBx = By.name("elgModification.elgMemberModifications[" + memIndex + "].memberMovedMA");
		clickOnElement("Mem" + (memIndex + 1) + "MovedToMAChkBx", memMovedToMAChkBx);
	}

	public void selectMemberMovedToMAWithPrevMH(int memIndex) throws Exception {
		By memMovedToMAPrevMHChkBx = By.name("elgModification.elgMemberModifications[" + memIndex + "].memberMovedMALSC");
		clickOnElement("Mem" + (memIndex + 1) + "MovedToMAChkBx", memMovedToMAPrevMHChkBx);
	}

	public void selectMemberMovedToMADate(int memIndex, String date) throws Exception {
		By memMovedToMADateTxt = By.name("elgModification.elgMemberModifications[" + memIndex + "].moveToMaDt");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "MovedToMADateTxt", memMovedToMADateTxt, date);
	}

	public void selectMemberMovedToMADateWithPrevMH(int memIndex, String date) throws Exception {
		By memMovedToMAPrevMHDateTxt = By.name("elgModification.elgMemberModifications[" + memIndex + "].moveToMaDtLSC");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "MovedToMADateTxt", memMovedToMAPrevMHDateTxt, date);
	}

	public void selectIfAnyMemIncarcerationStatusGotChanged(boolean truFalseValue) throws Exception {
		By incarcerationChangeRdBtn = By.xpath("//input[@name='elgModification.incarcerationChangeInHh' and @value='" + truFalseValue + "']/../label");
		clickOnElement("IncarcerationChangeRdBtn", incarcerationChangeRdBtn);
	}

	public void selectMemberReleasedFromJail(int memIndex) throws Exception {
		By memReleasedFromJailChkBx = By.name("elgModification.elgMemberModifications[" + memIndex + "].memberNoLongerIncarcerated");
		clickOnElement("Mem" + (memIndex + 1) + "ReleasedFromJailChkBx", memReleasedFromJailChkBx);
	}

	public void selectMemberReleasedFromJailDate(int memIndex, String date) throws Exception {
		By memReleasedFromJailDateTxt = By.name("elgModification.elgMemberModifications[" + memIndex + "].dateOfNoLongerIncarcerated");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "ReleasedFromJailDateTxt", memReleasedFromJailDateTxt, date);
	}

	public void selectIfAnyMemDomesticAbuseStatusGotChanged(boolean truFalseValue) throws Exception {
		By domesticAbuseChangeRdBtn = By.xpath("//input[@name='elgModification.domesticAbuse' and @value='" + truFalseValue + "']/../label");
		clickOnElement("DomesticAbuseChangeRdBtn", domesticAbuseChangeRdBtn);
	}

	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}

	public void takeScreenshot() throws Exception {
		takeScreenshot("QLE_Page");
	}

	// QLE Question 1
	public void enterMemberHIChangeDetail(int memIndex, String coverageEndDate) throws Exception {
		selectIfAnyMemLoseHIOrExpToLose(true);
		selectMemberLostCoverage(memIndex);
		selectMemberLostCoverageDate(memIndex, coverageEndDate);
	}

	// QLE Question 2
	public void enterMemberDependentChange(String fName, String lName, String fosterDate) throws Exception {
		selectIfAnyMemDependentStatusGotChanged(true);
		selectIfAnyMemMarriageStatusGotChanged(false);
		selectIfAnyMemAddedDueToBirth(false);
		selectIfAnyMemAddedDueToFosterCare(true);
		selectMemAddedDueToFosterCare(fName, lName);
		selectFosterMemDate(fName, lName, fosterDate);
	}

	// QLE Question 3
	public void enterMemberImmigrationChange() throws Exception {
		selectIfAnyMemImmStatusGotChanged(true);
	}

	// QLE Question 4
	public void enterMemberMoveToMADetail(int memIndex, String moveToMAdate) throws Exception {
		selectIfAnyMemMoveToMA(true);
		selectMemberMovedToMA(memIndex);
		selectMemberMovedToMADate(memIndex, moveToMAdate);
	}

	// QLE Question 5
	public void enterMemberIncarcerationChangeDetail(int memIndex, String releazedFromJailDate) throws Exception {
		selectIfAnyMemIncarcerationStatusGotChanged(true);
		selectMemberReleasedFromJail(memIndex);
		selectMemberReleasedFromJailDate(memIndex, releazedFromJailDate);
	}

	// QLE Question 6
	public void enterMemberDomesticAbuseDetails() throws Exception {
		selectIfAnyMemDomesticAbuseStatusGotChanged(true);
	}

	// QLE Question 7
	public void enterMemberHIChangeDetailWithPrevMH(int memIndex, String coverageEndDate) throws Exception {
		selectIfAnyMemLoseHIOrExpToLoseWithPrevMH(true);
		selectMemberLostCoverage(memIndex);
		selectMemberLostCoverageDate(memIndex, coverageEndDate);
	}

	// QLE Question 8
	public void enterMemberMoveToMAWithPrevMH(int memIndex, String moveToMAdate) throws Exception {
		selectIfAnyMemMoveToMAWithPrevMH(true);
		selectMemberMovedToMAWithPrevMH(memIndex);
		selectMemberMovedToMADateWithPrevMH(memIndex, moveToMAdate);
	}
	
	public void completeQLEDetails(EVPD_Data evpdData, Enrollment_Data enrollmentData) throws Exception {
		//CurrentYearEligibilityResultPage currentYearEligibilityResultPage=new CurrentYearEligibilityResultPage();
		//currentYearEligibilityResultPage.gotoQLEPage();
		
		QualifyingLifeEventPage qualifyingLifeEventPage = new QualifyingLifeEventPage(driver, testCaseId);
		System.out.println(enrollmentData.memsData.get(0).loseHiCoverage);
		
		
		
		if(enrollmentData.memsData.get(0).loseHiCoverage){
			for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
				qualifyingLifeEventPage.selectMemberLostCoverage(memIndex);
				qualifyingLifeEventPage.selectMemberLostCoverageDate(memIndex, enrollmentData.appDate);
				qualifyingLifeEventPage.selectNotPayingPremiums(memIndex, enrollmentData.memsData.get(0).notPayingPremiums);
				qualifyingLifeEventPage.selectCanceledHealthInsurance(memIndex, enrollmentData.memsData.get(0).healthInsurance);
			}				
		}else{
			qualifyingLifeEventPage.selectIfAnyMemLoseHIOrExpToLose(enrollmentData.memsData.get(0).loseHiCoverage);
		}
		
		if(enrollmentData.memsData.get(0).gainAdependent){
			if(enrollmentData.memsData.get(0).recentlyMarried){
				qualifyingLifeEventPage.selectIfAnyMemMarriageStatusGotChanged(enrollmentData.memsData.get(0).recentlyMarried);
				
				for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
					qualifyingLifeEventPage.selectMarried(memIndex);
					qualifyingLifeEventPage.selectMarriageDate(memIndex, enrollmentData.appDate);
				}
			}else{
				qualifyingLifeEventPage.selectIfAnyMemMarriageStatusGotChanged(enrollmentData.memsData.get(0).recentlyMarried);
			}
			
			if(enrollmentData.memsData.get(0).birthInHousehold){
				qualifyingLifeEventPage.selectIfAnyMemAddedDueToBirth(enrollmentData.memsData.get(0).birthInHousehold);
				
				for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
					qualifyingLifeEventPage.selectBirth(memIndex);
					qualifyingLifeEventPage.selectDateOfBirth(memIndex, enrollmentData.appDate);
				}
			}else{
				qualifyingLifeEventPage.selectIfAnyMemAddedDueToBirth(enrollmentData.memsData.get(0).birthInHousehold);
			}
			
			if(enrollmentData.memsData.get(0).fosterCare){
				qualifyingLifeEventPage.selectIfAnyMemAddedDueToBirth(enrollmentData.memsData.get(0).fosterCare);
				
				for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
					qualifyingLifeEventPage.selectBirth(memIndex);
					qualifyingLifeEventPage.selectMemAddedDueToFosterCare(evpdData.memsData.get(0).firstName, evpdData.memsData.get(0).lastName);
					qualifyingLifeEventPage.selectFosterMemDate(evpdData.memsData.get(0).firstName, evpdData.memsData.get(0).lastName, enrollmentData.appDate);
				}
			}else{
				qualifyingLifeEventPage.selectIfAnyMemAddedDueToBirth(enrollmentData.memsData.get(0).fosterCare);
			}
		}else{
			qualifyingLifeEventPage.selectIfAnyMemDependentStatusGotChanged(enrollmentData.memsData.get(0).gainAdependent);
		}
		
		if(enrollmentData.memsData.get(0).lawfullyPresentImmigrant){
			qualifyingLifeEventPage.selectIfAnyMemImmStatusGotChanged(enrollmentData.memsData.get(0).lawfullyPresentImmigrant);
			
			for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
				qualifyingLifeEventPage.selectImmigrationStatusGained(memIndex);
				qualifyingLifeEventPage.selectImmigrationChangeDate(memIndex, enrollmentData.appDate);
			}				
		}else{
			qualifyingLifeEventPage.selectIfAnyMemImmStatusGotChanged(enrollmentData.memsData.get(0).lawfullyPresentImmigrant);
		}
		
		if(enrollmentData.memsData.get(0).moveToMass){
			qualifyingLifeEventPage.selectIfAnyMemMoveToMAWithPrevMH(enrollmentData.memsData.get(0).moveToMass);
			
			for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
				qualifyingLifeEventPage.selectMemberMovedMA(memIndex);
				qualifyingLifeEventPage.selectMoveToMa(memIndex, enrollmentData.appDate);
			}				
		}else{
			qualifyingLifeEventPage.selectIfAnyMemMoveToMAWithPrevMH(enrollmentData.memsData.get(0).moveToMass);
		}
		
		if(enrollmentData.memsData.get(0).recentlyReleasedFromPrison){
			qualifyingLifeEventPage.selectIfAnyMemIncarcerationStatusGotChanged(enrollmentData.memsData.get(0).recentlyReleasedFromPrison);
			
			for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){
				qualifyingLifeEventPage.selectMemberReleasedFromJail(memIndex);
				qualifyingLifeEventPage.selectMemberReleasedFromJailDate(memIndex, enrollmentData.appDate);
			}				
		}else{
			qualifyingLifeEventPage.selectIfAnyMemIncarcerationStatusGotChanged(enrollmentData.memsData.get(0).recentlyReleasedFromPrison);
		}			
		
		qualifyingLifeEventPage.selectIfAnyMemDomesticAbuseStatusGotChanged(enrollmentData.memsData.get(0).victimDomAbuseAban);
		qualifyingLifeEventPage.takeScreenshot();
		qualifyingLifeEventPage.clickOnSaveAndContinueBtn();
	}

}
