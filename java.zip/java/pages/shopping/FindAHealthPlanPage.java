package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class FindAHealthPlanPage extends CommonPage{
	
	private static final By findAHealthPlanPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Find a Health Plan')]");
	
	public FindAHealthPlanPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("FindAHealthPlanPageHeader", findAHealthPlanPageHeader);
	}
}
