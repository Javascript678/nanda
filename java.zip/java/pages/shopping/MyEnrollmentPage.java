package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class MyEnrollmentPage extends CommonPage implements CommonPageOR{
	
	private static final By myEnrollmentPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'My Enrollments')]");
	private static final By makeAPaymentBtn = By.xpath("//input[@value='Make a Payment']");
	private static final By backButton = By.id("backButton");
	private static final By accountDashboardButton = By.id("backBtn");
	private static final By submitBtn = By.xpath("//input[@value='Submit']");
	private static final By changeEnrollmentBtn = By.xpath("//input[@value='Change Enrollment']");
	private static final By cancelEnrollmentBtn = By.xpath("//input[@value='Cancel Enrollment']");
	
	
	public MyEnrollmentPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("MyEnrollmentPageHeader", myEnrollmentPageHeader);
	}
	
	public void verifyPageLoad() throws Exception{
		waitForPageLoaded();
	}
	
	public void clickOnMakeAPaymentButton() throws Exception{
		clickOnElement("MakeAApyment", makeAPaymentBtn);
	}
	
	public void clickOnBackButton() throws Exception{
		clickOnElement("BackButton", backButton);
	}
	
	public void clickOnSubmitButton() throws Exception{
		clickOnElement("SubmitButton", submitBtn);
	}
	
	public void clickOnChangeEnrollmentButton() throws Exception{
		clickOnElement("ChangeEnrollmentBtn", changeEnrollmentBtn);
	}
	
	public void clickOnCancelEnrollmentButton() throws Exception{
		clickOnElement("CancelEnrollmentBtn", cancelEnrollmentBtn);
	}
	
	public void clickOnAccountDashboardutton() throws Exception{
		clickOnElementThenWait("BackToAccDashboardBtn", accountDashboardButton,10);
	}
	
	public void clickOnDialogOkButton() throws Exception{
		clickOnElement("PopupOkBtn", alertOkButton);
	}
	
	public void takeScreenshot() throws Exception{
		takeScreenshot("Summary");
	}
	
	
}
