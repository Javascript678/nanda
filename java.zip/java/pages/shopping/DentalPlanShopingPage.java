package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class DentalPlanShopingPage extends CommonPage{
	
	private static final By dentalPlanShoppingPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Dental Plan Shopping')]");
	private static final By continueBtn = By.id("planSelectionContinue");
	private static final By backBtn = By.id("planSelectionPrevious");
	
	public DentalPlanShopingPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("DentalPlanShoppingPageHeader", dentalPlanShoppingPageHeader);
	}
	
	private void clickOnFindAPlanForCurrentYearForShoopingGrp(int shoppingGrpNo) throws Exception{
		By findAPlanForCurrentYear = By.id("btnFindPlan_"+ shoppingGrpNo);
		clickOnElement("ShpGrp"+shoppingGrpNo+"_FindADntlPlanForCurrentYear", findAPlanForCurrentYear);
	}
	
	private boolean isThereAnyExistingPlanForShoopingGrp(int shoppingGrpNo) throws Exception{
		By removeExistingPlan = By.xpath("//div[contains(@id,'memberContainer')]["+shoppingGrpNo+"]//table[contains(@class,'planNonTable ')]//td[@class='lastCol']//a");
		return isElementPresent(removeExistingPlan,3);
	}
	
	private void clickOnRemoveExistingPlanForShoopingGrp(int shoppingGrpNo) throws Exception{
		By removeExistingPlan = By.xpath("//div[contains(@id,'memberContainer')]["+shoppingGrpNo+"]//table[contains(@class,'planNonTable ')]//td[@class='lastCol']//a");
		clickOnElementThenWait("ShpGrp"+shoppingGrpNo+"_RemoveExistingDntlPlan", removeExistingPlan,3);
	}
	
	private void clickOnContinueBtn() throws Exception{
		clickOnElement("ContinueBtn", continueBtn);
	}
	
	private void clickOnBackBtn() throws Exception{
		clickOnElement("BackBtn", backBtn);
	}
	
	public void clickOnFindAPlanForShoppingGrp(int shoppingGrpNo) throws Exception{
		waitForPageLoaded();
		if(isThereAnyExistingPlanForShoopingGrp(shoppingGrpNo)){
			clickOnRemoveExistingPlanForShoopingGrp(shoppingGrpNo);
		}
		clickOnFindAPlanForCurrentYearForShoopingGrp(shoppingGrpNo);
	}
	
	public void clickOnRemoveExistingPlaForShoppingGrpAndContinue(int shoppingGrpNo) throws Exception{
		waitForPageLoaded();
		clickOnRemoveExistingPlanForShoopingGrp(shoppingGrpNo);
		clickOnContinueBtn();
	}
	
	public void pageLoadAndClickOnContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnContinueBtn();
	}
	
	
}
