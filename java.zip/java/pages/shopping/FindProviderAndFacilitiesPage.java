package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class FindProviderAndFacilitiesPage extends CommonPage{
	
	private static final By findProviderAndFacilitiesPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Find Providers & Facilities')]");
	private static final By providersearchBtn = By.id("providerSubmit");
	private static final By providersTab = By.id("providerTab");
	private static final By facilitiesTab = By.id("facilityTab");
	private static final By firstNameTxtBox = By.id("fName");
	private static final By lastNameTxtBox = By.id("lName");
	private static final By providerzip = By.id("zip");
	private static final By specialityDropDown = By.id("speciality");
	private static final By acceptNewPatientsDropDown = By.id("acceptNew");
	private static final By genderDropDown = By.id("gender");
	private static final By languageDropDown = By.id("lang");
	private static final By facilityzip = By.id("facility_zip");
	private static final By facilitysearchBtn = By.id("facilitySubmit");
	private static final By continueBtn = By.id("jsReviewProviderSearch");
	private static final By skipBtn= By.xpath(".//div[@class='buttons']/a[contains(.,'Skip')]");
	private static final By backBtn= By.xpath(".//button[@class='secondaryButton marginL10'][contains(.,'Back')]");
	
	
	public FindProviderAndFacilitiesPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ProviderAndFacilitiesPageHeader", findProviderAndFacilitiesPageHeader);
	}
	
	public void takeScreenshot() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Provider & Prescription Page");
	}
	
	
	private void clickOnContinueBtn() throws Exception{
		clickOnElement("ContinueBtn", continueBtn);
	}
	
	private void clickOnSkipBtn() throws Exception{
		clickOnElement("SkipThisStepBtn", skipBtn);
	}
	
	private void clickOnBackBtn() throws Exception{
		clickOnElement("BackBtn", backBtn);
	}
	
	private void clickOnProviderTab() throws Exception{
		clickOnElement("ProviderTab", providersTab);
	}
	
	private void clickOnFacilitiesTab() throws Exception{
		clickOnElement("FacilitiesTab", facilitiesTab);
	}
	
	private void enterProviderZipCode(String zip) throws Exception{
		clickOnElement("ZipCode", providerzip);
		clearAndType("ZipCodeTxt" , providerzip ,zip);
	}
	
	private void clickOnProviderSearchBtn() throws Exception{
		clickOnElement("Search Providers", providersearchBtn);
		
	}
	
	private void enterFacilityZipCode(String zip) throws Exception{
		clickOnElement("ZipCode", facilityzip);
		clearAndType("ZipCodeTxt" , facilityzip ,zip);
	}
	
	private void clickOnFacilitySearchBtn() throws Exception{
		clickOnElement("Search Providers", facilitysearchBtn);
		
	}
	
	private void addProviderFromList(int providerNum) throws Exception{
		By addProviderLink = By.xpath("//table[@id='individualProviderList']/tbody//tr["+providerNum+"]/td[4]/ul/li[2]");
		clickOnElementThenWait("Add Provider "+providerNum, addProviderLink,10);
	}
	
	private void removeProviderFromList(int providerNum) throws Exception{
		By removeProviderLink = By.xpath("//div[@id='jsSelectedProvider']/div/table/tbody//tr["+providerNum+"]/td[2]");
		clickOnElementThenWait("Remove Provider "+providerNum, removeProviderLink,10);
	}
	
	private void addFacilityFromList(int facilityNum) throws Exception{
		By addFacilityLink = By.xpath("//table[@id='facilityProviderList']/tbody//tr["+facilityNum+"]/td[5]/ul/li[2]");
		clickOnElement("Add Facility "+facilityNum, addFacilityLink);
	}
	
	private void removeFacilityFromList(int facilityNum) throws Exception{
		By removeFacilityLink = By.xpath("//div[@class='section']/table/tbody//tr["+facilityNum+"]/td[2]");
		clickOnElementThenWait("Remove Facility "+facilityNum, removeFacilityLink,10);
	}
	
	public void pageLoadAndClickOnContinue() throws Exception{
		waitForPageLoaded();
		clickOnContinueBtn();
	}
	
	public void searchProviderUsingZipcode(String zipCode) throws Exception	{
		FindProviderAndFacilitiesPage providerAndFacilities = new FindProviderAndFacilitiesPage(driver, testCaseId);
		providerAndFacilities.clickOnProviderTab();
		providerAndFacilities.enterProviderZipCode(zipCode);
		providerAndFacilities.clickOnProviderSearchBtn();
		providerAndFacilities.takeScreenshot();
		
	}
	
	public void addProvider(int numOfProviders) throws Exception	{
		FindProviderAndFacilitiesPage providerAndFacilities = new FindProviderAndFacilitiesPage(driver, testCaseId);
		for (int i=1;i<=numOfProviders;i++)
		{
			providerAndFacilities.addProviderFromList(i);
			Thread.sleep(5000);
			
		}
		providerAndFacilities.takeScreenshot();
	}
	
	public void deleteProvider(int numOfProviders) throws Exception	{
		FindProviderAndFacilitiesPage providerAndFacilities = new FindProviderAndFacilitiesPage(driver, testCaseId);
		for (int i=1;i<=numOfProviders;i++)
		{
			providerAndFacilities.removeProviderFromList(i);
			Thread.sleep(5000);
			
		}
		providerAndFacilities.takeScreenshot();
	}
	
	public void searchFacilityUsingZipcode(String zipCode) throws Exception	{
		FindProviderAndFacilitiesPage providerAndFacilities = new FindProviderAndFacilitiesPage(driver, testCaseId);
		providerAndFacilities.clickOnFacilitiesTab();
		providerAndFacilities.enterFacilityZipCode(zipCode);
		providerAndFacilities.clickOnFacilitySearchBtn();
		providerAndFacilities.takeScreenshot();
		
	}
	
	public void addFacility(int numOfFacilities) throws Exception	{
		FindProviderAndFacilitiesPage providerAndFacilities = new FindProviderAndFacilitiesPage(driver, testCaseId);
		for (int i=1;i<=numOfFacilities;i++)
		{
			providerAndFacilities.addFacilityFromList(i);
			Thread.sleep(5000);

		}
		providerAndFacilities.takeScreenshot();
	}
	
	public void deleteFacility(int numOfFacilities) throws Exception	{
		FindProviderAndFacilitiesPage providerAndFacilities = new FindProviderAndFacilitiesPage(driver, testCaseId);
		for (int i=1;i<=numOfFacilities;i++)
		{
			providerAndFacilities.removeFacilityFromList(i);
			Thread.sleep(5000);

		}
		providerAndFacilities.takeScreenshot();
	}
}
