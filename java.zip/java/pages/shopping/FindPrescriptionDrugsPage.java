package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class FindPrescriptionDrugsPage extends CommonPage implements CommonPageOR{
	
	private static final By findPrescriptionDrugsPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Prescription Drug Search')]");
	private static final By addBtn = By.id("calculateBtn");
	private static final By drugNameTxtBox = By.id("comboBox1-edit");
	private static final By continueBtn = By.id("jsReviewProviderSearch");
	private static final By skipBtn= By.xpath(".//div[@class='buttons']/a[contains(.,'Skip')]");
	private static final By backBtn= By.xpath(".//button[@class='secondaryButton previousButton getBackUrlFormulary'][contains(.,'Back')]");
	private static final By drugAddInfoTxt= By.xpath(".//div[@class='successAlert form-group']/p[contains(.,'You can add up to 10 drugs to include in your plans.')]");
	private static final By drugUpdateInfoTxt= By.xpath(".//div[@class='contentBlock successAlert']/p[contains(.,'The prescription drug information is updated regularly so it is as up-to-date as possible.')]");
	private static final By drugAddSuccessMsg = By.id("successMessage1");
	private static final By removeDrug = By.xpath("//tr[1]//td[@class='lastCol']/a[text()='Remove']");
	
	public FindPrescriptionDrugsPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("FindPrescriptionDrugsPageHeader", findPrescriptionDrugsPageHeader);
	}
	

	public void clickOnContinueWarningMsg() throws Exception{
		takeScreenshot("Continue PopUp Msg");
		clickOnElementThenWait("ContinueWarningMsg", warningOkButton, 5);
	}
	
	public void clickOnSkipThisStepWarningMsg() throws Exception{
		takeScreenshot("SkipThisStepPopUpMsg");
		clickOnElementThenWait("SkipThisStepWarningMsg", popupNoBtn, 5);
	}
	
	public void clickOnRemoveBtn() throws Exception{
		clickOnElement("RemoveDrugBtn", removeDrug);
	}	
	
	public void clickOnContinueBtn() throws Exception{
		clickOnElement("ContinueBtn", continueBtn);
	}
	
	public void clickOnSkipBtn() throws Exception{
		clickOnElement("SkipThisStepBtn", skipBtn);
	}
	
	public void clickOnBackBtn() throws Exception{
		clickOnElement("BackBtn", backBtn);
	}
	
	public void clickOnAddBtn() throws Exception{
		clickOnElementThenWait("AddBtn", addBtn,3);
	}
	
	public void addDrugsAndValMsg(String text) throws Exception{
		enterTextWithDropDown(drugNameTxtBox, text);
		clickOnAddBtn();
		validateSuccessMsgIsPresent();
		takeScreenshot("AddDrugList");
	}
	
	public void validateSuccessMsgIsPresent() throws Exception{
		waitForPresenceOfElementLocated("Drug Add Success Message",drugAddSuccessMsg);
	}
		
	private void validateInfoTextIsPresent() throws Exception{
		waitForPresenceOfElementLocated("Drug Addition Info Message",drugAddInfoTxt);
	}
	
	private void validateDrugNameTextBoxIsPresent() throws Exception{
		waitForPresenceOfElementLocated("Drug Name Text Box",drugNameTxtBox);
	}
	
	private void validateDrugUpdateInfoTxtIsPresent() throws Exception{
		waitForPresenceOfElementLocated("Drug Update Info Message",drugUpdateInfoTxt);
	}
	
	public void clickOnContinue() throws Exception{
		//waitForPageLoadedd();
		clickOnContinueBtn();
	}
	
	public void validateUIElementsOnPrescriptionPage() throws Exception	{
		FindPrescriptionDrugsPage prescriptionanddrugs = new FindPrescriptionDrugsPage(driver, testCaseId);
		prescriptionanddrugs.waitForPageLoaded();
		prescriptionanddrugs.validateInfoTextIsPresent();
		prescriptionanddrugs.validateDrugNameTextBoxIsPresent();
		prescriptionanddrugs.validateDrugUpdateInfoTxtIsPresent();
		takeScreenshot("Prescription Page");
	}
}
	
	