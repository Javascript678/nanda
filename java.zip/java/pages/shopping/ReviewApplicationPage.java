package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class ReviewApplicationPage extends CommonPage implements CommonPageOR{
	
	private static final By reviewApplicationPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Review Application')]");
	
	public ReviewApplicationPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ReviewApplicationPageHeader", reviewApplicationPageHeader);
	}
	
	
	private void clickOnContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void pageLoadAndClickOnSaveAndContinue() throws Exception{
		waitForPageLoaded();
		clickOnContinueBtn();
	}
	
	
}
