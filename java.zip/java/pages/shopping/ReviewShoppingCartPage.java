package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class ReviewShoppingCartPage extends CommonPage{
	
	private static final By reviewShoppingCartPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Review Shopping Cart')]");
	private static final By continueBtn = By.id("goto");
	
	public ReviewShoppingCartPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("ReviewShoppingCartPageHeader", reviewShoppingCartPageHeader, 2);
	}
	
	
	private void clickOnContinueBtn() throws Exception{
		clickOnElement("ContinueBtn", continueBtn);
	}
	
	public void pageLoadAndClickOnSaveAndContinue() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Shpping Details");
		clickOnContinueBtn();
	}
	
	
}
