package pages.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class EnrollPage extends CommonPage{
	
	private static final By enrollPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Enroll')]");
	private static final By termServicesChkBx = By.id("check_terms_service");
	private static final By hohSignatureTxt = By.id("primary_applicant_sign");
	private static final By finishBtn = By.id("finishButton");
	private static final By closeBtn = By.xpath("//input[@value='Close']");
	
	
	public EnrollPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("EnrollPageHeader", enrollPageHeader);
	}
	
	
	private void clickOnTermServiceChkBx() throws Exception{
		clickOnElement("TermServicesChkBx", termServicesChkBx);
	}
	
	private String getHOHSignature()throws Exception{
		By hohSignatureLabel = By.xpath("//label[@for='primary_applicant_sign']");
		String signText = getElementText(hohSignatureLabel).split("\\r?\\n")[4];
		System.out.println(signText);
		return signText;
	}
	
	private void enterHOHSignature(String signature) throws Exception{
		clearAndType("HohSignatureTxt", hohSignatureTxt, signature);
	}
	
	private void clickOnFinishBtn() throws Exception{
		clickOnElementThenWait("FinishBtn", finishBtn, 3);
	}
	
	private void clickOnRequestSubmittedSuccessfullyCloseBtn() throws Exception{
		clickOnElement("CloseBtn", closeBtn);
	}
	
	public void enterHohSignAndContinue() throws Exception{
		waitForPageLoaded();
		clickOnTermServiceChkBx();
		String signature = getHOHSignature();
		enterHOHSignature(signature);
		clickOnFinishBtn();
		clickOnRequestSubmittedSuccessfullyCloseBtn();
	}
	
	
}
