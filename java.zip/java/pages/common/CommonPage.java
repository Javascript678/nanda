package pages.common;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import stepdefs.support.Hook;
import utils.ScreenShot;
import utils.TestReport;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class CommonPage {
		
	protected String testCaseId;
	protected Logger logger;
	
	private static final int DEFAULT_EXPLICIT_WAIT_TIMEOUT = 60;
	private static final int DEFAULT_EXPEDITED_WAIT_TIMEOUT = 5;
	
	public WebDriver driver;
	
	private String htmlReportErrorSyntax = "Error on Updating HTML Result for Action";
	private String keywordActionErrorSyntax = "Error on Performing Action";

	public CommonPage(WebDriver driver, String testCaseId) {
		this.driver = driver;
		this.testCaseId = testCaseId;
		logger = Logger.getLogger(testCaseId);
	}

	public String refreshCurrentPage() throws Exception {
		boolean status=true;
		
		String currentURL = null;
		
		try{
			driver.navigate().refresh();
		}catch(Exception e){
			status = false;
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[RefreshPage]");
		}
		
		return currentURL;		
	}
	
	public void switchWindow() throws Exception {
		boolean status = true;
		
		try{
			Thread.sleep(2000);
			
			// Switch to New Window
			Set<String> windowHandles = driver.getWindowHandles();
			
			for(String winHandle : windowHandles){
				String currentWinTitle = driver.getTitle();
				System.out.println("Current Window Title Is [" + currentWinTitle + "]");
				driver.switchTo().window(winHandle);
			}
			
		}catch (Exception e){
			status = false;
		}
		
		try {
			TestReport.stepResultInHTML(driver, testCaseId, "", "SwitchWindow", "", "", status, "");
		}catch(IOException e){
			throw new Exception(keywordActionErrorSyntax + "[SwitchWindow] Could Not Switch To New Window");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SwitchWindow] Could Not Switch To New Window");
		}		
	}
	
	public void switchWindow(String windowTitle) throws Exception {
		boolean status = false;
		
		try{
			Thread.sleep(2000);
			
			// Switch to Window with Given Title
			Set<String> windowHandles = driver.getWindowHandles();
			
			for(String winHandle : windowHandles){
				String currentWinTitle = driver.getTitle();				
				System.out.println("Current Window Title Is [" + currentWinTitle + "]");
				
				if(currentWinTitle.equals(windowTitle)){
					 driver.switchTo().window(winHandle);
					 status = true;
					 break;
				}			   
			}
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, "", "SwitchWindow", "", "", status, "");
		}catch(IOException e){
			throw new Exception(keywordActionErrorSyntax + "[SwitchWindow] Could Not Find Window With Tilte[" + windowTitle +"]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SwitchWindow] Could Not Find Window With Tilte[" + windowTitle +"]");
		}		
	}

	public String pressEnterOnPage() throws Exception {
		boolean status = true;
		
		String currentURL = null;
		
		try{
			Thread.sleep(1000);
				
			//driver.findElement(By.xpath("/htlm/body")).sendKeys(Keys.ENTER);
				
			Robot rb =new Robot();
				
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
				
			Thread.sleep(1000);
		}catch(Exception e){
			status = false;
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[PRESS_ENTER]");
		}
		
		return currentURL;		
	}
	public String getCurrentURL() throws Exception {
		boolean status = true;
		
		String currentURL = null;
		
		try{
			currentURL =  driver.getCurrentUrl();	
		}catch(Exception e){
			status = false;
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[GetURL]");
		}
		
		return currentURL;		
	}
	
	public String getCurrentPageTitle() throws Exception {
		boolean status = true;
		
		String currentTitle = null;
		
		try{
			currentTitle = driver.getTitle();	
		}catch(Exception e){
			status = false;
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[GetPageTitle]");
		}
		
		return currentTitle;		
	}
	
	public void goTo(String url) throws Exception {
		boolean status=true;
		
		try{
			logger.info("Go to URL " + url);
			driver.get(url);	
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, "", "OpenURL", url, "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[OpenURL] URL [" + url + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[OpenURL] URL [" +  url + "]");
		}
	}

	protected void clickOnElement(String elementName, By locator) throws Exception {
		boolean status = true;
		
		try{	
			logger.info("Clicking On Element[" + elementName + "] locator [" + locator + "]");			
			waitForVisibilityOfElementLocated(locator);
			scrollToElement(locator);
			getElement(locator).click();	
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "Click", "", "",status, "");
		}catch (IOException e){
			throw new Exception(htmlReportErrorSyntax + "[Click] On Element [" +  elementName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[Click] On Element [" +  elementName + "]");
		}
	}
	
	protected void clickOnElementThenWait(String elementName, By locator, int waitTime) throws Exception {
		boolean status=true;
		try{	
			logger.info("Clicking On Element[" + elementName + "] locator [" + locator + "]");
			waitForVisibilityOfElementLocated(locator);
			scrollToElement(locator);
			getElement(locator).click();
			Thread.sleep(waitTime * 1000);
		}catch(Exception e){
			status = false;
		}
		
		try {
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "Click", "", "", status, "");
		}catch (IOException e){
			throw new Exception(htmlReportErrorSyntax + "[Click] On Element [" +  elementName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[Click] On Element [" +  elementName + "]");
		}
	}
	
	protected void clickOnElementAfterWait(String elementName, By locator, int waitTime) throws Exception {
		boolean status = true;
		
		try{	
			Thread.sleep(waitTime*1000);
			logger.info("Clicking On Element[" + elementName + "] locator [" + locator + "]");
			waitForVisibilityOfElementLocated(locator);
			scrollToElement(locator);
			getElement(locator).click();
		}catch(Exception e){
			status = false;
		}
		
		try {
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "Click", "", "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[Click] On Element [" + elementName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[Click] On Element [" +  elementName + "]");
		}
	}
	
	protected void clickOnElementAfterScreenshot(String elementName, By locator) throws Exception {
		boolean status=true;

		String testReportFolder = Hook.testReportFolder;
		
		@SuppressWarnings({ "restriction", "deprecation" })
		
		Class<?> c = sun.reflect.Reflection.getCallerClass(3);
		
		String pageName = c.getName();
		String packageName = pageName.split("\\.")[0] +"." + pageName.split("\\.")[1]+".";
		String screenName = pageName.replace(packageName, "");
		
		String screenShotLink = "";
		screenShotLink = ScreenShot.takeScreenShot(driver, testReportFolder, testCaseId, screenName + "_" + elementName);
		
		try{	
			logger.info("Clicking On Element[" + elementName + "] locator [" + locator + "]");
			waitForVisibilityOfElementLocated(locator);
			scrollToElement(locator);
			getElement(locator).click();	
		}catch(Exception e){
				status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "Click", "", "", status, screenShotLink);
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[Click] On Element [" +  elementName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[Click] On Element [" +  elementName + "]");
		}
	}
	
	protected void optionalClickOnElement(String elementName, By locator) throws Exception {
        boolean status = true;
        try{
            logger.info("Optional Clicking On Element[" + elementName + "] locator [" + locator + "]");
            
            if(isElementPresent(locator)){
            	waitForVisibilityOfElementLocated(locator);
                scrollToElement(locator);
                getElement(locator).click(); 
           	}
        }catch (Exception e){
        	logger.info("Element not Found. So Ignored Clicking On Element[" + elementName + "] locator [" + locator + "]");
        }
        
        try{
        	TestReport.stepResultInHTML(driver, testCaseId, elementName, "OptionalClick", "", "", status, "");
        }catch(IOException e){
        	throw new Exception(htmlReportErrorSyntax + "[OptionalClick] On Element [" +  elementName + "]");
        }
        
        if(status == false){
               throw new Exception(keywordActionErrorSyntax + "[OptionalClick] On Element [" +  elementName + "]");
        }
	}
	
	protected void takeScreenshot(String imageName) throws Exception {
		boolean status = true;

		String testReportFolder = Hook.testReportFolder;
		
		@SuppressWarnings({ "restriction", "deprecation" })
		Class<?> c = sun.reflect.Reflection.getCallerClass(2);
		
		String pageName = c.getName();
		String packageName = pageName.split("\\.")[0] +"." + pageName.split("\\.")[1]+".";
		String screenName = pageName.replace(packageName, "");
		String screenShotLink = "";
		
		logger.info("Taking Screenshot for Screen [" + screenName + "] Image [" + imageName + "]");
		
		screenShotLink = ScreenShot.takeScreenShot(driver, testReportFolder, testCaseId, screenName+ "_" + imageName);
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, imageName, "ScreenShot", "", "", status, screenShotLink);
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[ScreenShot] with Image Name [" + imageName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[ScreenShot] with Image Name [" + imageName + "]");
		}
	}
	
	protected void enterText(String elementName, By locator, String text) throws Exception {		
		boolean status=true;
		
		try{	
			logger.info("Entering Text On Element[" + elementName + "] locator [" + locator + "] Text [" + text + "]");
			enterTextWithoutTab(locator, text);
			WebElement element = getElement(locator);
			element.sendKeys(Keys.TAB);	
		}catch (Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "EnterText", text, "", status, "");
		} catch (IOException e) {
			throw new Exception(htmlReportErrorSyntax + "[EnterText] On Element  [" +  elementName + "] with Text[" + text + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[EnterText] On Element  [" +  elementName + "] with Text[" + text + "]");
		}
	}
	
	protected void enterTextThenPressDoubleTab(String elementName, By locator, String text) throws Exception {		
		boolean status = true;
		try{	
			logger.info("Entering Text On Element[" + elementName + "] locator [" + locator + "] Text [" + text + "]");
			
			enterTextWithoutTab(locator, text);
			
			WebElement element = getElement(locator);
			
			element.sendKeys(Keys.TAB);
			element.sendKeys(Keys.TAB);
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "EnterText", text, "", status, "");
		} catch (IOException e) {
			throw new Exception(htmlReportErrorSyntax + "[EnterText] On Element  [" +  elementName + "] with Text[" + text + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[EnterText] On Element  [" +  elementName + "] with Text[" + text + "]");
		}
	}

	protected void clearAndType(String elementName, By locator, String text) throws Exception {
		boolean status = true;
		
		try{	
			logger.info("Entering Text On Element[" + elementName + "] locator [" + locator + "] Text [" + text + "]");
		
			waitForElementToBeClickable(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
			
			WebElement element = getElement(locator);
			
			element.click();
			element.clear();
			element.sendKeys(text);
			element.sendKeys(Keys.TAB);
		}catch (Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "ClearAndType", text, "", status, "");
		}catch (IOException e){
			throw new Exception(htmlReportErrorSyntax + "[ClearAndType] On Element  [" +  elementName + "] with Text[" + text + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[ClearAndType] On Element  [" +  elementName + "] with Text[" + text + "]");
		}
	}
	
	protected void clearAndTypeAfterWait(String elementName, By locator, String text) throws Exception {
		boolean status = true;
		
		try{	
			logger.info("Entering Text On Element[" + elementName + "] locator [" + locator + "] Text [" + text + "]");
		
			Thread.sleep(3000);
			
			waitForElementToBeClickable(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
			
			WebElement element = getElement(locator);
			
			element.click();
			element.clear();
			element.sendKeys(text);
			element.sendKeys(Keys.TAB);
		}catch (Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "ClearAndTypeDOB", text, "", status, "");
		}catch (IOException e){
			throw new Exception(htmlReportErrorSyntax + "[ClearAndTypeDOB] On Element  [" +  elementName + "] with Text[" + text + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[ClearAndTypeDOB] On Element  [" +  elementName + "] with Text[" + text + "]");
		}
	}	
    
	protected void selectByValue(String elementName, By locator, String attrValues) throws Exception {
    	boolean status = true, found = false;
		
    	try{
			logger.info("Select By Value On Element[" + elementName + "] locator [" + locator + "] Value [" + attrValues + "]");
		
			waitForVisibilityOfElementLocated(locator);
			
			List<String> actualElementValues = new ArrayList<String>();
			List<String> listValue = Arrays.asList(attrValues.trim().split(","));
			List<WebElement> listElement = getElements(locator);
			
			for(String value : listValue){
				found = false;
				
				for(WebElement element : listElement){
					String actualElementValue = element.getAttribute("value");
					
					actualElementValues.add(actualElementValue);
					
					if(actualElementValue.equalsIgnoreCase(value.trim())){
						element.click();
						found = true;
						break;
					}
				}

				if(found == false){
					new RuntimeException("For Locator [" + locator + "] value [" + value + "] is incorrect . Actual Attr Value Found was " + actualElementValues);
				}
			}
			
			status = found;	
		}catch (Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "SelectByValue", attrValues, "", status, "");
		} catch (IOException e) {
			throw new Exception(htmlReportErrorSyntax + "[SelectByValue] On Element  [" +  elementName + "] with Text[" + attrValues + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SelectByValue] On Element  [" +  elementName + "] with Text[" + attrValues + "]");
		}
	}
	
    protected void selectByValueUsingJS(String elementName, By locator, String attrValues) throws Exception {
		boolean status = true, found = false;
		
		try{
			logger.info("Select By Value On Element[" + elementName + "] locator [" + locator + "] Value [" + attrValues + "]");
		
			waitForVisibilityOfElementLocated(locator);
			
			List<String> actualElementValues = new ArrayList<String>();
			List<String> listValue = Arrays.asList(attrValues.split(","));
			List<WebElement> listElement = getElements(locator);
			
			for(String value : listValue){
				found = false;
				
				for(WebElement element : listElement){
					String actualElementValue = element.getAttribute("value");
					actualElementValues.add(actualElementValue);
					
					if(actualElementValue.equalsIgnoreCase(value)){
						executeJS("arguments[0].click()", element);
						found = true;
						break;
					}
				}

				if(found == false){
					new RuntimeException("For Locator [" + locator + "] value [" + value + "] is incorrect . Actual Attr Value Found was " + actualElementValues );
				}
			}
			
			status = found;	
		}catch (Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "SelectByValue", attrValues, "",status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[SelectByValue] On Element  [" +  elementName + "] with Text[" + attrValues + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SelectByValue] On Element  [" +  elementName + "] with Text[" + attrValues + "]");
		}
	}  
    
    //Ritu
    protected void clickOnElementByActionClass(String elementName, By locator) throws Exception {
		boolean status = true;
		
		try{	
			logger.info("Clicking On Element[" + elementName + "] locator [" + locator + "]");			
			//waitForVisibilityOfElementLocated(locator);
			scrollToElement(locator);
			WebElement element =driver.findElement(locator);
			Actions builder = new Actions(driver);
			builder.click(element).build().perform();	
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "Click", "", "", status, "");
		}catch (IOException e){
			throw new Exception(htmlReportErrorSyntax + "[Click] On Element [" +  elementName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[Click] On Element [" +  elementName + "]");
		}
	}
    
    protected void selectByAttributeName(String elementName, By locator, String attrName, String attrValues) throws Exception {
		boolean status = true,found=false;
		
		try{
			logger.info("Select By AttributeName On Element[" + elementName + "] locator [" + locator + "] attrName [" + attrName + "] Value [" + attrValues + "]");
		
			waitForVisibilityOfElementLocated(locator);
			
			List<String> actualElementValues = new ArrayList<String>();
			List<String> listValue = Arrays.asList(attrValues.split(","));
			List<WebElement> listElement = getElements(locator);
			
			for(String value : listValue){
				found = false;
				
				for(WebElement element : listElement){
					String actualElementValue = element.getAttribute(attrName);
					actualElementValues.add(actualElementValue);
	
					if(actualElementValue.equalsIgnoreCase(value)){
						element.click();
						found = true;
						break;
					}
				}

				if(found == false){
					new RuntimeException("For Locator [" + locator + "] value [" + value + "] is incorrect . Actual Attr Value Found was " + actualElementValues );
				}
			}
			
			status = found;	
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "SelectByAttrName", attrValues, "", status, "");
		} catch (IOException e) {
			throw new Exception(htmlReportErrorSyntax + "[SelectByValue] On Element  [" +  elementName + "] with Text[" + attrValues + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SelectByValue] On Element  [" +  elementName + "] with Text[" + attrValues + "]");
		}
	}
    
	protected void selectByAttributeNameUsingJS(String elementName, By locator, String attrName, String attrValues) throws Exception {
		boolean status = true, found = false;
		
		try{
			logger.info("Select By AttributeName On Element[" + elementName + "] locator [" + locator + "] attrName [" + attrName + "] Value [" + attrValues + "]");
			
			waitForVisibilityOfElementLocated(locator);
			
			List<String> actualElementValues = new ArrayList<String>();
			List<String> listValue = Arrays.asList(attrValues.split(","));
			List<WebElement> listElement = getElements(locator);
			
			for(String value : listValue){
				found = false;
					
				for(WebElement element : listElement){
					String actualElementValue = element.getAttribute(attrName);
					actualElementValues.add(actualElementValue);
					
					if(actualElementValue.equalsIgnoreCase(value)){
						executeJS("arguments[0].click()", element);
						found = true;
						break;
					}
				}

				if(found == false){
					new RuntimeException("For Locator [" + locator + "] value [" + value + "] is incorrect . Actual Attr Value Found was " + actualElementValues );
				}
			}
			status = found;
			
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "SelectByAttrName", attrValues, "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[SelectByValue] On Element [" +  elementName + "] with Text[" + attrValues + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SelectByValue] On Element [" +  elementName + "] with Text[" + attrValues + "]");
		}
	}

	protected void selectDropDownElementByIndex(String elementName, By locator, int index) throws Exception {
		boolean status = true;
		
		try{
			logger.info("Select DropDown Element By Index Value On Element [" + elementName + "] locator [" + locator + "] Index [" + index + "]");
		
			waitForVisibilityOfElementLocated(locator);
			
			Select dropdown = new Select(getElement(locator));
			dropdown.selectByIndex(index);
		}catch (Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "SelectByIndex", index + "", "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[SelectByIndex] On Element [" +  elementName + "] with Text[" + index+"" + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SelectByIndex] On Element [" +  elementName + "] with Text[" + index+"" + "]");
		}
	}
	
	protected void selectByIndexAfterWait(String elementName, By locator, int index) throws Exception {
		boolean status = true;

		try{
			Thread.sleep(4000);
		
			logger.info("Select DropDown Element By Index Value On Element [" + elementName + "] locator [" + locator + "] Index [" + index + "]");
			
			waitForVisibilityOfElementLocated(locator);
			
			Select dropdown = new Select(getElement(locator));
			dropdown.selectByIndex(index);
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "SelectByIndex", index + "", "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[SelectByIndex] On Element [" + elementName + "] with Index [" + index + "" + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SelectByIndex] On Element [" + elementName + "] with Index [" + index + "" + "]");
		}
	}
	
	protected void selectDropDownElementByVisibleText(String elementName, By locator, String text) throws Exception {
		boolean status = true;
		
		try{
			logger.info("Select DropDown Element By Visible Text On Element [" + elementName + "] locator [" + locator + "] Text [" + text + "]");
		
			waitForElementToBeClickable(locator);
			
			Select dropdown = new Select(getElement(locator));
			dropdown.selectByVisibleText(text);
		}catch (Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "SelectByVisibleText", text, "", status, "");
		}catch (IOException e){
			throw new Exception(htmlReportErrorSyntax + "[SelectByVisibleText] On Element  [" + elementName + "] with Text [" + text + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SelectByVisibleText] On Element  [" + elementName + "] with Text [" + text + "]");
		}
	}
	
	protected void selectByVisibleTextAfterWait(String elementName, By locator, String text) throws Exception {
		boolean status = true;
		
		try{
			Thread.sleep(3000);
		
			logger.info("Select Element By Visible Text On Element [" + elementName + "] locator [" + locator + "] Text [" + text + "]");
			
			waitForElementToBeClickable(locator);
			
			Select dropdown = new Select(getElement(locator));
			dropdown.selectByVisibleText(text);
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "SelectByVisibleText", text, "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[SelectByVisibleText] On Element [" + elementName + "] with Text [" + text + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SelectByVisibleText] On Element [" + elementName + "] with Text [" + text + "]");
		}
	}
	
	protected void selectDropDownByValue(String elementName, By locator, String value) throws Exception {
		boolean status = true;
		
		try{
			Thread.sleep(3000);
		
			logger.info("Select Drop Down Element By Value On Element[" + elementName + "] locator [" + locator + "] Text [" + value + "]");
			
			waitForElementToBeClickable(locator);
			
			Select dropdown = new Select(getElement(locator));
			dropdown.selectByValue(value);
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "SelectDDByValue", value, "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[SelectDDByValue] On Element  [" + elementName + "] with Value[" + value + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[SelectDDByValue] On Element  [" + elementName + "] with Value[" + value + "]");
		}
	}
	
	protected void waitForPresenceOfElementLocated(String elementName, By locator) throws Exception {
		boolean status = true;
		
		try{	
			logger.info("VerifyElement[" + elementName + "] locator [" + locator + "]");
			waitForPresenceOfElementLocated(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyElement", "true", status + "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyElement] On Element  [" + elementName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[VerifyElement] On Element  [" +  elementName + "]");
		}
	}
	
	protected void waitForPresenceOfElementLocatedExpedited(String elementName, By locator) throws Exception {
		boolean status = true;
		
		try{	
			logger.info("VerifyElement[" + elementName + "] locator [" + locator + "]");
			waitForPresenceOfElementLocated(locator, DEFAULT_EXPEDITED_WAIT_TIMEOUT);
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyElement", "true", status + "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyElement] On Element  [" + elementName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[VerifyElement] On Element  [" +  elementName + "]");
		}
	}
	
	protected void waitForPresenceOfElementLocatedThenWait(String elementName, By locator, int waitTime) throws Exception {
		boolean status = true;
		
		try{	
			logger.info("VerifyElement[" + elementName + "] locator [" + locator + "]");
			waitForPresenceOfElementLocated(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
			Thread.sleep(waitTime*1000);
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyElement", "true", status + "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyElement] On Element  [" + elementName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[VerifyElement] On Element  [" + elementName + "]");
		}
	}
	
	protected void waitForPresenceOfElementLocatedAfterWait(String elementName, By locator, int waitTime) throws Exception {
		boolean status = true;
		try{	
			Thread.sleep(waitTime*1000);
			logger.info("VerifyElement[" + elementName + "] locator [" + locator + "]");
			waitForPresenceOfElementLocated(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyElement", "true", status + "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyElement] On Element  [" + elementName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[VerifyElement] On Element  [" + elementName + "]");
		}
	}

    protected Boolean isElementPresent(By locator) {
		return isElementPresent(locator, 15);
	}
    
	protected Boolean isElementPresent(By locator, int waitTimeOut) {
			Boolean found = false;
			
			try{
				found = waitForPresenceOfAllElements(locator, waitTimeOut);
			}catch(TimeoutException e){
				logger.info("Element [" + locator + "] was not found in [" + waitTimeOut + "] Seconds");
			}
			return found;
	}
	
	protected void validateElementPresent(String elementName, By locator) throws Exception {
		Boolean status = true;
		
		try{
			status = waitForPresenceOfAllElements(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
		}catch(TimeoutException e){
			logger.info("Element [" + locator + "] was not found in [" + DEFAULT_EXPLICIT_WAIT_TIMEOUT + "] Seconds");
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyElement", "true", status + "", status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyElement] On Element  [" + elementName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[VerifyElement] On Element  [" + elementName + "]");
		}
	}
	
	protected WebElement getElement(By locator) {
		checkPageReadyState();
		return driver.findElement(locator);
	}
	
	protected List<WebElement> getElements(By locator) {
		checkPageReadyState();
		return driver.findElements(locator);
	}
	
	protected int getElementCount(By locator) {
		checkPageReadyState();
		return driver.findElements(locator).size();
	}
	
	private WebDriverWait webDriverWait(long timeOut) {
		WebDriverWait wait = new WebDriverWait(driver, timeOut);
		return wait;
	}
	
	private void executeJS(String script, WebElement element) {
		((JavascriptExecutor) driver).executeScript(script, element);
	}
	
	private void executeJS(String script, WebElement element, String text) {
		((JavascriptExecutor) driver).executeScript(script, element, text);
	}
	
	private String executeJS(String locatorType, String locatorValue, String attributeName) {
		String value = null;
		
		if(locatorType.equals("id")){
			By locator = By.id(locatorValue);
			WebElement element = getElement(locator);
			value = (String)((JavascriptExecutor) driver).executeScript("return document.getElementById('" + locatorValue + "').getAttribute('" + attributeName + "');", element);
		}
		
		return value;
	}
	
	//*************** Explicit Wait Related Command Start ***************//
	
	private void waitForElementToBeClickable(By locator, long timeOut) {
		WebDriverWait wait = webDriverWait(timeOut);
		wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	protected void waitForPresenceOfElementLocated(By locator, long timeOut) {
		WebDriverWait wait = webDriverWait(timeOut);
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}
	
	private boolean waitForPresenceOfAllElements(By locator, long timeOut) {
			WebDriverWait wait = webDriverWait(timeOut);
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
			return true;
	}
	
	private void waitForVisibilityOfElementLocated(By locator, long timeOut) {
		WebDriverWait wait = webDriverWait(timeOut);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}
	
	private void waitForElementToBeClickable(By locator) {
		waitForElementToBeClickable(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
	}
	
	private void waitForVisibilityOfElementLocated(By locator) throws InterruptedException {
		Thread.sleep(4000);
		//waitForVisibilityOfElementLocated(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
	}
	
	//*************** Explicit Wait Related Command END ***************//
	
	//***************** WEB ELEMENTS COMMANDS STARTED *****************//
	
	private void scrollToElement(By locator) {
		WebElement element = getElement(locator);
		executeJS("arguments[0].scrollIntoView(false)", element);
	}

	protected void clickOnElementUsingJS(By locator) {
		waitForElementToBeClickable(locator);
		WebElement element = getElement(locator);
		executeJS("arguments[0].click()", element);
	}
	
	protected void enterTextWithoutTab(By locator, String text) {
		waitForElementToBeClickable(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
		
		WebElement element = getElement(locator);
		
		element.click();
		element.sendKeys(text);
	}
	
	protected void enterTextWithDropDown(By locator, String text) throws Exception {
		WebElement element = getElement(locator);
		
		element.click();
		element.sendKeys(text);
		
		Thread.sleep(2000);
		
		element.sendKeys(Keys.DOWN);
		element.sendKeys(Keys.ENTER);
	}
	
	protected String getElementText(By locator) throws Exception {
		boolean status = true;
		
		String returnText = "RandDom";
		
		try{
			logger.info("Getting text using locator [" + locator + "]");
			waitForElementToBeClickable(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
			returnText = getElement(locator).getText().trim();
		}catch(Exception e){
			status = false;
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[GetText] On Element  [" + locator + "]");
		}
		
		return returnText;
	}
	
	protected String getElementText(String elementName, By locator) throws Exception {
		boolean status = true;
		
		String returnText = "RandDom";
		
		try{
			logger.info("Getting text On Element [" + elementName + "] using locator [" + locator + "]");
			waitForElementToBeClickable(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
			returnText = getElement(locator).getText().trim();
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "GetText", "", returnText, status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[GetText] On Element  [" + elementName + "] with Text[" + returnText + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[GetText] On Element  [" + elementName + "]");
		}
		
		return returnText;		
	}
	
	protected String getElementAttribute(By locator, String attrName) throws Exception {
		Boolean status = true;
		String returnAttrValue = "RandDom";
		
		try{
			logger.info("Getting Element Attribute ["+attrName + "] using locator ["+locator+"]");
			waitForElementToBeClickable(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
			returnAttrValue= getElement(locator).getAttribute(attrName);
		}catch(Exception e){
			status = false;
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[GetAttrValue] On locator  [" + locator + "] with Text[" + returnAttrValue + "]");
		}
		
		return returnAttrValue;
	}
	
	protected void validateElementAttribute(String elementName, By locator, String attrName, String expAttrValue) throws Exception {
		boolean status = true;
		String actualAttrValue = null;
		
		try{
			logger.info("Getting Element Attribute ["+attrName + "] on Element ["+ elementName+"] using locator ["+locator+"]");
			
			//waitForElementToBeClickable(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
			
			actualAttrValue = getElement(locator).getAttribute(attrName);
				
			if(!actualAttrValue.equalsIgnoreCase(expAttrValue)){
				status = false;
			}
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "ValidateAttr", attrName +" | "+ expAttrValue, attrName + " | " + actualAttrValue, status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[ValidateAttr] On Element  [" + elementName + "] with Text[" + actualAttrValue + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[ValidateAttr] On Element  [" + elementName + "] with Text[" + actualAttrValue + "]");
		}		
	}
	
	protected String getElementAttribute(String elementName, By locator, String attrName) throws Exception {
		boolean status = true;
		String returnAttrValue = "";
		
		try{
			logger.info("Getting Element Attribute [" + attrName + "] on Element [" + elementName + "] using locator [" + locator + "]");
			waitForElementToBeClickable(locator, DEFAULT_EXPLICIT_WAIT_TIMEOUT);
			returnAttrValue = getElement(locator).getAttribute(attrName);
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "GetAttrValue", "", returnAttrValue, status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[GetAttrValue] On Element  [" + elementName + "] with Attribute Name[" + attrName + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[GetAttrValue] On Element  [" + elementName + "] with Attribute Name[" + attrName + "]");
		}
		
		return returnAttrValue;
	}
	
	protected String getElementAttributeWhenDisabled(String elementName, String locatorType, String locatorValue, String attrName) throws Exception {
		boolean status = true;
		String returnAttrValue = "RandDom";
		
		try{
			logger.info("Getting Element Attribute ["+attrName + "] on Element ["+ elementName+"] using locator Type ["+locatorType+"]  and Locator Value ["+ locatorValue + "]");
			returnAttrValue = executeJS(locatorType, locatorValue, attrName);
		}catch(Exception e){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "GetAttrValue", "", returnAttrValue, status, "");
		}catch (IOException e){
			throw new Exception(htmlReportErrorSyntax + "[GetAttrValue] On Element  [" + elementName + "] with Text[" + returnAttrValue + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[GetAttrValue] On Element  [" + elementName + "] with Text[" + returnAttrValue + "]");
		}
		
		return returnAttrValue;
	}
	
	protected void validateTextEquals(String elementName, By locator, String expectedText) throws Exception {
		boolean status = true;
		
		String actualText = "";
		actualText = getElementText(locator).trim();
		
		logger.info("Comparing expected text ["+expectedText + "] With actual Text [" + actualText + "]");
		
		if(!actualText.equals(expectedText.trim())){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyTextEqual", expectedText, actualText, status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyTextEqual] On Element  [" + elementName + "] with Text[" + expectedText + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[VerifyTextEqual] On Element  [" + elementName + "] with Text[" + expectedText + "] Actual Text [" + actualText + "]");
		}
	}
	
	protected void validateTextEquals(String elementName, String actualText, String expectedText) throws Exception {
		boolean status = true;
			
		if(!actualText.trim().equals(expectedText.trim())){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyTextEqual", expectedText, actualText, status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyTextEqual] On Element  [" + elementName + "] with Text[" + expectedText + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[VerifyTextEqual] On Element  [" + elementName + "] with Text[" + expectedText + "] Actual Text [" + actualText + "]");
		}
	}
	
	protected void validateTextEquals_WithoutException(String elementName, String actualText, String expectedText) throws Exception {
		boolean status = true;
			
		if(!actualText.trim().equals(expectedText.trim())){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyTextEqual", expectedText, actualText, status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyTextEqual] On Element  [" + elementName + "] with Text[" + expectedText + "]");
		}
	}
	
	protected void validateTextContains(String elementName, By locator, String expectedText) throws Exception {
		boolean status = true;
		
		String actualText = "";
		actualText = getElementText(locator);
		
		logger.info("Comparing expected text [" + expectedText + "] With actual Text [" + actualText + "]");
		
		if(!actualText.contains(expectedText)){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyTextContain", expectedText, actualText, status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyTextContain] On Element  [" + elementName + "] with Text[" + expectedText + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[VerifyTextContain] On Element  [" + elementName + "] with Text[" + expectedText + "] Actual Text [" + actualText + "]");
		}
	}
	
	protected void validateTextContains(String elementName, String actualText, String expectedText) throws Exception {
		boolean status = true;
			
		if(!actualText.contains(expectedText)){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyTextContain", expectedText, actualText, status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyTextContain] On Element  [" + elementName + "] with Text[" + expectedText + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[VerifyTextContain] On Element  [" + elementName + "] with Text[" + expectedText + "] Actual Text [" + actualText + "]");
		}
	}
	
	protected void softValidateTextContains(String elementName, String actualText, String expectedText) throws Exception {
		boolean status = true;
			
		if(!actualText.contains(expectedText)){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyTextContain", expectedText, actualText, status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyTextContain] On Element  [" + elementName + "] with Text[" + expectedText + "]");
		}
	}
	
	protected void validateTextNotContains(String elementName, String actualText, String expectedText) throws Exception {
		boolean status = true;
			
		if(actualText.contains(expectedText)){
			status = false;
		}
		
		try{
			TestReport.stepResultInHTML(driver, testCaseId, elementName, "VerifyTextNotContain", expectedText, actualText, status, "");
		}catch(IOException e){
			throw new Exception(htmlReportErrorSyntax + "[VerifyTextNotContain] On Element  [" + elementName + "] with Text[" + expectedText + "]");
		}
		
		if(status == false){
			throw new Exception(keywordActionErrorSyntax + "[VerifyTextNotContain] On Element  [" + elementName + "] with Text[" + expectedText + "] Actual Text [" + actualText + "]");
		}
	}
	
	protected boolean isAttributePresent(By Locator, String attrName) {
		Boolean attributeFound = false;
		
		try{
			String attrValue = getElementAttribute(Locator, attrName);
		
			if(attrValue == null){
				attributeFound = false;
			}else{
				attributeFound = true;
			}
			
		}catch(Exception e){
			logger.info("Attribute not Found. So Ignored [" + attrName + "] locator [" + Locator + "]");
		}
		return attributeFound;
	}
	
	protected int getElementIndexUsingText(By locator, String elementText) {
		List<String> listAttr = new ArrayList<String>();
		
		int elementIndex = -1;
		
		boolean found = false;
		
		List<WebElement> webElements = getElements(locator);

		for(WebElement webElement : webElements){
			elementIndex++;
			
			String elmentTextFound = webElement.getText();
			
			listAttr.add(elmentTextFound);
			
			if(elmentTextFound.contains(elementText)){
				found=true;
				break;
			}
		}
		
		if(found == false){
			new RuntimeException("For Locator [" + locator + "] element Text [" + elementText + "] was not found . Actual Element Text Found was " + listAttr );
		}
		return elementIndex;
	}
	
	protected void waitForElementCountToBeAsExpected(By locator, int expectedCount, int timeInSecond) {
		Boolean expectedCountMatch = false;
		
		for(int counter = 0; counter < timeInSecond; counter++){
			try{
				Thread.sleep(1000);
			}catch (InterruptedException e){
				e.printStackTrace();
			}
			
			List<WebElement> listElement = getElements(locator);
			
			if(listElement.size() == expectedCount){
				expectedCountMatch = true;
				break;
			}
		}

		if(expectedCountMatch == false){
			new RuntimeException("For Locator [" + locator + "] ExpectedCount [" + expectedCount + "] is incorrect Tried for [" + timeInSecond + "] Seconds");
		}
	}
	
	private void checkPageReadyState() {
		for(int i = 0; i < 15; i++){ 
            try{ Thread.sleep(500); }catch(InterruptedException e){} 
            //To check page ready state.
            if(((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete")){ 
            	break; 
            }   
		}
	}

	
	// ******* TABLE RELATED COMMAND STARTED *******************
	
	/*protected int getColumnIndex(By tableLocator, String headerName) {
		List<String> headerListFound = new ArrayList<String>();
		
		int columnIndex = -1;
		
		boolean columnFound=false;
		
		List<WebElement> webElements = getElement(tableLocator)
				.findElement(By.tagName("thead"))
				.findElement(By.tagName("tr"))
				.findElements(By.tagName("th"));

		for(WebElement webElement : webElements){
			columnIndex++;
			
			String headerTextFound = webElement.getText();
			
			headerListFound.add(headerTextFound);
			
			if(headerTextFound.contains(headerName)){
				columnFound=true;
				break;
			}
		}
		
		if(columnFound == false){
			new RuntimeException("For Table [" + tableLocator + "] Header Name [" + headerName + "] was not found . Actual Header Found was " + headerListFound );
		}
		
		return columnIndex;
	}*/
	
}
