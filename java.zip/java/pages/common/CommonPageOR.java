package pages.common;

import org.openqa.selenium.By;

/**
 * 
 * @author Vinay Kumar
 *
 */
public interface CommonPageOR {

	static final By saveAndContinueBtn = By.id("nextPage");
	static final By nextButton = By.id("nextButton");
	static final By nextBtn = By.id("nextBtn");
	static final By oKButton = By.id("OKButton");
	static final By prevBtn = By.id("prevBtn");
	static final By backBtn = By.id("backBtn");
	static final By backButton = By.id("backButton");
	static final By cancelBtn = By.id("cancel");
	static final By saveBtn = By.id("save");
	static final By saveAndRerunEligiilityBtn = By.id("saveAndReRunEligibility");
	
	static final By verifyManualBtn = By.id("isVerifyManuallyDecision");
	
	static final By addNewNoteDialog = By.xpath("//div[@role='heading' and contains(text(),'Add New Note')]");
	
	static final By popupYesBtn = By.xpath("//span[text()='Yes']");
	static final By popupNoBtn = By.xpath("//span[text()='No']");
	static final By popupOkBtn = By.xpath("//span[text()='OK']");
	static final By popupCancelBtn = By.xpath("//span[text()='Cancel']");
	static final By popupCloseBtn = By.xpath("//span[text()='Close']");
	static final By popupConfirmBtn = By.xpath("//span[text()='Confirm']");
	static final By popupAgreeBtn = By.xpath("//span[text()='Agree']");
	
	static final By alertDialog = By.xpath("//h1[@id='popup_title' and text()='Alert']");
	static final By alertOkButton = By.id("popup_ok");
	static final By alertCancelButton = By.id("popup_cancel");
	
	static final By warningDialogH1 = By.xpath("//h1[@id='popup_title' and text()='Warning']");
	static final By warningDialogH2 = By.xpath("//h2[@id='popup_title' and text()='Warning']");
	static final By warningOkButton = By.id("popup_ok");

}
