package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class ResetPasswordOptumIdPage extends CommonPage implements CommonPageOR {
	
	private static final By resetPasswordOptumIdPageHeader= By.id("resetPasswordHeaderID");
	
	private static final By newPasswordTxt = By.id("newPasswordId_input");
	private static final By confirmPasswdTxt = By.id("confirmPasswdId_input");
	
	public ResetPasswordOptumIdPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ResetPswdOptumIdPageHeader", resetPasswordOptumIdPageHeader);
	}
	
	private void enterNewPassword(String password) throws Exception {
		clearAndType("NewPasswordTxt" , newPasswordTxt, password);
	}
	
	private void validateNewPasswordAttribute() throws Exception {
		validateElementAttribute("NewPasswordTxt" , newPasswordTxt, "type", "password");
	}
	
	private void enterConfirmPasswd(String password) throws Exception {
		clearAndType("ConfirmPasswdTxt" , confirmPasswdTxt, password);
	}

	private void validateConfirmPasswordAttribute() throws Exception {
		validateElementAttribute("ConfirmPasswdTxt" , confirmPasswdTxt, "type", "password");
	}
	
	private void clickOnNextButton() throws Exception {
		clickOnElement("NextButton", nextButton);
	}

	public void pageLoadAndValidatePasswordIsMasked() throws Exception{
		waitForPageLoaded();
		enterNewPassword("Dummy@123");
		enterConfirmPasswd("Dummy@123");
		validateNewPasswordAttribute();
		validateConfirmPasswordAttribute();
		takeScreenshot("PasswordMask");
	}
	
		
}
