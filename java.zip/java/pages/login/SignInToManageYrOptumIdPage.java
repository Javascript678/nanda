package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class SignInToManageYrOptumIdPage extends CommonPage implements CommonPageOR {
	
	private static final By signInToMngYrOptumIdPageHeader= By.id("signInManageOptumID");
	
	private static final By userNameTxt = By.id("userNameId_input");
	private static final By passwdTxt = By.id("passwdId_input");
	private static final By manageMyOptumIdBtn = By.id("SignIn");
	
	public SignInToManageYrOptumIdPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("SignInToMngYrOptmIdPageHeader", signInToMngYrOptumIdPageHeader);
	}
	
	private void enterUserName(String userName) throws Exception {
		clearAndType("UserNameTxt" , userNameTxt, userName);
	}
	
	private void enterPassword(String password) throws Exception {
		clearAndType("PasswdTxt" , passwdTxt, password);
	}
	
	private void clickOnManageMyOptumIdBtn() throws Exception {
		clickOnElement("ManageMyOptumIdBtn", manageMyOptumIdBtn);
	}

	public void enterUserNameAndPassword(String userName, String password) throws Exception{
		waitForPageLoaded();
		enterUserName(userName);
		enterPassword(password);
		clickOnManageMyOptumIdBtn();
	}
	
		
}
