package pages.login;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import pages.common.CommonPage;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class GuerrillaPage extends CommonPage{

	public GuerrillaPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public String getOTPFromGuerrilla(String emailAddress) throws Exception {
		String otp = null;

		String optumID = emailAddress.split("@")[0];
			String parentWindow = driver.getWindowHandle();

			
			try {
				
				((JavascriptExecutor) driver).executeScript("window.open()");
				ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				
				driver.get("https://www.guerrillamail.com/");

				String currentTitle = driver.getTitle();

				if (! currentTitle.contains("Guerrilla Mail")) {
					Boolean isPresentBtn1 = false, isPresentBtn2 = false;
					Boolean agreementHandled = false;

					By iAgreeBtn1 = By.xpath("//a[contains(text(),'Click here to accept this')]");
					By iAgreeBtn2 = By.xpath("//b[contains(text(),'I AGREE')]/../../a");

					isPresentBtn1 = isElementPresent(iAgreeBtn1, 5);
					if (isPresentBtn1) {
						driver.findElement(iAgreeBtn1).click();
						Thread.sleep(2000);

						if (!driver.getTitle().equalsIgnoreCase("Guerrilla Mail")) {
							isPresentBtn2 = isElementPresent(iAgreeBtn2, 5);
							if (isPresentBtn2) {
								driver.findElement(iAgreeBtn2).click();
								agreementHandled = true;
							}
						} else {
							agreementHandled = true;
						}
					}

					if (!agreementHandled) {
						isPresentBtn2 = isElementPresent(iAgreeBtn2, 1);
						if (isPresentBtn2) {
							driver.findElement(iAgreeBtn2).click();
							Thread.sleep(2000);

							if (!driver.getTitle().equalsIgnoreCase("Guerrilla Mail")) {
								isPresentBtn1 = isElementPresent(iAgreeBtn1, 5);
								if (isPresentBtn1) {
									driver.findElement(iAgreeBtn1).click();
								}
							}
						}
					}

				} // end of notification policy acknowledgement

				By hostDropDown = By.id("gm-host-select");

				waitForPresenceOfElementLocated(hostDropDown, 40);

				Select hostDropDownSelect = new Select(driver.findElement(hostDropDown));
				hostDropDownSelect.selectByVisibleText("guerrillamail.com");

				By emailIDResetBox = By.id("inbox-id");
				driver.findElement(emailIDResetBox).click();

				By emaidIdTextField = By.xpath("//span[@id='inbox-id']/input");
				driver.findElement(emaidIdTextField).clear();
				driver.findElement(emaidIdTextField).sendKeys(optumID);

				By emaidIdSetBtn = By.xpath("//span[@id='inbox-id']/button[1]");
				driver.findElement(emaidIdSetBtn).click();

				By emailTab = By.id("nav-item-inbox");
				driver.findElement(emailTab).click();

				By emailList = By.xpath("//tbody[@id='email_list']/tr");

				waitForElementCountToBeAsExpected(emailList, 2, 20);

				By emailOneSubject = By.xpath("//tbody[@id='email_list']/tr[1]/td[2]");
				driver.findElement(emailOneSubject).click();

				By emailBody = By.xpath("//p[contains(text(),'If you prefer, copy this 10-digit code ')]");

				try {
					waitForPresenceOfElementLocated(emailBody, 20);
				} catch (TimeoutException e) {
					// some time 404 error occurs to handle it try to click on Inbox
					// Again and fetch OTP
					driver.findElement(emailTab).click();
					waitForElementCountToBeAsExpected(emailList, 2, 20);
					driver.findElement(emailOneSubject).click();
					waitForPresenceOfElementLocated(emailBody, 20);
				}

				String emailContent = driver.findElement(emailBody).getText();

				String endresultnumber11 = emailContent.trim().split("10-digit code ")[1];
				otp = endresultnumber11.split(" and")[0];

				driver.close();
				driver.switchTo().window(parentWindow);
			} catch (Exception e) {
				driver.close();
				driver.switchTo().window(parentWindow);
				throw new Exception("Could Not Get OTP From Guerrilla Mail Page");
			}
		
		return otp;
	}

}
