package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import enums.BrowserName;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class HomePage extends CommonPage implements CommonPageOR {
	
	YouMayQualify youMayQualify = new YouMayQualify();

	private static final By agentManageCustProfileLink = By.xpath("//a[contains(text(),'Manage Customer')]");
	private static final By agentCreateCustProfileLink = By.xpath("//a[contains(text(),'Create Customer Profile')]");
	
	private static final By individualMyAccountLink = By.xpath("//a[contains(text(),'My Account')]");
	
	private static final By assisterManageMembersLink	=	By.id("manageClient1");
	private static final By assisterAddNewMemberLink	=	By.id("addNewClient");


	private static final By signInBtn = By.xpath("//form[@id='signin']/div/input[@type='submit']");
	private static final By logOutBtn = By.id("logout");
	private static final By previewPlanBtn = By.id("anonymousShopping");
	
	
	private static final By myProfileTab = By.xpath("//li[@id='section_begin']/a[contains(text(),'My Profile')]");
	private static final By myEligibilityTab = By.xpath("//li[@id='section_basicinfo']/a[contains(text(),'My Eligibility')]");
	private static final By myAppealsTab = By.xpath("//li[@id='myappeal']/a[contains(text(),'My Appeals')]");
	private static final By myEnrollmentsTab = By.xpath("//a[contains(text(),'My Enrollments')]");
	private static final By myAssistersTab = By.xpath("//a[contains(text(),'My Assisters')]");
	
	private static final By premiumAssistanceTab = By.xpath("//a[contains(text(),'Premium Assistance')]");
	private static final By viewAppSummaryTab = By.xpath("//a[contains(text(),'View Application Summary')]");
	private static final By viewMedicaidHouseholdTab = By.xpath("//a[contains(text(),'View Medicaid Household')]");
	private static final By viewMedicaidNoticesTab = By.xpath("//a[contains(text(),'View Medicaid Notices')]");
	
	private static final By findACustomerTab = By.xpath("//li[contains(@class,'subNavSection')]/a[contains(text(),'Find a Customer')]");
	private static final By findAndViewMedicaidNoticesTab = By.xpath("//li[contains(@class,'subNavSection')]/a[contains(text(),'Find and View Medicaid Notices')]");
	private static final By viewVLP2And3CasesTab = By.xpath("//li[contains(@class,'subNavSection')]/a[contains(text(),'View VLP 2 and 3 Cases')]");
	
	private static final By qualificationStepsDoYouQualifyTab = By.xpath("//li[contains(@class,'subNavSection')]/a[contains(text(),'Do You Qualify?')]");
	private static final By qualificationStepsFamilyDetailsTab = By.xpath("//li[contains(@class,'subNavSection')]/a[contains(text(),'Family Details')]");
	private static final By qualificationStepsIncomeDetailsTab = By.xpath("//li[contains(@class,'subNavSection')]/a[contains(text(),'Income Details')]");
	private static final By qualificationStepsEligibilityResultsTab = By.xpath("//li[contains(@class,'subNavSection')]/a[contains(text(),'Eligibility Results')]");
	
	private static final By accountDashboardTab = By.xpath("//a[contains(text(),'Account Dashboard')]");
	
	private static final By renewalInitiatedHeader = By.xpath("//div[@id='appStatusSecs']//strong[contains(text(), 'Renewal In-Progress')]");
	
	public HomePage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForAgentPortalPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("CreateCustProfileLink", agentCreateCustProfileLink);
	}
	
	public void waitForRenewalInitiated() throws Exception {
		waitForPresenceOfElementLocated("RenewalInitiated", renewalInitiatedHeader);
	}
	
	private void clickOnManageCustomerLink() throws Exception {
		clickOnElement("ManageCustProfileLink" , agentManageCustProfileLink);
	}
	
	private void clickOnCreateCustomerProfileLink() throws Exception {
		clickOnElementAfterWait("CreateCustProfileLink", agentCreateCustProfileLink, 7);
	}
	
	private class YouMayQualify {		
		private final By zipCodeTxt = By.id("zip");
		private final By coverageStartDateDD = By.id("elg_effectiveDate");
		private final By helpForPayingRdBtn = By.name("publicProgram");
		private final By startNowBtn = By.id("submitForEligibility");
		
		private void enterZipCode(String zipCode) throws Exception {
			clearAndType("ZipCodeTxt", zipCodeTxt, zipCode);
		}
		
		private void selectCoverageStartDate(String coverageStrDate) throws Exception {
			selectByVisibleTextAfterWait("CoverageStrDateDD", coverageStartDateDD, coverageStrDate);
		}
		
		private void selectIfHelpNeededForPaying(boolean trueFalseValue) throws Exception {
			selectByValue("HelpForPayingRdBtn", helpForPayingRdBtn, trueFalseValue + "");
		}
		
		private void clickOnStartNowBtn() throws Exception {
			clickOnElement("StartNowBtn", startNowBtn);
		}
	}
	
	public void agentPageLoadAndClickOnManageCustomerLink() throws Exception {
		//waitForAgentPortalPageLoaded();
		clickOnManageCustomerLink();
	}
	
	public void agentPageLoadAndClickOnCreateCustomerProfileLink() throws Exception {
		//waitForAgentPortalPageLoaded();
		clickOnCreateCustomerProfileLink();
	}
	
	public void dismissNoteIfPresent() throws Exception {
		if(isNotePresent()){
			clickOnAddANoteNoBtn();
		}
	}
	
	public void clickOnSignInBtn() throws Exception {
		clickOnElement("SignInBtn", signInBtn);
	}
	
	public void clickOnLogOutBtn() throws Exception {
		clickOnElementThenWait("LogOutBtn", logOutBtn, 20);
	}
	
	public void clickOnPreviewPlanBtn() throws Exception {
		clickOnElementThenWait("PreviewPlanBtn", previewPlanBtn, 5);
	}
	
	//********* ADD NOTE related behaviour START *********//
	
	public boolean isNotePresent() throws Exception {
		return isElementPresent(addNewNoteDialog);
	}
	
	public void clickOnAddANoteYesBtn() throws Exception {
		By noteDialogYesBtn = By.xpath("//div[contains(text(),'Add New Note')]/../..//span[text()='Yes']");
		clickOnElement("NoteYesBtn", noteDialogYesBtn);
	}

	public void clickOnAddANoteNoBtn() throws Exception {
		By noteDialogNoBtn = By.xpath("//div[contains(text(),'Add New Note')]/../..//span[text()='No']");
		clickOnElement("NoteNoBtn", noteDialogNoBtn);
	}
	
	public void clickOnNotesIcon() throws Exception{
		By notesIcon = By.id("noteBtn");
		clickOnElement("NotesIcon", notesIcon);
	}
	
	public void validateNoNotesText(String expNoNotesTxt) throws Exception {
		By actualNoNoteText = By.id("viewNoteData");
		validateTextContains("No Notes Present Text",actualNoNoteText,expNoNotesTxt);
	}
	
	public void clickOnWriteNoteBtn() throws Exception {
		By writeNoteBtn = By.id("write-note");
		clickOnElement("WriteNoteBtn", writeNoteBtn);
	}
	
	public void enterNotesText(String notesText) throws Exception {
		By notesTxtBox = By.id("caseNoteText");
		clickOnElement("NotesBox", notesTxtBox);
		clearAndType("NotesTxt" , notesTxtBox ,notesText);
	}
	
	public void clickOnSaveNoteBtn() throws Exception {
		By saveNoteBtn = By.id("saveNoteCaseNote");
		clickOnElement("SaveNoteBtn", saveNoteBtn);
	}
	
	public void takeScreenShot() throws Exception {
		takeScreenshot("Summary");
	}
	
	//********** ADD NOTE related behaviour END **********//
	
	//**** Individual portal related behaviour START *****//
	
	public void clickOnMyAccountLink() throws Exception {
		clickOnElement("MyAccountLink" , individualMyAccountLink);
	}
	
	public void clickOnMyProfileTab() throws Exception{
		clickOnElement("MyProfileTab", myProfileTab);
	}
	
	public void clickOnMyEligibilityTab() throws Exception {
		clickOnElement("MyEligibilityTab", myEligibilityTab);
	}
	
	public void clickOnMyAppealsTab() throws Exception{
		clickOnElement("MyAppealsTab", myAppealsTab);
	}
	
	public void clickOnMyEnrollmentsTab() throws Exception {
		clickOnElement("MyEnrollmentsTab", myEnrollmentsTab);
	}
	
	public void clickOnMyAssistersTab() throws Exception {
		clickOnElement("MyAssistersTab", myAssistersTab);
	}
	
	public void clickOnPremiumAssistanceTab() throws Exception {
		clickOnElement("PremiumAssistanceTab", premiumAssistanceTab);
	}
	
	public void clickOnViewAppSummaryTabTab() throws Exception {
		clickOnElement("ViewAppSummaryTab", viewAppSummaryTab);
	}
	
	public void clickOnViewMedicaidHouseholdTab() throws Exception {
		clickOnElement("ViewMedicaidHouseholdTab", viewMedicaidHouseholdTab);
	}
	
	public void clickOnViewMedicaidNoticesTab() throws Exception {
		clickOnElement("ViewMedicaidNoticesTab", viewMedicaidNoticesTab);
	}
	
	//****** Individual portal related behaviour END ******//

	//****** Assister portal related behavior Start *******//
	
	public void clickOnManageMembersLink() throws Exception {
		clickOnElementThenWait("AssisterManageMembersLink", assisterManageMembersLink, 15);
	}
	
	public void clickOnAddNewMemberLink() throws Exception {
		clickOnElement("AssisterAddNewMemberLink", assisterAddNewMemberLink);
	}
	//******* Assister portal related behavior END ********//
	
	//********* Find a Customer Related Tab Start *********//
	
	public void clickOnFindACustomerTab() throws Exception {
		clickOnElement("FindACustomerTab", findACustomerTab);
	}
	
	public void clickOnFindAndViewMedicaidNoticesTab() throws Exception {
		clickOnElement("FindAndViewMedicaidNoticesTab", findAndViewMedicaidNoticesTab);
	}
	
	public void clickOnViewVLP2And3CasesTab() throws Exception {
		clickOnElement("ViewVLP2And3CasesTab", viewVLP2And3CasesTab);
	}
	
	//********** Find a Customer Related Tab END **********//
	
	//********* Do you Qualify Related Tab Start **********//
	
	public void clickOnQualificationStepsDoYouQualifyTab() throws Exception {
		clickOnElement("DoYouQualifyTab", qualificationStepsDoYouQualifyTab);
	}
	
	public void clickOnQualificationStepsFamilyDetailsTab() throws Exception {
		clickOnElement("FamilyDetailsTab", qualificationStepsFamilyDetailsTab);
	}
	
	public void clickOnQualificationStepsIncomeDetailsTab() throws Exception {
		clickOnElement("IncomeDetailsTab", qualificationStepsIncomeDetailsTab);
	}
	
	public void clickOnQualificationStepsEligibilityResultsTab() throws Exception {
		clickOnElement("EligibilityResultsTab", qualificationStepsEligibilityResultsTab);
	}
	
	//********** Do you Qualify Related Tab END ***********//
		
	public void clickOnAccountDashboardTab() throws Exception {
		clickOnElement("AccountDashboardTab", accountDashboardTab);
	}
	
	public void submitYouMayQualifyDetails(String zipCode, String coverageStrDate, boolean heplNeededForPaying) throws Exception {
		youMayQualify.enterZipCode(zipCode);
		youMayQualify.selectCoverageStartDate(coverageStrDate);
		youMayQualify.selectIfHelpNeededForPaying(heplNeededForPaying);
		youMayQualify.clickOnStartNowBtn();
	}
	
	public void refreshPageToRemoveReaderViewIssueInSauceLab(String browserToUse) throws Exception {
		//page is being refreshed to handle Reader View issue in Sauce Lab
		if(browserToUse.equals(BrowserName.SAUCE_LAB_FF.val)){
			Thread.sleep(10000);
			driver.navigate().refresh();
			Thread.sleep(2000);
			driver.navigate().refresh();
			Thread.sleep(3000);
		}
	}
}
