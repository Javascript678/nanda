package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.common.OptumIdData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */

public class CreateOptumIdPage extends CommonPage implements CommonPageOR {
	
	private static final By EmailAddressVerifiedHeader = By.xpath("//h1[contains(.,'Email Address Verified')]");
	//private static final By ShareMyOptumIDHeader = By.xpath("//h1[contains(.,'Share My Optum ID')]");
	private static final By ShareMyOptumIDHeader = By.xpath("//h1[contains(.,'Share My MA Login')]");
	
	private static final By firstNameTxt = By.id("firstNameId_input");
	private static final By lastNameTxt = By.id("lastNameId_input");
	private static final By yobTxt= By.id("yobId_input");
	private static final By dobTxt= By.id("dob_id_dob");
	private static final By emailIdTxt = By.id("emailAddressId_input");
	private static final By userNameTxt = By.id("userNameId_input");
	private static final By createPaswdTxt = By.id("pwdId_input");
	private static final By confirmPaswdTxt = By.id("confirmPwdId_input");	
	private static final By secAns1Txt = By.id("secAnswerOneId_input");
	private static final By secAns2Txt = By.id("secAnswerTwoId_input");
	private static final By secAns3Txt = By.id("secAnswerThreeId_input");
	private static final By iAgreeBtn = By.id("agreeButtonId");
	private static final By cancelBtn = By.id("cancelLink");
	private static final By continueBtn	= By.xpath("//input[contains(@value,'Continue')]");
	private static final By agreeBtn = By.id("agreeButton");
	// private static final By enterActivationCodeBtn = By.id("enterCnfrmCodeLinkId");
	// private static final By confirmActivationCodeTxt = By.id("confirmCode_input");
	// private static final By nextBtn = By.id("verifyButton");
	// private static final By guerillaContinueBtn = By.xpath("//h1[@id='confirmEmailHeader']/../div[2]/input");
	// private static final By shareMyOptumIdAgreeBtn = By.xpath("//a[@id='declineLink']/../input[@id='agreeButton']");
	
	public CreateOptumIdPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	// added by ppinho
	private void waitForEmailAddressVerifiedHeader() throws Exception {
		waitForPresenceOfElementLocated("EmailAddressVerifiedHeader", EmailAddressVerifiedHeader);
	}
	
	// added by ppinho
	private void waitForShareMyOptumIDHeader() throws Exception {
		waitForPresenceOfElementLocated("ShareMyOptumIDHeader", ShareMyOptumIDHeader);
	}
		
	private void enterFirstName(String firstName) throws Exception {
		clearAndType("FirstNameTxt", firstNameTxt, firstName);
	}
	
	private void enterLastName(String lastName) throws Exception {
		clearAndType("LastNameTxt", lastNameTxt, lastName);
	}
	
	private void enterYOB(int yob) throws Exception {
		enterTextWithoutTab(yobTxt, yob+"");
	}
	
	private void enterDOB(String dob) throws Exception {
		enterTextWithoutTab(dobTxt, dob+"");
	}
	
	private void enterEmailId(String emailId) throws Exception {
		clearAndType("EmailIdTxt", emailIdTxt, emailId);
	}
	
	private void enterUserName(String userName) throws Exception {
		clearAndType("UserNameTxt", userNameTxt, userName);
	}
	
	private void enterCreatePassword(String password) throws Exception {
		clearAndType("CreatePaswdTxt", createPaswdTxt, password);
	}
	
	private void validateCreatePasswordAttribute() throws Exception {
		validateElementAttribute("CreatePaswdTxt", createPaswdTxt, "type", "password");
	}
	
	private void enterConfirmCreatePassword(String password) throws Exception {
		clearAndType("ConfirmPaswdTxt", confirmPaswdTxt, password);
	}
	
	private void validateConfirmCreatePasswordAttribute() throws Exception {
		validateElementAttribute("ConfirmPaswdTxt", confirmPaswdTxt, "type", "password");
	}
	
	private void selectQueByIndex(int quesNo, int index) throws Exception {
		By selectQueIndex= By.id("secQues"+quesNo+"Id");
		selectByIndexAfterWait("SelectQ"+quesNo+"Index", selectQueIndex, index);
	}
	
	private void selectQueByVisibleTxt(int quesNo, String txt) throws Exception {
		By selectQueIndex= By.id("secQues" + quesNo + "Id");
		selectDropDownElementByVisibleText("SelectQ" + quesNo + "Index", selectQueIndex, txt);
	}
	
	private void enterSec1Answer(String answer1) throws Exception {
		clearAndType("SecAns1Txt", secAns1Txt, answer1);
	}
	
	private void enterSec2Answer(String answer2) throws Exception {
		clearAndType("SecAns2Txt", secAns2Txt, answer2);
	}
	
	private void enterSec3Answer(String answer3) throws Exception {
		clearAndType("SecAns3Txt", secAns3Txt, answer3);
	}
	
	private void clickOnIAgreeBtn() throws Exception {
		clickOnElement("IAgreeBtn", iAgreeBtn);
	}
	
	private void clickOnContinueBtn() throws Exception {
		clickOnElement("ContinueBtn", continueBtn);
	}
	
	private void clickOnAgreeBtn() throws Exception {
		clickOnElement("AgreeBtn", agreeBtn);
	}
	
	// added by ppinho
	private void completeOptumIdRegistration() throws Exception {
		waitForEmailAddressVerifiedHeader();
		clickOnContinueBtn();
		
		waitForShareMyOptumIDHeader();
		clickOnAgreeBtn();
	}
	
	/*private void clickOnEnterTheActivationCodeBtn() throws Exception {
		clickOnElement("EnterActivationCodeBtn", enterActivationCodeBtn);
	}
	
	private void enterActivationCode(String otp) throws Exception {
		clearAndType("ConfirmActivationCodeTxt", confirmActivationCodeTxt, otp);
	}
	
	private void clickOnNextBtn() throws Exception {
		clickOnElement("NextBtn", nextBtn);
	}
	
	private void clickOnGuerillaContinueBtn() throws Exception {
		clickOnElementThenWait("ContinueBtn", guerillaContinueBtn, 5);
	}
	
	private void clickOnShareMyOptumIdAgreeBtn() throws Exception {
		clickOnElementThenWait("ShareMyOptumIdAgreeBtn", shareMyOptumIdAgreeBtn, 5);
	}*/
	
	public void createOptumId(OptumIdData optumIdData) throws Exception {
		enterFirstName(optumIdData.firstName);
		enterLastName(optumIdData.lastName);	
		enterYOB(optumIdData.yearOfBirth);
		//enterDOB(optumIdData.dateOfBirth);
		enterEmailId(optumIdData.emailAddress);
		enterUserName(optumIdData.optumId);
		enterCreatePassword(optumIdData.password);
		enterConfirmCreatePassword(optumIdData.password);
		
		//selectQueByIndex(1, optumIdData.createOptumIdQue1Index);
		selectQueByVisibleTxt(1, optumIdData.createOptumIdPhoneQue);
		enterSec1Answer(optumIdData.createOptumIdAnsForPhone);
		
		//selectQueByIndex(2, optumIdData.createOptumIdQue2Index);
		selectQueByVisibleTxt(2, optumIdData.createOptumIdFriendQue);
		enterSec2Answer(optumIdData.createOptumIdAnsForFriend);
		
		//selectQueByIndex(3, optumIdData.createOptumIdQue3Index);
		selectQueByVisibleTxt(3, optumIdData.createOptumIdColorQue);
		enterSec3Answer(optumIdData.createOptumIdAnsForColor);
		
		takeScreenshot("OptumID");
		clickOnIAgreeBtn();
		
		/* * @author ppinho
		 * 
		 * Using Getnada REST API to Activate Optum ID
		 * 
		 * */
		
		Getnada getnada = new Getnada(driver, testCaseId);
		getnada.activateOptumID(optumIdData.emailAddress);
		
		completeOptumIdRegistration();
		
		/* *
		 * 
		 * Existing Guerrilla Mail Code - backup option
		 * 
		 * GuerrillaPage guerrillaPage = new GuerrillaPage(driver, testCaseId);
		 * String otp = guerrillaPage.getOTPFromGuerrilla(optumIdData.emailAddress);
		 * System.out.println("OTP Generated is [ " + otp + "]");
		 * 
		 * clickOnEnterTheActivationCodeBtn();
		 * enterActivationCode(otp);
		 * clickOnNextBtn();
		 * clickOnGuerillaContinueBtn();
		 * clickOnShareMyOptumIdAgreeBtn();
		 * 
		 * */
	}
	
	public void verifyPasswordFieldIsMasked() throws Exception {
		enterCreatePassword("Dummy@123");
		enterConfirmCreatePassword("Dummy@123");
		validateCreatePasswordAttribute();
		validateConfirmCreatePasswordAttribute();
		takeScreenshot("PasswordMasking");
	}
	
	//Amrita
	public void clickOnCancelBtn() throws Exception {
		clickOnElement("CancelBtn" , cancelBtn);
	}		
}
