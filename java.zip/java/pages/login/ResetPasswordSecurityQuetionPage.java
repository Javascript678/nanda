package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.common.OptumIdData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class ResetPasswordSecurityQuetionPage extends CommonPage implements CommonPageOR {
	
	private static final By resetPasswordSecurityAnswerPageHeader= By.id("span_headerId_forgotUserPassword");
	private static final By secQues1Label = By.id("labelQuestion1");
	private static final By secQues2Label = By.id("labelSecurityQuestion2_input");
	
	private static final By securityAns1Txt = By.id("securityQuestion1_input");
	private static final By securityAns2Txt = By.id("securityQuestion2_input");
	
	public ResetPasswordSecurityQuetionPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ResetPswdSecrAnsPageHeader", resetPasswordSecurityAnswerPageHeader);
	}
	
	private void enterSecurityAnswer1(String ans1) throws Exception {
		clearAndType("SecurityAns1Txt" , securityAns1Txt, ans1);
	}
	
	private void enterSecurityAnswer2(String ans2) throws Exception {
		clearAndType("SecurityAns2Txt" , securityAns2Txt, ans2);
	}

	private void answerSecurityQuestion1(String secAnsPhone, String secAnsFriend, String secAnsColor,String secAnsPet,String secAnsCountry, String secAnsSports) throws Exception {
		String secQuestion1Label = getElementText("SecQues1Label", secQues1Label).toLowerCase();
		
		if(secQuestion1Label.contains("phone")){
			enterSecurityAnswer1(secAnsPhone);
		}else if(secQuestion1Label.contains("friend")){
			enterSecurityAnswer1(secAnsFriend);
		}else if(secQuestion1Label.contains("color")){
			enterSecurityAnswer1(secAnsColor);
		}else if(secQuestion1Label.contains("pet")){
			enterSecurityAnswer1(secAnsPet);
		}else if(secQuestion1Label.contains("country")){
			enterSecurityAnswer1(secAnsCountry);
		}else if(secQuestion1Label.contains("sports")){
			enterSecurityAnswer1(secAnsSports);
		}
	}
	
	private void answerSecurityQuestion2(String secAnsPhone, String secAnsFriend, String secAnsColor,String secAnsPet,String secAnsCountry, String secAnsSports) throws Exception {
		String secQuestion2Label = getElementText("SecQues2Label", secQues2Label).toLowerCase();
		
		if(secQuestion2Label.contains("phone")){
			enterSecurityAnswer2(secAnsPhone);
		}else if(secQuestion2Label.contains("friend")){
			enterSecurityAnswer2(secAnsFriend);
		}else if(secQuestion2Label.contains("color")){
			enterSecurityAnswer2(secAnsColor);
		}else if(secQuestion2Label.contains("pet")){
			enterSecurityAnswer2(secAnsPet);
		}else if(secQuestion2Label.contains("country")){
			enterSecurityAnswer2(secAnsCountry);
		}else if(secQuestion2Label.contains("sports")){
			enterSecurityAnswer2(secAnsSports);
		}
	}
	
	private void clickOnNextButton() throws Exception {
		clickOnElement("NextButton", nextButton);
	}

	public void pageLoadAndEnterSecurityAnswer(OptumIdData optumIdData) throws Exception{
		waitForPageLoaded();
		String secAnsPhone = optumIdData.sequrityQuePhoneNoAnswer;
		String secAnsFriend = optumIdData.sequrityQueFriendAnswer;
		String secAnsColor = optumIdData.sequrityQueColorAnswer;
		String secAnsPet = optumIdData.sequrityQuePetAnswer;
		String secAnsCountry = optumIdData.sequrityQueCountryAnswer;
		String secAnsSports = optumIdData.sequrityQueSportsAnswer;
		
		answerSecurityQuestion1(secAnsPhone, secAnsFriend, secAnsColor,secAnsPet,secAnsCountry, secAnsSports);
		answerSecurityQuestion2(secAnsPhone, secAnsFriend, secAnsColor,secAnsPet,secAnsCountry, secAnsSports);
		clickOnNextButton();
	}
	
		
}
