package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class ForgotPasswordPage extends CommonPage implements CommonPageOR {
	
	private static final By forgotPasswordPageHeader= By.xpath("//h1[ contains(text(),'Forgot Password')]");
	private static final By emailAddrOrOptumIdTxt = By.id("userNameText_input");
	
	public ForgotPasswordPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ForgotPasswordPageHeader", forgotPasswordPageHeader);
	}
	
	private void enterEmailAddrOrOptumId(String emailOrOptumId) throws Exception {
		enterText("EmailAddrOrOptumIdTxt" , emailAddrOrOptumIdTxt, emailOrOptumId);
	}

	private void clickOnNextButton() throws Exception {
		clickOnElement("NextButton", nextButton);
	}

	public void pageLoadAndEnterEmailOrOptumId(String emailOrOptumId) throws Exception{
		waitForPageLoaded();
		enterEmailAddrOrOptumId(emailOrOptumId);
		clickOnNextButton();
	}
	
		
}
