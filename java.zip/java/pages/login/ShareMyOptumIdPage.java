package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class ShareMyOptumIdPage extends CommonPage implements CommonPageOR {
	
	private static final By shareMyOptumIdAgreeBtn= By.xpath("//a[@id='declineLink']/../input[@id='agreeButton']");
	
	public ShareMyOptumIdPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void clickOnShareMyOptumIdAgreeBtn() throws Exception {
		clickOnElementThenWait("ShareMyOptumIdAgreeBtn" , shareMyOptumIdAgreeBtn, 5);
	}
	
	public void optionalClickOnShareMyOptumIdAgreeBtn() throws Exception {
		optionalClickOnElement("ShareMyOptumIdAgreeBtn" , shareMyOptumIdAgreeBtn);
	}
	
	
		
}
