package pages.login;

import appdata.common.OptumIdData;
import enums.BrowserName;
import enums.PortalName;

import pages.common.CommonPage;
import pages.login.HomePage;
import pages.login.ShareMyOptumIdPage;
import pages.login.SignInWithYourOptumIdPage;
import pages.login.UnrecognizedDevicePage;

import stepdefs.support.Hook;
import stepdefs.support.SuperStepDef;

/**
 * 
 * @author Paul Pinho
 *
 */

public class Portal extends SuperStepDef {
	
	public Portal(Hook hook) {
		super(hook);
	}
	
	public void goToPortal(String browserToUse, String url, String portal, OptumIdData optumIdData) throws Exception {
		CommonPage webPage = new CommonPage(driver, testCaseId);		
		webPage.goTo(url);

		HomePage homePages = new HomePage(driver, testCaseId);
		homePages.clickOnSignInBtn();
		
		if(!browserToUse.equalsIgnoreCase(BrowserName.SAUCE_LAB_FF.val) && portal.equalsIgnoreCase(PortalName.INDIVIDUAL.code)){
			SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver,	testCaseId);
			
			storeTempTestData("IndPortal_EmailId", optumIdData.emailAddress); //newly Created
			storeTempTestData("IndPortal_UserId", optumIdData.optumId); //newly Created
			
			signInWithYourOptumIdPage.createOptumIdUsingIndividualPortal(optumIdData);
		}else{			
			SignInWithYourOptumIdPage signInWithYourOptumIdPage = new SignInWithYourOptumIdPage(driver, testCaseId);
			signInWithYourOptumIdPage.completeOptumIdSignIn(portal, optumIdData);
			
			boolean errorPage = signInWithYourOptumIdPage.unabletoDisplayError();
			
			if(errorPage){
				signInWithYourOptumIdPage.returnToSignInPage();
				signInWithYourOptumIdPage.completeOptumIdSignIn(portal, optumIdData);
			}
			
			UnrecognizedDevicePage unrecognizedDevicePage = new UnrecognizedDevicePage(driver, testCaseId);
			unrecognizedDevicePage.handleSecurityQuestionIfPresent(optumIdData);
			
			ShareMyOptumIdPage shareMyOptumIdPage = new ShareMyOptumIdPage(driver, testCaseId);
			shareMyOptumIdPage.optionalClickOnShareMyOptumIdAgreeBtn();
		}				
		homePages.refreshPageToRemoveReaderViewIssueInSauceLab(browserToUse);
	}

}
