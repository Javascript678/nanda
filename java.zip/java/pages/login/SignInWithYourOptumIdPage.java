package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.common.OptumIdData;

import pages.common.CommonPage;
import pages.common.CommonPageOR;
import utils.PageHeader;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class SignInWithYourOptumIdPage extends CommonPage implements CommonPageOR {
	
	private static final By signInOptumIdHeader = By.id("signInOptumID");	
	private static final By userNameTxtField = By.id("userNameId_input");
	private static final By passwordTextField = By.id("passwdId_input");
	private static final By signInButton = By.id("SignIn");	
	private static final By forgotCredentialsLink = By.id("forgotCredentials");
	private static final By forgotPwdLink = By.id("forgotPwd");	
	private static final By createOptumIdLink= By.id("createOptumID");
	private static final By manageYourOptumIdLink= By.id("manageYourOptumId");
	private static final By whatIsOptumIdLink= By.id("whatIsOptumId");
	
	public SignInWithYourOptumIdPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocatedThenWait("SignInOptumIdHeader", signInOptumIdHeader, 3);
	}
	
	private void enterUserName(String userName) throws Exception {
		enterText("UserNameTxtField" , userNameTxtField, userName);
	}
	
	private void enterPassword(String password) throws Exception {
		enterText("PasswordTextField", passwordTextField, password);
	}
	
	private void clickOnSignInButton() throws Exception {
		clickOnElement("SignInButton", signInButton);
	}
	
	private void clickOnForgotCredentialsLink() throws Exception {
		clickOnElement("ForgotCredentialsLink", forgotCredentialsLink);
	}
	
	private void clickOnForgotPwdLink() throws Exception {
		clickOnElement("ForgotPwdLink", forgotPwdLink);
	}
	
	private void clickOnCreateOptumIdLink() throws Exception {
		clickOnElement("CreateOptumIdLink", createOptumIdLink);
	}
	
	private void clickOnManageYourOptumIdLink() throws Exception {
		clickOnElement("ManageYourOptumIdLink", manageYourOptumIdLink);
	}
	
	private void clickOnWhatIsOptumIdLink() throws Exception {
		clickOnElement("WhatIsOptumIdLink", whatIsOptumIdLink);
	}

	public void completeOptumIdSignIn(String portal, OptumIdData optumIdData) throws Exception {
		enterUserName(optumIdData.optumId);
		enterPassword(optumIdData.password);
		clickOnSignInButton();
	}
	
	public void createOptumIdUsingIndividualPortal(OptumIdData optumIdData) throws Exception {
		clickOnCreateOptumIdLink();
		CreateOptumIdPage createOptumIdPage = new CreateOptumIdPage(driver, testCaseId);
		createOptumIdPage.createOptumId(optumIdData);
	}
	
	public void pageLoadAndClickOnForgotCredendialLink() throws Exception {
		waitForPageLoaded();
		clickOnForgotCredentialsLink();
	}
	
	public void pageLoadAndClickOnForgotPasswordLink() throws Exception {
		waitForPageLoaded();
		clickOnForgotPwdLink();
	}
	
	public void pageLoadAndClickOnCreateOptumIdLink() throws Exception {
		waitForPageLoaded();
		clickOnCreateOptumIdLink();
	}
	
	public void pageLoadAndClickOnManageYourOptumIdLink() throws Exception {
		waitForPageLoaded();
		clickOnManageYourOptumIdLink();
	}
	
	public void pageLoadAndClickOnWhatIsOptumIdLink() throws Exception {
		waitForPageLoaded();
		clickOnWhatIsOptumIdLink();
	}
	
	//by ritu
	public void returnToSignInPage() throws Exception {
		By signInbutton = By.cssSelector("input#returnToSignInButton.returnToSignInButton");
		clickOnElementByActionClass("ClickOnReturnSignIN", signInbutton);
	}
	
	//Ritu
	public boolean unabletoDisplayError() throws Exception {
		Boolean errorPage = null;
		By errorText = By.xpath("//div[@id='whatHappendOnErrorHeaderDiv']//span[@class='whatHappendOnErrorHeader']");
		
		if(isElementPresent(errorText)){
			errorPage = true;
		}else{
			errorPage = false;
		}
		return errorPage;
	}
	
}
