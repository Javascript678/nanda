package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class PreviewPlansPage extends CommonPage implements CommonPageOR{

	private static final By previewPlanPageHeader = By.xpath("//div[@role='heading' and contains(text(),'Preview Plans')]");

	public PreviewPlansPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("PreviewPlanPageHeader", previewPlanPageHeader);
	}
	
	private void enterZipCode(String zipCode) throws Exception{
		By zipCodeTxt = By.id("zip_id");
		clearAndTypeAfterWait("ZipCodeTxt", zipCodeTxt, zipCode);
	}
	
	private void enterDOB(String dob) throws Exception{
		By dobTxt = By.id("a0_dobNoDay");
		clearAndTypeAfterWait("DOBTxt", dobTxt, dob);
	}
	
	private void clickOnMedicalChkBx() throws Exception{
		By medicalChkBx = By.id("sct_MEDICAL");
		clickOnElement("MedicalChkBx", medicalChkBx);
	}
	
	private void clickOnDentalChkBx() throws Exception{
		By dentalChkBx = By.id("sct_DENTAL");
		clickOnElement("DentalChkBx", dentalChkBx);
	}
	
	private void clickOnSubmitBtn() throws Exception{
		By submitBtn = By.id("anonymousSubmit");
		clickOnElement("SubmitBtn", submitBtn);
	}
	
	public void enterPreviewPlanDetails(String zipCode, String dob) throws Exception{
		waitForPageLoaded();
		enterZipCode(zipCode);
		enterDOB(dob);
		clickOnMedicalChkBx();
		clickOnDentalChkBx();
		takeScreenshot("Summary");
		clickOnSubmitBtn();
	}
	
	public void enterPreviewPlan(String zipCode, String dob,String plan) throws Exception{
		waitForPageLoaded();
		enterZipCode(zipCode);
		enterDOB(dob);
		if(plan.equalsIgnoreCase("HEALTH"))
		{		
			clickOnMedicalChkBx();
		}else
		{
		clickOnDentalChkBx();
		}
		takeScreenshot("PreviewDetails");
		clickOnSubmitBtn();
	}
}
