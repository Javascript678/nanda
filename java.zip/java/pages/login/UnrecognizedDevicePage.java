package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.common.OptumIdData;
import pages.common.CommonPage;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class UnrecognizedDevicePage extends CommonPage {
	
	private static final By secQuesLabel = By.id("challengeQuestionLabelId");
	//private static final By optumId_SecQueAnswerTxt = By.xpath("//input[contains(@id,'challengeQuestionList')]");
	private static final By optumId_SecQueAnswerTxt = By.xpath("//input[contains(@id,'UnrecognizedSecAns_input')]");
	private static final By optumId_SecQueSubmitBtn = By.id("authQuesSubmitButton");
	
	public UnrecognizedDevicePage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private boolean isSecurityQuestionPresent() throws Exception {
		return isElementPresent(secQuesLabel,50);
	}
	
	private void enterSecurityAnswer(String secAns) throws Exception {
		enterText("OptumId_SecQueAnswerTxt" , optumId_SecQueAnswerTxt, secAns);
	}
	
	private void clickOnSecQueSubmitButton() throws Exception {
		clickOnElement("OptumId_SecQueSubmitBtn" , optumId_SecQueSubmitBtn);
	}
	
	private void answerSecurityQuestion(String secAnsPhone, String secAnsFriend, String secAnsColor,String secAnsPet,String secAnsCountry, String secAnsSports) throws Exception {
		String secQueswerLabel = getElementText("SecQuesLabel", secQuesLabel).toLowerCase();
		
		if(secQueswerLabel.contains("phone")){
			enterSecurityAnswer(secAnsPhone);
		}else if(secQueswerLabel.contains("friend")){
			enterSecurityAnswer(secAnsFriend);
		}else if(secQueswerLabel.contains("color")){
			enterSecurityAnswer(secAnsColor);
		}else if(secQueswerLabel.contains("pet")){
			enterSecurityAnswer(secAnsPet);
		}else if(secQueswerLabel.contains("country")){
			enterSecurityAnswer(secAnsCountry);
		}else if(secQueswerLabel.contains("sports")){
			enterSecurityAnswer(secAnsSports);
		}
		clickOnSecQueSubmitButton();
	}
	
	public void handleSecurityQuestionIfPresent(OptumIdData optumIdData) throws Exception{
		String secAnsPhone = optumIdData.sequrityQuePhoneNoAnswer;
		String secAnsFriend = optumIdData.sequrityQueFriendAnswer;
		String secAnsColor = optumIdData.sequrityQueColorAnswer;
		String secAnsPet = optumIdData.sequrityQuePetAnswer;
		String secAnsCountry = optumIdData.sequrityQueCountryAnswer;
		String secAnsSports = optumIdData.sequrityQueSportsAnswer;
		if(isSecurityQuestionPresent()){
			answerSecurityQuestion(secAnsPhone, secAnsFriend, secAnsColor,secAnsPet,secAnsCountry, secAnsSports);
		}
	}
	
}
