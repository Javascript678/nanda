package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class ManageYrOptumIdPage extends CommonPage implements CommonPageOR {
	
	private SignInInfo signInInfo = new SignInInfo();
	
	private static final By mngYrOptumIdPageHeader= By.xpath("//h1[text()='Manage Your Optum ID']");
	
	private static final By updateProfileTab = By.xpath("//span[contains(text(),'Update Profile')]");
	private static final By signInInfoTab = By.xpath("//span[contains(text(),'Sign In Information')]");
	private static final By mngVerificationOptionTab = By.xpath("//span[contains(text(),'Manage Verification Options')]");

	public ManageYrOptumIdPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("MngYrOptumIdPageHeader", mngYrOptumIdPageHeader);
	}
	
	private void clickOnUpdateProfileTab() throws Exception{
		clickOnElement("UpdateProfileTab", updateProfileTab);
	}
	
	private void clickOnSignInInfoTab() throws Exception{
		clickOnElementThenWait("SignInInfoTab", signInInfoTab,10);
	}
	
	private void clickOnMngVerificationOptionTab() throws Exception{
		clickOnElement("MngVerificationOptionTab", mngVerificationOptionTab);
	}
	
	private class SignInInfo{
		
		final By currentPasswordTxt = By.id("currentPwdId_input");
		final By newPasswordTxt = By.id("passwordId_input");
		final By confirmPasswordTxt = By.id("confirmPwdId_input");
		
		private void enterCurrentPassword(String password) throws Exception{
			clearAndType("CurrentPasswordTxt", currentPasswordTxt, password);
		}
		
		private void validateCurrentPasswordIsMasked() throws Exception {
			validateElementAttribute("CurrentPasswordTxt" , currentPasswordTxt, "type", "password");
		}
		
		private void enterNewPassword(String password) throws Exception{
			clearAndType("NewPasswordTxt", newPasswordTxt, password);
		}
		
		private void validateNewPasswordIsMasked() throws Exception {
			validateElementAttribute("NewPasswordTxt" , newPasswordTxt, "type", "password");
		}
		
		private void enterConfirmPassword(String password) throws Exception{
			clearAndType("ConfirmPasswordTxt", confirmPasswordTxt, password);
		}
		
		private void validateConfirmPasswordIsMasked() throws Exception {
			validateElementAttribute("ConfirmPasswordTxt" , confirmPasswordTxt, "type", "password");
		}
		
	}
	
	
	public void enterPasswordOnSignInInfoTabAndVerifyFieldIsMasked() throws Exception{
		waitForPageLoaded();
		clickOnSignInInfoTab();
		signInInfo.enterCurrentPassword("Dummy1@123");
		signInInfo.enterNewPassword("Dummy2@123");
		signInInfo.enterConfirmPassword("Dummy2@123");
		signInInfo.validateCurrentPasswordIsMasked();
		signInInfo.validateNewPasswordIsMasked();
		signInInfo.validateConfirmPasswordIsMasked();
		takeScreenshot("PassworMasking");
	}
	
		
}
