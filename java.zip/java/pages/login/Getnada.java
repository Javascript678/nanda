package pages.login;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.Certificate;
import java.util.ArrayList;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 
 * @author Paul Pinho
 *
 */

public class Getnada extends CommonPage {
	
	String activationURL;
	
  	public Getnada(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

    private void getMessage(String email) {
    	// Store url for Getnada Inbox API
        String https_url = "https://getnada.com/api/v1/inboxes/" + email;
        URL url;

        try {
        	// Setup SSL Handshake
            setupProperties();

            url = new URL(https_url);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();           

            // Configure SSL
            SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            con.setSSLSocketFactory(sslsocketfactory);

            // Get input stream
            InputStream in = new BufferedInputStream(con.getInputStream());

            // Store result
            String result = IOUtils.toString(in, "UTF-8");

            JSONObject myResponse = new JSONObject(result);
            
            // Check if message was received then open first message
            if(myResponse.getString("msgs").equals("[]")) {
            	getMessage(email);
            } else {            
	            JSONArray msgs = new JSONArray(myResponse.getString("msgs"));
	            JSONObject msg = msgs.getJSONObject(0);
	            
	            // Get ID of first message and open it
	            String uid = msg.getString("uid");
	            openMessage(uid);
            }
            
            in.close();
            con.disconnect();
            
        } catch (Exception e) {
        	System.out.println(e);
        }
    }
    
    public void openMessage(String uid) {
    	// Store url for Getnada Message API
        String https_url = "https://getnada.com/api/v1/messages/" + uid;
        URL url;

        try {
        	// Setup SSL Handshake
            setupProperties();

            url = new URL(https_url);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();           

            // Configure SSL
            SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            con.setSSLSocketFactory(sslsocketfactory);

            // Get input stream
            InputStream in = new BufferedInputStream(con.getInputStream());

            // Store result
            String result = IOUtils.toString(in, "UTF-8");
            
            JSONObject myResponse = new JSONObject(result);
            String html = myResponse.getString("html");
            
            // Scrape message for activation link
            scrapeMessage(html);          
            
            in.close();
            con.disconnect();
            
        } catch (Exception e) {
        	System.out.println(e);
        }
    }
    
    public void scrapeMessage(String html) throws IOException {
        Document document;
        
        //Get Document object after parsing the html from given url
		document = Jsoup.parse(html);
    
		//Get links from document object
		Elements links = document.select("a[href]");
    
		//Iterate links and retrieve activation url
		for (Element link : links) {			
			// Optum ID 1.0
			//if(link.text().equals("Activate my Optum ID")) {
				
			// Optum ID 2.0
			if(link.text().equals("Activate my MA Login")) {
				
				activationURL = link.attr("href");
			}
		}		
	}
  
    public void activateOptumID(String email) {
    	// Use Getnada API's to activate Optum ID
    	getMessage(email);
    	
    	// Save parent window
    	String parentWindow = driver.getWindowHandle();
    	
    	try {			
			((JavascriptExecutor) driver).executeScript("window.open()");
			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			
			// Open new tab and save current window
			driver.switchTo().window(tabs.get(1));
			String currentWindow = driver.getWindowHandle();
			
			// Open activation url in current window
			driver.get(this.activationURL);
			
			// Close parent window and continue with application
			driver.switchTo().window(parentWindow);
			driver.close();
			driver.switchTo().window(currentWindow);
			
		} catch (Exception e) {
			driver.close();
			driver.switchTo().window(parentWindow);
	        System.out.println(e);
		}
    }
    
    @SuppressWarnings("hiding")
	public void print_https_cert(HttpsURLConnection con) {
        if (con != null) {
            try {
                System.out.println("\n");

                Certificate[] certs = con.getServerCertificates();
                
                for (Certificate cert : certs) {
                    System.out.println("Cert Type : " + cert.getType());
                    System.out.println("Cert Hash Code : " + cert.hashCode());
                    System.out.println("Cert Public Key Algorithm : "
                            + cert.getPublicKey().getAlgorithm());
                    System.out.println("Cert Public Key Format : "
                            + cert.getPublicKey().getFormat());
                    System.out.println("\n");
                }

            } catch (SSLPeerUnverifiedException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void setupProperties() {
        System.setProperty("javax.net.ssl.trustStoreType", "jks");
        System.setProperty("javax.net.ssl.trustStore", "src" + File.separator + "test" + File.separator + "resources" + File.separator + "devopsTrustStore");
        System.setProperty("javax.net.debug", "ssl");
        System.setProperty("javax.net.ssl.trustStorePassword", "abc123");
    }

}
