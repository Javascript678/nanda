package pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class ResetPasswordVerifyYrIdPage extends CommonPage implements CommonPageOR {
	
	private static final By resetPasswordVerifyYrIdPageHeader= By.id("span_headerId_forgotUserPassword");
	
	private static final By sendEmailRdBtn = By.id("sendEmail");
	private static final By securityAnswerRdBtn = By.id("answerSecurity");
	
	public ResetPasswordVerifyYrIdPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ResetPswdVerifyYrIdPageHeader", resetPasswordVerifyYrIdPageHeader);
	}
	
	private void clickOnSendEmailRdBtn() throws Exception {
		clickOnElement("SendEmailRdBtn" , sendEmailRdBtn);
	}
	
	private void clickOnSecurityAnswerRdBtn() throws Exception {
		clickOnElement("SecurityAnswerRdBtn" , securityAnswerRdBtn);
	}

	private void clickOnNextButton() throws Exception {
		clickOnElement("NextButton", nextButton);
	}

	public void pageLoadAndClickOnSendEmailRdBtn() throws Exception{
		waitForPageLoaded();
		clickOnSendEmailRdBtn();
		clickOnNextButton();
	}
	
	public void pageLoadAndClickOnSecurityAnswerRdBtn() throws Exception{
		waitForPageLoaded();
		clickOnSecurityAnswerRdBtn();
		clickOnNextButton();
	}
	
		
}
