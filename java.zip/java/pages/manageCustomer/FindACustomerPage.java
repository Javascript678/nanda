package pages.manageCustomer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class FindACustomerPage extends CommonPage {
	
	private static final By findACustomerPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Find a Customer')]");
		
	private SearchField searchField = new SearchField();
	private CustomerTable customerTable = new CustomerTable();
	
	public FindACustomerPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("FindACustomerPageHeader", findACustomerPageHeader);
	}
	
	private class SearchField{
		private final By externalRefIdTxt	= By.id("cohbeId");
		private final By emailIdTxt	= By.id("email");
		private final By userNameTxt	= By.id("userName");
		private final By fNameTxt	= By.id("firstName");
		private final By lNameTxt	= By.id("lastName");
		private final By ssnTxt	= By.id("userProfile.ssn");
		private final By dobTxt	= By.id("dob");
		private final By searchCustomerBtn = By.id("searchCustomer");
		
		private void enterExternalId(String externalId) throws Exception{
			enterText("ExternalRefIdTxt",externalRefIdTxt, externalId);
		}
		
		private void enterEmailId(String emailId) throws Exception{
			enterText("EmailIdTxt",emailIdTxt, emailId);
		}
		
		private void enterUserName(String userName) throws Exception{
			enterText("UserNameTxt",userNameTxt, userName);
		}
		
		private void enterFirstName(String fName) throws Exception{
			enterText("FirstNameTxt",fNameTxt, fName);
		}
		
		private void enterLastName(String lName) throws Exception{
			enterText("LastNameTxt",lNameTxt, lName);
		}
		
		private void enterSSN(String ssn) throws Exception{
			enterText("SSNTxt",ssnTxt, ssn);
		}
		
		private void enterDOB(String dob) throws Exception{
			clearAndType("DOBTxt",dobTxt, dob);
		}
		
		private void clickOnSearchCustomerBtn() throws Exception{
			clickOnElementThenWait("SearchCustomerBtn",searchCustomerBtn, 5);
		}
	}
	
	// updated by ppinho
	private class CustomerTable{
		By accountDashBoardBtn	= By.xpath("//a[contains(.,'Account Dashboard')]");
		By premiumAssistanceDashBoardBtn	= By.xpath("//a[contains(text(),'Premium Assistance Dashboard')]");
		
		private void clickOnAccountDashboardBtn() throws Exception{
			clickOnElement("AccountDashBoardBtn",accountDashBoardBtn);
		}
		
		private void clickOnPremiumAssistanceDashBoardBtn() throws Exception{
			clickOnElement("PremiumAssistanceDashBoardBtn",premiumAssistanceDashBoardBtn);
		}
	}
	
	public void findAcustomerUsingUserProfileRefIdAndGoToAccountDashBoard(String refId) throws Exception{
		waitForPageLoaded();
		searchField.enterExternalId(refId);
		searchField.clickOnSearchCustomerBtn();
		customerTable.clickOnAccountDashboardBtn();
	}
	
	public void findAcustomerUsingUserProfileRefIdAndGoToPremiumAssistanceDashBoard(String refId) throws Exception{
		waitForPageLoaded();
		searchField.enterExternalId(refId);
		searchField.clickOnSearchCustomerBtn();
		customerTable.clickOnPremiumAssistanceDashBoardBtn();
	}
	
	/*
	 * Ritu
	 * 
	 */
	public void findAcustomerUsingEmailIdAndDOBAndGoToAccountDashBoard(String emailId,String dob) throws Exception{
		waitForPageLoaded();
		searchField.enterEmailId(emailId);
		searchField.enterDOB(dob);
		searchField.clickOnSearchCustomerBtn();
		customerTable.clickOnAccountDashboardBtn();
	}
	
}
