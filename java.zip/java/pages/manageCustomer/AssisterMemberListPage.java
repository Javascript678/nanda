package pages.manageCustomer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class AssisterMemberListPage extends CommonPage implements CommonPageOR {

	private static final By assisterMemberListPageHeader = By.xpath("//h1[contains(.,'Member List')]");

	public AssisterMemberListPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("AssisterMemberListPageHeader", assisterMemberListPageHeader);
	}
	
	public void enterRefId(String userProfileRefId) throws Exception{
		By refIdTxt =   By.id("refId");
		clearAndType("RefIdTxt", refIdTxt,  userProfileRefId);
	}
	
	public void clickOnSearchBtn() throws Exception{
		By searchCustomerBtn =   By.id("searchCustomer");
		clickOnElementThenWait("SearchCustomerBtn", searchCustomerBtn,20);
	}

	public void clickOnConfirmPopUp() throws Exception{
		clickOnElementThenWait("PopupConfirmBtn", popupConfirmBtn,10);
	}
	
	public void clickOnAgreePopUp() throws Exception{
		clickOnElementThenWait("PopupAgreeBtn", popupAgreeBtn,10);
	}
	
	//Amrita
	public void clickOnConfirmYesPopUp() throws Exception{
		clickOnElementThenWait("PopupConfirmYesBtn", popupYesBtn,10);
	}
	
	public int getAllMemberCount() throws Exception{
		By customerTableInfoLink =   By.id("customerTable_info");
		String memCount = getElementText(customerTableInfoLink);
		return Integer.parseInt(memCount.split("of")[1].trim());
	}
	
	public int getMemberCountTillCurrentTable() throws Exception{
		By customerTableInfoLink =   By.id("customerTable_info");
		String memCount = getElementText(customerTableInfoLink);
		return Integer.parseInt(memCount.split("to")[1].split("of")[0].trim());
	}
	
	public void clickOnCustomerTablePrevLink() throws Exception{
		By customerTablePrevLink =   By.id("customerTable_previous");
		clickOnElement("CustomerTablePrevLink", customerTablePrevLink);
	}
	
	public void clickOnCustomerTableNextLink() throws Exception{
		By customerTableNextLink =   By.id("customerTable_next");
		clickOnElement("CustomerTableNextLink", customerTableNextLink);
	}
	
	public Boolean isViewProfileUsingUserProfileRefIdLinkPresent(String userProfileRefId) throws Exception{
		By viewProfileLink = By.xpath("//table[caption[text()='Member Details']]//tr[th[contains(.,'"+userProfileRefId+"')]]//a[contains(.,'View Profile')]");
		return isElementPresent(viewProfileLink);
	}
	
	public void clickOnViewProfileUsingUserProfileRefId(String userProfileRefId) throws Exception{
		By viewProfileLink = By.xpath("//table[caption[text()='Member Details']]//tr[th[contains(.,'"+userProfileRefId+"')]]//a[contains(.,'View Profile')]");
		clickOnElement("ViewProfileLink", viewProfileLink);
	}
	
	public void clickOnViewProfileForFirstSearchResult() throws Exception{
		By viewProfileLink = By.xpath("//a[contains(.,'View Profile')]");
		clickOnElement("ViewProfileLink", viewProfileLink);
	}
	
	//Amrita
	public void clickOnViewEligibilityForFirstSearchResult() throws Exception{
		By viewEligibilityLink = By.xpath("//a[contains(.,'View Eligibility')]");
		clickOnElement("ViewEligibilityLink", viewEligibilityLink);
	}
	
//Amrita
		public void clickOnViewProfileForMember(int memindex) throws Exception{
			By viewProfileLink = By.xpath("//div[@class='idProofIndShowDashboardButtons']//a[@aria-describedby[contains(.,'_"+memindex+"')]and contains(.,'View Profile')]");
			clickOnElement("ViewProfileLink", viewProfileLink);
		}
		
//Amrita
		public void clickOnViewEligibilityForMember(int memindex) throws Exception{
			By viewEligibilityLink = By.xpath("//div[@class='idProofIndShowDashboardButtons']//a[@aria-describedby[contains(.,'_"+memindex+"')]and contains(.,'View Eligibility')]");
			clickOnElement("ViewEligibilityLink", viewEligibilityLink);
		}
	
//Amrita
	public void clickOnRemoveAccessForMember(int memindex) throws Exception{
		By removeAccessLink = By.xpath("//div[@class='idProofIndShowDashboardButtons']//a[@aria-describedby[contains(.,'_"+memindex+"')]and contains(.,'Remove Access')]");
		clickOnElement("RemoveAccessLink", removeAccessLink);
	}
	
//Amrita
	public void clickOnViewDesignationFormForMember(int memindex) throws Exception{
			By viewDesignationFormLink = By.xpath("//div[@class='idProofIndShowDashboardButtons']//a[@aria-describedby[contains(.,'_"+memindex+"')]and contains(.,'View Designation Form')]");
			
		clickOnElement("View Designation Form", viewDesignationFormLink);
	}
	
	public void searchUsingRefIdAndClickOnViewProfile(String userProfileRefId) throws Exception{
		waitForPageLoaded();
		enterRefId(userProfileRefId);
		clickOnSearchBtn();
		//clickOnViewProfileUsingUserProfileRefId(userProfileRefId);
		clickOnViewProfileForFirstSearchResult();
	}
	
	//Amrita
	public void searchUsingRefIdAndClickOnViewEligibility(String userProfileRefId) throws Exception{
		waitForPageLoaded();
		enterRefId(userProfileRefId);
		clickOnSearchBtn();
		clickOnViewEligibilityForFirstSearchResult();
	}
	
	public void clickOnViewProfileUsingUserProfileRefIdAcrossAllTable(String userProfileRefId) throws Exception{
		Boolean viewProfileUsingUserProfileRefIdLinkFound=false;
		int allMemCount = getAllMemberCount();
		int memCountTillCurrentTable = getMemberCountTillCurrentTable();
		do{
			if(isViewProfileUsingUserProfileRefIdLinkPresent(userProfileRefId)){
				clickOnViewProfileUsingUserProfileRefId(userProfileRefId);
				viewProfileUsingUserProfileRefIdLinkFound=true;
				break;
			}else{
				clickOnCustomerTableNextLink();
			}
			
		}while(memCountTillCurrentTable!=allMemCount);
		
		if(viewProfileUsingUserProfileRefIdLinkFound==false){
			throw new Exception("ViewProfileUsingUserProfileRefIdLink Not Found For UerPRofile RefId [" + userProfileRefId + "]");
		}
	}
	
	public void takeScreenshot() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Member List Page");
	}

	
}
