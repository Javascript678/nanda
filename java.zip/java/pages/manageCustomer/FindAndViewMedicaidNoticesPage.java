package pages.manageCustomer;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import stepdefs.support.Hook;
//import utils.FileDownload;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class FindAndViewMedicaidNoticesPage extends CommonPage {
	
	SearchField searchField = new SearchField();
	Table table = new Table();
	
	private static final By findAndViewMedicaidNoticesPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Find and View Medicaid Notices')]");
	
	public FindAndViewMedicaidNoticesPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("FindAndViewMedicaidNoticesPgHdr", findAndViewMedicaidNoticesPageHeader);
	}
	
	private class SearchField{
		By eligibilityIdText	= By.id("eligibilityId");
		By dobtext	= By.id("dob");
		By firstNameText	= By.id("firstName");
		By lastNameText	= By.id("lastName");
		By ssnText	= By.id("elgMemberSsn");
		By searchButton	= By.id("searchMedicaidNotices");
		
		private void enterEligibilityId(String eligibilityId) throws Exception{
			clearAndType("EligibilityIdText", eligibilityIdText , eligibilityId);
		}
		
		private void enterDOB(String dob) throws Exception{
			clearAndType("DOBtext", dobtext, dob);
		}
		
		private void enterFirstName(String firstName) throws Exception{
			clearAndType("FirstNameText", firstNameText, firstName);
		}
		
		private void enterLastName(String lastName) throws Exception{
			clearAndType("LastNameText", lastNameText, lastName);
		}
		
		private void enterSSN(String ssn) throws Exception{
			clearAndType("SSNText", ssnText, ssn);
		}
		
		private void clickOnSearchButton() throws Exception{
			clickOnElementThenWait("SearchButton", searchButton, 10);
		}
	}
	
	private class Table{
		
		String table = "//table[@id='medicaidNoticeTable']";
		By tableHeader = By.xpath(table + "/thead//th");
		
		private boolean isPdfPresent(String name, String noticeType) throws Exception{
			
			By pdfLink = By.xpath(table + "/tbody/tr[ th[contains(text(),'" + name + "')] and td[contains(text(),'" + noticeType + "')] ]/td[@class='lastCol']//button[span[contains(text(),'View Medicaid Notice PDF')]]");
			return isElementPresent(pdfLink,10);
		}
		
		private String getPdfURL(String name, String noticeType) throws Exception{
			By pdfLink = By.xpath(table + "/tbody/tr[ th[contains(text(),'" + name + "')] and td[contains(text(),'" + noticeType + "')] ]/td[@class='lastCol']//button[span[contains(text(),'View Medicaid Notice PDF')]]");
			String url = getCurrentURL();
			
			String onclickAttr  = getElementAttribute(pdfLink, "onclick");
			String urlAppender = onclickAttr.substring(56,63);
			return url + "/pdf/" + urlAppender + ".pdf";
		}
		
		private void clickOnPdfLink(String name, String noticeType) throws Exception{
			By pdfLink = By.xpath(table + "/tbody/tr[ th[contains(text(),'" + name + "')] and td[contains(text(),'" + noticeType + "')] ]/td[@class='lastCol']//button[span[contains(text(),'View Medicaid Notice PDF')]]");
			clickOnElement("PDFLink", pdfLink);
		}
		
		
		
	}
	
	public void enterSearchDetailsAndClickOnSearchButton(String eligibilityId, String dob, String firstName, String lastName) throws Exception{
		waitForPageLoaded();
		searchField.enterEligibilityId(eligibilityId);
		searchField.enterDOB(dob);
		searchField.enterFirstName(firstName);
		searchField.enterLastName(lastName);
		searchField.clickOnSearchButton();
	}
	
	
	public void downloadNotices(String eligibilityId, String firstName, String lastName, String noticeType) throws Exception{
		String pdfFolder = Hook.testReportFolder + File.separator + testCaseId + File.separator + "PDF";
		File fPdfFolder = new File(pdfFolder);
		if(! fPdfFolder.exists()){
			fPdfFolder.mkdir();
		}
		File tempFileDownloadDir = new File(Hook.testReportFolder + File.separator + testCaseId + File.separator + "FileDownload");
    	if(tempFileDownloadDir.exists()){
			FileUtils.deleteDirectory(tempFileDownloadDir);
		}
    	tempFileDownloadDir.mkdir();
    	
		String fullName = lastName + ", " + firstName;
		
		if(fullName.length() > 17){
			fullName = fullName.substring(0, 16);
		}
		
		if(! table.isPdfPresent(fullName, noticeType) ){
			throw new Exception("Notices for Member Name[" + fullName +"] and Notie Type [" +noticeType + "] not found on UI");
		}
		
		
		String fileUrl = table.getPdfURL(fullName, noticeType);
		String destFileName = eligibilityId + "_"  + firstName+ "_" + lastName + "_" + noticeType + ".pdf";
		
		//It will help run code from Sauce Lab
		//FileDownload.saveFileFromUrlWithCommonsIO(pdfFolder + File.separator + destFileName, fileUrl);
		
		table.clickOnPdfLink(fullName, noticeType);
		
		Thread.sleep(10000);
		
		if(tempFileDownloadDir.list().length==0){
			new RuntimeException("Notices PDF for Member Name[" + fullName +"] and Notie Type [" +noticeType + "] was not downloaded from  UI");
		}
		File srcFileNameWithPath =new File(tempFileDownloadDir + File.separator + tempFileDownloadDir.list()[0]);
		destFileName = eligibilityId + "_"  + firstName+ "_" + lastName + "_" + noticeType + ".pdf";
		File destFileNameWithPath = new File(pdfFolder + File.separator + destFileName);
		
		Files.copy(srcFileNameWithPath.toPath(), 
				destFileNameWithPath.toPath(), 
				StandardCopyOption.REPLACE_EXISTING);
	}


}
