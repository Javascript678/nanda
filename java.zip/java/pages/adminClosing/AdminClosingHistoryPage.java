package pages.adminClosing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * @author :- Amrita Kumari
 * Page Description :- Admin Closing History Page Behavior
 *
 */

public class AdminClosingHistoryPage extends CommonPage implements CommonPageOR {

	private static final By adminClosingHistoryPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Administrative Closing History')]");
	
	public AdminClosingHistoryPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("AdminClosingHistoryPageHeader", adminClosingHistoryPageHeader);
	}

	private void validateClosingHistoryPresent(String name, String changeDate, String startEffectiveDate, String closingReason) throws Exception{
		// //table[@id='customerTable']/tbody/tr[ th[div[contains(text(),'MEMirjhr ONEyjqne')]] and td[1][div[contains(text(),'07-Mar-2018')]] and td[2][div[contains(text(),'07-Mar-2018')]] and td[4][contains(text(),'38 - Voluntary Withdrawal')]]
		By rowDetails = By.xpath("//table[@id='customerTable']/tbody/tr[ th[div[contains(text(),'"+name+"')]] and td[1][div[contains(text(),'"+changeDate+"')]] and td[2][div[contains(text(),'"+startEffectiveDate+"')]] and td[4][contains(text(),'"+closingReason+"')]]");
		validateElementPresent(name+"ClosingHistory", rowDetails);
	}
	
	private void clickOnBackButton() throws Exception{
		clickOnElement("BackButton", backButton);
	}
	
	public void validateClosingHistoryForMember(int memCount, String names[], String changeDates[], String startEffectiveDates[], String closingReasons[]) throws Exception{
		waitForPageLoaded();
		for(int memCounter=0; memCount < memCount; memCounter++){
			//Validate Details Only if Admin Closing reason is provided
			if(! closingReasons[memCounter].equals("")){
				validateClosingHistoryPresent(names[memCounter],changeDates[memCounter], startEffectiveDates[memCounter], closingReasons[memCounter]);
			}
		}
	}
	
}

