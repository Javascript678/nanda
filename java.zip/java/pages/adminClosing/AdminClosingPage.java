package pages.adminClosing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * @author :- Amrita Kumari
 * Page Description :- Admin Closing Page Behavior
 *
 */

public class AdminClosingPage extends CommonPage implements CommonPageOR {

	private static final By adminClosingPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Administrative Closing')]");
	private static final By reRunSuccessMsg = By.xpath("//div[@id='reRunSuccessStatusId']/strong");
	
	public AdminClosingPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("AdminClosingPageHeader", adminClosingPageHeader);
	}

	/**
	 * @author :- Paul Pinho
	 * Accepted Value :- "10 - Receiving benefits in another state" 
	 * 					 "38 - Voluntary Withdrawal"
	 * 
	 * @param memberIndex
	 * @param closureReason
	 * @throws Exception
	 */
	public void selectAdminClosingReason(String fName, String lName, String closureReason) throws Exception {
		By adminClosureReasonDD = By.xpath("//table[@id='customerTable']//*[contains(text(),'" + fName + "') and contains(text(),'" + lName + "')]/following::*[contains(@id,'adminClosureReason')]");
		selectDropDownElementByVisibleText("Member " + fName + " " + lName + " AdminClosureReasonDD", adminClosureReasonDD, closureReason);
	}

	// added by ppinho
	public void enterAdminClosingEffectDate(String fName, String lName, String closureDate) throws Exception {
		By adminClosureEffectiveDateTxt = By.xpath("//table[@id='customerTable']//*[contains(text(),'" + fName + "') and contains(text(),'" + lName + "')]/following::*[contains(@id,'effectiveDate') and @type='text']");
		clearAndType("Member " + fName + " " + lName + " AdminClosingEffectDateTxt", adminClosureEffectiveDateTxt, closureDate);
	}
	
	public void enterAdminClosingRemovalDate(int memNo, String removalDate) throws Exception {
		By adminClosureRemovalDateTxt = By.id("endDate" + (memNo-1));
		clearAndType("Mem" + (memNo)+"AdminClosingRemovalDateTxt", adminClosureRemovalDateTxt, removalDate);
	}

	public void clickOnBackButton() throws Exception{
		clickOnElement("BackButton", backButton);
	}
	
	public void clickOnSaveBtn() throws Exception {
		clickOnElement("SaveBtn", saveBtn);
	}
	
	public void clickOnSaveAndReRunEligibilityBtn() throws Exception {
		clickOnElement("SaveAndRerunEligiilityBtn", saveAndRerunEligiilityBtn);
	}

	public void clickOnOkPopup() throws Exception {
		clickOnElement("PopUpOkBtn", alertOkButton);
	}

	public void VerifySuccessMessage() throws Exception {
		validateTextContains("ReRunEligibilityMessage", reRunSuccessMsg, "Success: Eligibility Re-Run Successful");
	}

	public void taksScreenShot() throws Exception {
		takeScreenshot("Summary");
	}
}
