package pages.familyHouseHold;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class DeathConfirmationPage extends CommonPage implements CommonPageOR{
	
	private static final By deathConfirmationPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Death Confirmation')]");
		
	public DeathConfirmationPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("DeathConfirmationPageHeader", deathConfirmationPageHeader);
	}
	
	public void selectDeceasedStatusForMember(int memIndex, Boolean trueFalseValue,String deathDateValue) throws Exception{
		
		
		By selfAttestedDeathRdBtn = By.name("eligibilityMember["+memIndex+"].socialSecurityCard.selfAttestedDeath");
		By deathDateRdTxt= By.name("eligibilityMember["+memIndex+"].socialSecurityCard.deathDate");
		
		selectByValue("selfAttestedDeathRdBtn", selfAttestedDeathRdBtn, trueFalseValue+"");
		
		if(trueFalseValue){
			clearAndType("Mem" + (memIndex)+"ComfirmDeathDate", deathDateRdTxt, deathDateValue);
		}
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}
	
	public void clickOnWarningPopOkBtn() throws Exception{
		clickOnElement("WarningOkButton" , warningOkButton);
	}
	
	public void taksScreenShot() throws Exception{
		takeScreenshot("Summary");
	}
	
	
	
}
