package pages.familyHouseHold;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import enums.Race;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class MoreAboutThisHHPage extends CommonPage implements CommonPageOR{

	private static final By moreAboutHshldHeader = By.xpath("//h1[contains(.,'More about this household')]");

	public MoreAboutThisHHPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("MoreAboutHshldHeader", moreAboutHshldHeader);
	}

	public void selectIfMemberIsDisbaled(int memIndex, int memCount) throws Exception{
		if(memCount==1){
			By memDisabledRdBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberAdditionalInfo.isDisabled' and @value='true']/../label");
			clickOnElement("Mem" + (memIndex + 1) + "DisabledRdBtn", memDisabledRdBtn);
		}
		else{
			By memDisabledChkBx = By.xpath("//label[@for='isDisabled_"+memIndex+"']");
			clickOnElement("Mem"+(memIndex+1)+"DisabledChkBx", memDisabledChkBx);
		}
	}

	public void selectIfMemberIsAIAN(int memIndex, int memCount) throws Exception{
		if(memCount==1){
			By memAIANRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberAdditionalInfo.isAmericanIndian' and @value='true']/../label");
			clickOnElement("Mem"+(memIndex+1)+"AIANRdBtn", memAIANRdBtn);
		}
		else{
			By memAmericanIndianChkBx = By.xpath("//label[@for='isAmericanIndian_"+memIndex+"']");
			clickOnElement("Mem"+(memIndex+1)+"AmericanIndianChkBx", memAmericanIndianChkBx);
		}
	}

	public void selectAIANStateForMember(int memIndex, String state) throws Exception{
		By memAIANStateDD = By.id("member_state_"+memIndex);
		selectDropDownElementByVisibleText("Mem"+(memIndex+1)+"AIANStateDD", memAIANStateDD, state);
	}

	public void selectAIANTribeForMember(int memIndex, String tribe) throws Exception{
		By memAIANTribeDD = By.id("member_tribe_"+memIndex);
		selectDropDownElementByVisibleText("Mem"+(memIndex+1)+"AIANTribeDD", memAIANTribeDD, tribe);
	}

	public void selectIfMemberIsPregnant(int memIndex, int memCount) throws Exception{
		if(memCount==1){
			By memPregnantRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberAdditionalInfo.isPregnant' and @value='true']/../label");
			clickOnElement("Mem"+(memIndex+1)+"PregnantRdBtn", memPregnantRdBtn);
		}else{
			By memPregnantChkBx = By.xpath("//label[@for='isPregnant_"+memIndex+"']");
			clickOnElement("Mem"+(memIndex+1)+"PregnantChkBx", memPregnantChkBx);
		}

	}

	public void selectPregMemberBabyCount(int memIndex, int babyCount) throws Exception{
		By memBabyCountDD = By.id("eligibilityMember["+memIndex+"].eligibilityMemberAdditionalInfo.numberOfBabies");
		selectDropDownElementByVisibleText("Mem"+(memIndex+1)+"BabyCountDD", memBabyCountDD, babyCount+"");
	}

	public void enterPregMemberBabyDueDate(int memIndex, String babyDueDate) throws Exception{
		By memBabyDueDateTxt = By.id("eligibilityMember["+memIndex+"].eligibilityMemberAdditionalInfo.dueDate");
		clearAndTypeAfterWait("Mem"+(memIndex+1)+"BabyDueDateTxt", memBabyDueDateTxt, babyDueDate);
	}

	//Ritu
	public void enterPregMemberEndDate(int memIndex, String pregEndDate) throws Exception{
		By memPregEndDateTxt = By.name("eligibilityMember["+memIndex+"].eligibilityMemberAdditionalInfo.pregnancyEndDate");
		clearAndTypeAfterWait("Mem"+(memIndex+1)+"MemPregnancyEndDateTxt", memPregEndDateTxt , pregEndDate);
	}

	public void selectNoneOfTheseMemberIsPregnant() throws Exception{
        By nonOfThesePregnantChkBx = By.xpath("//label[@for='isPregnant_noneOfThese']");
        clickOnElement("NONE_OF_THESE_IS_PREGNENT ",nonOfThesePregnantChkBx);
	}

	public void selectIfMemberWasInFosterCare(int memIndex, int membersize) throws Exception{
	//label[@for='eligibilityMember"+memIndex+".eligibilityMemberAdditionalInfo.wasInFosterCare"+(memIndex+1)+"']
		By memFosterCareChkBx;
		if(membersize <= 1){		
			memFosterCareChkBx = By.xpath("//label[@for='eligibilityMember"+memIndex+".eligibilityMemberAdditionalInfo.wasInFosterCare"+(memIndex+1)+"']");
		}
		else{
			memFosterCareChkBx = By.xpath("//label[@for='wasInFosterCare_"+memIndex+"']");
		}
		clickOnElement("Mem" + (memIndex + 1) + "FosterCareChkBx", memFosterCareChkBx);
	}
	//label[@for='eligibilityMember0.eligibilityMemberAdditionalInfo.wasInFosterCare
	//label[@for='wasInFosterCare_0']
	//input[@id='wasInFosterCare_0']

	public void selectFosterCareStateForMember(int memIndex, String state) throws Exception{
		By memFosterCareStateDD = By.xpath("//div[@id='fosterCare_member"+memIndex+"']//select");
		clickOnElement("Clicking on State DD",memFosterCareStateDD);
		selectDropDownElementByVisibleText("Mem"+(memIndex+1)+"FosterCareStateDD", memFosterCareStateDD, state);
	}


	public void selectNoneOfTheseMemberIsBCC() throws Exception{
		By nonOfTheseBCCChkBx = By.id("breastCancer_noneOfThese");
		clickOnElement("NONE OF THESE IS BCC ",nonOfTheseBCCChkBx);
	}


	public void selectYesForFosterCareMemberhasStatePlan(int memIndex) throws Exception{
		By memFosterCareStatePlanYesRdBtn = By.xpath("//label[@for='check_healthcare_program_"+memIndex+"1']");
		clickOnElement("Mem"+(memIndex+1)+"FosterCareStatePlanYesRdBtn", memFosterCareStatePlanYesRdBtn);
	}

	public void selectNoForFosterCareMemberhasStatePlan(int memIndex) throws Exception{
		By memFosterCareStatePlanNoRdBtn = By.xpath("//label[@for='check_healthcare_program_"+memIndex+"2']");
		clickOnElement("Mem"+(memIndex+1)+"FosterCareStatePlanNoRdBtn", memFosterCareStatePlanNoRdBtn);
	}


	public void selectFosterCareAgeLeftForMember(int memIndex, int age) throws Exception{
		By memFosterCareAgeLeftDD = By.id("foster_care_age_"+memIndex);
		clickOnElement("Clicking on Age DD", memFosterCareAgeLeftDD);
		selectDropDownElementByVisibleText("Mem"+(memIndex+1)+"FosterCareAgeLeftDD", memFosterCareAgeLeftDD, age+"");
	}

	public void selectIfMemberIsBreastCancerPatient(int memIndex, int memCount) throws Exception{
		if(memCount==1){
			By memBreastCancerRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberAdditionalInfo.isHavingBreastOrCervicalCancer' and @value='true']/../label");
			clickOnElement("Mem"+(memIndex+1)+"BreastCancerRdBtn", memBreastCancerRdBtn);
		}
		else{
			By memBreastCancerChkBx = By.xpath("//label[@for='breastCancer_"+memIndex+"']");
			clickOnElement("Mem"+(memIndex+1)+"BreastCancerChkBx", memBreastCancerChkBx);
		}
	}

	public void selectIfMemberIsHIVPatient(int memIndex, int memCount) throws Exception{
		if(memCount==1){
			By memHIVPatientRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberAdditionalInfo.isHIVPositive' and @value='true']/../label");
			clickOnElement("Mem"+(memIndex+1)+"HIVPatientRdBtn", memHIVPatientRdBtn);
		}
		else{
			By memHIVChkBx = By.xpath("//label[@for='isHiv_"+memIndex+"']");
			clickOnElement("Mem"+(memIndex+1)+"HIVChkBx", memHIVChkBx);
		}
	}

	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}

	public void takeScreenshot() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Summary");
	}

	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}

	public void completeMoreAboutHHForMembers(boolean faReqd, String whoIsApplying, List<EVPD_MemData> memsData) throws Exception{
		if(faReqd){
			waitForPageLoaded();
			int memCount = memsData.size();

			for(int mCounter=0; mCounter<memCount; mCounter++){
				if(mCounter==0 && whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
				if(memsData.get(mCounter).isDisabled){
					selectIfMemberIsDisbaled(mCounter,memCount);
				}

				if(memsData.get(mCounter).isAIAN){
					if(! memsData.get(mCounter).raceList.contains(Race.AMERICAN_INDIAN_OR_ALASKA_NATIVE.val)){
						selectIfMemberIsAIAN(mCounter,memCount);
					}
					selectAIANStateForMember(mCounter, memsData.get(mCounter).indoAmericanState);
					selectAIANTribeForMember(mCounter, memsData.get(mCounter).indoAmericanTribe);
				}

				if(memsData.get(mCounter).isPregnant){
					selectIfMemberIsPregnant(mCounter,memCount);
					selectPregMemberBabyCount(mCounter, memsData.get(mCounter).prgBabyCount);
					enterPregMemberBabyDueDate(mCounter, memsData.get(mCounter).babyDueDate);
				}

				if(memsData.get(mCounter).fosterCare){
					selectIfMemberWasInFosterCare(mCounter, memCount);
					selectFosterCareStateForMember(mCounter, memsData.get(mCounter).fosterCareState);
					selectYesForFosterCareMemberhasStatePlan(mCounter);
					selectFosterCareAgeLeftForMember(mCounter, memsData.get(mCounter).fosterCareLeftAge);
				}

				if(memsData.get(mCounter).brestCancer){
					selectIfMemberIsBreastCancerPatient(mCounter,memCount);
				}

				if(memsData.get(mCounter).hivPositive){
					selectIfMemberIsHIVPatient(mCounter,memCount);
				}

			}
			clickOnSaveAndContinueBtn();
		}
	}

	// ppinho
	public void evpdCompleteMoreAboutHHForMembers(boolean faReqd, String whoIsApplying, List<EVPD_MemData> memsData) throws Exception {
		if(faReqd){
			int memCount = memsData.size();

			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(mCounter == 0 && whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;

				if(memsData.get(mCounter).isDisabled){
					selectIfMemberIsDisbaled(mCounter, memCount);
				}

				if(memsData.get(mCounter).isAIAN){
					if(!memsData.get(mCounter).raceList.contains(Race.AMERICAN_INDIAN_OR_ALASKA_NATIVE.val)){
						selectIfMemberIsAIAN(mCounter,memCount);
					}
					selectAIANStateForMember(mCounter, memsData.get(mCounter).indoAmericanState);
					selectAIANTribeForMember(mCounter, memsData.get(mCounter).indoAmericanTribe);
				}

				if(memsData.get(mCounter).isPregnant){
					selectIfMemberIsPregnant(mCounter, memCount);
					selectPregMemberBabyCount(mCounter, memsData.get(mCounter).prgBabyCount);
					enterPregMemberBabyDueDate(mCounter, memsData.get(mCounter).babyDueDate);
				}

				if(memsData.get(mCounter).fosterCare){
					selectIfMemberWasInFosterCare(mCounter, memCount);
					selectFosterCareStateForMember(mCounter, memsData.get(mCounter).fosterCareState);
					selectYesForFosterCareMemberhasStatePlan(mCounter);
					selectFosterCareAgeLeftForMember(mCounter, memsData.get(mCounter).fosterCareLeftAge);
				}

				if(memsData.get(mCounter).brestCancer){
					selectIfMemberIsBreastCancerPatient(mCounter, memCount);
				}

				if(memsData.get(mCounter).hivPositive){
					selectIfMemberIsHIVPatient(mCounter, memCount);
				}
			}
			clickOnSaveAndContinueBtn();
		}
	}
	
	// ppinho
	public void racCompleteMoreAboutHHForMembers(boolean faReqd, String whoIsApplying, List<RAC_MemData> memsData) throws Exception {
		if(faReqd){
			int memCount = memsData.size();

			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(mCounter == 0 && whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;

				if(memsData.get(mCounter).isDisabled){
					selectIfMemberIsDisbaled(mCounter, memCount);
				}

				if(memsData.get(mCounter).isAIAN){
					if(!memsData.get(mCounter).raceList.contains(Race.AMERICAN_INDIAN_OR_ALASKA_NATIVE.val)){
						selectIfMemberIsAIAN(mCounter,memCount);
					}
					selectAIANStateForMember(mCounter, memsData.get(mCounter).indoAmericanState);
					selectAIANTribeForMember(mCounter, memsData.get(mCounter).indoAmericanTribe);
				}

				if(memsData.get(mCounter).isPregnant){
					selectIfMemberIsPregnant(mCounter, memCount);
					selectPregMemberBabyCount(mCounter, memsData.get(mCounter).prgBabyCount);
					enterPregMemberBabyDueDate(mCounter, memsData.get(mCounter).babyDueDate);
				}

				if(memsData.get(mCounter).fosterCare){
					selectIfMemberWasInFosterCare(mCounter, memCount);
					selectFosterCareStateForMember(mCounter, memsData.get(mCounter).fosterCareState);
					selectYesForFosterCareMemberhasStatePlan(mCounter);
					selectFosterCareAgeLeftForMember(mCounter, memsData.get(mCounter).fosterCareLeftAge);
				}

				if(memsData.get(mCounter).brestCancer){
					selectIfMemberIsBreastCancerPatient(mCounter, memCount);
				}

				if(memsData.get(mCounter).hivPositive){
					selectIfMemberIsHIVPatient(mCounter, memCount);
				}
			}
			clickOnSaveAndContinueBtn();
		}
	}
}
