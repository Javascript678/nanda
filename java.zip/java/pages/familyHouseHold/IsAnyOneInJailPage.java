package pages.familyHouseHold;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class IsAnyOneInJailPage extends CommonPage implements CommonPageOR{
	
	private static final By isAnyOneInJailPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Is Anyone in Jail or Prison?')]");

	public IsAnyOneInJailPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("IsAnyOneInJailPageHeader", isAnyOneInJailPageHeader);
	}
	
public void selectIfNoOneIncarcerated(boolean trueFalseValue) throws Exception{
             By membersInJailRdBtn = By.xpath("//input[@name='agreement.isNoHouseholdMemberIncarcerated' and @value='"+trueFalseValue+"']/../label");
             //selectByValue("MembersInJailRdBtn" , membersInJailRdBtn, trueFalseValue+"");
             clickOnElement("MembersInJailRdBtn", membersInJailRdBtn);
}
	
	public void selectInJailChkBxForMember(int memIndex) throws Exception{
		By memberInJailChkBx = By.id("incarceration_incarcerated_"+memIndex);
		clickOnElement("Mem"+(memIndex+1) + "InJailChkBx" , memberInJailChkBx);
	}
	
	public void selectIfMemberAwaitingTrial(int memIndex, boolean trueFalseValue) throws Exception{
		//By memberAwaitingTrialRdBtn = By.name("eligibilityMember["+memIndex+"].incarceration.pendingDisposition");
		By memberAwaitingTrialRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].incarceration.pendingDisposition' and @value='"+trueFalseValue+"']/../label");
		
		//selectByValue("Mem"+(memIndex+1)+"AwaitingTrialRdBtn" , memberAwaitingTrialRdBtn, trueFalseValue+"");
		clickOnElement("Mem"+(memIndex+1)+"AwaitingTrialRdBtn" , memberAwaitingTrialRdBtn);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void provideDetailIfAnyMemberInJail(List<EVPD_MemData> memsData) throws Exception{
		boolean atleastOneMemInJail = false;
		//waitForPageLoaded();
		
		int memCount = memsData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++ ){
			if(memsData.get(mCounter).isInPrison){
				atleastOneMemInJail = true;
				break;
			}
		}
		
		if(atleastOneMemInJail){
			selectIfNoOneIncarcerated(false);
		}else{
			selectIfNoOneIncarcerated(true);
		}
		
		for(int mCounter = 0; mCounter < memCount; mCounter++ ){
			if(memsData.get(mCounter).isInPrison){
				selectInJailChkBxForMember(mCounter);
				selectIfMemberAwaitingTrial(mCounter, true);
			}
		}
		clickOnSaveAndContinueBtn();
	}
	
	//ppinho
	public void evpdProvideDetailIfAnyMemberInJail(List<EVPD_MemData> memsData) throws Exception {		
		boolean atleastOneMemInJail = false;
		//waitForPageLoaded();
		
		int memCount = memsData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++ ){
			if(memsData.get(mCounter).isInPrison){
				atleastOneMemInJail = true;
				break;
			}
		}
		
		if(atleastOneMemInJail){
			selectIfNoOneIncarcerated(false);
		}else{
			selectIfNoOneIncarcerated(true);
		}
		
		for(int mCounter = 0; mCounter < memCount; mCounter++ ){
			if(memsData.get(mCounter).isInPrison){
				selectInJailChkBxForMember(mCounter);
				selectIfMemberAwaitingTrial(mCounter, true);
			}
		}
		clickOnSaveAndContinueBtn();
	}
	
	//ppinho
	public void racProvideDetailIfAnyMemberInJail(List<RAC_MemData> memsData) throws Exception {		
		boolean atleastOneMemInJail = false;
		//waitForPageLoaded();
		
		int memCount = memsData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++ ){
			if(memsData.get(mCounter).isInPrison){
				atleastOneMemInJail = true;
				break;
			}
		}
		
		if(atleastOneMemInJail){
			selectIfNoOneIncarcerated(false);
		}else{
			selectIfNoOneIncarcerated(true);
		}
		
		for(int mCounter = 0; mCounter < memCount; mCounter++ ){
			if(memsData.get(mCounter).isInPrison){
				selectInJailChkBxForMember(mCounter);
				selectIfMemberAwaitingTrial(mCounter, true);
			}
		}
		clickOnSaveAndContinueBtn();
	}
	
}