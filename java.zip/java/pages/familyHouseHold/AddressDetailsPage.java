package pages.familyHouseHold;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class AddressDetailsPage extends CommonPage implements CommonPageOR{
	
	private static final By addressDetailPageHeader = By.xpath("//h1[contains(text(),'Address Details')]");
	private static final By saveAndContinueBtn = By.id("otherAddressNextPage");
	
	public AddressDetailsPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("AddressDetailPageHeader", addressDetailPageHeader);
	}
	
	public void clickOnOtherAddressChkBxForMember(int memIndex) throws Exception{
		By memOtherAddressChkBx	= By.name("eligibilityMember["+ memIndex + "].isOtherAddress");
		clickOnElement("Mem"+ (memIndex+1) + "OtherAddressChkBx" , memOtherAddressChkBx);
	}
	
	public void enterPrimaryAddressStreetForMember(int memIndex, String street) throws Exception{
		By memPrimaryAddressStr1	= By.id("eligibilityMember["+ memIndex + "].contactInfo.primaryAddress.streetAddress1");
		clearAndType("Mem"+ (memIndex+1) + "PrimaryAddressStr1" , memPrimaryAddressStr1, street);
	}
	public void enterPrimaryCityForMember(int memIndex, String city) throws Exception{
		By memPrimaryCity	= By.id("eligibilityMember["+ memIndex + "].contactInfo.primaryAddress.city");
		clearAndType("Mem"+ (memIndex+1) + "PrimaryCity" , memPrimaryCity, city);
	}
	public void enterPrimaryZipForMember(int memIndex, String zipCode) throws Exception{
		By memPrimaryZip	= By.id("eligibilityMember["+ memIndex + "].contactInfo.primaryAddress.zip");
		clearAndType("Mem"+ (memIndex+1) + "PrimaryZip" , memPrimaryZip, zipCode);
	}
	
	public void selectPrimaryCountyForMember(int memIndex, String county) throws Exception{
		By memPrimaryCounty	= By.id("eligibilityMember["+ memIndex + "].contactInfo.primaryAddress.county");
		selectByVisibleTextAfterWait("Mem"+ (memIndex+1) + "PrimaryCounty" , memPrimaryCounty, county);
	}
	
	public void clickOnLivingOutsideMAYesRdBtnForMember(int memIndex) throws Exception{
		By memLivingOutsideMATempYesRdBtn = By.id("eligibilityMember"+ memIndex + ".isLivingOutsideTemporarily1");
		clickOnElement("Mem"+ (memIndex+1) + "LivingOutsideMATempYesRdBtn" , memLivingOutsideMATempYesRdBtn);
	}
	public void enterMACityForMember(int memIndex, String city) throws Exception{
		By memMACity	= By.id("eligibilityMember["+memIndex+"].temporaryAddress.city");
		clearAndType("Mem"+ (memIndex+1) + "MACity" , memMACity, city);
	}
	public void enterMAZipForMember(int memIndex, String zipCode) throws Exception{
		By memMAZip	= By.id("eligibilityMember["+memIndex+"].temporaryAddress.zip");
		clearAndType("Mem"+ (memIndex+1) + "MAZip" , memMAZip, zipCode);
	}
	public void selectMACountyForMember(int memIndex, String county) throws Exception{
		
		By memMACounty	= By.id("eligibilityMember["+memIndex+"].temporaryAddress.county");
		selectByVisibleTextAfterWait("Mem"+ (memIndex+1) + "MACounty" , memMACounty, county);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}
	
	public void clickOnUSPSOtherAddressForMember(int memIndex) throws Exception{
		By memUSPSOtherAddressRdBtn	= By.id("enteredHomeAddressRadioButton-"+memIndex);
		clickOnElement("Mem"+(memIndex+1)+"USPSOtherAddressRdBtn" , memUSPSOtherAddressRdBtn);
	}
	public void clickOnNoHomeAddressForMember(int memIndex) throws Exception{
		By memNoHomeAddressRdBtn	= By.id("no_primary_address_"+memIndex);
		clickOnElement("Mem"+(memIndex+1)+"NoHomeAddressRdBtn" , memNoHomeAddressRdBtn);
	}
	
	public void clickOnOkBtn() throws Exception{
		clickOnElement("OKButton" , oKButton);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	public void taksScreenShot() throws Exception {
		takeScreenshot("Address Summary");
	}
	
	public void enterAddressDetailsForMembers(String whoIsApplying,List<EVPD_MemData> memsData) throws Exception {
		boolean atleastOneMemberNotLivingWithHOH = false;
		
		if(!whoIsApplying.equals(WhoIsApplying.SELF.code)){
			//waitForPageLoaded();
			int memCount = memsData.size();
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(mCounter == 0) continue;
				boolean tempLivingOutsideMA = memsData.get(mCounter).tempLivingOutsideMA;
				
				if(!memsData.get(mCounter).livingWithM1){
					clickOnOtherAddressChkBxForMember(mCounter);
					enterPrimaryAddressStreetForMember(mCounter, memsData.get(mCounter).homeAddr.streetAddress);
					enterPrimaryCityForMember(mCounter, memsData.get(mCounter).homeAddr.city);
					
					if(!tempLivingOutsideMA){
						enterPrimaryZipForMember(mCounter, memsData.get(mCounter).homeAddr.zipCode);
						selectPrimaryCountyForMember(mCounter, memsData.get(mCounter).homeAddr.county);
					}else{
						enterPrimaryZipForMember(mCounter, memsData.get(mCounter).ousideMAZipCode);
						selectPrimaryCountyForMember(mCounter, memsData.get(mCounter).ousideMAZipCounty);
						clickOnLivingOutsideMAYesRdBtnForMember(mCounter);
						enterMACityForMember(mCounter, memsData.get(mCounter).homeAddr.city);
						enterMAZipForMember(mCounter, memsData.get(mCounter).homeAddr.zipCode);
						selectMACountyForMember(mCounter, memsData.get(mCounter).homeAddr.county);
					}					
				}
			}
			
			clickOnSaveAndContinueBtn();
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(mCounter == 0) continue;
				
				if(!memsData.get(mCounter).livingWithM1){
					atleastOneMemberNotLivingWithHOH = true;
					clickOnUSPSOtherAddressForMember(mCounter);
				}
			}
			
			if(atleastOneMemberNotLivingWithHOH){
				clickOnOkBtn();
			}
		}
	}
	
	// ppinho
	public void evpdEnterAddressDetailsForMembers(String whoIsApplying, List<EVPD_MemData> memsData) throws Exception{
		boolean atleastOneMemberNotLivingWithHOH = false;
		
		if(!whoIsApplying.equals(WhoIsApplying.SELF.code)){
			int memCount = memsData.size();
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(mCounter == 0) continue;
				
				boolean tempLivingOutsideMA = memsData.get(mCounter).tempLivingOutsideMA;
				
				//if(!memsData.get(mCounter).livingWithM1){
				if(!memsData.get(mCounter).livingWith.get(0)){
					clickOnOtherAddressChkBxForMember(mCounter);
					enterPrimaryAddressStreetForMember(mCounter, memsData.get(mCounter).homeAddr.streetAddress);
					enterPrimaryCityForMember(mCounter, memsData.get(mCounter).homeAddr.city);
					
					if(!tempLivingOutsideMA){
						enterPrimaryZipForMember(mCounter, memsData.get(mCounter).homeAddr.zipCode);
						selectPrimaryCountyForMember(mCounter, memsData.get(mCounter).homeAddr.county);
					}else{
						enterPrimaryZipForMember(mCounter, memsData.get(mCounter).ousideMAZipCode);
						selectPrimaryCountyForMember(mCounter, memsData.get(mCounter).ousideMAZipCounty);
						clickOnLivingOutsideMAYesRdBtnForMember(mCounter);
						enterMACityForMember(mCounter, memsData.get(mCounter).homeAddr.city);
						enterMAZipForMember(mCounter, memsData.get(mCounter).homeAddr.zipCode);
						selectMACountyForMember(mCounter, memsData.get(mCounter).homeAddr.county);
					}					
				}
			}
			
			clickOnSaveAndContinueBtn();
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(mCounter == 0) continue;
				
				//if(!memsData.get(mCounter).livingWithM1){
				if(!memsData.get(mCounter).livingWith.get(0)){
					atleastOneMemberNotLivingWithHOH = true;
					clickOnUSPSOtherAddressForMember(mCounter);
				}
			}
			
			if(atleastOneMemberNotLivingWithHOH){
				clickOnOkBtn();
			}
		}
	}
	
	// ppinho
	public void racEnterAddressDetailsForMembers(String whoIsApplying, List<RAC_MemData> memsData) throws Exception{
		boolean atleastOneMemberNotLivingWithHOH = false;
		
		if(!whoIsApplying.equals(WhoIsApplying.SELF.code)){
			int memCount = memsData.size();
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(mCounter == 0) continue;
				
				boolean tempLivingOutsideMA = memsData.get(mCounter).tempLivingOutsideMA;
				
				//if(!memsData.get(mCounter).livingWithM1){
				if(!memsData.get(mCounter).livingWith.get(0)){
					clickOnOtherAddressChkBxForMember(mCounter);
					enterPrimaryAddressStreetForMember(mCounter, memsData.get(mCounter).homeAddr.streetAddress);
					enterPrimaryCityForMember(mCounter, memsData.get(mCounter).homeAddr.city);
					
					if(!tempLivingOutsideMA){
						enterPrimaryZipForMember(mCounter, memsData.get(mCounter).homeAddr.zipCode);
						selectPrimaryCountyForMember(mCounter, memsData.get(mCounter).homeAddr.county);
					}else{
						enterPrimaryZipForMember(mCounter, memsData.get(mCounter).ousideMAZipCode);
						selectPrimaryCountyForMember(mCounter, memsData.get(mCounter).ousideMAZipCounty);
						clickOnLivingOutsideMAYesRdBtnForMember(mCounter);
						enterMACityForMember(mCounter, memsData.get(mCounter).homeAddr.city);
						enterMAZipForMember(mCounter, memsData.get(mCounter).homeAddr.zipCode);
						selectMACountyForMember(mCounter, memsData.get(mCounter).homeAddr.county);
					}					
				}
			}
			
			clickOnSaveAndContinueBtn();
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(mCounter == 0) continue;
				
				//if(!memsData.get(mCounter).livingWithM1){
				if(!memsData.get(mCounter).livingWith.get(0)){
					atleastOneMemberNotLivingWithHOH = true;
					clickOnUSPSOtherAddressForMember(mCounter);
				}
			}
			
			if(atleastOneMemberNotLivingWithHOH){
				clickOnOkBtn();
			}
		}
	}
}
