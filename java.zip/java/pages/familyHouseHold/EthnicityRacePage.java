package pages.familyHouseHold;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_Data;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class EthnicityRacePage extends CommonPage implements CommonPageOR{
	
	private static final By ethnicityPageHeader = By.xpath("//h1[contains(text(),'Ethnicity')]");
		
	public EthnicityRacePage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("EthnicityPageHeader", ethnicityPageHeader);
	}
	
	private void waitForPageLoaded(int memIndex) throws Exception{
		By memberOtherOriginRdBtn		= By.name("eligibilityMember[" + memIndex + "].isOtherOrigin");
		waitForPresenceOfElementLocated("EthnicityPageHeader", memberOtherOriginRdBtn);
	}
	
	public void selectMemOtherOriginRdBtn(int memIndex, boolean trueFalseValue) throws Exception{
		By memberOtherOriginRdBtn		= By.name("eligibilityMember[" + memIndex + "].isOtherOrigin");
		//selectByValue("Mem"+ (memIndex+1) + "OtherOriginRdBtn", memberOtherOriginRdBtn, trueFalseValue+"");
		selectByAttributeNameUsingJS("Mem"+ (memIndex+1) + "OtherOriginRdBtn", memberOtherOriginRdBtn, "value", trueFalseValue+"");
	}
	
	public void selectEthnicityForMember(int memIndex, String ethnicity) throws Exception{
		By memberEthnicityChkBx		= By.name("eligibilityMember[" + memIndex + "].ethnicityList");
		selectByValue("Mem"+ (memIndex+1) + "EthnicityChkBx", memberEthnicityChkBx, ethnicity);
	}
	
	public void selectRaceForMember(int memIndex, String race) throws Exception{
		By memberRaceChkBx		= By.name("eligibilityMember[" + memIndex + "].raceList");
		selectByValue("Mem"+ (memIndex+1) + "RaceChkBx", memberRaceChkBx, race);
	}
	
	
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn(int memIndex) throws Exception{
		waitForPageLoaded(memIndex);
		clickOnSaveAndContinueBtn();
	}
	
	public void pageLoadValidatePageTitleDontContainsNameThenClickOnSave(int memIndex, String fullName) throws Exception {
		waitForPageLoaded(memIndex);
		String actualTitle = getCurrentPageTitle();
		validateTextNotContains("EthnicityRacePageTitle", actualTitle, fullName);
		clickOnSaveAndContinueBtn();
	}

	
	public void selectEthnicityRaceForMembrs(String whoIsApplying, List<EVPD_MemData> memsData) throws Exception{
		int memCount = memsData.size();
		waitForPageLoaded();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			if(mCounter == 0 && whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
			
			if(memsData.get(mCounter).ethnicityList.equals("")){
				selectMemOtherOriginRdBtn(mCounter, false);
			}else{
				selectMemOtherOriginRdBtn(mCounter, true);
				selectEthnicityForMember(mCounter, memsData.get(mCounter).ethnicityList);
			}
			
			if(! memsData.get(mCounter).raceList.equals("")){
				selectRaceForMember(mCounter, memsData.get(mCounter).raceList);
			}
			clickOnSaveAndContinueBtn();
		}
	}
	
	public void evpdSelectEthnicityRaceForMembrs(int memIndex, EVPD_Data evpdData) throws Exception {
		if(evpdData.memsData.get(memIndex).ethnicityList.equals("")){
			selectMemOtherOriginRdBtn(memIndex, false);
		}else{
			selectMemOtherOriginRdBtn(memIndex, true);
			selectEthnicityForMember(memIndex, evpdData.memsData.get(memIndex).ethnicityList);
		}
			
		if(!evpdData.memsData.get(memIndex).raceList.equals("")){
			selectRaceForMember(memIndex, evpdData.memsData.get(memIndex).raceList);
		}
		clickOnSaveAndContinueBtn();
	}
	
	public void racSelectEthnicityRaceForMembrs(int memIndex, RAC_Data evpdData) throws Exception {
		if(evpdData.memsData.get(memIndex).ethnicityList.equals("")){
			selectMemOtherOriginRdBtn(memIndex, false);
		}else{
			selectMemOtherOriginRdBtn(memIndex, true);
			selectEthnicityForMember(memIndex, evpdData.memsData.get(memIndex).ethnicityList);
		}
			
		if(!evpdData.memsData.get(memIndex).raceList.equals("")){
			selectRaceForMember(memIndex, evpdData.memsData.get(memIndex).raceList);
		}
		clickOnSaveAndContinueBtn();
	}

}
