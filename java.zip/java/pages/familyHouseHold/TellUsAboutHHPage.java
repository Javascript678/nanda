package pages.familyHouseHold;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import enums.DepRelationship;
import enums.DepSecondaryRelationship;
import enums.Relationship;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/** @author Paul Pinho
 * Aashita Verma

 * 
 */
public class TellUsAboutHHPage extends CommonPage implements CommonPageOR{
	
	private static final By tellAbtHshldPageHeader = By.xpath("//h1[contains(text(),'Tell Us About Your Household')]");
	
	public TellUsAboutHHPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("TellAbtHshldPageHeader", tellAbtHshldPageHeader);
	}
	
	private boolean identifyMember(int memIndex, boolean isU18) throws Exception {
		By hohTaxFilingRdBtn = By.xpath("//div[@id='SSAP1_" + memIndex + "']");
		By hohBeClaimedAsDependentRdBtn = By.xpath("//div[@id='SSAP7_" + memIndex + "']");
		
		if(isU18){
			return isElementPresent(hohBeClaimedAsDependentRdBtn, 5);
		}else{
			return isElementPresent(hohTaxFilingRdBtn, 5);
		}		
	}
	
	//Agree to File ITR	
	private boolean answerHHAgreeToFileITRInd(int memIndex) throws Exception {
		By answerHHAgreeToFileITRRdBtn = By.xpath("//div[@id='SSAP1_" + memIndex + "']//input[@type='radio']");
		return isElementPresent(answerHHAgreeToFileITRRdBtn, 5);
	}
	
	public void answerHHAgreeToFileITR(int taxHHIndex, int memIndex, boolean trueFalseValue) throws Exception {
		By hohTaxFilingRdBtn = By.xpath("//div[@id='SSAP1_" + memIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("TaxHH" + taxHHIndex + "TaxFilingRdBtn" + trueFalseValue, hohTaxFilingRdBtn);
	}
	
	private boolean hhLegallyMarriedInd(int memIndex) throws Exception {
		By hohLegallyMarriedRdBtn = By.xpath("//div[@id='SSAP2_" + memIndex + "']");
		return isElementPresent(hohLegallyMarriedRdBtn, 5);
	}
	
	public void answerHHLegallyMarried(int taxHHIndex, int memIndex, boolean trueFalseValue) throws Exception {
		By hohLegallyMarriedRdBtn = By.xpath("//div[@id='SSAP2_" + memIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("TaxHH" + taxHHIndex + "LegallyMarriedRdBtn" + trueFalseValue, hohLegallyMarriedRdBtn);
	}
	
	public void answerHHFilingTaxJointly(int taxHHIndex, int memIndex, boolean trueFalseValue) throws Exception {
		By hohFilingTaxJointlyRdBtn = By.xpath("//div[@id='SSAP3_" + memIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("TaxHH" + taxHHIndex + "FilingTaxJointlyRdBtn" + trueFalseValue, hohFilingTaxJointlyRdBtn);
	}
	
	public void answerTaxHHLiveWithSpouse_RdBtn(int taxHHIndex, int memIndex, boolean trueFalseValue) throws Exception {
		By hohLiveWithSpouseRdBtn = By.xpath("//div[@id='SSAP5_" + memIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("TaxHH" + taxHHIndex  + "LiveWithSpouseRdBtn" + trueFalseValue ,hohLiveWithSpouseRdBtn);
	}
	
	public void answerWhoIsTaxHHSpouse_RdBtn(int taxHHIndex, int memIndex, String memberIndex) throws Exception {
		By hohSpouseRdBtn = By.xpath("//div[@id='SSAP4_" + memIndex + "']//input[@type='radio' and @value='" + memberIndex + "']/../label");
		clickOnElement("TaxHH" + taxHHIndex  + "SpouseRdBtn", hohSpouseRdBtn);	
	}
	
	public void answerIfTaxHHClaimAnyDependentOnTheirITR_RdBtn(int taxHHIndex, int memIndex, boolean trueFalseValue) throws Exception {
		By hohClaimDepRdBtn = By.xpath("//div[@id='SSAP6_" + memIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("TaxHH" + taxHHIndex  + "ClaimDepRdBtn" + trueFalseValue, hohClaimDepRdBtn);
	}
	
	public void answerWhoAllLiveWithMem(int taxHHIndex, int memIndex, String dependentMembersByIndex) throws Exception {
		String[] depArr = dependentMembersByIndex.split(",");
		int depMem []= new int[10];
		 
		for(int i = 0; i < depArr.length; i++){
			 depMem[i] = Integer.parseInt(depArr[i]);
	
			 By whoAllLiveWithTaxHHCheckBox = By.xpath("//div[@id='SSAP6_" + memIndex + "']//input[@value='" + depMem[i]+ "']/../label");
			 clickOnElement("WhoAllLiveWithTaxHH" + (taxHHIndex + 1)  + "CheckBox", whoAllLiveWithTaxHHCheckBox);
		}
	}
	
	private boolean taxHHBeClaimedAsDependentOnSomeOneElseITRInd(int memIndex) throws Exception {
		By hohBeClaimedAsDependentRdBtn = By.xpath("//div[@id='SSAP7_" + memIndex + "']");
		return isElementPresent(hohBeClaimedAsDependentRdBtn, 5);
	}	
	
	public void answerIfTaxHHBeClaimedAsDependentOnSomeOneElseITR_RdBtn(int taxHHIndex, int memIndex, boolean trueFalseValue) throws Exception {
		By hohBeClaimedAsDependentRdBtn = By.xpath("//div[@id='SSAP7_" + memIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("TaxHH" + taxHHIndex + "BeClaimedAsDependentRdBtn" + trueFalseValue, hohBeClaimedAsDependentRdBtn);
	}
	
	//Shailza
	public void answerWhoWillClaimTaxHHAsDependent(int taxHHIndex, String dependentMembersByIndex) throws Exception {
		By answerWhoWillClaimTaxHHAsDependentRadioButton = By.xpath("//div[@id='SSAP6_" + taxHHIndex + "']/div/fieldset/div[1]//input");
		selectByValueUsingJS("WhoWillClaimTaxHHAsDependent" + taxHHIndex  + "RadioButton", answerWhoWillClaimTaxHHAsDependentRadioButton, dependentMembersByIndex);
	}
	
	public void relationCd(int taxHHIndex,int memIndex,int depIndex,String primaryRelation) throws Exception{
		By relationshipDD = By.xpath("//select[@id='SSAP8_" + memIndex + "_" + depIndex + "']");
		
		if(primaryRelation==Relationship.FORMER_SPOUSE.dropDownVal||primaryRelation == Relationship.FOSTER_CHILD.dropDownVal || primaryRelation == Relationship.GUARDIAN.dropDownVal || primaryRelation == Relationship.OTHER_RELATIVE.dropDownVal || primaryRelation == Relationship.UNRELATED.dropDownVal || primaryRelation == Relationship.WARD.dropDownVal) {
			String primaryRelationSel = primaryRelation;
			primaryRelationSel = Relationship.OTHER_UNRELATED.dropDownVal;
			
			selectDropDownElementByVisibleText("TaxHH" + (taxHHIndex) + "RelationWithTaxHH" + (depIndex) + "DD", relationshipDD ,primaryRelationSel);	
			answerOtherRelationship(taxHHIndex, depIndex,primaryRelation);	
		}else if(primaryRelation == Relationship.CHILD_IN_LAW.dropDownVal) {
			String PrimaryRelationOth = primaryRelation;
			
			PrimaryRelationOth = Relationship.OTHER_RELATIVE.dropDownVal;
			selectDropDownElementByVisibleText("TaxHH" + (taxHHIndex) + "RelationWithTaxHH" + (depIndex) + "DD", relationshipDD , PrimaryRelationOth);	
		}else{
			 //selectDropDownElementByVisibleText("TaxHH" + (taxHHIndex) + "RelationWithTaxHH" + (depIndex) + "DD", relationshipDD ,primaryRelation);
			selectDropDownElementByVisibleText("TaxHH" + taxHHIndex  + "RelationShipWithMem" + depIndex, relationshipDD, primaryRelation);
		}
	}
	

	// updated by ppinho
	public void answerTaxHHMemberRelationship(int taxHHIndex, int memIndex, int depIndex, String primaryRelation, String secondaryRelation) throws Exception {
		//By relationshipDD = By.xpath("//select[@id='SSAP8_" + memIndex + "_" + depIndex + "']");
		relationCd(taxHHIndex,memIndex,depIndex,primaryRelation);
		
		if(primaryRelation.equals(DepRelationship.OTHER_UNRELATED.dropDownVal)){
						answerTaxHHMemberRelationship2(taxHHIndex, memIndex, depIndex, secondaryRelation);
					}
	}
	
	// updated by ppinho
	public void answerTaxHHMemberRelationship2(int taxHHIndex, int memIndex, int depIndex, String secondaryRelation) throws Exception {
		By secondaryRelationshipDD = By.xpath("//select[contains(@id,'SSAP8_" + memIndex + "') and contains(@id,'otherRelationship')]");
		
		EnumSet.allOf(DepSecondaryRelationship.class).forEach(secRel -> {
			if(secondaryRelation.equals(secRel.dropDownVal)){				
				try {
					selectDropDownElementByIndex("TaxHH" + taxHHIndex  + "RelationShip2WithMem" + depIndex, secondaryRelationshipDD, secRel.index);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}			
		});
	}
	
	public void answerTaxHHSpouseMemberRelationship(int memberIndex, int depIndex, String relation) throws Exception {
		By relationShipDD = By.xpath("//select[@id ='SSAP8_"+ memberIndex + "_" + (depIndex) + "_j");

		if(relation.equals(Relationship.UNRELATED.dropDownVal)){
			selectDropDownElementByVisibleText("SpouseRelationShipWithMem" + (depIndex + 1), relationShipDD, "Other unrelated");
			answerTaxHHSpouseMemberRelationship2(memberIndex, depIndex, Relationship.UNRELATED.dropDownVal);
		}else{
			selectDropDownElementByVisibleText("SpouseRelationShipWithMem" + (depIndex + 1), relationShipDD, relation);
		}
	}
	
	// updated by ppinho
	public void answerTaxHHSpouseMemberRelationship(int memberIndex, int depIndex, int spMemberIndex, String primaryRelation, String secondaryRelation) throws Exception {
		By relationShipDD = By.xpath("//select[@id ='SSAP8_"+ memberIndex + "_" + (depIndex) + "_j']");
		
		if(primaryRelation.equals(Relationship.OTHER_UNRELATED.dropDownVal)){
			selectDropDownElementByVisibleText("SpouseRelationShipWithMem" + (depIndex + 1), relationShipDD, primaryRelation);
			answerTaxHHSpouseMemberRelationship2(memberIndex, depIndex, secondaryRelation);
		}else{
			selectDropDownElementByVisibleText("SpouseRelationShipWithMem" + (depIndex + 1), relationShipDD, primaryRelation);
		}
	}
	
	public void answerTaxHHSpouseMemberRelationship2(int taxHHIndex, int memberIndex, String relation)throws Exception {
		By relationShipDD = By.xpath("//select[@id='SSAP8_" + taxHHIndex + "_" + memberIndex + "_j']/parent::div/parent::div/div[2]/select");
		selectDropDownElementByVisibleText("SpouseRelationShip2WithMem" + (memberIndex + 1), relationShipDD, relation);
	}
	// If a member lives with Tax HH
	private boolean ifMemberLivesWithTaxHHInd(int memIndex) throws Exception {
		By ifMemberLivesWithTaxHHRdBtn = By.xpath("//div[@id='SSAP15_" + memIndex + "']//input[@type='radio']");
		return isElementPresent(ifMemberLivesWithTaxHHRdBtn, 5);
	}

	public void answerIfMemberLivesWithTaxHH(int taxHHIndex, int memIndex, boolean trueFalseValue) throws Exception {
		By memberLivesWithTahHH = By.xpath("//div[@id='SSAP15_" + memIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "LiveWithTaxHH" + taxHHIndex  + "RdBtn", memberLivesWithTahHH);
	}
	
	// If a member lives with Parent other than Tax HH
	private boolean ifMemberLivesWithParentStepOtherThanTaxHHInd(int memIndex) throws Exception {
		By ifMemberLivesWithParentStepOtherThanTaxHHRdBtn = By.xpath("//div[@id='SSAP16_" + memIndex + "']//input[@type='radio']");
		return isElementPresent(ifMemberLivesWithParentStepOtherThanTaxHHRdBtn, 5);
	}
	
	public void answerIfMemberLivesWithParentStepOtherThanTaxHH(int taxHHIndex, int memberIndex, boolean trueFalseValue) throws Exception {
		By memberLivesWithOtherRdBtn = By.xpath("//div[@id='SSAP16_" + memberIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("Mem" + (memberIndex + 1) + "LiveWithTaxHH" + taxHHIndex  + "RdBtn", memberLivesWithOtherRdBtn);
	}
	
	private boolean memberWithParentStepParentInd(int memIndex) throws Exception {
		By taxhhLivesWithParentStepParentRdBtn = By.xpath("//div[@id='SSAP18_"+ memIndex +"']");
		return isElementPresent(taxhhLivesWithParentStepParentRdBtn, 5);
	}	
	
	public void answerIfMemberWithParentStepParent(int taxHHIndex, int memIndex, boolean trueFalseValue) throws Exception {
		By taxhhLivesWithParentStepParentRdBtn = By.xpath("//div[@id='SSAP18_" + memIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("TaxHH" + taxHHIndex  + "LivesWithParentStepParentRdBtn", taxhhLivesWithParentStepParentRdBtn);
	}
	
	// added by ppinho
	public void answerAllWhoAreMemParentStepparent(int memIndex, String whoAllAreMemParentStepparentIndex) throws Exception {
		By allWhoAreMemParentStepparentCheckBox = By.id("m_SSAP19_" + memIndex + "_" + Integer.parseInt(whoAllAreMemParentStepparentIndex));
		selectByValue("WhoAllAreMemParentStepparent" + (memIndex + 1) + "CheckBox", allWhoAreMemParentStepparentCheckBox, whoAllAreMemParentStepparentIndex);
	}
	
	public void answerIfMemberLivesWithBrotherSister(int taxHHIndex, int memIndex, boolean trueFalseValue)throws Exception{
		By taxhhLivesWithBrotherSisterRdBtn = By.xpath("//div[@id='SSAP20_" + memIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("TaxHH" + taxHHIndex  + "LivesWithBrotherSisterRdBtn", taxhhLivesWithBrotherSisterRdBtn);
	}

	public void brotherSisterLivingWithTaxHH(int taxHHIndex, String siblingMembersByIndex) throws Exception {
		By siblingsOfTaxHHCheckBox = By.xpath(".//*[@id='m_SSAP21_" + taxHHIndex + "_" + siblingMembersByIndex + "']");
		selectByValue("WhoAllLiveWithTaxHH" + taxHHIndex  + "CheckBox", siblingsOfTaxHHCheckBox, siblingMembersByIndex);
	}
	
	//Neel
	public void answerOtherRelationship(int taxHH1Index,int taxHH2Index,String secondaryRelation) throws Exception {
		By relationship = By.xpath("//select[contains(@id,'SSAP8_0_" + taxHH2Index +"0')]");
		//input[contains(@id,'ssap25_0_"
		selectDropDownElementByVisibleText("TaxHH" + (taxHH1Index + 1) + "RelationWithTaxHH" + (taxHH2Index + 1) + "DD", relationship, secondaryRelation);	
		//clickOnSaveAndContinueBtn();
	}
	
	//Shailza
	public void parentLivingWithTaxHH(int taxHHIndex, String parentMembersByIndex)throws Exception{
		By parentOfTaxHHCheckBox = By.xpath(".//*[@id='m_SSAP19_" + taxHHIndex + "_" + parentMembersByIndex + "']");
		selectByValue("WhoAllLiveWithTaxHH" + taxHHIndex  + "CheckBox", parentOfTaxHHCheckBox, parentMembersByIndex);
	}
	
	private boolean memberLivesWithSonDoughterStepSonDaughterInd(int memIndex) throws Exception {
		By taxhhLivesWithParentStepParentRdBtn = By.xpath("//div[@id='SSAP22_" + memIndex + "']");
		return isElementPresent(taxhhLivesWithParentStepParentRdBtn, 5);
	}	
	
	public void answerIfMemberLivesWithSonDoughterStepSonDaughter(int taxHHIndex, int memIndex, boolean trueFalseValue) throws Exception {
		By taxhhLivesWithSonDaughterRdBtn = By.xpath("//div[@id='SSAP22_" + memIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("TaxHH" + taxHHIndex  + "LivesWithSonDaughterRdBtn" + trueFalseValue, taxhhLivesWithSonDaughterRdBtn);	
	}
	
	private boolean taxHH1IstheOfTaxHH2Ind(int memIndex) throws Exception {
		By relationshipDD = By.xpath("//select[@id='SSAP25_0_" + memIndex + "']");
		return isElementPresent(relationshipDD, 5);
	}
	
	public void selectTaxHH1IstheOfTaxHH2(int taxHH1Index, int taxHH2Index, String relation) throws Exception {
		By relationship = By.xpath("//select[@id='SSAP25_0_" + taxHH2Index + "']");
		
		if(relation == Relationship.FORMER_SPOUSE.dropDownVal || relation == Relationship.FOSTER_CHILD.dropDownVal || relation == Relationship.GUARDIAN.dropDownVal || relation == Relationship.OTHER_RELATIVE.dropDownVal || relation == Relationship.UNRELATED.dropDownVal || relation == Relationship.WARD.dropDownVal) {
			String primaryRelation = relation;
			primaryRelation = Relationship.OTHER_UNRELATED.dropDownVal;
			
			selectDropDownElementByVisibleText("TaxHH" + (taxHH1Index + 1) + "RelationWithTaxHH" + (taxHH2Index + 1) + "DD", relationship,primaryRelation);	
			answerOtherRelationship(taxHH1Index, taxHH2Index,relation);	
		}else if(relation == Relationship.CHILD_IN_LAW.dropDownVal){
			String PrimaryRelation = relation;
			
			PrimaryRelation = Relationship.OTHER_RELATIVE.dropDownVal;
			selectDropDownElementByVisibleText("TaxHH" + (taxHH1Index + 1) + "RelationWithTaxHH" + (taxHH2Index + 1) + "DD", relationship, PrimaryRelation);	
		}
		 else{
		 selectDropDownElementByVisibleText("TaxHH" + (taxHH1Index + 1) + "RelationWithTaxHH" + (taxHH2Index + 1) + "DD", relationship,relation);	
	}}
	
	public void selectTaxHH1LivesWithTaxHH2(int taxHH1Index, int taxHH2Index, boolean trueFalseValue) throws Exception {
		By livesWithRdBtn = By.xpath("//input[contains(@id,'ssap25_0_" + taxHH2Index + "') and @value='" + trueFalseValue + "']/../label");
		clickOnElement("TaxHH" + (taxHH1Index + 1) + "LivesWithTaxHH" + (taxHH2Index + 1) +"RdBtn" + trueFalseValue, livesWithRdBtn);
	}
	
	// Amrita
	public void selectTaxHHClaimedBySomeoneNotApplying(int taxHHIndex) throws Exception {
		By claimedBySomeoneNotApplyingRdBtn = By.xpath("//input[contains(@id,'m_SSAP7_" + taxHHIndex + "_other')]");
		clickOnElement("TaxHH" + taxHHIndex  + "Claimed By SomeOne Not Applying RdBtn", claimedBySomeoneNotApplyingRdBtn);
	}

	// Amrita
	public void enterNotApplyingMemberFirstName(int claimedmemberNo, String firstName) throws Exception {
		By memberFirstNameTxt = By.id("Tax_filer_firstName_" + (claimedmemberNo - 1) + "_[0]");
		enterText("First Name For Person Claiming Member" + claimedmemberNo, memberFirstNameTxt, firstName);
	}

	// Amrita
	public void enterNotApplyingMemberMiddleName(int claimedmemberNo, String middleName) throws Exception {
		By memberMiddleNameTxt = By.id("Tax_filer_middleName_" + (claimedmemberNo - 1) + "_[0]");
		enterText("Middle Name For Person Claiming Member" + claimedmemberNo, memberMiddleNameTxt, middleName);
	}

	// Amrita
	public void enterNotApplyingMemberLastName(int claimedmemberNo, String lastName) throws Exception {
		By memberLastNameTxt = By.id("Tax_filer_lastName_" + (claimedmemberNo - 1) + "_[0]");
		enterText("Last Name For Person Claiming Member" + claimedmemberNo, memberLastNameTxt, lastName);
	}

	// Amrita
	public void enterNotApplyingMemberDOB(int claimedmemberNo, String dob) throws Exception {
		By memberDOB = By.id("Tax_filer_s_dob_" + (claimedmemberNo - 1) + "_[0]");
		clearAndType("DOB For Person Claiming Member" + claimedmemberNo, memberDOB, dob);
	}

	// Amrita
	public void answerNotApplyingMemberLegallyMarried(int taxHHIndex, boolean trueFalseValue) throws Exception {
		By notApplyingMemLegallyMarriedRdBtn = By.xpath("//div[@id='SSAP9_" + taxHHIndex + "']//input[@type='radio' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("Not Applying Member Claiming TaxHH" + taxHHIndex  + "LegallyMarriedStatus" + trueFalseValue, notApplyingMemLegallyMarriedRdBtn);
	}

	// Amrita
	public void answerTaxHHRelationWithMemNotApplying(int taxHHIndex, String relation) throws Exception {
		By relationShipDD = By.id("SSAP14_" + taxHHIndex + "_3");
		selectDropDownElementByVisibleText("TaxHH" + taxHHIndex  + "RelationShip With Member Not Applying", relationShipDD, relation);
	}
	
	//Anubhuti
	public void selectTaxHHSpouseWhoIsNotSeekingHI(int taxHHIndex) throws Exception {
		By taxhhSpouseNotSeekingHI = By.xpath("//div[@id='SSAP4_" + taxHHIndex + "']//input[@type='radio']/../label");
		clickOnElement("TaxHH" + taxHHIndex  + "HOH Spouse Not Seeking Health Ins", taxhhSpouseNotSeekingHI);
	}
	
	//Anubhuti
	public void enterSpouseOneFirstName(int spouseNo, String firstName) throws Exception {
		By spouseFirstNameTxt = By.id("Spouse_firstName_" + (spouseNo - 1) + "_[0]");
		enterText("First Name For Spouse " + spouseNo, spouseFirstNameTxt, firstName);
	}
	
	//Anubhuti
	public void enterSpouseOneLastName(int spouseNo, String lastName) throws Exception {
		By spouseLastNameTxt = By.id("Spouse_lastName_" + (spouseNo - 1) + "_[0]");
		enterText("Last Name For Spouse" + spouseNo, spouseLastNameTxt, lastName);
	}
	
	//Anubhuti
	public void enterSpouseOneDOB(int spouseNo, String dob) throws Exception {
		By spouseDOB = By.id("Spouse_s_dob_" + (spouseNo - 1) + "_[0]");
		clearAndTypeAfterWait("DOB For Spouse" + spouseNo, spouseDOB, dob);
	}
	
	//Anubhuti
	public void provideSpouseDetail(int memberNo, String firstName, String lastName, String dob) throws Exception {
		enterSpouseOneFirstName(memberNo, firstName);
		enterSpouseOneLastName(memberNo, lastName);
		enterSpouseOneDOB(memberNo, dob);
	}
	
	//Paul
	public void answerAllParentStepparentWhoLiveWithMem(int memberIndex, int parentStepparentWhoLiveWithMemIndex)throws Exception {
		By ParentStepprentWhoAllLiveWithMemberCheckBox = By.xpath("//div[@id='SSAP16_"+ memberIndex + "']//input[@value='" + parentStepparentWhoLiveWithMemIndex + "']");
		String parentStepparentWhoLiveWithMem = Integer.toString(parentStepparentWhoLiveWithMemIndex);
		selectByValue("WhoAllLiveWithMember" + (memberIndex + 1) + "CheckBox", ParentStepprentWhoAllLiveWithMemberCheckBox, parentStepparentWhoLiveWithMem);
	}

	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn, 3);
		//clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void takeScreenshot() throws Exception {
		takeScreenshot("Summary");
	}

	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	//Aashita
		private boolean IfLegallyMarriedYesNo( int depIndex) throws Exception {
		//By isLegallyMarriedRdBtn = By.xpath("//input[@id= 'SSAP23_" + depIndex + "_" + depIndex + "' and @value='true']/../label");
		By isLegallyMarriedRdBtn = By.xpath("//input[contains(@id,'SSAP23_"+ depIndex +"_')]");
		return isElementPresent(isLegallyMarriedRdBtn, 5);
	}
		
	public void answerIfLegallyMarriedYes( int memIndex, int depIndex) throws Exception {
		By isLegallyMarriedRdBtn = By.xpath("//input[contains(@id,'SSAP23_"+ depIndex +"_') and @value='true']/../label");
		clickOnElement("TaxHH_marriedRdBtn"+ memIndex +" " , isLegallyMarriedRdBtn);
	}
	
	public void answerIfLegallyMarriedNo( int memIndex, int depIndex) throws Exception {
		By isLegallyMarriedRdBtn = By.xpath("//input[contains(@id,'SSAP23_"+ depIndex +"_')and @value='false']/../label");
		clickOnElement("TaxHH_marriedRdBtn"+ memIndex +" " , isLegallyMarriedRdBtn);
	}
	
	public void evpdMoreSelectDetailsForTaxHH(int memIndex, int taxHHIndex) throws Exception{
		if(memberWithParentStepParentInd(memIndex)){
			answerIfMemberWithParentStepParent(taxHHIndex, memIndex, false);
			answerIfMemberLivesWithBrotherSister(taxHHIndex, memIndex, false);
		}
		
		if(memberLivesWithSonDoughterStepSonDaughterInd(memIndex)){
			answerIfMemberLivesWithSonDoughterStepSonDaughter(taxHHIndex, memIndex, false);
		}
		clickOnSaveAndContinueBtn();
	}
	
	public void racMoreSelectDetailsForTaxHH(int memIndex, int taxHHIndex) throws Exception{
		if(memberWithParentStepParentInd(memIndex)){
			answerIfMemberWithParentStepParent(taxHHIndex, memIndex, false);
			answerIfMemberLivesWithBrotherSister(taxHHIndex, memIndex, false);
		}
		
		if(memberLivesWithSonDoughterStepSonDaughterInd(memIndex)){
			answerIfMemberLivesWithSonDoughterStepSonDaughter(taxHHIndex, memIndex, false);
		}
		clickOnSaveAndContinueBtn();
	}
	
	public void evpdCompleteTellUsAboutYourHouseholdForTaxHH(List<EVPD_MemData> memsData, int taxHHIndex, int memIndex) throws Exception {
		if(memsData.get(memIndex).isU18){
			answerIfTaxHHBeClaimedAsDependentOnSomeOneElseITR_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).claimedAsDependentOnSomeOneElse);
		}
		
		answerHHAgreeToFileITR(taxHHIndex, memIndex, memsData.get(memIndex).filingTaxes);
					
		if(hhLegallyMarriedInd(memIndex)){
			answerHHLegallyMarried(taxHHIndex, memIndex, memsData.get(memIndex).married);
		}						
			
		if(memsData.get(memIndex).married){
			if(memsData.get(memIndex).filingTaxes){
				answerHHFilingTaxJointly(taxHHIndex, memIndex, memsData.get(memIndex).jointTaxFiling);
			}
		
			if(memsData.get(memIndex).jointTaxFiling){
				answerWhoIsTaxHHSpouse_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).spouseByIndex);
			}else{
				answerTaxHHLiveWithSpouse_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).liveWithSpouse);
			
				if(memsData.get(memIndex).liveWithSpouse){
					answerWhoIsTaxHHSpouse_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).spouseByIndex);
				}
			}
		}
		
		if(memsData.get(memIndex).filingTaxes){
			answerIfTaxHHClaimAnyDependentOnTheirITR_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).claimAnyDependent);
			
			if(memsData.get(memIndex).claimAnyDependent){				
				answerWhoAllLiveWithMem(taxHHIndex, memIndex, memsData.get(memIndex).dependentMembersByIndex);
				clickOnSaveAndContinueBtn();
				
				String[] depArr = memsData.get(memIndex).dependentMembersByIndex.split(",");
				String relation = memsData.get(memIndex).relation.get(memIndex);
				
				 int depMem []= new int[10];
				 int depRel [] = new int[10];
				 
				 for(int i = 0; i < depArr.length ;i++){					
					 depMem[i]=Integer.parseInt(depArr[i]);
					 
					depRel[i] = depMem[i];
					 
					 String priRelation = memsData.get(memIndex).relation.get(depRel[i]-1);
					 System.out.println(priRelation);
					 
					 String secRelation = memsData.get(memIndex).secondaryRelation.get(depRel[i]-1);
					 System.out.println(secRelation);

					 answerTaxHHMemberRelationship(taxHHIndex, memIndex, depMem[i],priRelation, secRelation);
					 
					 if(IfLegallyMarriedYesNo(depMem[i])){
						 if(memsData.get(memIndex).married){
							 answerIfLegallyMarriedYes( memIndex, depMem[i]);
						 }else{
							 answerIfLegallyMarriedNo(memIndex, depMem[i]);
						 }
					 }

					 if(memsData.get(memIndex).married){
						 if(memsData.get(memIndex).jointTaxFiling){
							 int spouseIndex = Integer.parseInt(memsData.get(memIndex).spouseByIndex);
							 answerTaxHHSpouseMemberRelationship(memIndex, depMem[i], spouseIndex,priRelation, secRelation);
						 }
					 }
				 }
			}
				
			clickOnSaveAndContinueBtn();
		}
		
		for(int depIndex = 0; depIndex < memsData.size(); depIndex++){
			if(memsData.get(memIndex).dependentMembersByIndex.contains(Integer.toString(depIndex)) && memsData.get(depIndex).isU21){								
				if(ifMemberLivesWithTaxHHInd(depIndex)) {
					answerIfMemberLivesWithTaxHH(taxHHIndex, depIndex, memsData.get(memIndex).livingWith.get(depIndex - 1));
				}
				
				if(!memsData.get(memIndex).livingWith.get(depIndex - 1) || !memsData.get(memIndex).married){
					if(ifMemberLivesWithParentStepOtherThanTaxHHInd(depIndex)){
						answerIfMemberLivesWithParentStepOtherThanTaxHH(taxHHIndex, depIndex, false);
					}
				}
			}
		}
		
		if(taxHHBeClaimedAsDependentOnSomeOneElseITRInd(memIndex)){
			answerIfTaxHHBeClaimedAsDependentOnSomeOneElseITR_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).claimedAsDependentOnSomeOneElse);
		}
		
		evpdMoreSelectDetailsForTaxHH(memIndex,taxHHIndex);
	}

	public void racCompleteTellUsAboutYourHouseholdForTaxHH(List<RAC_MemData> memsData, int taxHHIndex, int memIndex) throws Exception {
		if(memsData.get(memIndex).isU18){
			answerIfTaxHHBeClaimedAsDependentOnSomeOneElseITR_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).claimedAsDependentOnSomeOneElse);
		}
		
		answerHHAgreeToFileITR(taxHHIndex, memIndex, memsData.get(memIndex).filingTaxes);
					
		if(hhLegallyMarriedInd(memIndex)){
			answerHHLegallyMarried(taxHHIndex, memIndex, memsData.get(memIndex).married);
		}						
			
		if(memsData.get(memIndex).married){
			if(memsData.get(memIndex).filingTaxes){
				answerHHFilingTaxJointly(taxHHIndex, memIndex, memsData.get(memIndex).jointTaxFiling);
			}
		
			if(memsData.get(memIndex).jointTaxFiling){
				answerWhoIsTaxHHSpouse_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).spouseByIndex);
			}else{
				answerTaxHHLiveWithSpouse_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).liveWithSpouse);
			
				if(memsData.get(memIndex).liveWithSpouse){
					answerWhoIsTaxHHSpouse_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).spouseByIndex);
				}
			}
		}
		
		if(memsData.get(memIndex).filingTaxes){
			answerIfTaxHHClaimAnyDependentOnTheirITR_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).claimAnyDependent);
			
			if(memsData.get(memIndex).claimAnyDependent){				
				answerWhoAllLiveWithMem(taxHHIndex, memIndex, memsData.get(memIndex).dependentMembersByIndex);
				clickOnSaveAndContinueBtn();
				
				String[] depArr = memsData.get(memIndex).dependentMembersByIndex.split(",");
				String relation = memsData.get(memIndex).relation.get(memIndex);
				
				 int depMem []= new int[10];
				 int depRel [] = new int[10];
				 
				 for(int i = 0; i < depArr.length ;i++){					
					 depMem[i]=Integer.parseInt(depArr[i]);
					 
					depRel[i] = depMem[i];
					 
					 String priRelation = memsData.get(memIndex).relation.get(depRel[i]-1);
					 System.out.println(priRelation);
					 
					 String secRelation = memsData.get(memIndex).secondaryRelation.get(depRel[i]-1);
					 System.out.println(secRelation);

					 answerTaxHHMemberRelationship(taxHHIndex, memIndex, depMem[i],priRelation, secRelation);
					 
					 if(IfLegallyMarriedYesNo(depMem[i])){
						 if(memsData.get(memIndex).married){
							 answerIfLegallyMarriedYes( memIndex, depMem[i]);
						 }else{
							 answerIfLegallyMarriedNo(memIndex, depMem[i]);
						 }
					 }

					 if(memsData.get(memIndex).married){
						 if(memsData.get(memIndex).jointTaxFiling){
							 int spouseIndex = Integer.parseInt(memsData.get(memIndex).spouseByIndex);
							 answerTaxHHSpouseMemberRelationship(memIndex, depMem[i], spouseIndex,priRelation, secRelation);
						 }
					 }
				 }
			}
				
			clickOnSaveAndContinueBtn();
		}
		
		for(int depIndex = 0; depIndex < memsData.size(); depIndex++){
			if(memsData.get(memIndex).dependentMembersByIndex.contains(Integer.toString(depIndex)) && memsData.get(depIndex).isU21){								
				if(ifMemberLivesWithTaxHHInd(depIndex)) {
					answerIfMemberLivesWithTaxHH(taxHHIndex, depIndex, memsData.get(memIndex).livingWith.get(depIndex - 1));
				}
				
				if(!memsData.get(memIndex).livingWith.get(depIndex - 1) || !memsData.get(memIndex).married){
					if(ifMemberLivesWithParentStepOtherThanTaxHHInd(depIndex)){
						answerIfMemberLivesWithParentStepOtherThanTaxHH(taxHHIndex, depIndex, false);
					}
				}
			}
		}
		
		if(taxHHBeClaimedAsDependentOnSomeOneElseITRInd(memIndex)){
			answerIfTaxHHBeClaimedAsDependentOnSomeOneElseITR_RdBtn(taxHHIndex, memIndex, memsData.get(memIndex).claimedAsDependentOnSomeOneElse);
		}
		
		evpdMoreSelectDetailsForTaxHH(memIndex,taxHHIndex);
	}

	
	public void evpdSelectDetailsForTaxHH(List<EVPD_MemData> memsData) throws Exception {
		List<Integer> memArray = new ArrayList<>();
		
		boolean hohInd = true;
		int taxHHCount = 0;
		
		for(int mCounter = 0; mCounter < memsData.size(); mCounter++){
			if(memsData.get(mCounter).taxHHMemIndex == 1){
				taxHHCount++;
			}
		}
		
		for(int taxHHIndex = 1; taxHHIndex <= taxHHCount; taxHHIndex++){
			int memIndex = 0;
			
			member:for(int mCounter = 1; mCounter < taxHHCount; mCounter++){
				if(hohInd){
					hohInd = false;
					memArray.add(memIndex);
					break member;
				}else{
					for(int memNo : memArray){
						if(memNo == 0){
							continue;				
						}else if(memNo == mCounter){
							continue member;
						}												
					}
					
					if(identifyMember(mCounter, memsData.get(mCounter).isU18)){
						memIndex = mCounter;
						memArray.add(memIndex);
						break member;						
					}
				}
			}
			
			for(int mCounter = 0; mCounter < memsData.size(); mCounter++){
				if(answerHHAgreeToFileITRInd(mCounter)|| taxHHBeClaimedAsDependentOnSomeOneElseITRInd(mCounter)){
					evpdCompleteTellUsAboutYourHouseholdForTaxHH(memsData, taxHHIndex, mCounter);
				}else{ 
					evpdMoreSelectDetailsForTaxHH(mCounter,taxHHIndex);
				}			
			}
			
			for(int memIndex1 = 0; memIndex1 < memsData.size(); memIndex1++){
				if(memsData.get(memIndex1).taxHHIndex == 1 || memsData.get(memIndex1).taxHHMemIndex != 0) //continue; 
					
				if(taxHH1IstheOfTaxHH2Ind((memsData.get(memIndex1).taxHHIndex))){
					selectTaxHH1IstheOfTaxHH2((memsData.get(memIndex1).taxHHIndex -1), (memsData.get(memIndex1).taxHHIndex), memsData.get(memIndex1).relation.get(memIndex1));
					selectTaxHH1LivesWithTaxHH2((memsData.get(memIndex1).taxHHIndex - 1), (memsData.get(memIndex1).taxHHIndex), memsData.get(memIndex1).livingWith.get(memIndex1));
				}
			}
			
			clickOnSaveAndContinueBtn();
		}
	}
	
	public void racSelectDetailsForTaxHH(List<RAC_MemData> memsData) throws Exception {
		List<Integer> memArray = new ArrayList<>();
		
		boolean hohInd = true;
		int taxHHCount = 0;
		
		for(int mCounter = 0; mCounter < memsData.size(); mCounter++){
			if(memsData.get(mCounter).taxHHMemIndex == 1){
				taxHHCount++;
			}
		}
		
		for(int taxHHIndex = 1; taxHHIndex <= taxHHCount; taxHHIndex++){
			int memIndex = 0;
			
			member:for(int mCounter = 1; mCounter < taxHHCount; mCounter++){
				if(hohInd){
					hohInd = false;
					memArray.add(memIndex);
					break member;
				}else{
					for(int memNo : memArray){
						if(memNo == 0){
							continue;				
						}else if(memNo == mCounter){
							continue member;
						}												
					}
					
					if(identifyMember(mCounter, memsData.get(mCounter).isU18)){
						memIndex = mCounter;
						memArray.add(memIndex);
						break member;						
					}
				}
			}
			
			for(int mCounter = 0; mCounter < memsData.size(); mCounter++){
				if(answerHHAgreeToFileITRInd(mCounter)|| taxHHBeClaimedAsDependentOnSomeOneElseITRInd(mCounter)){
					racCompleteTellUsAboutYourHouseholdForTaxHH(memsData, taxHHIndex, mCounter);
				}else{ 
					racMoreSelectDetailsForTaxHH(mCounter,taxHHIndex);
				}			
			}
			
			for(int memIndex1 = 0; memIndex1 < memsData.size(); memIndex1++){
				if(memsData.get(memIndex1).taxHHIndex == 1 || memsData.get(memIndex1).taxHHMemIndex != 0) //continue; 
					
				if(taxHH1IstheOfTaxHH2Ind((memsData.get(memIndex1).taxHHIndex))){
					selectTaxHH1IstheOfTaxHH2((memsData.get(memIndex1).taxHHIndex -1), (memsData.get(memIndex1).taxHHIndex), memsData.get(memIndex1).relation.get(memIndex1));
					selectTaxHH1LivesWithTaxHH2((memsData.get(memIndex1).taxHHIndex - 1), (memsData.get(memIndex1).taxHHIndex), memsData.get(memIndex1).livingWith.get(memIndex1));
				}
			}
			
			clickOnSaveAndContinueBtn();
		}
	}
	
}

	