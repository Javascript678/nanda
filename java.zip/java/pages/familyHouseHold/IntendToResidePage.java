package pages.familyHouseHold;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class IntendToResidePage extends CommonPage implements CommonPageOR {
	
	private static final By intendToResidePageHeader = By.xpath("//h1[contains(text(),'Intend To Reside')]");
	private static final By saveAndContinueBtn = By.id("otherAddressNextPage");
	
	public IntendToResidePage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("IntendToResidePageHeader", intendToResidePageHeader);
	}
	
	public void selectNoMemIntendToResideChkBx() throws Exception {
		By noMemIntendToResideChkBx = By.id("noneOfThese");
		clickOnElement("NoMemIntendToResideChkBx", noMemIntendToResideChkBx);
	}
	
	public void selectIntendToResideChkBxForMember(int memIndex) throws Exception {
		By memIntendToResideChkBx = By.id("eligibilityMember["+memIndex+"].userAttestedIntededToResideInState");
		clickOnElement("Mem"+(memIndex+1)+"IntendToResideChkBx", memIntendToResideChkBx);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}
	
	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void selectMembersIntendToResideOutsideMA(List<EVPD_MemData> memsData) throws Exception {
		boolean atleastOneMemberIntendToResideOutsideMA = false;	
		waitForPageLoaded();
		
		int memCount = memsData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			if(memsData.get(mCounter).intendToResideMA){
				selectIntendToResideChkBxForMember(mCounter);
				atleastOneMemberIntendToResideOutsideMA = true;
			}
		}
		
		if(!atleastOneMemberIntendToResideOutsideMA){
			selectNoMemIntendToResideChkBx();
		}
		clickOnSaveAndContinueBtn();
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdSelectMembersIntendToResideOutsideMA(List<EVPD_MemData> memsData) throws Exception {
		boolean atleastOneMemberIntendToResideOutsideMA = false;
		
		int memCount = memsData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			if(memsData.get(mCounter).intendToResideMA){
				selectIntendToResideChkBxForMember(mCounter);
				atleastOneMemberIntendToResideOutsideMA = true;
			}
		}
		
		if(!atleastOneMemberIntendToResideOutsideMA){
			selectNoMemIntendToResideChkBx();
		}
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void racSelectMembersIntendToResideOutsideMA(List<RAC_MemData> memsData) throws Exception {
		boolean atleastOneMemberIntendToResideOutsideMA = false;
		
		int memCount = memsData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			if(memsData.get(mCounter).intendToResideMA){
				selectIntendToResideChkBxForMember(mCounter);
				atleastOneMemberIntendToResideOutsideMA = true;
			}
		}
		
		if(!atleastOneMemberIntendToResideOutsideMA){
			selectNoMemIntendToResideChkBx();
		}
		clickOnSaveAndContinueBtn();
	}
}
