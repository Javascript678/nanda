package pages.familyHouseHold;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class ParentCaretakerRelativesPage extends CommonPage implements CommonPageOR {
	
	private static final By parentCaretakerPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Parent/Caretaker Relatives')]");
		
	public ParentCaretakerRelativesPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("ParentCaretakerPageHeader", parentCaretakerPageHeader);
	}
	

	public void selectIfMemLivingWithAtleastOneU19Child(int memIndex, boolean trueFalseValue) throws Exception {
		//IsMember1livingwithatleastonechildunder19	Xpath	//div[@id='CT1_0']/fieldset/div//input
		//IsMember2livingwithatleastonechildunder19	Xpath	//div[@id='CT1_1']/fieldset/div//input
		//By memlivingwithAtleast1ChildU19RdBtn	 = By.xpath("//div[@id='CT1_" + memIndex +"']/fieldset/div//input");
		By memlivingwithAtleast1ChildU19RdBtn	 = By.xpath("//div[@id='CT1_" + (memIndex) +"']//input[@type='radio' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem" + (memIndex+1) + "LivingwithAtleast1ChildU19RdBtn"+trueFalseValue , memlivingwithAtleast1ChildU19RdBtn);
	//selectByValue("Mem" + (memIndex+1) + "LivingwithAtleast1ChildU19RdBtn", memlivingwithAtleast1ChildU19RdBtn, trueFalseValue+"");
		
	}
	
	public void selectU19MemsLivingWithMember(int memIndex, String u19Mems) throws Exception {
		//MembersLiveWithMember1CheckBox	Xpath	//div[@id='CT2_0']/fieldset/div//input
		//MembersLiveWithMember2CheckBox	Xpath	//div[@id='CT2_1']/fieldset/div//input
		//By u19MembersLiveWithMemberCheckBox	 = By.xpath("//div[@id='CT2_" + (memIndex) +"']/fieldset/div//input");

		//selectByValue("U19MembersLiveWithMember"+(memIndex+1) + "CheckBox", u19MembersLiveWithMemberCheckBox, u19Mems);
		By u19MembersLiveWithMemberCheckBox	 = By.xpath("//div[@id='CT2_" + (memIndex) +"']//input[@type='checkbox' and @value='"+u19Mems+"']/../label");
		clickOnElement("U19MembersLiveWithMember"+(memIndex+1) + "CheckBox"+u19Mems , u19MembersLiveWithMemberCheckBox);
	}
	
	public void selectIfMemLivingWithTwoBirthOrAdoptiveParent(int memIndexOfParent, int memIndex, boolean trueFalseValue) throws Exception {
		/*By memlivingwithTwoBirthOrAdoptiveParentYesRdBtn	 = By.xpath("//div[@id='CT5_"+memIndexOfParent+"']/fieldset[1]/div/label[1]/input");
		By memlivingwithTwoBirthOrAdoptiveParentNoRdBtn	 = By.xpath("//div[@id='CT5_"+memIndexOfParent+"']/fieldset[1]/div/label[2]/input");*/
		
		//By memlivingwithTwoBirthOrAdoptiveParentYesRdBtn	 = By.id("CT5_"+memIndexOfParent+"_" +memIndex+"_1");
		By memlivingwithTwoBirthOrAdoptiveParentYesRdBtn	 = By.xpath("//label[@for='CT5_"+memIndexOfParent+"_" +memIndex+"_1']");
		By memlivingwithTwoBirthOrAdoptiveParentNoRdBtn	 = By.xpath("//label[@for='CT5_"+memIndexOfParent+"_" +memIndex+"_2']");
		//By memlivingwithTwoBirthOrAdoptiveParentNoRdBtn	 = By.id("CT5_"+memIndexOfParent+"_" +memIndex+"_2");
		
		if(trueFalseValue){
			clickOnElementThenWait("Mem"+(memIndex+1)+"livingwithTwoBirthParentYesRdBtn", memlivingwithTwoBirthOrAdoptiveParentYesRdBtn,1);
		}else{
			clickOnElementThenWait("Mem"+(memIndex+1)+"livingwithTwoBirthParentNoRdBtn", memlivingwithTwoBirthOrAdoptiveParentNoRdBtn,1);
		}
	}
	
	//Paul
	public void answerMemberRelationship(int memIndex, int depIndex,String relation)throws Exception {
		By relationShipDD = By.id("CT4_"+ memIndex + "_" + (depIndex));
		//selectDropDownElementByVisibleText("TaxHH" + (taxHHIndex+1) + "RelationShipWithMem" + (memberIndex+1), relationShipDD, relation);
		selectDropDownElementByVisibleText("Member" + (memIndex+1) + "RelationShipWithMem" + (depIndex+1), relationShipDD, relation);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElementAfterWait("SaveAndContinueBtn" , saveAndContinueBtn, 3);
		//clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}
	
	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception {
		//waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void completeParentCaretakerInfo(boolean faReqd, List<EVPD_MemData> memsData) throws Exception {
		if(faReqd){
			int memCount = memsData.size();
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(!memsData.get(mCounter).isU19){
					waitForPageLoaded();
					selectIfMemLivingWithAtleastOneU19Child(mCounter, memsData.get(mCounter).claimAnyDependentU19Member);
					clickOnSaveAndContinueBtn();
					
					if(memsData.get(mCounter).claimAnyDependentU19Member){
						selectU19MemsLivingWithMember(mCounter, memsData.get(mCounter).dependentU19MembersByIndex);
						clickOnSaveAndContinueBtn();
						
						String[] u19Dep = memsData.get(mCounter).dependentU19MembersByIndex.split(",");
						
						for(int i = 0; i < u19Dep.length; i++){
							selectIfMemLivingWithTwoBirthOrAdoptiveParent(mCounter, Integer.parseInt(u19Dep[i]), memsData.get(mCounter).liveWithSpouse);
							clickOnSaveAndContinueBtn();
						}
					}
				}
			}
		}
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		//waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdCompleteParentCaretakerInfo(boolean faReqd, List<EVPD_MemData> memsData) throws Exception {
		if(faReqd){
			int memCount = memsData.size();
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(!memsData.get(mCounter).isU19){
					selectIfMemLivingWithAtleastOneU19Child(mCounter, memsData.get(mCounter).claimAnyDependentU19Member);
					
					if(memsData.get(mCounter).claimAnyDependentU19Member){
						memsData.get(mCounter).isParent = true;
					}else{
						memsData.get(mCounter).isParent = false;
					}
					
					if(!memsData.get(mCounter).claimAnyDependentU19Member){ clickOnSaveAndContinueBtn(); };
					
					if(memsData.get(mCounter).claimAnyDependentU19Member){
						for(int i = 0; i < memsData.get(mCounter).dependentU19MembersByIndex.split(",").length; i++){
							selectU19MemsLivingWithMember(mCounter, memsData.get(mCounter).dependentU19MembersByIndex.split(",")[i]);
						}
						
						clickOnSaveAndContinueBtn();
						
						String[] u19Dep = memsData.get(mCounter).dependentU19MembersByIndex.split(",");
						
						for(int i = 0; i < u19Dep.length; i++){
							selectIfMemLivingWithTwoBirthOrAdoptiveParent(mCounter, Integer.parseInt(u19Dep[i]), memsData.get(mCounter).liveWithSpouse);
							clickOnSaveAndContinueBtn();
						}
					}
				}
			}
		}
	}
	
	// ppinho
	public void racCompleteParentCaretakerInfo(boolean faReqd, List<RAC_MemData> memsData) throws Exception {
		if(faReqd){
			int memCount = memsData.size();
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(!memsData.get(mCounter).isU19){
					selectIfMemLivingWithAtleastOneU19Child(mCounter, memsData.get(mCounter).claimAnyDependentU19Member);
					memsData.get(mCounter).isParent = true;
					
					if(!memsData.get(mCounter).claimAnyDependentU19Member){ clickOnSaveAndContinueBtn(); };
					
					if(memsData.get(mCounter).claimAnyDependentU19Member){
						selectU19MemsLivingWithMember(mCounter, memsData.get(mCounter).dependentU19MembersByIndex);
						clickOnSaveAndContinueBtn();
						
						String[] u19Dep = memsData.get(mCounter).dependentU19MembersByIndex.split(",");
						
						for(int i = 0; i < u19Dep.length; i++){
							selectIfMemLivingWithTwoBirthOrAdoptiveParent(mCounter, Integer.parseInt(u19Dep[i]), memsData.get(mCounter).liveWithSpouse);
							clickOnSaveAndContinueBtn();
						}
					}
				}
			}
		}
	}
}
