package pages.familyHouseHold;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import enums.Relationship;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class EnterHHMemRelationshipPage extends CommonPage implements CommonPageOR {

	private static final By enterHHRelationshipPageHeader = By.xpath("//h1[contains(text(),'Enter Household Members Relationships')]");

	public EnterHHMemRelationshipPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private boolean errorWarnMessageInd() throws Exception {
		By errorWarnMessageInd = By.xpath("//div[@id ='errorWarnholder']");
		return isElementPresent(errorWarnMessageInd, 5);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("EnterHHRelationshipPageHeader", enterHHRelationshipPageHeader);
	}

	public void selectMemsRelationship(int mem1Index, int mem2Index, String relationship) throws Exception {
		By relationshipDD = By.name("eligibilityMember[" + mem1Index + "].medicaidMemberRelationships[" + mem2Index + "].medicaidRelationship");

		if (relationship.equals(Relationship.DOMESTIC_PARTNER.dropDownVal)) {
			selectDropDownByValue("M" + (mem1Index + 1) + "_M" + (mem2Index + 1) + "_RelationshipDD", relationshipDD, "8");
		}
		// Neel
		else if (relationship.equals(Relationship.SIBLING_STEP_SIBLING.dropDownVal)) {
			String relation = "Sibling/stepsibling";
			selectDropDownElementByVisibleText("M" + (mem1Index + 1) + "_M" + (mem2Index + 1) + "_RelationshipDD", relationshipDD, relation);
		} else if (relationship.equals(Relationship.OTHER_UNRELATED.dropDownVal)) {
			String othrrelation = "Unrelated";
			selectDropDownElementByVisibleText("M" + (mem1Index + 1) + "_M" + (mem2Index + 1) + "_RelationshipDD", relationshipDD, othrrelation);
		} else {
			selectDropDownElementByVisibleText("M" + (mem1Index + 1) + "_M" + (mem2Index + 1) + "_RelationshipDD", relationshipDD, relationship);
		}

		if (errorWarnMessageInd()) clickOnSaveAndContinueBtn();
	}

	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn, 1);
	}

	public void selectMemsRelationship(List<EVPD_MemData> memsData) throws Exception {
		int memCount = memsData.size();

		for (int m1Counter = 0; m1Counter < memCount - 1; m1Counter++) {
			// waitForPageLoaded();

			for (int m2Counter = m1Counter + 1; m2Counter < memCount; m2Counter++) {
				switch (m2Counter) {
				case 0:
					selectMemsRelationship(m1Counter, m2Counter, memsData.get(m1Counter).relationWithM1);
					break;
				case 1:
					selectMemsRelationship(m1Counter, m2Counter, memsData.get(m1Counter).relationWithM2);
					break;
				case 2:
					selectMemsRelationship(m1Counter, m2Counter, memsData.get(m1Counter).relationWithM3);
					break;
				case 3:
					selectMemsRelationship(m1Counter, m2Counter, memsData.get(m1Counter).relationWithM4);
					break;
				case 4:
					selectMemsRelationship(m1Counter, m2Counter, memsData.get(m1Counter).relationWithM5);
					break;
				}
			}

			clickOnSaveAndContinueBtn();
		}

	}

	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}

	// ppinho
	public void evpdSelectMemsRelationship(List<EVPD_MemData> memsData) throws Exception {
		int memCount = memsData.size();

		for (int m1Counter = 0; m1Counter < memCount - 1; m1Counter++) {
			for (int m2Counter = 0; m2Counter < memCount; m2Counter++) {
				if (m1Counter == m2Counter) continue;
				if (m1Counter > m2Counter) continue;

				if (memsData.get(m1Counter).relation.get(m2Counter - 1).equals(Relationship.OTHER_UNRELATED.dropDownVal)) {
					selectMemsRelationship(m1Counter, m2Counter, memsData.get(m1Counter).secondaryRelation.get(m2Counter - 1));
				} else {
					selectMemsRelationship(m1Counter, m2Counter, memsData.get(m1Counter).relation.get(m2Counter - 1));
				}
			}
			
			clickOnSaveAndContinueBtn();
		}
	}
	
	// ppinho
	public void racSelectMemsRelationship(List<RAC_MemData> memsData) throws Exception {
		int memCount = memsData.size();

		for (int m1Counter = 0; m1Counter < memCount - 1; m1Counter++) {
			for (int m2Counter = 0; m2Counter < memCount; m2Counter++) {
				if (m1Counter == m2Counter) continue;
				if (m1Counter > m2Counter) continue;

				if (memsData.get(m1Counter).relation.get(m2Counter - 1).equals(Relationship.OTHER_UNRELATED.dropDownVal)) {
					selectMemsRelationship(m1Counter, m2Counter, memsData.get(m1Counter).secondaryRelation.get(m2Counter - 1));
				} else {
					selectMemsRelationship(m1Counter, m2Counter, memsData.get(m1Counter).relation.get(m2Counter - 1));
				}
			}
			
			clickOnSaveAndContinueBtn();
		}
	}
}
