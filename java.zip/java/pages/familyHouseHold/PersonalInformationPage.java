package pages.familyHouseHold;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_Data;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;


/**
 * 
 * @author Vinay Kumar
 *
 */
public class PersonalInformationPage extends CommonPage implements CommonPageOR {

	private static final By personalInfoPageHeader = By.xpath("//h1[contains(text(),'Personal Information')]");
	private static final By socialScrtNumInvalidErrorText = By.xpath("//a[contains(text(),'Enter a valid Social Security Number')]");
	
	private By memSSNTxt = By.id("ssn");

	public PersonalInformationPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("PersonalInfoPageHeader", personalInfoPageHeader);
	}
	
	public void waitForPageLoaded(int memIndex) throws Exception {
		By memGenderRdBtn = By.name("eligibilityMember[" + memIndex + "].gender");
		waitForPresenceOfElementLocated("PersonalInfoPageHeader", memGenderRdBtn);
	}
	
	public void validatePageTitleDontContainsName(String fullName) throws Exception {
		String actualTitle = getCurrentPageTitle();
		validateTextNotContains("PersonalInfoPageTitle", actualTitle, fullName);
	}

	public void selectMemGender(int memIndex, String gender) throws Exception {
		//By memGenderRdBtn = By.name("eligibilityMember[" + memIndex + "].gender");
		By memGenderRdBtn= By.xpath("//input[@type='radio' and @value='"+gender+"']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "GenderRdBtn", memGenderRdBtn);
	}

	public void selectIfMemHasSSN(int memIndex, boolean ssnStatus) throws Exception {
		//By memSSNRdBtn = By.name("eligibilityMember[" + memIndex + "].socialSecurityCard.hasSsn");
		By memSSNRdBtn = By.xpath("//input[@type='radio' and @value='"+ssnStatus+"']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "SSNRdBtn", memSSNRdBtn);
	}
	
	public void enterSSN(int memIndex, String ssn) throws Exception {
		clearAndType("Mem" + (memIndex + 1) + "SSNTxt", memSSNTxt, ssn);
	}

	//Ritika
	public String  getUserProfileSSN() throws Exception{
		return getElementAttribute("SSNTxt" , memSSNTxt, "value");
	}
	
	//Ritika
	public void  validateUserProfileSSNIsMasked(int memIndex) throws Exception{ 
		String ssn = getUserProfileSSN();
		By ssnTxt = By.name("eligibilityMember["+memIndex+"].socialSecurityCard.ssn");
		validateElementAttribute("SSNTxt", ssnTxt,"type", "hidden");
	}
	
	public void selectIfMemNameSameAsONSSNCardRdBtn(int memIndex, boolean trueFalseValue) throws Exception {
		//By memNameSameOnSsnCardRdBtn = By.name("eligibilityMember[" + memIndex + "].socialSecurityCard.nameSameOnSsnCard");
		By memNameSameOnSsnCardRdBtn = By.xpath("//div[@class='form-group sameNameDiv']//input[@type='radio' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "NameSameOnSsnCardRdBtn", memNameSameOnSsnCardRdBtn);
	}

	public void selectIfMemWantToProvideSSN(int memIndex, boolean wantToProvideSSN) throws Exception {
		By doesMemWantToProvideSSNNoRdBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].socialSecurityCard.isSSNProvided' and @value='" + wantToProvideSSN + "']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "WantToProvideSSNRdBtn", doesMemWantToProvideSSNNoRdBtn);
	}

	public void selectMemNoSSNReason(int memIndex, String reason) throws Exception {
		By memNoSSNExplainationDD = By.name("eligibilityMember[" + memIndex + "].socialSecurityCard.noSsnExplanation");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "SSNExplainationDD", memNoSSNExplainationDD,
				reason);
	}

	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}

	public void pageLoadThenClickOnSaveAndContinueBtn(int memIndex) throws Exception {
		waitForPageLoaded(memIndex);
		clickOnSaveAndContinueBtn();
	}
	
	public void pageLoadValidateSSNIsMaskedThenClickOnSaveAndContinueBtn(int memIndex) throws Exception {
		waitForPageLoaded(memIndex);
		takeScreenshot("PersonalInfoPageForMember"+(memIndex+1));
		validateUserProfileSSNIsMasked(memIndex);
		clickOnSaveAndContinueBtn();
	}

	public void enterMemPersonalInfo(String whoIsApplying, List<EVPD_MemData> memsData) throws Exception {
		int memCount = memsData.size();
		waitForPageLoaded();
		
		for(int memberCounter = 0; memberCounter < memCount; memberCounter++){
			selectMemGender(memberCounter, memsData.get(memberCounter).gender);
			selectIfMemHasSSN(memberCounter, memsData.get(memberCounter).hasSSN);

			if(memsData.get(memberCounter).hasSSN){
				if (whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code) && memberCounter == 0) {
					selectIfMemWantToProvideSSN(memberCounter, memsData.get(memberCounter).wantToProvideSSN);
				}
			
				enterSSN(memberCounter, memsData.get(memberCounter).ssn);
				selectIfMemNameSameAsONSSNCardRdBtn(memberCounter, memsData.get(memberCounter).nameSameAsOnSSN);
				clickOnSaveAndContinueBtn();
				
				/*if(isElementPresent(socialScrtNumInvalidErrorText)){
					long ssnNo = Long.parseLong(memsData.get(memberCounter).ssn) + 1;
					enterSSN(memberCounter, ssnNo + "");
					selectIfMemNameSameAsONSSNCardRdBtn(memberCounter, memsData.get(memberCounter).nameSameAsOnSSN);
					clickOnSaveAndContinueBtn();
				}*/
			}else if(memsData.get(memberCounter).hasSSN == false){
				selectMemNoSSNReason(memberCounter, memsData.get(memberCounter).noSSNReason);
				clickOnSaveAndContinueBtn();
			}
		}
	}
	
	public void evpdEnterMemPersonalInfo(int memIndex, EVPD_Data evpdData) throws Exception {
		selectMemGender(memIndex, evpdData.memsData.get(memIndex).gender);
		selectIfMemHasSSN(memIndex, evpdData.memsData.get(memIndex).hasSSN);

		if(evpdData.memsData.get(memIndex).hasSSN){
			if (evpdData.whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code) && memIndex == 0) {
				selectIfMemWantToProvideSSN(memIndex, evpdData.memsData.get(memIndex).wantToProvideSSN);
			}
			
			enterSSN(memIndex, evpdData.memsData.get(memIndex).ssn);
			selectIfMemNameSameAsONSSNCardRdBtn(memIndex, evpdData.memsData.get(memIndex).nameSameAsOnSSN);
			clickOnSaveAndContinueBtn();
				
			/*if(isElementPresent(socialScrtNumInvalidErrorText)){
				long ssnNo = Long.parseLong(memsData.get(memberCounter).ssn) + 1;
				enterSSN(memberCounter, ssnNo + "");
				selectIfMemNameSameAsONSSNCardRdBtn(memberCounter, memsData.get(memberCounter).nameSameAsOnSSN);
				clickOnSaveAndContinueBtn();
			}*/
		}else if(evpdData.memsData.get(memIndex).hasSSN == false){
			selectMemNoSSNReason(memIndex, evpdData.memsData.get(memIndex).noSSNReason);
			clickOnSaveAndContinueBtn();
		}
	}

	public void racEnterMemPersonalInfo(int memIndex, RAC_Data evpdData) throws Exception {
		selectMemGender(memIndex, evpdData.memsData.get(memIndex).gender);
		selectIfMemHasSSN(memIndex, evpdData.memsData.get(memIndex).hasSSN);

		if(evpdData.memsData.get(memIndex).hasSSN){
			if (evpdData.whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code) && memIndex == 0) {
				selectIfMemWantToProvideSSN(memIndex, evpdData.memsData.get(memIndex).wantToProvideSSN);
			}
			
			enterSSN(memIndex, evpdData.memsData.get(memIndex).ssn);
			selectIfMemNameSameAsONSSNCardRdBtn(memIndex, evpdData.memsData.get(memIndex).nameSameAsOnSSN);
			clickOnSaveAndContinueBtn();
				
			/*if(isElementPresent(socialScrtNumInvalidErrorText)){
				long ssnNo = Long.parseLong(memsData.get(memberCounter).ssn) + 1;
				enterSSN(memberCounter, ssnNo + "");
				selectIfMemNameSameAsONSSNCardRdBtn(memberCounter, memsData.get(memberCounter).nameSameAsOnSSN);
				clickOnSaveAndContinueBtn();
			}*/
		}else if(evpdData.memsData.get(memIndex).hasSSN == false){
			selectMemNoSSNReason(memIndex, evpdData.memsData.get(memIndex).noSSNReason);
			clickOnSaveAndContinueBtn();
		}
	}
	
}
