package pages.familyHouseHold;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class ReasonableAccomPage extends CommonPage implements CommonPageOR{
	
	private static final By reasonableAccPageHeader = By.xpath("//h1[contains(text(),'Reasonable Accommodation')]");
	private static final By requireSpecialAccomRdBtn = By.name("requireSpecialAccomodation");

	public ReasonableAccomPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("ReasonableAccPageHeader", reasonableAccPageHeader);
	}
	
	public void selectIfMemberRequireSpecialAccomodation(boolean trueFalseValue) throws Exception{
		selectByAttributeNameUsingJS("RequireSpecialAccomRdBtn", requireSpecialAccomRdBtn, "value", trueFalseValue+"");
	}
	
	public void selectSpecialAccomForMember(int memIndex) throws Exception{
		By MemNeededSpecialAccChkBox	= By.id("specialAccomodations["+memIndex+"].requireSpecialAccommodation");
		clickOnElement("Mem"+(memIndex+1)+"NeededSpecialAccChkBox" , MemNeededSpecialAccChkBox);
	}
	
	public void selectSpecialAccomDisabilityDetailForMember(int memIndex) throws Exception{
		By MemSpecialAccDisabilityDetailChkBox	= By.id("specialAccomodations"+memIndex+".accomodationDisabilityDetails6");
		clickOnElement("Mem"+(memIndex+1)+"SpecialAccDisabilityDetailChkBox" , MemSpecialAccDisabilityDetailChkBox);
	}
	
	public void selectTypeOfCondition(int memIndex, String typeOfCondition) throws Exception {
		By typeOfConditionCheckBox = By.name("specialAccomodations["+memIndex+"].accomodationDisabilityDetails");
		selectByValue("TypeOfConditionCheckBox", typeOfConditionCheckBox, typeOfCondition);
	}
	
	public void selectSpecialAccomTypeForMember(int memIndex, String accType) throws Exception{
		By MemSpecialAccTypeChkBox	= By.name("specialAccomodations["+memIndex+"].accomodationCommDetails");
		selectByValue("Mem"+(memIndex+1)+"SpecialAccTypeChkBox" , MemSpecialAccTypeChkBox, accType);
		
		// updated by ppinho   Commenting it as Ritu's Test case were failing.
		//By memSpecialAccTypeChkBox	= By.xpath("//*[@name='specialAccomodations["+(memIndex)+"].accomodationCommDetails']/../label[contains(text(),'"+(accType)+"')]");
		//clickOnElement("Mem"+(memIndex+1)+"SpecialAccTypeChkBox" , memSpecialAccTypeChkBox);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void completeResonableAccForMembers(List<EVPD_MemData> memsData) throws Exception {
		boolean AtleastOneMemReqdReasonableAcc = false;
		waitForPageLoaded();
		
		int memCount = memsData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			if(memsData.get(mCounter).resonableAccNeeded){
				AtleastOneMemReqdReasonableAcc = true;
				break;
			}
		}
		
		if(AtleastOneMemReqdReasonableAcc){
			selectIfMemberRequireSpecialAccomodation(true);
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(memsData.get(mCounter).resonableAccNeeded){
					selectSpecialAccomForMember(mCounter);
					selectSpecialAccomDisabilityDetailForMember(mCounter);
					selectSpecialAccomTypeForMember(mCounter, memsData.get(mCounter).resonableAccType);
				}
			}
		}
		clickOnSaveAndContinueBtn();
	}
	
	public void completeReasonableAccForMembers(int memIndex, String typeOfCondition,String resonableAccType) throws Exception{
		selectIfMemberRequireSpecialAccomodation(true);
		selectSpecialAccomForMember(memIndex);
		selectTypeOfCondition(memIndex, typeOfCondition);
		selectSpecialAccomTypeForMember(memIndex, resonableAccType);
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdCompleteResonableAccForMembers(List<EVPD_MemData> memsData) throws Exception {
		boolean AtleastOneMemReqdReasonableAcc = false;
		
		int memCount = memsData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			if(memsData.get(mCounter).resonableAccNeeded){
				AtleastOneMemReqdReasonableAcc = true;
				break;
			}
		}
		
		if(AtleastOneMemReqdReasonableAcc){
			selectIfMemberRequireSpecialAccomodation(true);
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(memsData.get(mCounter).resonableAccNeeded){
					selectSpecialAccomForMember(mCounter);
					selectSpecialAccomDisabilityDetailForMember(mCounter);
					selectSpecialAccomTypeForMember(mCounter, memsData.get(mCounter).resonableAccType);
				}
			}
		}
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void racCompleteResonableAccForMembers(List<RAC_MemData> memsData) throws Exception {
		boolean AtleastOneMemReqdReasonableAcc = false;
		
		int memCount = memsData.size();
		
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			if(memsData.get(mCounter).resonableAccNeeded){
				AtleastOneMemReqdReasonableAcc = true;
				break;
			}
		}
		
		if(AtleastOneMemReqdReasonableAcc){
			selectIfMemberRequireSpecialAccomodation(true);
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(memsData.get(mCounter).resonableAccNeeded){
					selectSpecialAccomForMember(mCounter);
					selectSpecialAccomDisabilityDetailForMember(mCounter);
					selectSpecialAccomTypeForMember(mCounter, memsData.get(mCounter).resonableAccType);
				}
			}
		}
		clickOnSaveAndContinueBtn();
	}
}
