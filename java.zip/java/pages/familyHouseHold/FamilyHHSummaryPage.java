package pages.familyHouseHold;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class FamilyHHSummaryPage extends CommonPage implements CommonPageOR{
	
	private static final By familyHHSummaryPageHeader = By.xpath("//h1[contains(text(),'Family & Household Summary')]");
	private static final By continueApplicationBtn = By.xpath("//div[contains(@class,'ui-dialog') and contains(@style,'display: block;')]//span[text()='Continue Application']/..");
	
	public FamilyHHSummaryPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("familyHHSummaryPageHeader", familyHHSummaryPageHeader,5);
	}
	
	//Shailza
	public void validateSSNIsMaskedForMember(int memIndex) throws Exception{
		By SSNLabel = By.xpath("//div[@id='shousehold_review_details']//div[2]/ul["+(memIndex+1)+"]/li[contains(.,'Social Security Number:')]");
		String ssn = getElementText("Mem"+(memIndex+1)+"SSN", SSNLabel);
		System.out.println("SSN Displayed On UI Is [" + ssn +"]");
		takeScreenshot();
	}
	
	//Shailza
	public void validateIfMemberIsApplyingForCoverage(int memIndex, String applyingForCoverage) throws Exception{
		By applyingForCoverageLabel = By.xpath("//div[@id='shousehold_review_details']//div[2]/ul["+(memIndex+1)+"]/li[contains(.,'Applying for coverage:')]");
		validateTextEquals("Mem"+(memIndex+1)+"Applying For Coverage", applyingForCoverageLabel, "Applying for coverage: "+applyingForCoverage);
	}
	
	//Shailza
	public void validateIfMemberIsIncarcerated(int memIndex, String memberIncarcerated) throws Exception{
		By memberIncarceratedLabel = By.xpath("//div[@id='shousehold_review_details']//div[2]/ul["+(memIndex+1)+"]/li[contains(.,'Incarcerated:')]");
		validateTextEquals("Mem"+(memIndex+1)+"Incarcerated", memberIncarceratedLabel, "Incarcerated: "+memberIncarcerated);
	}
	
	//Shailza
	public void validateMemberRelationShipWithTaxHH(int TaxHHIndex,int memIndex, String relationship) throws Exception{
		By memberRelationShipLabel = By.xpath("//div[@id='shousehold_review_details']//div[2]/ul["+(memIndex+1)+"]/li[contains(.,'Relationship to')]");
		validateTextContains("Mem"+(memIndex+1)+"MemberRelationShipWithTaxHH", memberRelationShipLabel, relationship);
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}
	
	private boolean isContinueApplicationBtnPresent() throws Exception{
		return isElementPresent(continueApplicationBtn);
	}
	
	private void clickOnContinueApplicationBtn() throws Exception{
		clickOnElementAfterWait("ContinueApplicationBtn" , continueApplicationBtn,5);
	}
	
	//Paul
	public void clickOnDuplicateWarningPopUpBtn() throws Exception{
		By dupWarningDD = By.xpath("//html/body/div[8]/div[3]/div/button/span");		
		clickOnElement("DupWarningBtn", dupWarningDD);
		waitForPageLoaded();
	}
	
	public void takeScreenshot() throws Exception{
		takeScreenshot("Summary");
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		takeScreenshot();
		clickOnSaveAndContinueBtn();
	}
	
	public void pageLoadThenClickOnSaveAndContinueAndHandleContinueAppIssue() throws Exception{
		//waitForPageLoaded();
		takeScreenshot();
		clickOnSaveAndContinueBtn();
		
		if(isContinueApplicationBtnPresent()){
			clickOnContinueApplicationBtn();
		}
	}
	
	// ppinho
	public void evpdClickOnSaveAndContinueAndHandleContinueAppIssue() throws Exception{
		takeScreenshot();
		clickOnSaveAndContinueBtn();
		
		if(isContinueApplicationBtnPresent()){
			clickOnContinueApplicationBtn();
		}
	}
	
	// ppinho
	public void racClickOnSaveAndContinueAndHandleContinueAppIssue() throws Exception{
		takeScreenshot();
		clickOnSaveAndContinueBtn();
		
		if(isContinueApplicationBtnPresent()){
			clickOnContinueApplicationBtn();
		}
	}
}
