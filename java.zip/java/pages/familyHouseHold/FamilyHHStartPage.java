package pages.familyHouseHold;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class FamilyHHStartPage extends CommonPage implements CommonPageOR{
	
	private static final By fmlyHshldStartPageHeader = By.xpath("//h1[contains(text(),'Family & Household')]");
		
	public FamilyHHStartPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("FmlyHshldStartPageHeader", fmlyHshldStartPageHeader);
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		//waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdClickOnSaveAndContinueBtn() throws Exception{
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void racClickOnSaveAndContinueBtn() throws Exception{
		clickOnSaveAndContinueBtn();
	}
	
}
