package pages.familyHouseHold;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class PastTaxCreditPage extends CommonPage implements CommonPageOR {
	
	private static final By postTaxCreditPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Past Tax Credits')]");
		
	public PastTaxCreditPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("PostTaxCreditPageHeader", postTaxCreditPageHeader);
	}
	
	public void selectPastTaxCreditForHouseHold(int hhIndex) throws Exception {
		By hhCheckBox = By.name("taxHouseholds[" + hhIndex + "].attested");
		clickOnElement("HH" + (hhIndex + 1) + "CheckBx", hhCheckBox);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
			//waitForPageLoaded();
			clickOnSaveAndContinueBtn();
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn(boolean faReqd, boolean isMem1FilingTaxes) throws Exception {
		if(faReqd == true && isMem1FilingTaxes == true){
			//waitForPageLoaded();
			clickOnSaveAndContinueBtn();
		}		
	}
	
	// ppinho
	public void evpdClickOnSaveAndContinueBtn(boolean faReqd, boolean isMem1FilingTaxes) throws Exception {
		if(faReqd == true){
			clickOnSaveAndContinueBtn();
		}		
	}
	
	// ppinho
	public void racClickOnSaveAndContinueBtn(boolean faReqd, boolean isMem1FilingTaxes) throws Exception {
		if(faReqd == true){
			clickOnSaveAndContinueBtn();
		}		
	}
}
