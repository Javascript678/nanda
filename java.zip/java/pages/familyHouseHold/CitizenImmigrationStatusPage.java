package pages.familyHouseHold;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_Data;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import utils.StubLogic;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class CitizenImmigrationStatusPage extends CommonPage implements CommonPageOR{
	
	private static final By citizenImmigrationStatusPage = By.xpath("//h1[contains(text(),'Citizenship/Immigration Status')]");
	private static final By immigrationChkBox = By.id("checkImmigrationStatus");
	//private static final By reEntryPermitI327RdBtn = By.xpath("//div[@id='immigrationDocumentDialog']/label[contains(text()[normalize-space()],'Reentry Permit')]/input[@type='radio']");
	private static final By alientNoTxt = By.xpath("//div[@id='immigrationDocumentAttributesDialog']//div[contains(@class,'input-group')]/input");
	//private static final By memNameSameAsAppearRdBtn = By.xpath("//div[@class='sameName']//div[@class='radioGroup']/span/input");
	
	//Shailza
	private static final By permanentResidentCardI551RdBtn = By.xpath("//div[@id='immigrationDocumentDialog']/label[contains(text()[normalize-space()],' Permanent Resident Card')]/input[@type='radio']");
	//Shailza
	private static final By recipientNoTxt = By.xpath("//div[@id='immigrationDocumentAttributesDialog']//div/input[contains(@class,'ReceiptNumber')]");


	public CitizenImmigrationStatusPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("CitizenImmigrationStatusPage", citizenImmigrationStatusPage);
	}
	
	public void waitForPageLoaded(int memIndex) throws Exception{
		By memUSCitizenRdBtn  = By.name("eligibilityMember[" + memIndex + "].citizenship.isUSCitizen");
		waitForPresenceOfElementLocated("CitizenImmigrationStatusPage", memUSCitizenRdBtn);
	}
	
	public void validatePageTitleDontContainsName(String fullName) throws Exception {
		String actualTitle = getCurrentPageTitle();
		validateTextNotContains("CitiImmStatusPageTitle", actualTitle, fullName);
	}
	
	public void selectIfMemIsUSCitizen(int memIndex, boolean trueFalseValue) throws Exception{
		//By memUSCitizenRdBtn  = By.name("eligibilityMember[" + memIndex + "].citizenship.isUSCitizen");
		By memUSCitizenRdBtn  = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].citizenship.isUSCitizen' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem" + (memIndex+1) + "USCitizenRdBtn", memUSCitizenRdBtn);
	}

	public void selectIfMemIsNaturalizedCitizen(int memIndex, boolean trueFalseValue) throws Exception{
		//By memNaturalCitizenRdBtn  = By.name("eligibilityMember[" + memIndex + "].citizenship.isNaturializedCitizen");
		By memNaturalCitizenRdBtn  = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].citizenship.isNaturializedCitizen' and @value='"+trueFalseValue+"']/../label");
		//selectByValue("Mem" + (memIndex+1) + "NaturalCitizenRdBtn", memNaturalCitizenRdBtn, trueFalseValue+"");
		clickOnElement("Mem" + (memIndex+1) + "NaturalCitizenRdBtn", memNaturalCitizenRdBtn);
	}
	
	public void selectDocTypeForNaturalizedCitizen() throws Exception{
		By naturalizationCertificateRdBtn  = By.xpath("//div[@id='naturalizationDocumentDialog']/div/input[@id=1]");
		By dontHaveCheckBox1  = By.id("certificateCheck1");
		clickOnElementThenWait("NaturalizationCertificate" , naturalizationCertificateRdBtn,1);
		clickOnElementThenWait("NaturalizationCertificate" , dontHaveCheckBox1,1);
	}

	public void selectIfMemIsVeteran(int memIndex, boolean trueFalseValue) throws Exception{
		By memVeteranRdBtn  =	 By.xpath("//input[@name='eligibilityMember[" + memIndex + "].isVeteran' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem" + (memIndex+1) + "VeteranRdBtn", memVeteranRdBtn);
	}
	
	public void clickOnImmigrationCheckBox() throws Exception{
		clickOnElement("ImmigrationChkBox" , immigrationChkBox);
	}
	public void clickOnReEntryPermitI327RdBtn(int memno) throws Exception{
		By reEntryPermitI327RdBtn = By.xpath("//label[@for='eligibilityMember["+memno+"].memberDocuments[1].documentType.3']");
		clickOnElement("ReEntryPermitI327RdBtn" , reEntryPermitI327RdBtn);
	}
	
	public void enterAlienNo(String alientNo) throws Exception{
		clearAndType("AlientNoTxt" , alientNoTxt, alientNo);
	}
	
	//Shailza
    public void clickOnPermanentResidentCardI551RdBtn() throws Exception{
          clickOnElement("PermanentResidentCardI551RdBtn" , permanentResidentCardI551RdBtn);
    }

    //Shailza
    public void enterReceiptCardNumber(String receiptCardNumber) throws Exception{
          clearAndType("ReceiptCardNumberTxt" , recipientNoTxt, receiptCardNumber);
    }

    public void selectIfMemNameSameAsAppearOnSSN(int memIndex,boolean trueFalseValue) throws Exception{
		By memNameSameAsAppearRdBtn= By.xpath("//input[@type='radio' and @value='"+trueFalseValue+"']/../label[contains(@for,'eligibilityMember"+memIndex+".memberDocuments1.nameMatches')]");
		clickOnElement("memNameSameAsAppearRdBtn"+trueFalseValue, memNameSameAsAppearRdBtn);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn" , saveAndContinueBtn);
	}
	
	public void clickOnWarningPopUpOKBtn() throws Exception{
		clickOnElement("WarningPopupOkBtn" , warningOkButton);
	}
	
	public void clickOnVeriyMannualBtn() throws Exception{
		clickOnElement("VerifyManualBtn" , verifyManualBtn);
	}
	
	public void selectIfMemArriveInUSAfter1960(int memIndex, boolean trueFalseValue) throws Exception{
		By memArriveInUSAfter1996RdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].citizenship.isLivedInUS' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem"+(memIndex+1) + "ArriveInUSAfter1996RdBtn", memArriveInUSAfter1996RdBtn);
	}
	
	public void selectImmStatusForMember(int memIndex, int vlpErrorimmIndex) throws Exception{
		By memImmStatusRadioBtn	=	By.xpath("//input[@name='eligibilityMember["+memIndex+"].citizenship.vlpErrorImmigrationStatus' and @value='"+vlpErrorimmIndex+"']/../label");
		clickOnElement("Mem"+(memIndex+1)+"ImmStatusRadioBtn" , memImmStatusRadioBtn);
	}
	
	public void enterCitizenStatusAwardDateForMemo(int memIndex, String awardDate) throws Exception{
		By memCitiStatusAwardDate	= By.name("eligibilityMember["+memIndex+ "].citizenship.statusAwardDate");
		clearAndTypeAfterWait("Mem"+(memIndex+1)+"CitiStatusAwardDate" , memCitiStatusAwardDate, awardDate);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn(int memIndex) throws Exception{
		waitForPageLoaded(memIndex);
		clickOnSaveAndContinueBtn();
	}
	
	// added by ppinho
	public void pageLoadThenClickOnContinueWithManualVerificationBtn() throws Exception{
		waitForPageLoaded();
		clickOnVeriyMannualBtn();
	}
		
	// added by ppinho
	public void pageLoadThenClickOnContinueWithManualVerificationBtn(int memIndex) throws Exception{
		waitForPageLoaded(memIndex);
		clickOnVeriyMannualBtn();
	}

	
	public void selectImmigartionStatusForMember(String whoIsApplying, List<EVPD_MemData> memsData) throws Exception {
		int memCount = memsData.size();
	
		for(int mCounter = 0; mCounter < memCount; mCounter++){
			if(mCounter == 0 && whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
			//waitForPageLoaded();
			
			switch(memsData.get(mCounter).immStatus){			
				case "CIT":
					selectIfMemIsUSCitizen(mCounter, true);
					selectIfMemIsNaturalizedCitizen(mCounter, false);
					clickOnSaveAndContinueBtn();
					break;
					
				case "CITN":
					selectIfMemIsUSCitizen(mCounter, true);
					selectIfMemIsNaturalizedCitizen(mCounter, true);
					clickOnSaveAndContinueBtn();
					break;
				
				case "QLP":
					selectIfMemIsUSCitizen(mCounter, false);
					clickOnImmigrationCheckBox();
					clickOnReEntryPermitI327RdBtn(mCounter);
					enterAlienNo(memsData.get(mCounter).alienNumber);
					selectIfMemNameSameAsAppearOnSSN(mCounter,memsData.get(mCounter).alientNameSameAsAppear);
					selectIfMemArriveInUSAfter1960(mCounter, memsData.get(mCounter).arrivedInUSAfter1996);
					selectIfMemIsVeteran(mCounter, true);
					clickOnSaveAndContinueBtn();
					
					if(StubLogic.isMemberExpecting_QLP_RFI(memsData.get(mCounter).lastName)){
						clickOnVeriyMannualBtn();
						selectImmStatusForMember(mCounter, memsData.get(mCounter).immStatusvlpErrorIndex);
						clickOnSaveAndContinueBtn();
					}
					break;
					
				case "QAB":
					selectIfMemIsUSCitizen(mCounter, false);
					clickOnImmigrationCheckBox();
					clickOnReEntryPermitI327RdBtn(mCounter);
					enterAlienNo(memsData.get(mCounter).alienNumber);
					selectIfMemNameSameAsAppearOnSSN(mCounter,memsData.get(mCounter).alientNameSameAsAppear);
					selectIfMemArriveInUSAfter1960(mCounter, memsData.get(mCounter).arrivedInUSAfter1996);
					selectIfMemIsVeteran(mCounter, false);
					clickOnSaveAndContinueBtn();
					
					if(StubLogic.isMemberExpecting_QAB_RFI(memsData.get(mCounter).lastName)){
						clickOnVeriyMannualBtn();
						selectImmStatusForMember(mCounter, memsData.get(mCounter).immStatusvlpErrorIndex);
						enterCitizenStatusAwardDateForMemo(mCounter, memsData.get(mCounter).immStatusAwardDate);
						clickOnSaveAndContinueBtn();
					}					
					break;
					
				case "ILP":
					selectIfMemIsUSCitizen(mCounter, false);
					clickOnImmigrationCheckBox();
					clickOnReEntryPermitI327RdBtn(mCounter);
					enterAlienNo(memsData.get(mCounter).alienNumber);
					selectIfMemNameSameAsAppearOnSSN(mCounter,memsData.get(mCounter).alientNameSameAsAppear);
					selectIfMemArriveInUSAfter1960(mCounter, memsData.get(mCounter).arrivedInUSAfter1996);
					selectIfMemIsVeteran(mCounter, true);
					clickOnSaveAndContinueBtn();
					
					if(StubLogic.isMemberExpecting_ILP_RFI(memsData.get(mCounter).lastName)){
						clickOnVeriyMannualBtn();
						selectImmStatusForMember(mCounter, memsData.get(mCounter).immStatusvlpErrorIndex);
						clickOnSaveAndContinueBtn();
					}					
					break;
				
				case "NQP":
					selectIfMemIsUSCitizen(mCounter, false);
					clickOnImmigrationCheckBox();
					clickOnReEntryPermitI327RdBtn(mCounter);
					enterAlienNo(memsData.get(mCounter).alienNumber);
					selectIfMemNameSameAsAppearOnSSN(mCounter,memsData.get(mCounter).alientNameSameAsAppear);
					selectIfMemArriveInUSAfter1960(mCounter, memsData.get(mCounter).arrivedInUSAfter1996);
					selectIfMemIsVeteran(mCounter, true);
					clickOnSaveAndContinueBtn();
					
					if( StubLogic.isMemberExpecting_NQP_RFI(memsData.get(mCounter).lastName)){
						clickOnVeriyMannualBtn();
					}
					
					selectImmStatusForMember(mCounter, memsData.get(mCounter).immStatusvlpErrorIndex);
					clickOnSaveAndContinueBtn();
					break;
					
				case "UND":
					selectIfMemIsUSCitizen(mCounter, false);
					selectIfMemIsVeteran(mCounter, false);
					clickOnSaveAndContinueBtn();
					clickOnWarningPopUpOKBtn();
					break;
					
			}
		}
	}
	
	// ppinho
	public void evpdSelectImmigartionStatusForMember(int memIndex, EVPD_Data evpdData) throws Exception {
		switch(evpdData.memsData.get(memIndex).immStatus){			
			case "CIT":
				selectIfMemIsUSCitizen(memIndex, true);
				selectIfMemIsNaturalizedCitizen(memIndex, false);
				clickOnSaveAndContinueBtn();
				break;
					
			case "CITN":
				selectIfMemIsUSCitizen(memIndex, true);
				selectIfMemIsNaturalizedCitizen(memIndex, true);
				clickOnSaveAndContinueBtn();
				break;
				
			case "QLP":
				selectIfMemIsUSCitizen(memIndex, false);
				clickOnImmigrationCheckBox();
				clickOnReEntryPermitI327RdBtn(memIndex);
				enterAlienNo(evpdData.memsData.get(memIndex).alienNumber);
				selectIfMemNameSameAsAppearOnSSN(memIndex, evpdData.memsData.get(memIndex).alientNameSameAsAppear);
				selectIfMemArriveInUSAfter1960(memIndex, evpdData.memsData.get(memIndex).arrivedInUSAfter1996);
				selectIfMemIsVeteran(memIndex, true);
				clickOnSaveAndContinueBtn();
					
				if(StubLogic.isMemberExpecting_QLP_RFI(evpdData.memsData.get(memIndex).lastName)){
					clickOnVeriyMannualBtn();
					selectImmStatusForMember(memIndex, evpdData.memsData.get(memIndex).immStatusvlpErrorIndex);
					clickOnSaveAndContinueBtn();
				}
				break;
					
			case "QAB":
				selectIfMemIsUSCitizen(memIndex, false);
				clickOnImmigrationCheckBox();
				clickOnReEntryPermitI327RdBtn(memIndex);
				enterAlienNo(evpdData.memsData.get(memIndex).alienNumber);
				selectIfMemNameSameAsAppearOnSSN(memIndex, evpdData.memsData.get(memIndex).alientNameSameAsAppear);
				selectIfMemArriveInUSAfter1960(memIndex, evpdData.memsData.get(memIndex).arrivedInUSAfter1996);
				selectIfMemIsVeteran(memIndex, false);
				clickOnSaveAndContinueBtn();
				
				if(StubLogic.isMemberExpecting_QAB_RFI(evpdData.memsData.get(memIndex).lastName)){
					clickOnVeriyMannualBtn();
					selectImmStatusForMember(memIndex, evpdData.memsData.get(memIndex).immStatusvlpErrorIndex);
					enterCitizenStatusAwardDateForMemo(memIndex, evpdData.memsData.get(memIndex).immStatusAwardDate);
					clickOnSaveAndContinueBtn();
				}					
				break;
					
			case "ILP":
				selectIfMemIsUSCitizen(memIndex, false);
				clickOnImmigrationCheckBox();
				clickOnReEntryPermitI327RdBtn(memIndex);
				enterAlienNo(evpdData.memsData.get(memIndex).alienNumber);
				selectIfMemNameSameAsAppearOnSSN(memIndex, evpdData.memsData.get(memIndex).alientNameSameAsAppear);
				selectIfMemArriveInUSAfter1960(memIndex, evpdData.memsData.get(memIndex).arrivedInUSAfter1996);
				selectIfMemIsVeteran(memIndex, true);
				clickOnSaveAndContinueBtn();
				
				if(StubLogic.isMemberExpecting_ILP_RFI(evpdData.memsData.get(memIndex).lastName)){
					clickOnVeriyMannualBtn();
					selectImmStatusForMember(memIndex, evpdData.memsData.get(memIndex).immStatusvlpErrorIndex);
					clickOnSaveAndContinueBtn();
				}					
				break;
			
			case "NQP":
				selectIfMemIsUSCitizen(memIndex, false);
				clickOnImmigrationCheckBox();
				clickOnReEntryPermitI327RdBtn(memIndex);
				enterAlienNo(evpdData.memsData.get(memIndex).alienNumber);
				selectIfMemNameSameAsAppearOnSSN(memIndex, evpdData.memsData.get(memIndex).alientNameSameAsAppear);
				selectIfMemArriveInUSAfter1960(memIndex, evpdData.memsData.get(memIndex).arrivedInUSAfter1996);
				selectIfMemIsVeteran(memIndex, true);
				clickOnSaveAndContinueBtn();
				
				if( StubLogic.isMemberExpecting_NQP_RFI(evpdData.memsData.get(memIndex).lastName)){
					clickOnVeriyMannualBtn();
				}
					
				selectImmStatusForMember(memIndex, evpdData.memsData.get(memIndex).immStatusvlpErrorIndex);
				clickOnSaveAndContinueBtn();
				break;
					
			case "UND":
				selectIfMemIsUSCitizen(memIndex, false);
				selectIfMemIsVeteran(memIndex, false);
				clickOnSaveAndContinueBtn();
				clickOnWarningPopUpOKBtn();
				break;
					
		}
	}
	
	// ppinho
	public void racSelectImmigartionStatusForMember(int memIndex, RAC_Data evpdData) throws Exception {
		switch(evpdData.memsData.get(memIndex).immStatus){			
			case "CIT":
				selectIfMemIsUSCitizen(memIndex, true);
				selectIfMemIsNaturalizedCitizen(memIndex, false);
				clickOnSaveAndContinueBtn();
				break;
					
			case "CITN":
				selectIfMemIsUSCitizen(memIndex, true);
				selectIfMemIsNaturalizedCitizen(memIndex, true);
				clickOnSaveAndContinueBtn();
				break;
				
			case "QLP":
				selectIfMemIsUSCitizen(memIndex, false);
				clickOnImmigrationCheckBox();
				clickOnReEntryPermitI327RdBtn(memIndex);
				enterAlienNo(evpdData.memsData.get(memIndex).alienNumber);
				selectIfMemNameSameAsAppearOnSSN(memIndex, evpdData.memsData.get(memIndex).alientNameSameAsAppear);
				selectIfMemArriveInUSAfter1960(memIndex, evpdData.memsData.get(memIndex).arrivedInUSAfter1996);
				selectIfMemIsVeteran(memIndex, true);
				clickOnSaveAndContinueBtn();
					
				if(StubLogic.isMemberExpecting_QLP_RFI(evpdData.memsData.get(memIndex).lastName)){
					clickOnVeriyMannualBtn();
					selectImmStatusForMember(memIndex, evpdData.memsData.get(memIndex).immStatusvlpErrorIndex);
					clickOnSaveAndContinueBtn();
				}
				break;
					
			case "QAB":
				selectIfMemIsUSCitizen(memIndex, false);
				clickOnImmigrationCheckBox();
				clickOnReEntryPermitI327RdBtn(memIndex);
				enterAlienNo(evpdData.memsData.get(memIndex).alienNumber);
				selectIfMemNameSameAsAppearOnSSN(memIndex, evpdData.memsData.get(memIndex).alientNameSameAsAppear);
				selectIfMemArriveInUSAfter1960(memIndex, evpdData.memsData.get(memIndex).arrivedInUSAfter1996);
				selectIfMemIsVeteran(memIndex, false);
				clickOnSaveAndContinueBtn();
				
				if(StubLogic.isMemberExpecting_QAB_RFI(evpdData.memsData.get(memIndex).lastName)){
					clickOnVeriyMannualBtn();
					selectImmStatusForMember(memIndex, evpdData.memsData.get(memIndex).immStatusvlpErrorIndex);
					enterCitizenStatusAwardDateForMemo(memIndex, evpdData.memsData.get(memIndex).immStatusAwardDate);
					clickOnSaveAndContinueBtn();
				}					
				break;
					
			case "ILP":
				selectIfMemIsUSCitizen(memIndex, false);
				clickOnImmigrationCheckBox();
				clickOnReEntryPermitI327RdBtn(memIndex);
				enterAlienNo(evpdData.memsData.get(memIndex).alienNumber);
				selectIfMemNameSameAsAppearOnSSN(memIndex, evpdData.memsData.get(memIndex).alientNameSameAsAppear);
				selectIfMemArriveInUSAfter1960(memIndex, evpdData.memsData.get(memIndex).arrivedInUSAfter1996);
				selectIfMemIsVeteran(memIndex, true);
				clickOnSaveAndContinueBtn();
				
				if(StubLogic.isMemberExpecting_ILP_RFI(evpdData.memsData.get(memIndex).lastName)){
					clickOnVeriyMannualBtn();
					selectImmStatusForMember(memIndex, evpdData.memsData.get(memIndex).immStatusvlpErrorIndex);
					clickOnSaveAndContinueBtn();
				}					
				break;
			
			case "NQP":
				selectIfMemIsUSCitizen(memIndex, false);
				clickOnImmigrationCheckBox();
				clickOnReEntryPermitI327RdBtn(memIndex);
				enterAlienNo(evpdData.memsData.get(memIndex).alienNumber);
				selectIfMemNameSameAsAppearOnSSN(memIndex, evpdData.memsData.get(memIndex).alientNameSameAsAppear);
				selectIfMemArriveInUSAfter1960(memIndex, evpdData.memsData.get(memIndex).arrivedInUSAfter1996);
				selectIfMemIsVeteran(memIndex, true);
				clickOnSaveAndContinueBtn();
				
				if( StubLogic.isMemberExpecting_NQP_RFI(evpdData.memsData.get(memIndex).lastName)){
					clickOnVeriyMannualBtn();
				}
					
				selectImmStatusForMember(memIndex, evpdData.memsData.get(memIndex).immStatusvlpErrorIndex);
				clickOnSaveAndContinueBtn();
				break;
					
			case "UND":
				selectIfMemIsUSCitizen(memIndex, false);
				selectIfMemIsVeteran(memIndex, false);
				clickOnSaveAndContinueBtn();
				clickOnWarningPopUpOKBtn();
				break;
					
		}
	}
	
}
