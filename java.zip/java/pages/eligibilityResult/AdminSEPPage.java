package pages.eligibilityResult;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Ritika 
 *
 */
public class AdminSEPPage extends CommonPage implements CommonPageOR{
	
	private static final By administrativeSEPChangeHeader = By.xpath("//div[contains(text()[normalize-space()],'Administrative SEP Change')]");
	private static final By administrativeSEPBtnPopUp = By.xpath("//button[contains(.,'Admin SEP')]");
	
	public AdminSEPPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("AdministrativeSEPChangeHeader", administrativeSEPChangeHeader, 5);
	}
	
	
	public void selectAdminMemberChkBx(int memIndex) throws Exception{
		By adminMemberChkBx = By.xpath("//label[contains(@class,'checkbox')]/input["+memIndex+"]");
		clickOnElement("Mem"+(memIndex+1)+"AdminMemberChkBx", adminMemberChkBx);
	}
	
	public void selectReasonDropDown(String reason) throws Exception{
		By reasonDD = By.xpath("//select[contains(@id,'sepReason')]");
		selectByVisibleTextAfterWait("ReasonDD" , reasonDD, reason);
	}
	
	public void enterCommentsTxt(String comments) throws Exception{
		By commentsTxt = By.xpath("//textarea[contains(@id,'msgComment')]");
		enterText("CommentsTxt", commentsTxt, comments);
	}
	
	public void clickOnAdminSEPBtn() throws Exception{
		clickOnElement("AdminSEPBtn", administrativeSEPBtnPopUp);
	}
	public void takeScreenshot() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Summary");
	}
	
	public void enterAdminSEPDetails(int memIndex,String reason,String comments) throws Exception
	{
		waitForPageLoaded();
		selectAdminMemberChkBx(memIndex);
		selectReasonDropDown(reason);
		enterCommentsTxt(comments);
		takeScreenshot();
		clickOnAdminSEPBtn();
	}		
}
