package pages.eligibilityResult;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.ReadablePartial;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import appdata.pa.PA_MemData;
import appdata.ruleEngine.RuleEngine_Data;
import drools.pdrules.DecisionTable;
import drools.pdrules.model.AidCat;

import pages.common.CommonPage;
import pages.common.CommonPageOR;
import utils.DateUtil;
import utils.EligibilityRuleEngine;
import utils.FPLCalculator;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class CurrentYearEligibilityResultPage extends CommonPage implements CommonPageOR {
	
	public List<RuleEngine_Data> ruleEngineData = new ArrayList<RuleEngine_Data>();
	
	private static final By eligibilityResultPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Eligibility Results')]");	
	private static final By showMedicaidHHDetailsBtn = By.id("MedicaidHHResult");
	private static final By showMedicaidNoticeBtn = By.id("MedicaidNotice");
	private static final By canIShopBtn = By.xpath("//div[@id='eligibilityResult']//input[@value='Can I Shop?']");
	private static final By findAPlanBtn = By.xpath("//input[contains(@value,'Find a Plan for')]");
	private static final By adminSEPBtn = By.xpath("//input[@value='Admin SEP']");
	private static final By changeEnrollmentBtn = By.xpath("//div[@id='eligibilityResult']//a[text()='Change Enrollment']");
	private static final By applicationSummaryBtn =By.id("applicationSummary");
	
	public CurrentYearEligibilityResultPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("EligibilityResultPageHeader", eligibilityResultPageHeader, 5);
	}
	
	public void clickOnBackToEligibilityApplicationsBtn() throws Exception{
		clickOnElement("BackToEligibilityAppBtn", backBtn);
	}
	
	public void clickOnShowMedicaidHHDetailseBtn() throws Exception{
		clickOnElement("ShowMedicaidHHDetailsBtn", showMedicaidHHDetailsBtn);
	}
	
	public void clickOnShowMedicaidNoticeBtn() throws Exception{
		clickOnElement("ShowMedicaidNoticeBtn", showMedicaidNoticeBtn);
	}
	
	public void clickOnCanIShopBtn() throws Exception{
		clickOnElement("CanIShopBtn", canIShopBtn);
	}
	
	public void clickOnFindAPlanBtn() throws Exception{
		clickOnElement("FindAPlanBtn", findAPlanBtn);
	}
	
	public void clickOnAdminSEPBtn() throws Exception{
		clickOnElement("AdminSEPBtn", adminSEPBtn);
	}
	
	public void clickOnChangeEnrollmentBtn() throws Exception{
		clickOnElement("ChangeEnrollmentBtn", changeEnrollmentBtn);
	}
	
	public void clickOnApplicationSummaryBtn() throws Exception{
		clickOnElement("ApplicationSummaryBtn", applicationSummaryBtn);
	}
	
	public void validateFPLForTaxHHBasedOnSelfReportedIncome(int taxHHNo, String expFPL) throws Exception{
		By taxHHFPLLabel = By.xpath("//*[@id='expandHouseholdContainer_" + taxHHNo + "']//*[contains(text(),'Federal Poverty Level (FPL) based on your self-reported income')]/..//td/span");
		validateTextContains("TaxHH" + taxHHNo + "FPLLabel", taxHHFPLLabel, expFPL);
	}
	
	public void validateFPLForTaxHHUsedToDecidePE(int taxHHNo, String expFPL ) throws Exception{
		By taxHHFPLLabel = By.xpath("//div[@id='expandHouseholdContainer_"+taxHHNo+"']//th[contains(text(),'Federal Poverty Level (FPL) used to decide your Program Eligibility')]/../td[1]/span");
		validateTextContains("TaxHH"+taxHHNo+"FPLLabel", taxHHFPLLabel, expFPL);
	}
	
	// added by ppinho
	public void validateAPTCamountForTaxHH(int taxHHNo, String expAPTCamount) throws Exception{
		By taxHHDolarAPTCamount = By.xpath("//div[@id='expandHouseholdContainer_"+taxHHNo+"']//p[contains(text(),'maximum monthly tax credit amount')]/span/span/span[1]");
		String[] arrAPTCamount = expAPTCamount.trim().split("\\.");
		validateTextContains("TaxHH"+taxHHNo+"FPLLabel", taxHHDolarAPTCamount, arrAPTCamount[0]);
	}

	//added by ppinho	
	public void validatePDForMember(int taxHHNo, String fName, String lName, String expPrg, int type) throws Exception {
		By pdLabel = By.xpath("//div[@id='expandHouseholdContainer_" + taxHHNo + "']//table[caption[text()='Program Eligibility']]//th[contains(text(), '" + fName + "') and contains(text(),'" + lName + "')]/../td[1]//p[" + type + "]");
		validateTextContains("TaxHH " + taxHHNo + ": " + fName + " " + lName + " PD", pdLabel, expPrg);
	}
	
	//vimal 
	
	public void validatePDForMemberInTaxHH(int taxHHNo, int memNo, String expPrg) throws Exception{
		//By pdLabel = By.xpath("//div[@id='expandHouseholdContainer_"+taxHHNo+"']//table[caption[text()='Program Eligibility']]/tbody["+memNo+"]/tr[1]/td[1]//span[@class='needEllipsis']");
		By pdLabel = By.xpath("//div[@id='expandHouseholdContainer_"+taxHHNo+"']//table[caption[text()='Program Eligibility']]/tbody["+memNo+"]/tr[1]/td[1]");
		validateTextContains("TaxHH"+taxHHNo+"MemNo"+memNo+"PD", pdLabel, expPrg);
	}
	
	//Ritu
	public void ValidateNORFI_ForMemberInTaxHH_Present(int taxHHNo, int memNo) throws Exception {
        
        
        By refLabelInRow1 = By.xpath("//div[@id='expandHouseholdContainer_"+taxHHNo+"']//table[caption[text()='Program Eligibility']]/tbody["+memNo+"]/tr[1]/td[contains(.,'No documents required')]");
        waitForPresenceOfElementLocated("TaxHH"+taxHHNo+"MemNo"+memNo+"NoRFILabel",refLabelInRow1);
     }

	//vimal
	public String getRFIsForMemberInTaxHH(int taxHHNo, int memNo) throws Exception {
		String rfis = "";
		
		By refLabelInRow1 = By.xpath("//div[@id='expandHouseholdContainer_"+taxHHNo+"']//table[caption[text()='Program Eligibility']]/tbody["+memNo+"]/tr[1]/td[2]");
		if(isElementPresent(refLabelInRow1, 1)){
			rfis = getElementText(refLabelInRow1);
		}
		int rowCounter=2;
		while(true){
			By refLabelInOtherRow = By.xpath("//div[@id='expandHouseholdContainer_"+taxHHNo+"']//table[caption[text()='Program Eligibility']]/tbody["+memNo+"]/tr["+rowCounter+"]/td[1]");
			if(isElementPresent(refLabelInOtherRow, 1)){
				rfis = rfis + "," + getElementText(refLabelInOtherRow);
				rowCounter++;
			}else{
				break;
			}
		}
		return rfis;
	}
	
	//vimal
	public String getRFIStatusForMemberInTaxHH(int taxHHNo, int memNo, String rfi) throws Exception {
		String status = "";
		
		By statusLabelInRow1 = By.xpath("//div[@id='expandHouseholdContainer_"+taxHHNo+"']//table[caption[text()='Program Eligibility']]/tbody["+memNo+"]/tr[1]/td[contains(.,'"+rfi+"')]/../td[3]");
		
		if(isElementPresent(statusLabelInRow1, 1)){
			return getElementText(statusLabelInRow1);
		}else{
			int rowCounter = 2;
			
			while(rowCounter < 10){
				By statusLabelInOtherRow = By.xpath("//div[@id='expandHouseholdContainer_" + taxHHNo + "']//table[caption[text()='Program Eligibility']]/tbody[" + memNo + "]/tr[" + rowCounter + "]/td[contains(.,'" + rfi + "')]/../td[2]");
				
				if(isElementPresent(statusLabelInOtherRow, 1)){
					return  getElementText(statusLabelInOtherRow);
				}else{
					rowCounter++;
				}
			}
		}
		return status;
	}
	
	//ppinho
	public String getQLERFIStatusForMemberInTaxHH(int taxHHNo, String fName, String lName, String expRFI) throws Exception {
		By statusLabelInRow1 = By.xpath("//div[@id='ke HouseholdContainer_" + taxHHNo + "']//div//*[text()='Documents Required']/following::*[contains(text(),'" + fName + "') and contains(text(),'" + lName + "')]/../following::*[text()='" + expRFI + "']");
		return getElementText(statusLabelInRow1);
	}
	
	//vimal
	public void ValidateRFI_ForMemberInTaxHH_Present(int taxHHNo, int memNo, String expRfi) throws Exception {
		String rfis = getRFIsForMemberInTaxHH(taxHHNo, memNo);
		validateTextContains("TaxHH" + taxHHNo + "MemNo" + memNo + "RFI", rfis, expRfi);
	}
	
	//vimal
	public void ValidateRFI_ForMemberInTaxHH_NotPresent(int taxHHNo, int memNo, String expRfi) throws Exception {
		String rfis = getRFIsForMemberInTaxHH(taxHHNo, memNo);
		validateTextNotContains("TaxHH" + taxHHNo + "MemNo" + memNo + "RFI", rfis, expRfi);
	}
	
	//vimal
	public void ValidateRFIstatus_ForMemberInTaxHH_Present(int taxHHNo, int memNo, String rfi, String expStatus) throws Exception {
		String status = getRFIStatusForMemberInTaxHH(taxHHNo, memNo, rfi);		
		validateTextEquals("TaxHH" + taxHHNo + "MemNo" + memNo + "RFIStatus", status, expStatus);
	}
	
	//ppinho
	public void ValidateQLERFIstatus_ForMemberInTaxHH_Present(int taxHHNo, String fName, String lName, String expRFI) throws Exception {
		String status = getQLERFIStatusForMemberInTaxHH(taxHHNo, fName, lName, expRFI);		
		validateTextEquals("TaxHH" + taxHHNo + "-" + fName + " " + lName + "-RFIStatus", status, expRFI);
	}
	
	// ppinho
	public void validateEligibilityResults(int year, EVPD_Data evpdData, List<PA_MemData> memsData2, String appDate, String currentDate) throws Exception {
		for(int memIndex = 0; memIndex < evpdData.memCount; memIndex++){			
			if(evpdData.memsData.get(memIndex).isTaxHHMember){ 
				int taxHHCount = 1;
				int taxHHIndex = evpdData.memsData.get(memIndex).taxHHIndex;
				
				// Run Rule Engine
				EligibilityRuleEngine.runEligibilityRuleEngine(year, evpdData, memsData2, memIndex, appDate, currentDate);
				
				// Check FPL of each household
				if(taxHHIndex == taxHHCount){
					validateFPLForTaxHHBasedOnSelfReportedIncome(taxHHIndex, evpdData.memsData.get(memIndex).taxFPL);
					taxHHCount++;
				}
				
				// Validate PD for each member
				if(!evpdData.memsData.get(memIndex).mhProgramDetermination.isEmpty() && !evpdData.memsData.get(memIndex).ccaProgramDetermination.isEmpty() && Integer.valueOf(evpdData.memsData.get(memIndex).age) < 65){
					validatePDForMember(taxHHIndex, evpdData.memsData.get(memIndex).firstName, evpdData.memsData.get(memIndex).lastName, evpdData.memsData.get(memIndex).ccaProgramDetermination, 1);
					validatePDForMember(taxHHIndex, evpdData.memsData.get(memIndex).firstName, evpdData.memsData.get(memIndex).lastName, evpdData.memsData.get(memIndex).mhProgramDetermination, 2);					
				}else if(!evpdData.memsData.get(memIndex).ccaProgramDetermination.isEmpty()){
					validatePDForMember(taxHHIndex, evpdData.memsData.get(memIndex).firstName, evpdData.memsData.get(memIndex).lastName, evpdData.memsData.get(memIndex).ccaProgramDetermination, 1);					
				}else{
					validatePDForMember(taxHHIndex, evpdData.memsData.get(memIndex).firstName, evpdData.memsData.get(memIndex).lastName, evpdData.memsData.get(memIndex).mhProgramDetermination, 1);
				}
			}			
		}
	}

	public boolean isWarningDialogPresent() throws Exception{
		return isElementPresent(warningOkButton);
	}
	
	public boolean isQLEPresent() throws Exception{
		return isElementPresent(canIShopBtn);
	}
	
	public void clickOnWarningOkButton() throws Exception{
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}
	
	public void handleWarningDialogIfPresent() throws Exception{
		if(isWarningDialogPresent()){
			clickOnWarningOkButton();
		}
	}
	
	public void takeScreenshot() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Summary");
	}
	
	public void gotoBackToEligibilityApplications() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Summary");
		clickOnBackToEligibilityApplicationsBtn();
	}
	
	public void gotoShowMedicaidHHDetails() throws Exception{
		waitForPageLoaded();
		clickOnShowMedicaidHHDetailseBtn();
	}
	
	public void gotoShowMedicaidNotices() throws Exception{
		waitForPageLoaded();
		clickOnShowMedicaidNoticeBtn();
	}
	
	public void gotoQLEPage() throws Exception{
		waitForPageLoaded();
		clickOnCanIShopBtn();
	}
	
	public void gotoFindAPlanPage() throws Exception{
		waitForPageLoaded();
		clickOnFindAPlanBtn();
	}
	
	public void clickOnChangeEnrollmentAndoToMyEnrollmentPage() throws Exception{
		waitForPageLoaded();
		clickOnChangeEnrollmentBtn();
	}
	
	public void clickOnApplicationSummaryButton() throws Exception{
		waitForPageLoaded();
		clickOnApplicationSummaryBtn();
	}
		
}
