package pages.eligibilityResult;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.evpd.PBFG_Data;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import utils.StubLogic;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class MedicaidNoticePage extends CommonPage implements CommonPageOR{
	
	private static final By medicaidNoticePageHeader = By.xpath("//h1[contains(text(),'Find and View Medicaid Notices')]");
	private static final By noNoticeMsg = By.xpath("//td[(@class='dataTables_empty') and contains (text(),'No Medicaid Notices')]");
	
	public MedicaidNoticePage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("MedicaidNoticePageHeader", medicaidNoticePageHeader);
	}
	
	public void verifyNoNoticeMsg() throws Exception{
		isElementPresent(noNoticeMsg);
	}
	
	public void takeScreenShot() throws Exception {
		takeScreenshot("Medicaid Notice Summary");
	}
		
}
