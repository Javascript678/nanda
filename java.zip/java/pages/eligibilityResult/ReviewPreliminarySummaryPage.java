package pages.eligibilityResult;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.ReadablePartial;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.pa.PA_MemData;
import appdata.ruleEngine.RuleEngine_Data;
import drools.pdrules.DecisionTable;
import drools.pdrules.model.AidCat;

import pages.common.CommonPage;
import pages.common.CommonPageOR;
import utils.DateUtil;
import utils.EligibilityRuleEngine;
import utils.FPLCalculator;

/**
 * 
 * @author Paul Pinho
 *
 */
public class ReviewPreliminarySummaryPage extends CommonPage implements CommonPageOR {
	
	private static final By reviewPreliminarySummaryPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Review Preliminary Summary')]");
	
	public ReviewPreliminarySummaryPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("EligibilityResultPageHeader", reviewPreliminarySummaryPageHeader, 5);
	}
	
	public String getEligibilityId() throws Exception {
		waitForPageLoaded();
		String url = getCurrentURL();
		System.out.println(url);
		String elgId = url.split("&eid=")[1].split("&")[0];
		return elgId;
	}
		
}
