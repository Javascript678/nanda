package pages.overrideEligibility;

import org.openqa.selenium.By;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
import utils.DateUtil;

import org.openqa.selenium.WebDriver;

import enums.PrimaryProgaramType;

/**
 * 
 * @author Ritika Gupta
 *
 */
public class OverrideEligibiltyPage extends CommonPage implements CommonPageOR {

	public OverrideEligibiltyPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private static final By overrideEligibilityPageHeader = By
			.xpath("//h1[contains(text()[normalize-space()],'Override Eligibility')]");

	private void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("OverrideEligibilityPageHeader", overrideEligibilityPageHeader);
	}

	public void takeScreenshot() throws Exception {
		takeScreenshot("ErrorMSG");
	}

	public void validateErrorMessage() throws Exception {
		By errorMsgLabel = By.xpath("//div[@id='errorSummary']//span[@class='errorSummaryValue']/a");
		waitForPageLoaded();
		String errorMsgTxt = "Override eligibility failed";
		validateTextEquals("ErrorMessage", errorMsgLabel, errorMsgTxt);
		takeScreenshot();
	}

	public void clickOnWarningOkButton() throws Exception {
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}

	public boolean isWarningDialogPresent() throws Exception {
		return isElementPresent(warningOkButton);
	}

	public void handleWarningDialogIfPresent() throws Exception {
		if (isWarningDialogPresent()) {
			clickOnWarningOkButton();
		}
	}

	public void selectPrimaryPgTypeDD(String primaryPgType) throws Exception {
		By primaryPgTypeDD = By.id("primaryProgType");
		selectDropDownElementByVisibleText("PrimaryPgTypeDD", primaryPgTypeDD, primaryPgType);
	}

	public void selectSecondaryProgTypeDD(String secondaryProgType) throws Exception {
		By secondaryProgTypeDD = By.id("secondaryProgType");
		selectDropDownElementByVisibleText("SecondaryProgTypeDD", secondaryProgTypeDD, secondaryProgType);
	}

	public void selectPlanType(String planType) throws Exception {
		By planTypeDD = By.id("planType");
		selectDropDownElementByVisibleText("PlanTypeDD", planTypeDD, planType);
	}

	//for connectorcare plans
    public void selectAidCategoryDD2(String aidCategory) throws Exception {
          By aidCategoryDD = By.id("adCategoryS");// aidCategoryP
          selectByVisibleTextAfterWait("AidCategoryDD", aidCategoryDD, aidCategory);
    }

    public void enterBenefitStartDateTxt2(String medicaidStartDate) throws Exception {
          By medicaidStartDateTxt = By.id("medicaid_start_date2");
          clearAndType("MedicaidStartDateTxt", medicaidStartDateTxt, medicaidStartDate);
    }

    public void selectMassHltCovDDForCHIP(String massHltCov) throws Exception {
          By massHltCovDD = By.id("medicaidCategory"); 
          selectDropDownElementByVisibleText("MassHealthCoverageDD", massHltCovDD, massHltCov);
    }

	public void selectMassHltCovDD(String massHltCov) throws Exception {
		By massHltCovDD = By.id("medicaidCategoryMH");
		selectDropDownElementByVisibleText("MassHealthCoverageDD", massHltCovDD, massHltCov);
	}

	public void selectAidCategoryDD(String aidCategory) throws Exception {
		By aidCategoryDD = By.id("aidCategoryP");
		selectByVisibleTextAfterWait("AidCategoryDD", aidCategoryDD, aidCategory);
	}

	public void enterBenefitStartDateTxt(String medicaidStartDate) throws Exception {
		By medicaidStartDateTxt = By.id("medicaid_start_date");
		clearAndType("MedicaidStartDateTxt", medicaidStartDateTxt, medicaidStartDate);
	}

	public void enterTMAStartDateTxt(String tmaStartDate) throws Exception {
		By tmaStartDateTxt = By.id("TMA_start_date");
		clearAndType("TMAStartDateTxt", tmaStartDateTxt, tmaStartDate);
	}

	public void enterTMAEffDateTxt(String tmaEffDate) throws Exception {
		By tmaEffDateTxt = By.id("TMA_effective_date");
		clearAndType("TMAEffectiveDateTxt", tmaEffDateTxt, tmaEffDate);
	}

	public void enterProtectionEndDateTxt(String protectionEndDate) throws Exception {
		By protectionEndDateTxt = By.id("submissionEndDate");
		clearAndType("ProtectionEndDateTxt", protectionEndDateTxt, protectionEndDate);
	}

	public void selectTMAEndDateTxt(String tmaEndDate) throws Exception {
		By tmaEndDateTxt = By.id("TMA_End_date");
		selectDropDownElementByVisibleText("TMAEndDateTxt", tmaEndDateTxt, tmaEndDate);
	}

	public void selectSendMHNoticeRdBtn(boolean trueFalseValue) throws Exception {
		By sendMHNoticeRdBtn = By.name("sendMHNotice");
		selectByValue("SendMHNoticeRdBtn", sendMHNoticeRdBtn, trueFalseValue + "");
	}

	public void selectSendCCANoticeRdBtn(boolean trueFalseValue) throws Exception {
		By sendCCANoticeRdBtn = By.name("sendCCANotice");
		selectByValue("SendCCANoticeRdBtn", sendCCANoticeRdBtn, trueFalseValue + "");
	}

	public void selectSendTMANoticeRdBtn(boolean trueFalseValue) throws Exception {
		By sendTMANoticeRdBtn = By.name("sendTMANotice");
		selectByValue("SendTMANoticeRdBtn", sendTMANoticeRdBtn, trueFalseValue + "");
	}

	public void clickOnOverrideTab() throws Exception {
		waitForPageLoaded();
		By overrideTabBtn = By.xpath("//a[contains(.,'Override')]");
		clickOnElement("OverrideTab", overrideTabBtn);
	}

	public void clickOnOverride() throws Exception {
		By overrideBtn = By.xpath("//button[contains(.,'Override Eligibility Results')]");
		String expandCollpse = getElementAttribute("AttributeValue", overrideBtn, "aria-expanded");
		if (expandCollpse.equalsIgnoreCase("false")) {
			clickOnElement("Override", overrideBtn);
		}
	}

	public void clickOnMemberChkBx(int memIndex) throws Exception {
		By memBtn = By.id("mmcheckbox_" + memIndex);
		clickOnElement("Mem" + memIndex + "checkBox", memBtn);
	}

	public void clickOnEditBtn() throws Exception {
		By editBtn = By.id("editButton1");
		clickOnElement("EditBtn", editBtn);
	}

	public void clickOnSaveBtn() throws Exception {
		By saveBtn = By.id("saveButton");
		clickOnElement("SaveBtn", saveBtn);
	}

	public void enterComments(String comments) throws Exception {
		By commentsTxt = By.name("comments");
		enterText("CommentsTxt", commentsTxt, comments);
	}

	public void clickOnApplyBtn() throws Exception {
		By applyBtn = By.id("applyButton");
		clickOnElement("ApplyBtn", applyBtn);
		takeScreenshot("Override");
	}

	// Paul
	public void clickOnAccountDashboard() throws Exception {
		By AccountDashboardBtn = By.id("section_begin");
		clickOnElement("AccountDashboardButton", AccountDashboardBtn);
	}

	// Paul
	public void overrideEligibilitySubmissionDate(String submissionDate) throws Exception {
		By submissionDateTxt = By.id("submissionDate");
		clearAndTypeAfterWait("SubmissionDate", submissionDateTxt, submissionDate);
	}

	// Paul
	private void selectTaxHHtoOverride(int taxHHindex, Boolean override) throws Exception {
		By taxHHoverrideCheckBox = By.id("hhcheckbox_" + taxHHindex);

		if (override.equals(true)) {
			clickOnElement("OverrideCheckBox", taxHHoverrideCheckBox);
		}
	}

	// Paul
	public void overrideAPTCAmountIfTrue(int taxHHindex, Boolean override) throws Exception {
		selectTaxHHtoOverride(taxHHindex, override);
	}

	// Paul
	public void clickOnOverrideAPTCamount() throws Exception {
		By taxHHoverrideAPTCamountDD = By.xpath("//button[contains(text(),'Household Details')]");

		String expandCollpse = getElementAttribute("taxHHoverrideAPTCamount", taxHHoverrideAPTCamountDD,
				"aria-expanded");

		if (expandCollpse.equalsIgnoreCase("false")) {
			clickOnElement("OverrideAPTCamount", taxHHoverrideAPTCamountDD);
		}
	}

	// Paul
	public void clickOnEditAPTCamount() throws Exception {
		By editBtn = By.id("editButton");
		clickOnElement("EditBtn", editBtn);
	}

	// Paul
	public void overrideEligibilityPageLoadAndClickOnOverrideTab() throws Exception {
		waitForPageLoaded();
		clickOnOverrideTab();
	}

	// Paul
	public void clickOnMemberDetails() throws Exception {
		By memberDetailsForm = By.xpath("//button[contains(.,'Member Details')]");

		String expandCollpse = getElementAttribute("MemberDetails", memberDetailsForm, "aria-expanded");

		if (expandCollpse.equalsIgnoreCase("false")) {
			clickOnElement("MemberDetails", memberDetailsForm);
		}
	}

	// Paul
	public void clickOnOverrideEligibilityResults() throws Exception {
		By memOverrideEligibilityResults = By.id("label_expand_3");

		String expandCollpse = getElementAttribute("taxHHoverrideAPTCamount", memOverrideEligibilityResults,
				"aria-expanded");

		if (expandCollpse.equalsIgnoreCase("false")) {
			clickOnElement("OverrideEligibilityResults", memOverrideEligibilityResults);
		}
	}

	// Paul
	private void selectMembersToOverride(int memIndex, Boolean override) throws Exception {
		By memOverrideCheckBox = By.id("mmcheckbox_" + memIndex);

		if (override.equals(true)) {
			clickOnElement("OverrideCheckBox", memOverrideCheckBox);
		}
	}

	// Paul
	public void overrideEligibilityIfTrue(int memIndex, Boolean override) throws Exception {
		selectMembersToOverride(memIndex, override);
	}

	// Paul
	public void clickOnSaveHHbtn() throws Exception {
		By hhSaveBtn = By.id("hhsaveButton");
		clickOnElement("SaveBtn", hhSaveBtn);
	}

	// Paul
	public void newAPTCamount(String inputDate, String newAPTCAmount, String overrideProtectionEndDate)
			throws Exception {
		By minAPTCamountDD = By.id("maximumAptcAmount");
		By protectionEndDateDD = By.id("protectionEndDate");

		String endDate = DateUtil.getFutureDateInUIFormatUsingPattern(inputDate, DateUtil.UIDatePattern,
				overrideProtectionEndDate);

		clearAndType("MinAPTCamount", minAPTCamountDD, newAPTCAmount);
		clearAndTypeAfterWait("ProtectionEndDate", protectionEndDateDD, endDate);
	}

	// Paul
	public void selectPrimaryProgramType(String inputDate, String primaryProgramType, String variableOne,
		String variableTwo, String variableThree, String variableFour, String variableFive) throws Exception {
		
		By PrimaryProgramTypeDD = By.id("primaryProgType");
		By masshealthCoverageMhDD = By.id("medicaidCategoryMH");
		By masshealthCoverageDD = By.id("medicaidCategory");
		By aidCategoryMHDD = By.id("aidCategoryP");
		By medicaidStartDateDD = By.id("medicaid_start_date");
		By submissionEndDateDD = By.id("submissionEndDate");
		By PlanTypeDD = By.name("planType");

		if (primaryProgramType.equals(PrimaryProgaramType.CHIP.dropDownVal)) {
			String startDate = DateUtil.getPriorDateInUIFormatUsingPattern(inputDate, DateUtil.UIDatePattern,
					variableThree);
			String endDate = DateUtil.getFutureDateInUIFormatUsingPattern(inputDate, DateUtil.UIDatePattern,
					variableFour);

			selectDropDownElementByVisibleText("Primary Program Type", PrimaryProgramTypeDD, primaryProgramType);
			selectDropDownElementByVisibleText("Masshealth Coverage", masshealthCoverageDD, variableOne);
			selectDropDownElementByVisibleText("Aid Category", aidCategoryMHDD, variableTwo);
			clearAndTypeAfterWait("Start Date", medicaidStartDateDD, startDate);
			clearAndTypeAfterWait("End Date", submissionEndDateDD, endDate);
		} else if (primaryProgramType.equals(PrimaryProgaramType.HCP.dropDownVal)) {
			selectDropDownElementByVisibleText("Primary Program Code", PrimaryProgramTypeDD, primaryProgramType);

			if (variableOne != null && !variableOne.trim().isEmpty()) {
				selectSecondaryProgramType(inputDate, variableOne, variableTwo, variableThree, variableFour);
			}
		} else if (primaryProgramType.equals(PrimaryProgaramType.MH.dropDownVal)) {
			String startDate = DateUtil.getPriorDateInUIFormatUsingPattern(inputDate, DateUtil.UIDatePattern,
					variableThree);
			String endDate = DateUtil.getFutureDateInUIFormatUsingPattern(inputDate, DateUtil.UIDatePattern,
					variableFour);

			selectDropDownElementByVisibleText("Primary Program Type", PrimaryProgramTypeDD, primaryProgramType);
			selectDropDownElementByVisibleText("Masshealth Coverage", masshealthCoverageMhDD, variableOne);
			selectDropDownElementByVisibleText("Aid Category", aidCategoryMHDD, variableTwo);
			clearAndTypeAfterWait("Start Date", medicaidStartDateDD, startDate);
			clearAndTypeAfterWait("End Date", submissionEndDateDD, endDate);
		} else if (primaryProgramType.equals(PrimaryProgaramType.CCA.dropDownVal)) {
			selectDropDownElementByVisibleText("Primary Program Code", PrimaryProgramTypeDD, primaryProgramType);
			selectDropDownElementByVisibleText("Plan Type", PlanTypeDD, variableOne);

			if (variableTwo != null && !variableTwo.trim().isEmpty()) {
				selectSecondaryProgramType(inputDate, variableTwo, variableThree, variableFour, variableFive);
			}
		} else if (primaryProgramType.equals(PrimaryProgaramType.HCP_W_APTC.dropDownVal)) {
			selectDropDownElementByVisibleText("Primary Program Code", PrimaryProgramTypeDD, primaryProgramType);

			if (variableOne != null && !variableOne.trim().isEmpty()) {
				selectSecondaryProgramType(inputDate, variableOne, variableTwo, variableThree, variableFour);
			}
		} else {
			selectDropDownElementByVisibleText("Primary Program Code", PrimaryProgramTypeDD, primaryProgramType);
		}
	}

	// Paul
	public void selectSecondaryProgramType(String inputDate, String variableTwo, String variableThree,
			String variableFour, String variableFive) throws Exception {
		By SecondaryProgramTypeDD = By.id("secondaryProgType");
		By AidCategoryDD = By.id("adCategoryS");
		By StartDateDD = By.id("medicaid_start_date2");
		By EndDateDD = By.id("submissionEndDate");

		String startDate = DateUtil.getPriorDateInUIFormatUsingPattern(inputDate, DateUtil.UIDatePattern, variableFour);
		String endDate = DateUtil.getFutureDateInUIFormatUsingPattern(inputDate, DateUtil.UIDatePattern, variableFive);

		selectDropDownElementByVisibleText("Secondary Program Type", SecondaryProgramTypeDD, variableTwo);
		selectDropDownByValue("Aid Category", AidCategoryDD, variableThree);
		clearAndTypeAfterWait("Start Date", StartDateDD, startDate);
		clearAndTypeAfterWait("End Date", EndDateDD, endDate);
	}
	
	public void selectNoticeResponse(boolean SendMHNotice, boolean SendCCANotice, boolean SendTMANotice) throws Exception {
		selectSendMHNoticeRdBtn(SendMHNotice);
		selectSendCCANoticeRdBtn(SendCCANotice);
		selectSendTMANoticeRdBtn(SendTMANotice);		
	}

}
