package pages.medicallyFrailInfo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class MedicallyFrailInfoPage extends CommonPage implements CommonPageOR {
	
	public MedicallyFrailInfoPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private static final By medicallyFrailInfoPageHeader = By.xpath("//h1[contains(.,'Medically Frail Info')]");
	private static final By saveReRunEligibilityBtn = By.id("saveAndApplyButton");
	
	
	private static final By confirmReRunEligibilityBtn =By.xpath("//span[text()='CONFIRM']");
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("MedicallyFrailInfoPageHeader", medicallyFrailInfoPageHeader);
	}

	private void selectMedicallyFrailInfoForMember(int memIndex, boolean isMedicallyFrail)throws Exception{
		By medicallyFrailRdBtn = By.name("memberMedicallyFrailInfoDTOList["+memIndex+"].isMedicallyFrail");
		selectByValue("DisabledRdBtn", medicallyFrailRdBtn, isMedicallyFrail+"");
	}
	
	private void enterEffectiveDateForMember(int memIndex , String effctiveDate)throws Exception{
		By effectiveDateTxt = By.id("medicallyFrailEffectiveDate_"+memIndex+"");
		clearAndType("MedicallyFrailEffectiveDateTxt", effectiveDateTxt, effctiveDate+"");
	}
	
	
	private void clickOnSaveAndORerunEligibility() throws Exception  {
		clickOnElementThenWait("ReRunEligibilityBtn", saveReRunEligibilityBtn,5);
	}
	
	private void clickOnConfrimRerunEligibilityBtn() throws Exception  {
		clickOnElementThenWait("ConfirmReRunEligibilityBtn",confirmReRunEligibilityBtn,5);
	}
	
	private void clickOnBackBtn() throws Exception  {
		clickOnElementThenWait("BackBtn",backButton,5);
	}
	
	private void optionalClickOnDisabilityMemTab(String name) throws Exception  {
		  By medicallyFrailMemTab = By.xpath("//h2//button[contains(.,'"+name+"') and contains(@aria-expanded,'false')]");
		optionalClickOnElement("MedicallyFrailMemTab",medicallyFrailMemTab);
	}
	public void selectMedicallyFrailAndRerun(String name,int memIndex, boolean isMedicallyFrail,String effctiveDate) throws Exception
	{
		waitForPageLoaded();
		optionalClickOnDisabilityMemTab(name);
		selectMedicallyFrailInfoForMember(memIndex,isMedicallyFrail);
		if(isMedicallyFrail)
		enterEffectiveDateForMember(memIndex,effctiveDate);
		clickOnSaveAndORerunEligibility();
		clickOnConfrimRerunEligibilityBtn();
		clickOnBackBtn();
			
	}

}


