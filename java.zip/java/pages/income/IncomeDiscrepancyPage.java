package pages.income;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class IncomeDiscrepancyPage extends CommonPage implements CommonPageOR{
	
	private static final By incomeDiscrepancyPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Income Discrepancies')]");
	
	public IncomeDiscrepancyPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	private void waitForPageLoadForMember(int memIndex) throws Exception{
		By memIncomeDisExplainTxt = By.id("eligibilityMember["+memIndex+"].eligibilityMemberIncome.eligibilityMemberIncomeDiscrepancies.lowIncomeExplanation");
		waitForPresenceOfElementLocated("Mem"+(memIndex+1)+"IncomeDisExplainTxt", memIncomeDisExplainTxt);		
	}
	
	public boolean isVerifyManualBtnPresent(int memIndex) throws Exception{
		By memIncomeDisExplainTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeDiscrepancies.lowIncomeExplanation");
		return isElementPresent(memIncomeDisExplainTxt, 25);		
	}
	
	public void clickOnVerifyManualBtn() throws Exception{
		clickOnElement("VerifyManualBtn", verifyManualBtn);
	}
	
	public void verifyIncomeDescripancyMannually(int memIndex) throws Exception {
		waitForPageLoadForMember(memIndex);
		clickOnVerifyManualBtn();
	}
	
	public void selectReasonvAndClickOnVerifyIncomeDescripancyMannually(int memIndex,String reason) throws Exception{
        By reasonslistInDiscrepancyPagechkbox=By.name("eligibilityMember["+memIndex+"].eligibilityMemberIncome.eligibilityMemberIncomeDiscrepancies.reasonsList");
        selectByValue("reasonslistInDiscrepancyPage", reasonslistInDiscrepancyPagechkbox, reason);
  }

	// ppinho
	public void evpdVerifyIncomeDescripancyMannually(int memIndex) throws Exception {
		waitForPageLoadForMember(memIndex);
		clickOnVerifyManualBtn();
	}
	
	// ppinho
	public void racVerifyIncomeDescripancyMannually(int memIndex) throws Exception {
		waitForPageLoadForMember(memIndex);
		clickOnVerifyManualBtn();
	}
	
}
