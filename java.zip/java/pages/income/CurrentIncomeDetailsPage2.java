package pages.income;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import enums.DeductionType;
import pages.common.CommonPage;
import pages.common.CommonPageOR;


/**
 * 
 * @author Vinay Kumar
 * @author Aashita Verma
 *
 */
public class CurrentIncomeDetailsPage2 extends CommonPage implements CommonPageOR{
	
	private static final By currentIncomeDetailsPage2Header = By.xpath("//h1/span[contains(text(),'Current Income Details')]");
	
	public CurrentIncomeDetailsPage2(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("CurrentIncomeDetailsPage2Header", currentIncomeDetailsPage2Header);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn, 3);
	}
	
	public void selectMemIncomeDeductions(int memIndex, String deductionTypes) throws Exception{
		By deductionTypeCheckBox = By.name("eligibilityMember["+memIndex+"].eligibilityMemberIncome.deductionTypes");
		selectByValue("Mem" + (memIndex+1) + "DeductionTypeCheckBox", deductionTypeCheckBox, deductionTypes);
	}
	
	public void selectMemIncomeDeductionsAsNone(int memIndex) throws Exception{
		By deductionTypeNoneChkBx = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberIncome.deductionTypes' and @value='NONE']/../label");
		if(! isAttributePresent(deductionTypeNoneChkBx, "checked")){
			clickOnElement("Mem" + (memIndex+1) + "DeductionTypeNoneChkBx", deductionTypeNoneChkBx);
		}
	}
	
	public void enterEducatorExpenseAmtYearly(int memIndex, String amount) throws Exception{
		By educatorExpenseAmtTxt = By.xpath("//input[@id ='eligibilityMemberAmount_EDUCATOR_EXPENSE']");
		clearAndType("OtherDeductionTxt", educatorExpenseAmtTxt, amount);
	}
	public void enterBusinessExpAmtYearly(int memIndex, String amount) throws Exception{
		By businessExpAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_BUSINESS_EXPENSES_RESERVIST_ARTIST']");
		clearAndType("OtherDeductionTxt", businessExpAmtTxt, amount);
	}
	public void enterMovingExpJobChangeAmtYearly(int memIndex, String amount) throws Exception{
		By movingExpJobChangeAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_MOVING_EXPENSES_RELATED_TO_JOB_CHANGE']");
		clearAndType("OtherDeductionTxt", movingExpJobChangeAmtTxt, amount);
	}
	public void enterHealthSavingAmtYearly(int memIndex, String amount) throws Exception{
		By healthSavingAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_HEALTH_SAVINGS_ACCOUNT_DEDUCTION']");
		clearAndType("OtherDeductionTxt", healthSavingAmtTxt, amount);
	}
	public void enterDedSelfEmployAmtYearly(int memIndex, String amount) throws Exception{
		By dedSelfEmployAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_DEDUCTIBLE_PART_OF_SELF_EMPLOYMENT_TAX']");
		clearAndType("OtherDeductionTxt", dedSelfEmployAmtTxt, amount);
	}
	public void enterContriSelfEmployAmtYearly(int memIndex, String amount) throws Exception{
		By contriSelfEmployAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_CONTRIBUTION_TO_SELF_EMPLOYED_SEP']");
		clearAndType("OtherDeductionTxt", contriSelfEmployAmtTxt, amount);
	}
	public void enterSelfHealthInsAmtYearly(int memIndex, String amount) throws Exception{
		By selfHealthInsAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_SELF_EMPLOYED_HEALTH_INSURANCE_DED']");
		clearAndType("OtherDeductionTxt", selfHealthInsAmtTxt, amount);
	}
	public void enterPenaltyEarlWithrAmtYearly(int memIndex, String amount) throws Exception{
		By penaltyEarlWithrAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_PENALTY_ON_EARLY_WITHDRAWAL']");
		clearAndType("OtherDeductionTxt", penaltyEarlWithrAmtTxt, amount);
	}
	public void enterAlimonyAmtYearly(int memIndex, String amount) throws Exception{
		By alimonyAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_ALIMONY_PAID']");
		clearAndType("OtherDeductionTxt", alimonyAmtTxt, amount);
	}
	public void enterIndiRetiremtAmtYearly(int memIndex, String amount) throws Exception{
		By indiRetiremtAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_INDIVIDUAL_RETIREMENT_ACCOUNT_DED']");
		clearAndType("OtherDeductionTxt", indiRetiremtAmtTxt, amount);
	}
	public void enterStuLoanAmtYearly(int memIndex, String amount) throws Exception{
		By stuLoanAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_STUDENT_LOAN_INTEREST_PAID']");
		clearAndType("OtherDeductionTxt", stuLoanAmtTxt, amount);
	}
	public void enterHighEduAmtYearly(int memIndex, String amount) throws Exception{
		By highEduAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_HIGHER_EDUCATION']");
		clearAndType("OtherDeductionTxt", highEduAmtTxt, amount);
	}
	public void enterDomesticProdAmtYearly(int memIndex, String amount) throws Exception{
		By domesticProdAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_DOMESTIC_PRODUCTION_DED']");
		clearAndType("OtherDeductionTxt", domesticProdAmtTxt, amount);
	}
	public void enterOtherDeduAmtYearly(int memIndex, String amount) throws Exception{
		By otherDeduAmtTxt = By.xpath("//input[@id = 'eligibilityMemberAmount_OTHER_DEDUCTIONS']");
		clearAndType("OtherDeductionTxt", otherDeduAmtTxt, amount);
	}
	
	
	public void enterWhatOtherDeductionDoYouHave(int memIndex, String txt) throws Exception{
		By otherDeductionTxt = By.name("eligibilityMember["+memIndex+"].eligibilityMemberIncome.eligibilityMemberIncomeDeductions[14].otherDeductions");
		enterText("OtherDeductionTxt", otherDeductionTxt, txt);
	}
	
	public void enterOtherDeductionAmount(int memIndex, String amount) throws Exception{
		By otherDeductionAmtTxt = By.id("eligibilityMemberAmount_OTHER_DEDUCTIONS");
		clearAndType("OtherDeductionTxt", otherDeductionAmtTxt, amount);
	}
	
	public void enterOtherDeductionAmountFreduency(int memIndex, String amountFreq) throws Exception{
		By otherDeductionAmtFrqDD = By.id("frequency_OTHER_DEDUCTIONS");
		selectDropDownByValue("OtherDeductionTxt", otherDeductionAmtFrqDD, amountFreq);
	}
	
	public void selectIfMemberHasSteadyIncome(int memIndex, boolean trueFalseValue) throws Exception{
		By steadyIncomeRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberIncome.confirmAmountForCoverageYear' and @value='"+ trueFalseValue+"']/../label");
		clickOnElement( "Mem" + (memIndex+1) + "SteadyIncomeRdBtn"+trueFalseValue, steadyIncomeRdBtn);
	}
	
	public void enterExpectedMonthlyIncomeForMemberNotHavingSteadyIncome(int memIndex,int amount) throws Exception{
		By projectedIncomeTxt = By.id("eligibilityMember"+memIndex+".eligibilityMemberIncome.avgIncome");
		enterText("Mem" + (memIndex+1) + "ExpectedMonthlyIncomeForMember", projectedIncomeTxt, amount+"");
	}
	
	public void enterExpectedMonthlyIncomeForMember(int memIndex, int amount) throws Exception{
		By expectedAvgMonthlyIncomeTxt = By.id("eligibilityMember"+memIndex+".eligibilityMemberIncome.avgIncome");
		enterText("Mem" + (memIndex+1) + "ExpectedAvgMonthlyIncomeTxt", expectedAvgMonthlyIncomeTxt, amount+"");
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void evpdCompleteCurrentIncomeDetailsForMember(int memIndex, EVPD_MemData memData) throws Exception {		
		//waitForPageLoaded();
		if(!memData.hasSourceOfDeduction){
			selectMemIncomeDeductions(memIndex, DeductionType.NONE.val);
		}else if(memData.deductionTypeAsEducator){
			selectMemIncomeDeductions(memIndex, DeductionType.EDUCATOR_EXPENSE.val);
			enterEducatorExpenseAmtYearly(memIndex, memData.deductionTypeAsEducatorAmt);
		}
		selectIfMemberHasSteadyIncome(memIndex, true);
		clickOnSaveAndContinueBtn();
	}
	
	public void racCompleteCurrentIncomeDetailsForMember(int memIndex, RAC_MemData memData) throws Exception {		
		//waitForPageLoaded();
		if(!memData.hasSourceOfDeduction){
			selectMemIncomeDeductions(memIndex, DeductionType.NONE.val);
		}else if(memData.deductionTypeAsEducator){
			selectMemIncomeDeductions(memIndex, DeductionType.EDUCATOR_EXPENSE.val);
			enterEducatorExpenseAmtYearly(memIndex, memData.deductionTypeAsEducatorAmt);
		}
		selectIfMemberHasSteadyIncome(memIndex, true);
		clickOnSaveAndContinueBtn();
	}
	
	//Aashita 
	public void completeCurrentIncomeDetailsForMemberNew(int memIndex, EVPD_MemData memData) throws Exception {		
		//waitForPageLoaded();
		if(memData.hasSourceOfDeduction){
		   if(memData.deductionTypeAsEducator){
			selectMemIncomeDeductions(memIndex, DeductionType.EDUCATOR_EXPENSE.val);
			enterEducatorExpenseAmtYearly(memIndex, memData.deductionTypeAsEducatorAmt);
		}
		   if(memData.deductionTypeAsBusinessExp){
				selectMemIncomeDeductions(memIndex, DeductionType.BUSINESS_EXPENSES_RESERVIST_ARTIST.val);
				enterBusinessExpAmtYearly(memIndex, memData.deductionTypeAsBusinessExpAmt);
			}
		   if(memData.deductionTypeAsHealthSavingDed){
				selectMemIncomeDeductions(memIndex, DeductionType.HEALTH_SAVINGS_ACCOUNT_DEDUCTION.val);
				enterHealthSavingAmtYearly(memIndex, memData.deductionTypeAsHealthSavingDedAmt);
			}
		   if(memData.deductionTypeAsMoveJobChange){
				selectMemIncomeDeductions(memIndex, DeductionType.MOVING_EXPENSES_RELATED_TO_JOB_CHANGE.val);
				enterMovingExpJobChangeAmtYearly(memIndex, memData.deductionTypeAsMoveJobChangeAmt);
			}
		   if(memData.deductionTypeAsSelfEmployTax){
				selectMemIncomeDeductions(memIndex, DeductionType.DEDUCTIBLE_PART_OF_SELF_EMPLOYMENT_TAX.val);
				enterDedSelfEmployAmtYearly(memIndex, memData.deductionTypeAsSelfEmployTaxAmt);
			}
		   if(memData.deductionTypeAsSelfEmploySEP){
				selectMemIncomeDeductions(memIndex, DeductionType.CONTRIBUTION_TO_SELF_EMPLOYED_SEP.val);
				enterContriSelfEmployAmtYearly(memIndex, memData.deductionTypeAsSelfEmploySEPAmt);
			}
		   if(memData.deductionTypeAsHealthInsDed){
				selectMemIncomeDeductions(memIndex, DeductionType.SELF_EMPLOYED_HEALTH_INSURANCE_DED.val);
				enterSelfHealthInsAmtYearly(memIndex, memData.deductionTypeAsHealthInsDedAmt);
			}
		   if(memData.deductionTypeAsPenaltyEarlywith){
				selectMemIncomeDeductions(memIndex, DeductionType.PENALTY_ON_EARLY_WITHDRAWAL.val);
				enterPenaltyEarlWithrAmtYearly(memIndex, memData.deductionTypeAsPenaltyEarlywithAmt);
			}
		   if(memData.deductionTypeAsAlimonyPaid){
				selectMemIncomeDeductions(memIndex, DeductionType.ALIMONY_PAID.val);
				enterAlimonyAmtYearly(memIndex, memData.deductionTypeAsAlimonyPaidAmt);
			}
		   if(memData.deductionTypeAsIndRetirement){
				selectMemIncomeDeductions(memIndex, DeductionType.INDIVIDUAL_RETIREMENT_ACCOUNT_DED.val);
				enterIndiRetiremtAmtYearly(memIndex, memData.deductionTypeAsIndRetirementAmt);
			}
		   if(memData.deductionTypeAsStdLoanIntrPaid){
				selectMemIncomeDeductions(memIndex, DeductionType.STUDENT_LOAN_INTEREST_PAID.val);
				enterStuLoanAmtYearly(memIndex, memData.deductionTypeAsStdLoanIntrPaidAmt);
			}
		   if(memData.deductionTypeAsHigherEdu){
				selectMemIncomeDeductions(memIndex, DeductionType.HIGHER_EDUCATION.val);
				enterHighEduAmtYearly(memIndex, memData.deductionTypeAsHigherEduAmt);
			}
		   if(memData.deductionTypeAsDomsProdDed){
				selectMemIncomeDeductions(memIndex, DeductionType.DOMESTIC_PRODUCTION_DED.val);
				enterDomesticProdAmtYearly(memIndex, memData.deductionTypeAsDomsProdDedAmt);
			}
		   if(memData.deductionTypeAsOther){
				selectMemIncomeDeductions(memIndex, DeductionType.OTHER_DEDUCTIONS.val);
				enterOtherDeduAmtYearly(memIndex, memData.deductionTypeAsOtherAmt);
			}
		}
		else {
				selectMemIncomeDeductions(memIndex, DeductionType.NONE.val);
		}
		selectIfMemberHasSteadyIncome(memIndex, true);
		clickOnSaveAndContinueBtn();
	}
	
	
	
	public void racCompleteCurrentIncomeDetailsForMember(int memIndex) throws Exception{
		waitForPageLoaded();
		selectMemIncomeDeductionsAsNone(memIndex);
		selectIfMemberHasSteadyIncome(memIndex, true);
		clickOnSaveAndContinueBtn();
	}
	
}