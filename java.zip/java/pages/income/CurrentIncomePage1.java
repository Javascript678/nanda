package pages.income;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import enums.IncomeType;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class CurrentIncomePage1 extends CommonPage implements CommonPageOR {
	
	private static final By currentIncomePage1Header = By.xpath("//h1[contains(.,'Current Income')]");
	
	public CurrentIncomePage1(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("CurrentIncomePage1Header", currentIncomePage1Header);
	}
	
	public void waitForPageLoaded(int memIndex) throws Exception{
		By memHasInomeRdBtn = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.hasIncome");
		waitForPresenceOfElementLocated("CurrentIncomePage1Header", memHasInomeRdBtn);
	}
	
	public void validatePageTitleDontContainsName(String fullName) throws Exception {
		String actualTitle = getCurrentPageTitle();
		validateTextNotContains("CurrentIncomePage1Title", actualTitle, fullName);
	}
	public void selectIfMemHasIncome(int memIndex, boolean trueFalseValue) throws Exception{
		//By memHasInomeRdBtn = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.hasIncome");
		By memHasInomeRdBtn = By.xpath("//input[@name='eligibilityMember["+ memIndex +"].eligibilityMemberIncome.hasIncome' and @value='"+ trueFalseValue +"']/../label");
		clickOnElement("Mem" + (memIndex+1) + "HasInomeRdBtn",memHasInomeRdBtn );
	}
	
	public void selectMemIncomeTypes(int memIndex, String incomeTypes) throws Exception {
		String[] sources = incomeTypes.split(",");
		
		for(String source : sources){
			By memIncomeTypeCheckBox = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberIncome.sourcesList' and @ value='"+ source +"']");
			waitForPresenceOfElementLocated("Mem" + (memIndex + 1) + "JobIncomeTypeChkBx", memIncomeTypeCheckBox);
			clickOnElement("Mem" + (memIndex + 1) + "IncomeTypeChkBx", memIncomeTypeCheckBox);
		}			
	}
	
	public void selectMemIncomeTypeAsJob(int memIndex) throws Exception{
		By memJobIncomeTypeChkBx = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberIncome.sourcesList' and @value='JOB']");
		if(! isAttributePresent(memJobIncomeTypeChkBx, "checked")){
			clickOnElement("Mem" + (memIndex+1) + "JobIncomeTypeChkBx", memJobIncomeTypeChkBx);
		}
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn, 3);
	}
	
	public boolean isWarningOkButtonPresent() throws Exception{
		return isElementPresent(warningOkButton, 3);
	}
	
	public void clickOnWarningOkButton() throws Exception{
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}
	
	public void pageLoadAndClickOnSaveAndContinue(int memIndex) throws Exception{
		waitForPageLoaded(memIndex);
		clickOnSaveAndContinueBtn();
	}
	
	public void selectIncomeTypeForMember(int memIndex, boolean hasSourceOfIncome,  String incomeTypes) throws Exception{
		waitForPageLoaded();
		selectIfMemHasIncome(memIndex, hasSourceOfIncome);
		if(hasSourceOfIncome){
			selectMemIncomeTypes(memIndex, incomeTypes);
		}
		clickOnSaveAndContinueBtn();
	}
	
	public void evpdSelectIncomeTypeForMember(int memIndex, EVPD_MemData memData) throws Exception{
		waitForPageLoaded();
		selectIfMemHasIncome(memIndex, memData.hasSourceOfIncome);
		if(memData.hasSourceOfIncome){
			selectMemIncomeTypes(memIndex, memData.incomeTypes);
		}
		clickOnSaveAndContinueBtn();		
	}
	
	public void racSelectIncomeTypeForMember(int memIndex, RAC_MemData memData) throws Exception{
		waitForPageLoaded();
		selectIfMemHasIncome(memIndex, memData.hasSourceOfIncome);
		if(memData.hasSourceOfIncome){
			selectMemIncomeTypes(memIndex, memData.incomeTypes);
		}
		clickOnSaveAndContinueBtn();		
	}
	
	public void handleWarningDialogIfPresent() throws Exception{
		if(isWarningOkButtonPresent()){
			clickOnWarningOkButton();
		}
	}
	
	// ppinho
	public void evpdCompleteCurrentIncomeForMembers(int memIndex, String displayShelteredWorkshopQuestion, EVPD_MemData memData) throws Exception {
		int incomeSourceIndex = -1;
			
		CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
		currentIncomePage1.evpdSelectIncomeTypeForMember(memIndex, memData);
					
		if(memData.incomeTypes != null){				
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
				
			if(memData.incomeTypes.contains(IncomeType.JOB.val)){
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterJobEmployerDetailsForMember(displayShelteredWorkshopQuestion, memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.SELF_EMPLOYMENT.val)){
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterSelfEmpEmployerDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.SOCIAL_SECURITY_BENEFITS.val)){
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterSocialSecurityBenefitsDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.UNEMPLOYMENT.val)){
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterUnemploymentDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.RETIREMENT.val)){
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterRetirementOrPensionDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.CAPITALGAINS.val)){
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterCapitalGainsDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.INVESTMENT_INCOME.val)){
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterInterestDividendsOtherInvestmentDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
			
			if(memData.incomeTypes.contains(IncomeType.RENTAL_OR_ROYALTY_INCOME.val)){
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterRentalOrRoyaltyDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.FARMING_OR_FISHING_INCOME.val)){
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterFarmingFishingDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
					
			if(memData.incomeTypes.contains(IncomeType.ALIMONY_RECEIVED.val)){
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterAlimonyDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
					
			if(memData.incomeTypes.contains(IncomeType.OTHER_INCOME.val)){
				String otherIncomeType = "";
				incomeSourceIndex++;
				currentIncomePage2.evpdEnterOtherIncomeDetailsForMember(memIndex, incomeSourceIndex, memData, otherIncomeType);
			}
			
			currentIncomePage2.clickOnSaveAndContinueBtn();
		}
	}
	
	// ppinho
	public void racCompleteCurrentIncomeForMembers(int memIndex, String displayShelteredWorkshopQuestion, RAC_MemData memData) throws Exception {
		int incomeSourceIndex = -1;
			
		CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
		currentIncomePage1.racSelectIncomeTypeForMember(memIndex, memData);
					
		if(memData.incomeTypes != null){				
			CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
				
			if(memData.incomeTypes.contains(IncomeType.JOB.val)){
				incomeSourceIndex++;
				currentIncomePage2.racEnterJobEmployerDetailsForMember(displayShelteredWorkshopQuestion, memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.SELF_EMPLOYMENT.val)){
				incomeSourceIndex++;
				currentIncomePage2.racEnterSelfEmpEmployerDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.SOCIAL_SECURITY_BENEFITS.val)){
				incomeSourceIndex++;
				currentIncomePage2.racEnterSocialSecurityBenefitsDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.UNEMPLOYMENT.val)){
				incomeSourceIndex++;
				currentIncomePage2.racEnterUnemploymentDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.RETIREMENT.val)){
				incomeSourceIndex++;
				currentIncomePage2.racEnterRetirementOrPensionDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.CAPITALGAINS.val)){
				incomeSourceIndex++;
				currentIncomePage2.racEnterCapitalGainsDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.INVESTMENT_INCOME.val)){
				incomeSourceIndex++;
				currentIncomePage2.racEnterInterestDividendsOtherInvestmentDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
			
			if(memData.incomeTypes.contains(IncomeType.RENTAL_OR_ROYALTY_INCOME.val)){
				incomeSourceIndex++;
				currentIncomePage2.racEnterRentalOrRoyaltyDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
						
			if(memData.incomeTypes.contains(IncomeType.FARMING_OR_FISHING_INCOME.val)){
				incomeSourceIndex++;
				currentIncomePage2.racEnterFarmingFishingDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
					
			if(memData.incomeTypes.contains(IncomeType.ALIMONY_RECEIVED.val)){
				incomeSourceIndex++;
				currentIncomePage2.racEnterAlimonyDetailsForMember(memIndex, incomeSourceIndex, memData);
			}
					
			if(memData.incomeTypes.contains(IncomeType.OTHER_INCOME.val)){
				String otherIncomeType = "";
				incomeSourceIndex++;
				currentIncomePage2.racEnterOtherIncomeDetailsForMember(memIndex, incomeSourceIndex, memData, otherIncomeType);
			}
			
			currentIncomePage2.clickOnSaveAndContinueBtn();
		}
	}
	
}
