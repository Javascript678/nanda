package pages.income;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import enums.IncomeType;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class IncomeStartPage extends CommonPage implements CommonPageOR{
	
	private static final By incomeStartPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Income')]");
	
	public IncomeStartPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("IncomeStartPageHeader", incomeStartPageHeader);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		//waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
		
	public void selectIncomeAndDeductionForMembers(
		String displayShelteredWorkshopQuestion,
		boolean faReqd, List<EVPD_MemData > memsData) throws Exception {
		
		if(faReqd){
			//waitForPageLoaded();
			clickOnSaveAndContinueBtn();
			int memCount = memsData.size();
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				int incomeSourceIndex = -1;
				
				CurrentIncomePage1 currentIncomePage1 = new CurrentIncomePage1(driver, testCaseId);
				currentIncomePage1.evpdSelectIncomeTypeForMember(mCounter, memsData.get(mCounter));
				
				if(memsData.get(mCounter).incomeTypes != null){					
					CurrentIncomePage2 currentIncomePage2 = new CurrentIncomePage2(driver, testCaseId);
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.JOB.val)){
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterJobEmployerDetailsForMember(displayShelteredWorkshopQuestion, mCounter, incomeSourceIndex, memsData.get(mCounter));
					}
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.SELF_EMPLOYMENT.val)){
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterSelfEmpEmployerDetailsForMember(mCounter, incomeSourceIndex, memsData.get(mCounter));
					}
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.SOCIAL_SECURITY_BENEFITS.val)){
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterSocialSecurityBenefitsDetailsForMember(mCounter, incomeSourceIndex, memsData.get(mCounter));
					}
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.UNEMPLOYMENT.val)){
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterUnemploymentDetailsForMember(mCounter, incomeSourceIndex, memsData.get(mCounter));
					}
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.RETIREMENT.val)){
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterRetirementOrPensionDetailsForMember(mCounter, incomeSourceIndex, memsData.get(mCounter));
					}
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.CAPITALGAINS.val)){
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterCapitalGainsDetailsForMember(mCounter, incomeSourceIndex, memsData.get(mCounter));
					}
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.INVESTMENT_INCOME.val)){
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterInterestDividendsOtherInvestmentDetailsForMember(mCounter, incomeSourceIndex, memsData.get(mCounter));
					}
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.RENTAL_OR_ROYALTY_INCOME.val)){
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterRentalOrRoyaltyDetailsForMember(mCounter, incomeSourceIndex, memsData.get(mCounter));
					}
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.FARMING_OR_FISHING_INCOME.val)){
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterFarmingFishingDetailsForMember(mCounter, incomeSourceIndex, memsData.get(mCounter));
					}
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.ALIMONY_RECEIVED.val)){
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterAlimonyDetailsForMember(mCounter, incomeSourceIndex, memsData.get(mCounter));
					}
					
					if(memsData.get(mCounter).incomeTypes.contains(IncomeType.OTHER_INCOME.val)){
						String otherIncomeType="";
						incomeSourceIndex++;
						currentIncomePage2.evpdEnterOtherIncomeDetailsForMember(mCounter, incomeSourceIndex, memsData.get(mCounter), otherIncomeType);
					}
					
					currentIncomePage2.clickOnSaveAndContinueBtn();
					
					CurrentIncomeDetailsPage1 currentIncomeDetailsPage1 = new CurrentIncomeDetailsPage1(driver, testCaseId);
					currentIncomeDetailsPage1.pageLoadThenClickOnSaveAndContinueBtn();
				}
				
				CurrentIncomeDetailsPage2 currentIncomeDetailsPage2  = new CurrentIncomeDetailsPage2(driver, testCaseId);
				currentIncomeDetailsPage2.evpdCompleteCurrentIncomeDetailsForMember(mCounter, memsData.get(mCounter));
			}
			
			IncomeDiscrepancyPage incomeDiscrepancyPage = new IncomeDiscrepancyPage(driver, testCaseId);
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(incomeDiscrepancyPage.isVerifyManualBtnPresent(mCounter)){
					incomeDiscrepancyPage.verifyIncomeDescripancyMannually(mCounter);
				}
			}
			
			AnnualIncomePage annualIncomePage = new AnnualIncomePage(driver, testCaseId);
			
			for(int mCounter=0; mCounter<memCount; mCounter++){
				annualIncomePage.verifyExpectedAnnualIncomeForMember(mCounter, memsData.get(mCounter));
			}
		}
	}
	
	// ppinho
	public void evpdClickOnSaveAndContinueBtn(boolean faReqd) throws Exception {
		if(faReqd){
			clickOnSaveAndContinueBtn();
		}
	}
	
	// ppinho
	public void racClickOnSaveAndContinueBtn(boolean faReqd) throws Exception {
		if(faReqd){
			clickOnSaveAndContinueBtn();
		}
	}
	
}
