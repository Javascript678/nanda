package pages.income;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class AnnualIncomePage extends CommonPage implements CommonPageOR{
	
	private static final By annualIncomePageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Annual Income')]");
	
	public AnnualIncomePage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("AnnualIncomePageHeader", annualIncomePageHeader);
	}
	
	public void selectIfExpectedIncomeSameAsMentionedForMember(int memIndex, boolean trueFalseValue) throws Exception{
	//	By sameAsCurrentIncomeRdBtn = By.name("eligibilityMember["+memIndex+"].eligibilityMemberIncome.sameAsCurrentIncome");
		By sameAsCurrentIncomeRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberIncome.sameAsCurrentIncome' and @value='"+trueFalseValue+"']/../label");
		//selectByValue("Mem"+(memIndex+1)+"IncomeSameAsCurrentIncomeRdBtn", sameAsCurrentIncomeRdBtn, trueFalseValue+"");		
	clickOnElement("Mem"+(memIndex+1)+"IncomeSameAsCurrentIncomeRdBtn"+trueFalseValue,sameAsCurrentIncomeRdBtn);
	}
	
	public void enterExpectedYearlyIncomeForMember(int memIndex, int amount) throws Exception{
		By expectedAvgYearlyIncomeTxt = By.name("eligibilityMember["+memIndex+"].eligibilityMemberIncome.expectedYearlyIncome");
		enterText("Mem" + (memIndex+1) + "ExpectedAvgYearlyIncomeTxt", expectedAvgYearlyIncomeTxt, amount+"");
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	
	public void verifyExpectedAnnualIncomeForMember(int memIndex, boolean expectedYearlyIncomeSameAsCurrent, int expectedYearlyIncomeAmt) throws Exception{
		waitForPageLoaded();
		if(expectedYearlyIncomeSameAsCurrent){
			selectIfExpectedIncomeSameAsMentionedForMember(memIndex, true);
		}else{
			selectIfExpectedIncomeSameAsMentionedForMember(memIndex, false);
			enterExpectedYearlyIncomeForMember(memIndex, expectedYearlyIncomeAmt);
		}
		clickOnSaveAndContinueBtn();
	}
	
	public void verifyExpectedAnnualIncomeForMember(int memIndex, EVPD_MemData memData) throws Exception{
		waitForPageLoaded();
		if(memData.expectedYearlyIncomeSameAsCurrent){
			selectIfExpectedIncomeSameAsMentionedForMember(memIndex, true);
		}else{
			selectIfExpectedIncomeSameAsMentionedForMember(memIndex, false);
			enterExpectedYearlyIncomeForMember(memIndex, memData.expectedYearlyIncomeAmtIfDiffr);
		}
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdVerifyExpectedAnnualIncomeForMember(int memIndex, EVPD_MemData memData) throws Exception{
		if(memData.expectedYearlyIncomeSameAsCurrent){
			selectIfExpectedIncomeSameAsMentionedForMember(memIndex, true);
		}else{
			selectIfExpectedIncomeSameAsMentionedForMember(memIndex, false);
			enterExpectedYearlyIncomeForMember(memIndex, memData.expectedYearlyIncomeAmtIfDiffr);
		}
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void racVerifyExpectedAnnualIncomeForMember(int memIndex, RAC_MemData memData) throws Exception{
		if(memData.expectedYearlyIncomeSameAsCurrent){
			selectIfExpectedIncomeSameAsMentionedForMember(memIndex, true);
		}else{
			selectIfExpectedIncomeSameAsMentionedForMember(memIndex, false);
			enterExpectedYearlyIncomeForMember(memIndex, memData.expectedYearlyIncomeAmtIfDiffr);
		}
		clickOnSaveAndContinueBtn();
	}
	
}
