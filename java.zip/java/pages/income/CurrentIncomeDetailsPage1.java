package pages.income;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import enums.IncomeType;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class CurrentIncomeDetailsPage1 extends CommonPage implements CommonPageOR{
	
	private static final By currentIncomeDetailsPage1Header = By.xpath("//h1/span[contains(text(),'Current Income Details')]");
	
	public CurrentIncomeDetailsPage1(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("CurrentIncomeDetailsPage1Header", currentIncomeDetailsPage1Header);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn, 3);
	}
	
	public void takeScreenshot() throws Exception{
		takeScreenshot("Summary");
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}

	//Ritika & Ritu
	public void validateJobForMember(int memIndex, String expJob) throws Exception{
		By jobIncomeLabel =By.xpath("//span[contains(.,'Job:')]/parent::li");
		validateTextContains("Mem"+(memIndex+1)+"Job", jobIncomeLabel, "$"+expJob+" /Yearly");
	}
	
	//Ritika & Ritu
	public void validateSelfEmployementForMember(int memIndex, String expSelfEmployment) throws Exception{
		By selfEmploymentIncomeLabel= By.xpath("//span[contains(.,'Self-Employment:')]/parent::li");
		validateTextContains("Mem"+(memIndex+1)+"SelfEmployemntIncome", selfEmploymentIncomeLabel,"$"+expSelfEmployment+" /Yearly");
	}
	
	//Ritika & Ritu
	public void validateSSBIncomeForMember(int memIndex, String expSSB) throws Exception{
		By socialSecurityBenifitIncomeLabel= By.xpath("//span[contains(.,'Social Security Benefits:')]/parent::li");
		validateTextContains("Mem"+(memIndex+1)+"SocialSecurityBenifitsIncome", socialSecurityBenifitIncomeLabel,"$"+expSSB+" /Yearly");
	}
	
	//Ritika & Ritu
	public void validateAlimonyReceivedIncomeForMember(int memIndex, String expAlimonyReceived) throws Exception{
		By alimonyReceivedIncomeLabel= By.xpath("//span[contains(.,'Alimony Received:')]/parent::li");
		validateTextContains("Mem"+(memIndex+1)+"AlimonyReceivedIncome",alimonyReceivedIncomeLabel,"$"+expAlimonyReceived+" /Yearly");
	}
	
	//Ritika & Ritu
	public void validateCapitalGainsIncomeForMember(int memIndex, String expCapitalGain) throws Exception{
		By capitalGainsIncomeLabel= By.xpath("//span[contains(.,'Capital Gains:')]/parent::li");
		validateTextContains("Mem"+(memIndex+1)+"CapitalGainsIncome",capitalGainsIncomeLabel,"$"+expCapitalGain+" /Yearly");
	}
	
	//Ritika & Ritu
	public void validateFarmingOrFishingIncomeForMember(int memIndex, String expFarmingAndFishing) throws Exception{
		By farmingOrFishingIncomeLabel= By.xpath("//span[contains(.,'Farming or Fishing Income:')]/parent::li");
		validateTextContains("Mem"+(memIndex+1)+"FarmingOrFishingIncome",farmingOrFishingIncomeLabel,"$"+expFarmingAndFishing+" /Yearly");
	}
	
	//Ritika & Ritu
	public void validateInterestDividendsIncomeForMember(int memIndex, String expInterestDividends) throws Exception{
		By interestDividendsIncomeLabel= By.xpath("//span[contains(.,'Interest, Dividends, or Other Investment Income:')]/parent::li");
		validateTextContains("Mem"+(memIndex+1)+"InterestDividendsIncome",interestDividendsIncomeLabel,"$"+expInterestDividends+" /Yearly");
	}
	
	//Ritika & Ritu
	public void validateOtherIncomeForMember(int memIndex, String expOtherIncome) throws Exception{
		 By otherIncomeLabel= By.xpath("//span[contains(.,'Other Income:')]/parent::li");
		 validateTextContains("Mem"+(memIndex+1)+"OtherIncome",otherIncomeLabel,"$"+expOtherIncome+" /Yearly");
	}
	
	//Ritika & Ritu
	public void validateRentalAndRoyalityIncomeForMember(int memIndex, String expRentalAndRoyality) throws Exception{
		By rentalAndRoyalityIncomeLabel= By.xpath("//span[contains(.,'Rental or Royalty Income:')]/parent::li");
		validateTextContains("Mem"+(memIndex+1)+"RentalAndRoyalityIncome",rentalAndRoyalityIncomeLabel,"$"+expRentalAndRoyality+" /Yearly");
	}
	
	//Ritika & Ritu
	public void validateRetirementOrPensionIncomeForMember(int memIndex, String expRetirementOrPension) throws Exception{
		By retirementOrPensionIncomeLabel= By.xpath("//span[contains(.,'Retirement or Pension:')]/parent::li");
		validateTextContains("Mem"+(memIndex+1)+"RetirementOrPensionIncome",retirementOrPensionIncomeLabel,"$"+expRetirementOrPension+" /Yearly");
	}
	
	//Ritika & Ritu
	public void validateUnEmploymentIncomeForMember(int memIndex, String expUnEmployment) throws Exception{
		By unEmploymentIncomeLabel= By.xpath("//span[contains(.,'Unemployment:')]/parent::li");
		validateTextContains("Mem"+(memIndex+1)+"unEmploymentIncomeLabel",unEmploymentIncomeLabel,"$"+expUnEmployment+" /Yearly");
	}
	
	// ppinho
	public void evpdCompleteCurrentIncomeDetailsForMembers(int memIndex, EVPD_MemData memData) throws Exception {
		if(memData.incomeTypes != null){				
			clickOnSaveAndContinueBtn();
		}
		CurrentIncomeDetailsPage2 currentIncomeDetailsPage2 = new CurrentIncomeDetailsPage2(driver, testCaseId);
		currentIncomeDetailsPage2.evpdCompleteCurrentIncomeDetailsForMember(memIndex, memData);
	}
	
	// ppinho
	public void racCompleteCurrentIncomeDetailsForMembers(int memIndex, RAC_MemData memData) throws Exception {
		if(memData.incomeTypes != null){				
			clickOnSaveAndContinueBtn();
		}
		CurrentIncomeDetailsPage2 currentIncomeDetailsPage2 = new CurrentIncomeDetailsPage2(driver, testCaseId);
		currentIncomeDetailsPage2.racCompleteCurrentIncomeDetailsForMember(memIndex, memData);
	}
	
}
