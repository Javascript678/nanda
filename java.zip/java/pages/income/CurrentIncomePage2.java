package pages.income;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class CurrentIncomePage2 extends CommonPage implements CommonPageOR {

	private static final By currentIncomePage2Header = By.xpath("//h1[contains(.,'Current Income')]");

	public CurrentIncomePage2(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoad(int incomeSourceIndex) throws Exception {
		waitForPresenceOfElementLocatedAfterWait("CurrentIncomePage2Header", currentIncomePage2Header, 3);
	}

	public void validatePageTitleDontContainsName(String fullName) throws Exception {
		String actualTitle = getCurrentPageTitle();
		validateTextNotContains("CurrentIncomePage2Title", actualTitle, fullName);
	}

	// ############# Job Income Details Start ################################

	public void clickOnEditEmployerName() throws Exception {
		By editEmployerBtn = By.xpath("//button[contains(@id,'editField')]");
		clickOnElement("EditEmployerName", editEmployerBtn);
	}

	public void enterEmployerNameForMember(int memIndex, int incomeSourceIndex, String employerName) throws Exception {
		By employerNameTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].memberEmployerDetails.employerName");
		clearAndType("Mem" + (memIndex + 1) + "EmployerNameTxt", employerNameTxt, employerName);
	}

	public void enterEmployerFedTaxIdForMember(int memIndex, int incomeSourceIndex, String fedTaxId) throws Exception {
		By fedTaxIdTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].memberEmployerDetails.federalTaxId");
		clearAndType("Mem" + (memIndex + 1) + "FedTaxIdTxt", fedTaxIdTxt, fedTaxId);
	}

	public void enterEmployerStreetAddressForMember(int memIndex, int incomeSourceIndex, String streetName) throws Exception {
		By employerStreetAddrTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].memberEmployerDetails.address.streetAddress1");
		clearAndType("Mem" + (memIndex + 1) + "EmployerStreetAddrTxt", employerStreetAddrTxt, streetName);
	}

	public void enterEmployerAptUnitNoForMember(int memIndex, int incomeSourceIndex, String aptUnitNo) throws Exception {
		By employerAptUnitTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].memberEmployerDetails.address.streetAddress2");
		clearAndType("Mem" + (memIndex + 1) + "EmployerAptUnitTxt", employerAptUnitTxt, aptUnitNo);
	}

	public void enterEmployerCityForMember(int memIndex, int incomeSourceIndex, String city) throws Exception {
		By employerCityTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].memberEmployerDetails.address.city");
		clearAndType("Mem" + (memIndex + 1) + "EmployerCityTxt", employerCityTxt, city);
	}

	public void enterEmployerZipForMember(int memIndex, int incomeSourceIndex, String zip) throws Exception {
		By employerZipTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].memberEmployerDetails.address.zip");
		clearAndType("Mem" + (memIndex + 1) + "EmployerZipTxt", employerZipTxt, zip);
	}

	public void selectEmployerCountyForMember(int memIndex, int incomeSourceIndex, String county) throws Exception {
		By employerCountyTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].memberEmployerDetails.address.county");
		selectByVisibleTextAfterWait("Mem" + (memIndex + 1) + "EmployerCountyTxt", employerCountyTxt, county);
	}

	public void enterJobIncomeAmountForMember(int memIndex, int incomeSourceIndex, int incomeAmount) throws Exception {
		By incomeAmountTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		clearAndType("Mem" + (memIndex + 1) + "IncomeAmountTxt", incomeAmountTxt, incomeAmount + "");
	}

	public void enterJobIncomeEffectiveDateForMember(int memIndex, int incomeSourceIndex, String date) throws Exception {
		By incomeEffectiveDateTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].incomeEffectiveDate");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "IncomeEffectiveDateTxt", incomeEffectiveDateTxt, date);
	}

	public void selectJobIncomeFrequencyForMember(int memIndex, int incomeSourceIndex, String frequency) throws Exception {
		By jobIncomeFrequencyDD = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].frequency");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "JobIncomeFrequencyDD", jobIncomeFrequencyDD, frequency);
	}

	public void enterJobHrPerWeekForMember(int memIndex, int incomeSourceIndex, int hrs) throws Exception {
		By jobHrsPerWeekTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].hoursPerWeek");
		clearAndType("Mem" + (memIndex + 1) + "JobHrsPerWeekTxt", jobHrsPerWeekTxt, hrs + "");
	}

	public void selectIfJobIsShelteredForMember(int memIndex, int incomeSourceIndex, boolean trueFalseValue) throws Exception {
		By shelteredJobRdBtn = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].hasIncomeFromSheltJobs");
		selectByValue("Mem" + (memIndex + 1) + "ShelteredJobRdBtn", shelteredJobRdBtn, trueFalseValue + "");
	}

	// ############# Job Income Details End ################################

	// ############# Self Employment Details Start ################################
	
	public void verifySelfEmploymentLabelForMember(int incomeSourceIndex) throws Exception {
		By selfEmploymentLabel = By.id("selfEmploymentIncome_" + "[" + incomeSourceIndex + "]");
		waitForPresenceOfElementLocated("SelfEmploymentLabel", selfEmploymentLabel);
	}

	public void enterSelfEmpWorkTypeForMember(int memIndex, int incomeSourceIndex, String workType) throws Exception {
		By selfEmpWorkTypeTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].workType");
		enterText("Mem" + (memIndex + 1) + "SelfEmpWorkTypeTxt", selfEmpWorkTypeTxt, workType);
	}

	public void selectSelfEmpProfitLossForMember(int memIndex, int incomeSourceIndex, Boolean isLoss) throws Exception {
		By selfEmpProfitRdBtn = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].isLoss");
		selectByValue("Mem" + (memIndex + 1) + "SelfEmpProfitRdBtn", selfEmpProfitRdBtn, isLoss + "");
	}

	public void enterSelfEmpAmountPerMonthForMember(int memIndex, int incomeSourceIndex, int amount) throws Exception {
		By selfEmpAmountPerMonthTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		Double sincome = (double) amount;
		Double SeIncomedouble = sincome / 12;
		SeIncomedouble = (Math.round(SeIncomedouble * 100.0) / 100.0);
		String seAmount = Double.toString(SeIncomedouble);
		System.out.println("Self Employment data in decimal - " + SeIncomedouble);
		enterText("Mem" + (memIndex + 1) + "SelfEmpAmountPerMonthTxt", selfEmpAmountPerMonthTxt, seAmount);
	}

	public void enterSelfEmpAmountForMember(int memIndex, int incomeSourceIndex, double amount) throws Exception {
		By selfEmpAmountPerMonthTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		System.out.println("Self Employment data in decimal - " + amount);
		enterText("Mem" + (memIndex + 1) + "SelfEmpAmountPerMonthTxt", selfEmpAmountPerMonthTxt, String.valueOf(amount));
	}

	public void enterSelfEmpEffectiveDateForMember(int memIndex, int incomeSourceIndex, String date) throws Exception {
		By incomeEffectiveDateTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].incomeEffectiveDate");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "IncomeEffectiveDateTxt", incomeEffectiveDateTxt, date);
	}

	public void enterSelfEmpHrPerWeekForMember(int memIndex, int incomeSourceIndex, int hrs) throws Exception {
		By seHrsPerWeekTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].hoursPerWeek");
		enterText("Mem" + (memIndex + 1) + "SEHrsPerWeekTxt", seHrsPerWeekTxt, hrs + "");
	}

	// ############# Self Employment Details END ################################

	// ############# SSB Details Start ################################
	
	public void enterSocialSecurityBenefitsAmount(int memIndex, int incomeSourceIndex, int socialSecurityBenefitsAmount) throws Exception {
		By socialSecurityBenefitsAmountTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		clearAndType("Mem" + (memIndex + 1) + "SocialSecurityBenefitsAmountTxt", socialSecurityBenefitsAmountTxt, socialSecurityBenefitsAmount + "");
	}

	public void selectSocialSecurityBenefitsAmountFrequency(int memIndex, int incomeSourceIndex, String socialSecurityBenefitsAmountFrequency) throws Exception {
		By socialSecurityBenefitsAmountFrequencyDD = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].frequency");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "SocialSecurityBenefitsAmountFrequencyDD", socialSecurityBenefitsAmountFrequencyDD, socialSecurityBenefitsAmountFrequency);
	}
	// ############# SSB Details END ################################

	// ############# Capital Gain Details Start ################################
	
	public void enterCapitalGainsMonthAmount(int memIndex, int incomeSourceIndex, int capitalGainsMonthAmount) throws Exception {
		By capitalGainsMonthAmountTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		enterText("Mem" + (memIndex + 1) + "CapitalGainsMonthAmountTxt", capitalGainsMonthAmountTxt, capitalGainsMonthAmount + "");
	}

	// Brajesh - Capital Gain correction for monthly amount in decimal
	public void enterCapitalGainsMonthAmountWithDecimals(int memIndex, int incomeSourceIndex, double amount) throws Exception {
		By capitalGainsMonthAmountTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		Double cGainIncome = (double) amount;
		Double cGIncomedouble = cGainIncome / 12;
		cGIncomedouble = (Math.round(cGIncomedouble * 100.0) / 100.0);
		String cGAmount = Double.toString(cGIncomedouble);
		System.out.println("Self Employment data in decimal - " + cGIncomedouble);
		enterText("Mem" + (memIndex + 1) + "SelfEmpAmountPerMonthTxt", capitalGainsMonthAmountTxt, cGAmount);
	}

	public void enterCapitalGainsYearlyAmount(int memIndex, int incomeSourceIndex, double capitalGainsYearlyAmount) throws Exception {
		By capitalGainsYearlyAmountTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amountExpectedYearly");
		enterText("Mem" + (memIndex + 1) + "CapitalGainsYearlyAmountTxt", capitalGainsYearlyAmountTxt, capitalGainsYearlyAmount + "");
	}

	// ############# Capital Gain Details End ################################

	// ############# Interest Dividend Details Start ################################
	
	public void enterInterestDividendsOtherInvestmentAmount(int memIndex, int incomeSourceIndex, int InterestDividendsOtherInvestment) throws Exception {
		By interestDividendsOtherInvestmentTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		enterText("Mem" + (memIndex + 1) + "InterestDividendsOtherInvestmentTxt", interestDividendsOtherInvestmentTxt, InterestDividendsOtherInvestment + "");
	}

	public void selectInterestDividendsOtherInvestmentFrequency(int memIndex, int incomeSourceIndex, String interestDividendsOtherInvestmentFrequency) throws Exception {
		By interestDividendsOtherInvestmentFrequencyDD = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].frequency");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "InterestDividendsOtherInvestmentFrequencyDD", interestDividendsOtherInvestmentFrequencyDD, interestDividendsOtherInvestmentFrequency);
	}
	// ############# Interest Dividend Details END ################################

	// ############# Unemployment Details Start ################################
	
	public void enterUnemploymentIncomeAmount(int memIndex, int incomeSourceIndex, int UnemploymentIncome) throws Exception {
		By unemploymentIncomeTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		enterText("Mem" + (memIndex + 1) + "UnemploymentIncomeTxt", unemploymentIncomeTxt, UnemploymentIncome + "");
	}

	public void selectUnemploymentIncomeFrequency(int memIndex, int incomeSourceIndex, String unemploymentIncome) throws Exception {
		By unemploymentIncomeDD = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].frequency");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "UnemploymentIncomeDD", unemploymentIncomeDD, unemploymentIncome);
	}
	// ############# Unemployment Details END ################################

	// ############# Retirement Details Start ################################
	public void enterRetirementOrPensionSource(int memIndex, int incomeSourceIndex, String retirementOrPensionSource) throws Exception {
		By retirementOrPensionSourceTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].retirementSource");
		enterText("Mem" + (memIndex + 1) + "RetirementOrPensionSourceTxt", retirementOrPensionSourceTxt, retirementOrPensionSource);
	}

	public void enterRetirementOrPensionAmount(int memIndex, int incomeSourceIndex, int retirementOrPension) throws Exception {
		By retirementOrPensionTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		enterText("Mem" + (memIndex + 1) + "RetirementOrPensionTxt", retirementOrPensionTxt, retirementOrPension + "");
	}

	public void selectRetirementOrPensionFrequency(int memIndex, int incomeSourceIndex, String retirementOrPension) throws Exception {
		By retirementOrPensionDD = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].frequency");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "RetirementOrPensionDD", retirementOrPensionDD, retirementOrPension);
	}

	// ############# Retirement Details END ################################

	// ############# Rental or Royalty Details Start ################################
	
	public void selectRentalRoyaltyAmountType(int memIndex, int incomeSourceIndex, boolean profitLossValue) throws Exception {
		By amountTypeRdBtn = By.xpath("//input[@name ='eligibilityMember[0].eligibilityMemberIncome.eligibilityMemberIncomeSources[0].isLoss' and @value ='" + profitLossValue + "']");
		clickOnElement("Mem" + (memIndex + 1) + "HasInomeRdBtn", amountTypeRdBtn);
	}

	public void enterRentalRoyaltyProfitAmountPerMonth(int memIndex, int incomeSourceIndex, int profitAmountPerMonth) throws Exception {
		By profitAmountPerMonthTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		clearAndType("Mem" + (memIndex + 1) + "profitAmountPerMonthTxt", profitAmountPerMonthTxt, profitAmountPerMonth + "");
	}

	public void selectRentalOrRoyaltyAmountFrequency(int memIndex, int incomeSourceIndex, String frequency) throws Exception {
		By howMemGetThisAmountDD = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].frequency");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "howMemGetThisAmountDD", howMemGetThisAmountDD, frequency);
	}
	// ############# Rental or Royalty Details END ################################

	// ############# Farming Fishing Details Start ################################
	
	public void enterFarmingOrFishingAmount(int memIndex, int incomeSourceIndex, int farmingAndFishingAmount) throws Exception {
		By farmingAndFishingAmountTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		clearAndType("Mem" + (memIndex + 1) + "farmingAndFishingAmountTxt", farmingAndFishingAmountTxt, farmingAndFishingAmount + "");
	}

	public void enterFarmingOrFishingIncomeEffectiveDateForMember(int memIndex, int incomeSourceIndex, String date) throws Exception {
		By incomeEffectiveDateTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].incomeEffectiveDate");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "IncomeEffectiveDateTxt", incomeEffectiveDateTxt, date);
	}

	public void selectFarmingOrFishingAmountFrequency(int memIndex, int incomeSourceIndex, String farmingOrFishingAmountFrequency) throws Exception {
		By farmingOrFishingAmountFrequencyDD = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].frequency");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "farmingOrFishingAmountFrequencyDD", farmingOrFishingAmountFrequencyDD, farmingOrFishingAmountFrequency);
	}

	// ############# Farming Fishing Details END ################################

	// ############# Alimony RECEIVED Details Start ################################

	public void enterAlimonyAmount(int memIndex, int incomeSourceIndex, int alimonyamount) throws Exception {
		By alimonyAmountTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		clearAndType("Mem" + (memIndex + 1) + "alimonyAmountTxt", alimonyAmountTxt, alimonyamount + "");
	}

	public void selectAlimonyAmountFrequency(int memIndex, int incomeSourceIndex, String frequency) throws Exception {
		By alimonyAmountFrequencyDD = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].frequency");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "alimonyAmountFrequencyDD ", alimonyAmountFrequencyDD, frequency);
	}

	// ############# Alimony RECEIVED Details END ################################

	// ############## Other Income Details START ################################

	public void enterOtherIncomeAmount(int memIndex, int incomeSourceIndex, int otherIncome) throws Exception {
		By otherIncomeTxt = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].amount");
		clearAndType("Mem" + (memIndex + 1) + "otherIncomeTxt", otherIncomeTxt, otherIncome + "");
	}

	public void selectOtherIncomeAmountFrequency(int memIndex, int incomeSourceIndex, String otherIncomeFrequency) throws Exception {
		By otherIncomeAmountFrequencyDD = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].frequency");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "otherIncomeAmountFrequencyDD ", otherIncomeAmountFrequencyDD, otherIncomeFrequency);
	}

	public void clickOnOtherIncomeTypeChkBxForMember(int memIndex, int incomeSourceIndex, String otherIncomeType) throws Exception {
		int incomeType = 0;
		String[] Type = { "Canceled Debts", "Court Awards", "Jury Duty Pay", "Other" };

		for (int i = 0; i <= 3; i++) {
			if (Type[i].equalsIgnoreCase(otherIncomeType)) {
				incomeType = i;

			}
		}
		By Otherincome = By.xpath( "//*[@id='eligibilityMember[" + memIndex + "].eligibilityMemberIncome.eligibilityMemberIncomeSources[" + incomeSourceIndex + "].otherIncomeType_" + incomeType + "']");
		clickOnElement("Mem" + (memIndex + 1) + "OtherIncomeChkBx", Otherincome);
	}

	// ############## Other Income Details END ################################

	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}

	public void takeScreenshot() throws Exception {
		takeScreenshot("CurrentIncomePage2");
	}

	public void clickOnPopupOkBtn() throws Exception {
		clickOnElement("PopupYesBtn", popupYesBtn);
	}

	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoad(0);
		clickOnSaveAndContinueBtn();
	}

	public void enterJobEmployerDetailsForMember(String displayShelteredWorkshopQuestion, int memIndex,
			int incomeSourceIndex, String evpdMode, String jobEmployerName, String jobEmployerStreetAddress,
			String jobEmployerAptUnit, String jobEmployerCity, String jobEmployerZipCode, String jobEmployerCounty,
			int jobIncomeAmount, String jobIncomeEffectiveDate, String jobIncomeFrequency, int jobIncomeHrsPerWeek,
			Boolean jobSheltered) throws Exception {
		waitForPageLoad(incomeSourceIndex);

		if (evpdMode.equalsIgnoreCase("RAC")) {
			clickOnEditEmployerName();
			clickOnPopupOkBtn();
		}
		enterEmployerNameForMember(memIndex, incomeSourceIndex, jobEmployerName);

		enterEmployerStreetAddressForMember(memIndex, incomeSourceIndex, jobEmployerStreetAddress);
		enterEmployerAptUnitNoForMember(memIndex, incomeSourceIndex, jobEmployerAptUnit);
		enterEmployerCityForMember(memIndex, incomeSourceIndex, jobEmployerCity);
		enterEmployerZipForMember(memIndex, incomeSourceIndex, jobEmployerZipCode);
		selectEmployerCountyForMember(memIndex, incomeSourceIndex, jobEmployerCounty);
		enterJobIncomeAmountForMember(memIndex, incomeSourceIndex, jobIncomeAmount);
		enterJobIncomeEffectiveDateForMember(memIndex, incomeSourceIndex, jobIncomeEffectiveDate);
		selectJobIncomeFrequencyForMember(memIndex, incomeSourceIndex, jobIncomeFrequency);
		enterJobHrPerWeekForMember(memIndex, incomeSourceIndex, jobIncomeHrsPerWeek);
		if (displayShelteredWorkshopQuestion.equalsIgnoreCase("true")) {
			selectIfJobIsShelteredForMember(memIndex, incomeSourceIndex, jobSheltered);
		}
	}

	public void clickAddOtherIncomeButton() throws Exception {
		By addOtherIncomeButton = By.id("JOB");
		clickOnElement("AddOtherIncomeButton", addOtherIncomeButton);
	}

	public void updateJobIncomeForMember(int memIndex, int incomeSourceIndex, int jobIncomeAmount) throws Exception {
		waitForPageLoad(incomeSourceIndex);
		enterJobIncomeAmountForMember(memIndex, incomeSourceIndex, jobIncomeAmount);
		takeScreenshot("Mem" + (memIndex + 1) + "JobIncome");
	}

	public void evpdEnterJobEmployerDetailsForMember(String displayShelteredWorkshopQuestion, int memIndex,
			int incomeSourceIndex, EVPD_MemData memData) throws Exception {
		waitForPageLoad(incomeSourceIndex);

		enterEmployerNameForMember(memIndex, incomeSourceIndex, memData.jobEmployerName);
		enterEmployerStreetAddressForMember(memIndex, incomeSourceIndex, memData.jobEmployerAddr.streetAddress);
		enterEmployerAptUnitNoForMember(memIndex, incomeSourceIndex, memData.jobEmployerAddr.aptUnit);
		enterEmployerCityForMember(memIndex, incomeSourceIndex, memData.jobEmployerAddr.city);
		enterEmployerZipForMember(memIndex, incomeSourceIndex, memData.jobEmployerAddr.zipCode);
		selectEmployerCountyForMember(memIndex, incomeSourceIndex, memData.jobEmployerAddr.county);
		enterJobIncomeAmountForMember(memIndex, incomeSourceIndex, memData.jobIncomeAmount);
		enterJobIncomeEffectiveDateForMember(memIndex, incomeSourceIndex, memData.jobIncomeEffectiveDate);
		selectJobIncomeFrequencyForMember(memIndex, incomeSourceIndex, memData.jobIncomeFrequency);
		enterJobHrPerWeekForMember(memIndex, incomeSourceIndex, memData.jobIncomeHrsPerWeek);

		if (displayShelteredWorkshopQuestion.equalsIgnoreCase("true")) {
			selectIfJobIsShelteredForMember(memIndex, incomeSourceIndex, memData.jobSheltered);
		}
		takeScreenshot("Mem" + (memIndex + 1) + "JobIncome");
	}

	public void racEnterJobEmployerDetailsForMember(String displayShelteredWorkshopQuestion, int memIndex, int incomeSourceIndex, RAC_MemData memData) throws Exception {
		waitForPageLoad(incomeSourceIndex);

		enterEmployerNameForMember(memIndex, incomeSourceIndex, memData.jobEmployerName);
		enterEmployerStreetAddressForMember(memIndex, incomeSourceIndex, memData.jobEmployerAddr.streetAddress);
		enterEmployerAptUnitNoForMember(memIndex, incomeSourceIndex, memData.jobEmployerAddr.aptUnit);
		enterEmployerCityForMember(memIndex, incomeSourceIndex, memData.jobEmployerAddr.city);
		enterEmployerZipForMember(memIndex, incomeSourceIndex, memData.jobEmployerAddr.zipCode);
		selectEmployerCountyForMember(memIndex, incomeSourceIndex, memData.jobEmployerAddr.county);
		enterJobIncomeAmountForMember(memIndex, incomeSourceIndex, memData.jobIncomeAmount);
		enterJobIncomeEffectiveDateForMember(memIndex, incomeSourceIndex, memData.jobIncomeEffectiveDate);
		selectJobIncomeFrequencyForMember(memIndex, incomeSourceIndex, memData.jobIncomeFrequency);
		enterJobHrPerWeekForMember(memIndex, incomeSourceIndex, memData.jobIncomeHrsPerWeek);

		if (displayShelteredWorkshopQuestion.equalsIgnoreCase("true")) {
			selectIfJobIsShelteredForMember(memIndex, incomeSourceIndex, memData.jobSheltered);
		}
		takeScreenshot("Mem" + (memIndex + 1) + "JobIncome");
	}

	/*
	 * 9/24/2018 Ritu
	 */
	public void enterSelfEmpEmployerDetailsForMember(int memIndex, int incomeSourceIndex, Boolean isLoss, String selfEmpWorkType, int selfEmpProfitAmountMonthly, String selfEmpEffectiveDate, int selfEmpHrsPerWeek) throws Exception {
		verifySelfEmploymentLabelForMember(incomeSourceIndex);
		selectSelfEmpProfitLossForMember(memIndex, incomeSourceIndex, isLoss);
		enterSelfEmpWorkTypeForMember(memIndex, incomeSourceIndex, selfEmpWorkType);
		enterSelfEmpAmountPerMonthForMember(memIndex, incomeSourceIndex, selfEmpProfitAmountMonthly);
		enterSelfEmpEffectiveDateForMember(memIndex, incomeSourceIndex, selfEmpEffectiveDate);
		enterSelfEmpHrPerWeekForMember(memIndex, incomeSourceIndex, selfEmpHrsPerWeek);
	}

	public void evpdEnterSelfEmpEmployerDetailsForMember(int memIndex, int incomeSourceIndex, EVPD_MemData memData) throws Exception {
		verifySelfEmploymentLabelForMember(incomeSourceIndex);
		enterSelfEmpWorkTypeForMember(memIndex, incomeSourceIndex, memData.selfEmpWorkType);
		enterSelfEmpAmountForMember(memIndex, incomeSourceIndex, memData.selfEmpProfitAmountMonthly);
		enterSelfEmpEffectiveDateForMember(memIndex, incomeSourceIndex, memData.selfEmpEffectiveDate);
		enterSelfEmpHrPerWeekForMember(memIndex, incomeSourceIndex, memData.selfEmpHrsPerWeek);
	}

	public void racEnterSelfEmpEmployerDetailsForMember(int memIndex, int incomeSourceIndex, RAC_MemData memData) throws Exception {
		verifySelfEmploymentLabelForMember(incomeSourceIndex);
		enterSelfEmpWorkTypeForMember(memIndex, incomeSourceIndex, memData.selfEmpWorkType);
		enterSelfEmpAmountForMember(memIndex, incomeSourceIndex, memData.selfEmpProfitAmountMonthly);
		enterSelfEmpEffectiveDateForMember(memIndex, incomeSourceIndex, memData.selfEmpEffectiveDate);
		enterSelfEmpHrPerWeekForMember(memIndex, incomeSourceIndex, memData.selfEmpHrsPerWeek);
	}

	// Ritu
	public void enterSocialSecurityBenefitsDetailsForMember(int memIndex, int incomeSourceIndex, int ssbAmt, String ssbAmountFrequency) throws Exception {
		enterSocialSecurityBenefitsAmount(memIndex, incomeSourceIndex, ssbAmt);
		selectSocialSecurityBenefitsAmountFrequency(memIndex, incomeSourceIndex, ssbAmountFrequency);
	}

	public void evpdEnterSocialSecurityBenefitsDetailsForMember(int memIndex, int incomeSourceIndex, EVPD_MemData memData) throws Exception {
		enterSocialSecurityBenefitsDetailsForMember(memIndex, incomeSourceIndex, memData.ssbAmt, memData.ssbAmountFrequency);
	}

	public void racEnterSocialSecurityBenefitsDetailsForMember(int memIndex, int incomeSourceIndex, RAC_MemData memData) throws Exception {
		enterSocialSecurityBenefitsDetailsForMember(memIndex, incomeSourceIndex, memData.ssbAmt, memData.ssbAmountFrequency);
	}

	/* @Ritu */
	public void enterCapitalGainsDetailsForMember(int memIndex, int incomeSourceIndex, double capitalGainsMonthlyAmnt, double capitalGainsYearlyAmnt) throws Exception {
		enterCapitalGainsMonthAmountWithDecimals(memIndex, incomeSourceIndex, capitalGainsYearlyAmnt);
		enterCapitalGainsYearlyAmount(memIndex, incomeSourceIndex, capitalGainsYearlyAmnt);
	}

	public void evpdEnterCapitalGainsDetailsForMember(int memIndex, int incomeSourceIndex, EVPD_MemData memData) throws Exception {
		enterCapitalGainsDetailsForMember(memIndex, incomeSourceIndex, memData.capitalGainsMonthlyAmnt, memData.capitalGainsYearlyAmnt);
	}

	public void racEnterCapitalGainsDetailsForMember(int memIndex, int incomeSourceIndex, RAC_MemData memData) throws Exception {
		enterCapitalGainsDetailsForMember(memIndex, incomeSourceIndex, memData.capitalGainsMonthlyAmnt, memData.capitalGainsYearlyAmnt);
	}

	// Ritu
	public void enterInterestDividendsOtherInvestmentDetailsForMember(int memIndex, int incomeSourceIndex, int interestAmt, String interestAmountFrequency) throws Exception {
		enterInterestDividendsOtherInvestmentAmount(memIndex, incomeSourceIndex, interestAmt);
		selectInterestDividendsOtherInvestmentFrequency(memIndex, incomeSourceIndex, interestAmountFrequency);
	}

	public void evpdEnterInterestDividendsOtherInvestmentDetailsForMember(int memIndex, int incomeSourceIndex, EVPD_MemData memData) throws Exception {
		enterInterestDividendsOtherInvestmentDetailsForMember(memIndex, incomeSourceIndex, memData.interestAmt, memData.interestAmountFrequency);
	}

	public void racEnterInterestDividendsOtherInvestmentDetailsForMember(int memIndex, int incomeSourceIndex, RAC_MemData memData) throws Exception {
		enterInterestDividendsOtherInvestmentDetailsForMember(memIndex, incomeSourceIndex, memData.interestAmt, memData.interestAmountFrequency);
	}

	// Ritu
	public void enterUnemploymentDetailsForMember(int memIndex, int incomeSourceIndex, int unEmploymentAmt, String unEmploymentAmountFrequency) throws Exception {
		enterUnemploymentIncomeAmount(memIndex, incomeSourceIndex, unEmploymentAmt);
		selectUnemploymentIncomeFrequency(memIndex, incomeSourceIndex, unEmploymentAmountFrequency);
	}

	public void evpdEnterUnemploymentDetailsForMember(int memIndex, int incomeSourceIndex, EVPD_MemData memData) throws Exception {
		enterUnemploymentDetailsForMember(memIndex, incomeSourceIndex, memData.UnemploymentAmt, memData.UnemploymentAmountFrequency);
	}

	public void racEnterUnemploymentDetailsForMember(int memIndex, int incomeSourceIndex, RAC_MemData memData) throws Exception {
		enterUnemploymentDetailsForMember(memIndex, incomeSourceIndex, memData.UnemploymentAmt, memData.UnemploymentAmountFrequency);
	}

	// Ritu
	public void enterRetirementOrPensionDetailsForMember(int memIndex, int incomeSourceIndex, int retirementAmt, String retirementAmountFrequency) throws Exception {
		enterRetirementOrPensionAmount(memIndex, incomeSourceIndex, retirementAmt);
		selectRetirementOrPensionFrequency(memIndex, incomeSourceIndex, retirementAmountFrequency);
	}

	public void evpdEnterRetirementOrPensionDetailsForMember(int memIndex, int incomeSourceIndex, EVPD_MemData memData) throws Exception {
		enterRetirementOrPensionDetailsForMember(memIndex, incomeSourceIndex, memData.RetirementAmt, memData.RetirementAmountFrequency);
	}

	public void racEnterRetirementOrPensionDetailsForMember(int memIndex, int incomeSourceIndex, RAC_MemData memData) throws Exception {
		enterRetirementOrPensionDetailsForMember(memIndex, incomeSourceIndex, memData.RetirementAmt, memData.RetirementAmountFrequency);
	}

	// Ritu
	public void enterRentalOrRoyaltyDetailsForMember(int memIndex, int incomeSourceIndex, String royaltyAmountFrequency, boolean royaltyAmtType, int royaltyAmtPerMonth) throws Exception {
		selectRentalOrRoyaltyAmountFrequency(memIndex, incomeSourceIndex, royaltyAmountFrequency);
		enterRentalRoyaltyProfitAmountPerMonth(memIndex, incomeSourceIndex, royaltyAmtPerMonth);
	}

	public void evpdEnterRentalOrRoyaltyDetailsForMember(int memIndex, int incomeSourceIndex, EVPD_MemData memData) throws Exception {
		enterRentalOrRoyaltyDetailsForMember(memIndex, incomeSourceIndex, memData.royaltyAmountFrequency, memData.royaltyAmtType, memData.royaltyAmtPerMonth);
	}

	public void racEnterRentalOrRoyaltyDetailsForMember(int memIndex, int incomeSourceIndex, RAC_MemData memData) throws Exception {
		enterRentalOrRoyaltyDetailsForMember(memIndex, incomeSourceIndex, memData.royaltyAmountFrequency, memData.royaltyAmtType, memData.royaltyAmtPerMonth);
	}

	// Ritu
	public void enterFarmingFishingDetailsForMember(int memIndex, int incomeSourceIndex, String farmingDate, int farmingAmount, String farmingAmountFrequency) throws Exception {
		enterFarmingOrFishingIncomeEffectiveDateForMember(memIndex, incomeSourceIndex, farmingDate);
		enterFarmingOrFishingAmount(memIndex, incomeSourceIndex, farmingAmount);
		selectFarmingOrFishingAmountFrequency(memIndex, incomeSourceIndex, farmingAmountFrequency);
	}

	public void evpdEnterFarmingFishingDetailsForMember(int memIndex, int incomeSourceIndex, EVPD_MemData memData) throws Exception {
		enterFarmingFishingDetailsForMember(memIndex, incomeSourceIndex, memData.farmingDate, memData.farmingAmount, memData.farmingAmountFrequency);
	}

	public void racEnterFarmingFishingDetailsForMember(int memIndex, int incomeSourceIndex, RAC_MemData memData) throws Exception {
		enterFarmingFishingDetailsForMember(memIndex, incomeSourceIndex, memData.farmingDate, memData.farmingAmount, memData.farmingAmountFrequency);
	}

	// Ritu
	public void enterAlimonyDetailsForMember(int memIndex, int incomeSourceIndex, int alimonyAmt, String alimonyAmountFrequency) throws Exception {
		enterAlimonyAmount(memIndex, incomeSourceIndex, alimonyAmt);
		selectAlimonyAmountFrequency(memIndex, incomeSourceIndex, alimonyAmountFrequency);
	}

	public void evpdEnterAlimonyDetailsForMember(int memIndex, int incomeSourceIndex, EVPD_MemData memData) throws Exception {
		enterAlimonyDetailsForMember(memIndex, incomeSourceIndex, memData.AlimonyAmt, memData.AlimonyAmountFrequency);
	}

	public void racEnterAlimonyDetailsForMember(int memIndex, int incomeSourceIndex, RAC_MemData memData) throws Exception {
		enterAlimonyDetailsForMember(memIndex, incomeSourceIndex, memData.AlimonyAmt, memData.AlimonyAmountFrequency);
	}

	// Ritu
	public void enterOtherIncomeDetailsForMember(int memIndex, int incomeSourceIndex, int otherIncomeAmt, String otherIncomeAmountFrequency, String otherIncomeType) throws Exception {
		enterOtherIncomeAmount(memIndex, incomeSourceIndex, otherIncomeAmt);
		selectOtherIncomeAmountFrequency(memIndex, incomeSourceIndex, otherIncomeAmountFrequency);
		clickOnOtherIncomeTypeChkBxForMember(memIndex, incomeSourceIndex, otherIncomeType);

	}

	public void evpdEnterOtherIncomeDetailsForMember(int memIndex, int incomeSourceIndex, EVPD_MemData memData, String otherIncomeDataType) throws Exception {
		enterOtherIncomeDetailsForMember(memIndex, incomeSourceIndex, memData.otherIncomeAmt, memData.otherIncomeAmountFrequency, memData.otherIncomeType);
	}

	public void racEnterOtherIncomeDetailsForMember(int memIndex, int incomeSourceIndex, RAC_MemData memData, String otherIncomeDataType) throws Exception {
		enterOtherIncomeDetailsForMember(memIndex, incomeSourceIndex, memData.otherIncomeAmt, memData.otherIncomeAmountFrequency, memData.otherIncomeType);
	}

}
