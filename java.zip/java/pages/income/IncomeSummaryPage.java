package pages.income;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import enums.IncomeType;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class IncomeSummaryPage extends CommonPage implements CommonPageOR {
	
	private static final By incomeSummaryPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Income Summary')]");
	
	public IncomeSummaryPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("IncomeSummaryPageHeader", incomeSummaryPageHeader, 5);
	}
	
	public void validateMonthlyCapitalGainForMember(int memIndex, String expCapitalGain) throws Exception{
		By capitalGainLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Capital Gain')]");
		validateTextContains("Mem"+(memIndex+1)+"CapitalGain", capitalGainLabel, expCapitalGain);
	}
	
	public void validateYearlyFarmingOrFishingForMember(int memIndex, String farmingOrFishing) throws Exception{
		By farmingOrFishingLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Farming or Fishing')]");
		validateTextContains("Mem"+(memIndex+1)+"FarmingOrFishing", farmingOrFishingLabel, farmingOrFishing);
	}
	
	public void validateYearlyInterestDividendsForMember(int memIndex, String interestDividends) throws Exception{
		By interestDividendsLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Interest, Dividends')]");
		validateTextContains("Mem"+(memIndex+1)+"InterestDividends", interestDividendsLabel, interestDividends);
	}

	public void validateYearlyJobForMember(int memIndex, String job) throws Exception{
		By jobLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Job')]");
		validateTextContains("Mem"+(memIndex+1)+"Job", jobLabel, job);
	}
	
	public void validateYearlyRentalRoyaltyForMember(int memIndex, String rentalRoyalty) throws Exception{
		By rentalRoyaltyLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Rental or Royalty')]");
		validateTextContains("Mem"+(memIndex+1)+"RentalRoyalty", rentalRoyaltyLabel, rentalRoyalty);
	}
	
	public void validateYearlySelfEmploymentForMember(int memIndex, String selfEmployment) throws Exception{
		By selfEmploymentLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Self-Employment')]");
		validateTextContains("Mem"+(memIndex+1)+"selfEmployment", selfEmploymentLabel, selfEmployment);
	}
	
	public void validateYearlySSBForMember(int memIndex, String SSB) throws Exception{
		By sSBLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Social Security')]");
		validateTextContains("Mem"+(memIndex+1)+"SSB", sSBLabel, SSB);
	}
	
	public void validateYearlyAlimonyForMember(int memIndex, String Alimony) throws Exception{
		By alimonyLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Alimony')]");
		validateTextContains("Mem"+(memIndex+1)+"Alimony", alimonyLabel, Alimony);
	}
	
	public void validateYearlyOtherIncomeForMember(int memIndex, String OtherIncome) throws Exception{
		By otherLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Other Income')]");
		validateTextContains("Mem"+(memIndex+1)+"OtherIncome", otherLabel, OtherIncome);
	}
	
	public void validateYearlyRetirementForMember(int memIndex, String retirement) throws Exception{
		By retirementLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Retirement')]");
		validateTextContains("Mem"+(memIndex+1)+"Retirement", retirementLabel, retirement);
	}
	
	public void validateYearlyUnemploymentForMember(int memIndex, String unemployment) throws Exception{
		By unemploymentLabel = By.xpath("//div[@id='shopEmployerDetails']//div["+(memIndex+1)+"]/ul[1]/li[contains(.,'Unemployment')]");
		validateTextContains("Mem"+(memIndex+1)+"Unemployment", unemploymentLabel, unemployment);
	}
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn, 3);
	}
	
	public void takeScreenshot() throws Exception {
		takeScreenshot("IncomeSurrmayPage");
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		takeScreenshot();
		clickOnSaveAndContinueBtn();
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn(boolean faReqd) throws Exception{
		if(faReqd){
			waitForPageLoaded();
			takeScreenshot("Summary");
			clickOnSaveAndContinueBtn();
		}
	}
	
	public void validateIncomeThenClickOnSaveAndContinueBtn(boolean faReqd, List<EVPD_MemData> memsData) throws Exception{
		if(faReqd){
			waitForPageLoaded();
			int memCount = memsData.size();
			for(int mCounter=0; mCounter<memCount; mCounter++){
				
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.JOB.val)){
					validateYearlyJobForMember(mCounter, memsData.get(mCounter).jobIncomeAmount+"");
				}
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.SELF_EMPLOYMENT.val)){
					validateYearlySelfEmploymentForMember(mCounter, memsData.get(mCounter).selfEmpProfitAmountMonthly+"");
				}
				
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.SOCIAL_SECURITY_BENEFITS.val)){
					validateYearlySSBForMember(mCounter, memsData.get(mCounter).ssbAmt+"");
				}
				
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.UNEMPLOYMENT.val)){
					validateYearlyUnemploymentForMember(mCounter, memsData.get(mCounter).UnemploymentAmt+"");
				}
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.RETIREMENT.val)){
					validateYearlyRetirementForMember(mCounter, memsData.get(mCounter).RetirementAmt+"");
				}
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.CAPITALGAINS.val)){
					validateMonthlyCapitalGainForMember(mCounter, memsData.get(mCounter).capitalGainsMonthlyAmnt+"");
				}
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.INVESTMENT_INCOME.val)){
					validateYearlyInterestDividendsForMember(mCounter, memsData.get(mCounter).interestAmt+"");
				}
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.RENTAL_OR_ROYALTY_INCOME.val)){
					validateYearlyRentalRoyaltyForMember(mCounter, memsData.get(mCounter).royaltyAmtPerMonth+"");
				}
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.FARMING_OR_FISHING_INCOME.val)){
					validateYearlyFarmingOrFishingForMember(mCounter, memsData.get(mCounter).farmingAmount+"");
				}
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.ALIMONY_RECEIVED.val)){
					validateYearlyAlimonyForMember(mCounter, memsData.get(mCounter).AlimonyAmt+"");
				}
				if(memsData.get(mCounter).incomeTypes.contains(IncomeType.OTHER_INCOME.val)){
					validateYearlyOtherIncomeForMember(mCounter, memsData.get(mCounter).otherIncomeAmt+"");
				}
				
			}
			
			takeScreenshot("Summary");
			clickOnSaveAndContinueBtn();
		}
		
	}

	// ppinho
	public void evpdClickOnSaveAndContinueBtn(boolean faReqd) throws Exception{
		if(faReqd){
			takeScreenshot("Summary");
			clickOnSaveAndContinueBtn();
		}
	}	
	
	// ppinho
	public void racClickOnSaveAndContinueBtn(boolean faReqd) throws Exception{
		if(faReqd){
			takeScreenshot("Summary");
			clickOnSaveAndContinueBtn();
		}
	}
}
