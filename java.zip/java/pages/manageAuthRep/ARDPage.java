package pages.manageAuthRep;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;

public class ARDPage extends CommonPage {
	static final By saveBtn = By.id("saveButton");
	static final By activateBtn = By.id("activateButton");
	static final By deactivateBtn = By.id("deactivateButton");
	
	public ARDPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private static final By eadPageHeader = By.xpath("//h1[contains(.,'Enrollment Assister Details')]");

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("EadPageHeader", eadPageHeader);
	}

	public void checkHelpFromAssister() throws Exception {
		By assisterBy = By.id("eligibilityMembers1");
		clickOnElement("assister", assisterBy);
	}

	public void selectDesignation(String desig) throws Exception {
		By designaton = By.id("designation");
		selectDropDownElementByVisibleText("designation", designaton, desig);
	}

	public void enterFirstName(String firstName) throws Exception {
		By firstNameBy = By.id("authorizedRepresentative.contactInfo.firstName");
		enterText("firstName", firstNameBy, firstName);
	}

	public void enterLastName(String lastName) throws Exception {
		By lastNameBy = By.id("authorizedRepresentative.contactInfo.lastName");
		enterText("lastName", lastNameBy, lastName);
	}

	public void enterStreetAddress(String streetAddress) throws Exception {
		By streetAddressBy = By.id("authorizedRepresentative.contactInfo.primaryAddress.streetAddress1");
		enterText("streetAddress", streetAddressBy, streetAddress);
	}

	public void enterCity(String city) throws Exception {
		By cityBy = By.id("authorizedRepresentative.contactInfo.primaryAddress.city");
		enterText("city", cityBy, city);
	}

	public void enterZipCode(String zipCode) throws Exception {
		By zipCodeBy = By.id("authorizedRepresentative.contactInfo.primaryAddress.zip");
		clearAndType("zipCode", zipCodeBy, zipCode);
	}

	public void selectCounty(String county) throws Exception {
		By countyBy = By.id("authorizedRepresentative.contactInfo.primaryAddress.county");
		selectByVisibleTextAfterWait("county", countyBy, county);
	}

	public void enterPhoneNumber(String phoneNumber) throws Exception {
		By phoneNumberBy = By.id("userProfile.contactInfo.primaryPhoneNumber_0");
		clearAndType("phoneNumber", phoneNumberBy, phoneNumber);
	}

	public void enterFromDate(String fromDate) throws Exception {
		By fromDateBy = By.id("authorityFrom");
		clearAndType("authorityFrom", fromDateBy, fromDate);
	}

	public void enterPhoneType(String phoneType) throws Exception {
		By phoneTypeBy = By.id("primaryPhoneType");
		selectDropDownElementByVisibleText("phoneType", phoneTypeBy, phoneType);
	}

	public void enterSignature(String signature) throws Exception {
		By signatureBy = By.id("signature");
		clearAndType("signature", signatureBy, signature);
	}

	public void checkSignatureRec() throws Exception {
		By checkSignBy = By.id("signatureReceived");
		clickOnElement("signatureReceived", checkSignBy);
	}

	public void clickOnSaveBtn() throws Exception {
		clickOnElement("SaveBtn", saveBtn);
	}

	public void clickOnActivateBtn() throws Exception {
		clickOnElement("ActivateBtn", activateBtn);
	}
	
	//Ritu
	public void clickOnDeActivateBtn() throws Exception {
        clickOnElement("DeActivateBtn", deactivateBtn);
	}
	
	


	public void enterArdDetails(String desig, String firstName, String lastName, String streetAddress, String city,
			String zipCode, String county, String phoneNumber, String phoneType, String signature, String fromDate)
			throws Exception {
		waitForPageLoaded();
		checkHelpFromAssister();
		selectDesignation(desig);
		enterFirstName(firstName);
		enterLastName(lastName);
		enterStreetAddress(streetAddress);
		enterCity(city);
		enterZipCode(zipCode);
		selectCounty(county);
		enterPhoneNumber(phoneNumber);
		enterPhoneType(phoneType);
		enterFromDate(fromDate);
		enterSignature(signature);
		checkSignatureRec();
		clickOnSaveBtn();
		// clickOnActivateBtn();

	}
	
	public void HelpFromAssisterChkBox(int memCount) throws Exception {
	       
        By assisterChkBox =  By.id("eligibilityMembers"+memCount);
        clickOnElement("HelpFromAssisterChkBox", assisterChkBox);
  }

	public void enterArdDetailsForMember(int memNo ,String designationType,String firstName, String lastName, String streetAddress, String city, String zipCode, String county, String phoneNumber,
               String phoneType,String signature, String effectivestartDate
               )
               throws Exception {
        waitForPageLoaded();
        for(int memCount=1;memCount<=memNo ;memCount++)
        {      
        HelpFromAssisterChkBox(memCount);
        }
        selectDesignation(designationType);
        enterFirstName(firstName);
        enterLastName(lastName);
        enterStreetAddress(streetAddress);
        enterCity(city);
        enterZipCode(zipCode);
        selectCounty(county);
        enterPhoneNumber(phoneNumber);
        enterPhoneType(phoneType);
        enterFromDate(effectivestartDate);
        enterSignature(signature);
        checkSignatureRec();
        //clickOnSaveBtn();
        clickOnActivateBtn();

  }

}
