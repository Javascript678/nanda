package pages.manageAuthRep;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

public class ManageAuthRepPage extends CommonPage implements CommonPageOR {
	public ManageAuthRepPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private static final By manageAuthRepPageHeader = By.xpath("//h1[contains(.,'Is someone helping you?')]");

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("ManageAuthRepPageHeader", manageAuthRepPageHeader);
	}

	public void clickOnEnrollmentAssister() throws Exception {
		waitForPageLoaded();
		By enrollAssisLink = By.xpath("//*[@id='authRepDiv']/a");
		clickOnElement("EnrollmentAssister", enrollAssisLink);
	}
	
	//Ritu
	public void clickOnManageBtn(String type,String Date) throws Exception {
        waitForPageLoaded();
        By enrollAssisLink = By.xpath("//table [@id='authorizedRepresentativesTable']/thead//th[contains(.,'Begin Date')]/../../following-sibling::tbody/tr/td[contains(.,'"+Date+"') ]/following-sibling::td[contains(.,'"+type+"')]/following-sibling::td/button/span[contains(.,'Manage')]");
        clickOnElement("EnrollmentAssister", enrollAssisLink);
	}
}
