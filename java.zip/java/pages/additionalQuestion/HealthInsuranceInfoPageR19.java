package pages.additionalQuestion;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import enums.InsurancePolicySource;
import enums.InsurancePolicySourceR19;
import enums.Race;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class HealthInsuranceInfoPageR19 extends CommonPage implements CommonPageOR{
	
	private static final By healthInsuranceInfoPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Health Insurance Information')]");
	
	public HealthInsuranceInfoPageR19(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("HealthInsuranceInfoPageHeader", healthInsuranceInfoPageHeader);
	}
	
	public void validatePageTitleDontContainsName(String fullName) throws Exception {
		String actualTitle = getCurrentPageTitle();
		validateTextNotContains("HealthInsuranceInfoPageTitle", actualTitle, fullName);
	}
	
	//updated
	public void selectIfOfferedThroughJobForMember(int memIndex, boolean trueFalseValue) throws Exception{
		By offeredThroughJobRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.jobCoverageInCoverageYear' and @value='"+trueFalseValue+"']/../label");		
	clickOnElement("Mem"+(memIndex+1)+"OfferedThroughJobRdBtn",offeredThroughJobRdBtn);
	}
	
	public void clickOnESICoverageDateNotKnownChkBxForMember(int memIndex) throws Exception{
		By esiCoverageDateNotKnownChkBx = By.name("eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.coverageDateNotKnown");
		clickOnElement("Mem"+(memIndex+1)+"ESICoverageDateNotKnownChkBx", esiCoverageDateNotKnownChkBx);		
	}
	
	public void selectESIEmployerNameForMember(int memIndex, String employerName) throws Exception{
		By esiEmployerNameDD = By.name("eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].employerName");
		selectDropDownElementByVisibleText("Mem"+(memIndex+1)+"ESIEmployerNameDD", esiEmployerNameDD, employerName);		
	}
	
	public void enterPrimaryPhoneNo(int memIndex, String phoneNo)throws Exception{
		By primaryPhnoTxt = By.id("eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryPhoneNumber_phone_no_1_0");
		clearAndTypeAfterWait("Mem"+(memIndex+1)+ "ESIEmployerPrimaryPhnoTxt" , primaryPhnoTxt,phoneNo);
	}
	
	public void enterSecondaryPhoneNo(int memIndex, String phoneNo)throws Exception{
		By secondaryPhnoTxt = By.id("eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactPerson.primaryPhoneNumber_phone_no_2_0");
		clearAndTypeAfterWait("Mem"+(memIndex+1)+ "ESIEmployerSecondaryPhnoTxt" , secondaryPhnoTxt,phoneNo);
	}
	
	//updated
	public void selectHealthCoverageChkBxForMember(int memIndex, String otherHltInsuranceRetiral) throws Exception {		
		By retirementPlanChkBx = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.retirementPlanInCoverageYear' and @value='" + otherHltInsuranceRetiral + "']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "OtherHealthInsunaceRetiralCheckBx:" + otherHltInsuranceRetiral, retirementPlanChkBx);	
	
	}
	
//----------------------------COBRA and Retiree Health Insurance ---------------------------------------//
 //Ritika  
	
	public void enterCOBRA_RHI_EmployerNameForMember(int memIndex, String employerName)throws Exception{
		By employerNameTxt = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].employerName']");
		clearAndType("Mem"+(memIndex+1)+ "EmployerNameTxt" , employerNameTxt,employerName);
	}
	
	public void enterCOBRA_RHI_PrimaryAddressStreetForMember(int memIndex, String street) throws Exception{
		By memPrimaryAddressStr1	= By.xpath("//div[@class='form-group']//input[@name='eligibilityMember["+ memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryAddress.streetAddress1']");
		clearAndType("Mem"+ (memIndex+1) + "PrimaryAddressStr1" , memPrimaryAddressStr1, street);
	}
	public void enterCOBRA_RHI_PrimaryCityForMember(int memIndex, String city) throws Exception{
		By memPrimaryCity	= By.xpath("//div[@class='form-group']//input[@name='eligibilityMember["+ memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryAddress.city']");
		clearAndType("Mem"+ (memIndex+1) + "PrimaryCity" , memPrimaryCity, city);
	}
	public void enterCOBRA_RHI_PrimaryZipForMember(int memIndex, String zipCode) throws Exception{
		By memPrimaryZip	= By.xpath("//div[@class='form-group']//input[@name='eligibilityMember["+ memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryAddress.zip']");
		clearAndType("Mem"+ (memIndex+1) + "PrimaryZip" , memPrimaryZip, zipCode);
	}
	
	public void selectCOBRA_RHI_PrimaryCountyForMember(int memIndex, String county) throws Exception{
		By memPrimaryCounty	= By.xpath("//div[@class='form-group']//select[@name='eligibilityMember["+ memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryAddress.county']");
		selectByVisibleTextAfterWait("Mem"+ (memIndex+1) + "PrimaryCounty" , memPrimaryCounty, county);

	}
	
	public void enterCOBRARetireePrimaryPhoneNo(int memIndex, String phoneNo)throws Exception{
		By primaryPhnoTxt = By.xpath("//div[@class='form-group']//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryPhoneNumber_phone_no_1_0']");
		clearAndTypeAfterWait("Mem"+(memIndex+1)+ "ESIEmployerPrimaryPhnoTxt" , primaryPhnoTxt,phoneNo);
	}
	
	public void enterCOBRARetireeSecondaryPhoneNo(int memIndex, String phoneNo)throws Exception{
		By secondaryPhnoTxt = By.xpath("//div[@class='form-group']//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactPerson.primaryPhoneNumber_phone_no_2_0']");
		clearAndTypeAfterWait("Mem"+(memIndex+1)+ "ESIEmployerSecondaryPhnoTxt" , secondaryPhnoTxt,phoneNo);
	}
	
/*-----------COBRA and Retiree Health Insurance Ends-----------------*/
	
	
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void selectESIDetailsForMember(int memIndex,String jobEmployerName,
			String employerPrimarnyPhoneNo,
			String employerSecondaryPhoneNo)throws Exception{
		
		selectIfOfferedThroughJobForMember(memIndex, true);
		clickOnESICoverageDateNotKnownChkBxForMember(memIndex);
		selectESIEmployerNameForMember(memIndex, jobEmployerName);
		enterPrimaryPhoneNo(memIndex, employerPrimarnyPhoneNo);
		enterSecondaryPhoneNo(memIndex, employerSecondaryPhoneNo);
	}	
	
	public void selectCOBRARetireeHealthInsuranceInfoForMember(int memIndex, EVPD_MemData memData) throws Exception
	{
		enterCOBRA_RHI_EmployerNameForMember(memIndex, memData.otherHltInsuranceEmployerName);
		enterCOBRA_RHI_PrimaryAddressStreetForMember(memIndex, memData.otherHltInsuranceEmployerAddr.streetAddress);
		enterCOBRA_RHI_PrimaryCityForMember(memIndex, memData.otherHltInsuranceEmployerAddr.city);
		enterCOBRA_RHI_PrimaryZipForMember(memIndex, memData.otherHltInsuranceEmployerAddr.zipCode);
		selectCOBRA_RHI_PrimaryCountyForMember(memIndex, memData.otherHltInsuranceEmployerAddr.county);
		enterCOBRARetireePrimaryPhoneNo(memIndex, memData.employerPrimaryPhoneNo);
		enterCOBRARetireeSecondaryPhoneNo(memIndex, memData.employerSecondaryPhoneNo);
	}
	
	public void selectHealthInsuranceInfoForMember(int memIndex, EVPD_MemData memData) throws Exception{
		waitForPageLoaded();
		selectIfOfferedThroughJobForMember(memIndex, memData.enrolledInESI);
		
		if(memData.enrolledInESI ){
			selectESIDetailsForMember(memIndex, memData.jobEmployerName, memData.employerPrimaryPhoneNo, memData.employerSecondaryPhoneNo);
		}else{
			if(memData.enrolledInCOBRA){
				selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySource.COBRA.uiVal);
				selectCOBRARetireeHealthInsuranceInfoForMember(memIndex, memData);
			}
			
			if(memData.enrolledInRetiree){
				selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySource.RETIREE_HEALTH_PLAN.code);
				selectCOBRARetireeHealthInsuranceInfoForMember(memIndex, memData);
			}
			
			if(memData.enrolledInVeteran){
				selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySourceR19.VETERAN_HEALTH_PROGRAM.code);
			}
			
			if(memData.enrolledNoHP){
				selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySourceR19.NONE_OF_THE_ABOVE.code);
			}
			
		}
		
		clickOnSaveAndContinueBtn();
	}
	
	public void selectHealthInsuranceInfoAsNoneForMember(int memIndex) throws Exception{
		waitForPageLoaded();
		selectIfOfferedThroughJobForMember(memIndex, false);
		selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySourceR19.NONE_OF_THE_ABOVE.code);
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdEnterHealthInsuranceInformationForMembers(int memIndex, EVPD_Data evpdData) throws Exception {		
		selectIfOfferedThroughJobForMember(memIndex, evpdData.memsData.get(memIndex).enrolledInESI);
		
		if(evpdData.memsData.get(memIndex).enrolledInESI){
			selectESIDetailsForMember(memIndex, evpdData.memsData.get(memIndex).jobEmployerName, 
									  evpdData.memsData.get(memIndex).employerPrimaryPhoneNo, 
									  evpdData.memsData.get(memIndex).employerSecondaryPhoneNo);
		}else{
			if(evpdData.memsData.get(memIndex).enrolledInCOBRA){
				selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySource.COBRA.uiVal);
				selectCOBRARetireeHealthInsuranceInfoForMember(memIndex, evpdData.memsData.get(memIndex));
			}
			
			if(evpdData.memsData.get(memIndex).enrolledInRetiree){
				selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySource.RETIREE_HEALTH_PLAN.code);
				selectCOBRARetireeHealthInsuranceInfoForMember(memIndex, evpdData.memsData.get(memIndex));
			}
			
			if(evpdData.memsData.get(memIndex).enrolledInVeteran){
				selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySourceR19.VETERAN_HEALTH_PROGRAM.code);
			}
			
			if(evpdData.memsData.get(memIndex).enrolledNoHP){
				selectHealthCoverageChkBxForMember(memIndex, InsurancePolicySourceR19.NONE_OF_THE_ABOVE.code);
			}
			
		}
		
		clickOnSaveAndContinueBtn();
	}
	
}