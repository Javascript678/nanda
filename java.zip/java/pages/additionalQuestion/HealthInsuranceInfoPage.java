package pages.additionalQuestion;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_Data;
import appdata.rac.RAC_MemData;
import enums.InsurancePolicySource;
import enums.Race;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class HealthInsuranceInfoPage extends CommonPage implements CommonPageOR {

	private static final By healthInsuranceInfoPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Health Insurance Information')]");

	public HealthInsuranceInfoPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("HealthInsuranceInfoPageHeader", healthInsuranceInfoPageHeader);
	}

	public void validatePageTitleDontContainsName(String fullName) throws Exception {
		String actualTitle = getCurrentPageTitle();
		validateTextNotContains("HealthInsuranceInfoPageTitle", actualTitle, fullName);
	}

	public void selectIfOfferedThroughJobForMember(int memIndex, boolean trueFalseValue) throws Exception {
		By offeredThroughJobRdBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.jobCoverageInCoverageYear' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "OfferedThroughJobRdBtn", offeredThroughJobRdBtn);
	}

	// ---------------------------- Enrolled In Any Health Insurance  ---------------------------------------//

	public void selectIfEnrolledInAnyHealthInsurance(int memIndex, boolean trueFalseValue) throws Exception {
		By enrolledInAnyHealthInsuranceBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.isEnrolledInAnyHealthInsurance' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "EnrolledInAnyHealthInsuranceBtn", enrolledInAnyHealthInsuranceBtn);
	}

	// ---------------------------- ESI ---------------------------------------//

	public void selectESI(int memIndex) throws Exception {
		By esiChkBx = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.selectedEnrolledHealthInsurance']/../label");
		clickOnElement("Mem" + (memIndex) + "ESIchkbx", esiChkBx);
	}

	public void clickOnESI(int memIndex) throws Exception {
		By esiBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[ESI].esiHealthCoverageDTOList[0].esiType' and @value='" + InsurancePolicySource.ESI.uiVal + "']/../label");
		clickOnElement("Mem" + (memIndex) + "ESIbtn", esiBtn);
	}

	public void clickOnCOBRA(int memIndex) throws Exception {
		By conbraBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[ESI].esiHealthCoverageDTOList[0].esiType' and @value='" + InsurancePolicySource.COBRA.uiVal + "']/../label");
		clickOnElement("Mem" + (memIndex) + "COBRAbtn", conbraBtn);
	}

	public void clickOnRetireeHealthPlan(int memIndex) throws Exception {
		By retireeHealthPlanBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[ESI].esiHealthCoverageDTOList[0].esiType' and @value='" + InsurancePolicySource.RETIREE_HEALTH_PLAN.uiVal + "']/../label");
		clickOnElement("Mem" + (memIndex) + "RetireeHealthPlanBtn", retireeHealthPlanBtn);
	}

	public void selectESIEmployerName(int memIndex, String employerName) throws Exception {
		By esiEmployerNameDD = By.xpath("//select[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[ESI].esiHealthCoverageDTOList[0].employerName']/../label");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "ESIEmployerNameDD", esiEmployerNameDD,
				employerName);
	}

	public void clickOnESIDontKnownChkBxForMember(int memIndex) throws Exception {
		By esiCoverageDateNotKnownChkBx = By.name("eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[ESI].esiHealthCoverageDTOList[0].startDateNotKnown");
		clickOnElement("Mem" + (memIndex + 1) + "ESICoverageDateNotKnownChkBx", esiCoverageDateNotKnownChkBx);
	}
	
	public void selectNoHealthInsuranceForMember(int memIndex) throws Exception{
		waitForPageLoaded();
		selectIfMemberEnrolledInHealthInsuranceChkBx(memIndex, false);
		selectIfMemberOfferedAnyHealthInsuranceChkBx(memIndex, false);
		clickOnSaveAndContinueBtn();
	}
	
	public void selectNoHRAInfoForMember(int memIndex) throws Exception{
		selectIfMemberOfferedHRAChkBx(memIndex, "NO");
		clickOnSaveAndContinueBtn();
	}
	
	public void selectIfMemberEnrolledInHealthInsuranceChkBx(int memIndex,boolean trueFalseValue) throws Exception{
		By memEnrolledInHltInsuranceChkBx = By.xpath("//input[@name='eligibilityMember["+memIndex+"].mecHealthCoverageDTO.isEnrolledInAnyHealthInsurance' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem"+(memIndex+1)+"EnrolledInHealthInsuranceChkBx", memEnrolledInHltInsuranceChkBx);		
	}
	
	public void selectIfMemberOfferedAnyHealthInsuranceChkBx(int memIndex,boolean trueFalseValue) throws Exception{
		By memOfferedAnyHltInsuranceChkBx = By.xpath("//input[@name='eligibilityMember["+memIndex+"].mecHealthCoverageDTO.isOfferedAnyHealthInsurance' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem"+(memIndex+1)+"OfferedAnyHealthInsuranceChkBx", memOfferedAnyHltInsuranceChkBx);		
	}
	
	public void selectIfMemberOfferedHRAChkBx(int memIndex,String hraValue) throws Exception{
		By memOfferedHRAChkBx = By.xpath("//label[@for='eligibilityMember["+memIndex+"]."+hraValue+".isHraOffered']");
		clickOnElement("Mem"+(memIndex+1)+"HRAInfoChkBx", memOfferedHRAChkBx);		
	}


	public void enterPrimaryPhoneNo(int memIndex, String phoneNo) throws Exception {
		By primaryPhnoTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryPhoneNumber_phone_no_1_0");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "ESIEmployerPrimaryPhnoTxt", primaryPhnoTxt, phoneNo);
	}

	public void enterSecondaryPhoneNo(int memIndex, String phoneNo) throws Exception {
		By secondaryPhnoTxt = By.id("eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactPerson.primaryPhoneNumber_phone_no_2_0");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "ESIEmployerSecondaryPhnoTxt", secondaryPhnoTxt, phoneNo);
	}

	public void clickOnIsAnyExpectedChange(int memIndex, Boolean trueFalse) throws Exception {
		By isAnyexpectedChangeBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[ESI].esiHealthCoverageDTOList[0].isAnyExpectedChange' and  @value='" + trueFalse + "']/../label");
		clickOnElement("Mem" + (memIndex) + "IsAnyexpectedChangeBtn", isAnyexpectedChangeBtn);
	}

	public void clickOnNoLongerOfferCoverage(int memIndex) throws Exception {
		By noLongerOfferCoverageBtn = By.xpath("//input[@id='noLongerCoverage_1_967576879_" + memIndex + "']/../label");
		clickOnElement("Mem" + (memIndex) + "NoLongerOfferCoverageBtn", noLongerOfferCoverageBtn);
	}

	public void clickOnESIDontKnownLastDayNoLongerOfferCoverageChkBx(int memIndex) throws Exception {
		By noLongerOfferCoverageChkBx = By.xpath("//input[@id='esiHealthCoverageDTOList[" + memIndex + "].967576879noLongerCoverage_1._endCoverageDateNotKnown']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "NoLongerOfferCoverage", noLongerOfferCoverageChkBx);
	}

	public void clickOnCanceledCoverage(int memIndex) throws Exception {
		By canceledCoverageBtn = By.xpath("//input[@id='noLongerCoverage_2_967576879_" + memIndex + "']/../label");
		clickOnElement("Mem" + (memIndex) + "CanceledCoverageBtn", canceledCoverageBtn);
	}

	public void clickOnESIDontKnownLastDayCanceledCoverageChkBx(int memIndex) throws Exception {
		By canceledCoverageChkBx = By.xpath("//input[@id='esiHealthCoverageDTOList[" + memIndex + "].967576879noLongerCoverage_2._endCoverageDateNotKnown']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "CanceledCoverageChkBx", canceledCoverageChkBx);
	}

	public void clickOnMeetsMinValue(int memIndex, boolean trueFalse) throws Exception {
		By meetsMinValueBtn = By.xpath("//input[@id='employerMeetsStandardOption_1_967576879_" + memIndex + "' and @value='" + trueFalse + "']/../label");
		clickOnElement("Mem" + (memIndex) + "MeetsMinValueBtn", meetsMinValueBtn);
	}

	public void enterPlanPremiumCost(int memIndex, String planPremiumCost) throws Exception {
		By planPremiumCostTxt = By.id("esiHealthCoverageDTOList[" + memIndex + "]967576879.plan_premium_cost");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "PlanPremiumCostTxt", planPremiumCostTxt, planPremiumCost);
	}

	public void selectPlanFrequency(int memIndex, String frequency) throws Exception {
		By frequencyDD = By.id("esiHealthCoverageDTOList[" + memIndex + "]967576879.planPremiumFrequency");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "FrequencyDD", frequencyDD, frequency);
	}

	// ---------------------------- Medicare  ---------------------------------------//

	public void selectOtherHealthInsuranceMixedAsMedicare() throws Exception {
		By otherHealthInsunaceMixedAsMedicareCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='MEDICARE']/../label");
		clickOnElement("MemDeductionTypeMedicareChkBx", otherHealthInsunaceMixedAsMedicareCheckBx);
	}

	public void enterPolicyNoMemIDforMedicare(int memIndex, String polNo) throws Exception {
		By polNoTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[MEDICARE].nonESIHealthCoverageParamDTO.policyNumber']/../label");
		enterText("MedicarePolNoTxt", polNoTxt, polNo);
	}

	public void enterCoverageStartDateForMedicare(int memIndex, String covStartDate) throws Exception {
		By covStartDateTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[MEDICARE].nonESIHealthCoverageParamDTO.startDate']/../label");
		clearAndType("MedicareCovStartDate", covStartDateTxt, covStartDate);
	}

	public void enterCoverageEndDateForMedicare(int memIndex, String covEndDate) throws Exception {
		By covEndDateTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[MEDICARE].nonESIHealthCoverageParamDTO.endDate']/../label");
		clearAndType("MedicareCovEndDate", covEndDateTxt, covEndDate);
	}

	// ---------------------------- Medicaid  ---------------------------------------//

	public void selectOtherHealthInsuranceMixedAsMedicaid() throws Exception {
		By otherHealthInsunaceMixedAsMedicareCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='MEDICAID']/../label");
		clickOnElement("MemDeductionTypeMedicaidChkBx", otherHealthInsunaceMixedAsMedicareCheckBx);
	}

	public void enterPolicyNoMemIDforMedicaid(int memIndex, String polNo) throws Exception {
		By polNoTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[MEDICAID].nonESIHealthCoverageParamDTO.policyNumber']/../label");
		enterText("MedicaidPolNoTxt", polNoTxt, polNo);
	}

	public void enterCoverageStartDateForMedicaid(int memIndex, String covStartDate) throws Exception {
		By covStartDateTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[MEDICAID].nonESIHealthCoverageParamDTO.startDate']/../label");
		clearAndType("MedicaidCovStartDate", covStartDateTxt, covStartDate);
	}

	public void enterCoverageEndDateForMedicaid(int memIndex, String covEndDate) throws Exception {
		By covEndDateTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[MEDICAID].nonESIHealthCoverageParamDTO.endDate']/../label");
		clearAndType("MedicaidCovEndDate", covEndDateTxt, covEndDate);
	}

	// ---------------------------- Peace Corps  ---------------------------------------//

	public void selectOtherHealthInsuranceMixedAsPeaceCorps() throws Exception {
		By otherHealthInsunaceMixedAsMedicareCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='PCHB']/../label");
		clickOnElement("MemDeductionTypePeaceCorpsChkBx", otherHealthInsunaceMixedAsMedicareCheckBx);
	}

	public void enterPolicyNoMemIDforPeaceCorps(int memIndex, String polNo) throws Exception {
		By polNoTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[PCHB].nonESIHealthCoverageParamDTO.policyNumber']/../label");
		enterText("PeaceCorpsPolNoTxt", polNoTxt, polNo);
	}

	public void enterCoverageStartDateForPeaceCorps(int memIndex, String covStartDate) throws Exception {
		By covStartDateTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[PCHB].nonESIHealthCoverageParamDTO.startDate']/../label");
		clearAndType("PeaceCorpsCovStartDate", covStartDateTxt, covStartDate);
	}

	public void enterCoverageEndDateForPeaceCorps(int memIndex, String covEndDate) throws Exception {
		By covEndDateTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[PCHB].nonESIHealthCoverageParamDTO.endDate']/../label");
		clearAndType("PeaceCorpsCovEndDate", covEndDateTxt, covEndDate);
	}

	// ---------------------------- Tricare ---------------------------------------//

	public void selectOtherHealthInsuranceMixedAsTricare() throws Exception {
		By otherHealthInsunaceMixedAsMedicareCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='TRICARE']/../label");
		clickOnElement("MemDeductionTypeTricareChkBx", otherHealthInsunaceMixedAsMedicareCheckBx);
	}

	public void enterPolicyNoMemIDforTricare(int memIndex, String polNo) throws Exception {
		By polNoTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[TRICARE].nonESIHealthCoverageParamDTO.policyNumber']/../label");
		enterText("TricarePolNoTxt", polNoTxt, polNo);
	}

	public void enterCoverageStartDateForTricare(int memIndex, String covStartDate) throws Exception {
		By covStartDateTxt = By.xpath("//input[@name='//eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[TRICARE].nonESIHealthCoverageParamDTO.startDate']/../label");
		clearAndType("TricareCovStartDate", covStartDateTxt, covStartDate);
	}

	public void enterCoverageEndDateForTricare(int memIndex, String covEndDate) throws Exception {
		By covEndDateTxt = By.xpath("//input[@name='//eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[TRICARE].nonESIHealthCoverageParamDTO.endDate']/../label");
		clearAndType("TricareCovEndDate", covEndDateTxt, covEndDate);
	}

	// ---------------------------- Veterans Affairs ---------------------------------------//

	public void selectOtherHealthInsuranceMixedAsVA() throws Exception {
		By otherHealthInsunaceMixedAsMedicareCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='VAHP']/../label");
		clickOnElement("MemDeductionTypeVeteransAffairsChkBx", otherHealthInsunaceMixedAsMedicareCheckBx);
	}

	public void enterPolicyNoMemIDforVeteransAffairs(int memIndex, String polNo) throws Exception {
		By polNoTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[VAHP].nonESIHealthCoverageParamDTO.policyNumber']/../label");
		enterText("VeteransAffairsPolNoTxt", polNoTxt, polNo);
	}

	public void enterCoverageStartDateForVA(int memIndex, String covStartDate) throws Exception {
		By covStartDateTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[VAHP].nonESIHealthCoverageParamDTO.startDate']/../label");
		clearAndType("VeteransAffairsCovStartDate", covStartDateTxt, covStartDate);
	}

	public void enterCoverageEndDateForVA(int memIndex, String covEndDate) throws Exception {
		By covEndDateTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[VAHP].nonESIHealthCoverageParamDTO.endDate']/../label");
		clearAndType("VeteransAffairsCovEndDate", covEndDateTxt, covEndDate);
	}

	// ---------------------------- Other ---------------------------------------//

	public void selectOtherHealthInsuranceMixedAsOther() throws Exception {
		By otherHealthInsunaceMixedAsMedicareCheckBx = By
				.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='OTHER']/../label");
		clickOnElement("MemDeductionTypeOtherChkBx", otherHealthInsunaceMixedAsMedicareCheckBx);
	}

	public void enterPolicyNoMemIDforOther(int memIndex, String polNo) throws Exception {
		By polNoTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex
				+ "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[OTHER].nonESIHealthCoverageParamDTO.policyNumber']/../label");
		enterText("OtherPolNoTxt", polNoTxt, polNo);
	}

	public void enterCoverageStartDateForOther(int memIndex, String covStartDate) throws Exception {
		By covStartDateTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex
				+ "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[OTHER].nonESIHealthCoverageParamDTO.startDate']/../label");
		clearAndType("OtherCovStartDate", covStartDateTxt, covStartDate);
	}

	public void enterCoverageEndDateForOther(int memIndex, String covEndDate) throws Exception {
		By covEndDateTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex
				+ "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[OTHER].nonESIHealthCoverageParamDTO.endDate']/../label");
		clearAndType("OtherCovEndDate", covEndDateTxt, covEndDate);
	}

	// ---------------------------- Offered Any Health Insurance ---------------------------------------//

	public void selectIfOfferedAnyHealthInsurance(int memIndex, boolean trueFalseValue) throws Exception {
		By offeredAnyHealthInsuranceBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.isOfferedAnyHealthInsurance' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "OfferedAnyHealthInsuranceBtn", offeredAnyHealthInsuranceBtn);
	}

	// ---------------------------- End ---------------------------------------//

	public void clickOnESICoverageDateNotKnownChkBxForMember(int memIndex) throws Exception {
		By esiCoverageDateNotKnownChkBx = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.coverageDateNotKnown");
		clickOnElement("Mem" + (memIndex + 1) + "ESICoverageDateNotKnownChkBx", esiCoverageDateNotKnownChkBx);
	}

	public void selectESIEmployerNameForMember(int memIndex, String employerName) throws Exception {
		By esiEmployerNameDD = By.name("eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].employerName");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "ESIEmployerNameDD", esiEmployerNameDD, employerName);
	}

	// updated
	public void selectHealthCoverageChkBxForMember(int memIndex, String otherHltInsuranceRetiral) throws Exception {
		By retirementPlanChkBx = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.retirementPlanInCoverageYear' and @value='" + otherHltInsuranceRetiral + "']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "OtherHealthInsunaceRetiralCheckBx:" + otherHltInsuranceRetiral, retirementPlanChkBx);

	}

	// ----------------------------COBRA and Retiree Health Insurance ---------------------------------------//

	public void enterCOBRA_RHI_EmployerNameForMember(int memIndex, String employerName) throws Exception {
		By employerNameTxt = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].employerName']");
		clearAndType("Mem" + (memIndex + 1) + "EmployerNameTxt", employerNameTxt, employerName);
	}

	public void enterCOBRA_RHI_PrimaryAddressStreetForMember(int memIndex, String street) throws Exception {
		By memPrimaryAddressStr1 = By.xpath("//div[@class='form-group']//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryAddress.streetAddress1']");
		clearAndType("Mem" + (memIndex + 1) + "PrimaryAddressStr1", memPrimaryAddressStr1, street);
	}

	public void enterCOBRA_RHI_PrimaryCityForMember(int memIndex, String city) throws Exception {
		By memPrimaryCity = By.xpath("//div[@class='form-group']//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryAddress.city']");
		clearAndType("Mem" + (memIndex + 1) + "PrimaryCity", memPrimaryCity, city);
	}

	public void enterCOBRA_RHI_PrimaryZipForMember(int memIndex, String zipCode) throws Exception {
		By memPrimaryZip = By.xpath("//div[@class='form-group']//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryAddress.zip']");
		clearAndType("Mem" + (memIndex + 1) + "PrimaryZip", memPrimaryZip, zipCode);
	}

	public void selectCOBRA_RHI_PrimaryCountyForMember(int memIndex, String county) throws Exception {
		By memPrimaryCounty = By.xpath("//div[@class='form-group']//select[@name='eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryAddress.county']");
		selectByVisibleTextAfterWait("Mem" + (memIndex + 1) + "PrimaryCounty", memPrimaryCounty, county);
	}

	public void enterCOBRARetireePrimaryPhoneNo(int memIndex, String phoneNo) throws Exception {
		By primaryPhnoTxt = By.xpath("//div[@class='form-group']//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactInfo.primaryPhoneNumber_phone_no_1_0']");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "ESIEmployerPrimaryPhnoTxt", primaryPhnoTxt, phoneNo);
	}

	public void enterCOBRARetireeSecondaryPhoneNo(int memIndex, String phoneNo) throws Exception {
		By secondaryPhnoTxt = By.xpath("//div[@class='form-group']//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].contactPerson.primaryPhoneNumber_phone_no_2_0']");
		clearAndTypeAfterWait("Mem" + (memIndex + 1) + "ESIEmployerSecondaryPhnoTxt", secondaryPhnoTxt, phoneNo);
	}

	/*-----------COBRA and Retiree Health Insurance Ends-----------------*/

	public void clickOnSaveAndContinueBtn() throws Exception {
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}

	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}

	public void selectESIDetailsForMember(int memIndex, String jobEmployerName, String employerPrimarnyPhoneNo, String employerSecondaryPhoneNo) throws Exception {
		selectIfOfferedThroughJobForMember(memIndex, true);
		clickOnESICoverageDateNotKnownChkBxForMember(memIndex);
		selectESIEmployerNameForMember(memIndex, jobEmployerName);
		enterPrimaryPhoneNo(memIndex, employerPrimarnyPhoneNo);
		enterSecondaryPhoneNo(memIndex, employerSecondaryPhoneNo);
	}

	public void evpdSelectCOBRARetireeHealthInsuranceInfoForMember(int memIndex, EVPD_MemData memData) throws Exception {
		enterCOBRA_RHI_EmployerNameForMember(memIndex, memData.otherHltInsuranceEmployerName);
		enterCOBRA_RHI_PrimaryAddressStreetForMember(memIndex, memData.otherHltInsuranceEmployerAddr.streetAddress);
		enterCOBRA_RHI_PrimaryCityForMember(memIndex, memData.otherHltInsuranceEmployerAddr.city);
		enterCOBRA_RHI_PrimaryZipForMember(memIndex, memData.otherHltInsuranceEmployerAddr.zipCode);
		selectCOBRA_RHI_PrimaryCountyForMember(memIndex, memData.otherHltInsuranceEmployerAddr.county);
		enterCOBRARetireePrimaryPhoneNo(memIndex, memData.employerPrimaryPhoneNo);
		enterCOBRARetireeSecondaryPhoneNo(memIndex, memData.employerSecondaryPhoneNo);
	}

	public void racSelectCOBRARetireeHealthInsuranceInfoForMember(int memIndex, RAC_MemData memData) throws Exception {
		enterCOBRA_RHI_EmployerNameForMember(memIndex, memData.otherHltInsuranceEmployerName);
		enterCOBRA_RHI_PrimaryAddressStreetForMember(memIndex, memData.otherHltInsuranceEmployerAddr.streetAddress);
		enterCOBRA_RHI_PrimaryCityForMember(memIndex, memData.otherHltInsuranceEmployerAddr.city);
		enterCOBRA_RHI_PrimaryZipForMember(memIndex, memData.otherHltInsuranceEmployerAddr.zipCode);
		selectCOBRA_RHI_PrimaryCountyForMember(memIndex, memData.otherHltInsuranceEmployerAddr.county);
		enterCOBRARetireePrimaryPhoneNo(memIndex, memData.employerPrimaryPhoneNo);
		enterCOBRARetireeSecondaryPhoneNo(memIndex, memData.employerSecondaryPhoneNo);
	}

	public void evpdSelectHealthInsuranceInfoForMember(int memIndex, EVPD_MemData memData) throws Exception {
		waitForPageLoaded();
		selectIfEnrolledInAnyHealthInsurance(memIndex, memData.enrolledInHealthInsurance);

		if (memData.enrolledInHealthInsurance) {
			if (memData.enrolledInESI) {
				selectESI(memIndex);

				if (memData.offeredThroughJob) {
					clickOnESI(memIndex);
				} else if (memData.enrolledInCOBRA) {
					clickOnCOBRA(memIndex);
				} else if (memData.enrolledInRetiree) {
					clickOnRetireeHealthPlan(memIndex);
				}

				selectESIEmployerName(memIndex, memData.jobEmployerName);
				clickOnESIDontKnownChkBxForMember(memIndex);
				enterPrimaryPhoneNo(memIndex, memData.employerPrimaryPhoneNo);
				enterSecondaryPhoneNo(memIndex, memData.employerSecondaryPhoneNo);

			} else if (memData.enrolledInMedicare) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, memData.medicarePolNo);
				enterCoverageStartDateForMedicare(memIndex, memData.medicareCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, memData.medicareCovEndDate);

				if (memData.insuranceExpChange) {
					clickOnIsAnyExpectedChange(memIndex, memData.insuranceExpChange);

					if (memData.insuranceNoLongerOffered) {
						clickOnNoLongerOfferCoverage(memIndex);
						clickOnESIDontKnownLastDayNoLongerOfferCoverageChkBx(memIndex);
					}

					if (memData.insuranceCanceled) {
						clickOnCanceledCoverage(memIndex);
						clickOnESIDontKnownLastDayCanceledCoverageChkBx(memIndex);
					}
				} else {
					clickOnIsAnyExpectedChange(memIndex, memData.insuranceExpChange);
				}

				if (memData.insuranceMeetMinVal) {
					clickOnMeetsMinValue(memIndex, memData.insuranceMeetMinVal);
					enterPlanPremiumCost(memIndex, "1500");
					selectPlanFrequency(memIndex, "Month");
				} else {
					clickOnMeetsMinValue(memIndex, memData.insuranceMeetMinVal);
				}
			} else if (memData.enrolledInMedicaid) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, memData.medicaidPolNo);
				enterCoverageStartDateForMedicare(memIndex, memData.medicaidCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, memData.medicaidCovEndDate);

			} else if (memData.enrolledInPeaceCorps) {
				selectOtherHealthInsuranceMixedAsPeaceCorps();
				enterPolicyNoMemIDforPeaceCorps(memIndex, memData.peaceCorpsPolNo);
				enterCoverageStartDateForPeaceCorps(memIndex, memData.peaceCorpsCovStartDate);
				enterCoverageEndDateForPeaceCorps(memIndex, memData.peaceCorpsCovEndDate);

			} else if (memData.enrolledInTricare) {
				selectOtherHealthInsuranceMixedAsTricare();
				enterPolicyNoMemIDforTricare(memIndex, memData.tricarePolNo);
				enterCoverageStartDateForTricare(memIndex, memData.tricareCovStartDate);
				enterCoverageEndDateForTricare(memIndex, memData.tricareCovEndDate);

			} else if (memData.enrolledInVaHp) {
				selectOtherHealthInsuranceMixedAsVA();
				enterPolicyNoMemIDforVeteransAffairs(memIndex, memData.vaPolNo);
				enterCoverageStartDateForVA(memIndex, memData.vaCovStartDate);
				enterCoverageEndDateForVA(memIndex, memData.vaCovEndDate);

			} else if (memData.enrolledInOtherPlan) {
				selectOtherHealthInsuranceMixedAsOther();
				enterPolicyNoMemIDforOther(memIndex, memData.otherPlanPolNo);
				enterCoverageStartDateForVA(memIndex, memData.otherPlanStartDate);
				enterCoverageEndDateForVA(memIndex, memData.otherPlanEndDate);
			}
		}

		selectIfOfferedAnyHealthInsurance(memIndex, memData.offeredInHealthInsurance);

		if (memData.offeredInHealthInsurance) {
			if (memData.enrolledInESI) {
				selectESI(memIndex);

				if (memData.offeredThroughJob) {
					clickOnESI(memIndex);
				} else if (memData.enrolledInCOBRA) {
					clickOnCOBRA(memIndex);
				} else if (memData.enrolledInRetiree) {
					clickOnRetireeHealthPlan(memIndex);
				}

				selectESIEmployerName(memIndex, memData.jobEmployerName);
				clickOnESIDontKnownChkBxForMember(memIndex);
				enterPrimaryPhoneNo(memIndex, memData.employerPrimaryPhoneNo);
				enterSecondaryPhoneNo(memIndex, memData.employerSecondaryPhoneNo);

			} else if (memData.enrolledInMedicare) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, memData.medicarePolNo);
				enterCoverageStartDateForMedicare(memIndex, memData.medicareCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, memData.medicareCovEndDate);
			}
		}

		clickOnSaveAndContinueBtn();
	}

	public void racSelectHealthInsuranceInfoForMember(int memIndex, RAC_MemData memData) throws Exception {
		waitForPageLoaded();
		selectIfEnrolledInAnyHealthInsurance(memIndex, memData.enrolledInHealthInsurance);

		if (memData.enrolledInHealthInsurance) {
			if (memData.enrolledInESI) {
				selectESI(memIndex);

				if (memData.offeredThroughJob) {
					clickOnESI(memIndex);
				} else if (memData.enrolledInCOBRA) {
					clickOnCOBRA(memIndex);
				} else if (memData.enrolledInRetiree) {
					clickOnRetireeHealthPlan(memIndex);
				}

				selectESIEmployerName(memIndex, memData.jobEmployerName);
				clickOnESIDontKnownChkBxForMember(memIndex);
				enterPrimaryPhoneNo(memIndex, memData.employerPrimaryPhoneNo);
				enterSecondaryPhoneNo(memIndex, memData.employerSecondaryPhoneNo);

				if (memData.insuranceExpChange) {
					clickOnIsAnyExpectedChange(memIndex, memData.insuranceExpChange);

					if (memData.insuranceNoLongerOffered) {
						clickOnNoLongerOfferCoverage(memIndex);
						clickOnESIDontKnownLastDayNoLongerOfferCoverageChkBx(memIndex);
					}

					if (memData.insuranceCanceled) {
						clickOnCanceledCoverage(memIndex);
						clickOnESIDontKnownLastDayCanceledCoverageChkBx(memIndex);
					}
				} else {
					clickOnIsAnyExpectedChange(memIndex, memData.insuranceExpChange);
				}

				if (memData.insuranceMeetMinVal) {
					clickOnMeetsMinValue(memIndex, memData.insuranceMeetMinVal);
					enterPlanPremiumCost(memIndex, "1500");
					selectPlanFrequency(memIndex, "Month");
				} else {
					clickOnMeetsMinValue(memIndex, memData.insuranceMeetMinVal);
				}
			} else if (memData.enrolledInMedicare) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, memData.medicarePolNo);
				enterCoverageStartDateForMedicare(memIndex, memData.medicareCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, memData.medicareCovEndDate);

			} else if (memData.enrolledInMedicaid) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, memData.medicaidPolNo);
				enterCoverageStartDateForMedicare(memIndex, memData.medicaidCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, memData.medicaidCovEndDate);

			} else if (memData.enrolledInPeaceCorps) {
				selectOtherHealthInsuranceMixedAsPeaceCorps();
				enterPolicyNoMemIDforPeaceCorps(memIndex, memData.peaceCorpsPolNo);
				enterCoverageStartDateForPeaceCorps(memIndex, memData.peaceCorpsCovStartDate);
				enterCoverageEndDateForPeaceCorps(memIndex, memData.peaceCorpsCovEndDate);

			} else if (memData.enrolledInTricare) {
				selectOtherHealthInsuranceMixedAsTricare();
				enterPolicyNoMemIDforTricare(memIndex, memData.tricarePolNo);
				enterCoverageStartDateForTricare(memIndex, memData.tricareCovStartDate);
				enterCoverageEndDateForTricare(memIndex, memData.tricareCovEndDate);

			} else if (memData.enrolledInVaHp) {
				selectOtherHealthInsuranceMixedAsVA();
				enterPolicyNoMemIDforVeteransAffairs(memIndex, memData.vaPolNo);
				enterCoverageStartDateForVA(memIndex, memData.vaCovStartDate);
				enterCoverageEndDateForVA(memIndex, memData.vaCovEndDate);

			} else if (memData.enrolledInOtherPlan) {
				selectOtherHealthInsuranceMixedAsOther();
				enterPolicyNoMemIDforOther(memIndex, memData.otherPlanPolNo);
				enterCoverageStartDateForVA(memIndex, memData.otherPlanStartDate);
				enterCoverageEndDateForVA(memIndex, memData.otherPlanEndDate);
			}
		}

		selectIfOfferedAnyHealthInsurance(memIndex, memData.offeredInHealthInsurance);

		if (memData.offeredInHealthInsurance) {
			if (memData.enrolledInESI) {
				selectESI(memIndex);

				if (memData.offeredThroughJob) {
					clickOnESI(memIndex);
				} else if (memData.enrolledInCOBRA) {
					clickOnCOBRA(memIndex);
				} else if (memData.enrolledInRetiree) {
					clickOnRetireeHealthPlan(memIndex);
				}

				selectESIEmployerName(memIndex, memData.jobEmployerName);
				clickOnESIDontKnownChkBxForMember(memIndex);
				enterPrimaryPhoneNo(memIndex, memData.employerPrimaryPhoneNo);
				enterSecondaryPhoneNo(memIndex, memData.employerSecondaryPhoneNo);

			} else if (memData.enrolledInMedicare) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, memData.medicarePolNo);
				enterCoverageStartDateForMedicare(memIndex, memData.medicareCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, memData.medicareCovEndDate);
			}
		}
		
		clickOnSaveAndContinueBtn();
	}

	public void evpdEnterHealthInsuranceInformationForMembers(int memIndex, EVPD_Data evpdData) throws Exception {
		selectIfEnrolledInAnyHealthInsurance(memIndex, evpdData.memsData.get(memIndex).enrolledInHealthInsurance);

		if (evpdData.memsData.get(memIndex).enrolledInHealthInsurance) {
			if (evpdData.memsData.get(memIndex).enrolledInESI) {
				selectESI(memIndex);

				if (evpdData.memsData.get(memIndex).offeredThroughJob) {
					clickOnESI(memIndex);
				} else if (evpdData.memsData.get(memIndex).enrolledInCOBRA) {
					clickOnCOBRA(memIndex);
				} else if (evpdData.memsData.get(memIndex).enrolledInRetiree) {
					clickOnRetireeHealthPlan(memIndex);
				}

				selectESIEmployerName(memIndex, evpdData.memsData.get(memIndex).jobEmployerName);
				clickOnESIDontKnownChkBxForMember(memIndex);
				enterPrimaryPhoneNo(memIndex, evpdData.memsData.get(memIndex).employerPrimaryPhoneNo);
				enterSecondaryPhoneNo(memIndex, evpdData.memsData.get(memIndex).employerSecondaryPhoneNo);

				if (evpdData.memsData.get(memIndex).insuranceExpChange) {
					clickOnIsAnyExpectedChange(memIndex, evpdData.memsData.get(memIndex).insuranceExpChange);

					if (evpdData.memsData.get(memIndex).insuranceNoLongerOffered) {
						clickOnNoLongerOfferCoverage(memIndex);
						clickOnESIDontKnownLastDayNoLongerOfferCoverageChkBx(memIndex);
					}

					if (evpdData.memsData.get(memIndex).insuranceCanceled) {
						clickOnCanceledCoverage(memIndex);
						clickOnESIDontKnownLastDayCanceledCoverageChkBx(memIndex);
					}
				} else {
					clickOnIsAnyExpectedChange(memIndex, evpdData.memsData.get(memIndex).insuranceExpChange);
				}

				if (evpdData.memsData.get(memIndex).insuranceMeetMinVal) {
					clickOnMeetsMinValue(memIndex, evpdData.memsData.get(memIndex).insuranceMeetMinVal);
					enterPlanPremiumCost(memIndex, "1500");
					selectPlanFrequency(memIndex, "Month");
				} else {
					clickOnMeetsMinValue(memIndex, evpdData.memsData.get(memIndex).insuranceMeetMinVal);
				}
			} else if (evpdData.memsData.get(memIndex).enrolledInMedicare) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, evpdData.memsData.get(memIndex).medicarePolNo);
				enterCoverageStartDateForMedicare(memIndex, evpdData.memsData.get(memIndex).medicareCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, evpdData.memsData.get(memIndex).medicareCovEndDate);

			} else if (evpdData.memsData.get(memIndex).enrolledInMedicaid) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, evpdData.memsData.get(memIndex).medicaidPolNo);
				enterCoverageStartDateForMedicare(memIndex, evpdData.memsData.get(memIndex).medicaidCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, evpdData.memsData.get(memIndex).medicaidCovEndDate);

			} else if (evpdData.memsData.get(memIndex).enrolledInPeaceCorps) {
				selectOtherHealthInsuranceMixedAsPeaceCorps();
				enterPolicyNoMemIDforPeaceCorps(memIndex, evpdData.memsData.get(memIndex).peaceCorpsPolNo);
				enterCoverageStartDateForPeaceCorps(memIndex, evpdData.memsData.get(memIndex).peaceCorpsCovStartDate);
				enterCoverageEndDateForPeaceCorps(memIndex, evpdData.memsData.get(memIndex).peaceCorpsCovEndDate);

			} else if (evpdData.memsData.get(memIndex).enrolledInTricare) {
				selectOtherHealthInsuranceMixedAsTricare();
				enterPolicyNoMemIDforTricare(memIndex, evpdData.memsData.get(memIndex).tricarePolNo);
				enterCoverageStartDateForTricare(memIndex, evpdData.memsData.get(memIndex).tricareCovStartDate);
				enterCoverageEndDateForTricare(memIndex, evpdData.memsData.get(memIndex).tricareCovEndDate);

			} else if (evpdData.memsData.get(memIndex).enrolledInVaHp) {
				selectOtherHealthInsuranceMixedAsVA();
				enterPolicyNoMemIDforVeteransAffairs(memIndex, evpdData.memsData.get(memIndex).vaPolNo);
				enterCoverageStartDateForVA(memIndex, evpdData.memsData.get(memIndex).vaCovStartDate);
				enterCoverageEndDateForVA(memIndex, evpdData.memsData.get(memIndex).vaCovEndDate);

			} else if (evpdData.memsData.get(memIndex).enrolledInOtherPlan) {
				selectOtherHealthInsuranceMixedAsOther();
				enterPolicyNoMemIDforOther(memIndex, evpdData.memsData.get(memIndex).otherPlanPolNo);
				enterCoverageStartDateForVA(memIndex, evpdData.memsData.get(memIndex).otherPlanStartDate);
				enterCoverageEndDateForVA(memIndex, evpdData.memsData.get(memIndex).otherPlanEndDate);
			}
		}
		
		evpdEnterOfferedHealthInsuranceInformationForMembers(memIndex, evpdData);
	}

	public void racEnterHealthInsuranceInformationForMembers(int memIndex, RAC_Data racData) throws Exception {
		selectIfEnrolledInAnyHealthInsurance(memIndex, racData.memsData.get(memIndex).enrolledInHealthInsurance);

		if (racData.memsData.get(memIndex).enrolledInHealthInsurance) {
			if (racData.memsData.get(memIndex).enrolledInESI) {
				selectESI(memIndex);

				if (racData.memsData.get(memIndex).offeredThroughJob) {
					clickOnESI(memIndex);
				} else if (racData.memsData.get(memIndex).enrolledInCOBRA) {
					clickOnCOBRA(memIndex);
				} else if (racData.memsData.get(memIndex).enrolledInRetiree) {
					clickOnRetireeHealthPlan(memIndex);
				}

				selectESIEmployerName(memIndex, racData.memsData.get(memIndex).jobEmployerName);
				clickOnESIDontKnownChkBxForMember(memIndex);
				enterPrimaryPhoneNo(memIndex, racData.memsData.get(memIndex).employerPrimaryPhoneNo);
				enterSecondaryPhoneNo(memIndex, racData.memsData.get(memIndex).employerSecondaryPhoneNo);

				if (racData.memsData.get(memIndex).insuranceExpChange) {
					clickOnIsAnyExpectedChange(memIndex, racData.memsData.get(memIndex).insuranceExpChange);

					if (racData.memsData.get(memIndex).insuranceNoLongerOffered) {
						clickOnNoLongerOfferCoverage(memIndex);
						clickOnESIDontKnownLastDayNoLongerOfferCoverageChkBx(memIndex);
					}

					if (racData.memsData.get(memIndex).insuranceCanceled) {
						clickOnCanceledCoverage(memIndex);
						clickOnESIDontKnownLastDayCanceledCoverageChkBx(memIndex);
					}
				} else {
					clickOnIsAnyExpectedChange(memIndex, racData.memsData.get(memIndex).insuranceExpChange);
				}

				if (racData.memsData.get(memIndex).insuranceMeetMinVal) {
					clickOnMeetsMinValue(memIndex, racData.memsData.get(memIndex).insuranceMeetMinVal);
					enterPlanPremiumCost(memIndex, "1500");
					selectPlanFrequency(memIndex, "Month");
				} else {
					clickOnMeetsMinValue(memIndex, racData.memsData.get(memIndex).insuranceMeetMinVal);
				}
			} else if (racData.memsData.get(memIndex).enrolledInMedicare) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, racData.memsData.get(memIndex).medicarePolNo);
				enterCoverageStartDateForMedicare(memIndex, racData.memsData.get(memIndex).medicareCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, racData.memsData.get(memIndex).medicareCovEndDate);

			} else if (racData.memsData.get(memIndex).enrolledInMedicaid) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, racData.memsData.get(memIndex).medicaidPolNo);
				enterCoverageStartDateForMedicare(memIndex, racData.memsData.get(memIndex).medicaidCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, racData.memsData.get(memIndex).medicaidCovEndDate);

			} else if (racData.memsData.get(memIndex).enrolledInPeaceCorps) {
				selectOtherHealthInsuranceMixedAsPeaceCorps();
				enterPolicyNoMemIDforPeaceCorps(memIndex, racData.memsData.get(memIndex).peaceCorpsPolNo);
				enterCoverageStartDateForPeaceCorps(memIndex, racData.memsData.get(memIndex).peaceCorpsCovStartDate);
				enterCoverageEndDateForPeaceCorps(memIndex, racData.memsData.get(memIndex).peaceCorpsCovEndDate);

			} else if (racData.memsData.get(memIndex).enrolledInTricare) {
				selectOtherHealthInsuranceMixedAsTricare();
				enterPolicyNoMemIDforTricare(memIndex, racData.memsData.get(memIndex).tricarePolNo);
				enterCoverageStartDateForTricare(memIndex, racData.memsData.get(memIndex).tricareCovStartDate);
				enterCoverageEndDateForTricare(memIndex, racData.memsData.get(memIndex).tricareCovEndDate);

			} else if (racData.memsData.get(memIndex).enrolledInVaHp) {
				selectOtherHealthInsuranceMixedAsVA();
				enterPolicyNoMemIDforVeteransAffairs(memIndex, racData.memsData.get(memIndex).vaPolNo);
				enterCoverageStartDateForVA(memIndex, racData.memsData.get(memIndex).vaCovStartDate);
				enterCoverageEndDateForVA(memIndex, racData.memsData.get(memIndex).vaCovEndDate);

			} else if (racData.memsData.get(memIndex).enrolledInOtherPlan) {
				selectOtherHealthInsuranceMixedAsOther();
				enterPolicyNoMemIDforOther(memIndex, racData.memsData.get(memIndex).otherPlanPolNo);
				enterCoverageStartDateForVA(memIndex, racData.memsData.get(memIndex).otherPlanStartDate);
				enterCoverageEndDateForVA(memIndex, racData.memsData.get(memIndex).otherPlanEndDate);
			}
		}
		
		racEnterOfferedHealthInsuranceInformationForMembers(memIndex, racData);
	}

	public void evpdEnterOfferedHealthInsuranceInformationForMembers(int memIndex, EVPD_Data evpdData) throws Exception {
		selectIfOfferedAnyHealthInsurance(memIndex, evpdData.memsData.get(memIndex).offeredInHealthInsurance);

		if (evpdData.memsData.get(memIndex).offeredInHealthInsurance) {
			if (evpdData.memsData.get(memIndex).enrolledInESI) {
				selectESI(memIndex);

				if (evpdData.memsData.get(memIndex).offeredThroughJob) {
					clickOnESI(memIndex);
				} else if (evpdData.memsData.get(memIndex).enrolledInCOBRA) {
					clickOnCOBRA(memIndex);
				} else if (evpdData.memsData.get(memIndex).enrolledInRetiree) {
					clickOnRetireeHealthPlan(memIndex);
				}

				selectESIEmployerName(memIndex, evpdData.memsData.get(memIndex).jobEmployerName);
				clickOnESIDontKnownChkBxForMember(memIndex);
				enterPrimaryPhoneNo(memIndex, evpdData.memsData.get(memIndex).employerPrimaryPhoneNo);
				enterSecondaryPhoneNo(memIndex, evpdData.memsData.get(memIndex).employerSecondaryPhoneNo);

				if (evpdData.memsData.get(memIndex).insuranceExpChange) {
					clickOnIsAnyExpectedChange(memIndex, evpdData.memsData.get(memIndex).insuranceExpChange);

					if (evpdData.memsData.get(memIndex).insuranceNoLongerOffered) {
						clickOnNoLongerOfferCoverage(memIndex);
						clickOnESIDontKnownLastDayNoLongerOfferCoverageChkBx(memIndex);
					}

					if (evpdData.memsData.get(memIndex).insuranceCanceled) {
						clickOnCanceledCoverage(memIndex);
						clickOnESIDontKnownLastDayCanceledCoverageChkBx(memIndex);
					}
				} else {
					clickOnIsAnyExpectedChange(memIndex, evpdData.memsData.get(memIndex).insuranceExpChange);
				}

				if (evpdData.memsData.get(memIndex).insuranceMeetMinVal) {
					clickOnMeetsMinValue(memIndex, evpdData.memsData.get(memIndex).insuranceMeetMinVal);
					enterPlanPremiumCost(memIndex, "1500");
					selectPlanFrequency(memIndex, "Month");
				} else {
					clickOnMeetsMinValue(memIndex, evpdData.memsData.get(memIndex).insuranceMeetMinVal);
				}
			} else if (evpdData.memsData.get(memIndex).enrolledInMedicare) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, evpdData.memsData.get(memIndex).medicarePolNo);
				enterCoverageStartDateForMedicare(memIndex, evpdData.memsData.get(memIndex).medicareCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, evpdData.memsData.get(memIndex).medicareCovEndDate);
			}
		}
	}

	public void racEnterOfferedHealthInsuranceInformationForMembers(int memIndex, RAC_Data racData) throws Exception {
		selectIfOfferedAnyHealthInsurance(memIndex, racData.memsData.get(memIndex).offeredInHealthInsurance);

		if (racData.memsData.get(memIndex).offeredInHealthInsurance) {
			if (racData.memsData.get(memIndex).enrolledInESI) {
				selectESI(memIndex);

				if (racData.memsData.get(memIndex).offeredThroughJob) {
					clickOnESI(memIndex);
				} else if (racData.memsData.get(memIndex).enrolledInCOBRA) {
					clickOnCOBRA(memIndex);
				} else if (racData.memsData.get(memIndex).enrolledInRetiree) {
					clickOnRetireeHealthPlan(memIndex);
				}

				selectESIEmployerName(memIndex, racData.memsData.get(memIndex).jobEmployerName);
				clickOnESIDontKnownChkBxForMember(memIndex);
				enterPrimaryPhoneNo(memIndex, racData.memsData.get(memIndex).employerPrimaryPhoneNo);
				enterSecondaryPhoneNo(memIndex, racData.memsData.get(memIndex).employerSecondaryPhoneNo);

				if (racData.memsData.get(memIndex).insuranceExpChange) {
					clickOnIsAnyExpectedChange(memIndex, racData.memsData.get(memIndex).insuranceExpChange);

					if (racData.memsData.get(memIndex).insuranceNoLongerOffered) {
						clickOnNoLongerOfferCoverage(memIndex);
						clickOnESIDontKnownLastDayNoLongerOfferCoverageChkBx(memIndex);
					}

					if (racData.memsData.get(memIndex).insuranceCanceled) {
						clickOnCanceledCoverage(memIndex);
						clickOnESIDontKnownLastDayCanceledCoverageChkBx(memIndex);
					}
				} else {
					clickOnIsAnyExpectedChange(memIndex, racData.memsData.get(memIndex).insuranceExpChange);
				}

				if (racData.memsData.get(memIndex).insuranceMeetMinVal) {
					clickOnMeetsMinValue(memIndex, racData.memsData.get(memIndex).insuranceMeetMinVal);
					enterPlanPremiumCost(memIndex, "1500");
					selectPlanFrequency(memIndex, "Month");
				} else {
					clickOnMeetsMinValue(memIndex, racData.memsData.get(memIndex).insuranceMeetMinVal);
				}
			} else if (racData.memsData.get(memIndex).enrolledInMedicare) {
				selectOtherHealthInsuranceMixedAsMedicare();
				enterPolicyNoMemIDforMedicare(memIndex, racData.memsData.get(memIndex).medicarePolNo);
				enterCoverageStartDateForMedicare(memIndex, racData.memsData.get(memIndex).medicareCovStartDate);
				enterCoverageEndDateForMedicare(memIndex, racData.memsData.get(memIndex).medicareCovEndDate);
			}
		}
	}

}
