package pages.additionalQuestion;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_MemData;
import enums.Race;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class AdditionalQuestionStartPage extends CommonPage implements CommonPageOR{
	
	private static final By additionalQueStartPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Additional Questions')]");
	
	public AdditionalQuestionStartPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("AdditionalQueStartPageHeader", additionalQueStartPageHeader);
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	public void clickOnSaveAndContinue(boolean faReqd) throws Exception {
		if(faReqd){
			waitForPageLoaded();
			clickOnSaveAndContinueBtn();
		}
	}
	
	public void evpdEnterAdditionalQuestionsForMembers(boolean faReqd, String whoIsApplying, boolean atleastOneMemberAbove18, List<EVPD_MemData> memsData) throws Exception {
		if(faReqd){
			waitForPageLoaded();
			clickOnSaveAndContinueBtn();
			
			int memCount = memsData.size();
			
			HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(mCounter == 0 && whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
				
				healthInsuranceInfoPage.evpdSelectHealthInsuranceInfoForMember(mCounter, memsData.get(mCounter));
				
				if(memsData.get(mCounter).enrolledInESI || memsData.get(mCounter).enrolledInCOBRA || memsData.get(mCounter).enrolledInRetiree){
					EmployerHealthCoverageInfoPage employerHealthCoverageInfoPage = new EmployerHealthCoverageInfoPage(driver, testCaseId);
					employerHealthCoverageInfoPage.evpdSelectHealthInsuranceInfoForMember(mCounter, memsData);					
				}
				
				OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);
				otherInsurancePage.evpdEnterOtherHealthInsuranceMixedForMember(memsData.get(mCounter));
				
				if(memsData.get(mCounter).isTaxHHMember){
					TaxFilerAndOtherAdditionalQuePage taxFilerAndOtherAdditionalQuePage = new TaxFilerAndOtherAdditionalQuePage(driver, testCaseId);
				
					if(memsData.get(mCounter).filingTaxes){
						if(memsData.get(mCounter).married && !memsData.get(mCounter).jointTaxFiling){
							taxFilerAndOtherAdditionalQuePage.evpdCompleteTaxFilerQuestion(mCounter, false);
						}
					
						if(memsData.get(mCounter).claimAnyDependent && !memsData.get(mCounter).hasSSN){
							taxFilerAndOtherAdditionalQuePage.evpdCompleteSSNQuestion(mCounter, false);
						}
					}else{
						taxFilerAndOtherAdditionalQuePage.evpdCompleteTaxFilerQuestion(mCounter, false);
					}
				}
				
				//NCP Question
				if(memsData.get(mCounter).isU18 && atleastOneMemberAbove18 == true){
					if(memsData.get(mCounter).parentCount < 2){
						NCPQuestionPage ncpQuestionPage = new NCPQuestionPage(driver, testCaseId);
						
						if(memsData.get(mCounter).ncpRfiRequired){
							// Ritika -- to NCP RFI handling
							ncpQuestionPage.completeNCPQuestion(mCounter, true, true, true, true);
						}else{
							ncpQuestionPage.completeNCPQuestion(mCounter, false, false, true, false);
						}
					}
				}
				
				if(memsData.get(mCounter).isAIAN || memsData.get(mCounter).raceList.contains(Race.AMERICAN_INDIAN_OR_ALASKA_NATIVE.val)){
					MassHealthSpecQuestionPage massHealthSpecQuestionPage = new MassHealthSpecQuestionPage(driver, testCaseId);
					massHealthSpecQuestionPage.completeMassHealthSpecQuestion(mCounter, true);
				}
			}			
		}
	}
	
	public void racEnterAdditionalQuestionsForMembers(boolean faReqd, String whoIsApplying, boolean atleastOneMemberAbove18, List<RAC_MemData> memsData) throws Exception {
		if(faReqd){
			waitForPageLoaded();
			clickOnSaveAndContinueBtn();
			
			int memCount = memsData.size();
			
			HealthInsuranceInfoPage healthInsuranceInfoPage = new HealthInsuranceInfoPage(driver, testCaseId);
			
			for(int mCounter = 0; mCounter < memCount; mCounter++){
				if(mCounter == 0 && whoIsApplying.equals(WhoIsApplying.FAMILY_ONLY.code)) continue;
				
				healthInsuranceInfoPage.racSelectHealthInsuranceInfoForMember(mCounter, memsData.get(mCounter));
				
				if(memsData.get(mCounter).enrolledInESI || memsData.get(mCounter).enrolledInCOBRA || memsData.get(mCounter).enrolledInRetiree){
					EmployerHealthCoverageInfoPage employerHealthCoverageInfoPage = new EmployerHealthCoverageInfoPage(driver, testCaseId);
					employerHealthCoverageInfoPage.racSelectHealthInsuranceInfoForMember(mCounter, memsData);					
				}
				
				OtherInsurancePage otherInsurancePage = new OtherInsurancePage(driver, testCaseId);
				otherInsurancePage.racEnterOtherHealthInsuranceMixedForMember(memsData.get(mCounter));
				
				if(memsData.get(mCounter).isTaxHHMember){
					TaxFilerAndOtherAdditionalQuePage taxFilerAndOtherAdditionalQuePage = new TaxFilerAndOtherAdditionalQuePage(driver, testCaseId);
				
					if(memsData.get(mCounter).filingTaxes){
						if(memsData.get(mCounter).married && !memsData.get(mCounter).jointTaxFiling){
							taxFilerAndOtherAdditionalQuePage.evpdCompleteTaxFilerQuestion(mCounter, false);
						}
					
						if(memsData.get(mCounter).claimAnyDependent && !memsData.get(mCounter).hasSSN){
							taxFilerAndOtherAdditionalQuePage.evpdCompleteSSNQuestion(mCounter, false);
						}
					}else{
						taxFilerAndOtherAdditionalQuePage.evpdCompleteTaxFilerQuestion(mCounter, false);
					}
				}
				
				//NCP Question
				if(memsData.get(mCounter).isU18 && atleastOneMemberAbove18 == true){
					if(memsData.get(mCounter).parentCount < 2){
						NCPQuestionPage ncpQuestionPage = new NCPQuestionPage(driver, testCaseId);
						
						if(memsData.get(mCounter).ncpRfiRequired){
							// Ritika -- to NCP RFI handling
							ncpQuestionPage.completeNCPQuestion(mCounter, true, true, true, true);
						}else{
							ncpQuestionPage.completeNCPQuestion(mCounter, false, false, true, false);
						}
					}
				}
				
				if(memsData.get(mCounter).isAIAN || memsData.get(mCounter).raceList.contains(Race.AMERICAN_INDIAN_OR_ALASKA_NATIVE.val)){
					MassHealthSpecQuestionPage massHealthSpecQuestionPage = new MassHealthSpecQuestionPage(driver, testCaseId);
					massHealthSpecQuestionPage.completeMassHealthSpecQuestion(mCounter, true);
				}
			}			
		}
	}
	
	// ppinho
	public void evpdClickOnSaveAndContinue(boolean faReqd) throws Exception {
		if(faReqd){
			clickOnSaveAndContinueBtn();
		}
	}
	
	// ppinho
	public void racClickOnSaveAndContinue(boolean faReqd) throws Exception {
		if(faReqd){
			clickOnSaveAndContinueBtn();
		}
	}
	
}
