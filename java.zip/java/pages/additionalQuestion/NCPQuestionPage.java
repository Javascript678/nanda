package pages.additionalQuestion;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import enums.Race;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class NCPQuestionPage extends CommonPage implements CommonPageOR{
	
	private static final By ncpQuePageHeader = By.xpath("//h1[contains(text()[normalize-space()],'MassHealth Specific Questions')]");
	
	public NCPQuestionPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("NCPQuePageHeader", ncpQuePageHeader);
	}
	
	private void SelectIfMemberIsAdoptedBySingleParent(int memIndex, boolean trueFalseValue) throws Exception{
		By adoptedBySingleParentRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].nonCustodialParentInfoList[0].isAdoptedBySingleParent' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem"+(memIndex+1)+"AdoptedBySingleParentRdBtn",adoptedBySingleParentRdBtn);
		}
	
	private void SelectIfMemberParentDied(int memIndex, boolean trueFalseValue) throws Exception{
		By  parentDiedRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].nonCustodialParentInfoList[0].hasParentDied' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem"+(memIndex+1)+"ParentDiedRdBtn", parentDiedRdBtn);
	}
	
	private void SelectIfMemberParentIdentityUnknown(int memIndex, boolean trueFalseValue) throws Exception{
		By  parentIdentityUnknownRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].nonCustodialParentInfoList[0].isParentUnknown' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem"+(memIndex+1)+"ParentIdentityUnknownRdBtn", parentIdentityUnknownRdBtn);
	}
	
	private void SelectIfMemberNotLivingWithParent(int memIndex, boolean trueFalseValue) throws Exception{
		By  notLivingWithParentRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].nonCustodialParentInfoList[0].notLivingWithParent' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem"+(memIndex+1)+"NotLivingWithParentRdBtn", notLivingWithParentRdBtn);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void completeNCPQuestion(int memIndex, boolean isAdopted, boolean parentDied, boolean parentIdUnknown, boolean notLivingWithParent) throws Exception{
		waitForPageLoaded();
		SelectIfMemberIsAdoptedBySingleParent(memIndex, isAdopted);
		SelectIfMemberParentDied(memIndex, parentDied);
		SelectIfMemberParentIdentityUnknown(memIndex, parentIdUnknown);
		SelectIfMemberNotLivingWithParent(memIndex, notLivingWithParent);
		clickOnSaveAndContinueBtn();
	}

}
