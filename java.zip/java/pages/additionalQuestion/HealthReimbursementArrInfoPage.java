package pages.additionalQuestion;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_Data;
import appdata.rac.RAC_MemData;
import enums.InsurancePolicySource;
import enums.Race;
import enums.WhoIsApplying;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class HealthReimbursementArrInfoPage extends CommonPage implements CommonPageOR {
	
	private static final By healthReimbursementArrInfoPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Health Reimbursement Arrangement Information')]");
	
	public HealthReimbursementArrInfoPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception {
		waitForPresenceOfElementLocated("HealthReimbursementArrInfoPageHeader", healthReimbursementArrInfoPageHeader);
	}
	
	public void clickOnHealthReimbursementArrangements(int memIndex) throws Exception {
		By healthReimbursementArrangementsBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].eligibilityMemberAdditionalInfo.isHraOffered' and @value='YES']/../label");
		clickOnElement("Mem" + (memIndex) + "HealthReimbursementArrangementsBtn", healthReimbursementArrangementsBtn);
	}
	
	public void clickOnQSEHRAQulified(int memIndex) throws Exception {
		By qsehraQulifiedBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].hraMemberDetails[1].hraType' and @value='QSEHRA']/../label");
		clickOnElement("Mem" + (memIndex) + "QSEHRAQulifiedBtn", qsehraQulifiedBtn);
	}
	
	public void clickOnICHRAQulified(int memIndex) throws Exception {
		By ichraQulifiedBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].hraMemberDetails[1].hraType' and @value='ICHRA']/../label");
		clickOnElement("Mem" + (memIndex) + "ICHRAQulifiedBtn", ichraQulifiedBtn);
	}
	
	public void selectHRAEmployerName(int memIndex, String employerName) throws Exception {
		By esiEmployerNameDD = By.xpath("select[@name='eligibilityMember[" + memIndex + "].mecHealthCoverageDTO.enrollerHealthInsuranceParamMap[ESI].esiHealthCoverageDTOList[0].employerName']");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "ESIEmployerNameDD", esiEmployerNameDD, employerName);		
	}
	
	public void selectStartMonthOfYourActiveICHRA(int memIndex, String startMonthOfYourActiveICHRA) throws Exception {
		By startMonthOfYourActiveICHRADD = By.name("eligibilityMember[" + memIndex + "].hraMemberDetails[1].memberIcHraDetail.fromMonth");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "StartMonthOfYourActiveICHRADD", startMonthOfYourActiveICHRADD, startMonthOfYourActiveICHRA);		
	}
	
	public void selectStartYearOfYourActiveICHRA(int memIndex, String startYearOfYourActiveICHRA) throws Exception {
		By startYearOfYourActiveICHRADD = By.name("eligibilityMember[" + memIndex + "].hraMemberDetails[1].memberIcHraDetail.fromYear");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "StartYearOfYourActiveICHRA", startYearOfYourActiveICHRADD, startYearOfYourActiveICHRA);		
	}
	
	public void selectEndMonthOfYourActiveICHRA(int memIndex, String endMonthOfYourActiveICHRA) throws Exception {
		By endMonthOfYourActiveICHRADD = By.name("eligibilityMember[" + memIndex + "].hraMemberDetails[1].memberIcHraDetail.toMonth");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "EndMonthOfYourActiveICHRADD", endMonthOfYourActiveICHRADD, endMonthOfYourActiveICHRA);		
	}
	
	public void selectEndYearOfYourActiveICHRA(int memIndex, String endYearOfYourActiveICHRA) throws Exception{
		By endYearOfYourActiveICHRADD = By.name("eligibilityMember[" + memIndex + "].hraMemberDetails[1].memberIcHraDetail.toYear");
		selectDropDownElementByVisibleText("Mem" + (memIndex + 1) + "EndYearOfYourActiveICHRADD", endYearOfYourActiveICHRADD, endYearOfYourActiveICHRA);		
	}
	
	
	public void enterSelfonlyCoverageThroughICHRA(int memIndex, String selfonlyCoverageAmount)throws Exception{
		By selfonlyCoverageThroughICHRATxt = By.name("eligibilityMember[" + memIndex + "].hraMemberDetails[1].memberIcHraDetail.maxCoverageAmount");
		clearAndTypeAfterWait("Mem"+(memIndex+1)+ "SelfonlyCoverageThroughICHRATxt" , selfonlyCoverageThroughICHRATxt, selfonlyCoverageAmount);
	}
	
	public void clickOnAcceptICHRABenefit(int memIndex, String yesNo) throws Exception {
		By AcceptICHRABenefitBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].hraMemberDetails[1].memberIcHraDetail.isAcceptIcHra' @value='" + yesNo + "']/../label");
		clickOnElement("Mem" + (memIndex) + "ICHRAQulifiedBtn", AcceptICHRABenefitBtn);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void evpdCompleteHealthReimbursementArrangementInformation(int memIndex, EVPD_Data evpdData) throws Exception{
		if(evpdData.memsData.get(memIndex).healthReimbursementArr){
			clickOnHealthReimbursementArrangements(memIndex);
			selectHRAEmployerName(memIndex, evpdData.memsData.get(memIndex).jobEmployerName);
			
			if(evpdData.memsData.get(memIndex).qsehraQulified){
				clickOnQSEHRAQulified(memIndex);
			}
			
			if(evpdData.memsData.get(memIndex).ichraQulified){
				clickOnICHRAQulified(memIndex);
			}
			
			selectStartMonthOfYourActiveICHRA(memIndex, "January");
			selectStartYearOfYourActiveICHRA(memIndex, "2019");
			selectEndMonthOfYourActiveICHRA(memIndex, "January");
			selectEndYearOfYourActiveICHRA(memIndex, "2020");
			enterSelfonlyCoverageThroughICHRA(memIndex, "1500");
			
			if(evpdData.memsData.get(memIndex).acceptICHRABenefit){
				clickOnAcceptICHRABenefit(memIndex, "YES");
			}else{
				clickOnAcceptICHRABenefit(memIndex, "NO");
			}
		}
		
		clickOnSaveAndContinueBtn();
	}
	
}
