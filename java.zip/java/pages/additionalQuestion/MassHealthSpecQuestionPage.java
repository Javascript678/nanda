package pages.additionalQuestion;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.rac.RAC_Data;
import enums.Race;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class MassHealthSpecQuestionPage extends CommonPage implements CommonPageOR{
	
	private static final By massHealthSpecQuePageHeader = By.xpath("//h1[contains(text()[normalize-space()],'MassHealth Specific Questions')]");
	
	public MassHealthSpecQuestionPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("MassHealthSpecQuePageHeader", massHealthSpecQuePageHeader);
	}
	
	private void SelectIfMemberGotHealthInsuranceFromIHS(int memIndex, boolean trueFalseValue) throws Exception{
		//By coverageFromIHSRdBtn = By.name("eligibilityMember["+memIndex+"].eligibilityMemberCoverage.coverageFromIHS");
		By coverageFromIHSRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberCoverage.coverageFromIHS' and @value='"+trueFalseValue+"']/../label");
				//name("eligibilityMember["+memIndex+"].eligibilityMemberCoverage.coverageFromIHS");
		  clickOnElement("Mem"+(memIndex+1)+"CoverageFromIHSRdBtn", coverageFromIHSRdBtn);
	
	
	}
	
	private void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}
	
	public void completeMassHealthSpecQuestion(int memIndex, boolean trueFalseValue) throws Exception{
		waitForPageLoaded();
		SelectIfMemberGotHealthInsuranceFromIHS(memIndex, trueFalseValue);
		clickOnSaveAndContinueBtn();
	}

	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception {
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdEnterMassHealthSpecificQuestionsForMembers(int memIndex, EVPD_Data evpdData) throws Exception {
		// NCP Questions
		if(evpdData.memsData.get(memIndex).isU18 && evpdData.atleastOneMemberAbove18 == true){
			if(evpdData.memsData.get(memIndex).parentCount < 2){
				NCPQuestionPage ncpQuestionPage = new NCPQuestionPage(driver, testCaseId);
				
				if(evpdData.memsData.get(memIndex).ncpRfiRequired){
					// Ritika -- to NCP RFI handling
					ncpQuestionPage.completeNCPQuestion(memIndex, true, true, true, true);
				}else{
					ncpQuestionPage.completeNCPQuestion(memIndex, false, false, true, false);
				}
			}
		}
		
		// AIAN Question
		if(evpdData.memsData.get(memIndex).isAIAN || evpdData.memsData.get(memIndex).raceList.contains(Race.AMERICAN_INDIAN_OR_ALASKA_NATIVE.val)){
			completeMassHealthSpecQuestion(memIndex, true);
		}
	}
	
	// ppinho
	public void racEnterMassHealthSpecificQuestionsForMembers(int memIndex, RAC_Data racData) throws Exception {
		// NCP Questions
		if(racData.memsData.get(memIndex).isU18 && racData.atleastOneMemberAbove18 == true){
			if(racData.memsData.get(memIndex).parentCount < 2){
				NCPQuestionPage ncpQuestionPage = new NCPQuestionPage(driver, testCaseId);
				
				if(racData.memsData.get(memIndex).ncpRfiRequired){
					// Ritika -- to NCP RFI handling
					ncpQuestionPage.completeNCPQuestion(memIndex, true, true, true, true);
				}else{
					ncpQuestionPage.completeNCPQuestion(memIndex, false, false, true, false);
				}
			}
		}
		
		// AIAN Question
		if(racData.memsData.get(memIndex).isAIAN || racData.memsData.get(memIndex).raceList.contains(Race.AMERICAN_INDIAN_OR_ALASKA_NATIVE.val)){
			completeMassHealthSpecQuestion(memIndex, true);
		}
	}
	
}
