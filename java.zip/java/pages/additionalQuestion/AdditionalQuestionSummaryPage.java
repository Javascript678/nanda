package pages.additionalQuestion;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class AdditionalQuestionSummaryPage extends CommonPage implements CommonPageOR{
	
	private static final By additionalQueSummaryPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Additional Questions Summary')]");
	
	public AdditionalQuestionSummaryPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}
	
	public void validateMECForMember(int memIndex,String insValue) throws Exception{
		By mecLabel=By.xpath("//div[@id='shopEmployerDetails']//ul["+memIndex+"]/li[1]");
		validateTextContains("Mem"+(memIndex+1)+"MEC Value", mecLabel, insValue);
	}
	
	public void validateEnrollInHPForMember(int memIndex,String insHPValue) throws Exception{
		By insHPLabel = By.xpath("//div[@id='shopEmployerDetails']//ul["+memIndex+"]/li[2]");
		validateTextContains("Mem"+(memIndex+1)+"Enroll in HP", insHPLabel, insHPValue);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("AdditionalQueSummaryPageHeader", additionalQueSummaryPageHeader,5);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn, 3);
	}
	
	public void takeScreenshot() throws Exception{
		takeScreenshot("Summary");
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn(boolean faReqd) throws Exception{
		if(faReqd){
			waitForPageLoaded();
			takeScreenshot();
			clickOnSaveAndContinueBtn();
		}
		
	}
	
	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		takeScreenshot();
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdClickOnSaveAndContinueBtn(boolean faReqd) throws Exception{
		if(faReqd){
			takeScreenshot();
			clickOnSaveAndContinueBtn();
		}
	}
	
	// ppinho
	public void racClickOnSaveAndContinueBtn(boolean faReqd) throws Exception{
		if(faReqd){
			takeScreenshot();
			clickOnSaveAndContinueBtn();
		}
	}
	
}
