package pages.additionalQuestion;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class TaxFilerAndOtherAdditionalQuePage extends CommonPage implements CommonPageOR{

	private static final By taxFillerAndOtherAddQuePageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Tax Filer & Other Additional Questions')]");
	
	public TaxFilerAndOtherAdditionalQuePage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}

	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("TaxFillerAndOtherAddQuePageHeader", taxFillerAndOtherAddQuePageHeader);
	}

	private void SelectIfMemberWillFileTaxes(int memIndex, boolean trueFalseValue) throws Exception {
		By changeFilingTaxesAnsRdBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].changeAnswer' and @value='" + trueFalseValue + "']/../label");	
		clickOnElement("Mem" + (memIndex + 1) + "ChangeFilingTaxesAnsRdBtn" + trueFalseValue, changeFilingTaxesAnsRdBtn);
	}
	private void SelectIfMemberWillProvideSSN(int memIndex, boolean trueFalseValue) throws Exception{
		By provideSSNRdBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].socialSecurityCard.hasSsn' and @value='" + trueFalseValue + "']/../label");
		clickOnElement("Mem" + (memIndex + 1) + "ProvideSSNRdBtn", provideSSNRdBtn);
	}
	
	public boolean elgMemChangeAnswerInd(int memIndex) throws Exception {
		By eligibilityMemberChangeAnswerRdBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].changeAnswer']");
		
		Boolean elgMembChangeAnswer = null;
		
		if(isElementPresent(eligibilityMemberChangeAnswerRdBtn)){
			elgMembChangeAnswer = true;
		}else{
			elgMembChangeAnswer = false;
		}
		
		return elgMembChangeAnswer;
	}
	
	public boolean hasSSNInd(int memIndex) throws Exception {
		By hasSSNRdBtn = By.xpath("//input[@name='eligibilityMember[" + memIndex + "].socialSecurityCard.hasSsn']");
		
		Boolean hasSSN = null;
		
		if(isElementPresent(hasSSNRdBtn)){
			hasSSN = true;
		}else{
			hasSSN = false;
		}
		
		return hasSSN;
	}

	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}

	public void evpdCompleteTaxFilerQuestion(int memIndex, boolean trueFalseValue) throws Exception{
		waitForPageLoaded();
		SelectIfMemberWillFileTaxes(memIndex, trueFalseValue);
		clickOnSaveAndContinueBtn();
	}

	public void evpdCompleteSSNQuestion(int memIndex, boolean trueFalseValue) throws Exception{
		waitForPageLoaded();
		SelectIfMemberWillProvideSSN(memIndex, trueFalseValue);
		clickOnSaveAndContinueBtn();
	}
	
	public void racCompleteTaxFilerQuestion(int memIndex, boolean trueFalseValue) throws Exception{
		waitForPageLoaded();
		SelectIfMemberWillFileTaxes(memIndex, trueFalseValue);
		clickOnSaveAndContinueBtn();
	}

	public void racCompleteSSNQuestion(int memIndex, boolean trueFalseValue) throws Exception{
		waitForPageLoaded();
		SelectIfMemberWillProvideSSN(memIndex, trueFalseValue);
		clickOnSaveAndContinueBtn();
	}
	
}
