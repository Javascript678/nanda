package pages.additionalQuestion;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_Data;
import appdata.rac.RAC_MemData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class OtherInsurancePage extends CommonPage implements CommonPageOR{

	private static final By otherInsurancePageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Other Insurance')]");

	public OtherInsurancePage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("OtherInsurancePageHeader", otherInsurancePageHeader,3);
	}
	
	public void validatePageTitleDontContainsName(String fullName) throws Exception {
		String actualTitle = getCurrentPageTitle();
		validateTextNotContains("OtherInsuranceInfoPageTitle", actualTitle, fullName);
	}
	
	public void selectOtherHealthInsuranceMixed(String otherHltInsuranceMixed) throws Exception{
		By otherHealthInsunaceMixedCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox']");

		selectByValue("OtherHealthInsunaceMixedCheckBx", otherHealthInsunaceMixedCheckBx, otherHltInsuranceMixed);
	}

	public void selectOtherHealthInsuranceMixedAsMH() throws Exception{
		By otherHealthInsunaceMixedAsMHCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='MASS_HEALTH']");

		if(! isAttributePresent(otherHealthInsunaceMixedAsMHCheckBx, "checked")){
			clickOnElement("MemDeductionTypeMHChkBx", otherHealthInsunaceMixedAsMHCheckBx);
		}
	}
	//Ritika

	public void selectOtherHealthInsuranceMixedAsMedicare() throws Exception{
		By otherHealthInsunaceMixedAsMedicareCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='MEDICARE']");

		if(! isAttributePresent(otherHealthInsunaceMixedAsMedicareCheckBx, "checked")){
			clickOnElement("MemDeductionTypeMedicareChkBx", otherHealthInsunaceMixedAsMedicareCheckBx);
		}
	}

	public void enterPolicyNoMemIDforMedicare(String polNo)throws Exception{
		By polNoTxt = By.xpath("//input[contains(@aria-labelledby,'otherInsurance_1 policyNumberMemId_1')]");
		enterText( "MedicarePolNoTxt" , polNoTxt,polNo);
	}

	public void enterCoverageStartDateForMedicare(String covStartDate) throws Exception{
		By covStartDateTxt	= By.xpath("//input[contains(@aria-labelledby,'otherInsurance_1 startCovedate_1')]");
		clearAndType("MedicareCovStartDate" , covStartDateTxt, covStartDate);
	}

	public void enterCoverageEndDateForMedicare(String covEndDate) throws Exception{
		By covEndDateTxt	= By.xpath("//input[contains(@aria-labelledby,'otherInsurance_1 endCovDate_1')]");
		clearAndType("MedicareCovEndDate" , covEndDateTxt, covEndDate);
	}


	public void enterCoverageStartDateForPeaceCorps(String covStartDate) throws Exception{
		By covStartDateTxt	= By.xpath("//input[contains(@aria-labelledby,'otherInsurance_2 startCovedate_2')]");
		clearAndType("PeaceCorpsCovStartDate" , covStartDateTxt, covStartDate);
	}

	public void enterCoverageEndDateForPeaceCorps(String covEndDate) throws Exception{
		By covEndDateTxt	= By.xpath("//input[contains(@aria-labelledby,'otherInsurance_2 endCovDate_2')]");
		clearAndType("PeaceCorpsCovEndDate" , covEndDateTxt, covEndDate);
	}

	public void enterPolicyNoMemIDforTricare(String polNo)throws Exception{
		By polNoTxt = By.xpath("//input[contains(@aria-labelledby,'otherInsurance_3 policyNumberMemId_3')]");
		enterText("TricarePolNoTxt" , polNoTxt,polNo);
	}

	public void enterCoverageStartDateForTricare(String covStartDate) throws Exception{
		By covStartDateTxt	= By.xpath("//input[contains(@aria-labelledby,'otherInsurance_3 startCovedate_3')]");
		clearAndType("TricareCovStartDate" , covStartDateTxt, covStartDate);
	}

	public void enterCoverageEndDateForTricare(String covEndDate) throws Exception{
		By covEndDateTxt	= By.xpath("//input[contains(@aria-labelledby,'otherInsurance_3 endCovDate_3')]");
		clearAndType("TricareCovEndDate" , covEndDateTxt, covEndDate);
	}


	public void enterCoverageStartDateForVA(String covStartDate) throws Exception{
		By covStartDateTxt	= By.xpath("//input[contains(@aria-labelledby,'otherInsurance_4 startCovedate_4')]");
		clearAndType("VACovStartDate" , covStartDateTxt, covStartDate);
	}

	public void enterCoverageEndDateForVA(String covEndDate) throws Exception{
		By covEndDateTxt	= By.xpath("//input[contains(@aria-labelledby,'otherInsurance_4 endCovDate_4')]");
		clearAndType("VACovEndDate" , covEndDateTxt, covEndDate);
	}


	public void enterPlanNameforOther(String planName)throws Exception{
		By planNameTxt = By.xpath("//input[contains(@aria-labelledby,'otherInsurance_5 healthPlanName_5')]");
		enterText("OtherPlanNameTxt" , planNameTxt,planName);
	}

	public void enterPolicyNoMemIDforOther( String polNo)throws Exception{
		By polNoTxt = By.xpath("//input[contains(@aria-labelledby,'otherInsurance_5 policyNumberMemId_5')]");
		enterText("OtherPolNoTxt" , polNoTxt,polNo);
	}

	public void selectOtherHealthInsuranceMixedAsPeaceCorps() throws Exception{
		By otherHealthInsunaceMixedAsPeaceCorpsCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='PEACE_CORPS']");

		if(! isAttributePresent(otherHealthInsunaceMixedAsPeaceCorpsCheckBx, "checked")){
			clickOnElement("MemDeductionTypePeaceCorpsChkBx", otherHealthInsunaceMixedAsPeaceCorpsCheckBx);
		}
	}


	public void selectOtherHealthInsuranceMixedAsTricare() throws Exception{
		By otherHealthInsunaceMixedAsTricareCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='TRICARE']");

		if(! isAttributePresent(otherHealthInsunaceMixedAsTricareCheckBx, "checked")){
			clickOnElement("MemDeductionTypeTricareChkBx", otherHealthInsunaceMixedAsTricareCheckBx);
		}
	}


	public void selectOtherHealthInsuranceMixedAsVA() throws Exception{
		By otherHealthInsunaceMixedAsVACheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='VA_HEALTH_PROGRAM']");

		if(! isAttributePresent(otherHealthInsunaceMixedAsVACheckBx, "checked")){
			clickOnElement("MemDeductionTypeVAChkBx", otherHealthInsunaceMixedAsVACheckBx);
		}
	}

	public void selectOtherHealthInsuranceMixedAsOther() throws Exception{
		By otherHealthInsunaceMixedAsOtherCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='OTHER']");

		if(! isAttributePresent(otherHealthInsunaceMixedAsOtherCheckBx, "checked")){
			clickOnElement("MemDeductionTypeOtherChkBx", otherHealthInsunaceMixedAsOtherCheckBx);
		}
	}


	public void selectOtherHealthInsuranceMixedAsNone() throws Exception{
		By otherHealthInsunaceMixedAsNoneCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='NONE_OF_THE_ABOVE']");
		
		if(! isAttributePresent(otherHealthInsunaceMixedAsNoneCheckBx, "checked")){
			clickOnElement("MemDeductionTypeNoneChkBx", otherHealthInsunaceMixedAsNoneCheckBx);
		}
	}
	
	//Consider None of the Above is already selected , de selct It
	public void deselectOtherHealthInsuranceAsNone() throws Exception{
		By otherHealthInsunaceMixedAsNoneCheckBx = By.xpath("//div[contains(@class,'checkbox')]/input[@type='checkbox' and @value='NONE_OF_THE_ABOVE']");
		clickOnElement("MemDeductionTypeNoneChkBx", otherHealthInsunaceMixedAsNoneCheckBx);
	}
	
	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElementThenWait("SaveAndContinueBtn", saveAndContinueBtn, 3);
	}
	
	public void pageLoadAndClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}

	public void enterOtherHealthInsuranceMixedForMemberAsNone() throws Exception{
		waitForPageLoaded();
		selectOtherHealthInsuranceMixedAsNone();	
		clickOnSaveAndContinueBtn();
	}

	public void evpdEnterOtherHealthInsuranceMixedForMember(EVPD_MemData memData) throws Exception{
		waitForPageLoaded();

		if(memData.enrolledInMassHealth){
			selectOtherHealthInsuranceMixedAsMH();	
		}
		if(memData.enrolledInMedicare){
			selectOtherHealthInsuranceMixedAsMedicare();	
			enterPolicyNoMemIDforMedicare(memData.medicarePolNo);
			enterCoverageStartDateForMedicare(memData.medicareCovStartDate);
			enterCoverageEndDateForMedicare(memData.medicareCovEndDate);
		}
		if(memData.enrolledInPeaceCorps){
			selectOtherHealthInsuranceMixedAsPeaceCorps();	
			enterCoverageStartDateForPeaceCorps(memData.peaceCorpsCovStartDate);
			enterCoverageEndDateForPeaceCorps(memData.peaceCorpsCovEndDate);
		}
		if(memData.enrolledInTricare){
			selectOtherHealthInsuranceMixedAsTricare();
			enterPolicyNoMemIDforTricare(memData.tricarePolNo);
			enterCoverageStartDateForTricare(memData.tricareCovStartDate);
			enterCoverageEndDateForTricare(memData.tricareCovEndDate);
		}
		if(memData.enrolledInVaHp){
			selectOtherHealthInsuranceMixedAsVA();
			enterCoverageStartDateForVA(memData.vaCovStartDate);
			enterCoverageEndDateForVA(memData.vaCovEndDate);
		}
		if(memData.enrolledInOtherPlan){
			selectOtherHealthInsuranceMixedAsOther();
			enterPlanNameforOther(memData.otherPlanName);
			enterPolicyNoMemIDforOther(memData.otherPlanPolNo);
		}
		
		if(memData.enrolledNoHPMixed){
			selectOtherHealthInsuranceMixedAsNone();	
		}
		
		clickOnSaveAndContinueBtn();
	}
	
	public void racEnterOtherHealthInsuranceMixedForMember(RAC_MemData memData) throws Exception{
		waitForPageLoaded();

		if(memData.enrolledInMassHealth){
			selectOtherHealthInsuranceMixedAsMH();	
		}
		if(memData.enrolledInMedicare){
			selectOtherHealthInsuranceMixedAsMedicare();	
			enterPolicyNoMemIDforMedicare(memData.medicarePolNo);
			enterCoverageStartDateForMedicare(memData.medicareCovStartDate);
			enterCoverageEndDateForMedicare(memData.medicareCovEndDate);
		}
		if(memData.enrolledInPeaceCorps){
			selectOtherHealthInsuranceMixedAsPeaceCorps();	
			enterCoverageStartDateForPeaceCorps(memData.peaceCorpsCovStartDate);
			enterCoverageEndDateForPeaceCorps(memData.peaceCorpsCovEndDate);
		}
		if(memData.enrolledInTricare){
			selectOtherHealthInsuranceMixedAsTricare();
			enterPolicyNoMemIDforTricare(memData.tricarePolNo);
			enterCoverageStartDateForTricare(memData.tricareCovStartDate);
			enterCoverageEndDateForTricare(memData.tricareCovEndDate);
		}
		if(memData.enrolledInVaHp){
			selectOtherHealthInsuranceMixedAsVA();
			enterCoverageStartDateForVA(memData.vaCovStartDate);
			enterCoverageEndDateForVA(memData.vaCovEndDate);
		}
		if(memData.enrolledInOtherPlan){
			selectOtherHealthInsuranceMixedAsOther();
			enterPlanNameforOther(memData.otherPlanName);
			enterPolicyNoMemIDforOther(memData.otherPlanPolNo);
		}
		
		if(memData.enrolledNoHPMixed){
			selectOtherHealthInsuranceMixedAsNone();	
		}
		
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdEnterOtherInsuranceForMembers(int memIndex, EVPD_Data evpdData) throws Exception {
		if(evpdData.memsData.get(memIndex).enrolledInMassHealth){
			selectOtherHealthInsuranceMixedAsMH();	
		}
		
		if(evpdData.memsData.get(memIndex).enrolledInMedicare){
			selectOtherHealthInsuranceMixedAsMedicare();	
			enterPolicyNoMemIDforMedicare(evpdData.memsData.get(memIndex).medicarePolNo);
			enterCoverageStartDateForMedicare(evpdData.memsData.get(memIndex).medicareCovStartDate);
			enterCoverageEndDateForMedicare(evpdData.memsData.get(memIndex).medicareCovEndDate);
		}
		
		if(evpdData.memsData.get(memIndex).enrolledInPeaceCorps){
			selectOtherHealthInsuranceMixedAsPeaceCorps();	
			enterCoverageStartDateForPeaceCorps(evpdData.memsData.get(memIndex).peaceCorpsCovStartDate);
			enterCoverageEndDateForPeaceCorps(evpdData.memsData.get(memIndex).peaceCorpsCovEndDate);
		}
		
		if(evpdData.memsData.get(memIndex).enrolledInTricare){
			selectOtherHealthInsuranceMixedAsTricare();
			enterPolicyNoMemIDforTricare(evpdData.memsData.get(memIndex).tricarePolNo);
			enterCoverageStartDateForTricare(evpdData.memsData.get(memIndex).tricareCovStartDate);
			enterCoverageEndDateForTricare(evpdData.memsData.get(memIndex).tricareCovEndDate);
		}
		
		if(evpdData.memsData.get(memIndex).enrolledInVaHp){
			selectOtherHealthInsuranceMixedAsVA();
			enterCoverageStartDateForVA(evpdData.memsData.get(memIndex).vaCovStartDate);
			enterCoverageEndDateForVA(evpdData.memsData.get(memIndex).vaCovEndDate);
		}
		
		if(evpdData.memsData.get(memIndex).enrolledInOtherPlan){
			selectOtherHealthInsuranceMixedAsOther();
			enterPlanNameforOther(evpdData.memsData.get(memIndex).otherPlanName);
			enterPolicyNoMemIDforOther(evpdData.memsData.get(memIndex).otherPlanPolNo);
		}
		
		if(evpdData.memsData.get(memIndex).enrolledNoHPMixed){
			selectOtherHealthInsuranceMixedAsNone();	
		}
		
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void racEnterOtherInsuranceForMembers(int memIndex, RAC_Data evpdData) throws Exception {
		if(evpdData.memsData.get(memIndex).enrolledInMassHealth){
			selectOtherHealthInsuranceMixedAsMH();	
		}
		
		if(evpdData.memsData.get(memIndex).enrolledInMedicare){
			selectOtherHealthInsuranceMixedAsMedicare();	
			enterPolicyNoMemIDforMedicare(evpdData.memsData.get(memIndex).medicarePolNo);
			enterCoverageStartDateForMedicare(evpdData.memsData.get(memIndex).medicareCovStartDate);
			enterCoverageEndDateForMedicare(evpdData.memsData.get(memIndex).medicareCovEndDate);
		}
		
		if(evpdData.memsData.get(memIndex).enrolledInPeaceCorps){
			selectOtherHealthInsuranceMixedAsPeaceCorps();	
			enterCoverageStartDateForPeaceCorps(evpdData.memsData.get(memIndex).peaceCorpsCovStartDate);
			enterCoverageEndDateForPeaceCorps(evpdData.memsData.get(memIndex).peaceCorpsCovEndDate);
		}
		
		if(evpdData.memsData.get(memIndex).enrolledInTricare){
			selectOtherHealthInsuranceMixedAsTricare();
			enterPolicyNoMemIDforTricare(evpdData.memsData.get(memIndex).tricarePolNo);
			enterCoverageStartDateForTricare(evpdData.memsData.get(memIndex).tricareCovStartDate);
			enterCoverageEndDateForTricare(evpdData.memsData.get(memIndex).tricareCovEndDate);
		}
		
		if(evpdData.memsData.get(memIndex).enrolledInVaHp){
			selectOtherHealthInsuranceMixedAsVA();
			enterCoverageStartDateForVA(evpdData.memsData.get(memIndex).vaCovStartDate);
			enterCoverageEndDateForVA(evpdData.memsData.get(memIndex).vaCovEndDate);
		}
		
		if(evpdData.memsData.get(memIndex).enrolledInOtherPlan){
			selectOtherHealthInsuranceMixedAsOther();
			enterPlanNameforOther(evpdData.memsData.get(memIndex).otherPlanName);
			enterPolicyNoMemIDforOther(evpdData.memsData.get(memIndex).otherPlanPolNo);
		}
		
		if(evpdData.memsData.get(memIndex).enrolledNoHPMixed){
			selectOtherHealthInsuranceMixedAsNone();	
		}
		
		clickOnSaveAndContinueBtn();
	}
	
}
