package pages.additionalQuestion;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import appdata.evpd.EVPD_Data;
import appdata.evpd.EVPD_MemData;
import appdata.rac.RAC_Data;
import appdata.rac.RAC_MemData;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

/**
 * 
 * @author Vinay Kumar
 *
 */
public class EmployerHealthCoverageInfoPage extends CommonPage implements CommonPageOR{

	private static final By employerHltCvrgInfoPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Employer Health Coverage Information')]");

	public EmployerHealthCoverageInfoPage(WebDriver driver, String testCaseId){
		super(driver, testCaseId);
	}

	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("EmployerHltCvrgInfoPageHeader", employerHltCvrgInfoPageHeader);
	}

	public void selectIfEnrolledInCoverageYearForMember(int memIndex, boolean trueFalseValue) throws Exception{
		By enrolledInCoverageYearRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].enrolledInCoverageYear' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem"+(memIndex+1)+"EnrolledInCoverageYearRdBtn", enrolledInCoverageYearRdBtn);           
	}

	public void clickOnCoverageStartDateNotKnownChkBxForMember(int memIndex) throws Exception{
		By coverageStartDateNotKnownChkBx = By.id("eligibilityMember"+memIndex+".eligibilityMemberHealthCoverage.employersOfferingCoverage0.coverageDateNotKnown1");
		clickOnElement("Mem"+(memIndex+1)+"CoverageEndDateNotKnownChkBx", coverageStartDateNotKnownChkBx);		
	}

	public void enterPlanName(int memIndex, String planName)throws Exception{
		By planNameTxt = By.name("eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].planName");
		enterText("Mem"+(memIndex+1)+ "PlanNameTxt" , planNameTxt,planName);
	}

	public void enterPolicyNo(int memIndex, String policyNo)throws Exception{
		By policyNoTxt = By.name("eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].policyNumber");
		enterText("Mem"+(memIndex+1)+ "PolicyNoTxt" , policyNoTxt,policyNo);
	}

	public void clickOnMemberCoveredInPolicyOfMember(String firstName) throws Exception{
		By otherMemberCoveredInPolicyChkBx = By.xpath("//label[contains(text(),'"+firstName+"')]/parent::div/input[@type='checkbox']");
		clickOnElement(firstName+"CoveredInPolicyChkBx", otherMemberCoveredInPolicyChkBx);		
	}

	public void clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove(int memIndex) throws Exception{
		By otherMemberCoveredInPolicyChkBx = By.xpath("//label[text()='None of the Above']/parent::div/input[@type='checkbox']");
		clickOnElement("Mem"+(memIndex+1)+"NoMemberCoveredInPolicyChkBx", otherMemberCoveredInPolicyChkBx);		
	}

	public void clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove() throws Exception{
		By otherMemberCoveredInPolicyChkBx = By.xpath("//label[text()='None of the Above']/parent::div/input[@type='checkbox']");
		clickOnElement("Mem"+"NoMemberCoveredInPolicyChkBx", otherMemberCoveredInPolicyChkBx);		
	}

	public void selectIfExpectChangeInHealthCoverageForMember(int memIndex, boolean trueFalseValue) throws Exception{
		By expectChangeInHlthCoverageRdBtn = By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].expectingChanges' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem"+(memIndex+1)+"ExpectChangeInHlthCoverageRdBtn", expectChangeInHlthCoverageRdBtn);       
	}

	public void clickOnEmployerNoLongerOfferHeathCoverage() throws Exception{
		By employerNoLongerOfferHeathCoverageRdBtn = By.xpath("//label[contains(text()[normalize-space()],'will no longer offer health coverage')]/input");
		clickOnElement("EmployerNoLongerOfferHeathCoverageRdBtn", employerNoLongerOfferHeathCoverageRdBtn);		
	}	

	public void clickOnCoverageEndDateNotKnownChkBxForMember(int memIndex) throws Exception{
		By coverageEndDateNotKnownChkBx = By.id("eligibilityMember"+memIndex+".eligibilityMemberHealthCoverage.employersOfferingCoverage0.endCoverageDateNotKnownEmployer1");
		clickOnElement("Mem"+(memIndex+1)+"CoverageEndDateNotKnownChkBx", coverageEndDateNotKnownChkBx);		
	}	

	public void clickOnMemberPlantoDropHeathCoverage() throws Exception{
		By dropHeathCoverageRdBtn = By.id("drop_health_coverage");
		clickOnElement("DropHeathCoverageRdBtn", dropHeathCoverageRdBtn);		
	}

	public void selectIfHlthPlanMeetMinimumValueStandardForMember(int memIndex, boolean trueFalseValue) throws Exception{
		By minimumValueStandardRdBtn =By.xpath("//input[@name='eligibilityMember["+memIndex+"].eligibilityMemberHealthCoverage.employersOfferingCoverage[0].minimumValueStandard' and @value='"+trueFalseValue+"']/../label");
		clickOnElement("Mem"+(memIndex+1)+"MinimumValueStandardRdBtn", minimumValueStandardRdBtn);          
	}

	public void enterPlanPremiumCost(String premiumCost)throws Exception{
		By planPremiumCostTxt = By.id("premium_amount");
		enterText("PlanPremiumCostTxt" , planPremiumCostTxt,premiumCost);
	}

	public void selectPlanPremiumFrequency(String premiumFrequency)throws Exception{
		By planPremiumFrequencyDD = By.id("everyDD");
		selectDropDownElementByVisibleText("PlanPremiumFrequencyDD" , planPremiumFrequencyDD,premiumFrequency);
	}

	public void clickOnSaveAndContinueBtn() throws Exception{
		clickOnElement("SaveAndContinueBtn", saveAndContinueBtn);
	}

	public void pageLoadThenClickOnSaveAndContinueBtn() throws Exception{
		waitForPageLoaded();
		clickOnSaveAndContinueBtn();
	}

	public void evpdSelectHealthInsuranceInfoForMember(int memIndex, List<EVPD_MemData> memsData) throws Exception{
		waitForPageLoaded();
		selectIfEnrolledInCoverageYearForMember(memIndex, memsData.get(memIndex).enrolledInHPInCoverageYear);
		
		if(memsData.get(memIndex).enrolledInHPInCoverageYear){
			clickOnCoverageStartDateNotKnownChkBxForMember(memIndex);
			enterPlanName(memIndex, memsData.get(memIndex).planName);
			enterPolicyNo(memIndex, memsData.get(memIndex).policyNumber);
			if(!memsData.get(memIndex).otherMembersEnrolledInInsuranceByIndex.equals("")){
				clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove(memIndex);
				int memCount = memsData.size();
				for(int mCounter=0; mCounter < memCount ; mCounter++){
					if(memsData.get(memIndex).otherMembersEnrolledInInsuranceByIndex.contains(mCounter+"")){
						clickOnMemberCoveredInPolicyOfMember(memsData.get(mCounter).firstName);
					}
				}
			}else{
				//By Default None Of the Above already Disabled, so commenting it
				//clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove(memIndex);
			}

			selectIfExpectChangeInHealthCoverageForMember(memIndex, memsData.get(memIndex).insuranceExpChange);
			if(memsData.get(memIndex).insuranceExpChange){
				clickOnEmployerNoLongerOfferHeathCoverage();
				clickOnCoverageEndDateNotKnownChkBxForMember(memIndex);
				//clickOnMemberPlantoDropHeathCoverage();
			}else{
				selectIfHlthPlanMeetMinimumValueStandardForMember(memIndex, memsData.get(memIndex).insuranceCoverageAffordable);
				if(memsData.get(memIndex).insuranceCoverageAffordable){
					enterPlanPremiumCost(memsData.get(memIndex).planPremiumCost);
					selectPlanPremiumFrequency(memsData.get(memIndex).planPremiumFrequency);
				}		
			}

		}
		clickOnSaveAndContinueBtn();
	}
	
	public void racSelectHealthInsuranceInfoForMember(int memIndex, List<RAC_MemData> memsData) throws Exception{
		waitForPageLoaded();
		selectIfEnrolledInCoverageYearForMember(memIndex, memsData.get(memIndex).enrolledInHPInCoverageYear);
		
		if(memsData.get(memIndex).enrolledInHPInCoverageYear){
			clickOnCoverageStartDateNotKnownChkBxForMember(memIndex);
			enterPlanName(memIndex, memsData.get(memIndex).planName);
			enterPolicyNo(memIndex, memsData.get(memIndex).policyNumber);
			if(!memsData.get(memIndex).otherMembersEnrolledInInsuranceByIndex.equals("")){
				clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove(memIndex);
				int memCount = memsData.size();
				for(int mCounter=0; mCounter < memCount ; mCounter++){
					if(memsData.get(memIndex).otherMembersEnrolledInInsuranceByIndex.contains(mCounter+"")){
						clickOnMemberCoveredInPolicyOfMember(memsData.get(mCounter).firstName);
					}
				}
			}else{
				//By Default None Of the Above already Disabled, so commenting it
				//clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove(memIndex);
			}

			selectIfExpectChangeInHealthCoverageForMember(memIndex, memsData.get(memIndex).insuranceExpChange);
			if(memsData.get(memIndex).insuranceExpChange){
				clickOnEmployerNoLongerOfferHeathCoverage();
				clickOnCoverageEndDateNotKnownChkBxForMember(memIndex);
				//clickOnMemberPlantoDropHeathCoverage();
			}else{
				selectIfHlthPlanMeetMinimumValueStandardForMember(memIndex, memsData.get(memIndex).insuranceCoverageAffordable);
				if(memsData.get(memIndex).insuranceCoverageAffordable){
					enterPlanPremiumCost(memsData.get(memIndex).planPremiumCost);
					selectPlanPremiumFrequency(memsData.get(memIndex).planPremiumFrequency);
				}		
			}

		}
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void evpdSelectEmployerHealthCoverageInformationForMember(int memIndex, EVPD_Data evpdData) throws Exception{
		selectIfEnrolledInCoverageYearForMember(memIndex, evpdData.memsData.get(memIndex).enrolledInHPInCoverageYear);
		
		if(evpdData.memsData.get(memIndex).enrolledInHPInCoverageYear){
			clickOnCoverageStartDateNotKnownChkBxForMember(memIndex);
			enterPlanName(memIndex, evpdData.memsData.get(memIndex).planName);
			enterPolicyNo(memIndex, evpdData.memsData.get(memIndex).policyNumber);
			
			if(!evpdData.memsData.get(memIndex).otherMembersEnrolledInInsuranceByIndex.equals("")){
				clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove(memIndex);
				
				int memCount = evpdData.memsData.size();
				
				for(int mCounter = 0; mCounter < memCount; mCounter++){
					if(evpdData.memsData.get(memIndex).otherMembersEnrolledInInsuranceByIndex.contains(mCounter + "")){
						clickOnMemberCoveredInPolicyOfMember(evpdData.memsData.get(mCounter).firstName);
					}
				}
			}else{
				//By Default None Of the Above already Disabled, so commenting it
				//clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove(memIndex);
			}

			selectIfExpectChangeInHealthCoverageForMember(memIndex, evpdData.memsData.get(memIndex).insuranceExpChange);
			
			if(evpdData.memsData.get(memIndex).insuranceExpChange){
				clickOnEmployerNoLongerOfferHeathCoverage();
				clickOnCoverageEndDateNotKnownChkBxForMember(memIndex);
				//clickOnMemberPlantoDropHeathCoverage();
			}else{
				selectIfHlthPlanMeetMinimumValueStandardForMember(memIndex, evpdData.memsData.get(memIndex).insuranceCoverageAffordable);
				
				if(evpdData.memsData.get(memIndex).insuranceCoverageAffordable){
					enterPlanPremiumCost(evpdData.memsData.get(memIndex).planPremiumCost);
					selectPlanPremiumFrequency(evpdData.memsData.get(memIndex).planPremiumFrequency);
				}		
			}
		}
		
		clickOnSaveAndContinueBtn();
	}
	
	// ppinho
	public void racSelectEmployerHealthCoverageInformationForMember(int memIndex, RAC_Data racData) throws Exception{
		selectIfEnrolledInCoverageYearForMember(memIndex, racData.memsData.get(memIndex).enrolledInHPInCoverageYear);
		
		if(racData.memsData.get(memIndex).enrolledInHPInCoverageYear){
			clickOnCoverageStartDateNotKnownChkBxForMember(memIndex);
			enterPlanName(memIndex, racData.memsData.get(memIndex).planName);
			enterPolicyNo(memIndex, racData.memsData.get(memIndex).policyNumber);
			
			if(!racData.memsData.get(memIndex).otherMembersEnrolledInInsuranceByIndex.equals("")){
				clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove(memIndex);
				
				int memCount = racData.memsData.size();
				
				for(int mCounter = 0; mCounter < memCount; mCounter++){
					if(racData.memsData.get(memIndex).otherMembersEnrolledInInsuranceByIndex.contains(mCounter + "")){
						clickOnMemberCoveredInPolicyOfMember(racData.memsData.get(mCounter).firstName);
					}
				}
			}else{
				//By Default None Of the Above already Disabled, so commenting it
				//clickOnMemberCoveredInPolicyOfMemberAsNoneOfTheAbove(memIndex);
			}

			selectIfExpectChangeInHealthCoverageForMember(memIndex, racData.memsData.get(memIndex).insuranceExpChange);
			
			if(racData.memsData.get(memIndex).insuranceExpChange){
				clickOnEmployerNoLongerOfferHeathCoverage();
				clickOnCoverageEndDateNotKnownChkBxForMember(memIndex);
				//clickOnMemberPlantoDropHeathCoverage();
			}else{
				selectIfHlthPlanMeetMinimumValueStandardForMember(memIndex, racData.memsData.get(memIndex).insuranceCoverageAffordable);
				
				if(racData.memsData.get(memIndex).insuranceCoverageAffordable){
					enterPlanPremiumCost(racData.memsData.get(memIndex).planPremiumCost);
					selectPlanPremiumFrequency(racData.memsData.get(memIndex).planPremiumFrequency);
				}		
			}
		}
		
		clickOnSaveAndContinueBtn();
	}
	
}
