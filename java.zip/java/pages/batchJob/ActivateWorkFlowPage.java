package pages.batchJob;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

public class ActivateWorkFlowPage extends CommonPage implements CommonPageOR {

	private final static By activateWorkFlowPageHeader = By.xpath("");
	
	public ActivateWorkFlowPage(WebDriver driver, String featureName) 
	{
		super(driver,featureName);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("SSNRFIHeader", activateWorkFlowPageHeader);
	}
	
	public void goToActivateWorkFlowPage(String ipAddress) throws Exception{
		String url = "https://"+ipAddress + ":8448/workflowActivate";
		goTo(url);
	}
	
	public void selectEnvironment(String env) throws Exception{
		By envDD = By.id("envId");
		selectDropDownElementByVisibleText("EnvDD", envDD, env);
	}
	
	public void selectWorkFlow(String workFlow) throws Exception{
		By workFlowDD = By.id("workflowId");
		selectDropDownElementByVisibleText("WorkFlowDD", workFlowDD, workFlow);
	}
	
	public void selectServer(String server) throws Exception{
		By serverId = By.id("serverId");
		selectDropDownElementByVisibleText("ServerIdDD", serverId, server);
	}
	
	public void clickOnSubmit() throws Exception{
		By submitBtn = By.xpath("//button[text()='Submit']");
		clickOnElement("SubmitBtn", submitBtn);
	}
	
	public void refreshActiveWorkFlowPage() throws Exception{
		refreshCurrentPage();
	}
	
	public int getRecentWorkFlowRunId() throws Exception{
		By latestWorkFlowIdLabel = By.xpath("//table[@id='wfActivityList']/tbody/tr[1]/td[1]");
		String runId = getElementText("WorkFlowIdLabel", latestWorkFlowIdLabel); 
		return Integer.parseInt(runId);
	}
	
	public String getRecentWorkFlowStatus(int tryCounterVal, int runId) throws Exception{
		By latestWorkFlowIdLabel = By.xpath("//table[@id='wfActivityList']/tbody/tr[td[text()='"+runId+"']]/td[4]");
		String currentStatus = getElementText("WorkFlowId"+runId + "Status_"+tryCounterVal, latestWorkFlowIdLabel); 
		return currentStatus;
	}
	
	public int submitWorkFlow(String env, String workFlow, String server) throws Exception{
		selectEnvironment(env);
		selectWorkFlow(workFlow);
		selectServer(server);
		clickOnSubmit();
		pressEnterOnPage();
		refreshActiveWorkFlowPage();
		return getRecentWorkFlowRunId();
	}

	public void takeScreenshot() throws Exception {
		takeScreenshot("ActivateWorkFlow");
	}
	
}