package pages.batchJob;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;

public class WorkFlowStatusPage extends CommonPage implements CommonPageOR {

	
	public WorkFlowStatusPage(WebDriver driver, String featureName) 
	{
		super(driver,featureName);
	}
	
	public String getStatusByRunId(String ipAddress, String runId) throws Exception{
		String currentStatus = "";
		
		String url = "https://"+ipAddress + ":8448/workflow/getStatusByRunId/"+runId;
		goTo(url);
		currentStatus = getElementText("Current Status", By.xpath("/html/body"));
		return currentStatus;
	}
	
	
	
	
	/*
	For run id (4) 
	Request 1. https://localhost:8448/workflow/getStatusByRunId/4
	Response 1. "COMPLETED"

	For run id (4) 
	Request 2. https://localhost:8448/workflow/getTaskStatusByRunId/4
	Response 2. [{"key":"2","value":"COMPLETED"},{"key":"4","value":"COMPLETED"}]

*/
}