package pages.rac;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import enums.PortalName;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class ChangeYourInfoPage extends CommonPage implements CommonPageOR{

	UpdateDialog updateDialog = new UpdateDialog();
	
	private static final By changeYourInfoPageHeader = By.xpath("//h1[contains(text()[normalize-space()],'Change Your Information')]");
	
	private static final By addFamilyMemRdBtn = By.name("addFamilyMemers");
	private static final By removeFamilyMemRdBtn = By.name("removeFamilyMemers");
	private static final By updateIncomeRdBtn = By.name("changeIncome");
	private static final By changeStatusRdBtn = By.name("changeStatus");
	private static final By changeHomeAddrRdBtn = By.name("changeAddressAndIdentification");
	private static final By changeAppTypeRdBtn = By.name("changeEligibilityType");
	private static final By changePastTaxCreditInfoRdBtn = By.name("ftrOverride");
	
	private static final By reportChangeBtn = By.id("submitButton");
	
	
	public ChangeYourInfoPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}
	
	public void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocatedThenWait("ChangeYourInfoPageHeader", changeYourInfoPageHeader, 3);
	}

	public void selectAddFamilyMemRdBtn(boolean trueFalseValue) throws Exception{
		selectByValue("AddFamilyMemRdBtn", addFamilyMemRdBtn, trueFalseValue+"");
	}
	
	public void selectRemoveFamilyMemRdBtn(boolean trueFalseValue) throws Exception{
		selectByValue("RemoveFamilyMemRdBtn", removeFamilyMemRdBtn, trueFalseValue+"");
	}
	
	public void selectUpdateIncomeRdBtn(boolean trueFalseValue) throws Exception{
		selectByValue("UpdateIncomeRdBtn", updateIncomeRdBtn, trueFalseValue+"");
	}
	
	public void selectChangeStatusRdBtn(boolean trueFalseValue) throws Exception{
		selectByValue("ChangeStatusRdBtn", changeStatusRdBtn, trueFalseValue+"");
	}
	
	public void selectChangeHomeAddrRdBtn(boolean trueFalseValue) throws Exception{
		selectByValue("ChangeHomeAddrRdBtn", changeHomeAddrRdBtn, trueFalseValue+"");
	}
	
	public void selectChangeAppTypeRdBtn(boolean trueFalseValue) throws Exception{
		selectByValue("ChangeAppTypeRdBtn", changeAppTypeRdBtn, trueFalseValue+"");
	}
	
	public void selectChangePastTaxCreditRdBtn(boolean trueFalseValue) throws Exception{
		selectByValue("ChangePastTaxCreditInfoRdBtn", changePastTaxCreditInfoRdBtn, trueFalseValue+"");
	}
	
	public void clickOnReportChangeBtn() throws Exception{
		clickOnElement("ReportChangeBtn", reportChangeBtn);
	}
	
	public boolean isWarningDialogPresent() throws Exception{
		return isElementPresent(warningDialogH2);
	}
	
	public void clickOnWarningOkButton() throws Exception{
		clickOnElementThenWait("WarningOkButton", warningOkButton, 5);
	}
	
	public void takseScreenShot() throws Exception{
		waitForPageLoaded();
		takeScreenshot("Summary");
	}
	
	private class UpdateDialog{
		private void selectMemberForUpdate(int memIndex) throws Exception{
			By memChkBox = By.xpath("//div[@id='racMemberDialog']//input[@id='memberIndexes["+memIndex+"]']");
			clickOnElement("Mem"+(memIndex+1)+"ChkBox", memChkBox);
		}
		
		private void selectAllMemberForUpdate() throws Exception{
			By memChkBox = By.xpath("//div[@id='racMemberDialog']//input[@id='rac_memberIndexesAll']");
			clickOnElement("AllMemChkBox", memChkBox);
		}
		
		private void clickOnDialogOkButton() throws Exception{
			clickOnElement("PopupOkBtn", popupOkBtn);
		}
		
		private void clickOnDialogCancelButton() throws Exception{
			clickOnElement("PopupCancelBtn", popupCancelBtn);
		}
	}
	
	public void handleWarningDialogIfPresent() throws Exception{
		if(isWarningDialogPresent()){
			clickOnWarningOkButton();
		}
	}
	
	public void selectIncomeUpdateAndClickOnReportAChange() throws Exception{
		if(isWarningDialogPresent()){
			clickOnWarningOkButton();
		}
		waitForPageLoaded();
		selectUpdateIncomeRdBtn(true);
		clickOnReportChangeBtn();
		
	}
	
	
	public void contactInfoPreferences() throws Exception{
		By contactInfoPref = By.id("changeInOthers");
		clickOnElement("ContactInfoPreferencesLink", contactInfoPref);
	}
	
	public void selectAllMembersForIncomeUpdate(String portal, int memCount) throws Exception{

		if(memCount > 1 && !portal.equals(PortalName.ASSISTER.code)){
			updateDialog.selectAllMemberForUpdate();
			takeScreenshot("RACForMember");
			updateDialog.clickOnDialogOkButton();
		}
		
		if(isWarningDialogPresent()){
			takeScreenshot("RACForMember");
			clickOnWarningOkButton();
		}
		
	}
	
	public void selectMemberForUpdate(int memIndex) throws Exception{

		updateDialog.selectMemberForUpdate(memIndex);
		takeScreenshot("RACForMember");
		updateDialog.clickOnDialogOkButton();
		
		if(isWarningDialogPresent()){
			takeScreenshot("RACForMember");
			clickOnWarningOkButton();
		}
	}
	
	// added by ppinho
	public void selectAllMembersForUpdate(int memCount) throws Exception{		
		if(memCount > 1){
			updateDialog.selectAllMemberForUpdate();
			takeScreenshot("RACForMember");
			updateDialog.clickOnDialogOkButton();
			
			if(isWarningDialogPresent()){
				takeScreenshot("RACForMember");
				clickOnWarningOkButton();
			}
		}else{
			takeScreenshot("RACForMember");
			updateDialog.clickOnDialogOkButton();
			
			if(isWarningDialogPresent()){
				takeScreenshot("RACForMember");
				clickOnWarningOkButton();
			}
		}
	}
	
	public void clickOnOkBtn() throws Exception{
		clickOnWarningOkButton();
	}
}
