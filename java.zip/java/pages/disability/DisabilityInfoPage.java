package pages.disability;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.common.CommonPage;
import pages.common.CommonPageOR;
/**
 * 
 * @author Vinay Kumar
 *
 */
public class DisabilityInfoPage extends CommonPage implements CommonPageOR {

	private static final By disabilityInfoPageHeader = By.xpath("//h1[contains(.,'Disability Info')]");
	private static final By reRunEligibilityBtn = By.id("reRunEligibility");
	private static final By confirmReRunEligibilityBtn =By.xpath("//span[text()='CONFIRM']");
	
	public DisabilityInfoPage(WebDriver driver, String testCaseId) {
		super(driver, testCaseId);
	}

	private void waitForPageLoaded() throws Exception{
		waitForPresenceOfElementLocated("DisabilityInfoPageHeader", disabilityInfoPageHeader);
	}

	// updated by ppinho
	private void selectDisabilityForMember(String name, boolean isDisabled)throws Exception{
		By disabledRdBtn = By.xpath("//*[span[strong[contains(.,'"+name+"')]]]//following-sibling::div[1]//input[contains(@id,'isDisabled')]");
		selectByValue("DisabledRdBtn", disabledRdBtn, isDisabled+"");
	}

	// updated by ppinho
	private void selectBODisabilityCodeForMember(String name, String boDisabilityCode)throws Exception{
		By boDisabilityCodeRdBtn = By.xpath("//*[strong[contains(.,'" + name + "')]]/following::input[contains(@id, 'disabled') and @value='" + boDisabilityCode + "']");
		selectByValue("BODisabilityCodeRdBtn", boDisabilityCodeRdBtn, boDisabilityCode+"");
	}
	
	
	private void clickOnRerunEligibility() throws Exception  {
		clickOnElement("ReRunEligibilityBtn", reRunEligibilityBtn);
	}
	
	private void clickOnSaveBtn() throws Exception  {
		clickOnElement("SaveBtn",saveBtn);
	}
	
	private void clickOnConfrimRerunEligibilityBtn() throws Exception  {
		clickOnElement("ConfirmReRunEligibilityBtn",confirmReRunEligibilityBtn);
	}
	
	private void clickOnBackBtn() throws Exception  {
		clickOnElement("BackBtn",backButton);
	}
	
	private void optionalClickOnDisabilityMemTab(String name) throws Exception  {
		  By disabilityMemTab = By.xpath("//h2[contains(@aria-expanded,'false')]//strong[contains(.,'"+name+"')]");
		optionalClickOnElement("DisabilityMemTab",disabilityMemTab);
	}
	
	public void selectDisabilityAndRerun(String name, boolean isDisabled,String boDisabilityCode) throws Exception{
		waitForPageLoaded();
		optionalClickOnDisabilityMemTab(name);
		selectDisabilityForMember(name, isDisabled);
		if(isDisabled)
	    selectBODisabilityCodeForMember(name, boDisabilityCode);
		clickOnRerunEligibility();
		clickOnConfrimRerunEligibilityBtn();
		clickOnBackBtn();
	}

}


