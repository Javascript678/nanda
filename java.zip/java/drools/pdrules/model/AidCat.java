package drools.pdrules.model;

import java.util.ArrayList;
import java.util.List;

public enum AidCat{
      FOURTY_THREE("43", "MassHealth Standard plus Medicare Buy-In"),
      FOURTY_TWO("42", "MassHealth Standard"),
      EP("EP", "MassHealth Standard"),							// PA for 42
      A1("A1", "MassHealth Standard"),
      A4("A4", "MassHealth Standard"),							// PA for A1
      D1("D1", "MassHealth CarePlus"),
      D4("D4", "MassHealth CarePlus"),							// PA for D1
      M1("M1", "MassHealth Standard"),
      M4("M4", "MassHealth Standard"),							// PA for M1
      L1("L1", "MassHealth Standard"),
      L4("L4", "MassHealth Standard"),							// PA for L1
      H1("H1", "MassHealth Standard"),
      H4("H4", "MassHealth Standard"),							// PA for H1
      J1("J1", "MassHealth Standard"),
      J4("J4", "MassHealth Standard"),							// PA for J1
      FOURTY_EIGHT("48", "MassHealth Standard"),
      EJ("EJ", "MassHealth Standard"),							// PA for 48
      EK("EK", "MassHealth Standard"),					    	// PA for 40 and 48
      FOURTY("40", "MassHealth Standard"),
      AD("AD", "MassHealth Standard"),
      T1("T1", "MassHealth Standard"),
      T4("T4", "MassHealth Standard"),							//PA for T1
      B1("B1", "MassHealth Standard"),
      B4("B4", "MassHealth Standard"),							//PA for B1
      EIGHTEEN("18", "MassHealth Standard"),
      FOURTY_SIX("46", "MassHealth Standard"),
      A9("A9", "MassHealth Standard"),							//PA for 46
      FIFTY("50", "MassHealth CommonHealth"),
      EL("EL", "MassHealth CommonHealth"),						//PA for 50
      EM("EM", "MassHealth CommonHealth"),						//PA for 50
      FIFTY_ONE("51", "MassHealth CommonHealth"),
      EN("EN", "MassHealth CommonHealth"),						//PA for 51
      E1("E1", "MassHealth CommonHealth"),
      E4("E4", "MassHealth CommonHealth"),						//PA for E1
      R1("R1", "MassHealth Standard"),
      R4("R4", "MassHealth Standard"),							//PA for R1
      NINETY_THREE("93", "MassHealth Family Assistance"),
      SEVENTY_FIVE("75", "MassHealth Family Assistance"),		//PA for 93
      SEVENTY_EIGHT("78", "MassHealth Family Assistance"),		//PA for 93
      EIGHTY_FOUR("84", "MassHealth Family Assistance"),				
      EIGHTY_SIX("86","MassHealth Family Assistance"),			//PA for 84	
      N1("N1", "MassHealth Family Assistance"),
      NINETY_FIVE("95", "MassHealth Family Assistance"),
      SIXTY_FIVE("65", "MassHealth Family Assistance"),			//PA for 95
      U3("U3", "MassHealth Family Assistance"),
      NINETY("90", "MassHealth Family Assistance"),
      V2("V2", "MassHealth Family Assistance"),					//PA for 90
      Q1("Q1", "MassHealth Family Assistance"),
      AX("AX", "Children's Medical Security Plan + Limited"),
      THIRTY_SEVEN("37", "Limited + Health Safety Net"),
      AY("AY", "Children's Medical Security Plan"),
      BA("BA", "Children's Medical Security Plan"),
      ONE_X("1X", "Temporary Health Safety Net"),
      ONE_Y("1Y", "Temporary Health Safety Net"),
      Z3("Z3", "Temporary Health Safety Net"),
      Z4("Z4", "Temporary Health Safety Net"),
      AQ("AQ", "Health Safety Net Full"),
      AP("AP", "Health Safety Net Partial"),
      PT3B("--", "ConnectorCare Plan Type 3B"),
      PT3A("--", "ConnectorCare Plan Type 3A"),
      PT2B("--", "ConnectorCare Plan Type 2B"),
      PT2A("--", "ConnectorCare Plan Type 2A"),
      PT1("--", "ConnectorCare Plan Type 1"),
      HCP("--", "Health Connector Plans"),
      NOT_ELIGIBLE("--", "Not Eligible");

	public final String code;
    public final String valueOnUI;
    
    private AidCat(String code, String valueOnUI) {
        this.code = code;
        this.valueOnUI = valueOnUI;
    }
    
    public static List<String> getCodes() {
    	List<String> codes = new ArrayList<String>();
    	AidCat[] arrValues = AidCat.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		codes.add(arrValues[i].code);
    	}
    	return codes;
    }
    
    public static String get_UI_Val(String code) {
    	AidCat[] arrValues = AidCat.values();
    	
    	for(int i = 0; i < arrValues.length; i++){
    		if(arrValues[i].code.equals(code)){
    			return 	arrValues[i].valueOnUI;
    		}
    	}
    	return null;
    }
}