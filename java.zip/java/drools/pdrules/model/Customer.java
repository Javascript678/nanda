package drools.pdrules.model;

import java.util.List;

import appdata.evpd.EVPD_MemData;
import appdata.ruleEngine.RuleEngine_Data;

public class Customer {
	
	private AidCat aidCat;
	private String name = null;
	private String type = null;
	private boolean awaitingTrial = false;
	private int age = 0;
	private double mfpl = 0.00;
	private double tfpl = 0.00;
	private String immigrationStatus = null;
	private boolean medicareViaSelfAttestation = false;
	private boolean medicareViaHUB = false;
	private boolean disabled = false;
	private boolean hiv = false;
	private boolean bcc = false;
	private boolean pregnant = false;
	private boolean parent = false;
	private boolean medicallyFrail = false;
	private boolean formerFosterCare = false;
	private boolean esi = false;
	private boolean peaceCorps = false;
	private boolean veteransAffairs = false;
	private boolean tricare = false;
	private boolean other = false;
	private boolean tma = false;
	private boolean mmisReturns35 = false;
	private boolean mmisReturns02with3 = false;
	private boolean hsnWithin90Days = true;
	private boolean filingTaxes = false;
	private boolean financialAssistance = false;
	private boolean intendToReside = false;
	private String tplStatus = null;
	private Boolean meetsBasicBenefit = null;
	private Boolean enrolledPerMHRequest = null;
	private String insuranceCoverage = null;
	
	public Customer(List<EVPD_MemData> memsData, List<RuleEngine_Data> reData, int memIndex) {
		this.name = memsData.get(memIndex).firstName + " " + memsData.get(memIndex).lastName;
		this.type = reData.get(memIndex).Type;
		this.awaitingTrial = reData.get(memIndex).AwaitingTrial;
		this.age = reData.get(memIndex).Age;
		this.mfpl = reData.get(memIndex).MFPL;
		this.tfpl = reData.get(memIndex).TFPL;
		this.immigrationStatus = reData.get(memIndex).ImmigrationStatus;
		this.medicareViaSelfAttestation = reData.get(memIndex).MedicareViaSelfAttestation;
		this.medicareViaHUB = reData.get(memIndex).MedicareViaHUB;
		this.disabled = reData.get(memIndex).Disabled;            
		this.hiv = reData.get(memIndex).HIV;                 
		this.bcc = reData.get(memIndex).BCC;                 
		this.pregnant = reData.get(memIndex).Pregnant;            
		this.parent = reData.get(memIndex).Parent;              
		this.medicallyFrail = reData.get(memIndex).MedicallyFrail;      
		this.formerFosterCare = reData.get(memIndex).FormerFosterCare;    
		this.esi = reData.get(memIndex).ESI;                 
		this.peaceCorps = reData.get(memIndex).PeaceCorps;          
		this.veteransAffairs = reData.get(memIndex).VeteransAffairs;     
		this.tricare = reData.get(memIndex).Tricare;             
		this.other = reData.get(memIndex).Other;               
		this.tma = reData.get(memIndex).TMA;                 
		this.mmisReturns35 = reData.get(memIndex).MMISReturns35;
		this.mmisReturns02with3 = reData.get(memIndex).MMISReturns02with3;
		this.hsnWithin90Days = reData.get(memIndex).HsnWithin90Days;
		this.filingTaxes = reData.get(memIndex).FilingTaxes;
		this.financialAssistance = reData.get(memIndex).FinancialAssistance;
		this.intendToReside = reData.get(memIndex).IntendToReside;
		this.tplStatus = reData.get(memIndex).TPLStatus;           
		this.meetsBasicBenefit = reData.get(memIndex).MeetsBasicBenefit;   
		this.enrolledPerMHRequest = reData.get(memIndex).EnrolledPerMHRequest;
		this.insuranceCoverage = reData.get(memIndex).InsuranceCoverage;
	}

	public void setAidCat(AidCat aidCat) {
		this.aidCat = aidCat;
	}

	public AidCat getAidCat() {
		return aidCat;
	}

	public void setType(String Type) {
		this.type = Type;
	}

	public String getType() {
		return type;
	}
	
	public void setAwaitingTrial(boolean AwaitingTrial) {
		this.awaitingTrial = AwaitingTrial;
	}

	public boolean getAwaitingTrial() {
		return awaitingTrial;
	}
	
	public void setAge(int Age) {
		this.age = Age;
	}

	public int getAge(){
		return age;
	}
	
	public void setMFPL(double MFPL) {
		this.mfpl = MFPL;
	}

	public double getMFPL() {
		return mfpl;
	}
	
	public void setTFPL(double TFPL) {
		this.tfpl = TFPL;
	}

	public double getTFPL() {
		return tfpl;
	}
	
	public void setImmigrationStatus(String ImmigrationStatus) {
		this.immigrationStatus = ImmigrationStatus;
	}

	public String getImmigrationStatus() {
		return immigrationStatus;
	}
	
	public void setMedicareViaSelfAttestation(boolean MedicareViaSelfAttestation) {
		this.medicareViaSelfAttestation = MedicareViaSelfAttestation;
	}

	public boolean getMedicareViaSelfAttestation() {
		return medicareViaSelfAttestation;
	}
	
	public void setMedicareViaHUB(boolean MedicareViaHUB) {
		this.medicareViaHUB = MedicareViaHUB;
	}

	public boolean getMedicareViaHUB() {
		return medicareViaHUB;
	}
	
	public void setDisabled(boolean Disabled) {
		this.disabled = Disabled;
	}

	public boolean getDisabled() {
		return disabled;
	}
	
	public void setHIV(boolean HIV) {
		this.hiv = HIV;
	}

	public boolean getHIV() {
		return hiv;
	}
	
	public void setBCC(boolean BCC) {
		this.bcc = BCC;
	}

	public boolean getBCC() {
		return bcc;
	}
	
	public void setPregnant(boolean Pregnant) {
		this.pregnant = Pregnant;
	}

	public boolean getPregnant() {
		return pregnant;
	}
	
	public void setParent(boolean Parent) {
		this.parent = Parent;
	}

	public boolean getParent() {
		return parent;
	}
	
	public void setMedicallyFrail(boolean MedicallyFrail) {
		this.medicallyFrail = MedicallyFrail;
	}

	public boolean getMedicallyFrail() {
		return medicallyFrail;
	}
	
	public void setFormerFosterCare(boolean FormerFosterCare) {
		this.formerFosterCare = FormerFosterCare;
	}

	public boolean getFormerFosterCare() {
		return formerFosterCare;
	}
	
	public void setTMA(boolean TMA) {
		this.tma = TMA;
	}

	public boolean getTMA() {
		return tma;
	}
	
	public void setESI(boolean ESI) {
		this.esi = ESI;
	}

	public boolean getESI() {
		return esi;
	}
	
	public void setPeaceCorps(boolean PeaceCorps) {
		this.peaceCorps = PeaceCorps;
	}

	public boolean getPeaceCorps() {
		return peaceCorps;
	}
	
	public void setVeteransAffairs(boolean VeteransAffairs) {
		this.veteransAffairs = VeteransAffairs;
	}

	public boolean getVeteransAffairs() {
		return veteransAffairs;
	}
	
	public void setTricare(boolean Tricare) {
		this.tricare = Tricare;
	}

	public boolean getTricare() {
		return tricare;
	}
	
	public void setOther(boolean Other) {
		this.other = Other;
	}

	public boolean getOther() {
		return other;
	}
	
	public void setMMISReturns35(boolean MMISReturns35) {
		this.mmisReturns35 = MMISReturns35;
	}

	public boolean getMMISReturns35() {
		return mmisReturns35;
	}
	
	public void setMMISReturns02with3(boolean MMISReturns02with3) {
		this.mmisReturns02with3 = MMISReturns02with3;
	}

	public boolean getMMISReturns02with3() {
		return mmisReturns02with3;
	}
	
	public void setHsnWithin90Days(boolean HsnWithin90Days) {
		this.hsnWithin90Days = HsnWithin90Days;
	}

	public boolean getHsnWithin90Days() {
		return hsnWithin90Days;
	}
	
	public void setFilingTaxes(boolean FilingTaxes) {
		this.filingTaxes = FilingTaxes;
	}

	public boolean getFilingTaxes() {
		return filingTaxes;
	}
	
	public void setFinancialAssistance(boolean FinancialAssistance) {
		this.financialAssistance = FinancialAssistance;
	}

	public boolean getFinancialAssistance() {
		return financialAssistance;
	}
	
	public void setIntendToReside(boolean IntendToReside) {
		this.intendToReside = IntendToReside;
	}

	public boolean getIntendToReside() {
		return intendToReside;
	}
	
	public void setTPLStatus(String TPLStatus) {
		this.tplStatus = TPLStatus;
	}

	public String getTPLStatus() {
		return tplStatus;
	}
	
	public void setMeetsBasicBenefit(boolean MeetsBasicBenefit) {
		this.meetsBasicBenefit = MeetsBasicBenefit;
	}

	public boolean getMeetsBasicBenefit() {
		return meetsBasicBenefit;
	}
	
	public void setEnrolledPerMHRequest(boolean EnrolledPerMHRequest) {
		this.enrolledPerMHRequest = EnrolledPerMHRequest;
	}

	public boolean getEnrolledPerMHRequest() {
		return enrolledPerMHRequest;
	}

	public void setInsuranceCoverage(String InsuranceCoverage) {
		this.insuranceCoverage = InsuranceCoverage;
	}

	public String getInsuranceCoverage() {
		return insuranceCoverage;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return name + ": " + type + " - " + age + " " + mfpl + " "  + tfpl + " " + immigrationStatus + " " + medicareViaSelfAttestation + " " + 
			   medicareViaHUB + " " + disabled + " " + hiv + " " + bcc + " " + pregnant + " " + parent + " " + medicallyFrail + " " + formerFosterCare + " " + 
			   esi + " " + peaceCorps + " " + veteransAffairs + " " + tricare + " " + other + " " + tma + " " + mmisReturns35 + " " + mmisReturns02with3 + " " + 
			   hsnWithin90Days + " " + filingTaxes + " " + financialAssistance + " " + intendToReside + " " +  tplStatus + " " + 
			   meetsBasicBenefit + " " + enrolledPerMHRequest+ " " + insuranceCoverage;
	}
	
}
