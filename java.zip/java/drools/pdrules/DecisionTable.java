package drools.pdrules;

import java.util.List;

import drools.pdrules.model.Customer;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import appdata.evpd.EVPD_MemData;
import appdata.ruleEngine.RuleEngine_Data;

/** @author ppinho
 * This is a class to launch a decision table.
 */
public class DecisionTable {
    public void runRuleEngine(List<RuleEngine_Data> reData, List<EVPD_MemData> memsData, String type, int memIndex) {    	
	    KieSession knowledgeSession = null;
	    
	    reData.get(memIndex).Type = type;
	    
	    // For MH pass MAGI FPL to Rule Engine Else for CCA pass Tax FPL
        if(type.equals("MH")){
        	if(Double.parseDouble(memsData.get(memIndex).magiFPL) > 500.00){ 
        		reData.get(memIndex).MFPL = 500.00; 
        	}else{
        		reData.get(memIndex).MFPL = Double.parseDouble(memsData.get(memIndex).magiFPL);
        	}
        }else if(type.equals("CCA")){
        	if(Double.parseDouble(memsData.get(memIndex).taxFPL) > 500.00){ 
        		reData.get(memIndex).MFPL = 500.00; 
        	}else{
        		reData.get(memIndex).MFPL = Double.parseDouble(memsData.get(memIndex).taxFPL);
        	}
        }
	    
	    try {
	    	// load up the knowledge base
	    	KieServices ks = KieServices.Factory.get();
	        KieContainer kContainer = ks.getKieClasspathContainer();
	        knowledgeSession = kContainer.newKieSession("ksession-rules");
	        		
	        Customer customer = new Customer(memsData, reData, memIndex);
            
            knowledgeSession.insert(customer);
            knowledgeSession.fireAllRules();
            
            System.out.println(customer);
            
			switch(type){
				case "MH":
		            memsData.get(memIndex).mhProgramDetermination = customer.getAidCat().valueOnUI;            
		            memsData.get(memIndex).mhAidCat = customer.getAidCat().code;
		            break;
		            
				case "CCA":
		            memsData.get(memIndex).ccaProgramDetermination = customer.getAidCat().valueOnUI;            
		            memsData.get(memIndex).ccaAidCat = customer.getAidCat().code;
		            break;
			}
            
            System.out.println("Program Determination: " + customer.getAidCat().valueOnUI + "\n" + 
            				   "Aid Cat: " + customer.getAidCat().code);
            
        }catch(Throwable t){
        	System.out.println("Rule Not Found!");
            // t.printStackTrace();
        }finally{
			knowledgeSession.dispose();
        }
    }

}
